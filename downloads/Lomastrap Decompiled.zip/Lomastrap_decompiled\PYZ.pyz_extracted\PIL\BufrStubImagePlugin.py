from __future__ import annotations
import os
from . import Image, ImageFile
TYPE_CHECKING = False
if TYPE_CHECKING:
    from typing import IO

def register_handler(handler: 'ImageFile.StubHandler | None') -> 'None':
    '''
    Install application-specific BUFR image handler.

    :param handler: Handler object.
    '''

    BufrStubImageFile._handler = handler

def _accept(prefix: 'bytes') -> 'bool':
    return prefix.startswith((b'BUFR', b'ZCZC'))

class BufrStubImageFile(ImageFile.StubImageFile):
    format = 'BUFR'
    format_description = 'BUFR'
    def _open(self) -> 'None':
        assert self.fp is not None
        if not _accept(self.fp.read(4)):
            msg = 'Not a BUFR file'
            raise SyntaxError(msg)
        self.fp.seek(-4, os.SEEK_CUR)
        self._mode = 'F'


def _save(im: 'Image.Image', fp: 'IO[bytes]', filename: 'str | bytes') -> 'None':
    if BufrStubImageFile._handler is None or not hasattr(BufrStubImageFile._handler, 'save'):
        msg = 'BUFR save handler not installed'
        raise OSError(msg)
    BufrStubImageFile._handler.save(im, fp, filename)

Image.register_open(BufrStubImageFile.format, BufrStubImageFile, _accept)
Image.register_save(BufrStubImageFile.format, _save)
Image.register_extension(BufrStubImageFile.format, '.bufr')
