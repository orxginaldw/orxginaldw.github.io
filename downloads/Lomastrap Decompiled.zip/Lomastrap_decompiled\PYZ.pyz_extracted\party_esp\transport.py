'''A reusable TLS connection owned by the health sender; no redirects or credential logging.'''

import http.client
import json
import threading
from urllib.parse import urlsplit
from lomastrap_access import (AccessError, Unavailable, connection_error, https_context, VERSION)

class PersistentPartyTransport:
    def __init__(self, endpoint, connection_factory=None):
        url = urlsplit(endpoint)
        if url.scheme != 'https' or not url.hostname or url.username or url.password or url.query or url.fragment:
            raise ValueError('Invalid shared-health HTTPS endpoint')
        self.host, self.port, self.path = url.hostname, url.port, url.path.rstrip('/') + '/party/state'
        self.factory = connection_factory or http.client.HTTPSConnection
        self.context, self.connection = None, None
        self.lock = threading.Lock()

    def __call__(self, body, token):
        with self.lock:
            try:
                if self.connection is None:
                    if self.context is None:
                        self.context = https_context()
                    self.connection = self.factory(self.host, port=self.port, timeout=3, context=self.context)
                payload = json.dumps(body, separators=(',', ':'))
                self.connection.request('POST', self.path, body=payload, headers={'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json', 'Accept': 'application/json', 'User-Agent': 'Lomastrap/' + VERSION})
                response = self.connection.getresponse()
                raw = response.read(262145)
                if len(raw) > 262144:
                    raise Unavailable('Shared health response is oversized')
                if not 200 <= response.status < 300:
                    messages = {400: 'Shared health request rejected. Deploy the latest Worker for sync heartbeats.', 401: 'Session ended. Sign in again.', 403: 'Access removed or permission required.', 429: 'Shared health service is rate limiting updates.', 404: 'Shared health endpoint not found. Update the Worker.'}
                    raise AccessError(messages.get(response.status, 'Shared health service unavailable. Check the Worker and PARTY_ROOMS binding.'))
                result = json.loads(raw)
                if not isinstance(result, dict):
                    raise ValueError()
            except AccessError:
                self._close()
                raise
            except (OSError, http.client.HTTPException) as exc:
                self._close()
                raise Unavailable(connection_error(exc)) from None
            except (ValueError, UnicodeError):
                self._close()
                raise Unavailable('Unreadable shared health response') from None
            return result

    def _close(self):
        if self.connection:
            self.connection.close()
            self.connection = None

    def close(self):
        with self.lock:
            self._close()


