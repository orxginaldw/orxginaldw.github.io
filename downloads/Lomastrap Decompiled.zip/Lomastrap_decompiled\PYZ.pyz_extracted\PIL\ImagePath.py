from __future__ import annotations
from . import Image
Path = Image.core.path
