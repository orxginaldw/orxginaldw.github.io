'''Support for running coroutines in parallel with staggered start times.'''

__all__ = ('staggered_race',)
import contextlib
from . import events
from . import exceptions as exceptions_mod
from . import locks
from . import tasks

async def staggered_race(coro_fns, delay, *, loop=None):
    """Run coroutines with staggered start times and take the first to finish.

    This method takes an iterable of coroutine functions. The first one is
    started immediately. From then on, whenever the immediately preceding one
    fails (raises an exception), or when *delay* seconds has passed, the next
    coroutine is started. This continues until one of the coroutines complete
    successfully, in which case all others are cancelled, or until all
    coroutines fail.

    The coroutines provided should be well-behaved in the following way:

    * They should only ``return`` if completed successfully.

    * They should always raise an exception if they did not complete
      successfully. In particular, if they handle cancellation, they should
      probably reraise, like this::

        try:
            # do work
        except asyncio.CancelledError:
            # undo partially completed work
            raise

    Args:
        coro_fns: an iterable of coroutine functions, i.e. callables that
            return a coroutine object when called. Use ``functools.partial`` or
            lambdas to pass arguments.

        delay: amount of time, in seconds, between starting coroutines. If
            ``None``, the coroutines will run sequentially.

        loop: the event loop to use.

    Returns:
        tuple *(winner_result, winner_index, exceptions)* where

        - *winner_result*: the result of the winning coroutine, or ``None``
          if no coroutines won.

        - *winner_index*: the index of the winning coroutine in
          ``coro_fns``, or ``None`` if no coroutines won. If the winning
          coroutine may return None on success, *winner_index* can be used
          to definitively determine whether any coroutine won.

        - *exceptions*: list of exceptions returned by the coroutines.
          ``len(exceptions)`` is equal to the number of coroutines actually
          started, and the order is the same as in ``coro_fns``. The winning
          coroutine's entry is ``None``.

    """

    loop = loop or events.get_running_loop()
    enum_coro_fns = enumerate(coro_fns)
    winner_result = None
    winner_index = None
    unhandled_exceptions = []
    exceptions = []
    running_tasks = set()
    on_completed_fut = None
    def task_done(task):
        running_tasks.discard(task)
        if on_completed_fut is not None and not on_completed_fut.done() and not running_tasks:
            on_completed_fut.set_result(None)
        if task.cancelled():
            return
        exc = task.exception()
        if exc is None:
            return
        unhandled_exceptions.append(exc)

    async def run_one_coro(ok_to_start, previous_failed) -> None:
        nonlocal winner_index, winner_result
        await ok_to_start.wait()
        if previous_failed is not None:
            with contextlib.suppress(exceptions_mod.TimeoutError):
                await tasks.wait_for(previous_failed.wait(), delay)
        try:
            this_index, coro_fn = next(enum_coro_fns)
        except StopIteration:
            return
        this_failed = locks.Event()
        next_ok_to_start = locks.Event()
        next_task = loop.create_task(run_one_coro(next_ok_to_start, this_failed))
        running_tasks.add(next_task)
        next_task.add_done_callback(task_done)
        next_ok_to_start.set()
        exceptions.append(None)
        assert len(exceptions) == this_index + 1
        try:
            result = await coro_fn()
        except (SystemExit, KeyboardInterrupt):
            raise
        except BaseException as e:
            exceptions[this_index] = e
            this_failed.set()
        assert winner_index is None
        winner_index = this_index
        winner_result = result
        current_task = tasks.current_task(loop)
        for t in running_tasks:
            if t is not current_task:
                t.cancel()

    propagate_cancellation_error = None
    try:
        ok_to_start = locks.Event()
        first_task = loop.create_task(run_one_coro(ok_to_start, None))
        running_tasks.add(first_task)
        first_task.add_done_callback(task_done)
        ok_to_start.set()
        propagate_cancellation_error = None
        while running_tasks:
            on_completed_fut = loop.create_future()
            try:
                await on_completed_fut
            except exceptions_mod.CancelledError as ex:
                propagate_cancellation_error = ex
                for task in running_tasks:
                    task.cancel(*ex.args)
            on_completed_fut = None
        if unhandled_exceptions:
            raise ExceptionGroup('staggered race failed', unhandled_exceptions)
        if propagate_cancellation_error is not None:
            raise propagate_cancellation_error
    finally:
        del exceptions, propagate_cancellation_error, unhandled_exceptions
    return winner_result, winner_index, exceptions

