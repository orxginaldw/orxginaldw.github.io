from __future__ import annotations
__lazy_modules__ = {'io'}
import io
from . import ContainerIO

class TarIO(ContainerIO.ContainerIO[bytes]):
    '''A file object that provides read access to a given member of a TAR file.'''

    def __init__(self, tarfile: 'str', file: 'str') -> 'None':
        '''
        Create file object.

        :param tarfile: Name of TAR file.
        :param file: Name of member file.
        '''

        self.fh = open(tarfile, 'rb')
        while True:
            s = self.fh.read(512)
            if len(s) != 512:
                self.fh.close()
                msg = 'unexpected end of tar file'
                raise OSError(msg)
            name = s[:100].decode('utf-8')
            i = name.find('\x00')
            if i == 0:
                self.fh.close()
                msg = 'cannot find subfile'
                raise OSError(msg)
            if i > 0:
                name = name[:i]
            size = int(s[124:135], 8)
            if size < 0:
                self.fh.close()
                msg = 'size must not be negative'
                raise ValueError(msg)
            if file == name:
                break
            offset = size + 511 & -512
            self.fh.seek(offset, io.SEEK_CUR)
        super().__init__(self.fh, self.fh.tell(), size)


