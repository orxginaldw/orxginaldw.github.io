import typing

def theme():
    pass

def isDark():
    pass

def isLight():
    pass

def listener(callback: typing.Callable[[str], None]) -> None:
    raise NotImplementedError()

