'''Conservative three-word server recognition and stable, recent HUD evidence.'''

from collections import Counter
from functools import lru_cache
import json
from pathlib import Path
import re
import sys
import time
import unicodedata
import lomastrap_logic as logic
ROOT = Path(getattr(sys, '_MEIPASS', Path(__file__).parent))
DATA = json.loads((ROOT / 'assets/server-vocabulary.json').read_text(encoding='utf-8'))
WORDS = [tuple(DATA[field] + DATA.get('owner_examples', {}).get(field, [])) for field in ('adjectives', 'colors', 'nouns')]
REGIONS = tuple(DATA['regions'])
COUNTRIES = set('AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BV BW BY BZ CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL TM TN TO TR TT TV TW TZ UA UG UK UM US UY UZ VA VC VE VG VI VN VU WF WS YE YT ZA ZM ZW'.split())

def letters(value):
    return ''.join((c for c in unicodedata.normalize('NFKD', value).casefold()
         if c.isascii() and c.isalpha()))

@lru_cache(maxsize=12000)
def distance(a, b):
    '''Damerau-Levenshtein (adjacent transpositions such as falocn).'''

    previous_previous = None
    previous = list(range(len(b) + 1))
    for i, x in enumerate(a, 1):
        current = [i]
        for j, y in enumerate(b, 1):
            value = min(current[-1] + 1, previous[j] + 1, previous[j - 1] + (x != y))
            if previous_previous is not None and i > 1 and j > 1 and x == b[j - 2] and a[i - 2] == y:
                value = min(value, previous_previous[j - 2] + 1)
            current.append(value)
        previous_previous, previous = previous, current
    return previous[-1]

@lru_cache(maxsize=4096)
def word(token, position):
    token = letters(token)
    if not token:
        return
    exact = [w for w in WORDS[position] if w.casefold() == token]
    if exact:
        return exact[0], 0
    maximum = 1 if len(token) < 7 else 2
    candidates = sorted(((distance(token, w.casefold()), w) for w in WORDS[position]
         if abs(len(w) - len(token)) <= maximum))
    if not candidates or candidates[0][0] > maximum:
        return
    if len(candidates) > 1 and candidates[1][0] == candidates[0][0]:
        return
    return candidates[0][1], candidates[0][0]

@lru_cache(maxsize=2048)
def server_name(value):
    value = re.sub('(?<=[a-z])(?=[A-Z])', ' ', value)
    tokens = value.split()
    if len(tokens) == 3:
        menus = {'home', 'games', 'login', 'search', 'friends', 'profile', 'discover', 'settings'}
        if sum((t.casefold() in menus for t in tokens)) >= 2:
            return
        if any((not t.isascii() or not t.isalpha() or not 2 <= len(t) <= 30 or len(set(t.casefold())) == 1 for t in tokens)):
            return
        repaired = []
        for index, token in enumerate(tokens):
            exact = next((w for w in WORDS[index] if w.casefold() == token.casefold()), None)
            guess = word(token, index)
            swaps = {token[:i] + token[i + 1] + token[i] + token[i + 2:] for i in range(len(token) - 1)}
            obvious = guess and (guess[0].casefold() in {w.casefold() for w in swaps} or guess[0].casefold().replace('l', 'i') == token.casefold().replace('l', 'i'))
            repaired.append(exact or (guess[0] if obvious else token.title()))
            continue
        if len({w.casefold() for w in repaired}) == 3:
            return ' '.join(repaired)
        return
    possibilities = []
    if len(tokens) == 2:
        for index in (0, 1):
            for split in range(2, len(tokens[index]) - 1):
                possibilities.append(tokens[:index] + [tokens[index][:split], tokens[index][split:]] + tokens[index + 1:])
    elif len(tokens) == 1:
        if 12 <= len(tokens[0]) <= 45:
            for first in set((len(w) for w in WORDS[0])):
                for second in set((len(w) for w in WORDS[1])):
                    if first + second < len(value) - 2:
                        possibilities.append([value[:first], value[first:first + second], value[first + second:]])
    results = {}
    for parts in possibilities:
        if any((not p.isalpha() for p in parts)):
            continue
        corrected = [word(token, index) for index, token in enumerate(parts)]
        if any((item is None for item in corrected)):
            continue
        if len({item[0].casefold() for item in corrected}) != 3:
            continue
        name = ' '.join((item[0] for item in corrected))
        cost = sum((item[1] for item in corrected))
        if cost <= 3:
            results[name] = min(cost, results.get(name, 100))
    ranked = sorted(((score, name) for name, score in results.items()))
    if ranked:
        if len(ranked) > 1 and ranked[0][0] == ranked[1][0]:
            return
    return ranked[0][1]

def region(value):
    value = logic._region_line(value)
    if ',' not in value:
        return ''
    city, code = value.rsplit(',', 1)
    raw_code = code.strip()
    code = re.sub('[^A-Za-z]', '', raw_code).upper()
    aliases = {'GB': 'UK', 'USA': 'US', 'IJK': 'UK', 'LJK': 'UK'}
    code = aliases.get(code, code)
    if code not in COUNTRIES:
        match = re.fullmatch('([A-Za-z]{2})(?:[. :;!|]*[Ilı|!.,:;]*)', raw_code)
        code = aliases.get(match[1].upper(), match[1].upper()) if match else ''
    if code not in COUNTRIES:
        return ''
    city = city.strip()
    if not 2 <= len(city) <= 60:
        return ''
    options = [r for r in REGIONS if r.endswith(', ' + code)]
    ranked = sorted(((distance(letters(city), letters(r.rsplit(',', 1)[0])), r) for r in options))
    if ranked and ranked[0][0] <= 2:
        if len(ranked) == 1 or ranked[1][0] > ranked[0][0]:
            return ranked[0][1]
    return city + ', ' + code

def parse_hud(text):
    if not isinstance(text, str):
        return
    raw = logic.parse_reading(text)
    if raw is None:
        return
    name = server_name(raw.server)
    if name is None:
        return
    location = region(raw.area)
    luminant = raw.luminant if raw.luminant in logic.KNOWN_LUMINANTS else ''
    return logic.Reading(name, location, luminant)

class HudTracker:
    '''Three reads initially, five for a different server; no candidate in the UI.'''

    def __init__(self, clock=time.monotonic, initial=3, change=5, candidate_gap=10.0, idle_seconds=60.0):
        self.clock = clock
        self.initial, self.change = initial, change
        self.candidate_gap = candidate_gap
        self.idle_seconds = idle_seconds
        self.next_check = 0.0
        self.settled = False
        self.idle_lease_until = float('-inf')
        self.confirmed = None
        self.candidate = None
        self.count = 0
        self.last_good = float('-inf')
        self.absent = True
        self.explicit_absent = True
        self._metadata = []

    @property
    def ready(self):
        return self.confirmed is not None

    def time_until_read(self):
        if self.settled:
            return max(0.0, self.next_check - self.clock())
        return 0.0

    def force_fast(self):
        self.settled = False
        self.next_check = 0.0
        self.idle_lease_until = min(self.idle_lease_until, self.clock())

    def _same_confirmed(self, reading):
        return bool(reading and self.confirmed and reading.server == self.confirmed.server and (not reading.area or reading.area == self.confirmed.area) and (not reading.luminant or reading.luminant == self.confirmed.luminant))

    def _settle(self):
        self.settled = True
        self.next_check = self.clock() + self.idle_seconds
        self.idle_lease_until = self.next_check

    def cached_eligible(self):
        '''Only health/display can use the scheduled lease. Sending a ping still refreshes OCR.'''

        return bool(self.settled and self.time_until_read() > 0 and not self.absent and not self.explicit_absent and self._same_confirmed(self.candidate))

    def failed(self):
        self.force_fast()
        self.absent = True
        self.count, self.candidate = 0, None
        self._metadata = []

    def feed_text(self, text):
        self.force_fast()
        if self.clock() - self.last_good > self.candidate_gap:
            self.count, self.candidate = 0, None
            self._metadata = []
        reading = parse_hud(text)
        if reading is None or not reading.area and not reading.luminant:
            tokens = set(text.casefold().split())
            metadata = any((logic._luminant_line(line) or region(line) for line in text.splitlines()))
            explicit_absence = not text.strip() or bool(tokens & {'home', 'games', 'login', 'avatar', 'roblox', 'search', 'friends', 'loading', 'profile', 'discover', 'settings'})
            self.absent = explicit_absence or not metadata
            self.explicit_absent = bool(tokens & {'home', 'games', 'login', 'avatar', 'roblox', 'search', 'friends', 'loading', 'profile', 'discover', 'settings'})
            if explicit_absence:
                self.count, self.candidate = 0, None
                self._metadata = []
            return reading
        self.last_good = self.clock()
        self.absent = False
        self.explicit_absent = False
        if self._same_confirmed(reading):
            self.candidate = reading
            self.count = self.initial
            self._metadata = [reading]
            self._settle()
            return reading
        if self.candidate is None or reading.server != self.candidate.server:
            self.candidate, self.count, self._metadata = reading, 1, [reading]
        else:
            self.count += 1
            self._metadata.append(reading)
            self._metadata = self._metadata[-5:]
        self.candidate = reading
        needed = self.initial if self.confirmed is None else self.change
        if self.confirmed and reading.server == self.confirmed.server:
            needed = self.initial
        if self.count >= needed:
            def stable(field):
                values = [getattr(r, field) for r in self._metadata if getattr(r, field)]
                counts = Counter(values)
                if counts and counts.most_common(1)[0][1] >= 2:
                    return counts.most_common(1)[0][0]
                return ''

            previous = self.confirmed if self.confirmed and self.confirmed.server == reading.server else None
            self.confirmed = logic.Reading(reading.server, stable('area') or (previous.area if previous else ''), stable('luminant') or (previous.luminant if previous else ''))
            self.count = min(self.count, needed)
            if self._same_confirmed(reading):
                self._settle()
        return reading

    def status(self, reading):
        if self.settled:
            return 'Server confirmed - automatic server check once per minute.'
        if self.eligible():
            return 'Watching - server confirmed'
        if reading is None:
            return 'HUD name unreadable: select a clear three-word name and check raw OCR below.'
        if not reading.area and not reading.luminant:
            return 'Server name read; waiting for a readable region or Luminant. Check the capture area.'
        needed = self.initial if not self.confirmed or reading.server == self.confirmed.server else self.change
        return f'Verifying server: {min(self.count, needed)}/{needed} matching reads.'

    def eligible(self):
        return bool(self.confirmed and not self.absent and self.clock() - self.last_good <= 3 and self.candidate and self.candidate.server == self.confirmed.server and (not self.candidate.area or not self.confirmed.area or self.candidate.area == self.confirmed.area) and (not self.candidate.luminant or not self.confirmed.luminant or self.candidate.luminant == self.confirmed.luminant))

    def display_eligible(self):
        '''Display/HP presence tolerates brief unreadable HUDs; sending still uses eligible().'''

        return bool(self.confirmed and not self.explicit_absent and self.clock() - max(self.last_good, self.idle_lease_until) <= 30)


