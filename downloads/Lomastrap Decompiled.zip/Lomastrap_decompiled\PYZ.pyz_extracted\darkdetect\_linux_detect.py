import subprocess

def theme():
    try:
        out = subprocess.run(['gsettings', 'get', 'org.gnome.desktop.interface', 'color-scheme'], capture_output=True)
        stdout = out.stdout.decode()
        if len(stdout) < 1:
            out = subprocess.run(['gsettings', 'get', 'org.gnome.desktop.interface', 'gtk-theme'], capture_output=True)
            stdout = out.stdout.decode()
    except Exception:
        return 'Light'
    theme = stdout.lower().strip()[1:-1]
    if '-dark' in theme.lower():
        return 'Dark'
    return 'Light'

def isDark():
    return theme() == 'Dark'

def isLight():
    return theme() == 'Light'

def listener(callback):
    with subprocess.Popen(('gsettings', 'monitor', 'org.gnome.desktop.interface', 'gtk-theme'), stdout=subprocess.PIPE, universal_newlines=True) as p:
        for line in p.stdout:
            callback('Dark' if '-dark' in line.strip().removeprefix("gtk-theme: '").removesuffix("'").lower() else 'Light')

