from __future__ import annotations
import sys
from cryptography.hazmat.bindings._rust import openssl as rust_openssl
from cryptography.hazmat.primitives.kdf import KeyDerivationFunction
_MEM_LIMIT = sys.maxsize // 2
Scrypt = rust_openssl.kdf.Scrypt
KeyDerivationFunction.register(Scrypt)
__all__ = ['Scrypt']
