'''Bounded image preprocessing and agreement between independent OCR passes.

No server dictionary: names must come from the current captured pixels.
'''

from collections import Counter
import re
from PIL import (Image, ImageChops, ImageOps, ImageStat)
import lomastrap_logic as logic

class OcrText(str):
    def __new__(cls, selected, raw):
        value = super().__new__(cls, selected)
        value.raw = raw
        return value


def variants(image):
    if image.width < 20 or image.height < 12:
        raise ValueError('Capture area is too small for readable text.')
    if image.width > 2048 or image.height > 1024:
        raise ValueError('Capture area is too large. Select only the server information.')
    gray = image.convert('L')
    scale = min(4, 2048 / max(image.size))
    size = max(1, round(image.width * scale)), max(1, round(image.height * scale))
    baseline_scale = min(3, 2048 / max(image.size))
    yield ('contrast', ImageOps.autocontrast(gray).resize((round(gray.width * baseline_scale), round(gray.height * baseline_scale)), Image.Resampling.LANCZOS))
    if ImageStat.Stat(gray).stddev[0] < 3:
        return
    enlarged = gray.resize(size, Image.Resampling.LANCZOS)
    yield ('bright-core', enlarged.point((lambda v: 255 if v > 220 else 0)))
    rgb = image.convert('RGB')
    r, g, b = rgb.split()
    low = ImageChops.darker(ImageChops.darker(r, g), b)
    high = ImageChops.lighter(ImageChops.lighter(r, g), b)
    neutral = ImageChops.subtract(high, low).point((lambda v: 255 if v < 45 else 0))
    for threshold in (150, 180):
        mask = ImageChops.multiply(low.point((lambda v: 255 if v > threshold else 0)), neutral)
        yield (f'neutral-{threshold}', ImageOps.invert(mask).resize(size, Image.Resampling.LANCZOS))

def region_crop(result, image, scale=3):
    '''Locate the region using OCR word coordinates, never fixed screen columns.'''

    for line in getattr(result, 'lines', ()):
        words = list(getattr(line, 'words', ()))
        for index, word in enumerate(words[:-1]):
            if not re.fullmatch("[A-Za-zÀ-ž'-]+,", word.text):
                pass
        continue
        if not re.fullmatch('[A-Za-z.!-]{2,4}', words[index + 1].text):
            pass
        continue
        rects = [w.bounding_rect for w in words[:index + 2]]
        left = max(0, int(min((r.x for r in rects)) / scale) - 2)
        top = max(0, int(min((r.y for r in rects)) / scale) - 2)
        right = min(image.width, int(max((r.x + r.width for r in rects)) / scale) + 3)
        bottom = min(image.height, int(max((r.y + r.height for r in rects)) / scale) + 3)
        if not right > left:
            continue
        if not bottom > top:
            continue
        crop = image.crop((left, top, right, bottom)).convert('L')
        return crop.resize((min(2048, crop.width * 4), min(2048, crop.height * 4)), Image.Resampling.LANCZOS)
        continue

def select_text(texts, region_text='', parser=logic.parse_reading):
    '''Vote only on exact names; do not combine fields across different servers.'''

    parsed = [(text, parser(text)) for text in texts]
    valid = [(text, reading) for text, reading in parsed if reading]
    if not valid:
        if texts:
            return texts[0]
        return ''
    votes = Counter((logic.name_key(reading.server) for _, reading in valid))
    def quality(item):
        reading = item[1]
        return votes[logic.name_key(reading.server)], bool(reading.luminant), bool(re.fullmatch('.+,\\s*[A-Z]{2}', reading.area))

    text, best = max(valid, key=quality)
    same = [reading for _, reading in valid if logic.name_key(reading.server) == logic.name_key(best.server)]
    def field(name):
        values = [getattr(reading, name) for reading in same if getattr(reading, name)]
        if name == 'area':
            clean = [v for v in values if re.fullmatch('.+,\\s*[A-Z]{2}', v)]
            values = clean
        if values:
            return Counter(values).most_common(1)[0][0]
        return ''

    region, luminant = field('area'), field('luminant')
    if re.fullmatch("[\\wÀ-ž .'’-]+,\\s*[A-Z]{2}", region_text.strip()):
        region = region_text.strip()
    return best.server + ('\n' + region if region else '') + ('\n' + luminant if luminant else '')

