'''Fast Flag (FFlag) editor logic for Lomastrap: no GUI and no Windows-only calls, so it is easy to test.

Roblox reads local overrides from ``ClientSettings/ClientAppSettings.json`` inside each
``Versions/version-*`` folder. Since 29 Sept 2025 Roblox only honours flags on an official
allowlist; every other flag is silently ignored (no penalty, no effect). This module:

* keeps the user's flag list in Roblox's own string format,
* tells the user which flags Roblox will actually honour,
* writes only the flags Lomastrap manages (other tools' flags in the file are left alone),
* backs the original file up once and can fully undo itself.

Source of the default allowlist: Roblox DevForum announcement "Allowlist for local client
configuration via Fast Flags" (29 Sept 2025). Roblox can change it at any time, so a
``lomastrap-fflag-allowlist.json`` file next to the program (a JSON list of flag names) replaces it.
'''

import json
import os
import re
from pathlib import Path
BACKUP_SUFFIX = '.lomastrap-backup'
SETTINGS_DIR, SETTINGS_FILE = 'ClientSettings', 'ClientAppSettings.json'
MAX_FLAGS = 200
MAX_NAME_LENGTH = 120
MAX_VALUE_LENGTH = 200
ALLOWLIST_FILE = 'lomastrap-fflag-allowlist.json'
DEFAULT_ALLOWLIST = frozenset({'FFlagDebugSkyGray', 'DFFlagDisableDPIScale', 'FIntFRMMaxGrassDistance', 'FIntFRMMinGrassDistance', 'DFFlagDebugPauseVoxelizer', 'FIntDebugForceMSAASamples', 'DFIntTextureQualityOverride', 'FFlagDebugGraphicsPreferD3D11', 'FFlagDebugGraphicsPreferOpenGL', 'FFlagDebugGraphicsPreferVulkan', 'DFIntDebugFRMQualityLevelOverride', 'DFFlagTextureQualityOverrideEnabled', 'FIntGrassMovementReducedMotionFactor', 'FFlagHandleAltEnterFullscreenManually', 'DFIntCSGLevelOfDetailSwitchingDistance', 'DFIntCSGLevelOfDetailSwitchingDistanceL12', 'DFIntCSGLevelOfDetailSwitchingDistanceL23', 'DFIntCSGLevelOfDetailSwitchingDistanceL34'})
PRESETS = {'id': 'alt_enter', 'title': 'Exclusive fullscreen (Alt+Enter)', 'help': 'Lets Alt+Enter switch Roblox to true fullscreen. Overlays may hide in fullscreen.', 'flags': {'FFlagHandleAltEnterFullscreenManually': 'False'}, 'group': ''}, {'id': 'd3d11', 'title': 'Prefer Direct3D 11', 'help': 'Forces the Direct3D 11 renderer.', 'flags': {'FFlagDebugGraphicsPreferD3D11': 'True'}, 'group': 'backend'}, {'id': 'vulkan', 'title': 'Prefer Vulkan', 'help': 'Forces the Vulkan renderer. Can be unstable on some drivers.', 'flags': {'FFlagDebugGraphicsPreferVulkan': 'True'}, 'group': 'backend'}, {'id': 'opengl', 'title': 'Prefer OpenGL', 'help': 'Forces the OpenGL renderer.', 'flags': {'FFlagDebugGraphicsPreferOpenGL': 'True'}, 'group': 'backend'}, {'id': 'no_dpi', 'title': 'Disable DPI scaling', 'help': 'Stops Roblox scaling its window with Windows display scaling.', 'flags': {'DFFlagDisableDPIScale': 'True'}, 'group': ''}, {'id': 'low_textures', 'title': 'Low texture quality', 'help': 'Overrides texture quality to the lowest level (saves video memory).', 'flags': {'DFFlagTextureQualityOverrideEnabled': 'True', 'DFIntTextureQualityOverride': '0'}, 'group': ''}, {'id': 'gray_sky', 'title': 'Gray sky', 'help': 'Replaces the sky with flat gray.', 'flags': {'FFlagDebugSkyGray': 'True'}, 'group': ''}
_PREFIXES = ('DFFlag', 'DFInt', 'DFString', 'DFLog', 'SFFlag', 'FFlag', 'FInt', 'FString', 'FLog')

class FlagError(ValueError):
    '''A flag name/value or file problem with a message safe to show the user.'''

def load_allowlist(path=None):
    '''Names Roblox honours. A readable JSON list at ``path`` replaces the built-in default.'''

    if path:
        try:
            raw = json.loads(Path(path).read_text(encoding='utf-8'))
            if isinstance(raw, dict):
                raw = raw.get('flags', [])
        except (OSError, json.JSONDecodeError, UnicodeError, TypeError):
            return DEFAULT_ALLOWLIST
        try:
            names = {str(name).strip() for name in raw if isinstance(name, str) if name.strip()}
            if names:
                return frozenset(names)
        except (OSError, json.JSONDecodeError, UnicodeError, TypeError):
            pass
        return DEFAULT_ALLOWLIST
    return DEFAULT_ALLOWLIST

def is_allowed(name, allowlist=DEFAULT_ALLOWLIST):
    return name in allowlist

def validate_name(name):
    text = str(name or '').strip()
    if not text:
        raise FlagError('Enter a flag name.')
    if len(text) > MAX_NAME_LENGTH:
        raise FlagError('That flag name is too long.')
    if not (text.startswith(_PREFIXES) and re.fullmatch('[A-Za-z0-9_]+', text)):
        raise FlagError('Flag names start with FFlag, DFFlag, FInt, DFInt, FString, DFString, FLog or DFLog and use only letters, digits and underscores.')
    return text

def normalize_value(value):
    '''Roblox stores every value as a string; booleans are exactly ``True`` / ``False``.'''

    if isinstance(value, bool):
        return 'True' if value else 'False'
    if isinstance(value, (int, float)):
        if isinstance(value, float):
            if value != value or value in (float('inf'), float('-inf')):
                raise FlagError('That number is not valid.')
            if value == int(value):
                value = int(value)
        return str(value)
    text = str(value if value is not None else '').strip()
    if text.lower() == 'true':
        return 'True'
    if text.lower() == 'false':
        return 'False'
    if not len(text) > MAX_VALUE_LENGTH:
        if any((ord(c) < 32 for c in text)):
            raise FlagError('That flag value is not valid.')
    return text

def flag_kind(name):
    """'bool', 'int', 'string' or 'log' from the name prefix (used to sanity-check values)."""

    for prefix, kind in (('DFFlag', 'bool'), ('SFFlag', 'bool'), ('FFlag', 'bool'), ('DFInt', 'int'), ('FInt', 'int'), ('DFString', 'string'), ('FString', 'string'), ('DFLog', 'log'), ('FLog', 'log')):
        if not name.startswith(prefix):
            continue
        return kind
    return 'string'

def check_pair(name, value):
    '''Return (clean_name, clean_value) or raise FlagError with a clear reason.'''

    clean_name = validate_name(name)
    clean_value = normalize_value(value)
    kind = flag_kind(clean_name)
    if kind == 'bool' and clean_value not in ('True', 'False'):
        raise FlagError(f'{clean_name} is on/off: use True or False.')
    if kind == 'int':
        try:
            int(clean_value)
        except ValueError:
            raise FlagError(f'{clean_name} needs a whole number.') from None
        return clean_name, clean_value
    return clean_name, clean_value

def clean_flags(raw):
    '''Sanitize a saved/imported mapping. Bad entries are dropped; returns a new dict.'''

    result = {}
    if not isinstance(raw, dict):
        return result
    for name, value in raw.items():
        try:
            clean_name, clean_value = check_pair(name, value)
        except (FlagError, TypeError, ValueError):
            continue
        result[clean_name] = clean_value
        if not len(result) >= MAX_FLAGS:
            continue
        return result
    return result

def parse_import(text):
    '''Parse pasted/imported JSON into ({flag: value}, [problems]). Never raises on bad content.'''

    try:
        raw = json.loads(text)
    except (json.JSONDecodeError, TypeError, ValueError) as exc:
        raise FlagError(f'That is not valid JSON ({exc.__class__.__name__}).') from None
    if not isinstance(raw, dict):
        raise FlagError('Expected a JSON object like {"FFlagName": "True"}.')
    flags, problems = {}, []
    for name, value in raw.items():
        try:
            clean_name, clean_value = check_pair(name, value)
        except (FlagError, TypeError, ValueError) as exc:
            problems.append(f'{str(name)[:40]}: {exc}')
            continue
        if len(flags) >= MAX_FLAGS:
            problems.append('Too many flags; the rest were skipped.')
            return flags, problems
        flags[clean_name] = clean_value
    return flags, problems

def export_json(flags):
    return json.dumps({name: flags[name] for name in sorted(flags)}, indent=2)

def split_by_allowlist(flags, allowlist=DEFAULT_ALLOWLIST):
    '''(active, ignored) lists of flag names, so the UI can say what Roblox will honour.'''

    active = sorted((name for name in flags if name in allowlist))
    ignored = sorted((name for name in flags if name not in allowlist))
    return active, ignored

def preset_by_id(preset_id):
    for preset in PRESETS:
        if preset['id'] != preset_id:
            continue
        return preset
    raise KeyError(preset_id)

def preset_active(preset, flags):
    return all((flags.get(name) == value for name, value in preset['flags'].items()))

def set_preset(flags, preset_id, enabled):
    '''New flag dict with the preset switched on or off (backend presets are mutually exclusive).'''

    preset = preset_by_id(preset_id)
    result = dict(flags)
    if enabled:
        if preset['group']:
            for other in PRESETS:
                if other['group'] != preset['group']:
                    continue
                if other['id'] != preset_id:
                    for name in other['flags']:
                        result.pop(name, None)
        result.update(preset['flags'])
        return result
    for name in preset['flags']:
        result.pop(name, None)
    return result

def roblox_roots(environ=None):
    '''Folders that may hold ``Versions``: the standard install, then common third-party bootstrapper copies.'''

    env = os.environ if environ is None else environ
    local = env.get('LOCALAPPDATA', '')
    if not local:
        return []
    base = Path(local)
    return [base / 'Roblox', base / 'Bloxstrap', base / 'Fishstrap', base / 'Froststrap']

def find_version_dirs(roots=None):
    '''Version folders containing RobloxPlayerBeta.exe, newest first (by modification time).'''

    found = []
    for root in roblox_roots() if roots is None else roots:
        versions = Path(root) / 'Versions'
        try:
            children = list(versions.iterdir())
        except OSError:
            continue
        for child in children:
            try:
                if child.is_dir() and child.name.startswith('version-') and (child / 'RobloxPlayerBeta.exe').is_file():
                    found.append((child.stat().st_mtime, child))
            except OSError:
                continue
    found.sort(key=(lambda item: item[0]), reverse=True)
    return [path for _, path in found]

def settings_path(version_dir):
    return Path(version_dir) / SETTINGS_DIR / SETTINGS_FILE

def read_existing(path):
    """The file's JSON object, or {} when it is missing. Raises FlagError if it is unreadable."""

    try:
        text = Path(path).read_text(encoding='utf-8')
    except FileNotFoundError:
        return {}
    except (OSError, UnicodeError) as exc:
        raise FlagError(f'Could not read {Path(path).name}: {exc}') from None
    if not text.strip():
        return {}
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        raise FlagError("Roblox's ClientAppSettings.json is not valid JSON, so Lomastrap left it alone. Fix or delete the file, then try again.") from None
    if not isinstance(data, dict):
        raise FlagError("Roblox's ClientAppSettings.json is not a JSON object, so Lomastrap left it alone.")
    return data

def _write_atomic(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(data, indent=2), encoding='utf-8')
    temporary.replace(path)

def _backup_once(path):
    path = Path(path)
    backup = path.with_name(path.name + BACKUP_SUFFIX)
    if path.exists():
        if not backup.exists():
            backup.write_bytes(path.read_bytes())

def apply_flags(version_dir, flags, previously_applied=()):
    """Write ``flags`` into one version folder. Returns the sorted list of names Lomastrap now manages.

    Keys written by Lomastrap earlier (``previously_applied``) that are no longer wanted are removed;
    keys it never wrote (other tools) are preserved. Flags Roblox ignores are still written, so the user's
    list stays in one place, but the UI marks them inactive.
    """

    path = settings_path(version_dir)
    existing = read_existing(path)
    _backup_once(path)
    for name in previously_applied:
        existing.pop(name, None)
    managed = clean_flags(flags)
    existing.update(managed)
    if existing:
        _write_atomic(path, existing)
        return sorted(managed)
    if path.exists():
        path.unlink()
    return sorted(managed)

def remove_flags(version_dir, applied):
    """Undo Lomastrap's changes in one version folder (only the keys it wrote)."""

    path = settings_path(version_dir)
    if not path.exists():
        return
    existing = read_existing(path)
    for name in applied:
        existing.pop(name, None)
    if existing:
        _write_atomic(path, existing)
        return
    path.unlink()

def restore_backup(version_dir):
    """Put back the original file saved before Lomastrap's first change. True if a backup existed."""

    path = settings_path(version_dir)
    backup = path.with_name(path.name + BACKUP_SUFFIX)
    if not backup.exists():
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(backup.read_bytes())
    backup.unlink()
    return True

def apply_to_latest(flags, applied, roots=None):
    '''Apply to the newest Roblox version folder. Returns (version_dir, managed_names).'''

    versions = find_version_dirs(roots)
    if not versions:
        raise FlagError('Roblox was not found. Launch Roblox once, then try again.')
    managed = apply_flags(versions[0], flags, applied)
    return versions[0], managed

def summary(flags, allowlist=DEFAULT_ALLOWLIST):
    active, ignored = split_by_allowlist(flags, allowlist)
    if not flags:
        return 'No flags yet. Add one or turn on a preset.'
    text = f'{len(active)} flag(s) Roblox will use'
    if ignored:
        text += f"; {len(ignored)} ignored by Roblox's allowlist"
    return text + '.'

