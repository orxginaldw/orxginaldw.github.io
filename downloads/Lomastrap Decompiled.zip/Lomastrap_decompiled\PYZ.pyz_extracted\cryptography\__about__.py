from __future__ import annotations
__all__ = ['__author__', '__copyright__', '__version__']
__version__ = '50.0.2'
__author__ = 'The Python Cryptographic Authority and individual contributors'
__copyright__ = f'Copyright 2013-2026 {__author__}'
