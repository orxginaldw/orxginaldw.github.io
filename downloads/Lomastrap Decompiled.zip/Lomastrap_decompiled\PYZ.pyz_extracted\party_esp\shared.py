'''Independent ROI reader and asynchronous change-only publisher; viewing remains separate.'''

import logging
import queue
import random
import threading
import time
from .config import PartyEspConfig
from .detector import PartyMemberState
from .reader import (HealthReaderConfig, SegmentReader, PercentConfirmation, confirm_percent)
from dataclasses import dataclass, replace
import math
from .overlay import PartyEspOverlay
from lomastrap_logic import short_luminant

class StableRoster:
    def __init__(self, shuffle=None, clock=time.monotonic, missing_grace=6):
        self.clock, self.missing_grace = clock, missing_grace
        self.seen = {}
        self.room = None
        self.states = {}
        self.initialized = False
        self.shuffle = shuffle or random.SystemRandom().shuffle

    def update(self, room, peers, departed=()):
        if room != self.room:
            self.states, self.room = {}, room
            self.initialized, self.seen = False, {}
        peers = list(peers)
        if not self.initialized:
            if peers:
                self.shuffle(peers)
                self.initialized = True
        present = {p['id'] for p in peers}
        now = self.clock()
        for key in list(self.states):
            if key in departed or key not in present and now - self.seen.get(key, now) >= self.missing_grace:
                del self.states[key]
                self.seen.pop(key, None)
            else:
                if key in present:
                    continue
                self.states[key].is_stale = True
        for peer in peers:
            state = self.states.setdefault(peer['id'], PartyMemberState(peer['name']))
            state.detected_name = peer['name']
            state.update_reading(peer['hp'], None)
            state.is_stale = peer.get('stale', False) is True
            self.seen[peer['id']] = now
        return self.states


@dataclass(frozen=True)
class HealthState:
    room: tuple
    area: tuple
    hp: int
    stale: bool = False

class TabOutGrace:
    '''Freeze the last confirmed health on focus loss; never extend the same away period.'''

    def __init__(self, seconds=30.0, clock=time.monotonic):
        self.seconds, self.clock = seconds, clock
        self.since = None
        self.state = None

    def away(self, state):
        if self.since is None:
            self.since = self.clock()
            self.state = state
        if self.clock() - self.since < self.seconds:
            return self.state

    def resume(self):
        self.since = None
        self.state = None


class SharedHealthService:
    def __init__(self, master, session, snapshot, capture, game_active, authorize, notice, position=(0.02, 0.05), on_moved=None, settings=None, scale=1.0, focused=None, server_fresh=None):
        self.master, self.session = master, session
        self.snapshot, self.capture, self.game_active = snapshot, capture, game_active
        self.server_fresh = server_fresh or (lambda: True)
        self.focused = focused or (lambda: True)
        self.focus_grace = TabOutGrace()
        self.authorize, self.notice = authorize, notice
        self.settings = settings or HealthReaderConfig()
        self.enabled = False
        self.overlay = PartyEspOverlay(PartyEspConfig(members={}, fraction_x=position[0], fraction_y=position[1], scale=scale), self._visible, self._overlay_failed, on_moved)
        self.roster = StableRoster()
        self._stop = threading.Event()
        self._thread = None
        self._after = None
        self._results = queue.Queue(maxsize=1)
        self._last_network = float('-inf')
        self._last_room = None
        self._view_room = None
        self._network_thread = None
        self._condition = threading.Condition()
        self._desired = None
        self._last_notice = None

    def _visible(self):
        reading, area = self.snapshot()
        return bool(self.enabled and self.authorize() and self.game_active() and reading and area and (reading.server, reading.area, short_luminant(reading.luminant)) == self._view_room and time.monotonic() - self._last_network <= 30)

    def _overlay_failed(self, text):
        self.enabled = False
        self.notice(text)

    def start(self):
        if not self.session.valid():
            raise PermissionError('Sign in before sharing health.')
        if any((t and t.is_alive() for t in (self._thread, self._network_thread))):
            return
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._worker, name='shared-local-hp', daemon=True)
        self._network_thread = threading.Thread(target=self._send_worker, name='shared-hp-network', daemon=True)
        self._network_thread.start()
        self._thread.start()
        self._poll()

    def set_enabled(self, enabled):
        if enabled and not self.authorize():
            raise PermissionError('Trusted member or owner access required.')
        self.enabled = bool(enabled)
        if enabled:
            self.overlay.start(self.master)
        else:
            self.overlay.stop()
        with self._condition:
            self._condition.notify_all()

    def moving(self):
        return self.overlay.moving

    def begin_move(self):
        '''Show the overlay where it is so it can be dragged; needs the overlay switched on.'''

        if not self.enabled or not self.authorize():
            return False
        self.overlay.begin_move()
        return True

    def end_move(self):
        self.overlay.end_move()

    def reset_position(self):
        self.overlay.reset_position()

    def _put(self, payload):
        try:
            self._results.get_nowait()
        except queue.Empty:
            pass
        self._results.put_nowait(payload)

    def _leave(self):
        previous = self._last_room
        self._last_room = None
        if previous:
            if self.session.valid():
                try:
                    self.session.party_state({**previous, 'action': 'leave', 'view': False})
                except Exception:
                    logging.warning('Live HP leave could not be confirmed; room entry expires within six seconds')

    @staticmethod
    def _identity(reading, area):
        if not reading or not area or not reading.area or not reading.luminant:
            return
        return (reading.server, reading.area, short_luminant(reading.luminant)), tuple((area[key] for key in ('x', 'y', 'width', 'height')))

    def _set_desired(self, state):
        with self._condition:
            if state != self._desired:
                self._desired = state
                self._condition.notify_all()

    def _retain_hp(self, identity):
        with self._condition:
            previous = self._desired
        keep = previous is not None and identity == (previous.room, previous.area)
        if keep:
            self._set_desired(replace(previous, stale=True))
            return keep
        return keep

    def _announce(self, message, clear=False):
        if message != self._last_notice:
            self._last_notice = message
            self._put((None if clear else 'notice', [], message))

    def _worker(self):
        '''Capture -> read_segments -> confirm_percent. Never waits for an HTTP request.'''

        try:
            try:
                while not stop.is_set():
                    while self.session.valid():
                        started = time.monotonic()
                        if not self.focused():
                            with self._condition:
                                previous = self._desired
                            retained = self.focus_grace.away(previous)
                            self._set_desired(retained)
                            context = None
                            reader.reset()
                            confirmation.reset()
                            if retained is None:
                                self._announce('Tabbed out: health hidden until you return to Roblox.', clear=True)
                            stop.wait(max(0, period - (time.monotonic() - started)))
                            break
                        self.focus_grace.resume()
                        reading, area = self.snapshot()
                        current = self._identity(reading, area)
                        if current is None:
                            context = None
                            reader.reset()
                            confirmation.reset()
                            self._set_desired(None)
                            self._announce('Waiting for Roblox, a confirmed server/region/Luminant, and your saved life-bar area.', clear=True)
                        elif not self.game_active():
                            keep = self._retain_hp(current)
                            context = None
                            reader.reset()
                            confirmation.reset()
                            self._announce('Life-bar area temporarily covered; keeping last verified HP.', clear=not keep)
                        elif not self.server_fresh():
                            with self._condition:
                                previous = self._desired
                            if previous is not None and (previous.room, previous.area) == current:
                                self._set_desired(replace(previous, stale=True))
                            else:
                                self._set_desired(None)
                            context = None
                            reader.reset()
                            confirmation.reset()
                            self._announce('HUD temporarily unclear; holding last verified HP until the server is verified again.')
                        else:
                            if current != context:
                                context = current
                                reader.reset()
                                confirmation.reset()
                                with self._condition:
                                    previous = self._desired
                                if previous is None or (previous.room, previous.area) != context:
                                    self._set_desired(None)
                                self._announce('Confirming life bar: two consecutive frames required.')
                            segments = reader.read_segments(self.capture(area))
                            check, check_area = self.snapshot()
                            if not stop.is_set():
                                if not self.session.valid():
                                    break
                        if not self.focused():
                            with self._condition:
                                previous = self._desired
                            self._set_desired(self.focus_grace.away(previous))
                            context = None
                            reader.reset()
                            confirmation.reset()
                        elif not self.server_fresh():
                            with self._condition:
                                previous = self._desired
                            if previous is not None:
                                self._set_desired(replace(previous, stale=True))
                            context = None
                            reader.reset()
                            confirmation.reset()
                        elif self._identity(check, check_area) != context:
                            context = None
                            reader.reset()
                            confirmation.reset()
                            self._set_desired(None)
                            self._announce('Health read discarded: the server or capture area changed.', clear=True)
                        elif not self.game_active():
                            keep = self._retain_hp(context)
                            context = None
                            reader.reset()
                            confirmation.reset()
                            self._announce('Life-bar area temporarily covered; keeping last verified HP.', clear=not keep)
                        else:
                            changed = confirm_percent(segments, confirmation)
                            if changed is not None:
                                self._set_desired(HealthState(context[0], context[1], changed))
                        stop.wait(max(0, period - (time.monotonic() - started)))
            finally:
                stop = self._stop
                reader = SegmentReader(self.settings)
                confirmation = PercentConfirmation()
                context = None
                period = 1 / self.settings.read_fps
        finally:
            if not self.focused():
                with self._condition:
                    previous = self._desired
                retained = self.focus_grace.away(previous)
                self._set_desired(retained)
                context = None
                reader.reset()
                confirmation.reset()
                if retained is None:
                    self._announce('Tabbed out: health hidden until you return to Roblox.', clear=True)
                stop.wait(max(0, period - (time.monotonic() - started)))
            self.focus_grace.resume()
            reading, area = self.snapshot()
            current = self._identity(reading, area)
            if current is None:
                context = None
                reader.reset()
                confirmation.reset()
                self._set_desired(None)
                self._announce('Waiting for Roblox, a confirmed server/region/Luminant, and your saved life-bar area.', clear=True)
            elif not self.game_active():
                keep = self._retain_hp(current)
                context = None
                reader.reset()
                confirmation.reset()
                self._announce('Life-bar area temporarily covered; keeping last verified HP.', clear=not keep)
            elif not self.server_fresh():
                with self._condition:
                    previous = self._desired
                if previous is not None and (previous.room, previous.area) == current:
                    self._set_desired(replace(previous, stale=True))
                else:
                    self._set_desired(None)
                context = None
                reader.reset()
                confirmation.reset()
                self._announce('HUD temporarily unclear; holding last verified HP until the server is verified again.')
            else:
                if current != context:
                    context = current
                    reader.reset()
                    confirmation.reset()
                    with self._condition:
                        previous = self._desired
                    if previous is None or (previous.room, previous.area) != context:
                        self._set_desired(None)
                    self._announce('Confirming life bar: two consecutive frames required.')
                segments = reader.read_segments(self.capture(area))
                check, check_area = self.snapshot()
                if not stop.is_set():
                    if not self.session.valid():
                        pass
                    else:
                        if not self.focused():
                            with self._condition:
                                previous = self._desired
                            self._set_desired(self.focus_grace.away(previous))
                            context = None
                            reader.reset()
                            confirmation.reset()
                        elif not self.server_fresh():
                            with self._condition:
                                previous = self._desired
                            if previous is not None:
                                self._set_desired(replace(previous, stale=True))
                            context = None
                            reader.reset()
                            confirmation.reset()
                        elif self._identity(check, check_area) != context:
                            context = None
                            reader.reset()
                            confirmation.reset()
                            self._set_desired(None)
                            self._announce('Health read discarded: the server or capture area changed.', clear=True)
                        elif not self.game_active():
                            keep = self._retain_hp(context)
                            context = None
                            reader.reset()
                            confirmation.reset()
                            self._announce('Life-bar area temporarily covered; keeping last verified HP.', clear=not keep)
                        else:
                            changed = confirm_percent(segments, confirmation)
                            if changed is not None:
                                self._set_desired(HealthState(context[0], context[1], changed))
                        stop.wait(max(0, period - (time.monotonic() - started)))
                        if not stop.is_set():
                            if self.session.valid():
                                pass
            self._set_desired(None)
            close = getattr(self.capture, 'close', None)
            if callable(close):
                try:
                    close()
                except Exception:
                    logging.warning('Life-bar capture cleanup failed')

    @staticmethod
    def _peers(result):
        peers = result.get('peers', [])
        departed = result.get('departed', [])
        if isinstance(departed, list):
            if any((not isinstance(key, str) for key in departed)):
                raise ValueError('Unreadable shared-health removal response.')
        if isinstance(peers, list):
            if any((not isinstance(p, dict) or not isinstance(p.get('id'), str) or not isinstance(p.get('name'), str) or type(p.get('hp')) not in (int, float) or not math.isfinite(p['hp']) or not 0 <= p['hp'] <= 100 for p in peers)):
                raise ValueError('Unreadable shared-health response.')
        return peers

    def _send_worker(self):
        '''One bounded latest state, one in-flight request; heartbeats contain no HP field.'''

        stop = self._stop
        sent = None
        deadline = float('inf')
        last_view = False
        retry_until = 0
        try:
            if result.get('needs_publish'):
                sent = None
                deadline = 0
                # WARNING: continue outside loop (unrecovered structure)
        finally:
            try:
                if result.get('needs_publish'):
                    sent = None
                    deadline = 0
                try:
                    while not stop.is_set():
                        while self.session.valid():
                            with self._condition:
                                state = self._desired
                                view = bool(self.enabled and self.authorize())
                                now = time.monotonic()
                                publish = state is not None and (sent is None or (state.room, state.area, state.hp) != (sent.room, sent.area, sent.hp))
                                leaving = state is None and self._last_room is not None
                                due = state is not None and (now >= deadline or view != last_view or state != sent)
                                if now < retry_until:
                                    self._condition.wait(min(0.5, retry_until - now))
                                    break
                                if not publish and not leaving and not due:
                                    self._condition.wait(min(0.5, max(0, deadline - now)))
                                    break
                            if leaving:
                                self._leave()
                                sent = None
                                deadline = float('inf')
                                continue
                            if state is None:
                                continue
                            room = dict(zip(('server', 'region', 'luminant'), state.room))
                            body = {**room, 'action': 'publish' if publish else 'sync', 'view': view, 'stale': state.stale}
                            if publish:
                                body['hp'] = state.hp
                            try:
                                result = self.session.party_state(body)
                                peers = self._peers(result)
                                self._last_room = room
                                with self._condition:
                                    current = self._desired
                                if current is not None:
                                    if current.room != state.room or current.area != state.area:
                                        sent = None
                                        deadline = 0
                                        continue
                            except Exception as exc:
                                sent = None
                                retry_until = time.monotonic() + 0.5
                                self._put(('notice', [], 'Shared HP unavailable; keeping last known bars: ' + str(exc)))
                            sent = state
                            last_view = view
                            deadline = time.monotonic() + (self.settings.poll_seconds if view else self.settings.heartbeat_seconds)
                            self._last_notice = None
                            self._put((state.room, {'peers': peers, 'departed': result.get('departed', [])}, ('Your last confirmed HP is held while capture recovers. Overlay ' if state.stale else 'Your confirmed HP is shared. Overlay ') + ('on.' if view else 'off; others can still see you.')))
                except Exception as exc:
                    sent = None
                    retry_until = time.monotonic() + 0.5
                    self._put(('notice', [], 'Shared HP unavailable; keeping last known bars: ' + str(exc)))
                finally:
                    self._leave()
                    close = getattr(self.session, 'close_party_transport', None)
                    if callable(close):
                        close()
            except Exception as exc:
                sent = None
                retry_until = time.monotonic() + 0.5
                self._put(('notice', [], 'Shared HP unavailable; keeping last known bars: ' + str(exc)))
            finally:
                self._leave()
                close = getattr(self.session, 'close_party_transport', None)
                if callable(close):
                    close()
        self._leave()
        close = getattr(self.session, 'close_party_transport', None)
        if callable(close):
            close()

    def _poll(self):
        self._after = None
        if self._stop.is_set():
            return
        if not self.session.valid():
            self.stop()
            return
        if self.enabled and not self.authorize():
            self.set_enabled(False)
        try:
            room, peers, message = self._results.get_nowait()
            if room == 'notice':
                pass
            elif room is None:
                self._view_room = None
                self._last_network = float('-inf')
                self.overlay.update_states({})
            else:
                self._last_network = time.monotonic()
                self._view_room = room
                if self.enabled and self.authorize():
                    states = self.roster.update(room, peers.get('peers', []) if isinstance(peers, dict) else peers, peers.get('departed', []) if isinstance(peers, dict) else ())
                    self.overlay.config.members = dict(states)
                    self.overlay.update_states(states)
            self.notice(message)
        except queue.Empty:
            pass
        self._after = self.master.after(25, self._poll)

    def stop(self):
        self._stop.set()
        with self._condition:
            self._condition.notify_all()
        if self._after is not None:
            self.master.after_cancel(self._after)
            self._after = None
        self.overlay.stop()
        for thread in self._thread, self._network_thread:
            if not thread:
                continue
            if thread is not threading.current_thread():
                thread.join(timeout=4)
                if thread.is_alive():
                    logging.warning('Shared HP worker still returning during exit; no new reads will start')


# WARNING: Decompyle incomplete
