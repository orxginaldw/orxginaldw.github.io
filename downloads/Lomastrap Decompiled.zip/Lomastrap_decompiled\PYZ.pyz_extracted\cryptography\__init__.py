from __future__ import annotations
from cryptography.__about__ import (__author__, __copyright__, __version__)
__all__ = ['__author__', '__copyright__', '__version__']
