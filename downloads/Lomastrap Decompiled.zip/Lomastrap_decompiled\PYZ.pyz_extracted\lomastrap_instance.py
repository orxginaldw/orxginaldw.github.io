'''One application per interactive Windows session, including source and EXE.'''

import ctypes
from ctypes import wintypes
import sys
MUTEX_NAME = 'Local\\Lomastrap.UI.v1'

class SingleInstance:
    def __init__(self, name=MUTEX_NAME):
        self.name, self.handle, self.kernel = name, None, None

    def acquire(self):
        if sys.platform != 'win32':
            return True
        self.kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        self.kernel.CreateMutexW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR]
        self.kernel.CreateMutexW.restype = wintypes.HANDLE
        self.kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        ctypes.set_last_error(0)
        self.handle = self.kernel.CreateMutexW(None, False, self.name)
        error = ctypes.get_last_error()
        if not self.handle:
            raise ctypes.WinError(error)
        return error != 183 and not self.existing_window()

    def existing_window(self):
        user = ctypes.WinDLL('user32', use_last_error=True)
        user.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
        user.FindWindowW.restype = wintypes.HWND
        return user.FindWindowW(None, 'Lomastrap')

    def activate_existing(self):
        user = ctypes.WinDLL('user32', use_last_error=True)
        user.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
        user.SetForegroundWindow.argtypes = [wintypes.HWND]
        user.FlashWindow.argtypes = [wintypes.HWND, wintypes.BOOL]
        hwnd = self.existing_window()
        if hwnd:
            user.ShowWindow(hwnd, 9)
            user.SetForegroundWindow(hwnd)
            user.FlashWindow(hwnd, True)

    def close(self):
        if self.handle:
            self.kernel.CloseHandle(self.handle)
            self.handle = None


