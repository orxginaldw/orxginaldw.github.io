__version__ = '0.8.0'
import sys
import platform

def macos_supported_version():
    sysver = platform.mac_ver()[0]
    major = int(sysver.split('.')[0])
    if major < 10:
        return False
    if major >= 11:
        return True
    minor = int(sysver.split('.')[1])
    if minor < 14:
        return False
    return True

if sys.platform == 'darwin':
    if macos_supported_version():
        from ._mac_detect import *
        del sys, platform
    else:
        from ._dummy import *
        del sys, platform
if sys.platform == 'win32' and platform.release().isdigit() and int(platform.release()) >= 10:
    winver = int(platform.version().split('.')[2])
    if winver >= 14393:
        from ._windows_detect import *
        del sys, platform
    else:
        from ._dummy import *
        del sys, platform
if sys.platform == 'linux':
    from ._linux_detect import *
    del sys, platform
else:
    from ._dummy import *
    del sys, platform
