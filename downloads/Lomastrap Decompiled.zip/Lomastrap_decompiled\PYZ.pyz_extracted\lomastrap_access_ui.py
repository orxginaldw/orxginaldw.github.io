"""Purple login gate and owner controls. All network work stays off Tk's thread."""

import queue
import threading
import time
import tkinter as tk
from tkinter import messagebox, ttk
import customtkinter as ctk
from lomastrap_access import (AccessClient, AccessError, PRIVACY, read_json)
BG, PANEL, TEXT, MUTED, PRIMARY = '#100a1b', '#1c132c', '#f8f3ff', '#baa9cf', '#8653ed'

class AsyncWindow:
    def setup_tasks(self):
        self.tasks = queue.Queue()
        self.busy = False
        self.after(60, self.poll_tasks)

    def task(self, operation, complete):
        if self.busy:
            return
        self.busy = True
        self.notice.set('Connecting…')
        def work():
            try:
                result = operation()
            except AccessError as exc:
                self.tasks.put((False, str(exc), complete))
            except Exception:
                self.tasks.put((False, 'Request failed. Check service setup and your connection.', complete))
            self.tasks.put((True, result, complete))

        threading.Thread(target=work, daemon=True).start()

    def poll_tasks(self):
        try:
            while True:
                ok, result, complete = self.tasks.get_nowait()
                self.busy = False
                if ok:
                    self.notice.set('')
                    complete(result)
                else:
                    self.notice.set(result)
        except queue.Empty:
            pass
        try:
            if self.winfo_exists():
                self.after(60, self.poll_tasks)
                return
        except tk.TclError:
            pass


class LoginWindow(AsyncWindow, ctk.CTk):
    def __init__(self, config_path, directory, updater=None):
        super().__init__()
        ctk.set_appearance_mode('dark')
        self.title('Lomastrap')
        self.geometry('520x680')
        self.minsize(480, 580)
        self.configure(fg_color=BG)
        self.updater = updater
        self.update_notice = tk.StringVar(value=updater.message if updater else '')
        self.result = None
        self.client = None
        self.owner_mode = False
        self.notice = tk.StringVar()
        self.name = tk.StringVar()
        self.password = tk.StringVar()
        self.consent = tk.BooleanVar(value=False)
        self.revealed = False
        ctk.CTkLabel(self, text='LOMASTRAP', font=('Segoe UI', 28, 'bold'), text_color='#bd9aff').pack(pady=(30, 5))
        ctk.CTkLabel(self, text='Sign in to your server toolkit', text_color=MUTED).pack(pady=(0, 20))
        form = ctk.CTkFrame(self, fg_color=PANEL, corner_radius=16)
        form.pack(fill='both', expand=True, padx=24, pady=(0, 24))
        self.name_label = ctk.CTkLabel(form, text='Your name', anchor='w')
        self.name_label.pack(fill='x', padx=20, pady=(16, 4))
        self.name_entry = ctk.CTkEntry(form, textvariable=self.name, height=36)
        self.name_entry.pack(fill='x', padx=20)
        self.password_label = ctk.CTkLabel(form, text='Access code', anchor='w')
        self.password_label.pack(fill='x', padx=20, pady=(12, 4))
        row = ctk.CTkFrame(form, fg_color='transparent')
        row.pack(fill='x', padx=20)
        self.password_entry = ctk.CTkEntry(row, textvariable=self.password, show='•', height=36)
        self.password_entry.pack(side='left', fill='x', expand=True)
        ctk.CTkButton(row, text='Show', width=60, command=self.reveal).pack(side='right', padx=(8, 0))
        ctk.CTkLabel(form, text=PRIVACY, justify='left', wraplength=410, text_color=MUTED, font=('Segoe UI', 11)).pack(fill='x', padx=20, pady=(16, 8))
        ctk.CTkCheckBox(form, text='I understand the login records and device check', variable=self.consent, font=('Segoe UI', 11)).pack(anchor='w', padx=20, pady=8)
        ctk.CTkLabel(form, textvariable=self.notice, text_color='#ffb8c9', wraplength=410, justify='left').pack(fill='x', padx=20, pady=6)
        ctk.CTkButton(form, text='Sign in', fg_color=PRIMARY, command=self.submit, height=36).pack(fill='x', padx=20, pady=4)
        ctk.CTkButton(form, text='Restore saved access', fg_color='#332247', command=self.resume).pack(fill='x', padx=20, pady=4)
        self.owner_button = ctk.CTkButton(form, text='Owner sign in', fg_color='transparent', command=self.switch_mode)
        self.owner_button.pack(pady=(6, 14))
        self.bind('<Return>', (lambda _e: self.submit()))
        try:
            self.client = AccessClient(read_json(config_path), directory)
        except (AccessError, OSError) as exc:
            self.notice.set(str(exc))
        self.setup_tasks()
        if self.client and self.client.cache.exists():
            self.after(100, self.restore_automatically)
        if updater:
            ctk.CTkLabel(self, textvariable=self.update_notice, text_color=MUTED, wraplength=470, font=('Segoe UI', 11)).pack(padx=20, pady=(0, 8))
            self.after(200, self.poll_updates)

    def poll_updates(self):
        if self.updater:
            self.update_notice.set(self.updater.message)
            self.after(500, self.poll_updates)

    def destroy(self):
        for task in self.tk.call('after', 'info'):
            self.after_cancel(task)
        super().destroy()

    def reveal(self):
        self.revealed = not self.revealed
        if self.revealed:
            self.password_entry.configure(show='')
            return
        None(show='•')

    def switch_mode(self):
        if self.busy:
            return
        self.owner_mode = not self.owner_mode
        self.password.set('')
        self.revealed = False
        self.password_entry.configure(show='•')
        self.password_label.configure(text='Private owner key' if self.owner_mode else 'Access code')
        self.owner_button.configure(text='Back to user sign in' if self.owner_mode else 'Owner sign in')
        self.name_entry.configure(state='normal')
        if self.owner_mode:
            self.notice.set('Owner access needs your separate long key.')
            return
        None('')

    def ready(self):
        if not self.client:
            self.notice.set('Owner setup required. See ACCESS-SETUP.md; the service must be configured.')
            return False
        if not self.consent.get():
            self.notice.set('Read and acknowledge the login-data notice first.')
            return False
        return True

    def submit(self):
        if not self.ready() or self.busy:
            return
        password, name, owner = self.password.get(), self.name.get(), self.owner_mode
        self.password.set('')
        self.task((lambda: self.client.login_owner(name, password) if owner else self.client.login(name, password)), self.finish)

    def restore_automatically(self):
        if self.client:
            if not self.busy:
                self.consent.set(True)
                self.task(self.client.resume, self.finish)

    def resume(self):
        if self.ready():
            if not self.busy:
                self.task(self.client.resume, self.finish)

    def finish(self, _result):
        self.result = self.client
        self.destroy()


def sign_in(config_path, directory, updater=None):
    window = LoginWindow(config_path, directory, updater)
    window.mainloop()
    return window.result

def timestamp(value):
    return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(value))

class OwnerPanel(AsyncWindow, ctk.CTkToplevel):
    def __init__(self, app, client):
        super().__init__(app)
        self.client = client
        self.title('Lomastrap — Owner')
        self.geometry('870x650')
        self.configure(fg_color=BG)
        self.notice = tk.StringVar(value='Loading login history…')
        ctk.CTkLabel(self, text='Owner controls', font=('Segoe UI', 22, 'bold')).pack(anchor='w', padx=20, pady=15)
        ctk.CTkLabel(self, text='Block prevents sign-in. Kick ends the current session; they may sign in again.', text_color=MUTED).pack(anchor='w', padx=20)
        ctk.CTkLabel(self, text='Checks run every 60 seconds online. Offline access can last up to 24 hours.', text_color=MUTED).pack(anchor='w', padx=20, pady=(0, 10))
        tabs = ctk.CTkTabview(self, fg_color=PANEL)
        tabs.pack(fill='both', expand=True, padx=20)
        users_tab, events_tab = tabs.add('Users'), tabs.add('Login history')
        columns = ('name', 'last', 'version', 'blocked', 'device', 'code', 'tier')
        style = ttk.Style(self)
        style.theme_use('clam')
        style.configure('Loma.Treeview', background=PANEL, foreground=TEXT, fieldbackground=PANEL, rowheight=27, borderwidth=0)
        style.configure('Loma.Treeview.Heading', background='#332247', foreground=TEXT)
        style.map('Loma.Treeview', background=[('selected', PRIMARY)])
        self.users = ttk.Treeview(users_tab, style='Loma.Treeview', columns=columns, show='headings', selectmode='browse')
        for col, label, width in zip(columns, ('Name', 'Last seen (local)', 'Version', 'Blocked', 'Device', 'Access code', 'Access'), (120, 150, 60, 55, 90, 110, 80)):
            self.users.heading(col, text=label)
            self.users.column(col, width=width, minwidth=50)
        scroll = ttk.Scrollbar(users_tab, command=self.users.yview)
        scroll.pack(side='right', fill='y')
        self.users.configure(yscrollcommand=scroll.set)
        self.users.pack(fill='both', expand=True)
        self.history = ctk.CTkTextbox(events_tab, fg_color=BG)
        self.history.pack(fill='both', expand=True)
        row = ctk.CTkFrame(self, fg_color='transparent')
        row.pack(fill='x', padx=20, pady=10)
        for text, command in ('Refresh', self.refresh), ('Blacklist', (lambda: self.change_block(True))), ('Unblock', (lambda: self.change_block(False))), ('Kick', self.kick):
            ctk.CTkButton(row, text=text, width=100, fg_color=PRIMARY if text == 'Refresh' else '#332247', command=command).pack(side='left', padx=(0, 8))
        row2 = ctk.CTkFrame(self, fg_color='transparent')
        row2.pack(fill='x', padx=20, pady=5)
        self.invite_code = tk.StringVar()
        self.invite_entry = ctk.CTkEntry(row2, textvariable=self.invite_code, state='readonly')
        self.invite_entry.pack(side='left', fill='x', expand=True)
        self.generate_button = ctk.CTkButton(row2, text='Generate member code', command=self.generate_code, width=160)
        self.generate_button.pack(side='right', padx=(8, 0))
        self.trusted_generate_button = ctk.CTkButton(row2, text='Generate trusted member code', width=145, height=24, fg_color='#a53149', hover_color='#c4415d', font=('Segoe UI', 10), command=(lambda: self.generate_code('trusted')))
        self.trusted_generate_button.pack(side='right', padx=(12, 0))
        ctk.CTkButton(row2, text='Copy', command=self.copy_code, width=65).pack(side='right', padx=(8, 0))
        self.invite_tier = 'member'
        self.invite_deadline = 0
        self.invite_timer = None
        ctk.CTkLabel(self, textvariable=self.notice, text_color='#ffb8c9', wraplength=800).pack(fill='x', padx=20, pady=(5, 15))
        self.setup_tasks()
        self.refresh()

    def refresh(self):
        def operation():
            return self.client.owner_request('/owner/users')['users'], self.client.owner_request('/owner/events')['events']

        def complete(data):
            users, events = data
            self.users.delete(*self.users.get_children())
            for user in users:
                self.users.insert('', 'end', iid=user['id'], values=(user['name'], timestamp(user['last_seen']), user['version'], 'Yes' if user['blocked'] else 'No', user['device_hash'][:10], user.get('access_code') or '—', user.get('tier', 'member').title()))
            self.history.configure(state='normal')
            self.history.delete('1.0', 'end')
            for event in events:
                self.history.insert('end', timestamp(event['at']) + '  ' + event['name'] + '  v' + event['version'] + '  Code: ' + (event.get('access_code') or '—') + '\n')
            self.history.configure(state='disabled')
            self.notice.set('Latest 500 users / logins. Login history retention: 30 days.')

        self.task(operation, complete)

    def selected(self):
        selection = self.users.selection()
        if not selection:
            self.notice.set('Select a user first.')
            return
        return selection[0]

    def change_block(self, blocked):
        user = self.selected()
        if user:
            if not self.busy:
                if messagebox.askyesno('Confirm access change', ('Blacklist' if blocked else 'Unblock') + ' this name, installation and device?', parent=self):
                    self.task((lambda: self.client.owner_request('/owner/block', {'user_id': user, 'blocked': blocked})), (lambda _result: self.refresh()))

    def kick(self):
        user = self.selected()
        if user:
            if not self.busy:
                self.task((lambda: self.client.owner_request('/owner/kick', {'user_id': user})), (lambda _result: self.notice.set('Session ended. They may sign in again unless blacklisted.')))

    def generate_code(self, tier='member'):
        if self.busy:
            return
        def complete(result):
            import re
            code = result.get('code', '')
            expected = 12 if tier == 'trusted' else 6
            if isinstance(code, str) and re.fullmatch('[A-Z0-9]{' + str(expected) + '}', code):
                if tier == 'trusted' and result.get('tier') != 'trusted':
                    pass
            self.invite_code.set('')
            self.invite_deadline = 0
            if self.invite_timer is not None:
                self.after_cancel(self.invite_timer)
                self.invite_timer = None
            self.notice.set('Access service needs the latest Worker update. No code was displayed.')

        self.task((lambda: self.client.owner_request('/owner/invites', {'tier': tier})), complete)

    def update_invite_timer(self):
        if self.invite_timer is not None:
            self.after_cancel(self.invite_timer)
            self.invite_timer = None
        remaining = max(0, int(self.invite_deadline - time.monotonic()))
        if remaining == 0:
            self.invite_code.set('')
            self.notice.set('Code expired. Generate a new code.')
            return
        self.notice.set(f'{self.invite_tier.title()} code valid for {remaining // 60}m {remaining % 60:02d}s. One login only; send it privately.')
        self.invite_timer = self.after(1000, self.update_invite_timer)

    def copy_code(self):
        if self.invite_deadline <= time.monotonic() or not self.invite_code.get():
            self.notice.set('Generate a valid code first.')
            return
        self.clipboard_clear()
        self.clipboard_append(self.invite_code.get())

    def destroy(self):
        if getattr(self, 'invite_timer', None) is not None:
            self.after_cancel(self.invite_timer)
            self.invite_timer = None
        super().destroy()


# WARNING: Decompyle incomplete
