from __future__ import annotations
import re
from . import Image, ImageFile
TYPE_CHECKING = False
if TYPE_CHECKING:
    from typing import IO
xbm_head = re.compile(b'\\s*#define[ \\t]+.*_width[ \\t]+(?P<width>[0-9]+)[\\r\\n]+#define[ \t]+.*_height[ \t]+(?P<height>[0-9]+)[\r\n]+(?P<hotspot>#define[ \t]+[^_]*_x_hot[ \t]+(?P<xhot>[0-9]+)[\r\n]+#define[ \t]+[^_]*_y_hot[ \t]+(?P<yhot>[0-9]+)[\r\n]+)?[\\000-\\377]*_bits\\[]')

def _accept(prefix: 'bytes') -> 'bool':
    return prefix.startswith((b'#define', b'\n#define', b'/*'))

class XbmImageFile(ImageFile.ImageFile):
    format = 'XBM'
    format_description = 'X11 Bitmap'
    def _open(self) -> 'None':
        assert self.fp is not None
        width = None
        height = None
        x_hot = None
        offset = None
        starting = True
        in_block_comment = False
        while True:
            line = self.fp.readline(75)
            if not line:
                break
            line = line.rstrip()
            if in_block_comment:
                if line.endswith(b'*/'):
                    in_block_comment = False
                continue
            if line.startswith(b'/*'):
                in_block_comment = not line.endswith(b'*/')
                continue
            if starting:
                if not line:
                    starting = False
                    continue
            if not line.startswith(b'#define '):
                if line.endswith(b'_bits[] = {'):
                    offset = self.fp.tell()
                break
            value = int(line.split().pop())
            if b'width ' in line:
                width = value
            elif b'height ' in line:
                height = value
            elif b'_x_hot ' in line:
                x_hot = value
            elif b'_y_hot ' in line and x_hot is not None:
                self.info['hotspot'] = x_hot, value
        if width is None or height is None or offset is None:
            msg = 'not a XBM file'
            raise SyntaxError(msg)
        self._mode = '1'
        self._size = width, height
        self.tile = [ImageFile._Tile('xbm', (0, 0, *self.size), offset)]


def _save(im: 'Image.Image', fp: 'IO[bytes]', filename: 'str | bytes') -> 'None':
    if im.mode != '1':
        msg = f'cannot write mode {im.mode} as XBM'
        raise OSError(msg)
    fp.write(f'#define im_width {im.size[0]}\n'.encode('ascii'))
    fp.write(f'#define im_height {im.size[1]}\n'.encode('ascii'))
    hotspot = im.encoderinfo.get('hotspot')
    if hotspot:
        fp.write(f'#define im_x_hot {hotspot[0]}\n'.encode('ascii'))
        fp.write(f'#define im_y_hot {hotspot[1]}\n'.encode('ascii'))
    fp.write(b'static char im_bits[] = {\n')
    ImageFile._save(im, fp, [ImageFile._Tile('xbm', (0, 0, *im.size))])
    fp.write(b'};\n')

Image.register_open(XbmImageFile.format, XbmImageFile, _accept)
Image.register_save(XbmImageFile.format, _save)
Image.register_extension(XbmImageFile.format, '.xbm')
Image.register_mime(XbmImageFile.format, 'image/xbm')
