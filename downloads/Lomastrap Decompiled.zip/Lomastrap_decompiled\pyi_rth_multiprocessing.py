def _pyi_rthook():
    import sys
    import multiprocessing
    import multiprocessing.spawn
    from subprocess import _args_from_interpreter_flags
    multiprocessing.process.ORIGINAL_DIR = None
    def _divert_multiprocessing_helper():
        try:
            command_switch_idx = sys.argv.index('-c')
        except ValueError:
            pass
        else:
            if set(sys.argv[1:command_switch_idx]) != set(_args_from_interpreter_flags()):
                return
            if len(sys.argv) <= command_switch_idx + 1:
                return
            command = sys.argv[command_switch_idx + 1]
            COMMAND_PREFIXES = ('from multiprocessing.resource_tracker import main', 'from multiprocessing.forkserver import main', 'import sys; from multiprocessing.forkserver import main')
            if not command.startswith(COMMAND_PREFIXES):
                return
            exec(command)
            sys.exit()

    def _freeze_support():
        _divert_multiprocessing_helper()
        if multiprocessing.spawn.is_forking(sys.argv):
            kwds = {}
            for arg in sys.argv[2:]:
                name, value = arg.split('=')
                if value == 'None':
                    kwds[name] = None
                else:
                    kwds[name] = int(value)
            multiprocessing.spawn.spawn_main(**kwds)
            sys.exit()

    multiprocessing.freeze_support = _freeze_support
    multiprocessing.spawn.freeze_support = _freeze_support

_pyi_rthook()
del _pyi_rthook
