'''Watches one keyboard key without blocking it, so the parry bar can follow your parry key.

The key still reaches the game; this only listens. Keys sent by programs are ignored.
Windows-only; elsewhere start() reports that it cannot run.
'''

import ctypes
import logging
import sys
import threading
from ctypes import wintypes
WM_KEYDOWN, WM_KEYUP, WM_SYSKEYDOWN, WM_SYSKEYUP = 256, 257, 260, 261
LLKHF_LOWER_IL_INJECTED, LLKHF_INJECTED = 2, 16
WH_KEYBOARD_LL, WM_QUIT = 13, 18

def key_change(message, flags, code, target):
    '''"down" or "up" for a real press/release of `target`, otherwise None.'''

    targets = {16: (16, 160, 161), 17: (17, 162, 163), 18: (18, 164, 165), 91: (91, 92)}.get(target, (target,))
    if code not in targets or flags & (LLKHF_INJECTED | LLKHF_LOWER_IL_INJECTED):
        return
    if message in (WM_KEYDOWN, WM_SYSKEYDOWN):
        return 'down'
    if message in (WM_KEYUP, WM_SYSKEYUP):
        return 'up'

class KeyWatcher:
    '''Calls `on_press()` once per real press of the key (holding it does not repeat).'''

    def __init__(self, virtual_key, on_press, modifiers=0):
        self.virtual_key, self.on_press = virtual_key, on_press
        self.modifiers = modifiers & 15
        self._modifier_reader = None
        self._thread = None
        self._thread_id = None
        self._ready = threading.Event()
        self._error = ''
        self._down = False

    def alive(self):
        return self._thread is not None and self._thread.is_alive()

    def start(self, timeout=3.0):
        '''Returns "" when watching, otherwise a message saying why not.'''

        if sys.platform != 'win32':
            return 'Watching the keyboard only works on Windows.'
        self._thread = threading.Thread(target=self._run, name='key-watch', daemon=True)
        self._thread.start()
        if not self._ready.wait(timeout):
            return 'Could not start watching the keyboard (timed out).'
        return self._error

    def handle(self, message, flags, code):
        change = key_change(message, flags, code, self.virtual_key)
        if change == 'down' and not self._down:
            self._down = True
            actual = self._modifier_reader() if self._modifier_reader else 0
            own = {16: 4, 160: 4, 161: 4, 17: 2, 162: 2, 163: 2, 18: 1, 164: 1, 165: 1, 91: 8, 92: 8}.get(code, 0)
            if actual & ~own == self.modifiers:
                self.on_press()
                return
            return
        if change == 'up':
            self._down = False

    def _run(self):
        user32 = None
        hook = None
        try:
            user32 = ctypes.WinDLL('user32', use_last_error=True)
            kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
            user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
            def modifiers():
                return sum((bit for bit, key in ((1, 18), (2, 17), (4, 16)) if user32.GetAsyncKeyState(key) & 32768)) | (8 if (user32.GetAsyncKeyState(91) | user32.GetAsyncKeyState(92)) & 32768 else 0)

            self._modifier_reader = modifiers
            lresult = ctypes.c_ssize_t
            class KBDLLHOOKSTRUCT(ctypes.Structure):
                _fields_ = [('vkCode', wintypes.DWORD), ('scanCode', wintypes.DWORD), ('flags', wintypes.DWORD), ('time', wintypes.DWORD), ('dwExtraInfo', ctypes.c_size_t)]

            hook_proc = ctypes.WINFUNCTYPE(lresult, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)
            kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
            kernel32.GetModuleHandleW.restype = wintypes.HMODULE
            user32.SetWindowsHookExW.argtypes = [ctypes.c_int, hook_proc, wintypes.HINSTANCE, wintypes.DWORD]
            user32.SetWindowsHookExW.restype = wintypes.HHOOK
            user32.CallNextHookEx.argtypes = [wintypes.HHOOK, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM]
            user32.CallNextHookEx.restype = lresult
            user32.UnhookWindowsHookEx.argtypes = [wintypes.HHOOK]
            user32.GetMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT]
            def procedure(code, wparam, lparam):
                try:
                    if code >= 0:
                        info = ctypes.cast(lparam, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
                        self.handle(int(wparam), int(info.flags), int(info.vkCode))
                except Exception:
                    logging.exception('Key watcher callback failed')
                return user32.CallNextHookEx(None, code, wparam, lparam)

            callback = hook_proc(procedure)
            self._thread_id = kernel32.GetCurrentThreadId()
            hook = user32.SetWindowsHookExW(WH_KEYBOARD_LL, callback, kernel32.GetModuleHandleW(None), 0)
            if not hook:
                self._error = f'Windows would not let Lomastrap watch the keyboard (error {ctypes.get_last_error()}).'
                if hook and user32:
                    user32.UnhookWindowsHookEx(hook)
                self._ready.set()
                return
            self._ready.set()
            message = wintypes.MSG()
            while user32.GetMessageW(ctypes.byref(message), None, 0, 0) > 0:
                pass
        except Exception as exc:
            logging.exception('Key watcher failed')
            self._error = self._error or f'Could not watch the keyboard: {exc}'
        if hook and user32:
            user32.UnhookWindowsHookEx(hook)
        self._ready.set()

    def close(self):
        thread_id = self._thread_id
        if self.alive() and thread_id and sys.platform == 'win32':
            try:
                ctypes.WinDLL('user32').PostThreadMessageW(thread_id, WM_QUIT, 0, 0)
            except Exception:
                logging.exception('Could not stop the key watcher')
        if self._thread is not None:
            self._thread.join(timeout=1)


