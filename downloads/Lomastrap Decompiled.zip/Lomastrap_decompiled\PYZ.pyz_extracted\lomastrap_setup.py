'''First-run setup; writes only beside the app, never into onefile extraction.'''

import json
from pathlib import Path
SAFE_SECRETS = {'discord_webhook': '', 'mention': ''}

def ensure_secrets(path):
    '''Create a blank private template exclusively; never overwrite user credentials.'''

    path = Path(path)
    try:
        with path.open('x', encoding='utf-8') as stream:
            json.dump(SAFE_SECRETS, stream, indent=2)
            stream.write('\n')
    except FileExistsError:
        return
    except OSError as exc:
        return f'Cannot create {path.name} beside Lomastrap: {exc}. Move Lomastrap.exe into a writable folder and open it there.'
    return f'Created a blank {path.name} beside Lomastrap.\n\nIn Discord: Channel Settings → Integrations → Webhooks → New Webhook.\nOpen Auto Gank Ping, scroll to Discord connection, paste the full URL and click Save. The field is hidden by default; Show reveals it when you choose. Changes apply immediately. The JSON file remains available for advanced setup.\n\nKeep this file private. Join Macro and monitoring work without a webhook.'

