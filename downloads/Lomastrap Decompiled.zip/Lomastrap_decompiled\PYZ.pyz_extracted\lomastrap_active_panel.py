'''Movable, click-through active-feature list. All rows share one position and scale.'''

from party_esp.config import PartyEspConfig, HealthBarStyleConfig
from party_esp.overlay import PartyEspOverlay, overlay_size
from dataclasses import replace

def active_features(app):
    '''Read actual runtime state and committed bindings, never unsaved key-box drafts.'''

    from lomastrap_hotkeys import display_hotkey
    rows = []
    for label, enabled, key in ('Join Macro', app.joining, 'joiner_hotkey'), ('Auto Gank Ping', app.monitoring, 'ping_hotkey'), ('Combat M1', app.combating and app.advanced_allowed(), 'combat_hotkey'), ('Parry Bar', app.parry_bar is not None and app.data['parry_bar_enabled'] and app.advanced_allowed(), 'parry_key'), ('Party ESP', app.party_service is not None and app.party_service.enabled and app.advanced_allowed(), 'esp_hotkey'):
        if enabled:
            rows.append((label, display_hotkey(app.data[key])))
    return rows

class ActiveFeaturePanel(PartyEspOverlay):
    def __init__(self, rows, on_moved, on_error, position=(0.78, 0.12), scale=1.0, allowed=(lambda: True)):
        super().__init__(PartyEspConfig(fraction_x=position[0], fraction_y=position[1], scale=scale, bar_style=HealthBarStyleConfig(width=280)), on_moved=on_moved, on_error=on_error)
        self.allowed = allowed
        self.rows = rows
        self.items = []

    def start(self, master):
        super().start(master)
        self.root.title('Lomastrap Active Features')

    def _row_count(self):
        return max(2, len(self.items) + 1)

    def _render_loop(self):
        if not self._running or self.canvas is None:
            return
        self._after = None
        self.items = list(self.rows())
        shown = self.allowed() and self._place_over_game()
        if shown:
            if self.root.state() == 'withdrawn':
                self.root.deiconify()
        elif self.root.state() != 'withdrawn':
            self.root.withdraw()
        canvas = self.canvas
        canvas.delete('all')
        width, height = overlay_size(replace(self.config, scale=1.0), self._row_count())
        scale = self.config.scale
        def font(size, bold=False):
            return 'Segoe UI', max(5, round(size * scale)), 'bold' if bold else 'normal'

        canvas.create_rectangle(1, 1, width - 1, height - 1, fill='#1d112c', outline='#77509e', width=1)
        canvas.create_rectangle(1, 1, 4, height - 1, fill='#a779f0', outline='')
        canvas.create_text(17, 22, anchor='w', text='ACTIVE FEATURES', fill='#d7b9ff', font=font(10, True))
        canvas.create_line(15, 41, width - 15, 41, fill='#432958')
        for index, (label, key) in enumerate(self.items):
            y = 64 + index * 45
            canvas.create_oval(17, y - 3, 23, y + 3, fill='#b38afa', outline='')
            canvas.create_text(31, y, anchor='w', text=label, fill='#f0e5ff', font=font(10))
            canvas.create_rectangle(width - 110, y - 13, width - 15, y + 13, fill='#372046', outline='#614078')
            canvas.create_text(width - 62, y, text=key, fill='#d8b9ff', font=font(min(9, max(6, 130 / len(key))), True))
        if not self.items:
            canvas.create_text(17, 64, anchor='w', text='No active features', fill='#ac91bd', font=font(10))
        if self.moving:
            canvas.create_text(width - 10, height - 8, anchor='se', text='Drag this panel', fill='#ae82d8', font=font(8))
        canvas.scale('all', 0, 0, scale, scale)
        self._after = self.root.after(100, self._safe_render)


