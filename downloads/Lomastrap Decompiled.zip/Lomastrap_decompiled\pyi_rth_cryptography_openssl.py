import os
import sys
_ossl_modules_dir = os.path.join(sys._MEIPASS, 'ossl-modules')
if os.path.isdir(_ossl_modules_dir):
    os.environ['OPENSSL_MODULES'] = _ossl_modules_dir
del _ossl_modules_dir
