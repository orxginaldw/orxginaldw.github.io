'''
Local HP fill estimation and smoothed display state.
Names come from authenticated Lomastrap logins, not screen OCR.
'''

import re
import time
from typing import Optional
from PIL import Image

class HealthBarDetector:
    @staticmethod
    def calculate_hp_percentage(image):
        from .reader import read_segments, segment_percent
        return float(segment_percent(read_segments(image)))


class PartyMemberState:
    '''Tracks state and smoothed values for a single party member.'''

    def __init__(self, name: str):
        self.name = name
        self.detected_name = name
        self.current_hp = 100.0
        self.target_hp = 100.0
        self.is_stale = True
        self.last_update_ts = time.monotonic()
        self.history = []

    def update_reading(self, raw_hp: Optional[float], raw_name: Optional[str], stale_timeout: float=3.5):
        now = time.monotonic()
        if raw_hp is not None:
            first = not self.history
            self.history.append(raw_hp)
            if len(self.history) > 3:
                self.history.pop(0)
            self.target_hp = raw_hp
            if first:
                self.current_hp = self.target_hp
            self.last_update_ts = now
            self.is_stale = False
        elif now - self.last_update_ts > stale_timeout:
            self.is_stale = True
        if raw_name:
            if raw_name.strip():
                cleaned = re.sub('[^a-zA-Z0-9_]', '', raw_name)
                if len(cleaned) >= 3:
                    self.detected_name = cleaned

    def tick_animation(self, ease_factor: float=0.15):
        diff = self.target_hp - self.current_hp
        if abs(diff) < 0.2:
            self.current_hp = self.target_hp
            return
        self.current_hp += diff * ease_factor


