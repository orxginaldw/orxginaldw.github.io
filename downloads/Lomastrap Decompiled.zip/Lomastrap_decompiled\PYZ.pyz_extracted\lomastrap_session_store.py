'''Windows CurrentUser DPAPI protection for saved session credentials.'''

import base64
import json
import os
from pathlib import Path

def _crypt(data, decrypt=False):
    if os.name != 'nt':
        raise OSError('Saved persistent access requires Windows protected storage.')
    import ctypes
    from ctypes import wintypes
    class Blob(ctypes.Structure):
        _fields_ = [('size', wintypes.DWORD), ('data', ctypes.POINTER(ctypes.c_ubyte))]

    buffer = ctypes.create_string_buffer(data)
    source = Blob(len(data), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte)))
    result = Blob()
    crypt = ctypes.WinDLL('crypt32', use_last_error=True)
    function = crypt.CryptUnprotectData if decrypt else crypt.CryptProtectData
    function.argtypes = [ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
    function.restype = wintypes.BOOL
    if not function(ctypes.byref(source), None, None, None, None, 1, ctypes.byref(result)):
        raise OSError(ctypes.get_last_error(), 'Windows could not protect or restore this saved session.')
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    kernel.LocalFree.restype = ctypes.c_void_p
    try:
        return ctypes.string_at(result.data, result.size)
    finally:
        kernel.LocalFree(result.data)

def encode(value):
    raw = json.dumps(value).encode('utf-8')
    return {'protected_session_v1': base64.b64encode(_crypt(raw)).decode('ascii')}

def decode(value):
    if 'protected_session_v1' not in value:
        return value
    encoded = value['protected_session_v1']
    if not isinstance(encoded, str) or len(encoded) > 65536:
        raise ValueError('Invalid saved session.')
    raw = _crypt(base64.b64decode(encoded, validate=True), decrypt=True)
    result = json.loads(raw)
    if not isinstance(result, dict):
        raise ValueError('Invalid saved session.')
    return result

