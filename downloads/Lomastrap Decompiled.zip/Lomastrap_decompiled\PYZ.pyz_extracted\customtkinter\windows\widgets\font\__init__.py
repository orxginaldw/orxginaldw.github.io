import os
import sys
from .ctk_font import CTkFont
from .font_manager import FontManager
from ..core_rendering import DrawEngine
FontManager.init_font_manager()
customtkinter_directory = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
FontManager.load_font(os.path.join(customtkinter_directory, 'assets', 'fonts', 'Roboto', 'Roboto-Regular.ttf'))
FontManager.load_font(os.path.join(customtkinter_directory, 'assets', 'fonts', 'Roboto', 'Roboto-Medium.ttf'))
if FontManager.load_font(os.path.join(customtkinter_directory, 'assets', 'fonts', 'CustomTkinter_shapes_font.otf')) is False:
    if DrawEngine.preferred_drawing_method == 'font_shapes':
        sys.stderr.write("customtkinter.windows.widgets.font warning: Preferred drawing method 'font_shapes' can not be used because the font file could not be loaded.\nUsing 'circle_shapes' instead. The rendering quality will be bad!\n")
        DrawEngine.preferred_drawing_method = 'circle_shapes'
