'''Filename globbing utility.'''

import contextlib
import os
import re
import fnmatch
import itertools
import stat
import sys
__all__ = ['glob', 'iglob', 'escape']

def glob(pathname, *, root_dir=None, dir_fd=None, recursive=False, include_hidden=False):
    """Return a list of paths matching a pathname pattern.

    The pattern may contain simple shell-style wildcards a la
    fnmatch. Unlike fnmatch, filenames starting with a
    dot are special cases that are not matched by '*' and '?'
    patterns by default.

    If `include_hidden` is true, the patterns '*', '?', '**'  will match hidden
    directories.

    If `recursive` is true, the pattern '**' will match any files and
    zero or more directories and subdirectories.
    """

    return list(iglob(pathname, root_dir=root_dir, dir_fd=dir_fd, recursive=recursive, include_hidden=include_hidden))

def iglob(pathname, *, root_dir=None, dir_fd=None, recursive=False, include_hidden=False):
    """Return an iterator which yields the paths matching a pathname pattern.

    The pattern may contain simple shell-style wildcards a la
    fnmatch. However, unlike fnmatch, filenames starting with a
    dot are special cases that are not matched by '*' and '?'
    patterns.

    If recursive is true, the pattern '**' will match any files and
    zero or more directories and subdirectories.
    """

    sys.audit('glob.glob', pathname, recursive)
    sys.audit('glob.glob/2', pathname, recursive, root_dir, dir_fd)
    if root_dir is not None:
        root_dir = os.fspath(root_dir)
    else:
        root_dir = pathname[:0]
    it = _iglob(pathname, root_dir, dir_fd, recursive, False, include_hidden=include_hidden)
    if pathname:
        if recursive and _isrecursive(pathname[:2]):
            pass
    try:
        s = next(it)
        if s:
            it = itertools.chain((s,), it)
    except StopIteration:
        pass
    return it

def _iglob(pathname, root_dir, dir_fd, recursive, dironly, include_hidden=False):
    dirname, basename = os.path.split(pathname)
    if not has_magic(pathname):
        if dironly:
            raise AssertionError
        if basename:
            if _lexists(_join(root_dir, pathname), dir_fd):
                yield pathname
            return
        if _isdir(_join(root_dir, dirname), dir_fd):
            yield pathname
        return
    if not dirname:
        if recursive and _isrecursive(basename):
            yield from _glob2(root_dir, basename, dir_fd, dironly, include_hidden=include_hidden)
            return
        yield from _glob1(root_dir, basename, dir_fd, dironly, include_hidden=include_hidden)
        return
    if dirname != pathname and has_magic(dirname):
        dirs = _iglob(dirname, root_dir, dir_fd, recursive, True, include_hidden=include_hidden)
    else:
        dirs = [dirname]
    if has_magic(basename):
        if recursive and _isrecursive(basename):
            glob_in_dir = _glob2
        else:
            glob_in_dir = _glob1
    else:
        glob_in_dir = _glob0
    for dirname in dirs:
        for name in glob_in_dir(_join(root_dir, dirname), basename, dir_fd, dironly, include_hidden=include_hidden):
            yield os.path.join(dirname, name)

def _glob1(dirname, pattern, dir_fd, dironly, include_hidden=False):
    names = _listdir(dirname, dir_fd, dironly)
    if include_hidden or not _ishidden(pattern):
        names = (x for x in names if include_hidden or _ishidden(x))
    return fnmatch.filter(names, pattern)

def _glob0(dirname, basename, dir_fd, dironly, include_hidden=False):
    if basename:
        if _lexists(_join(dirname, basename), dir_fd):
            return [basename]
        return []
    if _isdir(dirname, dir_fd):
        return [basename]
    return []

def glob0(dirname, pattern):
    return _glob0(dirname, pattern, None, False)

def glob1(dirname, pattern):
    return _glob1(dirname, pattern, None, False)

def _glob2(dirname, pattern, dir_fd, dironly, include_hidden=False):
    assert _isrecursive(pattern)
    if not dirname or _isdir(dirname, dir_fd):
        yield pattern[:0]
    yield from _rlistdir(dirname, dir_fd, dironly, include_hidden=include_hidden)

def _iterdir(dirname, dir_fd, dironly):
    try:
        fd = None
        fsencode = None
        if dir_fd is not None:
            if dirname:
                fd = arg = os.open(dirname, _dir_open_flags, dir_fd=dir_fd)
            else:
                arg = dir_fd
            if isinstance(dirname, bytes):
                fsencode = os.fsencode
        elif dirname:
            arg = dirname
        elif isinstance(dirname, bytes):
            arg = bytes(os.curdir, 'ASCII')
        else:
            arg = os.curdir
    except OSError:
        return
    try:
        with os.scandir(arg) as it:
            for entry in it:
                try:
                    try:
                        if not dironly or entry.is_dir():
                            if fsencode is not None:
                                yield fsencode(entry.name)
                            else:
                                yield entry.name
                    except OSError:
                        continue
                finally:
                    pass
    finally:
        if fd is not None:
            os.close(fd)
    try:
        pass
    except OSError:
        return
    finally:
        if fd is not None:
            os.close(fd)

def _listdir(dirname, dir_fd, dironly):
    with contextlib.closing(_iterdir(dirname, dir_fd, dironly)) as it:
        return list(it)

def _rlistdir(dirname, dir_fd, dironly, include_hidden=False):
    names = _listdir(dirname, dir_fd, dironly)
    for x in names:
        if not include_hidden:
            if _ishidden(x):
                continue
        yield x
        path = _join(dirname, x) if dirname else x
        for y in _rlistdir(path, dir_fd, dironly, include_hidden=include_hidden):
            yield _join(x, y)

def _lexists(pathname, dir_fd):
    if dir_fd is None:
        return os.path.lexists(pathname)
    try:
        os.lstat(pathname, dir_fd=dir_fd)
    except (OSError, ValueError):
        return False
    return True

def _isdir(pathname, dir_fd):
    if dir_fd is None:
        return os.path.isdir(pathname)
    try:
        st = os.stat(pathname, dir_fd=dir_fd)
    except (OSError, ValueError):
        return False
    return stat.S_ISDIR(st.st_mode)

def _join(dirname, basename):
    if not dirname or not basename:
        return dirname or basename
    return os.path.join(dirname, basename)

magic_check = re.compile('([*?[])')
magic_check_bytes = re.compile(b'([*?[])')

def has_magic(s):
    if isinstance(s, bytes):
        match = magic_check_bytes.search(s)
        return match is not None
    match = magic_check.search(s)
    return match is not None

def _ishidden(path):
    return path[0] in ('.', 46)

def _isrecursive(pattern):
    if isinstance(pattern, bytes):
        return pattern == b'**'
    return pattern == '**'

def escape(pathname):
    '''Escape all special characters.
    '''

    drive, pathname = os.path.splitdrive(pathname)
    if isinstance(pathname, bytes):
        pathname = magic_check_bytes.sub(b'[\\1]', pathname)
        return drive + pathname
    pathname = magic_check.sub('[\\1]', pathname)
    return drive + pathname

_dir_open_flags = os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0)
