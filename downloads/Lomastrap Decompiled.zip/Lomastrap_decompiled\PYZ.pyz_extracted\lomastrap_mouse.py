"""Watches the REAL left mouse button so Combat M1 can follow it.

Clicks that programs send (including Lomastrap's own) are ignored; only the physical
button counts. Windows-only; on other systems start() reports that it cannot run.
"""

import ctypes
import logging
import sys
import threading
from ctypes import wintypes
WM_LBUTTONDOWN, WM_LBUTTONUP = 513, 514
LLMHF_INJECTED, LLMHF_LOWER_IL_INJECTED = 1, 2
WH_MOUSE_LL, WM_QUIT = 14, 18

def physical_left_change(message, flags):
    '''True = real press, False = real release, None = not a real left-button event.'''

    if flags & (LLMHF_INJECTED | LLMHF_LOWER_IL_INJECTED):
        return
    if message == WM_LBUTTONDOWN:
        return True
    if message == WM_LBUTTONUP:
        return False

class PhysicalLeftButton:
    '''`pressed` is set while the person holds the real left mouse button.'''

    def __init__(self):
        self.pressed = threading.Event()
        self._thread = None
        self._thread_id = None
        self._ready = threading.Event()
        self._error = ''

    def alive(self):
        return self._thread is not None and self._thread.is_alive()

    def start(self, timeout=3.0):
        '''Returns "" when watching, otherwise a message saying why not.'''

        if sys.platform != 'win32':
            return 'Watching the mouse only works on Windows.'
        self._thread = threading.Thread(target=self._run, name='mouse-watch', daemon=True)
        self._thread.start()
        if not self._ready.wait(timeout):
            return 'Could not start watching the mouse (timed out).'
        return self._error

    def _run(self):
        user32 = None
        hook = None
        try:
            user32 = ctypes.WinDLL('user32', use_last_error=True)
            kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
            lresult = ctypes.c_ssize_t
            class MSLLHOOKSTRUCT(ctypes.Structure):
                _fields_ = [('pt', wintypes.POINT), ('mouseData', wintypes.DWORD), ('flags', wintypes.DWORD), ('time', wintypes.DWORD), ('dwExtraInfo', ctypes.c_size_t)]

            hook_proc = ctypes.WINFUNCTYPE(lresult, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)
            kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
            kernel32.GetModuleHandleW.restype = wintypes.HMODULE
            user32.SetWindowsHookExW.argtypes = [ctypes.c_int, hook_proc, wintypes.HINSTANCE, wintypes.DWORD]
            user32.SetWindowsHookExW.restype = wintypes.HHOOK
            user32.CallNextHookEx.argtypes = [wintypes.HHOOK, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM]
            user32.CallNextHookEx.restype = lresult
            user32.UnhookWindowsHookEx.argtypes = [wintypes.HHOOK]
            user32.GetMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT]
            def procedure(code, wparam, lparam):
                try:
                    if code >= 0:
                        info = ctypes.cast(lparam, ctypes.POINTER(MSLLHOOKSTRUCT)).contents
                        change = physical_left_change(int(wparam), int(info.flags))
                        if change is True:
                            self.pressed.set()
                        elif change is False:
                            self.pressed.clear()
                except Exception:
                    logging.exception('Mouse watcher callback failed')
                return user32.CallNextHookEx(None, code, wparam, lparam)

            callback = hook_proc(procedure)
            self._thread_id = kernel32.GetCurrentThreadId()
            hook = user32.SetWindowsHookExW(WH_MOUSE_LL, callback, kernel32.GetModuleHandleW(None), 0)
            if not hook:
                self._error = f'Windows would not let Lomastrap watch the mouse (error {ctypes.get_last_error()}).'
                self.pressed.clear()
                if hook and user32:
                    user32.UnhookWindowsHookEx(hook)
                self._ready.set()
                return
            self._ready.set()
            message = wintypes.MSG()
            while user32.GetMessageW(ctypes.byref(message), None, 0, 0) > 0:
                pass
        except Exception as exc:
            logging.exception('Mouse watcher failed')
            self._error = self._error or f'Could not watch the mouse: {exc}'
        self.pressed.clear()
        if hook and user32:
            user32.UnhookWindowsHookEx(hook)
        self._ready.set()

    def close(self):
        self.pressed.clear()
        thread_id = self._thread_id
        if self.alive() and thread_id and sys.platform == 'win32':
            try:
                ctypes.WinDLL('user32').PostThreadMessageW(thread_id, WM_QUIT, 0, 0)
            except Exception:
                logging.exception('Could not stop the mouse watcher')
        if self._thread is not None:
            self._thread.join(timeout=1)


