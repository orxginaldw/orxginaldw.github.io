'''The small parry cooldown bar drawn over the Roblox window.'''

import logging
import sys
import tkinter as tk
BAR_BACK, BAR_BORDER = '#100a1b', '#6b4a99'
READY, RECHARGING, MOVING = '#9de6c5', '#ff93b7', '#bd9aff'
GWL_EXSTYLE = -20
WS_EX_TRANSPARENT, WS_EX_TOOLWINDOW, WS_EX_LAYERED, WS_EX_NOACTIVATE = 32, 128, 524288, 134217728

def clamp(value, low, high):
    return max(low, min(high, value))

def bar_geometry(rect, fraction_x, fraction_y):
    '''(width, height, left, top) in pixels for a Roblox window rect (left, top, right, bottom).'''

    left, top, right, bottom = rect
    window_width, window_height = max(1, right - left), max(1, bottom - top)
    width = int(clamp(window_width * 0.13, 100, 600))
    height = int(clamp(window_height * 0.02, 10, 28))
    x = int(left + fraction_x * window_width - width / 2)
    y = int(top + fraction_y * window_height - height / 2)
    return width, height, x, y

def fractions_from_position(rect, left, top, width, height):
    '''Inverse of bar_geometry: where the bar centre sits inside the window, as fractions 0..1.'''

    window_left, window_top, window_right, window_bottom = rect
    window_width, window_height = max(1, window_right - window_left), max(1, window_bottom - window_top)
    return clamp((left + width / 2 - window_left) / window_width, 0.0, 1.0), clamp((top + height / 2 - window_top) / window_height, 0.0, 1.0)

class ParryBar(tk.Toplevel):
    '''A thin always-on-top bar that never takes clicks or focus (except while it is being moved).'''

    def __init__(self, app, on_moved):
        super().__init__(app)
        self.on_moved = on_moved
        self.moving = False
        self._geometry = None
        self._drawn = None
        self._drag = None
        self._visible = False
        self.overrideredirect(True)
        self.configure(bg=BAR_BACK)
        try:
            self.attributes('-topmost', True)
            self.attributes('-alpha', 0.92)
        except tk.TclError:
            pass
        self.canvas = tk.Canvas(self, bg=BAR_BACK, highlightthickness=0, bd=0)
        self.canvas.pack(fill='both', expand=True)
        self.canvas.bind('<ButtonPress-1>', self._press)
        self.canvas.bind('<B1-Motion>', self._drag_to)
        self.canvas.bind('<ButtonRelease-1>', self._release)
        self.withdraw()
        self.update_idletasks()
        self._click_through(True)

    def _click_through(self, enabled):
        if sys.platform != 'win32':
            return
        try:
            import ctypes
            user32 = ctypes.windll.user32
            user32.GetParent.argtypes = [ctypes.c_void_p]
            user32.GetParent.restype = ctypes.c_void_p
            user32.GetWindowLongPtrW.argtypes = [ctypes.c_void_p, ctypes.c_int]
            user32.GetWindowLongPtrW.restype = ctypes.c_ssize_t
            user32.SetWindowLongPtrW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_ssize_t]
            user32.SetWindowLongPtrW.restype = ctypes.c_ssize_t
            handle = user32.GetParent(self.winfo_id()) or self.winfo_id()
            style = user32.GetWindowLongPtrW(handle, GWL_EXSTYLE)
            style |= WS_EX_LAYERED | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE
            style = style | WS_EX_TRANSPARENT if enabled else style & ~WS_EX_TRANSPARENT
            user32.SetWindowLongPtrW(handle, GWL_EXSTYLE, style)
            return
        except Exception:
            logging.exception('Could not make the parry bar click-through')

    def begin_move(self):
        self.moving = True
        self._click_through(False)
        self._drawn = None

    def end_move(self):
        self.moving = False
        self._click_through(True)
        self._drawn = None

    def _press(self, event):
        if self.moving:
            self._drag = event.x_root - self.winfo_x(), event.y_root - self.winfo_y()

    def _drag_to(self, event):
        if self.moving:
            if self._drag:
                self.geometry(f'+{event.x_root - self._drag[0]}+{event.y_root - self._drag[1]}')

    def _release(self, event):
        if self.moving:
            if self._drag:
                self._drag = None
                self.on_moved(self.winfo_x(), self.winfo_y(), self.winfo_width(), self.winfo_height())

    def update_bar(self, rect, fraction_x, fraction_y, fraction):
        '''rect is the Roblox window rectangle, or None when the bar should be hidden.'''

        if rect is None:
            if self._visible:
                self.withdraw()
                self._visible = False
            return
        width, height, left, top = bar_geometry(rect, fraction_x, fraction_y)
        if not self.moving or self._geometry is None:
            geometry = f'{width}x{height}+{left}+{top}'
            if geometry != self._geometry:
                self.geometry(geometry)
                self._geometry = geometry
        else:
            self.geometry(f'{width}x{height}')
        if not self._visible:
            self.deiconify()
            self._visible = True
            self._drawn = None
        try:
            self.attributes('-topmost', True)
        except tk.TclError:
            pass
        shown = width, height, round(fraction * width), self.moving
        if shown != self._drawn:
            self._drawn = shown
            self._draw(width, height, fraction)

    def _draw(self, width, height, fraction):
        canvas = self.canvas
        canvas.delete('all')
        canvas.configure(width=width, height=height)
        canvas.create_rectangle(0, 0, width - 1, height - 1, outline=BAR_BORDER, fill=BAR_BACK)
        colour = MOVING if self.moving else READY if fraction >= 1.0 else RECHARGING
        filled = round((width - 4) * clamp(fraction, 0.0, 1.0))
        if filled > 0:
            canvas.create_rectangle(2, 2, 2 + filled, height - 3, outline='', fill=colour)
        if self.moving:
            canvas.create_text(width / 2, height / 2, text='drag me', fill=BAR_BACK, font=('Segoe UI', max(7, height // 2), 'bold'))


_WINDOWS = {}

def _windows_api():
    '''user32 with typed arguments, created once.'''

    if 'user32' not in _WINDOWS:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.WinDLL('user32', use_last_error=True)
        user32.GetForegroundWindow.restype = wintypes.HWND
        user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
        user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        user32.GetClientRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
        user32.ClientToScreen.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.POINT)]
        user32.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
        user32.FindWindowW.restype = wintypes.HWND
        user32.IsIconic.argtypes = [wintypes.HWND]
        user32.IsWindowVisible.argtypes = [wintypes.HWND]
        user32.WindowFromPoint.argtypes = [wintypes.POINT]
        user32.WindowFromPoint.restype = wintypes.HWND
        user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
        user32.GetAncestor.restype = wintypes.HWND
        _WINDOWS['user32'] = user32
    return _WINDOWS['user32']

def foreground_client_rect():
    '''(window title, (left, top, right, bottom) of its drawing area) for the window in front, or None.'''

    if sys.platform != 'win32':
        return
    try:
        import ctypes
        from ctypes import wintypes
        user32 = _windows_api()
        handle = user32.GetForegroundWindow()
        if not handle:
            return
        length = user32.GetWindowTextLengthW(handle)
        buffer = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(handle, buffer, length + 1)
        rect, origin = wintypes.RECT(), wintypes.POINT(0, 0)
        if not (user32.GetClientRect(handle, ctypes.byref(rect)) and user32.ClientToScreen(handle, ctypes.byref(origin))):
            return
        return buffer.value, (origin.x, origin.y, origin.x + rect.right, origin.y + rect.bottom)
    except Exception:
        logging.exception('Could not read the window in front')

def _window_title(user32, handle):
    import ctypes
    length = user32.GetWindowTextLengthW(handle)
    buffer = ctypes.create_unicode_buffer(length + 1)
    user32.GetWindowTextW(handle, buffer, length + 1)
    return buffer.value

def roblox_client_rect():
    '''(left, top, right, bottom) of the Roblox drawing area even when another window is in front.

    None when Roblox is closed or minimised, so overlays can follow the game without it being focused.
    '''

    if sys.platform != 'win32':
        return
    try:
        import ctypes
        from ctypes import wintypes
        user32 = _windows_api()
        handle = user32.FindWindowW(None, 'Roblox')
        if not handle or user32.IsIconic(handle) or not user32.IsWindowVisible(handle):
            return
        rect, origin = wintypes.RECT(), wintypes.POINT(0, 0)
        if not (user32.GetClientRect(handle, ctypes.byref(rect)) and user32.ClientToScreen(handle, ctypes.byref(origin))):
            return
        if rect.right <= 0 or rect.bottom <= 0:
            return
        return origin.x, origin.y, origin.x + rect.right, origin.y + rect.bottom
    except Exception:
        logging.exception('Could not find the Roblox window')

def roblox_shows_point(x, y):
    '''True when Roblox is the window showing at screen point (x, y), so a screen grab there sees the game.

    Roblox does not have to be the focused window, but nothing may cover that spot.
    '''

    if sys.platform != 'win32':
        return False
    try:
        from ctypes import wintypes
        user32 = _windows_api()
        handle = user32.WindowFromPoint(wintypes.POINT(int(x), int(y)))
        if not handle:
            return False
        root = user32.GetAncestor(handle, 2) or handle
        return _window_title(user32, root).strip().lower() == 'roblox'
    except Exception:
        logging.exception('Could not check what is on screen')
        return False

