'''Display-only shared-health overlay style; all user settings live in lomastrap-settings.json.'''

from dataclasses import dataclass, field

@dataclass
class HealthBarStyleConfig:
    width: int = 260
    height: int = 24
    orientation: str = 'horizontal'
    show_border: bool = True
    border_color: str = '#1E1E1E'
    background_color: str = '#2B2B2B'
    color_high: str = '#33DD55'
    color_mid: str = '#33DD55'
    color_low: str = '#EE3333'
    color_stale: str = '#555555'
    text_position: str = 'inside'
    low_hp_threshold: float = 25.0
    pulse_on_low: bool = False
    ease_speed: float = 0.3

@dataclass
class PartyEspConfig:
    fraction_x: float = 0.02
    fraction_y: float = 0.05
    scale: float = 1.0
    overlay_opacity: float = 0.9
    members: dict = field(default_factory=dict)
    bar_style: HealthBarStyleConfig = field(default_factory=HealthBarStyleConfig)

