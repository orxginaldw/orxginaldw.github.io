'''Pure logic for Lomastrap: no GUI and no Windows APIs, so it is easy to test.

Covers settings, reading the server name out of OCR text, the two-matching-reads
confirmation rule, the ping cooldown, the Discord message and the webhook
credentials (which are read from the environment or a git-ignored file, never
from source code).
'''

import copy
import difflib
import json
import logging
import math
import os
import re
import socket
import ssl
import time
import unicodedata
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
import lomastrap_fflags as fflags
WEBHOOK_RE = re.compile('^https://(?:canary\\.|ptb\\.)?discord(?:app)?\\.com/api/webhooks/\\d+/[\\w-]+$')
DEFAULT_SETTINGS = {'health_reader': {}, 'life_capture_area': None, 'active_panel_enabled': False, 'active_panel_hotkey': 'f10', 'active_panel_x': 0.78, 'active_panel_y': 0.12, 'active_panel_scale': 1.0, 'esp_enabled': False, 'esp_hotkey': 'f9', 'capture_area': None, 'points': [{'x': 1142, 'y': 258}, {'x': 958, 'y': 629}], 'click_interval_ms': 10, 'click_hold_ms': 1, 'reads_per_second': 1.0, 'last_page': 'Join Macro', 'window_geometry': '760x650', 'cooldown_seconds': 900, 'monitoring_enabled': False, 'joiner_hotkey': 'f5', 'ping_hotkey': 'f2', 'combat_hotkey': 'f6', 'combat_fastest_ms': 12, 'combat_slowest_ms': 30, 'parry_bar_enabled': False, 'parry_key': 'f', 'parry_cooldown_ms': 1250, 'parry_buffer_ms': 50, 'parry_bar_x': 0.5, 'parry_bar_y': 0.75, 'esp_x': 0.02, 'esp_scale': 1.0, 'esp_y': 0.05, 'fflags': {}, 'fflags_applied': [], 'fflags_auto_apply': True}
WEBHOOK_ENV = 'LOMASTRAP_DISCORD_WEBHOOK'
MENTION_ENV = 'LOMASTRAP_DISCORD_MENTION'

def pick_combat_hotkey(wanted, joiner, ping):
    '''The saved Combat key if it is valid and unused, otherwise the first free default.'''

    from lomastrap_hotkeys import validate_bindings
    for candidate in wanted, DEFAULT_SETTINGS['combat_hotkey'], 'f7', 'f9', 'f10', 'f11':
        try:
            pass
        except ValueError:
            continue
        return validate_bindings(joiner, ping, str(candidate))[2]
    return DEFAULT_SETTINGS['combat_hotkey']

def clean_parry_key(value):
    from lomastrap_hotkeys import canonical_hotkey
    return canonical_hotkey(value)

def parry_times(cooldown_ms, buffer_ms):
    '''Valid (cooldown, buffer) in whole milliseconds.'''

    return int(clamp(cooldown_ms, 200, 10000, DEFAULT_SETTINGS['parry_cooldown_ms'])), int(clamp(buffer_ms, 0, 500, DEFAULT_SETTINGS['parry_buffer_ms']))

class ParryCooldown:
    '''The parry bar: full means you can parry. A key press empties it and it refills over time.

    Only a press while the bar is full starts a refill; presses during a refill are ignored,
    because the game does not let you parry then either. It cannot know whether a parry hit
    (a hit resets the real cooldown), so every press is treated as a miss.
    '''

    def __init__(self, cooldown_ms=1250, buffer_ms=50, clock=time.monotonic):
        self.clock = clock
        self.started = None
        self.configure(cooldown_ms, buffer_ms)

    def configure(self, cooldown_ms, buffer_ms):
        self.cooldown_ms, self.buffer_ms = parry_times(cooldown_ms, buffer_ms)

    @property
    def total_seconds(self):
        return (self.cooldown_ms + self.buffer_ms) / 1000

    def fraction(self):
        if self.started is None:
            return 1.0
        done = (self.clock() - self.started) / self.total_seconds
        if done >= 1:
            self.started = None
            return 1.0
        return max(0.0, done)

    def ready(self):
        return self.fraction() >= 1.0

    def press(self):
        '''True when this press started a refill.'''

        if not self.ready():
            return False
        self.started = self.clock()
        return True

    def reset(self):
        self.started = None


COMBAT_MIN_GAP_MS, COMBAT_MAX_GAP_MS = 5, 1000

def combat_range(fastest, slowest):
    '''Valid (fastest, slowest) click gaps in whole milliseconds; slowest is never below fastest.'''

    low = int(clamp(fastest, COMBAT_MIN_GAP_MS, COMBAT_MAX_GAP_MS, DEFAULT_SETTINGS['combat_fastest_ms']))
    high = int(clamp(slowest, COMBAT_MIN_GAP_MS, COMBAT_MAX_GAP_MS, DEFAULT_SETTINGS['combat_slowest_ms']))
    return low, max(low, high)

class HumanTiming:
    '''Click timing that never settles into one rhythm.

    Each click gets its own gap (press to next press) drawn around the fast end of
    the chosen range, an occasional short hesitation, and its own hold time. The
    gap is never shorter than `fastest` and the normal gap never longer than
    `slowest`; only a hesitation can exceed it, and only by a small amount.
    '''

    HESITATION_CHANCE = 0.04
    def __init__(self, fastest_ms, slowest_ms, rng=None):
        import random
        self.fastest, self.slowest = combat_range(fastest_ms, slowest_ms)
        self.rng = rng or random.Random()

    def next_click(self):
        '''Returns (hold_seconds, release_wait_seconds) for the next click.'''

        span = self.slowest - self.fastest
        if span == 0:
            gap = float(self.fastest)
        else:
            gap = self.rng.gauss(self.fastest + span * 0.35, span / 4)
            gap = min(max(gap, self.fastest), self.slowest)
        if self.rng.random() < self.HESITATION_CHANCE:
            gap += self.rng.uniform(25, 80)
        hold = self.rng.uniform(1.0, min(9.0, max(1.0, gap / 2)))
        return hold / 1000, max(0.0, gap - hold) / 1000


def load_settings(path):
    data = copy.deepcopy(DEFAULT_SETTINGS)
    try:
        saved = json.loads(Path(path).read_text(encoding='utf-8'))
        if isinstance(saved, dict):
            data.update({k: v for k, v in saved.items() if k in DEFAULT_SETTINGS})
    except (OSError, json.JSONDecodeError, UnicodeError):
        pass
    if not (isinstance(data['points'], list) and len(data['points']) == 2):
        data['points'] = copy.deepcopy(DEFAULT_SETTINGS['points'])
    data['points'] = [point if all((type(point.get(k)) is int for k in ('x', 'y'))) else copy.deepcopy(DEFAULT_SETTINGS['points'][index]) for index, point in enumerate(data['points']) if not isinstance(point, dict)]
    area = data['capture_area']
    if area is not None:
        if isinstance(area, dict):
            if not (all((type(area.get(k)) is int for k in ('x', 'y', 'width', 'height'))) and area['width'] > 0 and area['height'] > 0):
                data['capture_area'] = None
    for key in ('joiner_hotkey', 'ping_hotkey'):
        if isinstance(data[key], str):
            if data[key].strip():
                continue
        data[key] = DEFAULT_SETTINGS[key]
    data['click_interval_ms'] = int(clamp(data['click_interval_ms'], 10, 5000, 10))
    data['click_hold_ms'] = int(clamp(data['click_hold_ms'], 1, 40, 1))
    data['reads_per_second'] = reads_per_second(data['reads_per_second'])
    if data['last_page'] not in ('Settings', 'Join Macro', 'Auto Gank Ping', 'Combat', 'Visuals'):
        data['last_page'] = 'Join Macro'
    if not valid_geometry(data['window_geometry']):
        data['window_geometry'] = '760x650'
    data['cooldown_seconds'] = 900
    data['monitoring_enabled'] = data['monitoring_enabled'] is True
    from lomastrap_hotkeys import validate_bindings
    try:
        data['joiner_hotkey'], data['ping_hotkey'] = validate_bindings(data['joiner_hotkey'], data['ping_hotkey'])
    except ValueError:
        data['joiner_hotkey'], data['ping_hotkey'] = DEFAULT_SETTINGS['joiner_hotkey'], DEFAULT_SETTINGS['ping_hotkey']
    data['combat_hotkey'] = pick_combat_hotkey(data['combat_hotkey'], data['joiner_hotkey'], data['ping_hotkey'])
    data['combat_fastest_ms'], data['combat_slowest_ms'] = combat_range(data['combat_fastest_ms'], data['combat_slowest_ms'])
    data['esp_enabled'] = data['esp_enabled'] is True
    try:
        from lomastrap_hotkeys import canonical_hotkey
        data['esp_hotkey'] = canonical_hotkey(data['esp_hotkey'])
    except ValueError:
        data['esp_hotkey'] = DEFAULT_SETTINGS['esp_hotkey']
    if data['life_capture_area'] is not None:
        try:
            capture_box(data['life_capture_area'], (-100000, -100000, 200000, 200000))
        except (ValueError, TypeError):
            data['life_capture_area'] = None
    from lomastrap_hotkeys import validate_bindings
    for candidate in data['esp_hotkey'], 'f9', 'f10', 'f11', 'insert', 'home', 'f24':
        try:
            data['esp_hotkey'] = validate_bindings(data['joiner_hotkey'], data['ping_hotkey'], data['combat_hotkey'], candidate)[3]
        except ValueError:
            continue
        break
    data['active_panel_enabled'] = data['active_panel_enabled'] is True
    data['parry_bar_enabled'] = data['parry_bar_enabled'] is True
    try:
        data['parry_key'] = clean_parry_key(data['parry_key'])
    except ValueError:
        data['parry_key'] = DEFAULT_SETTINGS['parry_key']
    for candidate in data['active_panel_hotkey'], 'f10', 'f11', 'f12', 'insert', 'home', 'f24':
        try:
            data['active_panel_hotkey'] = validate_bindings(data['joiner_hotkey'], data['ping_hotkey'], data['combat_hotkey'], data['esp_hotkey'], candidate)[4]
            from lomastrap_hotkeys import parse_hotkey
            if data['parry_bar_enabled'] and parse_hotkey(candidate) == parse_hotkey(data['parry_key']):
                raise ValueError('Panel conflicts with parry.')
        except (ValueError, TypeError):
            continue
        break
    data['parry_cooldown_ms'], data['parry_buffer_ms'] = parry_times(data['parry_cooldown_ms'], data['parry_buffer_ms'])
    for key in ('parry_bar_x', 'parry_bar_y', 'esp_x', 'esp_y', 'active_panel_x', 'active_panel_y'):
        data[key] = float(clamp(data[key], 0.0, 1.0, DEFAULT_SETTINGS[key]))
    data['esp_scale'] = float(clamp(data['esp_scale'], 0.5, 2.0, 1.0))
    data['active_panel_scale'] = float(clamp(data['active_panel_scale'], 0.5, 2.0, 1.0))
    data['fflags'] = fflags.clean_flags(data['fflags'])
    applied = data['fflags_applied'] if isinstance(data['fflags_applied'], list) else []
    data['fflags_applied'] = sorted({name for name in applied
         if isinstance(name, str)
         if _valid_flag_name(name)})[:fflags.MAX_FLAGS]
    data['fflags_auto_apply'] = data['fflags_auto_apply'] is not False
    return data

def _valid_flag_name(name):
    try:
        return fflags.validate_name(name) == name
    except fflags.FlagError:
        return False

def save_settings(path, data):
    saved = {key: copy.deepcopy(data.get(key, default)) for key, default in DEFAULT_SETTINGS.items()}
    saved['cooldown_seconds'] = 900
    saved.pop('allies', None)
    target = Path(path)
    temporary = target.with_suffix('.tmp')
    temporary.write_text(json.dumps(saved, indent=2), encoding='utf-8')
    temporary.replace(target)

def clamp(value, low, high, default):
    try:
        number = float(value)
        if math.isfinite(number) and not isinstance(value, bool):
            return max(low, min(high, number))
        return default
    except (TypeError, ValueError):
        return default

@dataclass(frozen=True)
class Reading:
    server: str
    area: str = ''
    luminant: str = ''

KNOWN_LUMINANTS = ('Eastern Luminant', 'Etrean Luminant', 'The Depths')
LUMINANT_SUFFIX = re.compile('(\\b\\w+\\s+Luminant|\\bThe\\s+Depths)\\s*$', re.IGNORECASE)

def canonical_luminant(text):
    '''Map OCR text to a known Luminant ("Eastem Luminant" -> "Eastern Luminant").'''

    value = ' '.join(unicodedata.normalize('NFC', str(text or '')).split()).strip(" .,:;|!-'’")
    if value and not len(value) > 40:
        if any((not (c.isalpha() or c.isspace() or c in "-'’") for c in value)):
            return ''
    close = difflib.get_close_matches(value.title(), KNOWN_LUMINANTS, n=1, cutoff=0.72)
    if close:
        return close[0]
    if value.lower().endswith('luminant'):
        return value.title()
    return ''

def short_luminant(value):
    '''Eastern Luminant -> Eastern, Etrean Luminant -> Etrean, The Depths -> Depths.'''

    value = str(value or '').strip()
    if value.lower().endswith(' luminant'):
        value = value[:-len(' luminant')]
        return value.strip()
    if value.lower().startswith('the '):
        value = value[4:]
    return value.strip()

ICON_LETTERS = set('OoQ0iIl')

def _split_icon(value):
    """Return (name part, text after the info icon).

    The game puts a small circled-i after the server name, the OCR reads it as
    O, i, l or a symbol, and the next column's text (the Luminant) can share the
    same OCR line. A lone one-character word marks that spot. When the icon is
    missed, a known Luminant at the end of the line is split off instead.
    """

    words = value.split()
    start = next((i for i, word in enumerate(words) if any((c.isalpha() for c in word))), len(words))
    for index in range(start + 1, len(words)):
        word = words[index]
        if len(word) != 1:
            continue
        if word not in ICON_LETTERS:
            if word.isalnum():
                continue
        return ' '.join(words[:index]), ' '.join(words[index + 1:])
    match = LUMINANT_SUFFIX.search(value)
    if match and match.start() > 0:
        return value[:match.start()].rstrip(), match.group(1)
    return value, ''

def _cut_at_icon(value):
    return _split_icon(value)[0]

def _name_line(line):
    value = _cut_at_icon(unicodedata.normalize('NFC', ' '.join(line.split())))
    while value and not value[0].isalpha():
        value = value[1:]
    while value and not value[-1].isalpha():
        value = value[:-1]
    if 2 <= len(value) <= 120:
        if sum((c.isalpha() for c in value)) < 2:
            return
    allowed = " -'’‐‑"
    if any((not (c.isalpha() or unicodedata.category(c).startswith('M') or c in allowed) for c in value)):
        return
    if value[0].isalpha() and value[-1].isalpha():
        return value

def _region_line(line):
    '''Region such as "England, UK" from a line like "England, UK .111".

    Stops at the first word with a digit (signal bars, ping, clock) and drops
    trailing icon-like fragments; returns "" when nothing readable is left.
    '''

    words = []
    for word in unicodedata.normalize('NFC', ' '.join(line.split())).split():
        if any((c.isdigit() for c in word)):
            break
        words.append(word)
    while words and set(words[-1]) <= set(".,:;|!ıIl'’-"):
        words.pop()
    value = ' '.join(words).rstrip(' .,:;|!-')
    if value and not len(value) > 120:
        if any((c.isalpha() for c in value)):
            if any((not (c.isalpha() or c.isspace() or c in ",.-'’‐‑" or unicodedata.category(c).startswith('M')) for c in value)):
                return ''
    return value

def _luminant_line(line):
    '''Recognize a standalone realm label without treating ordinary names as one.'''

    compact = ''.join((c for c in unicodedata.normalize('NFKD', line).casefold()
         if c.isascii() and c.isalpha()))
    if compact.endswith(('nant', 'nnt', 'inan', 'inant')):
        choices = {'easternluminant': 'Eastern Luminant', 'etreanluminant': 'Etrean Luminant'}
        match = difflib.get_close_matches(compact, choices, n=1, cutoff=0.84)
        if match:
            return choices[match[0]]
    words = line.split()
    if words and len(words[0]) == 1:
        if words[0] in ICON_LETTERS or not words[0].isalnum():
            while True:
                words.pop(0)
                if not words:
                    break
                if len(words[0]) != 1:
                    break
                if words[0] in ICON_LETTERS:
                    continue
                if words[0].isalnum():
                    break
    value = _name_line(' '.join(words))
    if not value:
        return ''
    words = value.split()
    if len(words) == 2 and re.fullmatch('lumi[a-z]{0,5}nt', words[1].casefold()):
        prefix = difflib.get_close_matches(words[0].title(), ('Eastern', 'Etrean'), n=1, cutoff=0.72)
        if prefix:
            return prefix[0] + ' Luminant'
        return ''
    if value.casefold() in ('depths', 'the depths'):
        return 'The Depths'
    return ''

def parse_reading(text):
    '''Read a dynamic server name and metadata, even when OCR reorders columns.'''

    if not isinstance(text, str):
        return
    lines = [' '.join(line.split()) for line in text.splitlines() if line.strip()]
    labels = [_luminant_line(line) for line in lines]
    distinct = {label for label in labels if label}
    separate = next(iter(distinct)) if len(distinct) == 1 else ''
    for index, line in enumerate(lines):
        if labels[index]:
            continue
        name = _name_line(line)
        if name is not None:
            location = ''
            for following, label in zip(lines[index + 1:], labels[index + 1:]):
                if label:
                    continue
                location = _region_line(following)
                if location:
                    break
            tail = _split_icon(unicodedata.normalize('NFC', line))[1]
            return Reading(name, location, canonical_luminant(tail) or separate)

def name_key(name):
    return unicodedata.normalize('NFC', ' '.join(name.split())).casefold().replace('’', "'")

class Confirmer:
    '''Confirm two matching recognized names; unclear reads do not change evidence.'''

    def __init__(self, needed=2):
        self.needed = needed
        self.candidate = None
        self._pending = None
        self.count = 0
        self.confirmed = None

    @property
    def ready(self):
        return self.confirmed is not None and self.count >= self.needed and name_key(self.confirmed.server) == self.candidate

    def feed(self, reading):
        if reading is None:
            return False
        key = name_key(reading.server)
        if key == self.candidate:
            self.count = min(self.needed, self.count + 1)
            if self._pending is not None:
                reading = Reading(reading.server, reading.area or self._pending.area, reading.luminant or self._pending.luminant)
        else:
            self.candidate, self.count = key, 1
        if self.count >= self.needed:
            previous = self.confirmed
            if previous is not None and name_key(previous.server) == key:
                reading = Reading(reading.server, reading.area or previous.area, reading.luminant or previous.luminant)
            changed = previous != reading
            self.confirmed = reading
            self._pending = reading
            return changed
        self._pending = reading
        return False


class Cooldown:
    def __init__(self, seconds, clock=time.monotonic):
        self.seconds, self.clock, self.last = seconds, clock, None

    def remaining(self):
        if self.last is None:
            return 0.0
        return max(0.0, self.seconds - (self.clock() - self.last))

    def ready(self):
        return self.remaining() <= 0

    def restore(self, remaining):
        '''Display a server deadline using a monotonic local countdown.'''

        self.last = self.clock() - self.seconds + max(0, float(remaining))

    def start(self):
        self.last = self.clock()


def describe_extras(reading):
    '''"  |  Luminant: Eastern  |  Region: Paris, FR" for the window; empty parts are left out.'''

    parts = ('Luminant', short_luminant(reading.luminant)), ('Region', reading.area)
    return ''.join((f'  |  {label}: {value}' for label, value in parts if value))

def format_ping(reading, mention=''):
    lines = [mention] if mention else []
    lines += ['**Gank ping**', f'Server: {reading.server}', f'Luminant: {short_luminant(reading.luminant) or 'unknown'}', f'Region: {reading.area or 'unknown'}']
    return '\n'.join(lines)[:1900]

def load_webhook(secrets_path):
    '''Returns (url, mention, error). Environment variables win over the file.'''

    url = os.environ.get(WEBHOOK_ENV, '').strip()
    mention = os.environ.get(MENTION_ENV, '').strip()
    if not url:
        try:
            secrets = json.loads(Path(secrets_path).read_text(encoding='utf-8'))
            url = str(secrets.get('discord_webhook', '')).strip()
            mention = mention or str(secrets.get('mention', '')).strip()
        except (OSError, json.JSONDecodeError, AttributeError):
            pass
    if not url:
        return None, '', f'No Discord webhook. Set {WEBHOOK_ENV} or create lomastrap-secrets.json.'
    if not WEBHOOK_RE.match(url):
        return (None, '', 'The Discord webhook URL is not valid.')
    return url, mention, ''

def send_webhook(url, content, mention='', timeout=10):
    '''Posts to Discord. Returns None on success or a short error (never the URL).'''

    payload = {'content': content, 'allowed_mentions': {'parse': ['roles', 'users'] if mention else []}}
    request = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), method='POST', headers={'Content-Type': 'application/json', 'User-Agent': 'Lomastrap/0.2'})
    try:
        with urllib.request.urlopen(request, timeout=timeout):
            pass
    except urllib.error.HTTPError as exc:
        error = describe_http_error(exc.code)
    except (urllib.error.URLError, OSError) as exc:
        error = describe_network_error(getattr(exc, 'reason', exc))

def describe_http_error(code):
    if code in (401, 403):
        return f'Discord refused the webhook (HTTP {code}). Create a new webhook and save it again.'
    if code == 404:
        return 'Discord says this webhook does not exist (HTTP 404). It was deleted or the URL is wrong; create a new one.'
    if code == 429:
        return 'Discord is rate-limiting pings (HTTP 429). Wait a minute and try again.'
    return f'Discord rejected the ping (HTTP {code}).'

def describe_network_error(reason):
    '''Plain-language cause for a failed connection. Never includes the URL.'''

    if isinstance(reason, ssl.SSLError):
        return 'Could not reach Discord: the secure connection failed (SSL). Antivirus HTTPS scanning, a proxy, or a wrong PC clock can cause this. Check the date/time and pause HTTPS scanning.'
    if isinstance(reason, (socket.timeout, TimeoutError)):
        return 'Could not reach Discord: the connection timed out. Check your internet or firewall.'
    if isinstance(reason, socket.gaierror):
        return 'Could not reach Discord: DNS lookup failed. Check your internet connection or DNS.'
    if isinstance(reason, (ConnectionRefusedError, ConnectionResetError, ConnectionAbortedError)):
        return 'Could not reach Discord: the connection was blocked. A firewall or antivirus may be stopping Lomastrap.'
    return f'Could not reach Discord ({type(reason).__name__}). Check your internet, firewall and antivirus.'

def capture_box(area, bounds):
    '''Validate a physical-pixel region against (x, y, width, height).'''

    if not isinstance(area, dict):
        raise ValueError('no region selected')
    values = [area.get(k) for k in ('x', 'y', 'width', 'height')]
    if any((type(v) is not int for v in values)):
        raise ValueError('coordinates and dimensions must be integers')
    x, y, width, height = values
    bx, by, bw, bh = bounds
    if width < 20 or height < 12:
        raise ValueError('region must be at least 20 by 12 pixels')
    if x < bx or y < by or x + width > bx + bw or y + height > by + bh:
        raise ValueError('region is outside the current desktop (monitor layout changed)')
    return x, y, x + width, y + height

def reads_per_second(value):
    return float(clamp(value, 1, 2, 1.0))

def choose_ocr_language(tags):
    '''Use installed English first, then an installed Latin-script recognizer.'''

    for prefix in ('en', 'it', 'fr', 'de', 'es', 'pt', 'nl', 'sv', 'da', 'nb', 'fi', 'pl', 'cs', 'ro', 'tr'):
        for tag in tags:
            if tag.lower().split('-')[0] != prefix:
                continue
            return tag
    raise ValueError('No suitable Windows OCR language installed. Add the English Windows OCR capability.')

def ocr_result_text(result):
    '''Windows OcrResult.text flattens rows; retain lines for name/location parsing.'''

    lines = result.get('lines') if isinstance(result, dict) else getattr(result, 'lines', None)
    if lines:
        return '\n'.join((str(line.get('text', '') if isinstance(line, dict) else getattr(line, 'text', '')) for line in lines))
    return str(result.get('text', '') if isinstance(result, dict) else getattr(result, 'text', ''))

def save_webhook(path, url):
    '''Validate/save only to the private file, preserving mention and other fields.'''

    url = str(url).strip()
    if not WEBHOOK_RE.fullmatch(url):
        raise ValueError('Enter a complete Discord webhook URL. It has not been saved.')
    target = Path(path)
    try:
        existing = json.loads(target.read_text(encoding='utf-8'))
    except FileNotFoundError:
        existing = {}
    except (json.JSONDecodeError, UnicodeError):
        raise ValueError('The secrets JSON is invalid. Repair it before saving to preserve its other values.') from None
    if not isinstance(existing, dict):
        raise ValueError('The secrets file must contain a JSON object.')
    existing['discord_webhook'] = url
    temporary = target.with_suffix('.tmp')
    temporary.write_text(json.dumps(existing, indent=2), encoding='utf-8')
    temporary.replace(target)

ROLE_HELP = 'Enter the role ID (numbers only) or a mention like <@&123456789012345678>. Typing @Gank does not ping anyone in a webhook; Discord needs the ID.'

def normalize_mention(value):
    '''Turn a pasted role/user ID into a real Discord mention. Empty means no ping.'''

    text = str(value or '').strip()
    if not text:
        return ''
    if text.isdigit():
        if 15 <= len(text) <= 22:
            return f'<@&{text}>'
    if re.fullmatch('<@[&!]?\\d{15,22}>', text):
        return text
    raise ValueError(ROLE_HELP)

def save_mention(path, value):
    '''Save the role to ping in the private file, keeping the webhook and other fields.'''

    mention = normalize_mention(value)
    target = Path(path)
    try:
        existing = json.loads(target.read_text(encoding='utf-8'))
    except FileNotFoundError:
        existing = {}
    except (json.JSONDecodeError, UnicodeError):
        raise ValueError('The secrets JSON is invalid. Repair it before saving.') from None
    if not isinstance(existing, dict):
        raise ValueError('The secrets file must contain a JSON object.')
    existing['mention'] = mention
    temporary = target.with_suffix('.tmp')
    temporary.write_text(json.dumps(existing, indent=2), encoding='utf-8')
    temporary.replace(target)
    return mention

def valid_geometry(value):
    if not isinstance(value, str):
        return False
    match = re.fullmatch('(\\d{3,4})x(\\d{3,4})(?:[+-]\\d{1,5}[+-]\\d{1,5})?', value)
    if match:
        if 720 <= int(match[1]) <= 7680:
            return bool(560 <= int(match[2]) <= 4320)
    return None(None)

def normalize_role_id(value):
    mention = normalize_mention(value)
    if not mention:
        return ''
    if not mention.startswith('<@&'):
        raise ValueError('Use a numeric role ID or <@&ID>, not a user mention.')
    role = mention[3:-1]
    if role.isascii() and role.isdigit():
        if 15 <= len(role):
            if not len(role) <= 22:
                raise ValueError('Enter a numeric Discord role ID (15–22 digits), or leave it blank.')
    raise ValueError('Enter a numeric Discord role ID (15–22 digits), or leave it blank.')
    return role

def load_depths_mention(path):
    try:
        role = normalize_role_id(json.loads(Path(path).read_text(encoding='utf-8')).get('depths_role_id', ''))
        if role:
            return '<@&' + role + '>'
        return ''
    except (OSError, ValueError, TypeError, AttributeError):
        return ''

def save_depths_mention(path, value):
    role = normalize_role_id(value)
    target = Path(path)
    try:
        data = json.loads(target.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        data = {}
    if not isinstance(data, dict):
        data = {}
    data['depths_role_id'] = role
    temp = target.with_suffix('.tmp')
    temp.write_text(json.dumps(data, indent=2), encoding='utf-8')
    temp.replace(target)

def mention_for_luminant(luminant, surface, depths):
    realm = short_luminant(luminant)
    if realm == 'Depths':
        return depths
    if realm in ('Eastern', 'Etrean'):
        return surface
    return ''

# WARNING: Decompyle incomplete
