from __future__ import annotations
import hmac

def bytes_eq(a: 'bytes', b: 'bytes') -> 'bool':
    if not (isinstance(a, bytes) and isinstance(b, bytes)):
        raise TypeError('a and b must be bytes.')
    return hmac.compare_digest(a, b)

