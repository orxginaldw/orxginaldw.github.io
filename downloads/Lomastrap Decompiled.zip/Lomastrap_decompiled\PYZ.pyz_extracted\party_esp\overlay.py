'''
Click-through, transparent HUD overlay for Party ESP using Tkinter and Win32 API.
Renders smooth health bars and player names over Roblox without window focus capture.
'''

import tkinter as tk
from dataclasses import replace
from typing import Dict, Optional
from .config import PartyEspConfig
from .detector import PartyMemberState
PAD, TAB_H, TAB_OVERLAP, ROW_GAP, MAX_ROWS = 10, 16, 5, 10, 10
SEGMENTS = 5
SILVER, SILVER_STALE, OUTLINE, TAB_FILL = '#b9bfcc', '#7c7f88', '#14141c', '#c8ccd8'

def row_height(config):
    '''Vertical space one person takes: the name tab, the bar and the gap below it.'''

    return (TAB_H - TAB_OVERLAP + config.bar_style.height + ROW_GAP) * config.scale

def overlay_size(config, count=None):
    '''Window size in pixels. Every person gets their own row, stacked downward in join order.'''

    rows = max(1, min(MAX_ROWS, len(config.members) if count is None else count))
    return round(max(260, config.bar_style.width + 2 * PAD) * config.scale), round((2 * PAD - ROW_GAP) * config.scale + rows * row_height(config))

def member_layout(config, index):
    '''Where the pieces of row `index` (0 = the first person) go inside the overlay window.'''

    style = config.bar_style
    top = PAD + index * row_height(replace(config, scale=1.0))
    x0 = PAD
    x1 = x0 + style.width
    bar_top = top + TAB_H - TAB_OVERLAP
    bar = x0, bar_top, x1, bar_top + style.height
    inner = x0 + 3, bar[1] + 3, x1 - 3, bar[3] - 3
    step = (inner[2] - inner[0]) / SEGMENTS
    dividers = [round(inner[0] + step * k) for k in range(1, SEGMENTS)]
    scale = config.scale
    return {'tab_top': top * scale, 'bar': tuple((v * scale for v in bar)), 'inner': tuple((v * scale for v in inner)), 'dividers': [x * scale for x in dividers], 'centre_x': (x0 + x1) // 2 * scale}

def shade(colour, factor):
    '''Lighter (factor > 1) or darker (factor < 1) version of a #rrggbb colour.'''

    r, g, b = (int(colour[i:i + 2], 16) for i in (1, 3, 5))
    if factor >= 1:
        r, g, b = (round(v + (255 - v) * (factor - 1)) for v in (r, g, b))
    else:
        r, g, b = (round(v * factor) for v in (r, g, b))
    return '#%02x%02x%02x' % (min(255, r), min(255, g), min(255, b))

def overlay_position(rect, fraction_x, fraction_y, width, height):
    """(x, y) of the overlay's top-left corner, kept inside the rect (left, top, right, bottom)."""

    left, top, right, bottom = rect
    x = left + int(fraction_x * max(1, right - left))
    y = top + int(fraction_y * max(1, bottom - top))
    return max(left, min(x, right - width)), max(top, min(y, bottom - height))

def overlay_fractions(rect, x, y):
    '''Inverse of overlay_position: where the top-left corner sits in the rect, as fractions 0..1.'''

    left, top, right, bottom = rect
    return max(0.0, min(1.0, (x - left) / max(1, right - left))), max(0.0, min(1.0, (y - top) / max(1, bottom - top)))

class PartyEspOverlay:
    '''Transparent layered window overlay that follows the Roblox window, focused or not.'''

    def __init__(self, config: PartyEspConfig, visible=(lambda: True), on_error=(lambda text: None), on_moved=None):
        self.config = config
        self.visible = visible
        self.on_error = on_error
        self.on_moved = on_moved
        self.moving = False
        self._drag = None
        self._sample = PartyMemberState('Drag me')
        self._after = None
        self._position = None
        self.root = None
        self.canvas = None
        self._running = False
        self.members_state = {}

    def start(self, master_tk: tk.Tk):
        if self.root:
            return
        self._running = True
        self._position = None
        self.members_state = {}
        self.root = tk.Toplevel(master_tk)
        self.root.title('Lomastrap Party ESP')
        self.root.withdraw()
        self.root.overrideredirect(True)
        self.root.attributes('-topmost', True)
        trans_color = '#010101'
        self.root.config(bg=trans_color)
        try:
            self.root.wm_attributes('-transparentcolor', trans_color)
            self.root.attributes('-alpha', self.config.overlay_opacity)
        except tk.TclError:
            pass
        w, h = overlay_size(self.config, 1)
        self.root.geometry(f'{w}x{h}+0+0')
        self.canvas = tk.Canvas(self.root, bg=trans_color, highlightthickness=0, width=w, height=h)
        self.canvas.pack(fill='both', expand=True)
        self.canvas.bind('<ButtonPress-1>', self._press)
        self.canvas.bind('<B1-Motion>', self._drag_to)
        self.canvas.bind('<ButtonRelease-1>', self._release)
        self._set_click_through()
        self._render_loop()

    def _set_click_through(self, enabled=True):
        from lomastrap_parry_bar import ParryBar
        self.root.update_idletasks()
        ParryBar._click_through(self.root, enabled)

    def begin_move(self):
        if not self.root:
            return
        self.moving = True
        self._position = None
        self._set_click_through(False)

    def end_move(self):
        self.moving = False
        self._drag = None
        self._position = None
        if self.root:
            self._set_click_through(True)

    def _press(self, event):
        if self.moving:
            self._drag = event.x_root - self.root.winfo_x(), event.y_root - self.root.winfo_y()

    def _drag_to(self, event):
        if self.moving:
            if self._drag:
                self.root.geometry(f'+{event.x_root - self._drag[0]}+{event.y_root - self._drag[1]}')

    def _release(self, event):
        if not self.moving or not self._drag:
            return
        self._drag = None
        rect = self._game_rect() or self._screen_rect()
        fraction_x, fraction_y = overlay_fractions(rect, self.root.winfo_x(), self.root.winfo_y())
        self.config.fraction_x = round(fraction_x, 4)
        self.config.fraction_y = round(fraction_y, 4)
        if self.on_moved:
            self.on_moved(self.config.fraction_x, self.config.fraction_y)

    def _screen_rect(self):
        return 0, 0, self.root.winfo_screenwidth(), self.root.winfo_screenheight()

    def _game_rect(self):
        '''Where Roblox is on screen, even when another window has focus; None when it is closed or minimised.'''

        from lomastrap_parry_bar import roblox_client_rect
        return roblox_client_rect()

    def set_scale(self, value):
        self.config.scale = max(0.5, min(2.0, float(value)))
        self._position = None
        if self.root:
            width, height = overlay_size(self.config, self._row_count())
            self.root.geometry(f'{width}x{height}')
            self.canvas.configure(width=width, height=height)

    def reset_position(self):
        defaults = PartyEspConfig()
        self.config.fraction_x = defaults.fraction_x
        self.config.fraction_y = defaults.fraction_y
        self._position = None

    def _place_over_game(self):
        '''Put the overlay over Roblox. False means there is no Roblox window to put it on.'''

        rect = self._game_rect()
        if rect is None:
            return self.moving
        if self.moving:
            return True
        width, height = overlay_size(self.config, self._row_count())
        x, y = overlay_position(rect, self.config.fraction_x, self.config.fraction_y, width, height)
        position = x, y, width, height
        if position == self._position:
            return True
        import ctypes
        user = ctypes.WinDLL('user32', use_last_error=True)
        user.GetParent.argtypes = [ctypes.c_void_p]
        user.GetParent.restype = ctypes.c_void_p
        user.SetWindowPos.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_uint]
        hwnd = user.GetParent(self.root.winfo_id()) or self.root.winfo_id()
        if not user.SetWindowPos(hwnd, None, x, y, width, height, 20):
            raise RuntimeError('Windows could not position the Party ESP overlay.')
        self._position = position
        return True

    def update_states(self, states: Dict[str, PartyMemberState]):
        for key, incoming in states.items():
            previous = self.members_state.get(key)
            if previous is None:
                self.members_state[key] = incoming
            else:
                previous.target_hp = incoming.target_hp
                previous.is_stale = incoming.is_stale
                previous.detected_name = incoming.detected_name
        for key in set(self.members_state) - set(states):
            del self.members_state[key]

    def _get_health_color(self, hp: float, is_stale: bool) -> str:
        cfg = self.config.bar_style
        if is_stale:
            return cfg.color_stale
        if hp >= 25.0:
            return cfg.color_high
        return cfg.color_low

    def _row_count(self):
        return min(MAX_ROWS, max(1, len(self.members_state)))

    def _render_loop(self):
        if not self._running or not self.canvas:
            return
        self._after = None
        shown = (self.moving or self.visible()) and self._place_over_game()
        if shown:
            if self.root.state() == 'withdrawn':
                self.root.deiconify()
        elif self.root.state() != 'withdrawn':
            self.root.withdraw()
        self.canvas.delete('all')
        style = self.config.bar_style
        if self.moving:
            width, height = overlay_size(replace(self.config, scale=1.0), self._row_count())
            self.canvas.create_rectangle(0, 0, width, height, fill='#1c132c', outline='#bd9aff', width=2)
            self.canvas.create_text(width - 8, height - 6, anchor='se', text='drag me, then press Done moving', fill='#bd9aff', font=('Segoe UI', max(5, round(8 * self.config.scale)), 'bold'))
        members = self.members_state or ({'sample': self._sample} if self.moving else {})
        for index, (member_id, state) in enumerate(list(members.items())[:MAX_ROWS]):
            state.tick_animation(style.ease_speed)
            name_text = state.detected_name if state.detected_name else member_id
            self._draw_member(member_layout(replace(self.config, scale=1.0), index), name_text, state.current_hp, state.is_stale, state.target_hp)
        self.canvas.scale('all', 0, 0, self.config.scale, self.config.scale)
        if self.root:
            self._after = self.root.after(50, self._safe_render)

    def _draw_member(self, layout, name, hp, stale, confirmed_hp=None):
        """One person: a framed bar in five parts, their name on a tab above it, 'NN% HEALTH' across it."""

        canvas, style = self.canvas, self.config.bar_style
        x0, y0, x1, y1 = layout['bar']
        ix0, iy0, ix1, iy1 = layout['inner']
        silver = SILVER_STALE if stale else SILVER
        canvas.create_rectangle(x0, y0, x1, y1, fill=silver, outline=OUTLINE, width=1)
        canvas.create_rectangle(ix0 - 1, iy0 - 1, ix1 + 1, iy1 + 1, fill=OUTLINE, outline='')
        canvas.create_rectangle(ix0, iy0, ix1, iy1, fill=style.background_color, outline='')
        fill_width = round((ix1 - ix0) * max(0.0, min(100.0, hp)) / 100.0)
        if fill_width > 0:
            colour = self._get_health_color(hp if confirmed_hp is None else confirmed_hp, stale)
            canvas.create_rectangle(ix0, iy0, ix0 + fill_width, iy1, fill=colour, outline='')
            canvas.create_rectangle(ix0, iy0, ix0 + fill_width, iy0 + 1, fill=shade(colour, 1.35), outline='')
            canvas.create_rectangle(ix0, iy1 - 2, ix0 + fill_width, iy1, fill=shade(colour, 0.7), outline='')
        for x in layout['dividers']:
            canvas.create_line(x, iy0, x, iy1, fill=OUTLINE)
            for y, direction in (y0, 1), (y1, -1):
                canvas.create_polygon(x, y - 2 * direction, x + 3, y + 1 * direction, x, y + 4 * direction, x - 3, y + 1 * direction, fill=shade(silver, 1.25), outline=OUTLINE)
        for x in x0 + 1, x1 - 1:
            canvas.create_oval(x - 3, y0 + (y1 - y0) // 2 - 3, x + 3, y0 + (y1 - y0) // 2 + 3, fill=shade(silver, 1.25), outline=OUTLINE)
        text = f'{int(round(hp if confirmed_hp is None else confirmed_hp))}% HEALTH' + (' · LAST' if stale else '')
        middle_x, middle_y = layout['centre_x'], (y0 + y1) // 2
        canvas.create_text(middle_x + 1, middle_y + 1, text=text, fill='#000000', font=('Segoe UI', max(5, round(9 * self.config.scale)), 'bold'))
        canvas.create_text(middle_x, middle_y, text=text, fill='#FFFFFF' if not stale else '#cfcfcf', font=('Segoe UI', max(5, round(9 * self.config.scale)), 'bold'))
        label = name if len(name) <= 18 else name[:17] + '…'
        tab_width = max(54, 8 * len(label) + 18)
        top = layout['tab_top']
        canvas.create_rectangle(middle_x - tab_width // 2, top, middle_x + tab_width // 2, top + TAB_H, fill=TAB_FILL if not stale else SILVER_STALE, outline=OUTLINE)
        canvas.create_text(middle_x, top + TAB_H // 2, text=label, fill='#23232b', font=('Segoe UI', max(5, round(8 * self.config.scale)), 'bold'))

    def _safe_render(self):
        try:
            self._render_loop()
            return
        except Exception as exc:
            self.stop()
            self.on_error('Party ESP overlay stopped: ' + str(exc))

    def stop(self):
        self._running = False
        self.moving = False
        self._drag = None
        if self.root:
            if self._after is not None:
                self.root.after_cancel(self._after)
                self._after = None
            self.root.destroy()
            self.root = None
            self.canvas = None


