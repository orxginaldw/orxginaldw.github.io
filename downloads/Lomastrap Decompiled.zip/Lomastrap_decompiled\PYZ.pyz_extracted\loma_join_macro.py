'''Lomastrap shared macro control panel.
Run with: pythonw loma_join_macro.py (no terminal window).

Server Joiner: clicks two saved screen points over and over. F5 starts and stops by default.
Gank Ping:     watches a small screen area for the server name. F2 sends a Discord ping.
'''

import os
import logging
import math
import queue
import sys
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import messagebox
import customtkinter as ctk
import lomastrap_fflags as fflags
import lomastrap_logic as logic
from lomastrap_hotkeys import (GlobalHotkeys, validate_bindings, display_hotkey)
from lomastrap_setup import ensure_secrets
from lomastrap_instance import SingleInstance
from lomastrap_mouse import PhysicalLeftButton
from lomastrap_keys import KeyWatcher
from lomastrap_parry_bar import (ParryBar, fractions_from_position, foreground_client_rect, roblox_client_rect, roblox_shows_point)
BIND_ACTIONS = {'joiner_hotkey': ('joiner', 'toggle_joiner'), 'ping_hotkey': ('ping', 'ping'), 'combat_hotkey': ('combat', 'toggle_combat'), 'esp_hotkey': ('esp', 'toggle_esp'), 'active_panel_hotkey': ('active_panel', 'toggle_active_panel')}
BIND_SETTING = {event: setting for setting, (_, event) in BIND_ACTIONS.items()}
BIND_TITLES = {'joiner_hotkey': 'JOIN SHORTCUT', 'ping_hotkey': 'PING SHORTCUT', 'combat_hotkey': 'COMBAT SHORTCUT', 'esp_hotkey': 'ESP SHORTCUT', 'active_panel_hotkey': 'PANEL SHORTCUT'}
BG, PANEL, BORDER = '#100a1b', '#1c132c', '#3d2b55'
SIDEBAR, PRIMARY = '#160e24', '#8653ed'
TEXT, MUTED, PURPLE, GREEN = '#f8f3ff', '#baa9cf', '#bd9aff', '#9de6c5'
BUTTON, WARNING, RED = '#332247', '#ebcf99', '#ff93b7'
APP_DIR = Path(sys.executable).parent if getattr(sys, 'frozen', False) else Path(__file__).parent
ASSETS = Path(getattr(sys, '_MEIPASS', Path(__file__).parent)) / 'assets'
SETTINGS = APP_DIR / 'lomastrap-settings.json'
SECRETS = APP_DIR / 'lomastrap-secrets.json'

def tcl_path(path):
    try:
        return Path(os.path.relpath(path)).as_posix()
    except ValueError:
        return Path(path).as_posix()

if getattr(sys, 'frozen', False):
    bundle = Path(sys._MEIPASS)
    os.environ['TCL_LIBRARY'] = tcl_path(bundle / '_tcl_data')
    os.environ['TK_LIBRARY'] = tcl_path(bundle / '_tk_data')
IS_WINDOWS = sys.platform == 'win32'
if IS_WINDOWS:
    import ctypes
    _user32 = ctypes.windll.user32

def enable_dpi_awareness():
    '''Make screen coordinates real pixels so saved areas and clicks line up.'''

    if not IS_WINDOWS:
        return
    try:
        _user32.SetProcessDpiAwarenessContext.argtypes = [ctypes.c_void_p]
        if _user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4)):
            return
        logging.warning('Per-monitor V2 DPI awareness unavailable')
    except AttributeError:
        logging.info('DPI V2 API unavailable; trying per-monitor V1')
    try:
        result = ctypes.windll.shcore.SetProcessDpiAwareness(2)
        if result not in (0, -2147024891):
            logging.warning('SetProcessDpiAwareness returned %s', result)
            return
    except (AttributeError, OSError):
        logging.exception('Per-monitor DPI awareness unavailable')
        _user32.SetProcessDPIAware()

def desktop_bounds():
    if not IS_WINDOWS:
        raise ValueError('Screen capture requires Windows.')
    return tuple((_user32.GetSystemMetrics(i) for i in (76, 77, 78, 79)))

def click_at(x, y, hold_ms=1, stop=None):
    '''Move, send a real mouse-move, settle, press, hold, release.

    SetCursorPos alone moves the pointer without a mouse-move event, so Roblox keeps
    using the old position until the user moves the mouse. A small timed nudge sends
    real move events; the pointer ends exactly on the target. Cancellation can never
    leave a button down or the pointer offset.
    '''

    def pause(seconds):
        if stop is None:
            time.sleep(seconds)
            return True
        return not stop.wait(seconds)

    if stop is not None and stop.is_set():
        return False
    if not _user32.SetCursorPos(int(x), int(y)):
        raise OSError('SetCursorPos failed; check the input desktop and privilege level.')
    if not pause(0.01):
        return False
    _user32.mouse_event(1, 1, 0, 0, 0)
    try:
        pause(0.01)
    finally:
        _user32.mouse_event(1, -1, 0, 0, 0)
        _user32.SetCursorPos(int(x), int(y))
    if not pause(0.02):
        return False
    _user32.mouse_event(2, 0, 0, 0, 0)
    try:
        pause(logic.clamp(hold_ms, 1, 40, 1) / 1000)
    finally:
        _user32.mouse_event(4, 0, 0, 0, 0)
    return stop is None or not stop.is_set()

def click_m1(hold_seconds, stop):
    """One left click at the pointer's current spot. The button is always released."""

    _user32.mouse_event(2, 0, 0, 0, 0)
    try:
        stop.wait(hold_seconds)
    finally:
        _user32.mouse_event(4, 0, 0, 0, 0)

def foreground_title():
    hwnd = _user32.GetForegroundWindow()
    length = _user32.GetWindowTextLengthW(hwnd)
    buffer = ctypes.create_unicode_buffer(length + 1)
    _user32.GetWindowTextW(hwnd, buffer, length + 1)
    return buffer.value

def game_active():
    '''True only while the Roblox window is the one in front.'''

    return IS_WINDOWS and foreground_title().strip().lower() == 'roblox'

def game_readable(area=None):
    '''True while Roblox can be read off the screen, even when it is not the window in front.

    Roblox must be open and not minimised; with an area, Roblox must also be what shows at the middle of it,
    so a window on top never gets read as if it were the game.
    '''

    if area:
        return roblox_shows_point(area['x'] + area['width'] // 2, area['y'] + area['height'] // 2)
    return roblox_client_rect() is not None

def game_usable(area=None):
    '''Roblox is in front, or is open and showing at `area` while another window has focus.'''

    return game_active() or game_readable(area)

_SCREEN_CAPTURE_LOCK = threading.Lock()

class OcrUnavailable(Exception):
    pass

def grab(area):
    try:
        box = logic.capture_box(area, desktop_bounds())
    except ValueError as exc:
        raise ValueError(f'Invalid capture area: {exc}. Choose the area again.') from exc
    try:
        from PIL import ImageGrab
    except ImportError as exc:
        raise OcrUnavailable('Capture dependency missing: run python -m pip install Pillow.') from exc
    try:
        with _SCREEN_CAPTURE_LOCK:
            image = ImageGrab.grab(bbox=box, all_screens=True)
        if image.size != (box[2] - box[0], box[3] - box[1]):
            raise OSError('Capture returned unexpected pixel dimensions')
    except Exception as exc:
        raise RuntimeError(f'Capture API/permission failure ({type(exc).__name__}: {exc}). Use an unlocked interactive Windows desktop; check screen-capture restrictions and try Roblox in borderless/windowed mode.') from exc
    return image

def ocr_text(image, strict=False):
    from lomastrap_ocr import (variants, select_text, OcrText, region_crop)
    prepared = iter(variants(image))
    _, gray = next(prepared)
    try:
        import winocr
    except ImportError:
        winocr = None
    if winocr:
        import asyncio
        try:
            engine = getattr(winocr, 'OcrEngine', None)
        except Exception as exc:
            raise OcrUnavailable(f'Windows OCR failed: {exc}. Install an English Windows language/OCR pack to enable a suitable recognizer.') from exc
        language = logic.choose_ocr_language([item.language_tag for item in engine.available_recognizer_languages]) if engine else 'en'
        recognizer = engine.try_create_from_language(winocr.Language(language)) if engine else None
        async def recognize_one(gray):
            if engine is None:
                return await asyncio.wait_for(winocr.recognize_pil(gray, language), timeout=2)
            writer = winocr.DataWriter()
            writer.write_bytes(gray.tobytes())
            bitmap = winocr.SoftwareBitmap.create_copy_from_buffer(writer.detach_buffer(), winocr.BitmapPixelFormat.GRAY8, gray.width, gray.height)
            return await asyncio.wait_for(recognizer.recognize_async(bitmap), timeout=2)

        async def recognize():
            started = time.monotonic()
            original_result = await recognize_one(gray)
            texts = [logic.ocr_result_text(original_result)]
            diagnostics = ['Language: ' + language + '\ncontrast:\n' + texts[0]]
            for label, candidate in prepared:
                if time.monotonic() - started > 0.35:
                    break
                try:
                    text = logic.ocr_result_text(await recognize_one(candidate))
                except Exception as exc:
                    logging.warning('OCR fallback %s failed (%s)', label, type(exc).__name__)
                    diagnostics.append(label + ': failed (' + type(exc).__name__ + ')')
                    continue
                texts.append(text)
                diagnostics.append(label + ':\n' + text)
            region_text = ''
            if engine is not None:
                if time.monotonic() - started < 0.35:
                    crop = region_crop(original_result, image, gray.width / image.width)
                    if crop is not None:
                        try:
                            region_text = logic.ocr_result_text(await recognize_one(crop))
                            diagnostics.append('region detail:\n' + region_text)
                        except Exception as exc:
                            logging.warning('OCR region detail failed (%s)', type(exc).__name__)
                            diagnostics.append('region detail: failed (' + type(exc).__name__ + ')')
            if strict:
                from lomastrap_hud import parse_hud
                chosen = select_text(texts, region_text, parser=parse_hud) if len(texts) > 1 else texts[0]
            else:
                chosen = select_text(texts, region_text) if len(texts) > 1 else texts[0]
            return OcrText(chosen, '\n\n'.join(diagnostics))

        result = asyncio.run(recognize())
        return result
    try:
        import pytesseract
    except ImportError:
        raise OcrUnavailable('No OCR engine. Run: pip install winocr') from None
    try:
        return pytesseract.image_to_string(gray, config='--psm 6', timeout=10)
    except Exception as exc:
        raise OcrUnavailable(f'Tesseract OCR failed: {exc}. Install Tesseract and add it to PATH.') from exc

class FullScreenOverlay(tk.Toplevel):
    def __init__(self, app, prompt):
        super().__init__(app)
        self.app = app
        self.attributes('-topmost', True)
        self.attributes('-alpha', 0.3)
        self.configure(bg='black')
        self.origin_x, self.origin_y, width, height = desktop_bounds()
        self.geometry(f'{width}x{height}+0+0')
        self.overrideredirect(True)
        self.update_idletasks()
        _user32.GetParent.argtypes = [ctypes.c_void_p]
        _user32.GetParent.restype = ctypes.c_void_p
        _user32.SetWindowPos.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_uint]
        hwnd = _user32.GetParent(self.winfo_id()) or self.winfo_id()
        if not _user32.SetWindowPos(hwnd, None, self.origin_x, self.origin_y, width, height, 4):
            raise OSError('Could not position selection overlay on the virtual desktop')
        self.overrideredirect(True)
        self.canvas = tk.Canvas(self, bg='black', highlightthickness=0, cursor='crosshair')
        self.canvas.pack(fill='both', expand=True)
        self.canvas.create_text(width // 2, 35, text=prompt, fill='white', font=('Segoe UI', 13, 'bold'))
        self.bind('<Escape>', (lambda event: self.destroy()))
        self.focus_force()

    def destroy(self):
        super().destroy()
        if not self.app.closing:
            self.app.deiconify()
            self.app.lift()


class AreaPicker(FullScreenOverlay):
    def __init__(self, app, kind='server'):
        self.kind = kind
        super().__init__(app, 'Drag around your FULL life bar (filled and empty). Enter saves. Esc cancels.' if kind == 'life' else 'Drag around server name, region and Luminant. Enter saves. Esc cancels.')
        self.start, self.rect = None, None
        self.canvas.bind('<ButtonPress-1>', self.begin)
        self.canvas.bind('<B1-Motion>', self.draw)
        self.bind('<Return>', self.save)

    def begin(self, event):
        self.start = event.x, event.y
        if self.rect:
            self.canvas.delete(self.rect)
        self.rect = self.canvas.create_rectangle(event.x, event.y, event.x, event.y, outline=GREEN, width=3, fill='#1f8f70')

    def draw(self, event):
        if self.start:
            if self.rect:
                self.canvas.coords(self.rect, self.start[0], self.start[1], event.x, event.y)

    def save(self, event):
        if not self.rect:
            self.bell()
            return
        x1, y1, x2, y2 = map(int, self.canvas.coords(self.rect))
        left, right = sorted((x1, x2))
        top, bottom = sorted((y1, y2))
        if right - left < 20 or bottom - top < 12:
            messagebox.showwarning('Area too small', 'Choose an area large enough to read.', parent=self)
            return
        area = {'x': left + self.origin_x, 'y': top + self.origin_y, 'width': right - left, 'height': bottom - top}
        if self.__dict__.get('kind') == 'life':
            self.app.store_life_area(area)
        else:
            self.app.store_area(area)
        self.destroy()


class PointPicker(FullScreenOverlay):
    def __init__(self, app, index):
        super().__init__(app, f'Click where point {index + 1} should be clicked. Esc cancels.')
        self.index = index
        self.canvas.bind('<ButtonPress-1>', self.pick)

    def pick(self, event):
        x, y = event.x_root, event.y_root
        self.destroy()
        self.app.store_point(self.index, x, y)


class Lomastrap(tk.Tk):
    def __init__(self, access_session=None, updater=None):
        self.updater = updater
        self.update_status = None
        self.access_session = access_session
        self.strict_reading = access_session is not None
        self.logout_requested = False
        self._access_check_running = False
        self._owner_panel = None
        enable_dpi_awareness()
        super().__init__()
        self.title('Lomastrap')
        ctk.set_appearance_mode('dark')
        self.data = logic.load_settings(SETTINGS)
        if self.strict_reading:
            self.data['reads_per_second'] = 1.0
        self._initializing = True
        self._autosave_id = None
        self.geometry(self.data['window_geometry'])
        self.minsize(720, 560)
        self.configure(bg=BG)
        try:
            self.iconbitmap(tcl_path(ASSETS / 'lomastrap.ico'))
        except tk.TclError:
            logging.exception('Could not load window icon')
        self.events = queue.Queue()
        self.lock = threading.Lock()
        self.ping_lock = threading.Lock()
        self.read_lock = threading.Lock()
        self.joiner_lock = threading.Lock()
        from lomastrap_hud import HudTracker
        self.confirmer = HudTracker() if self.strict_reading else logic.Confirmer()
        self.cooldown = logic.Cooldown(30 if access_session and access_session.owner else 900)
        self.joiner_stop, self.monitor_stop = threading.Event(), threading.Event()
        self.combat_stop, self.combat_lock, self.combating = threading.Event(), threading.Lock(), False
        self.combat_watcher = None
        self.parry = logic.ParryCooldown(self.data['parry_cooldown_ms'], self.data['parry_buffer_ms'])
        self.parry_bar, self.parry_watcher, self.parry_after = None, None, None
        self.parry_presses = queue.SimpleQueue()
        self.joining = self.monitoring = False
        self._last_state = None
        self.monitor_thread = None
        self.closing = False
        self.hotkey_status = tk.StringVar(value='Registering global hotkeys…')
        self.joiner_notice = tk.StringVar(value='Set both points, then use Start or your shortcut.')
        self.ping_notice = tk.StringVar(value='Confirm a server before sending. Discord is managed by the owner.')
        self.joiner_key_seen = tk.StringVar(value='No shortcut received yet')
        self.ping_key_seen = tk.StringVar(value='No shortcut received yet')
        self.status = tk.StringVar(value='Ready - choose a capture area before monitoring.')
        self.update_status = tk.StringVar(value=updater.message if updater else '')
        self.access_status = tk.StringVar(value='Owner: ' + access_session.claims.get('name', 'Owner') if access_session and access_session.owner else 'Signed in as ' + access_session.claims.get('name', 'user') if access_session else 'Developer widget session')
        self.area_text = tk.StringVar(value=self.describe_area())
        self.point_text = [tk.StringVar(value=self.describe_point(i)) for i in range(2)]
        self.joiner_button_text = tk.StringVar()
        self.joiner_state = tk.StringVar(value='Stopped')
        self.monitor_button_text = tk.StringVar(value='Start monitoring')
        self.monitor_state = tk.StringVar(value='Monitoring is off')
        self.server_text = tk.StringVar(value='No confirmed server yet')
        self.raw_ocr_text = tk.StringVar(value='Raw OCR: no screen read yet')
        self.ping_banner = tk.StringVar(value='')
        self.interval_var = tk.StringVar(value=str(int(self.data['click_interval_ms'])))
        self.hold_var = tk.StringVar(value=str(int(self.data['click_hold_ms'])))
        self.rate_var = tk.StringVar(value=str(self.data['reads_per_second']))
        self.bind_vars = {key: tk.StringVar(value=display_hotkey(self.data[key])) for key in ('joiner_hotkey', 'ping_hotkey', 'combat_hotkey', 'esp_hotkey', 'active_panel_hotkey')}
        self.combat_button_text = tk.StringVar(value='Turn on Combat M1')
        self.combat_state = tk.StringVar(value='Off')
        self.combat_notice = tk.StringVar(value='Hold the left mouse button to click. It only works while Roblox is in front.')
        self.combat_key_seen = tk.StringVar(value='No shortcut received yet')
        self.parry_on_var = tk.BooleanVar(value=self.data['parry_bar_enabled'])
        self.parry_key_var = tk.StringVar(value=display_hotkey(self.data['parry_key']))
        self.parry_cooldown_var = tk.StringVar(value=str(self.data['parry_cooldown_ms']))
        self.parry_buffer_var = tk.StringVar(value=str(self.data['parry_buffer_ms']))
        self.parry_notice = tk.StringVar(value='Shows over Roblox. Full = you can parry.')
        self.parry_move_text = tk.StringVar(value='Move bar')
        self.fastest_var = tk.StringVar(value=str(self.data['combat_fastest_ms']))
        self.slowest_var = tk.StringVar(value=str(self.data['combat_slowest_ms']))
        self.active_panel = None
        self.panel_notice = tk.StringVar(value='Shows only active features and their saved shortcuts.')
        self.panel_button_text = tk.StringVar(value='Hide active features' if self.data['active_panel_enabled'] else 'Show active features')
        self.panel_move_text = tk.StringVar(value='Move panel')
        self.party_service = None
        self.party_notice = tk.StringVar(value='Select your life bar below Auto Gank Ping. Your HP is shared even with the overlay off.')
        self.fflag_summary = tk.StringVar(value='')
        self.fflag_notice = tk.StringVar(value='Changes apply the next time Roblox starts.')
        self.fflag_name_var, self.fflag_value_var = tk.StringVar(value=''), tk.StringVar(value='True')
        self.fflag_auto_var = tk.BooleanVar(value=self.data['fflags_auto_apply'])
        self.fflag_preset_vars, self.fflag_list, self.fflag_canvas, self.fflag_after = {}, None, None, None
        self.fflag_show, self.fflag_viewport = False, None
        self.fflag_toggle_text = tk.StringVar(value='Show flags')
        self.esp_move_text = tk.StringVar(value='Move overlay')
        self.esp_button_text = tk.StringVar(value='Hide ESP' if self.data['esp_enabled'] else 'Show ESP')
        self.life_area_text = tk.StringVar(value=self.describe_life_area())
        self.discord_owner = access_session is None or access_session.owner
        self._discord_busy = False
        self.webhook_text = tk.StringVar(value='Checking shared Discord connection...' if access_session else self.describe_webhook())
        legacy = logic.load_webhook(SECRETS) if self.discord_owner else ('', '', '')
        self.webhook_var = tk.StringVar(value=legacy[0] or '')
        self.mention_var = tk.StringVar(value=legacy[1])
        self.depths_mention_var = tk.StringVar(value=logic.load_depths_mention(SECRETS) if self.discord_owner else '')
        self.mention_loaded = self.mention_var.get()
        self.webhook_visible = False
        self.refresh_joiner_button()
        self.bind_pending = None
        self.action_buttons = {}
        self.build()
        setup_message = ensure_secrets(SECRETS) if access_session is None else None
        if setup_message:
            self.webhook_text.set(self.describe_webhook())
            self.after(200, (lambda: messagebox.showinfo('Discord webhook setup', setup_message, parent=self)))
        self.register_hotkeys()
        self.protocol('WM_DELETE_WINDOW', self.close)
        self.bind('<Control-Shift-F12>', self.run_diagnostics)
        self._initializing = False
        for variable in self.interval_var, self.hold_var, self.rate_var, *self.bind_vars.values():
            variable.trace_add('write', self.schedule_save)
        self.bind('<Configure>', self.window_changed, add='+')
        self.after(60, self.process_events)
        if access_session:
            self._discord_busy = True
            self.after(100, self.load_shared_discord)
            self.after(1000, self.check_access)
        if updater:
            self.after(1000, self.poll_updates)
        if self.data['capture_area']:
            if self.strict_reading or self.data['monitoring_enabled']:
                self.after(100, self.ensure_monitoring)
        if self.access_session is not None:
            self.after(250, self.start_health_sharing)
        if self.data['parry_bar_enabled'] and self.advanced_allowed():
            self.after(300, self.start_parry)
        if self.data['active_panel_enabled'] and self.advanced_allowed():
            self.after(350, self.start_active_panel)
        if self.data['fflags_auto_apply']:
            if self.data['fflags'] or self.data['fflags_applied']:
                self.after(500, self.fflags_startup_apply)

    def describe_area(self):
        area = self.data.get('capture_area')
        if area:
            return f'{area['width']} x {area['height']} px at ({area['x']}, {area['y']})'
        return 'No area selected'

    def describe_point(self, index):
        point = self.data['points'][index]
        if point:
            return f'Point {index + 1}: ' + f'({point['x']}, {point['y']})'
        return None + 'not set'

    def describe_webhook(self):
        url, mention, error = logic.load_webhook(SECRETS)
        if not url:
            return f'Discord: {error}'
        if mention:
            return 'Discord: webhook found. ' + f'Pings {mention}.'
        return None + 'No role to ping.'

    def hotkey_label(self, key):
        return self.data[key].upper()

    def refresh_joiner_button(self):
        verb = 'Stop' if self.joining else 'Start'
        self.joiner_button_text.set(f'{verb} Join Macro')
        if self.joining:
            self.joiner_state.set('Running - clicking both points')
            return
        None('Stopped')

    def collect_settings(self):
        self.data['click_interval_ms'] = int(logic.clamp(self.interval_var.get(), 10, 5000, self.data['click_interval_ms']))
        self.data['click_hold_ms'] = int(logic.clamp(self.hold_var.get(), 1, 40, self.data['click_hold_ms']))
        self.data['reads_per_second'] = logic.clamp(self.rate_var.get(), 1, 2, self.data['reads_per_second'])
        self.data['combat_fastest_ms'], self.data['combat_slowest_ms'] = logic.combat_range(self.fastest_var.get(), self.slowest_var.get())
        geometry = self.geometry()
        if logic.valid_geometry(geometry):
            self.data['window_geometry'] = geometry

    def schedule_save(self, *args):
        if self._initializing or self.closing:
            return
        if self._autosave_id is not None:
            self.after_cancel(self._autosave_id)
        self._autosave_id = self.after(400, self.flush_settings)

    def window_changed(self, event):
        if event.widget is self:
            self.schedule_save()

    def flush_settings(self, wait_bindings=False):
        if self._autosave_id is not None:
            self.after_cancel(self._autosave_id)
            self._autosave_id = None
        if not self.bind_pending:
            try:
                proposed = validate_bindings(*(self.bind_vars[key].get() for key in self.bind_vars))
                current = tuple((self.data[key] for key in self.bind_vars))
                if proposed != current:
                    self.save_bind(next((key for key, value in zip(self.bind_vars, proposed)
                         if value != self.data[key])))
            except ValueError as exc:
                self.status.set(f'Shortcut not saved: {exc}')
        if wait_bindings:
            deadline = time.monotonic() + 3
            while self.bind_pending:
                self.process_events()
                if not self.bind_pending or not self.hotkeys.thread or not self.hotkeys.thread.is_alive():
                    return self.save()
                if time.monotonic() >= deadline:
                    self.status.set('Shortcut change is still pending; previous saved keys are retained.')
                    return self.save()
                time.sleep(0.01)
        return self.save()

    def save(self):
        self.collect_settings()
        try:
            logic.save_settings(SETTINGS, self.data)
            return True
        except OSError as exc:
            logging.exception('Could not save settings')
            self.status.set(f'Could not save settings: {exc}')
            return False

    def card(self, parent):
        return ctk.CTkFrame(parent, fg_color=PANEL, bg_color=BG, corner_radius=16, border_width=1, border_color=BORDER)

    def button(self, parent, text=None, command=None, small=False, textvariable=None):
        initial = text or (textvariable.get() if textvariable is not None else '') or ' '
        return ctk.CTkButton(parent, text=initial, textvariable=textvariable, command=command, width=58 if small else 118, height=30 if small else 34, corner_radius=9, fg_color=BUTTON, hover_color='#4c306a', text_color=TEXT, font=('Segoe UI', 12, 'bold'))

    def label(self, parent, text=None, textvariable=None, fg=MUTED, size=9, bold=False, **kw):
        return tk.Label(parent, text=text, textvariable=textvariable, bg=PANEL, fg=fg, font=('Segoe UI', size, 'bold' if bold else 'normal'), wraplength=400, justify='left', anchor='w', **kw)

    def entry(self, parent, variable, command, width=7):
        box = ctk.CTkEntry(parent, textvariable=variable, width=width * 10, height=30, corner_radius=8, fg_color=BUTTON, text_color=TEXT, border_width=1, border_color=BORDER, font=('Segoe UI', 12))
        box.bind('<Return>', (lambda event: command()))
        box.bind('<FocusOut>', (lambda event: command()))
        return box

    def build(self):
        shell = tk.Frame(self, bg=BG)
        shell.pack(fill='both', expand=True)
        sidebar = tk.Frame(shell, bg=SIDEBAR, width=152, padx=12, pady=20)
        sidebar.pack(side='left', fill='y')
        sidebar.pack_propagate(False)
        from PIL import Image
        with Image.open(ASSETS / 'lomastrap.png') as source_logo:
            self.brand_image = ctk.CTkImage(dark_image=source_logo.copy(), size=(52, 52))
        ctk.CTkLabel(sidebar, text='', image=self.brand_image, fg_color=SIDEBAR).pack(anchor='w')
        tk.Label(sidebar, text='LOMASTRAP', bg=SIDEBAR, fg=TEXT, font=('Segoe UI', 10, 'bold')).pack(anchor='w', pady=(12, 3))
        tk.Label(sidebar, text='Server toolkit', bg=SIDEBAR, fg=MUTED, font=('Segoe UI', 9)).pack(anchor='w', pady=(0, 22))
        tk.Label(sidebar, text='WORKSPACE', bg=SIDEBAR, fg=PURPLE, font=('Segoe UI', 8, 'bold')).pack(anchor='w', pady=(0, 12))
        main = tk.Frame(shell, bg=BG, padx=18, pady=18)
        main.pack(side='left', fill='both', expand=True)
        self.page_title = tk.StringVar(value='Join Macro')
        tk.Label(main, textvariable=self.page_title, bg=BG, fg=TEXT, font=('Segoe UI', 20, 'bold'), anchor='w').pack(fill='x')
        tk.Label(main, text='Ready when you are.', bg=BG, fg=MUTED, font=('Segoe UI', 10), anchor='w').pack(fill='x', pady=(4, 10))
        tk.Label(main, textvariable=self.hotkey_status, bg=BG, fg=PURPLE, wraplength=430, justify='left', anchor='w', font=('Segoe UI', 8)).pack(fill='x', pady=(0, 14))
        viewport = tk.Frame(main, bg=BG)
        viewport.pack(fill='both', expand=True)
        self.content_canvas = tk.Canvas(viewport, bg=BG, highlightthickness=0)
        scroll = ctk.CTkScrollbar(viewport, orientation='vertical', command=self.content_canvas.yview, fg_color=BG, button_color=BORDER, button_hover_color=PURPLE, width=10, corner_radius=5)
        scroll.pack(side='right', fill='y', padx=(8, 0))
        self.content_canvas.pack(side='left', fill='both', expand=True)
        self.content_canvas.configure(yscrollcommand=scroll.set)
        content = tk.Frame(self.content_canvas, bg=BG)
        item = self.content_canvas.create_window((0, 0), window=content, anchor='nw')
        content.bind('<Configure>', (lambda event: self.content_canvas.configure(scrollregion=self.content_canvas.bbox('all'))))
        self.content_canvas.bind('<Configure>', (lambda event: self.content_canvas.itemconfigure(item, width=event.width)))
        self.bind_all('<MouseWheel>', self.scroll_content)
        self.pages = {'Settings': self.settings(content), 'Join Macro': self.joiner(content), 'Auto Gank Ping': self.ping(content)}
        if self.advanced_allowed():
            self.pages.update({'Combat': self.combat(content), 'Visuals': self.visuals(content)})
        self.menu_buttons = {}
        for name in self.pages:
            button = self.button(sidebar, name, (lambda page=name: self.show_page(page)))
            button.configure(anchor='w', height=36)
            button.pack(fill='x', pady=(0, 9))
            self.menu_buttons[name] = button
        if self.access_session and self.access_session.owner:
            self.button(sidebar, 'Owner controls', self.open_owner).pack(fill='x', pady=(20, 8))
        if self.access_session:
            self.logout_button = self.button(sidebar, 'Log out', self.logout, True)
            self.logout_button.pack(fill='x', pady=(8, 8))
        tk.Label(sidebar, textvariable=self.access_status, bg=SIDEBAR, fg=MUTED, wraplength=124, justify='left', font=('Segoe UI', 8)).pack(side='bottom', anchor='w', pady=(8, 8))
        tk.Label(sidebar, text='LOMASTRAP  v0.8.9', bg=SIDEBAR, fg=MUTED, font=('Segoe UI', 8)).pack(side='bottom', anchor='w')
        tk.Label(main, textvariable=self.update_status, bg=BG, fg=PURPLE, wraplength=430, justify='left', font=('Segoe UI', 8)).pack(side='bottom', fill='x')
        self.show_page(self.data['last_page'])
        tk.Frame(main, bg=BORDER, height=1).pack(fill='x', pady=(16, 10))
        tk.Label(main, textvariable=self.status, bg=BG, fg=MUTED, font=('Segoe UI', 9), wraplength=430, justify='left', anchor='w').pack(fill='x')

    def poll_updates(self):
        if not self.closing:
            if self.updater:
                self.update_status.set(self.updater.message)
                self.after(1000, self.poll_updates)

    def scroll_content(self, event):
        if event.widget.winfo_class() == 'Text':
            return
        target = self.fflag_canvas if self.wheel_over_fflags(event) else self.content_canvas
        target.yview_scroll(-int(event.delta / 120), 'units')

    def wheel_over_fflags(self, event):
        '''True when the mouse is over a flag list long enough to scroll on its own.'''

        if not self.fflag_show or self.fflag_viewport is None or self.fflag_canvas is None:
            return False
        try:
            return str(event.widget).startswith(str(self.fflag_viewport)) and self.fflag_list.winfo_reqheight() > self.fflag_canvas.winfo_height()
        except Exception:
            return False

    def show_page(self, selected):
        if selected not in self.pages:
            selected = 'Join Macro'
        self.webhook_visible = False
        if self.discord_owner:
            self.webhook_entry.configure(show='*')
            self.webhook_reveal.configure(text='Show')
        for name, page in self.pages.items():
            page.pack_forget()
            self.menu_buttons[name].configure(fg_color=PRIMARY if name == selected else SIDEBAR, text_color=TEXT if name == selected else MUTED)
        self.page_title.set(selected)
        self.pages[selected].pack(fill='both', expand=True)
        self.content_canvas.yview_moveto(0)
        self.data['last_page'] = selected
        if not self._initializing:
            self.flush_settings()

    def status_card(self, parent):
        box = self.card(parent)
        box.pack(fill='x')
        box.grid_columnconfigure(1, weight=1)
        tk.Label(box, text='●', bg=PANEL, fg=GREEN, font=('Segoe UI', 17)).grid(row=0, column=0, rowspan=2, padx=(18, 11), pady=14)
        tk.Label(box, text='Capture area', bg=PANEL, fg=TEXT, font=('Segoe UI', 11, 'bold')).grid(row=0, column=1, sticky='sw', pady=(13, 0))
        tk.Label(box, textvariable=self.area_text, bg=PANEL, fg=MUTED, font=('Segoe UI', 9)).grid(row=1, column=1, sticky='nw', pady=(1, 14))
        self.button(box, 'Set up area', self.pick_area, True).grid(row=0, column=2, rowspan=2, padx=18, pady=16)

    def label_row(self, box, title, number):
        row = tk.Frame(box, bg=PANEL)
        row.pack(fill='x', padx=20, pady=(20, 0))
        tk.Label(row, text=title, bg=PANEL, fg=TEXT, font=('Segoe UI', 12, 'bold')).pack(side='left')
        tk.Label(row, text=number, bg=PANEL, fg=PURPLE, font=('Segoe UI', 9, 'bold')).pack(side='right')

    def settings(self, parent):
        page = tk.Frame(parent, bg=BG)
        box = self.card(page)
        box.pack(fill='x')
        self.label_row(box, 'Fast Flags', '00')
        self.label(box, 'Fast Flags are hidden Roblox engine options. Roblox only honours flags on its official allowlist and silently ignores the rest. Roblox also clears them on every update, so Lomastrap can re-apply yours when it starts.').pack(anchor='w', padx=20, pady=(12, 8))
        self.label(box, textvariable=self.fflag_summary, fg=GREEN, size=9).pack(anchor='w', padx=20, pady=(0, 10))
        self.label(box, 'Presets', fg=PURPLE, size=8, bold=True).pack(anchor='w', padx=20, pady=(0, 6))
        for preset in fflags.PRESETS:
            row = tk.Frame(box, bg=PANEL)
            row.pack(fill='x', padx=20, pady=(0, 2))
            self.label(row, preset['title'], fg=TEXT).pack(side='left')
            variable = tk.BooleanVar(value=fflags.preset_active(preset, self.data['fflags']))
            self.fflag_preset_vars[preset['id']] = variable
            ctk.CTkSwitch(row, text='', variable=variable, progress_color=PRIMARY, width=46, command=(lambda key=preset['id']: self.toggle_fflag_preset(key))).pack(side='right')
            self.label(box, preset['help'], size=8).pack(anchor='w', padx=20, pady=(0, 8))
            continue
        head = tk.Frame(box, bg=PANEL)
        head.pack(fill='x', padx=20, pady=(6, 6))
        self.label(head, 'Your flags', fg=PURPLE, size=8, bold=True).pack(side='left')
        self.button(head, textvariable=self.fflag_toggle_text, command=self.toggle_fflag_list).pack(side='right')
        self.button(head, 'Remove ignored', self.remove_ignored_fflags).pack(side='right', padx=8)
        self.fflag_viewport = tk.Frame(box, bg=PANEL)
        self.fflag_canvas = tk.Canvas(self.fflag_viewport, bg=PANEL, highlightthickness=0, height=200)
        flag_scroll = ctk.CTkScrollbar(self.fflag_viewport, orientation='vertical', command=self.fflag_canvas.yview, fg_color=PANEL, button_color=BORDER, button_hover_color=PURPLE, width=10, corner_radius=5)
        flag_scroll.pack(side='right', fill='y', padx=(8, 0))
        self.fflag_canvas.pack(side='left', fill='both', expand=True)
        self.fflag_canvas.configure(yscrollcommand=flag_scroll.set)
        self.fflag_list = tk.Frame(self.fflag_canvas, bg=PANEL)
        flag_item = self.fflag_canvas.create_window((0, 0), window=self.fflag_list, anchor='nw')
        self.fflag_list.bind('<Configure>', (lambda event: self.fflag_canvas.configure(scrollregion=self.fflag_canvas.bbox('all'))))
        self.fflag_canvas.bind('<Configure>', (lambda event: self.fflag_canvas.itemconfigure(flag_item, width=event.width)))
        self.fflag_after = row = tk.Frame(box, bg=PANEL)
        row.pack(fill='x', padx=20, pady=(0, 8))
        name_box = ctk.CTkEntry(row, textvariable=self.fflag_name_var, placeholder_text='Flag name', height=30, corner_radius=8, fg_color=BUTTON, text_color=TEXT, border_width=1, border_color=BORDER, font=('Segoe UI', 12))
        name_box.pack(side='left', fill='x', expand=True)
        value_box = ctk.CTkEntry(row, textvariable=self.fflag_value_var, width=80, height=30, corner_radius=8, fg_color=BUTTON, text_color=TEXT, border_width=1, border_color=BORDER, font=('Segoe UI', 12))
        value_box.pack(side='left', padx=8)
        for widget in name_box, value_box:
            widget.bind('<Return>', (lambda event: self.add_fflag()))
        self.button(row, 'Add / update', self.add_fflag, True).pack(side='right')
        self.label(box, 'Import / export JSON', fg=PURPLE, size=8, bold=True).pack(anchor='w', padx=20, pady=(8, 6))
        self.fflag_json_box = ctk.CTkTextbox(box, height=84, corner_radius=9, fg_color=BUTTON, text_color=TEXT, wrap='word', font=('Consolas', 11))
        self.fflag_json_box.pack(fill='x', padx=20, pady=(0, 8))
        row = tk.Frame(box, bg=PANEL)
        row.pack(fill='x', padx=20, pady=(0, 8))
        self.button(row, 'Import from box', self.import_fflags).pack(side='left')
        self.button(row, 'Export to box', self.export_fflags).pack(side='left', padx=8)
        row = tk.Frame(box, bg=PANEL)
        row.pack(fill='x', padx=20, pady=(6, 8))
        self.label(row, 'Re-apply when Lomastrap starts', fg=TEXT).pack(side='left')
        ctk.CTkSwitch(row, text='', variable=self.fflag_auto_var, progress_color=PRIMARY, width=46, command=self.set_fflag_auto).pack(side='right')
        row = tk.Frame(box, bg=PANEL)
        row.pack(fill='x', padx=20, pady=(4, 8))
        self.button(row, 'Apply to Roblox', self.apply_fflags).pack(side='left')
        self.button(row, 'Remove my flags', self.remove_applied_fflags).pack(side='left', padx=8)
        self.button(row, 'Restore original', self.restore_fflag_backup).pack(side='left')
        self.label(box, textvariable=self.fflag_notice, fg=WARNING).pack(anchor='w', padx=20, pady=(2, 16))
        self.refresh_fflags_ui()
        return page

    def fflag_allowlist(self):
        return fflags.load_allowlist(APP_DIR / fflags.ALLOWLIST_FILE)

    def refresh_fflags_ui(self):
        flags, allowlist = self.data['fflags'], self.fflag_allowlist()
        self.fflag_summary.set(fflags.summary(flags, allowlist))
        for preset in fflags.PRESETS:
            variable = self.fflag_preset_vars.get(preset['id'])
            if variable is not None:
                variable.set(fflags.preset_active(preset, flags))
        self.fflag_toggle_text.set('Hide flags' if self.fflag_show else f'Show flags ({len(flags)})')
        if self.fflag_list is None:
            return
        for child in list(self.fflag_list.winfo_children()):
            child.destroy()
        if not self.fflag_show or not flags:
            self.fflag_viewport.pack_forget()
            return
        self.fflag_viewport.pack(fill='x', padx=20, pady=(0, 8), before=self.fflag_after)
        for name in sorted(flags, key=(lambda key: (not fflags.is_allowed(key, allowlist), key))):
            allowed = fflags.is_allowed(name, allowlist)
            row = tk.Frame(self.fflag_list, bg=PANEL)
            row.pack(fill='x', pady=1)
            self.label(row, f'{name} = {flags[name]}', fg=TEXT if allowed else MUTED, size=9).pack(side='left')
            self.button(row, 'Remove', (lambda key=name: self.remove_fflag(key)), True).pack(side='right')
            self.label(row, 'active' if allowed else 'ignored by Roblox', fg=GREEN if allowed else WARNING, size=8).pack(side='right', padx=8)
        self.fflag_canvas.yview_moveto(0)

    def toggle_fflag_list(self):
        self.fflag_show = not self.fflag_show
        self.refresh_fflags_ui()

    def remove_ignored_fflags(self):
        _active, ignored = fflags.split_by_allowlist(self.data['fflags'], self.fflag_allowlist())
        if not ignored:
            self.fflag_notice.set('No ignored flags. Every flag in your list is one Roblox uses.')
            return
        if not messagebox.askyesno('Remove ignored flags', f'Remove {len(ignored)} flag(s) that Roblox ignores?\n\nThey do nothing in Roblox. To keep a copy, press Export to box first.', parent=self):
            return
        for name in ignored:
            self.data['fflags'].pop(name, None)
        self.fflags_changed(f'Removed {len(ignored)} ignored flag(s).')

    def fflags_changed(self, message):
        self.refresh_fflags_ui()
        self.fflag_notice.set(message + ' Press Apply to Roblox to write it.')
        self.flush_settings()

    def add_fflag(self):
        try:
            name, value = fflags.check_pair(self.fflag_name_var.get(), self.fflag_value_var.get())
        except fflags.FlagError as exc:
            self.fflag_notice.set(str(exc))
        if name not in self.data['fflags'] and len(self.data['fflags']) >= fflags.MAX_FLAGS:
            self.fflag_notice.set(f'You can keep up to {fflags.MAX_FLAGS} flags.')
            return
        self.data['fflags'][name] = value
        self.fflag_name_var.set('')
        self.fflags_changed(f'Saved {name}.')

    def remove_fflag(self, name):
        if self.data['fflags'].pop(name, None) is not None:
            self.fflags_changed(f'Removed {name}.')

    def toggle_fflag_preset(self, preset_id):
        enabled = bool(self.fflag_preset_vars[preset_id].get())
        self.data['fflags'] = fflags.set_preset(self.data['fflags'], preset_id, enabled)
        if enabled:
            self.fflags_changed('Preset on.')
            return
        None('Preset off.')

    def import_fflags(self):
        try:
            imported, problems = fflags.parse_import(self.fflag_json_box.get('1.0', 'end'))
        except fflags.FlagError as exc:
            self.fflag_notice.set(str(exc))
        merged = dict(self.data['fflags'])
        merged.update(imported)
        if len(merged) > fflags.MAX_FLAGS:
            self.fflag_notice.set(f'That would pass the limit of {fflags.MAX_FLAGS} flags; nothing was imported.')
            return
        self.data['fflags'] = merged
        note = f'Imported {len(imported)} flag(s).'
        if problems:
            note += f' Skipped {len(problems)}: {problems[0]}'
        self.fflags_changed(note)

    def export_fflags(self):
        self.fflag_json_box.delete('1.0', 'end')
        self.fflag_json_box.insert('1.0', fflags.export_json(self.data['fflags']))
        self.fflag_notice.set('Your flags are in the box above. Copy them to share or back up.')

    def set_fflag_auto(self):
        self.data['fflags_auto_apply'] = bool(self.fflag_auto_var.get())
        self.flush_settings()

    def apply_fflags(self, quiet=False):
        try:
            version, managed = fflags.apply_to_latest(self.data['fflags'], self.data['fflags_applied'])
        except fflags.FlagError as exc:
            if not quiet:
                self.fflag_notice.set(str(exc))
            return False
        except OSError as exc:
            logging.exception('Could not write Roblox fast flags')
            self.fflag_notice.set(f"Could not write Roblox's settings file: {exc}")
            return False
        self.data['fflags_applied'] = managed
        self.flush_settings()
        _active, ignored = fflags.split_by_allowlist(self.data['fflags'], self.fflag_allowlist())
        text = f'Wrote {len(managed)} flag(s) for {version.name}. Restart Roblox to use them.'
        if ignored:
            text += f" {len(ignored)} are not on Roblox's allowlist and will be ignored."
        if managed:
            self.fflag_notice.set(text)
            return True
        None("Removed Lomastrap's flags. Restart Roblox.")
        return True

    def fflags_startup_apply(self):
        if not self.closing:
            self.apply_fflags(quiet=True)

    def remove_applied_fflags(self):
        versions = fflags.find_version_dirs()
        if not versions:
            self.fflag_notice.set('Roblox was not found, so there is nothing to remove.')
            return
        try:
            for version in versions:
                fflags.remove_flags(version, self.data['fflags_applied'])
        except (fflags.FlagError, OSError) as exc:
            self.fflag_notice.set(f'Could not remove the flags: {exc}')
        self.data['fflags_applied'] = []
        self.flush_settings()
        self.fflag_notice.set('Removed the flags Lomastrap wrote. Your list here is kept. Restart Roblox.')

    def restore_fflag_backup(self):
        versions = fflags.find_version_dirs()
        try:
            pass
        except OSError as exc:
            self.fflag_notice.set(f'Could not restore the original file: {exc}')
        try:
            restored = [v for v in versions if fflags.restore_backup(v)]
        except OSError as exc:
            self.fflag_notice.set(f'Could not restore the original file: {exc}')
        if restored:
            self.data['fflags_applied'] = []
            self.flush_settings()
        if restored:
            self.fflag_notice.set('Restored the original ClientAppSettings.json. Restart Roblox.')
            return
        None('There is no saved original to restore.')

    def combat(self, parent):
        page = tk.Frame(parent, bg=BG)
        box = self.card(page)
        box.pack(fill='x')
        self.label_row(box, 'Combat', '03')
        self.label(box, 'Fast M1 clicker. Turn it on, then HOLD the left mouse button: it clicks fast while you hold and stops when you let go. Every click has slightly different timing. One key turns it on and off.').pack(anchor='w', padx=20, pady=(12, 14))
        row = tk.Frame(box, bg=PANEL)
        row.pack(fill='x', padx=20, pady=(0, 8))
        self.label(row, 'Fastest gap between clicks (ms)', fg=TEXT).pack(side='left')
        self.entry(row, self.fastest_var, self.apply_combat_speed).pack(side='right')
        row = tk.Frame(box, bg=PANEL)
        row.pack(fill='x', padx=20, pady=(0, 12))
        self.label(row, 'Slowest gap between clicks (ms)', fg=TEXT).pack(side='left')
        self.entry(row, self.slowest_var, self.apply_combat_speed).pack(side='right')
        self.action_row(box, self.combat_button_text, self.toggle_combat, 'combat_hotkey')
        self.label(box, textvariable=self.combat_key_seen, fg=PURPLE, size=8).pack(anchor='w', padx=20, pady=(4, 2))
        self.combat_notice_label = self.label(box, textvariable=self.combat_notice, fg=WARNING)
        self.combat_notice_label.pack(anchor='w', padx=20, pady=(3, 6))
        self.label(box, textvariable=self.combat_state, fg=GREEN).pack(anchor='w', padx=20, pady=(10, 14))
        return page

    def advanced_allowed(self):
        session = self.access_session
        return session is None or bool(session.valid() and (session.owner or session.claims.get('tier') == 'trusted'))

    def visuals(self, parent):
        page = tk.Frame(parent, bg=BG)
        self.parry_card(page)
        self.active_panel_card(page)
        box = self.card(page)
        box.pack(fill='x', pady=(14, 0))
        self.label_row(box, 'Shared Party ESP', '03')
        self.label(box, 'Shows login names and HP of other Lomastrap users in your confirmed server. Discord is not required. Tabbing out pauses reading and keeps your last HP visible for up to 30 seconds. It disappears after 30 seconds until you return. Your HP is shared while the overlay is off.').pack(anchor='w', padx=20, pady=12)
        self.action_row(box, self.esp_button_text, self.toggle_esp, 'esp_hotkey')
        row = tk.Frame(box, bg=PANEL)
        row.pack(fill='x', padx=20, pady=(0, 4))
        self.button(row, textvariable=self.esp_move_text, command=self.toggle_esp_move).pack(side='left')
        self.button(row, 'Reset position', self.reset_esp_position).pack(side='left', padx=8)
        row = tk.Frame(box, bg=PANEL)
        row.pack(fill='x', padx=20, pady=(10, 4))
        self.esp_scale_text = tk.StringVar(value=f'ESP size: {round(self.data['esp_scale'] * 100)}%')
        self.label(row, textvariable=self.esp_scale_text, fg=TEXT).pack(side='left')
        self.esp_scale_slider = ctk.CTkSlider(row, from_=0.5, to=2.0, number_of_steps=30, command=self.resize_esp, progress_color=PRIMARY, button_color=PRIMARY, width=180)
        self.esp_scale_slider.set(self.data['esp_scale'])
        self.esp_scale_slider.pack(side='right', padx=(12, 0))
        self.label(box, 'Resizes every player together. Position and size are saved automatically.').pack(anchor='w', padx=20, pady=(4, 0))
        self.label(box, textvariable=self.party_notice, fg=WARNING, size=9).pack(anchor='w', padx=20, pady=12)
        return page

    def active_panel_card(self, page):
        box = self.card(page)
        box.pack(fill='x', pady=(14, 0))
        self.label_row(box, 'Active features panel', '02')
        self.label(box, 'Only active features are listed, with their current saved shortcut. The ping shortcut sends a ping; it does not toggle monitoring.').pack(anchor='w', padx=20, pady=12)
        self.action_row(box, self.panel_button_text, self.toggle_active_panel, 'active_panel_hotkey')
        row = tk.Frame(box, bg=PANEL)
        row.pack(fill='x', padx=20, pady=4)
        self.button(row, textvariable=self.panel_move_text, command=self.move_active_panel).pack(side='left')
        self.button(row, 'Reset position', self.reset_active_panel).pack(side='left', padx=8)
        row = tk.Frame(box, bg=PANEL)
        row.pack(fill='x', padx=20, pady=8)
        self.panel_size_text = tk.StringVar(value=f'Panel size: {round(self.data['active_panel_scale'] * 100)}%')
        self.label(row, textvariable=self.panel_size_text, fg=TEXT).pack(side='left')
        self.panel_slider = ctk.CTkSlider(row, from_=0.5, to=2.0, number_of_steps=30, command=self.resize_active_panel, progress_color=PRIMARY, button_color=PRIMARY, width=180)
        self.panel_slider.set(self.data['active_panel_scale'])
        self.panel_slider.pack(side='right')
        self.label(box, textvariable=self.panel_notice, fg=WARNING).pack(anchor='w', padx=20, pady=(4, 12))

    def start_active_panel(self):
        if self.closing or not self.advanced_allowed() or not self.data['active_panel_enabled']:
            return
        from lomastrap_active_panel import ActiveFeaturePanel, active_features
        if self.active_panel is None:
            self.active_panel = ActiveFeaturePanel((lambda: active_features(self)), self.active_panel_moved, self.active_panel_failed, position=(self.data['active_panel_x'], self.data['active_panel_y']), scale=self.data['active_panel_scale'], allowed=self.advanced_allowed)
        try:
            self.active_panel.start(self)
            return
        except Exception as exc:
            self.active_panel_failed('Active features panel unavailable: ' + str(exc))

    def active_panel_failed(self, text):
        if self.active_panel is not None:
            self.active_panel.stop()
        self.data['active_panel_enabled'] = False
        self.panel_button_text.set('Show active features')
        self.panel_move_text.set('Move panel')
        self.panel_notice.set(text)
        self.schedule_save()

    def toggle_active_panel(self):
        if not self.advanced_allowed():
            self.panel_notice.set('Trusted member or owner access required.')
            return
        self.data['active_panel_enabled'] = not self.data['active_panel_enabled']
        if self.data['active_panel_enabled']:
            self.start_active_panel()
        elif self.active_panel is not None:
            self.active_panel.stop()
        self.panel_button_text.set('Hide active features' if self.data['active_panel_enabled'] else 'Show active features')
        self.panel_move_text.set('Move panel')
        self.save()

    def move_active_panel(self):
        if self.active_panel is None or not self.data['active_panel_enabled']:
            self.panel_notice.set('Show active features first, then move the panel.')
            return
        if self.active_panel.moving:
            self.active_panel.end_move()
            self.panel_move_text.set('Move panel')
            self.panel_notice.set('Panel position saved.')
            return
        self.active_panel.begin_move()
        self.panel_move_text.set('Done moving')
        self.panel_notice.set('Drag the whole panel, then press Done moving.')

    def active_panel_moved(self, x, y):
        self.data['active_panel_x'] = x
        self.data['active_panel_y'] = y
        self.save()

    def resize_active_panel(self, value):
        scale = float(logic.clamp(value, 0.5, 2.0, 1.0))
        self.data['active_panel_scale'] = scale
        self.panel_size_text.set(f'Panel size: {round(scale * 100)}%')
        if self.active_panel is not None:
            self.active_panel.set_scale(scale)
        self.schedule_save()

    def reset_active_panel(self):
        for key in ('active_panel_x', 'active_panel_y'):
            self.data[key] = logic.DEFAULT_SETTINGS[key]
        if self.active_panel is not None:
            self.active_panel.config.fraction_x = self.data['active_panel_x']
            self.active_panel.config.fraction_y = self.data['active_panel_y']
            self.active_panel._position = None
        self.save()
        self.panel_notice.set('Panel moved back to the default spot.')

    def describe_life_area(self):
        area = self.data.get('life_capture_area')
        if area:
            return f'Life bar: {area['width']} x {area['height']} px at ({area['x']}, {area['y']})'
        return 'Life bar: choose your capture area once; it is saved.'

    def party_owner_allowed(self):
        return self.advanced_allowed() and self.access_session is not None

    def start_health_sharing(self):
        if self.closing or self.access_session is None or not self.access_session.valid():
            return
        if self.party_service is None:
            from party_esp.shared import SharedHealthService
            from party_esp.roi_capture import Win32RegionCapture
            from party_esp.reader import HealthReaderConfig
            self.party_service = SharedHealthService(self, self.access_session, self.health_snapshot, Win32RegionCapture(desktop_bounds), (lambda: game_usable(self.data.get('life_capture_area'))), self.party_owner_allowed, self.party_notice.set, position=(self.data['esp_x'], self.data['esp_y']), on_moved=self.esp_moved, scale=self.data['esp_scale'], settings=HealthReaderConfig.from_mapping(self.data.get('health_reader')), focused=game_active, server_fresh=self.health_server_fresh)
        self.party_service.start()
        if self.data['esp_enabled']:
            if self.advanced_allowed():
                self.party_service.set_enabled(True)

    def health_server_fresh(self):
        with self.lock:
            return bool(self.strict_reading and (self.confirmer.eligible() or self.confirmer.cached_eligible()))

    def health_snapshot(self):
        with self.lock:
            valid = self.strict_reading and self.confirmer.display_eligible()
            reading = self.confirmer.confirmed if valid else None
            area = self.data.get('life_capture_area')
        return reading, dict(area) if area else None

    def toggle_esp_move(self):
        service = self.party_service
        if service is None or not self.data['esp_enabled']:
            self.party_notice.set('Turn the ESP on first (Show ESP), then move it.')
            return
        if service.moving():
            service.end_move()
            self.esp_move_text.set('Move overlay')
            self.party_notice.set('ESP position saved.')
            return
        if service.begin_move():
            self.esp_move_text.set('Done moving')
            self.party_notice.set('Drag the ESP where you want it, then press Done moving.')
            return
        self.party_notice.set('Trusted member or owner access required.')

    def resize_esp(self, value):
        scale = float(logic.clamp(value, 0.5, 2.0, 1.0))
        self.data['esp_scale'] = scale
        self.esp_scale_text.set(f'ESP size: {round(scale * 100)}%')
        if self.party_service is not None:
            self.party_service.overlay.set_scale(scale)
        self.schedule_save()

    def esp_moved(self, fraction_x, fraction_y):
        self.data['esp_x'] = fraction_x
        self.data['esp_y'] = fraction_y
        self.save()

    def reset_esp_position(self):
        self.data['esp_x'] = logic.DEFAULT_SETTINGS['esp_x']
        self.data['esp_y'] = logic.DEFAULT_SETTINGS['esp_y']
        self.save()
        if self.party_service is not None:
            self.party_service.reset_position()
        self.party_notice.set('ESP moved back to the default spot.')

    def toggle_esp(self):
        if not self.advanced_allowed():
            self.party_notice.set('Trusted member or owner access required.')
            return
        enabled = not self.data['esp_enabled']
        if self.party_service is None:
            self.start_health_sharing()
        if self.party_service is not None:
            self.party_service.set_enabled(enabled)
        self.data['esp_enabled'] = enabled
        self.esp_button_text.set('Hide ESP' if enabled else 'Show ESP')
        if not enabled:
            self.esp_move_text.set('Move overlay')
        self.save()

    def ensure_monitoring(self):
        if not self.closing:
            if self.data.get('capture_area'):
                if not self.monitoring:
                    self.toggle_monitor()

    def store_life_area(self, area):
        with self.lock:
            self.data['life_capture_area'] = area
        self.life_area_text.set(self.describe_life_area())
        self.save()
        self.status.set('Life bar area saved. HP sharing starts automatically in a confirmed server.')
        if self.access_session is not None:
            if self.party_service is None:
                self.start_health_sharing()

    def parry_card(self, page):
        box = self.card(page)
        box.pack(fill='x', pady=(14, 0))
        self.label_row(box, 'Parry bar', '01')
        self.label(box, 'A small bar over Roblox. Full means you can parry. When you press your parry key it empties and refills over the cooldown. It cannot tell if a parry hit, so it always assumes a miss.').pack(anchor='w', padx=20, pady=(12, 10))
        row = tk.Frame(box, bg=PANEL)
        row.pack(fill='x', padx=20, pady=(0, 8))
        self.label(row, 'Show the parry bar', fg=TEXT).pack(side='left')
        ctk.CTkSwitch(row, text='', variable=self.parry_on_var, command=self.apply_parry, progress_color=PRIMARY, width=46).pack(side='right')
        for text, variable in ('Parry key', self.parry_key_var), ('Cooldown (ms)', self.parry_cooldown_var), ('Extra buffer (ms)', self.parry_buffer_var):
            row = tk.Frame(box, bg=PANEL)
            row.pack(fill='x', padx=20, pady=(0, 8))
            self.label(row, text, fg=TEXT).pack(side='left')
            self.entry(row, variable, self.apply_parry).pack(side='right')
        row = tk.Frame(box, bg=PANEL)
        row.pack(fill='x', padx=20, pady=(4, 8))
        self.button(row, textvariable=self.parry_move_text, command=self.toggle_parry_move).pack(side='left')
        self.button(row, 'Reset position', self.reset_parry_position).pack(side='left', padx=8)
        self.parry_notice_label = self.label(box, textvariable=self.parry_notice, fg=WARNING)
        self.parry_notice_label.pack(anchor='w', padx=20, pady=(2, 14))

    def joiner(self, parent):
        box = self.card(parent)
        self.label_row(box, 'Join Macro', '01')
        self.label(box, 'Clicks your two saved points back and forth. One key starts and stops it.').pack(anchor='w', padx=20, pady=(12, 14))
        for index in range(2):
            row = tk.Frame(box, bg=PANEL)
            row.pack(fill='x', padx=20, pady=(0, 8))
            self.label(row, textvariable=self.point_text[index], fg=TEXT).pack(side='left')
            self.button(row, 'Set point', (lambda i=index: self.pick_point(i)), True).pack(side='right')
        row = tk.Frame(box, bg=PANEL)
        row.pack(fill='x', padx=20, pady=(6, 12))
        self.label(row, 'Click delay (ms)', fg=TEXT).pack(side='left')
        self.entry(row, self.interval_var, self.apply_interval).pack(side='right')
        row = tk.Frame(box, bg=PANEL)
        row.pack(fill='x', padx=20, pady=(0, 12))
        self.label(row, 'Click hold (ms)', fg=TEXT).pack(side='left')
        self.entry(row, self.hold_var, self.flush_settings).pack(side='right')
        self.action_row(box, self.joiner_button_text, self.toggle_joiner, 'joiner_hotkey')
        self.label(box, textvariable=self.joiner_key_seen, fg=PURPLE, size=8).pack(anchor='w', padx=20, pady=(4, 2))
        self.joiner_notice_label = self.label(box, textvariable=self.joiner_notice, fg=WARNING)
        self.joiner_notice_label.pack(anchor='w', padx=20, pady=(3, 6))
        self.label(box, textvariable=self.joiner_state, fg=GREEN).pack(anchor='w', padx=20, pady=(10, 4))
        self.label(box, 'Press the same key again to stop. Click timing updates automatically.', fg=WARNING, size=8).pack(anchor='w', padx=20, pady=(4, 20))
        return box

    def ping(self, parent):
        box = self.card(parent)
        self.label_row(box, 'Auto Gank Ping', '02')
        self.label(box, textvariable=self.area_text).pack(anchor='w', padx=20, pady=(8, 0))
        self.label(box, 'Watches the capture area for the server name. The keybind below sends a Discord ping.').pack(anchor='w', padx=20, pady=(12, 12))
        self.button(box, 'Choose capture area [Server Name]', self.pick_area).pack(fill='x', padx=20)
        self.button(box, 'Choose capture area [Life bar]', (lambda: self.pick_area('life'))).pack(fill='x', padx=20, pady=(8, 0))
        self.label(box, textvariable=self.life_area_text, size=9).pack(anchor='w', padx=20, pady=6)
        self.label(box, textvariable=self.party_notice, size=9, fg=WARNING).pack(anchor='w', padx=20, pady=6)
        self.action_row(box, tk.StringVar(value='Send Gank Ping'), (lambda: threading.Thread(target=self.do_ping, daemon=True).start()), 'ping_hotkey')
        self.label(box, 'Monitoring is automatic: one read per second.', size=9).pack(anchor='w', padx=20, pady=6)
        self.label(box, textvariable=self.ping_key_seen, fg=PURPLE, size=8).pack(anchor='w', padx=20, pady=(4, 2))
        self.ping_notice_label = self.label(box, textvariable=self.ping_notice, fg=WARNING)
        self.ping_notice_label.pack(anchor='w', padx=20, pady=(3, 6))
        self.label(box, textvariable=self.server_text, fg=TEXT, size=10, bold=True).pack(anchor='w', padx=20)
        self.label(box, textvariable=self.monitor_state).pack(anchor='w', padx=20, pady=(2, 10))
        self.label(box, 'Raw OCR (latest read; scroll to inspect)', fg=WARNING, size=8).pack(anchor='w', padx=20)
        self.raw_ocr_box = ctk.CTkTextbox(box, height=64, corner_radius=9, fg_color=BUTTON, text_color=TEXT, wrap='word', font=('Segoe UI', 12))
        self.raw_ocr_box.pack(fill='x', padx=20, pady=(3, 8))
        self.raw_ocr_box.insert('1.0', self.raw_ocr_text.get())
        self.raw_ocr_box.configure(state='disabled')
        row = tk.Frame(box, bg=PANEL)
        row.pack(fill='x', padx=20, pady=(0, 8))
        if not self.strict_reading:
            self.label(row, 'Search reads/second (confirmed: once/minute)' if self.strict_reading else 'Reads per second (1–2)', fg=TEXT).pack(side='left')
            self.entry(row, self.rate_var, self.apply_read_rate).pack(side='right')
        self.label(box, 'Gank Ping cooldown: ' + self.cooldown_description(), fg=WARNING).pack(anchor='w', padx=20, pady=(0, 8))
        self.label(box, textvariable=self.ping_banner, fg=GREEN, size=12, bold=True).pack(anchor='w', padx=20)
        if not self.discord_owner:
            self.label(box, 'Discord managed by the owner', fg=PURPLE, bold=True).pack(anchor='w', padx=20, pady=(12, 4))
            self.label(box, textvariable=self.webhook_text, size=9).pack(anchor='w', padx=20, pady=(0, 20))
            return box
        tk.Frame(box, bg=BORDER, height=1).pack(fill='x', padx=20, pady=(14, 16))
        self.label(box, 'Discord connection', fg=TEXT, size=11, bold=True).pack(anchor='w', padx=20)
        self.label(box, 'Owner settings apply to every member. Webhook hidden by default.', size=9).pack(anchor='w', padx=20, pady=(5, 9))
        self.webhook_notice_label = self.label(box, textvariable=self.webhook_text, fg=WARNING, size=9, bold=True)
        self.webhook_notice_label.pack(anchor='w', padx=20, pady=(0, 10))
        connection = tk.Frame(box, bg=PANEL)
        connection.pack(fill='x', padx=20)
        self.webhook_entry = ctk.CTkEntry(connection, textvariable=self.webhook_var, show='*', height=32, corner_radius=8, fg_color=BUTTON, text_color=TEXT, border_color=BORDER, font=('Segoe UI', 12))
        self.webhook_entry.pack(side='left', fill='x', expand=True)
        self.webhook_reveal = self.button(connection, 'Show', self.toggle_webhook_visibility, True)
        self.webhook_reveal.pack(side='left', padx=(8, 0))
        self.button(connection, 'Save', self.save_webhook_input, True).pack(side='left', padx=(8, 0))
        self.button(connection, 'Test', self.test_webhook, True).pack(side='left', padx=(8, 0))
        self.label(box, 'Eastern / Etrean role: numeric role ID or <@&ID>, then Save role.', size=9).pack(anchor='w', padx=20, pady=(14, 5))
        role_row = tk.Frame(box, bg=PANEL)
        role_row.pack(fill='x', padx=20, pady=(0, 12))
        self.mention_entry = ctk.CTkEntry(role_row, textvariable=self.mention_var, height=32, corner_radius=8, fg_color=BUTTON, text_color=TEXT, border_color=BORDER, font=('Segoe UI', 12), placeholder_text='Role ID, for example 123456789012345678')
        self.mention_entry.pack(side='left', fill='x', expand=True)
        self.role_save_button = self.button(role_row, 'Save role', self.save_webhook_input, True)
        self.role_save_button.pack(side='left', padx=(8, 0))
        self.mention_entry.bind('<Return>', (lambda _event: self.save_webhook_input()))
        self.label(box, 'The Depths role: used only when the confirmed Luminant is Depths.', size=9).pack(anchor='w', padx=20, pady=(5, 5))
        depths_row = tk.Frame(box, bg=PANEL)
        depths_row.pack(fill='x', padx=20, pady=(0, 14))
        self.depths_mention_entry = ctk.CTkEntry(depths_row, textvariable=self.depths_mention_var, height=32, corner_radius=8, fg_color=BUTTON, text_color=TEXT, border_color=BORDER, font=('Segoe UI', 12))
        self.depths_mention_entry.pack(side='left', fill='x', expand=True)
        self.depths_role_save_button = self.button(depths_row, 'Save roles', self.save_webhook_input, True)
        self.depths_role_save_button.pack(side='left', padx=(8, 0))
        self.depths_mention_entry.bind('<Return>', (lambda _event: self.save_webhook_input()))
        return box

    def load_shared_discord(self):
        '''Read credentials only for owners; members receive readiness/deadline only.'''

        session = self.access_session
        def work():
            from lomastrap_access import AccessError
            try:
                status = session.discord_status()
                config = session.owner_request('/owner/discord') if session.owner else None
                self.events.put(('shared_discord', ('loaded', status, config)))
                return
            except AccessError as exc:
                self.events.put(('shared_discord', ('error', str(exc), None)))

        threading.Thread(target=work, daemon=True).start()

    def save_shared_discord(self):
        session = self.access_session
        if not session.owner or not session.valid():
            self.webhook_text.set('Owner sign-in required.')
            return
        if self._discord_busy:
            self.webhook_text.set('Please wait for the shared settings request to finish.')
            return
        webhook = self.webhook_var.get().strip()
        try:
            if not logic.WEBHOOK_RE.fullmatch(webhook) or len(webhook) > 512:
                raise ValueError('Enter a valid Discord webhook URL.')
            mention = logic.normalize_mention(self.mention_var.get())
            if mention and not mention.startswith('<@&'):
                raise ValueError('Use the numeric role ID or <@&ID>. <@ID> is a user mention. Discord: Server Settings > Roles > Copy Role ID.')
            depths_role = logic.normalize_role_id(self.depths_mention_var.get())
            role = mention[3:-1] if mention else ''
            if role:
                if role.isascii() and role.isdigit():
                    if 15 <= len(role):
                        if not len(role) <= 22:
                            raise ValueError('Enter a numeric Discord role ID (15–22 digits), or leave it blank.')
                raise ValueError('Enter a numeric Discord role ID (15–22 digits), or leave it blank.')
        except ValueError as exc:
            self.webhook_text.set(str(exc))
        self._discord_busy = True
        self.webhook_visible = False
        self.webhook_entry.configure(show='*')
        self.webhook_reveal.configure(text='Show')
        self.webhook_text.set('Saving shared Discord settings for all members...')
        def work():
            from lomastrap_access import AccessError
            try:
                if depths_role and 'luminant-roles-v1' not in session.discord_status().get('capabilities', []):
                    raise AccessError('Update the Cloudflare Worker before saving the separate Depths role.')
                session.owner_request('/owner/discord', {'webhook': webhook, 'role_id': role, 'depths_role_id': depths_role})
                self.events.put(('shared_discord', ('saved', None, None)))
                return
            except AccessError as exc:
                self.events.put(('shared_discord', ('error', str(exc), None)))

        threading.Thread(target=work, daemon=True).start()

    def test_shared_discord(self):
        session = self.access_session
        if not session.owner or not session.valid():
            self.webhook_text.set('Owner sign-in required.')
            return
        if self._discord_busy:
            self.webhook_text.set('Please wait for the shared settings request to finish.')
            return
        self._discord_busy = True
        self.webhook_text.set('Testing the saved shared webhook (no role mention)...')
        def work():
            from lomastrap_access import AccessError
            try:
                result = session.owner_request('/owner/discord/test', {})
                text = 'Test sent to the shared Discord channel.' if result.get('ok') else result.get('error', 'Discord test failed.')
                self.events.put(('shared_discord', ('tested', text, None)))
                return
            except AccessError as exc:
                self.events.put(('shared_discord', ('error', str(exc), None)))

        threading.Thread(target=work, daemon=True).start()

    def shared_discord_result(self, payload):
        self._discord_busy = False
        kind, value, config = payload
        if kind == 'loaded':
            self.cooldown.restore(max(self.cooldown.remaining(), value.get('remaining_seconds', 0)))
            remaining = math.ceil(self.cooldown.remaining())
            if remaining > 0:
                self.show_action_message('ping', f'Cooldown ({self.cooldown_description()}) — wait {remaining // 60}m {remaining % 60:02d}s before the next ping.', error=True)
            self.webhook_text.set('Discord ready — managed by the owner.' if value.get('configured') else 'Discord is not configured. The owner must save the shared webhook.')
            if self.discord_owner and config and config.get('webhook'):
                self.webhook_var.set(config['webhook'])
                self.mention_var.set(config.get('role_id', ''))
                self.depths_mention_var.set(config.get('depths_role_id', ''))
                self.mention_loaded = self.mention_var.get()
                return
            if self.discord_owner:
                if not value.get('configured'):
                    self.webhook_text.set('Save the webhook and role here to apply them to every member.')
                    return
                return
            return
        if kind == 'saved':
            self.webhook_text.set('Shared Discord settings saved. All members use these immediately.')
            return
        self.webhook_text.set(value)
        self.status.set(value)

    def toggle_webhook_visibility(self):
        if not self.discord_owner:
            return
        self.webhook_visible = not self.webhook_visible
        self.webhook_entry.configure(show='' if self.webhook_visible else '*')
        if self.webhook_visible:
            self.webhook_reveal.configure(text='Hide')
            return
        None(text='Show')

    def save_webhook_input(self):
        if self.access_session:
            return self.save_shared_discord()
        typed_mention = self.mention_var.get().strip()
        role_changed = typed_mention != self.mention_loaded
        try:
            mention = logic.normalize_mention(typed_mention) if role_changed else None
            depths_role = logic.normalize_role_id(self.depths_mention_var.get())
            logic.save_webhook(SECRETS, self.webhook_var.get())
            logic.save_depths_mention(SECRETS, depths_role)
            if role_changed:
                logic.save_mention(SECRETS, mention)
        except ValueError as exc:
            self.webhook_text.set(str(exc))
        except OSError:
            self.webhook_text.set('Could not save webhook. Move the app into a writable folder.')
        mention = logic.load_webhook(SECRETS)[1]
        self.mention_var.set(mention)
        self.mention_loaded = mention
        self.webhook_visible = False
        self.webhook_entry.configure(show='*')
        self.webhook_reveal.configure(text='Show')
        self.webhook_var.set(self.webhook_var.get().strip())
        env_override = bool(os.environ.get(logic.WEBHOOK_ENV, '').strip())
        self.webhook_text.set('Saved locally. An environment webhook is active and takes priority.' if env_override else 'Discord ready - saved. ' + (f'Pings {mention}.' if mention else 'No role to ping.') + ' Changes apply immediately.')
        self.status.set('Webhook saved privately. No test message was sent.')

    def test_webhook(self):
        '''Send one harmless test message so the webhook can be checked without a gank.'''

        if self.access_session:
            return self.test_shared_discord()
        if getattr(self, 'testing_webhook', False):
            return
        typed = self.webhook_var.get().strip()
        saved_url = logic.load_webhook(SECRETS)[0]
        if typed:
            if typed != (saved_url or '') or self.mention_var.get().strip() != self.mention_loaded:
                self.save_webhook_input()
        url, _, problem = logic.load_webhook(SECRETS)
        if not url:
            self.webhook_text.set(problem)
            return
        self.testing_webhook = True
        self.webhook_text.set('Sending a test message…')
        def work():
            error = logic.send_webhook(url, 'Lomastrap test message: the webhook works.')
            self.events.put(('webhook_test', error))

        threading.Thread(target=work, daemon=True).start()

    def pick_area(self, kind='server'):
        self.status.set('Select the left-side server name and following region line, then press Enter.')
        try:
            self.withdraw()
            AreaPicker(self, kind)
            return
        except Exception as exc:
            self.deiconify()
            logging.exception('Capture selector failed')
            self.status.set(f'Capture selector/API failure: {exc}')

    def store_area(self, area):
        with self.lock:
            from lomastrap_hud import HudTracker
            self.confirmer = HudTracker() if self.strict_reading else logic.Confirmer()
        self.server_text.set('No confirmed server yet')
        self.data['capture_area'] = area
        saved = self.save()
        self.area_text.set(self.describe_area())
        if saved:
            self.status.set('Capture area saved.')
        if self.strict_reading:
            self.ensure_monitoring()

    def pick_point(self, index):
        self.status.set(f'Click where point {index + 1} should be clicked.')
        try:
            self.withdraw()
            PointPicker(self, index)
            return
        except Exception as exc:
            self.deiconify()
            logging.exception('Point selector failed')
            self.status.set(f'Point selector/API failure: {exc}')

    def store_point(self, index, x, y):
        self.data['points'][index] = {'x': x, 'y': y}
        self.save()
        self.point_text[index].set(self.describe_point(index))
        self.status.set(f'Point {index + 1} saved.')

    def apply_interval(self):
        value = logic.clamp(self.interval_var.get(), 10, 5000, self.data['click_interval_ms'])
        self.data['click_interval_ms'] = int(value)
        self.interval_var.set(str(int(value)))
        self.save()

    def action_row(self, box, textvariable, command, key):
        row = tk.Frame(box, bg=PANEL)
        row.pack(fill='x', padx=20, pady=(8, 10))
        action = self.button(row, textvariable=textvariable, command=command)
        self.action_buttons[key] = action
        action.configure(fg_color=PRIMARY, hover_color='#9a70f5')
        action.pack(side='left')
        group = tk.Frame(row, bg=PANEL)
        group.pack(side='right', padx=(16, 0))
        self.label(group, BIND_TITLES[key], fg=PURPLE, size=7, bold=True).pack(anchor='w', pady=(0, 4))
        editor = tk.Frame(group, bg=PANEL)
        editor.pack()
        bind_entry = ctk.CTkEntry(editor, textvariable=self.bind_vars[key], width=115, height=30, corner_radius=8, fg_color=BUTTON, text_color=TEXT, border_color=BORDER, justify='center', font=('Segoe UI', 12, 'bold'))
        bind_entry.pack(side='left')
        bind_entry.bind('<FocusIn>', (lambda event: bind_entry.configure(border_color=PURPLE)))
        bind_entry.bind('<FocusOut>', (lambda event: bind_entry.configure(border_color=BORDER)))
        self.button(editor, 'Save', (lambda: self.save_bind(key)), True).pack(side='left', padx=(7, 0))

    def shortcut_settings(self):
        if self.advanced_allowed():
            return ['joiner_hotkey', 'ping_hotkey'] + ['combat_hotkey', 'esp_hotkey', 'active_panel_hotkey']
        return None + []

    def shortcut_bindings(self, values):
        return [(values.get(key, self.data[key]), BIND_ACTIONS[key][1]) for key in self.shortcut_settings()]

    def save_bind(self, key):
        action = BIND_ACTIONS[key][0]
        if key not in self.shortcut_settings():
            self.show_action_message(action, 'Trusted member or owner access required.', error=True)
            return
        if self.bind_pending:
            self.show_action_message(action, 'A shortcut change is still being applied. Please wait.', error=True)
            return
        proposed = dict(self.data)
        proposed.update({name: variable.get() for name, variable in self.bind_vars.items()})
        keys = self.shortcut_settings()
        try:
            pass
        except ValueError as exc:
            self.show_action_message(action, f'Keybind not saved: {exc}', error=True)
        try:
            args = [proposed[k] for k in keys]
            normalized = validate_bindings(*args)
            if self.data['parry_bar_enabled'] and self.advanced_allowed():
                from lomastrap_hotkeys import parse_hotkey
                if parse_hotkey(self.data['parry_key']) in [parse_hotkey(value) for value in normalized]:
                    raise ValueError('This shortcut conflicts with the active parry key.')
        except ValueError as exc:
            self.show_action_message(action, f'Keybind not saved: {exc}', error=True)
        try:
            proposed = {key: value for key, value in zip(keys, normalized)}
        except ValueError as exc:
            self.show_action_message(action, f'Keybind not saved: {exc}', error=True)
        previous = {name: self.data[name] for name in self.bind_vars}
        request = self.hotkeys.rebind(self.shortcut_bindings(proposed))
        self.bind_pending = {'request': request, 'previous': previous, 'proposed': proposed, 'action': action, 'draft': {name: variable.get() for name, variable in self.bind_vars.items()}}
        self.show_action_message(action, 'Applying shortcut...')

    def rebind_finished(self, result):
        pending = self.bind_pending
        if not pending or pending['request'] != result['request']:
            return
        self.bind_pending = None
        if pending.get('restore_only'):
            active = {BIND_SETTING[action]: key for key, action in result['bindings']}
            self.data.update(active)
            for key in self.bind_vars:
                self.bind_vars[key].set(display_hotkey(self.data[key]))
            self.show_action_message(pending['action'], 'Settings could not be saved. ' + ('Previous shortcuts restored.' if result['ok'] else result['error']), error=True)
            return
        if result['ok']:
            self.data.update(pending['proposed'])
            if not self.save():
                self.data.update(pending['previous'])
                old = pending['previous']
                request = self.hotkeys.rebind(self.shortcut_bindings(old))
                self.bind_pending = dict(pending, request=request, restore_only=True)
                self.show_action_message(pending['action'], 'Could not save settings; restoring previous shortcuts.', error=True)
                return
            message = 'Shortcut saved and active.'
        else:
            self.data.update(pending['previous'])
            message = 'Shortcut change failed: ' + result['error']
        for name in self.bind_vars:
            if self.bind_vars[name].get() == pending['draft'].get(name, self.bind_vars[name].get()):
                self.bind_vars[name].set(display_hotkey(self.data[name]))
        self.show_action_message(pending['action'], message, error=not result['ok'])

    def apply_read_rate(self):
        value = 1.0 if self.strict_reading else logic.reads_per_second(self.rate_var.get())
        self.data['reads_per_second'] = value
        self.rate_var.set(f'{value:g}')
        return self.save()

    def register_hotkeys(self):
        self.hotkeys = GlobalHotkeys(self.shortcut_bindings(self.data), self.events)
        self.hotkeys.start()

    def show_action_message(self, action, text, error=False):
        if action == 'active_panel':
            self.panel_notice.set(text)
            self.status.set(text)
            return
        if action == 'esp':
            self.party_notice.set(text)
            self.status.set(text)
            return
        notice = {'joiner': self.joiner_notice, 'combat': self.combat_notice}.get(action, self.ping_notice)
        label = {'joiner': self.joiner_notice_label, 'combat': self.__dict__.get('combat_notice_label', self.ping_notice_label)}.get(action, self.ping_notice_label)
        notice.set(text)
        label.configure(fg=RED if error else GREEN)
        self.status.set(text)

    def hotkey_received(self, action, payload):
        key = payload.get('key', '') if isinstance(payload, dict) else self.data[{'joiner': 'joiner_hotkey', 'combat': 'combat_hotkey'}.get(action, 'ping_hotkey')]
        timestamp = payload.get('time', time.strftime('%H:%M:%S')) if isinstance(payload, dict) else time.strftime('%H:%M:%S')
        variable = {'joiner': self.joiner_key_seen, 'combat': self.combat_key_seen}.get(action, self.ping_key_seen)
        variable.set(f'{key.upper()} pressed at {timestamp}')

    def process_events(self):
        try:
            while True:
                kind, payload = self.events.get_nowait()
                if self.closing and kind not in ('rebind_result', 'hotkey_status'):
                    continue
                if kind == 'access_revoked':
                    self.stop_parry()
                    self.stop_combat()
                    self.stop_joiner()
                    self.stop_monitor(persist=False)
                    messagebox.showerror('Lomastrap access', payload, parent=self)
                    self.logout_requested = True
                    self.close()
                    return
                if kind == 'access_status':
                    self.access_status.set(payload)
                elif kind == 'rebind_result':
                    self.rebind_finished(payload)
                elif kind == 'hotkey_status':
                    self.hotkey_status.set(payload)
                elif kind == 'joiner_failed':
                    token, error = payload
                    if token is self.joiner_stop:
                        self.stop_joiner()
                        self.show_action_message('joiner', error, error=True)
                elif kind == 'toggle_joiner':
                    self.hotkey_received('joiner', payload)
                    self.toggle_joiner()
                elif kind == 'toggle_active_panel':
                    self.toggle_active_panel()
                elif kind == 'toggle_esp':
                    self.toggle_esp()
                elif kind == 'toggle_combat':
                    self.hotkey_received('combat', payload)
                    self.toggle_combat()
                elif kind == 'combat_failed':
                    token, error = payload
                    if token is self.combat_stop:
                        self.stop_combat()
                        self.show_action_message('combat', error, error=True)
                elif kind == 'combat_state':
                    token, text = payload
                    if token is self.combat_stop and self.combating:
                        self.combat_state.set(text)
                elif kind == 'ping':
                    self.hotkey_received('ping', payload)
                    threading.Thread(target=self.do_ping, daemon=True).start()
                elif kind == 'ping_notice':
                    self.show_action_message('ping', payload, error=True)
                elif kind == 'status':
                    self.status.set(payload)
                elif kind == 'shared_discord':
                    self.shared_discord_result(payload)
                elif kind == 'webhook_test':
                    self.testing_webhook = False
                    text = payload or 'Test message sent. Check your Discord channel.'
                    self.webhook_text.set(text)
                    self.status.set(text)
                elif kind == 'monitor_state':
                    self.monitor_state.set(payload) if self.monitoring else None
                elif kind == 'monitor_update':
                    token, text = payload
                    if token is self.monitor_stop and not token.is_set() and self.monitoring:
                        self.monitor_state.set(text)
                elif kind == 'monitor_finished':
                    token, error = payload
                    if token is self.monitor_stop:
                        self.monitoring = False
                        self.monitor_button_text.set('Start monitoring')
                        self.monitor_state.set('Monitoring failed: ' + error if error else 'Monitoring is off')
                        if not error:
                            self.status.set('Monitoring stopped.')
                        if error:
                            self.data['monitoring_enabled'] = False
                            self.save()
                            self.status.set(error)
                elif kind == 'raw_ocr':
                    token, raw = payload
                    if token is None or token is self.monitor_stop and not token.is_set():
                        self.raw_ocr_text.set(raw)
                        self.raw_ocr_box.configure(state='normal')
                        self.raw_ocr_box.delete('1.0', 'end')
                        self.raw_ocr_box.insert('1.0', raw)
                        self.raw_ocr_box.configure(state='disabled')
                elif kind == 'reading_state':
                    token, reading, confirmed, ready, count = payload
                    if token is None or token is self.monitor_stop and not token.is_set():
                        if confirmed:
                            location = logic.describe_extras(confirmed)
                            checking = '' if self.strict_reading else f' | checking {reading.server} ({count}/2)' if reading and not ready else ''
                            self.server_text.set(f'Confirmed server: {confirmed.server}{location}{checking}')
                        elif reading:
                            self.server_text.set('Verifying server…' if self.strict_reading else f'Checking server: {reading.server} ({count}/2)')
                        else:
                            self.server_text.set('Server not confirmed - check raw OCR below')
                elif kind == 'confirmed':
                    area = logic.describe_extras(payload)
                    self.server_text.set(f'Confirmed server: {payload.server}{area}')
                elif kind == 'monitor_failed':
                    self.stop_monitor()
                    self.status.set(payload)
                elif kind == 'ping_sent':
                    self.ping_banner.set('Ping sent')
                    self.show_action_message('ping', f'Ping sent for {payload}.')
                    self.after(3000, (lambda: self.ping_banner.set('')))
        except queue.Empty:
            pass
        if not self.closing:
            self.after(60, self.process_events)

    def access_allowed(self):
        session = self.__dict__.get('access_session')
        if session is None:
            return True
        if session.valid():
            return True
        self.events.put(('access_revoked', 'Session expired. Sign in online again.'))
        return False

    def check_access(self):
        if self.closing:
            return
        session = self.access_session
        if session and not self._access_check_running:
            self._access_check_running = True
            def work():
                from lomastrap_access import AccessError
                try:
                    session.refresh()
                    text = 'Owner: ' + session.claims.get('name', 'Owner') if session.owner else 'Signed in as ' + session.claims.get('name', 'user')
                    if session.offline:
                        text += ' — offline; expires ' + time.strftime('%H:%M', time.localtime(session.claims['exp']))
                    self.events.put(('access_status', text))
                    while True:
                        self._access_check_running = False
                        return
                except AccessError as exc:
                    self.events.put(('access_revoked', str(exc)))
                except Exception:
                    self.events.put(('access_revoked', 'Cannot validate access. Sign in again.'))
                finally:
                    self._access_check_running = False

            threading.Thread(target=work, daemon=True).start()
        self.after(60000, self.check_access)

    def logout(self):
        if self.closing or not self.access_session:
            return
        session = self.access_session
        saved = session.refresh_token
        session.forget()
        self.logout_requested = True
        threading.Thread(target=(lambda: session.revoke_saved_session(saved)), daemon=True).start()
        self.close()

    def cooldown_description(self):
        if self.access_session and self.access_session.owner:
            return '30 seconds'
        return '15 minutes'

    def open_owner(self):
        session = self.access_session
        if not session or not session.owner or not session.valid():
            return
        from lomastrap_access_ui import OwnerPanel
        if self._owner_panel and self._owner_panel.winfo_exists():
            self._owner_panel.lift()
            return
        self._owner_panel = OwnerPanel(self, session)

    def toggle_joiner(self):
        if self.closing:
            return
        if self.joining:
            self.stop_joiner()
            self.show_action_message('joiner', 'Server Joiner stopped.')
            return
        if not self.access_allowed():
            return
        if not IS_WINDOWS:
            self.show_action_message('joiner', 'Clicking only works on Windows.', error=True)
            return
        points = self.data['points']
        if not all(points):
            self.show_action_message('joiner', 'Set both click points first.', error=True)
            return
        self.joiner_stop = threading.Event()
        self.joining = True
        self.refresh_joiner_button()
        threading.Thread(target=self.joiner_worker, daemon=True, args=([dict(p) for p in points], self.joiner_stop)).start()
        self.show_action_message('joiner', 'Server Joiner running.')

    def stop_joiner(self):
        self.joiner_stop.set()
        self.joining = False
        self.refresh_joiner_button()

    def joiner_worker(self, points, stop):
        try:
            with self.joiner_lock:
                index = 0
                while not stop.is_set():
                    if not self.access_allowed():
                        return
                    if click_at(points[index]['x'], points[index]['y'], hold_ms=self.data['click_hold_ms'], stop=stop) is False:
                        return
                    index = 1 - index
                    delay = logic.clamp(self.data['click_interval_ms'], 10, 5000, 10) / 1000
                    stop.wait(delay)
        except Exception as exc:
            logging.exception('Join Macro click failed')
            self.events.put(('joiner_failed', (stop, f'Click failed ({type(exc).__name__}): {exc}')))
        try:
            return
        except Exception as exc:
            logging.exception('Join Macro click failed')
            self.events.put(('joiner_failed', (stop, f'Click failed ({type(exc).__name__}): {exc}')))

    def toggle_monitor(self):
        if self.closing:
            return
        if self.monitoring:
            self.stop_monitor()
            return
        if not self.access_allowed():
            return
        if self.monitor_thread and self.monitor_thread.is_alive():
            self.status.set('Monitoring is stopping; wait for the current OCR read to finish.')
            return
        if not self.apply_read_rate():
            return
        try:
            logic.capture_box(self.data['capture_area'], desktop_bounds())
        except Exception as exc:
            self.status.set(f'Monitoring cannot start: {exc}')
        self.monitor_stop = threading.Event()
        self.monitoring = True
        self.data['monitoring_enabled'] = True
        if not self.save():
            self.monitoring = False
            self.data['monitoring_enabled'] = False
            return
        self.monitor_button_text.set('Stop monitoring')
        self.monitor_state.set('Monitoring started — waiting for Roblox')
        self.monitor_thread = threading.Thread(target=self.monitor_worker, args=(self.monitor_stop,), daemon=True)
        try:
            self.monitor_thread.start()
        except Exception as exc:
            logging.exception('Monitoring thread could not start')
            self.monitoring = False
            self.data['monitoring_enabled'] = False
            self.save()
            self.monitor_button_text.set('Start monitoring')
            self.monitor_state.set('Monitoring is off')
            self.status.set(f'Monitoring cannot start: {exc}')
        if self.strict_reading:
            self.status.set('Server reader: fast confirmation, then one automatic check per minute.')
            return
        None(f'Monitoring started at {self.data['reads_per_second']:g} reads/second. Roblox must be active.')

    def stop_monitor(self, persist=True):
        self.monitor_stop.set()
        self.monitoring = False
        alive = self.monitor_thread and self.monitor_thread.is_alive()
        self.monitor_button_text.set('Stopping…' if alive else 'Start monitoring')
        self.monitor_state.set('Stopping current read…' if alive else 'Monitoring is off')
        self.status.set('Monitoring is stopping…' if alive else 'Monitoring stopped.')
        if persist:
            self.data['monitoring_enabled'] = False
            self.save()

    def post_state(self, text, stop=None):
        if stop is not None:
            self.events.put(('monitor_update', (stop, text)))
            return
        if self.monitoring:
            self.events.put(('monitor_state', text))

    def monitor_worker(self, stop):
        error = None
        try:
            while not stop.is_set():
                if not self.access_allowed():
                    self.events.put(('monitor_finished', (stop, error)))
                    return
                started = time.monotonic()
                if not game_usable(self.data.get('capture_area')):
                    if self.strict_reading:
                        with self.lock:
                            self.confirmer.force_fast()
                    self.post_state('Paused — Roblox is closed, minimised or covered', stop)
                else:
                    with self.lock:
                        due = not self.strict_reading or self.confirmer.time_until_read() <= 0
                    if due:
                        error = self.read_once(stop)
                        if error and not error.startswith('OCR unreadable:'):
                            if not self.strict_reading:
                                self.events.put(('monitor_finished', (stop, error)))
                                return
                            self.post_state(error, stop)
                        error = None
                period = 1.0 if self.strict_reading else 1 / logic.reads_per_second(self.data['reads_per_second'])
                delay = max(0.0, period - (time.monotonic() - started))
                if self.strict_reading:
                    with self.lock:
                        remaining = self.confirmer.time_until_read()
                    if remaining > 0:
                        delay = min(delay, remaining)
                stop.wait(delay)
        except Exception as exc:
            logging.exception('Monitoring worker failed')
            error = f'Monitoring failed ({type(exc).__name__}): {exc}'
        self.events.put(('monitor_finished', (stop, error)))

    def read_once(self, stop=None):
        with self.read_lock:
            if stop is not None and stop.is_set():
                return
            if stop is not None and not game_usable(self.data.get('capture_area')):
                self.post_state('Paused - Roblox is closed, minimised or covered', stop)
                return
            return self._read_once(stop)

    def _read_once(self, stop=None):
        '''One screen read. Returns an error message, or None when it worked.'''

        area = self.data['capture_area']
        text = ocr_text(grab(area), strict=True) if self.strict_reading else ocr_text(grab(area))
        if stop is not None and stop.is_set():
            return
        self.events.put(('raw_ocr', (stop, 'Raw OCR:\n' + (getattr(text, 'raw', text) if text.strip() else '(empty OCR result)'))))
        reading = logic.parse_reading(text)
        with self.lock:
            if self.strict_reading:
                previous = self.confirmer.confirmed
                reading = self.confirmer.feed_text(text)
                changed = previous != self.confirmer.confirmed
            else:
                changed = self.confirmer.feed(reading)
            confirmed = self.confirmer.confirmed
            ready = self.confirmer.ready
            count = self.confirmer.count
        self.events.put(('reading_state', (stop, reading, confirmed, ready, count)))
        if self.strict_reading:
            status = self.confirmer.status(reading)
            self.post_state(status, stop)
        else:
            self.post_state(('Watching - server confirmed' if ready else 'Waiting for a second consecutive matching server name') if reading else 'Unclear read - keeping the latest confirmed server' if confirmed else 'OCR unreadable: no clear name line. See raw OCR below; reselect the left-side server label.', stop)
        return None if reading else 'OCR unreadable: no complete server name in the selected region.'
        self.events.put(('raw_ocr', (stop, f'Raw OCR unavailable: {type(exc).__name__}: {exc}')))
        self.events.put(('reading_state', (stop, None, self.confirmer.confirmed, self.confirmer.ready, self.confirmer.count)))
        exc = None
        del exc
        return str(exc) if isinstance(exc, (OcrUnavailable, ValueError, RuntimeError)) else f'Screen/OCR failure ({type(exc).__name__}): {exc}'

    def say(self, text):
        self.events.put(('ping_notice', text))

    def do_ping(self):
        if not self.access_allowed():
            return
        if self.closing:
            return
        if not self.ping_lock.acquire(blocking=False):
            self.say('A ping is already being prepared. Please wait.')
            return
        try:
            if not game_active():
                self.say('Ping ignored - Roblox is not the active window.')
                self.ping_lock.release()
                return
        finally:
            self.ping_lock.release()
        try:
            wait = self.cooldown.remaining()
            if wait > 0:
                self.say(f'Cooldown ({self.cooldown_description()}) — wait {math.ceil(wait) // 60}m {math.ceil(wait) % 60:02d}s before the next ping.')
                self.ping_lock.release()
                return
        finally:
            self.ping_lock.release()
        try:
            url, mention = None, ''
            if not self.access_session:
                url, mention, problem = logic.load_webhook(SECRETS)
                if not url:
                    self.say(problem)
                    self.ping_lock.release()
                    return
        finally:
            self.ping_lock.release()
        if self.strict_reading and not self.confirmer.eligible():
            try:
                try:
                    error = self.read_once()
                    with self.lock:
                        confirmed = self.confirmer.confirmed
                finally:
                    self.say('Ping blocked: no recent verified Deepwoken HUD, or a new server is still being confirmed.')
            finally:
                self.ping_lock.release()
            return
        try:
            if not confirmed:
                hint = '' if self.monitoring else ' Start monitoring first.'
                self.say('No confirmed server name yet. Two matching recognized reads are required.' + hint + (' ' + error if error else ''))
                self.ping_lock.release()
                return
        finally:
            self.ping_lock.release()
        try:
            if error:
                logging.info('Ping refresh was unclear or failed; retaining the latest confirmed server')
            if not self.access_session:
                mention = logic.mention_for_luminant(confirmed.luminant, mention, logic.load_depths_mention(SECRETS))
            message = logic.format_ping(confirmed, mention)
            if not game_active():
                self.say('Ping ignored - Roblox is no longer the active window.')
                self.ping_lock.release()
                return
        finally:
            self.ping_lock.release()
        try:
            if self.closing:
                self.say('Ping cancelled - the app is closing.')
                self.ping_lock.release()
                return
        finally:
            self.ping_lock.release()
        try:
            if not self.access_allowed():
                self.ping_lock.release()
                return
        finally:
            self.ping_lock.release()
        try:
            if self.access_session:
                from lomastrap_access import AccessError
                try:
                    result = self.access_session.send_gank(confirmed)
                except AccessError as exc:
                    self.say(str(exc) + ' Gank pings require the online service.')
                    self.ping_lock.release()
                    return
                self.cooldown.restore(result.get('remaining_seconds', 0))
                if not result.get('ok'):
                    wait = math.ceil(self.cooldown.remaining())
                    remaining = f' Wait {wait // 60}m {wait % 60:02d}s.' if wait else ''
                    self.say(result.get('error', 'The service could not send the ping.') + remaining)
                    self.ping_lock.release()
                    return
                error = None
            else:
                error = logic.send_webhook(url, message, mention)
        finally:
            self.ping_lock.release()
        if error:
            self.say(error)
            self.ping_lock.release()
            return
        try:
            if not self.access_session:
                self.cooldown.start()
            self.events.put(('ping_sent', confirmed.server))
        finally:
            self.ping_lock.release()

    def run_diagnostics(self, event=None):
        '''Run explicit native diagnostics without clicks or webhook sends.'''

        self.flush_settings(wait_bindings=True)
        self.stop_monitor(persist=False)
        self.hotkeys.close()
        report = APP_DIR / 'packaged-smoke.json'
        try:
            from lomastrap_diagnostics import run
            result = run(sys.modules[__name__], report)
            self.status.set(f'Diagnostics {'passed' if result == 0 else 'need attention'} - see {report.name}')
        except Exception as exc:
            logging.exception('Diagnostics failed')
            self.status.set(f'Diagnostics failed: {exc}')
        finally:
            self.register_hotkeys()

    def refresh_combat_button(self):
        self.combat_button_text.set(('Turn off' if self.combating else 'Turn on') + ' Combat M1')
        if self.combating:
            self.combat_state.set('On - hold the left mouse button to click')
            return
        None('Off')

    def apply_combat_speed(self):
        low, high = logic.combat_range(self.fastest_var.get(), self.slowest_var.get())
        self.data['combat_fastest_ms'] = low
        self.data['combat_slowest_ms'] = high
        self.fastest_var.set(str(low))
        self.slowest_var.set(str(high))
        return self.save()

    def toggle_combat(self):
        if not self.advanced_allowed():
            self.show_action_message('combat', 'Trusted member or owner access required.', error=True)
            return
        if self.closing:
            return
        if self.combating:
            self.stop_combat()
            self.show_action_message('combat', 'Combat M1 turned off.')
            return
        if not self.access_allowed():
            return
        if not IS_WINDOWS:
            self.show_action_message('combat', 'Clicking only works on Windows.', error=True)
            return
        self.apply_combat_speed()
        watcher = PhysicalLeftButton()
        problem = watcher.start()
        if problem:
            watcher.close()
            self.show_action_message('combat', problem, error=True)
            return
        self.combat_watcher = watcher
        self.combat_stop = threading.Event()
        self.combating = True
        self.refresh_combat_button()
        threading.Thread(target=self.combat_worker, daemon=True, args=(self.combat_stop, watcher)).start()
        self.show_action_message('combat', 'Combat M1 is on. Hold the left mouse button in Roblox to click.')

    def stop_combat(self):
        self.combat_stop.set()
        self.combating = False
        watcher, self.combat_watcher = self.combat_watcher, None
        if watcher is not None:
            watcher.close()
        self.refresh_combat_button()

    def combat_worker(self, stop, watcher):
        '''Clicks with fresh timing while the real left button is held and Roblox is in front.'''

        shown = ['']
        def tell(key, text):
            if shown[0] != key:
                shown[0] = key
                self.events.put(('combat_state', (stop, text)))

        try:
            with self.combat_lock:
                timing, shape = None, None
                while not stop.is_set():
                    if not self.access_allowed():
                        return
                    if not watcher.alive():
                        raise OSError('the mouse watcher stopped')
                    if not game_active():
                        watcher.pressed.clear()
                        tell('paused', 'Paused - Roblox is not the window in front')
                        stop.wait(0.1)
                        continue
                    if not watcher.pressed.wait(0.02):
                        tell('idle', 'On - hold the left mouse button to click')
                        continue
                    tell('clicking', 'Clicking - let go of the mouse button to stop')
                    current = self.data['combat_fastest_ms'], self.data['combat_slowest_ms']
                    if current != shape:
                        timing, shape = logic.HumanTiming(*current), current
                    hold, rest = timing.next_click()
                    click_m1(hold, stop)
                    stop.wait(rest)
        except Exception as exc:
            logging.exception('Combat clicker failed')
            self.events.put(('combat_failed', (stop, f'Combat M1 turned off: {exc}')))
        try:
            return
        except Exception as exc:
            logging.exception('Combat clicker failed')
            self.events.put(('combat_failed', (stop, f'Combat M1 turned off: {exc}')))

    def say_parry(self, text, error=False):
        self.parry_notice.set(text)
        if error:
            self.parry_notice_label.configure(fg=RED)
            return
        None(fg=GREEN)

    def apply_parry(self):
        if not self.advanced_allowed():
            return
        try:
            key = logic.clean_parry_key(self.parry_key_var.get())
        except ValueError as exc:
            self.parry_key_var.set(display_hotkey(self.data['parry_key']))
            self.say_parry(f'Parry key not changed: {exc}', error=True)
        changed_key = key != self.data['parry_key']
        cooldown, buffer = logic.parry_times(self.parry_cooldown_var.get(), self.parry_buffer_var.get())
        self.data.update({'parry_key': key, 'parry_cooldown_ms': cooldown, 'parry_buffer_ms': buffer, 'parry_bar_enabled': bool(self.parry_on_var.get())})
        self.parry_key_var.set(display_hotkey(key))
        self.parry_cooldown_var.set(str(cooldown))
        self.parry_buffer_var.set(str(buffer))
        self.parry.configure(cooldown, buffer)
        self.save()
        if self.data['parry_bar_enabled']:
            if changed_key or self.parry_watcher is None:
                self.start_parry()
                return
            return
        self.stop_parry()
        self.say_parry('Parry bar is off.')

    def start_parry(self):
        if not self.advanced_allowed():
            return
        if self.closing or not self.access_allowed():
            return
        from lomastrap_hotkeys import parse_hotkey
        if parse_hotkey(self.data['parry_key']) in [parse_hotkey(key) for key, _ in self.shortcut_bindings(self.data)]:
            self.data['parry_bar_enabled'] = False
            self.parry_on_var.set(False)
            self.say_parry('Parry key conflicts with another active shortcut. Choose a different key.', error=True)
            self.save()
            return
        self.stop_parry_watcher()
        if self.parry_bar is None:
            self.parry_bar = ParryBar(self, self.parry_moved)
        problem = ''
        if IS_WINDOWS:
            from lomastrap_hotkeys import parse_hotkey
            modifiers, vk = parse_hotkey(self.data['parry_key'])
            callback = lambda: self.parry_presses.put(time.monotonic())
            watcher = KeyWatcher(vk, callback, modifiers=modifiers) if modifiers & 15 else KeyWatcher(vk, callback)
            problem = watcher.start()
            if problem:
                watcher.close()
            else:
                self.parry_watcher = watcher
        else:
            problem = 'The parry bar only works on Windows.'
        if problem:
            self.say_parry(problem, error=True)
        else:
            self.say_parry(f'On. Press {self.data['parry_key'].upper()} in Roblox to start the bar.')
        self.parry.reset()
        if self.parry_after is None:
            self.parry_after = self.after(50, self.parry_tick)

    def stop_parry_watcher(self):
        watcher, self.parry_watcher = self.parry_watcher, None
        if watcher is not None:
            watcher.close()

    def stop_parry(self):
        if self.parry_after is not None:
            try:
                self.after_cancel(self.parry_after)
            except tk.TclError:
                pass
            self.parry_after = None
        self.stop_parry_watcher()
        bar = self.parry_bar
        if bar is not None:
            try:
                if bar.moving:
                    bar.end_move()
                bar.update_bar(None, 0, 0, 1.0)
            except tk.TclError:
                pass
        self.parry_move_text.set('Move bar')

    def parry_rect(self):
        '''The Roblox drawing area while Roblox is in front; the whole screen while the bar is being moved.'''

        front = foreground_client_rect()
        if front is not None and front[0].strip().lower() == 'roblox':
            return front[1]
        if self.parry_bar is not None and self.parry_bar.moving:
            return 0, 0, self.winfo_screenwidth(), self.winfo_screenheight()

    def parry_tick(self):
        self.parry_after = None
        if self.closing or not self.data['parry_bar_enabled'] or self.parry_bar is None:
            return
        rect = None
        try:
            rect = self.parry_rect()
            pressed = False
            try:
                self.parry_presses.get_nowait()
            except queue.Empty:
                pass
            else:
                pressed = True
        except Exception:
            logging.exception('Parry bar update failed')
        try:
            if rect is not None and not self.access_allowed():
                rect = None
            if pressed and rect is not None and not self.parry_bar.moving:
                self.parry.press()
            self.parry_bar.update_bar(rect, self.data['parry_bar_x'], self.data['parry_bar_y'], self.parry.fraction())
        except Exception:
            logging.exception('Parry bar update failed')
        self.parry_after = self.after(33 if rect is not None else 150, self.parry_tick)

    def toggle_parry_move(self):
        if self.parry_bar is None or not self.data['parry_bar_enabled']:
            self.say_parry('Turn the parry bar on first.', error=True)
            return
        if self.parry_bar.moving:
            self.parry_bar.end_move()
            self.parry_move_text.set('Move bar')
            self.say_parry('Position saved.')
            return
        self.parry_bar.begin_move()
        self.parry_move_text.set('Done moving')
        self.say_parry('Drag the bar where you want it, then press Done moving.')

    def parry_moved(self, left, top, width, height):
        rect = self.parry_rect() or (0, 0, self.winfo_screenwidth(), self.winfo_screenheight())
        self.data['parry_bar_x'], self.data['parry_bar_y'] = (round(value, 4) for value in fractions_from_position(rect, left, top, width, height))
        self.save()

    def reset_parry_position(self):
        self.data['parry_bar_x'] = logic.DEFAULT_SETTINGS['parry_bar_x']
        self.data['parry_bar_y'] = logic.DEFAULT_SETTINGS['parry_bar_y']
        self.save()
        if self.parry_bar is not None:
            self.parry_bar._geometry = None
        self.say_parry('Bar moved back to the default spot.')

    def close(self):
        self.closing = True
        if self.active_panel is not None:
            self.active_panel.stop()
        if self.party_service is not None:
            self.party_service.stop()
        self.flush_settings(wait_bindings=True)
        self.stop_parry()
        self.stop_combat()
        self.stop_joiner()
        self.stop_monitor(persist=False)
        if self.monitor_thread:
            self.monitor_thread.join(timeout=12)
            if self.monitor_thread.is_alive():
                logging.warning('Monitor still returning from a native API during exit; no more reads will be started')
        self.hotkeys.close()
        try:
            self.save()
        finally:
            self.destroy()


def main():
    if len(sys.argv) == 3 and sys.argv[1] == '--update-self-test':
        from lomastrap_diagnostics import update_self_test
        raise SystemExit(update_self_test(sys.modules[__name__], sys.argv[2]))
    if len(sys.argv) == 3 and sys.argv[1] == '--apply-update':
        from lomastrap_access import read_json
        from lomastrap_updates import apply_update
        config = Path(getattr(sys, '_MEIPASS', APP_DIR)) / 'access-config.json'
        raise SystemExit(apply_update(sys.argv[2], read_json(config).get('public_key', '')))
    if len(sys.argv) == 3 and sys.argv[1] == '--access-check':
        from lomastrap_diagnostics import access_check
        raise SystemExit(access_check(sys.modules[__name__], sys.argv[2]))
    if len(sys.argv) == 3 and sys.argv[1] == '--self-test':
        from lomastrap_diagnostics import run
        raise SystemExit(run(sys.modules[__name__], sys.argv[2]))
    instance = SingleInstance()
    try:
        if not instance.acquire():
            instance.activate_existing()
            messagebox.showinfo('Lomastrap already running', 'Another Lomastrap copy is already running. Its window has been restored. Close the existing copy before opening a different version.')
            instance.close()
            return
        launch_ui()
    except OSError as exc:
        messagebox.showerror('Lomastrap', f'Cannot establish the single-instance guard: {exc}')
    finally:
        instance.close()

def launch_ui():
    handlers = [logging.StreamHandler()] if sys.stderr is not None else []
    try:
        handlers.append(logging.FileHandler(APP_DIR / 'lomastrap.log', encoding='utf-8'))
    except OSError:
        pass
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s', handlers=handlers)
    updater = None
    try:
        from lomastrap_access_ui import sign_in
        bundle_config = Path(getattr(sys, '_MEIPASS', APP_DIR)) / 'access-config.json'
        config = APP_DIR / 'access-config.json'
        if not config.exists():
            config = bundle_config
        directory = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'Lomastrap'
        if getattr(sys, 'frozen', False) and IS_WINDOWS:
            from lomastrap_access import read_json
            from lomastrap_updates import UpdateManager
        try:
            updater = UpdateManager(read_json(config)).start()
        except Exception:
            logging.warning('Updater could not start; app login remains available.')
        else:
            session = sign_in(config, directory, updater)
            if session is None:
                pass
            else:
                window = Lomastrap(access_session=session, updater=updater)
                window.mainloop()
                if not window.logout_requested:
                    pass
    except Exception:
        logging.exception('Lomastrap failed')
        messagebox.showerror('Lomastrap', f'Startup failed. See {APP_DIR / 'lomastrap.log'}')
        raise
    if updater:
        try:
            updater.close_and_apply()
        except Exception:
            logging.warning('Update installation could not be scheduled; current app retained.')

if __name__ == '__main__':
    main()
# WARNING: Decompyle incomplete
