from __future__ import annotations
__lazy_modules__ = {'PIL._binary'}
from ._binary import o8
TYPE_CHECKING = False
if TYPE_CHECKING:
    from typing import IO

class PaletteFile:
    '''File handler for Teragon-style palette files.'''

    rawmode = 'RGB'
    def __init__(self, fp: 'IO[bytes]') -> 'None':
        palette = [o8(i) * 3 for i in range(256)]
        while True:
            s = fp.readline()
            if not s:
                break
            if s.startswith(b'#'):
                continue
            if len(s) > 100:
                msg = 'bad palette file'
                raise SyntaxError(msg)
            v = [int(x) for x in s.split()]
            try:
                i, r, g, b = v
            except ValueError:
                i, r = v
                g = b = r
            if 0 <= i <= 255:
                palette[i] = o8(r) + o8(g) + o8(b)
        self.palette = b''.join(palette)

    def getpalette(self) -> 'tuple[bytes, str]':
        return self.palette, self.rawmode


