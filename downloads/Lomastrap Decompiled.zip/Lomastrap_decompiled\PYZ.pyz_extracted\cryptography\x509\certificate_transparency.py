from __future__ import annotations
from cryptography import utils
from cryptography.hazmat.bindings._rust import x509 as rust_x509

class LogEntryType(utils.Enum):
    X509_CERTIFICATE = 0
    PRE_CERTIFICATE = 1

class Version(utils.Enum):
    v1 = 0

class SignatureAlgorithm(utils.Enum):
    '''
    Signature algorithms that are valid for SCTs.

    These are exactly the same as SignatureAlgorithm in RFC 5246 (TLS 1.2).

    See: <https://datatracker.ietf.org/doc/html/rfc5246#section-7.4.1.4.1>
    '''

    ANONYMOUS = 0
    RSA = 1
    DSA = 2
    ECDSA = 3

SignedCertificateTimestamp = rust_x509.Sct
