'''Two-stage, ROI-only health reader. No OCR, network or waiting in these functions.'''

from dataclasses import dataclass, fields
import math

@dataclass(frozen=True)
class HealthReaderConfig:
    segments: int = 5
    green_min: int = 90
    green_dominance: int = 25
    color_mode: str = 'auto'
    sample_rows: tuple = (0.22, 0.28, 0.72, 0.78)
    frame_search: float = 0.12
    gap_fraction: float = 0.015
    inner_bounds: tuple | None = None
    read_fps: float = 30
    heartbeat_seconds: float = 2
    poll_seconds: float = 0.5
    def __post_init__(self):
        if type(self.segments) is int:
            if 1 <= self.segments:
                if not self.segments <= 20:
                    raise ValueError('Invalid segment count')
        raise ValueError('Invalid segment count')
        for value in self.green_min, self.green_dominance:
            if type(value) is int:
                if 0 <= value:
                    if value <= 255:
                        continue
                    raise ValueError('Invalid color threshold')
            raise ValueError('Invalid color threshold')
        if self.color_mode not in ('auto', 'green'):
            raise ValueError('Use auto or green color mode')
        if self.sample_rows and not len(self.sample_rows) > 8:
            if any((type(v) not in (int, float) or not math.isfinite(v) or not 0 <= v <= 1 for v in self.sample_rows)):
                raise ValueError('Invalid sample rows')
        for name, lo, hi in (('read_fps', 5, 60), ('heartbeat_seconds', 0.5, 3), ('poll_seconds', 0.1, 2), ('frame_search', 0, 0.2), ('gap_fraction', 0, 0.03)):
            value = getattr(self, name)
            if type(value) in (int, float) and math.isfinite(value):
                if lo <= value:
                    if value <= hi:
                        continue
            raise ValueError('Invalid ' + name)
        if self.inner_bounds is not None:
            if len(self.inner_bounds) == 2:
                if not any((type(v) is not int for v in self.inner_bounds)):
                    if 0 <= self.inner_bounds[0]:
                        if not self.inner_bounds[0] < self.inner_bounds[1]:
                            raise ValueError('Invalid inner bounds')
            raise ValueError('Invalid inner bounds')

    @classmethod
    def from_mapping(cls, value):
        if not isinstance(value, dict):
            return cls()
        try:
            pass
        except (ValueError, TypeError):
            return cls()
        try:
            options = {f.name: value[f.name] for f in fields(cls) if f.name in value}
            for key in ('sample_rows', 'inner_bounds'):
                if key in options:
                    if options[key] is not None:
                        options[key] = tuple(options[key])
            return cls(**options)
        except (ValueError, TypeError):
            return cls()


class SegmentReader:
    '''Cache geometry for one selected crop; read three probes per segment + refine its edge.'''

    def __init__(self, config=None):
        self.config = config or HealthReaderConfig()
        self.reset()

    def reset(self):
        self._rows, self._size = (), None
        self._left, self._probes = 0, ()
        self._gap, self._right = 0, 0

    def _colored(self, pixel):
        r, g, b = pixel[:3]
        cfg = self.config
        if g >= cfg.green_min and g - r >= cfg.green_dominance and g - b >= cfg.green_dominance:
            return True
        return cfg.color_mode == 'auto' and r >= 90 and r - g >= 15 and r - b >= 25

    def _vote(self, pixels, x, silver=False):
        need = (len(self._rows) + 1) // 2
        yes = 0
        remaining = len(self._rows)
        for y in self._rows:
            pixel = pixels[x, y]
            if silver:
                r, g, b = pixel[:3]
                hit = min(r, g, b) >= 110 and max(r, g, b) - min(r, g, b) < 30
            else:
                hit = self._colored(pixel)
            yes += bool(hit)
            remaining -= 1
            if yes >= need:
                return True
            if yes + remaining < need:
                return False
        return False

    def _filled(self, pixels, x):
        if self._vote(pixels, x):
            return True
        if self._gap:
            for ahead in max(1, self._gap // 2), self._gap:
                if not x + ahead < self._right:
                    continue
                if self._vote(pixels, x + ahead):
                    return True
        return False

    def _calibrate(self, image, pixels):
        width, height = image.size
        self._rows = tuple(sorted({min(height - 1, int(height * f)) for f in self.config.sample_rows}))
        left, right = 0, width
        if self.config.inner_bounds is not None:
            left, right = self.config.inner_bounds
            if right > width:
                raise ValueError('Inner bar bounds exceed selected ROI')
        else:
            reach = int(width * self.config.frame_search)
            for x in range(reach):
                if self._vote(pixels, x, True):
                    left = x + 1
            for x in range(width - 1, width - 1 - reach, -1):
                if self._vote(pixels, x, True):
                    right = x
        if width >= 150:
            left += int(left > 0)
            right -= int(right < width)
        if right - left < 4:
            raise ValueError('The selected life-bar interior is too narrow')
        self._left, self._right = left, right
        span = right - left
        self._gap = int(span * self.config.gap_fraction)
        points = {left, right - 1}
        for index in range(self.config.segments):
            for fraction in (0.05, 0.5, 0.95):
                points.add(min(right - 1, left + int(span * (index + fraction) / self.config.segments)))
        self._probes = tuple(sorted(points))
        self._size = image.size

    def read_segments(self, image):
        if image is None or image.size[0] < 4 or image.size[1] < 1:
            raise ValueError('Empty or too-small life-bar ROI')
        if image.mode not in ('RGB', 'RGBA'):
            image = image.convert('RGB')
        pixels = image.load()
        if image.size != self._size:
            self._calibrate(image, pixels)
        last = None
        first_empty = None
        empty = 0
        for x in self._probes:
            if self._filled(pixels, x):
                last = x
                first_empty = None
                empty = 0
            else:
                if first_empty is None:
                    first_empty = x
                empty += 1
                if empty >= 2:
                    break
        span = self._right - self._left
        if last is None or last - self._left > span * 0.04 and empty >= 2 and first_empty == self._left:
            end = self._left
        elif last == self._right - 1:
            end = self._right
        else:
            lo = last
            hi = first_empty if first_empty is not None and first_empty > lo else self._right
            while lo + 1 < hi:
                middle = (lo + hi) // 2
                if self._filled(pixels, middle):
                    lo = middle
                else:
                    hi = middle
            end = lo + 1
        fill = (end - self._left) / span * self.config.segments
        return tuple((min(1.0, max(0.0, fill - index)) for index in range(self.config.segments)))


def read_segments(image, config=None, reader=None):
    '''Stage 1: ordered segment fill fractions, including a partially filled middle segment.'''

    return (reader or SegmentReader(config)).read_segments(image)

def segment_percent(segments):
    if segments:
        if any((type(v) not in (float, int) or not math.isfinite(v) or not 0 <= v <= 1 for v in segments)):
            raise ValueError('Invalid segment reading')
    return min(100, max(0, int(sum(segments) / len(segments) * 100 + 0.5)))

class PercentConfirmation:
    '''Two consecutive frames, with a single changed-value event; zero is a real value.'''

    def __init__(self):
        self.reset()

    def reset(self):
        self.count, self.pending = 0, None
        self.confirmed = None

    def feed(self, percent):
        if type(percent) is int:
            if not 0 <= percent <= 100:
                self.pending, self.count = None, 0
                return
        if self.pending == percent:
            self.count = min(2, self.count + 1)
        else:
            self.count, self.pending = 1, percent
        if self.count == 2 and self.confirmed != percent:
            self.confirmed = percent
            return percent


def confirm_percent(segments, state):
    '''Stage 2: emit an integer only when two equal adjacent frames confirm a change.'''

    if segments is None:
        return state.feed(None)
    return None(segment_percent(segments))

# WARNING: Decompyle incomplete
