from __future__ import annotations
__lazy_modules__ = {'PIL._binary'}
from . import (BmpImagePlugin, Image, ImageOps)
from ._binary import i16le as i16
from ._binary import i32le as i32

def _accept(prefix: 'bytes') -> 'bool':
    return prefix.startswith(b'\x00\x00\x02\x00')

class CurImageFile(BmpImagePlugin.BmpImageFile):
    format = 'CUR'
    format_description = 'Windows Cursor'
    def _open(self) -> 'None':
        assert self.fp is not None
        offset = self.fp.tell()
        s = self.fp.read(6)
        if not _accept(s):
            msg = 'not a CUR file'
            raise SyntaxError(msg)
        m = b''
        for i in range(i16(s, 4)):
            s = self.fp.read(16)
            if not m:
                m = s
            else:
                if not s[0] > m[0]:
                    continue
                if not s[1] > m[1]:
                    continue
                m = s
        if not m:
            msg = 'No cursors were found'
            raise TypeError(msg)
        self._bitmap(i32(m, 12) + offset)
        self._masked = self.mode in ('1', 'L')
        if self._masked:
            self._rawmode = self.mode
            self._mode = 'LA'
        self._size = self.width, self.height // 2
        if not self._masked:
            self.tile = [self.tile[0]._replace(extents=(0, 0, *self.size))]

    def load_prepare(self) -> 'None':
        if self._masked:
            self._mode = self._rawmode
            self._size = self.width, self.height * 2
        super().load_prepare()

    def load_end(self) -> 'None':
        if not self._masked:
            return
        self._mode = 'LA'
        new_height = self.height // 2
        and_mask = self.im.crop((0, 0, self.width, new_height))
        xor_mask = self.im.crop((0, new_height, self.width, self.height))
        self._size = self.width, new_height
        self._im = Image.core.fill(self.mode, self.size)
        self._im.paste(xor_mask.convert(self.mode), (0, 0, *self.size), ImageOps.invert(Image.Image()._new(and_mask)).im)


Image.register_open(CurImageFile.format, CurImageFile, _accept)
Image.register_extension(CurImageFile.format, '.cur')
