from __future__ import annotations
from cryptography.hazmat.bindings._rust import openssl as rust_openssl
from cryptography.hazmat.primitives.kdf import KeyDerivationFunction
PBKDF2HMAC = rust_openssl.kdf.PBKDF2HMAC
KeyDerivationFunction.register(PBKDF2HMAC)
__all__ = ['PBKDF2HMAC']
