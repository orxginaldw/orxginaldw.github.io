'''Console-free Windows entry point. Debug with python loma_join_macro.py.'''

from loma_join_macro import main
if __name__ == '__main__':
    main()
