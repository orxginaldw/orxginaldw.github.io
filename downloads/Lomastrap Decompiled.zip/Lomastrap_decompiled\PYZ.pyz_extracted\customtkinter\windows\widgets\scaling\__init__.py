import sys
from .scaling_base_class import CTkScalingBaseClass
from .scaling_tracker import ScalingTracker
if sys.platform.startswith('win'):
    if sys.getwindowsversion().build < 9000:
        ScalingTracker.deactivate_automatic_dpi_awareness = True
