from __future__ import annotations
from cryptography.hazmat.bindings._rust import openssl as rust_openssl
from cryptography.hazmat.primitives.kdf import KeyDerivationFunction
X963KDF = rust_openssl.kdf.X963KDF
KeyDerivationFunction.register(X963KDF)
__all__ = ['X963KDF']
