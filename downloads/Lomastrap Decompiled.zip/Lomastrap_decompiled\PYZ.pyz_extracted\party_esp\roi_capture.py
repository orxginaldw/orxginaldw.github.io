'''Windows ROI capture into one reused top-down DIB. No full-screen bitmap or PIL crop.'''

import ctypes
import sys
import threading
from lomastrap_logic import capture_box

class BitmapHeader(ctypes.Structure):
    _fields_ = [('size', ctypes.c_uint32), ('width', ctypes.c_int32), ('height', ctypes.c_int32), ('planes', ctypes.c_uint16), ('bits', ctypes.c_uint16), ('compression', ctypes.c_uint32), ('image_size', ctypes.c_uint32), ('xppm', ctypes.c_int32), ('yppm', ctypes.c_int32), ('colors', ctypes.c_uint32), ('important', ctypes.c_uint32)]

class BitmapInfo(ctypes.Structure):
    _fields_ = [('header', BitmapHeader), ('palette', ctypes.c_uint32 * 1)]

class RoiFrame:
    mode = 'RGB'
    def __init__(self, width, height, address):
        self.stride, self.size = width * 4, (width, height)
        self.buffer = (ctypes.c_ubyte * (self.stride * height)).from_address(address)

    def load(self):
        return self

    def __getitem__(self, point):
        if self.buffer is None:
            raise ValueError('ROI frame was released')
        x, y = point
        if 0 <= x < self.size[0]:
            if 0 <= y:
                if not y < self.size[1]:
                    raise IndexError(point)
            else:
                x
        raise IndexError(point)
        offset = y * self.stride + x * 4
        data = self.buffer
        return data[offset + 2], data[offset + 1], data[offset]


class Win32RegionCapture:
    def __init__(self, bounds, api=None):
        self._api, self.bounds = api, bounds
        self._owner = None
        self.screen = self.memory = self.bitmap = None
        self.previous = None
        self.frame = None

    def _apis(self):
        if self._api:
            return self._api
        if sys.platform != 'win32':
            raise RuntimeError('Native ROI capture requires Windows')
        user = ctypes.WinDLL('user32', use_last_error=True)
        gdi = ctypes.WinDLL('gdi32', use_last_error=True)
        ptr = ctypes.c_void_p
        integer = ctypes.c_int
        for function, args, result in (user.GetDC, [ptr], ptr), (user.ReleaseDC, [ptr, ptr], integer), (gdi.CreateCompatibleDC, [ptr], ptr), (gdi.DeleteDC, [ptr], integer), (gdi.CreateDIBSection, [ptr, ctypes.POINTER(BitmapInfo), ctypes.c_uint, ctypes.POINTER(ptr), ptr, ctypes.c_uint32], ptr), (gdi.SelectObject, [ptr, ptr], ptr), (gdi.DeleteObject, [ptr], integer), (gdi.BitBlt, [ptr, integer, integer, integer, integer, ptr, integer, integer, ctypes.c_uint32], integer), (gdi.GdiFlush, [], integer):
            function.restype, function.argtypes = result, args
        self._api = user, gdi
        return self._api

    def _check_owner(self):
        current = threading.get_ident()
        if self._owner is None:
            self._owner = current
            return
        if self._owner != current:
            raise RuntimeError('ROI capture must stay on its owning reader thread')

    def _allocate(self, width, height):
        user, gdi = self._apis()
        self.screen = user.GetDC(None)
        if not self.screen:
            raise RuntimeError('ROI capture permission/API failure: GetDC failed')
        self.memory = gdi.CreateCompatibleDC(self.screen)
        if not self.memory:
            raise RuntimeError('ROI capture API failure: CreateCompatibleDC failed')
        info = BitmapInfo()
        info.header = BitmapHeader(ctypes.sizeof(BitmapHeader), width, -height, 1, 32, 0, width * height * 4, 0, 0, 0, 0)
        address = ctypes.c_void_p()
        self.bitmap = gdi.CreateDIBSection(self.screen, ctypes.byref(info), 0, ctypes.byref(address), None, 0)
        if not self.bitmap or not address.value:
            raise RuntimeError('ROI capture API failure: CreateDIBSection failed')
        self.previous = gdi.SelectObject(self.memory, self.bitmap)
        if not self.previous or self.previous == ctypes.c_void_p(-1).value:
            self.previous = None
            raise RuntimeError('ROI capture API failure: SelectObject failed')
        self.frame = RoiFrame(width, height, address.value)

    def __call__(self, area):
        self._check_owner()
        left, top, right, bottom = capture_box(area, self.bounds())
        width, height = right - left, bottom - top
        if width * height > 2000000:
            raise ValueError('Life-bar ROI is too large; select only the health bar')
        try:
            if self.frame is None or self.frame.size != (width, height):
                self.close()
                self._check_owner()
                self._allocate(width, height)
            _, gdi = self._apis()
            if not gdi.BitBlt(self.memory, 0, 0, width, height, self.screen, left, top, 1087111200):
                raise RuntimeError('ROI capture API/permission failure: BitBlt failed')
            if not gdi.GdiFlush():
                raise RuntimeError('ROI capture API failure: GdiFlush failed')
        except Exception:
            self.close()
            raise
        return self.frame

    def close(self):
        if not any((self.screen, self.memory, self.bitmap)):
            return
        self._check_owner()
        user, gdi = self._apis()
        if self.frame:
            self.frame, self.frame.buffer = None, None
        if self.previous and self.memory:
            gdi.SelectObject(self.memory, self.previous)
        self.previous = None
        if self.bitmap:
            gdi.DeleteObject(self.bitmap)
            self.bitmap = None
        if self.memory:
            gdi.DeleteDC(self.memory)
            self.memory = None
        if self.screen:
            user.ReleaseDC(None, self.screen)
            self.screen = None
        self._owner = None


