import tkinter
from typing import Callable
import darkdetect

class AppearanceModeTracker:
    callback_list = []
    app_list = []
    update_loop_running = False
    update_loop_interval = 30
    appearance_mode_set_by = 'system'
    appearance_mode = 0
    @classmethod
    def init_appearance_mode(cls):
        if cls.appearance_mode_set_by == 'system':
            new_appearance_mode = cls.detect_appearance_mode()
            if new_appearance_mode != cls.appearance_mode:
                cls.appearance_mode = new_appearance_mode
                cls.update_callbacks()

    @classmethod
    def add(cls, callback: Callable, widget=None):
        cls.callback_list.append(callback)
        if widget is not None:
            app = cls.get_tk_root_of_widget(widget)
            if app not in cls.app_list:
                cls.app_list.append(app)
                if not cls.update_loop_running:
                    app.after(cls.update_loop_interval, cls.update)
                    cls.update_loop_running = True

    @classmethod
    def remove(cls, callback: Callable):
        try:
            cls.callback_list.remove(callback)
            return
        except ValueError:
            return

    @staticmethod
    def detect_appearance_mode() -> int:
        try:
            if darkdetect.theme() == 'Dark':
                return 1
        except NameError:
            pass
        return 0

    @classmethod
    def get_tk_root_of_widget(cls, widget):
        current_widget = widget
        while isinstance(current_widget, tkinter.Tk) is False:
            current_widget = current_widget.master
        return current_widget

    @classmethod
    def update_callbacks(cls):
        if cls.appearance_mode == 0:
            for callback in cls.callback_list:
                try:
                    callback('Light')
                except Exception:
                    continue
            return
        if cls.appearance_mode == 1:
            for callback in cls.callback_list:
                try:
                    callback('Dark')
                except Exception:
                    continue

    @classmethod
    def update(cls):
        if cls.appearance_mode_set_by == 'system':
            new_appearance_mode = cls.detect_appearance_mode()
            if new_appearance_mode != cls.appearance_mode:
                cls.appearance_mode = new_appearance_mode
                cls.update_callbacks()
        for app in cls.app_list:
            try:
                app.after(cls.update_loop_interval, cls.update)
            except Exception:
                continue
            return
        cls.update_loop_running = False

    @classmethod
    def get_mode(cls) -> int:
        return cls.appearance_mode

    @classmethod
    def set_appearance_mode(cls, mode_string: str):
        if mode_string.lower() == 'dark':
            cls.appearance_mode_set_by = 'user'
            new_appearance_mode = 1
            if new_appearance_mode != cls.appearance_mode:
                cls.appearance_mode = new_appearance_mode
                cls.update_callbacks()
                return
            return
        if mode_string.lower() == 'light':
            cls.appearance_mode_set_by = 'user'
            new_appearance_mode = 0
            if new_appearance_mode != cls.appearance_mode:
                cls.appearance_mode = new_appearance_mode
                cls.update_callbacks()
                return
            return
        if mode_string.lower() == 'system':
            cls.appearance_mode_set_by = 'system'


