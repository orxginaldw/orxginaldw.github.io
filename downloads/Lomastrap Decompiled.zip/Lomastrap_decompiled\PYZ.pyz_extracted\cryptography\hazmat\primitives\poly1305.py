from __future__ import annotations
from cryptography.hazmat.bindings._rust import openssl as rust_openssl
__all__ = ['Poly1305']
Poly1305 = rust_openssl.poly1305.Poly1305
