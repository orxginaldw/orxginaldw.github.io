from winreg import (HKEY_CURRENT_USER as hkey, QueryValueEx as getSubkeyValue, OpenKey as getKey)
import ctypes
import ctypes.wintypes
advapi32 = ctypes.windll.advapi32
advapi32.RegOpenKeyExA.argtypes = ctypes.wintypes.HKEY, ctypes.wintypes.LPCSTR, ctypes.wintypes.DWORD, ctypes.wintypes.DWORD, ctypes.POINTER(ctypes.wintypes.HKEY)
advapi32.RegOpenKeyExA.restype = ctypes.wintypes.LONG
advapi32.RegQueryValueExA.argtypes = ctypes.wintypes.HKEY, ctypes.wintypes.LPCSTR, ctypes.wintypes.LPDWORD, ctypes.wintypes.LPDWORD, ctypes.wintypes.LPBYTE, ctypes.wintypes.LPDWORD
advapi32.RegQueryValueExA.restype = ctypes.wintypes.LONG
advapi32.RegNotifyChangeKeyValue.argtypes = ctypes.wintypes.HKEY, ctypes.wintypes.BOOL, ctypes.wintypes.DWORD, ctypes.wintypes.HANDLE, ctypes.wintypes.BOOL
advapi32.RegNotifyChangeKeyValue.restype = ctypes.wintypes.LONG

def theme():
    ''' Uses the Windows Registry to detect if the user is using Dark Mode '''

    valueMeaning = {0: 'Dark', 1: 'Light'}
    try:
        key = getKey(hkey, 'Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize')
        subkey = getSubkeyValue(key, 'AppsUseLightTheme')[0]
    except FileNotFoundError:
        return
    return valueMeaning[subkey]

def isDark():
    if theme() is not None:
        return theme() == 'Dark'

def isLight():
    if theme() is not None:
        return theme() == 'Light'

def listener(callback):
    hKey = ctypes.wintypes.HKEY()
    advapi32.RegOpenKeyExA(ctypes.wintypes.HKEY(2147483649), ctypes.wintypes.LPCSTR(b'SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize'), ctypes.wintypes.DWORD(), ctypes.wintypes.DWORD(131097), ctypes.byref(hKey))
    dwSize = ctypes.wintypes.DWORD(ctypes.sizeof(ctypes.wintypes.DWORD))
    queryValueLast = ctypes.wintypes.DWORD()
    queryValue = ctypes.wintypes.DWORD()
    advapi32.RegQueryValueExA(hKey, ctypes.wintypes.LPCSTR(b'AppsUseLightTheme'), ctypes.wintypes.LPDWORD(), ctypes.wintypes.LPDWORD(), ctypes.cast(ctypes.byref(queryValueLast), ctypes.wintypes.LPBYTE), ctypes.byref(dwSize))
    while True:
        advapi32.RegNotifyChangeKeyValue(hKey, ctypes.wintypes.BOOL(True), ctypes.wintypes.DWORD(4), ctypes.wintypes.HANDLE(None), ctypes.wintypes.BOOL(False))
        advapi32.RegQueryValueExA(hKey, ctypes.wintypes.LPCSTR(b'AppsUseLightTheme'), ctypes.wintypes.LPDWORD(), ctypes.wintypes.LPDWORD(), ctypes.cast(ctypes.byref(queryValue), ctypes.wintypes.LPBYTE), ctypes.byref(dwSize))
        if queryValueLast.value != queryValue.value:
            queryValueLast.value = queryValue.value
            callback('Light' if queryValue.value else 'Dark')

