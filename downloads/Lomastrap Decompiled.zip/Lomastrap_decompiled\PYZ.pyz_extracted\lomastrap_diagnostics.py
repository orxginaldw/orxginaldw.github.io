'''Optional packaged smoke checks. Never sends Discord messages or clicks.'''

import json
import queue
import time
from pathlib import Path

def run(app, destination):
    results = {}
    def check(name, function):
        try:
            results[name] = {'ok': True, 'detail': str(function())}
            return
        except Exception as exc:
            results[name] = {'ok': False, 'detail': f'{type(exc).__name__}: {exc}'}

    check('pillow', (lambda: __import__('PIL').__version__))
    check('keyboard', (lambda: __import__('keyboard').__name__))
    check('winocr', (lambda: __import__('winocr').__name__))
    def gui():
        root = app.tk.Tk()
        try:
            root.withdraw()
            root.iconbitmap(app.tcl_path(app.ASSETS / 'lomastrap.ico'))
            root.update()
        finally:
            root.destroy()
        return root.tk.call('info', 'patchlevel')

    app.enable_dpi_awareness()
    check('tk_and_icon', gui)
    check('capture', (lambda: app.grab(dict(zip(('x', 'y', 'width', 'height'), (*app.desktop_bounds()[:2], 200, 80)))).size))
    def ocr():
        from PIL import Image, ImageDraw
        image = Image.new('RGB', (500, 80), 'white')
        ImageDraw.Draw(image).text((10, 10), 'Silver Mist Harbor', fill='black', font_size=16)
        text = app.ocr_text(image)
        if not app.logic.parse_reading(text):
            raise ValueError(f'Synthetic OCR result could not be parsed: {text!r}')
        return 'synthetic readable server recognized'

    check('ocr', ocr)
    def hotkeys():
        from lomastrap_hotkeys import GlobalHotkeys
        events = queue.Queue()
        service = GlobalHotkeys([('f8', 'toggle_joiner'), ('f2', 'ping')], events)
        try:
            service.start()
            kind, message = events.get(timeout=5)
            if 'ready' not in message.lower():
                raise RuntimeError(message)
        finally:
            service.close()
        return message

    check('f8_f2_registration', hotkeys)
    check('hotkey_cleanup_reregister', hotkeys)
    Path(destination).write_text(json.dumps(results, indent=2), encoding='utf-8')
    return 0 if all((item['ok'] for item in results.values())) else 1

def access_check(app, destination):
    '''Public HTTPS probe: no login, hardware ID, credentials, clicks or hotkeys.'''

    import urllib.request
    import urllib.error
    from lomastrap_access import (NoRedirect, VERSION, connection_error, read_json, validate_config, https_context)
    config = app.APP_DIR / 'access-config.json'
    if not config.exists():
        config = Path(getattr(app.sys, '_MEIPASS', app.APP_DIR)) / 'access-config.json'
    report = {'ok': False, 'version': VERSION}
    try:
        endpoint = validate_config(read_json(config))
        request = urllib.request.Request(endpoint + '/owner/status', headers={'User-Agent': 'Lomastrap/' + VERSION, 'Accept': 'application/json'})
        try:
            response = urllib.request.build_opener(NoRedirect, urllib.request.HTTPSHandler(context=https_context())).open(request, timeout=12)
        except urllib.error.HTTPError as exc:
            response = exc
        else:
            with response:
                pass
    except (OSError, urllib.error.URLError) as exc:
        report['detail'] = connection_error(exc)
    except Exception as exc:
        report['detail'] = 'Access check failed (' + type(exc).__name__ + ').'
    try:
        report['ok'] = response.status == 401 and payload.get('error') == 'Session expired or invalid. Sign in again.'
        report['detail'] = 'Public HTTPS request reached the deployed access service.' if report['ok'] else 'Unexpected access-service response.'
    except (OSError, urllib.error.URLError) as exc:
        report['detail'] = connection_error(exc)
    except Exception as exc:
        report['detail'] = 'Access check failed (' + type(exc).__name__ + ').'
    Path(destination).write_text(json.dumps(report, indent=2), encoding='utf-8')
    return 0 if report['ok'] else 1

def update_self_test(app, destination):
    from lomastrap_access import VERSION, https_context
    report = {'ok': False, 'version': VERSION}
    root = None
    try:
        import cryptography
        import certifi
        import PIL
        import keyboard
        import winocr
        import customtkinter
        from lomastrap_session_store import encode, decode
        if decode(encode({'check': 'session-storage'})) != {'check': 'session-storage'}:
            raise ValueError('Session storage check failed')
        report['session_storage'] = 'Windows CurrentUser DPAPI'
        reading = app.logic.parse_reading('Kind Ivory Priest\nHesse, DE\n0d 6h 47m || 02:13 2 NOV\nEastern Luminant')
        if not reading or reading.luminant != 'Eastern Luminant':
            raise ValueError('Standalone Luminant parsing failed')
        report['luminant_parser'] = 'separate-line supported'
        https_context()
        app.enable_dpi_awareness()
        root = app.tk.Tk()
        root.withdraw()
        root.iconbitmap(app.tcl_path(app.ASSETS / 'lomastrap.ico'))
        root.update_idletasks()
        report['ok'] = True
    except Exception as exc:
        report['detail'] = 'Startup check failed (' + type(exc).__name__ + ').'
    if root:
        root.destroy()
    Path(destination).write_text(json.dumps(report), encoding='utf-8')
    return 0 if report['ok'] else 1

