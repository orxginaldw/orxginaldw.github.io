'''Access client: signed, expiring user sessions; owner credentials stay in memory.'''

import base64
import hashlib
import json
import logging
import socket
import ssl
import os
import time
import threading
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path
VERSION = '0.8.9'
PRIVACY = "Login records include your chosen name, login time, app version, random install ID, and a hashed device identifier for blocking. The Windows machine ID is hashed before sending; the service stores a further keyed hash. Owners can see the expired, single-use code used to join for 30 days. No raw hardware ID, owner key, reusable password, or IP address is stored in the app's database. Login history is kept for 30 days; inactive unblocked devices without saved access for 90 days. Saved access remains until logout or revocation. Server name, Luminant, region and captured HP are shared live with authorized viewers in your server while the app is open; screen images are not sent. Live health expires after six seconds without updates. Block records remain until unblocked. Gank messages include your login name. Cooldown records use the same keyed device identity and survive logout; expired records are removed after 24 hours by scheduled cleanup. Cloudflare may process network metadata to provide the service."

class AccessError(Exception):
    '''An explicit denial: never grant offline access after one.'''

class Unavailable(AccessError):
    '''Network/service outage: only a valid signed user session may continue.'''

def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2), encoding='utf-8')
    temporary.replace(path)

def read_json(path):
    try:
        value = json.loads(Path(path).read_text(encoding='utf-8'))
        if isinstance(value, dict):
            return value
        return {}
    except (OSError, ValueError, UnicodeError):
        return {}

def install_id(directory):
    path = Path(directory) / 'install.json'
    previous = read_json(path).get('id', '')
    try:
        return str(uuid.UUID(previous))
    except (ValueError, TypeError, AttributeError):
        value = str(uuid.uuid4())
        atomic_json(path, {'id': value})
        return value

def device_id(fallback):
    '''Do not transmit or persist MachineGuid itself. No serial-number enumeration.'''

    value = fallback
    if os.name == 'nt':
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, 'SOFTWARE\\Microsoft\\Cryptography', 0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as key:
                value = winreg.QueryValueEx(key, 'MachineGuid')[0]
        except OSError:
            pass
    return hashlib.sha256(('Lomastrap-device-v1:' + str(value)).encode()).hexdigest()

def validate_config(config):
    endpoint = config.get('endpoint', '')
    parsed = urllib.parse.urlparse(endpoint)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in ('', '/'):
        raise AccessError('Owner setup required: configure the HTTPS access-service origin before building.')
    if not isinstance(config.get('public_key'), str) or 'BEGIN PUBLIC KEY' not in config['public_key']:
        raise AccessError('Owner setup required: the session verification public key is missing.')
    return endpoint.rstrip('/')

def decode_token(token, public_key, expected_install=None, now=None):
    '''Worker WebCrypto emits a raw r||s P-256 signature, not DER.'''

    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec, utils
    now = time.time() if now is None else now
    try:
        if not isinstance(token, str) or len(token) > 4096:
            raise ValueError()
        body, encoded = token.split('.')
        signature = base64.urlsafe_b64decode(encoded + '=' * (-len(encoded) % 4))
        if len(signature) != 64:
            raise ValueError()
        key = serialization.load_pem_public_key(public_key.encode())
        if not (isinstance(key, ec.EllipticCurvePublicKey) and isinstance(key.curve, ec.SECP256R1)):
            raise ValueError()
        der = utils.encode_dss_signature(int.from_bytes(signature[:32], 'big'), int.from_bytes(signature[32:], 'big'))
        key.verify(der, body.encode('ascii'), ec.ECDSA(hashes.SHA256()))
        claims = json.loads(base64.urlsafe_b64decode(body + '=' * (-len(body) % 4)))
        role = claims.get('role')
        maximum = 86400 if role == 'user' else 3600
        if role in ('user', 'owner') and claims.get('aud') == 'lomastrap' and type(claims.get('iat')) is int and type(claims.get('exp')) is int and not claims['iat'] > now + 60 and not claims['exp'] <= now:
            if 0 < claims['exp'] - claims['iat']:
                if not claims['exp'] - claims['iat'] <= maximum:
                    raise ValueError()
        raise ValueError()
        if (role == 'user' or 'install_id' in claims) and claims.get('install_id') != expected_install:
            raise ValueError()
        return claims
    except Exception:
        raise AccessError('Session expired or invalid. Sign in online again.') from None

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        pass


def https_context():
    '''Keep platform trust and runtime policy, adding the shipped Mozilla CA set.'''

    import certifi
    context = ssl.create_default_context()
    context.load_verify_locations(cafile=certifi.where())
    return context

def connection_error(exc):
    '''Explain failures without interpolating exception text or request secrets.'''

    reason = getattr(exc, 'reason', exc)
    if isinstance(reason, FileNotFoundError):
        return 'Packaged HTTPS resource is missing. Download the updated Lomastrap build.'
    if isinstance(reason, ssl.SSLCertVerificationError):
        code = getattr(reason, 'verify_code', None)
        detail = getattr(reason, 'verify_message', '')[:110]
        suffix = ' (code ' + str(code) + ': ' + detail + ')' if code is not None else ''
        return 'HTTPS certificate verification failed' + suffix + '. Check your PC date/time and network certificate settings.'
    if isinstance(reason, ssl.SSLError):
        return 'Secure HTTPS connection failed (TLS). Check your network or proxy settings.'
    if isinstance(reason, socket.gaierror):
        return 'DNS lookup failed. Check your internet connection and DNS.'
    if isinstance(reason, (TimeoutError, socket.timeout)):
        return 'Access-service connection timed out. Try again.'
    if isinstance(reason, PermissionError):
        return 'Access-service connection was blocked. Check app firewall permissions.'
    return 'Cannot connect to the access service (' + type(reason).__name__ + '). Check your connection.'

def transport(endpoint, path, body=None, token=None, timeout=20):
    headers = {'Accept': 'application/json', 'User-Agent': 'Lomastrap/' + VERSION}
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        headers['Content-Type'] = 'application/json'
    if token:
        headers['Authorization'] = 'Bearer ' + token
    request = urllib.request.Request(endpoint + path, data=data, headers=headers)
    try:
        with urllib.request.build_opener(NoRedirect, urllib.request.HTTPSHandler(context=https_context())).open(request, timeout=timeout) as reply:
            raw = reply.read(262145)
            if len(raw) > 262144:
                raise Unavailable('Access service returned an oversized response.')
            result = json.loads(raw)
            if not isinstance(result, dict):
                raise ValueError()
            return result
    except urllib.error.HTTPError as exc:
        if exc.code >= 500 and path == '/party/state':
            raise Unavailable('Shared health service unavailable. The owner must check the latest Worker and PARTY_ROOMS binding.') from None
        if exc.code >= 500:
            raise Unavailable('Access service is temporarily unavailable.') from None
        messages = {401: 'Session or password invalid. Sign in again.', 403: 'Access removed or owner permission required.', 429: 'Too many attempts. Wait one minute.', 400: 'Invalid name or request. Check your input.', 404: 'Service endpoint not found. Deploy the latest Lomastrap Worker code.'}
        raise AccessError(messages.get(exc.code, 'Access request was rejected.')) from None
    except (OSError, urllib.error.URLError) as exc:
        reason = getattr(exc, 'reason', exc)
        logging.warning('Access HTTPS failure: category=%s code=%s', type(reason).__name__, getattr(reason, 'errno', None))
        raise Unavailable(connection_error(exc)) from None
    except (ValueError, UnicodeError):
        raise Unavailable('Access service returned an unreadable response. Check the Worker deployment.') from None

def validate_name(name):
    if not isinstance(name, str):
        raise AccessError('Enter your name.')
    name = name.strip()
    if 2 <= len(name) <= 32:
        if not all((c.isalnum() or c in " _'-" for c in name)):
            raise AccessError('Use a name with 2–32 letters, numbers, spaces, apostrophes or hyphens.')
    return name

class AccessClient:
    def __init__(self, config, directory, request=transport, clock=time.time):
        self.endpoint = validate_config(config)
        self.public_key = config['public_key']
        self.directory = Path(directory)
        self.install = install_id(self.directory)
        self.request = request
        self.clock = clock
        self._session_lock = threading.RLock()
        self._generation = 0
        self.refresh_token = None
        self.token = None
        self.claims = {}
        self.offline = False
        self._party_transport = None
        self.cache = self.directory / 'session.json'

    @property
    def owner(self):
        return self.claims.get('role') == 'owner'

    @property
    def trusted(self):
        return self.claims.get('role') == 'user' and self.claims.get('tier') == 'trusted'

    @property
    def advanced(self):
        return self.owner or self.trusted

    def party_state(self, body):
        if not self.valid():
            raise AccessError('Sign in to share health.')
        if self.request is transport:
            if urllib.request.getproxies():
                return transport(self.endpoint, '/party/state', body, self.token, timeout=3)
            if self._party_transport is None:
                from party_esp.transport import PersistentPartyTransport
                self._party_transport = PersistentPartyTransport(self.endpoint)
            return self._party_transport(body, self.token)
        return self.request(self.endpoint, '/party/state', body, self.token)

    def close_party_transport(self):
        if self._party_transport is not None:
            self._party_transport.close()
            self._party_transport = None

    def valid(self):
        return bool(self.token and self.claims.get('exp', 0) > self.clock())

    def accept(self, token, role, refresh_token=None, expected_generation=None):
        claims = decode_token(token, self.public_key, self.install, self.clock())
        if claims['role'] != role:
            raise AccessError('Unexpected session role.')
        if refresh_token is not None and (not isinstance(refresh_token, str) or len(refresh_token) != 43):
            raise AccessError('Invalid saved-session response.')
        with self._session_lock:
            if expected_generation is not None and expected_generation != self._generation:
                raise AccessError('Session ended.')
            if refresh_token:
                from lomastrap_session_store import encode
                try:
                    atomic_json(self.cache, encode({'token': token, 'endpoint': self.endpoint, 'refresh_token': refresh_token}))
                except OSError:
                    raise AccessError('Windows could not save access securely. Use your normal Windows account and a writable user profile.') from None
            elif role == 'user':
                atomic_json(self.cache, {'token': token, 'endpoint': self.endpoint})
            else:
                self.cache.unlink(missing_ok=True)
            self.token, self.claims, self.offline = token, claims, False
            self.refresh_token = refresh_token

    @staticmethod
    def response_token(response):
        if not (isinstance(response, dict) and isinstance(response.get('token'), str)):
            raise AccessError('Invalid access-service response. Sign in online again.')
        return response['token']

    def accept_response(self, response, expected_generation):
        token = self.response_token(response)
        claims = decode_token(token, self.public_key, self.install, self.clock())
        self.accept(token, claims['role'], response.get('refresh_token'), expected_generation=expected_generation)

    def identity(self):
        return {'install_id': self.install, 'device_id': device_id(self.install), 'version': VERSION}

    def login(self, name, password):
        name = validate_name(name)
        if isinstance(password, str):
            if 1 <= len(password):
                if not len(password) <= 128:
                    raise AccessError('Enter the access code supplied by an owner.')
        raise AccessError('Enter the access code supplied by an owner.')
        generation = self._generation
        response = self.request(self.endpoint, '/login', {**self.identity(), 'name': name, 'password': password, 'remember': True})
        self.accept(self.response_token(response), 'user', response.get('refresh_token'), generation)

    def login_owner(self, name, key):
        name = validate_name(name)
        if isinstance(key, str):
            if 24 <= len(key):
                if not len(key) <= 512:
                    raise AccessError('Enter your separate long owner key.')
        raise AccessError('Enter your separate long owner key.')
        generation = self._generation
        response = self.request(self.endpoint, '/owner/login', {**self.identity(), 'name': name, 'owner_key': key, 'remember': True})
        self.accept(self.response_token(response), 'owner', response.get('refresh_token'), generation)

    def forget(self, expected_generation=None):
        with self._session_lock:
            if expected_generation is not None and expected_generation != self._generation:
                return
            self._generation += 1
            self.token, self.claims, self.offline, self.refresh_token = None, {}, False, None
            try:
                self.cache.unlink(missing_ok=True)
                return
            except OSError:
                atomic_json(self.cache, {})

    def logout(self, refresh_token=None):
        '''Clear locally before network I/O. A late refresh cannot recreate this cache.'''

        with self._session_lock:
            saved = refresh_token or self.refresh_token
            self.forget()
        return self.revoke_saved_session(saved)

    def revoke_saved_session(self, saved):
        if saved:
            try:
                self.request(self.endpoint, '/logout', {'refresh_token': saved})
            except AccessError:
                return False
            return True
        return True

    def resume(self):
        generation = self._generation
        from lomastrap_session_store import decode
        try:
            cached = decode(read_json(self.cache))
        except (OSError, ValueError, TypeError):
            raise AccessError('Saved session cannot be restored on this Windows account. Sign in again.') from None
        if cached.get('endpoint') != self.endpoint:
            raise AccessError('No saved session for this service. Sign in online.')
        saved = cached.get('refresh_token')
        if saved:
            try:
                response = self.request(self.endpoint, '/session/resume', {**self.identity(), 'refresh_token': saved})
                self.accept_response(response, generation)
            except Unavailable:
                try:
                    self.accept(cached.get('token'), 'user', saved, generation)
                except AccessError:
                    raise Unavailable('Reconnect to restore your saved access. No password is needed.') from None
                self.offline = True
                return
            except AccessError:
                self.forget(generation)
                raise
            return
        try:
            self.accept(cached.get('token'), 'user', expected_generation=generation)
            self.refresh()
        except AccessError as exc:
            if not isinstance(exc, Unavailable):
                self.forget(generation)
            raise

    def refresh(self):
        generation = self._generation
        saved, token = self.refresh_token, self.token
        if not saved and not self.valid():
            self.forget(generation)
            raise AccessError('Session expired. Sign in online again.')
        try:
            if saved:
                response = self.request(self.endpoint, '/session/resume', {**self.identity(), 'refresh_token': saved})
                self.accept_response(response, generation)
                return
            if self.owner:
                self.owner_request('/owner/status')
                return
            response = self.request(self.endpoint, '/session', {**self.identity(), 'remember': True}, token)
            self.accept(self.response_token(response), 'user', response.get('refresh_token'), generation)
            return
        except Unavailable:
            if generation != self._generation:
                raise AccessError('Session ended.') from None
            if self.owner:
                raise
            if not self.valid():
                if not saved:
                    self.forget(generation)
                raise Unavailable('Reconnect to restore your saved access.') from None
            self.offline = True
        except AccessError:
            self.forget(generation)
            raise

    def owner_request(self, path, body=None):
        if not self.owner or not self.valid() or not path.startswith('/owner/'):
            raise AccessError('Owner sign-in required.')
        return self.request(self.endpoint, path, body, self.token)

    def discord_status(self):
        if not self.valid():
            raise AccessError('Sign in online before sending a gank ping.')
        return self.request(self.endpoint, '/discord/status', token=self.token)

    def send_gank(self, reading):
        from lomastrap_logic import short_luminant
        if not self.valid():
            raise AccessError('Sign in online before sending a gank ping.')
        if short_luminant(reading.luminant) == 'Depths' and 'luminant-roles-v1' not in self.discord_status().get('capabilities', []):
            raise AccessError('Update the Cloudflare Worker for the separate Depths role before sending a Depths ping.')
        return self.request(self.endpoint, '/gank-ping', {'request_id': str(uuid.uuid4()), 'server': reading.server, 'region': reading.area, 'luminant': short_luminant(reading.luminant) or 'unknown'}, self.token)


