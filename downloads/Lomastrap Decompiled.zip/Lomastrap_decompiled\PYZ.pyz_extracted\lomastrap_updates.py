'''Signed updates bundled in Lomastrap.exe. Never changes private configuration.'''

import base64
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import uuid
from lomastrap_access import (VERSION, NoRedirect, atomic_json, https_context, read_json, validate_config)
CHUNK_SIZE = 524288
MAX_SIZE = 33554432

class UpdateError(Exception):
    pass

def version_tuple(value):
    if not (isinstance(value, str) and re.fullmatch('(0|[1-9]\\d{0,3})\\.(0|[1-9]\\d{0,3})\\.(0|[1-9]\\d{0,3})', value)):
        raise UpdateError('Invalid update version.')
    return tuple(map(int, value.split('.')))

def verify_manifest(token, public_key, current_version=None):
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec, utils
    try:
        if not isinstance(token, str) or len(token) > 16384:
            raise ValueError()
        body, encoded = token.split('.')
        raw = base64.urlsafe_b64decode(encoded + '=' * (-len(encoded) % 4))
        if len(raw) != 64:
            raise ValueError()
        key = serialization.load_pem_public_key(public_key.encode())
        if not (isinstance(key, ec.EllipticCurvePublicKey) and isinstance(key.curve, ec.SECP256R1)):
            raise ValueError()
        key.verify(utils.encode_dss_signature(int.from_bytes(raw[:32], 'big'), int.from_bytes(raw[32:], 'big')), body.encode('ascii'), ec.ECDSA(hashes.SHA256()))
        data = json.loads(base64.urlsafe_b64decode(body + '=' * (-len(body) % 4)))
        if data.get('aud') != 'lomastrap-update-v1':
            raise ValueError()
        version_tuple(data.get('version'))
        if str(uuid.UUID(data['release_id'])) != data['release_id']:
            raise ValueError()
        if type(data['size']) is int:
            if 1024 <= data['size']:
                if not data['size'] <= MAX_SIZE:
                    raise ValueError()
        raise ValueError()
        if data['chunk_size'] != CHUNK_SIZE or type(data['chunks']) is not int or data['chunks'] != math.ceil(data['size'] / CHUNK_SIZE):
            raise ValueError()
        if type(data.get('published_at')) is not int or data['published_at'] < 0:
            raise ValueError()
        def valid_hash(value):
            return isinstance(value, str) and re.fullmatch('[a-f0-9]{64}', value)

        if valid_hash(data['sha256']) and isinstance(data['chunk_hashes'], list) and len(data['chunk_hashes']) == data['chunks']:
            if not all((valid_hash(h) for h in data['chunk_hashes'])):
                raise ValueError()
        if current_version is not None and version_tuple(data['version']) <= version_tuple(current_version):
            raise UpdateError('Update is not newer than this app.')
        return data
    except UpdateError:
        raise
    except Exception:
        raise UpdateError('Update signature or metadata is invalid.') from None

def file_hash(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as source:
        for part in iter((lambda: source.read(1048576)), b''):
            digest.update(part)
    return digest.hexdigest()

def get_bytes(endpoint, path, maximum):
    request = urllib.request.Request(endpoint + path, headers={'User-Agent': 'Lomastrap/' + VERSION, 'Accept': 'application/octet-stream'})
    try:
        with urllib.request.build_opener(NoRedirect, urllib.request.HTTPSHandler(context=https_context())).open(request, timeout=20) as reply:
            data = reply.read(maximum + 1)
            if len(data) > maximum:
                raise UpdateError('Update response exceeded its limit.')
            return data
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            raise UpdateError('Update service is not enabled yet.') from None
        raise UpdateError('Update download failed (HTTP ' + str(exc.code) + ').') from None
    except OSError:
        raise UpdateError('Cannot connect to the update service. Current app remains available.') from None

def download_release(manifest, endpoint, directory, fetch=get_bytes, stop=None):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    target = directory / 'download.exe'
    temporary = directory / 'download.partial'
    if target.exists() and target.stat().st_size == manifest['size'] and file_hash(target) == manifest['sha256']:
        return target
    digest = hashlib.sha256()
    try:
        with temporary.open('wb') as destination:
            for index in range(manifest['chunks']):
                if stop is not None and stop.is_set():
                    raise UpdateError('Update download cancelled.')
                expected = CHUNK_SIZE if index < manifest['chunks'] - 1 else manifest['size'] - index * CHUNK_SIZE
                data = fetch(endpoint, '/updates/' + manifest['release_id'] + '/' + str(index), expected)
                if len(data) != expected or hashlib.sha256(data).hexdigest() != manifest['chunk_hashes'][index]:
                    raise UpdateError('Update part checksum failed. Current app was kept.')
                destination.write(data)
                digest.update(data)
        if digest.hexdigest() != manifest['sha256']:
            raise UpdateError('Update file checksum failed. Current app was kept.')
        temporary.replace(target)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise
    return target

def update_directory():
    return Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'Lomastrap' / 'updates'

class UpdateManager:
    def __init__(self, config, directory=None, target=None, fetch=get_bytes):
        self.endpoint = validate_config(config)
        self.public_key = config['public_key']
        self.root = Path(directory) if directory is not None else update_directory()
        self.target = Path(target or sys.executable).resolve()
        self.fetch = fetch
        self.stop = threading.Event()
        self.message = 'Updates: checking…'
        self.ready = None
        self.lock = threading.Lock()
        self.thread = None

    def check(self):
        raw = self.fetch(self.endpoint, '/updates/latest', 16384)
        try:
            token = json.loads(raw).get('manifest')
        except (ValueError, AttributeError):
            raise UpdateError('Invalid update-service response.') from None
        if not token:
            self.message = 'Updates: no published update.'
            return
        manifest = verify_manifest(token, self.public_key)
        if version_tuple(manifest['version']) <= version_tuple(VERSION):
            self.message = 'Updates: up to date.'
            return
        previous = read_json(self.root / 'result.json')
        if previous.get('version') == manifest['version'] and previous.get('ok') is False:
            self.message = 'Updates: last installation failed; current version retained.'
            return
        self.message = 'Downloading update ' + manifest['version'] + '…'
        directory = self.root / manifest['release_id']
        staged = download_release(manifest, self.endpoint, directory, self.fetch, self.stop)
        if self.stop.is_set():
            return
        job = {'manifest': token, 'target': str(self.target), 'old_hash': file_hash(self.target), 'pid': os.getpid()}
        atomic_json(directory / 'job.json', job)
        with self.lock:
            self.ready = directory / 'job.json'
        self.message = 'Update ' + manifest['version'] + ' ready — installs when you close.'

    def clean_cache(self):
        if not self.root.exists():
            return
        cutoff = time.time() - 604800
        resolved = self.root.resolve()
        for directory in self.root.iterdir():
            try:
                if not directory.is_symlink():
                    if not directory.is_dir() or directory.resolve().parent != resolved:
                        continue
                    if str(uuid.UUID(directory.name)) != directory.name or directory.stat().st_mtime >= cutoff:
                        continue
                    shutil.rmtree(directory)
            except (OSError, ValueError):
                continue

    def start(self):
        self.clean_cache()
        def work():
            while not self.stop.is_set():
                try:
                    self.check()
                except UpdateError as exc:
                    self.message = 'Updates: ' + str(exc)
                except Exception:
                    self.message = 'Updates unavailable; current app remains available.'
                if self.stop.wait(21600):
                    return

        self.thread = threading.Thread(target=work, daemon=True)
        self.thread.start()
        return self

    def close_and_apply(self):
        self.stop.set()
        with self.lock:
            job = self.ready
        if job is None or not getattr(sys, 'frozen', False) or os.name != 'nt':
            return
        helper = job.parent / 'installer.exe'
        shutil.copy2(sys.executable, helper)
        subprocess.Popen([str(helper), '--apply-update', str(job)], cwd=str(job.parent), creationflags=subprocess.CREATE_NO_WINDOW, close_fds=True)


def wait_for_parent(pid, timeout=120):
    if os.name != 'nt':
        raise UpdateError('Installing updates requires Windows.')
    import ctypes
    from ctypes import wintypes as w
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]
    kernel.OpenProcess.restype = w.HANDLE
    kernel.WaitForSingleObject.argtypes = [w.HANDLE, w.DWORD]
    kernel.WaitForSingleObject.restype = w.DWORD
    kernel.CloseHandle.argtypes = [w.HANDLE]
    kernel.CloseHandle.restype = w.BOOL
    handle = kernel.OpenProcess(1048576, False, pid)
    if not handle:
        if ctypes.get_last_error() == 87:
            return
        raise UpdateError('Cannot wait for the previous app process.')
    try:
        if kernel.WaitForSingleObject(handle, timeout * 1000) != 0:
            raise UpdateError('Previous app has not closed.')
    finally:
        kernel.CloseHandle(handle)

def atomic_install(staged, target, expected_hash, retry_seconds=10):
    staged, target = Path(staged), Path(target)
    incoming = target.with_name(target.name + '.update')
    backup = target.with_name(target.name + '.previous')
    if target.is_symlink() or staged.is_symlink():
        raise UpdateError('Update paths must be regular files.')
    shutil.copyfile(staged, incoming)
    try:
        if file_hash(incoming) != expected_hash:
            raise UpdateError('Staged update checksum changed.')
        deadline = time.monotonic() + retry_seconds
        try:
            target.replace(backup)
        except PermissionError:
            if time.monotonic() >= deadline:
                raise UpdateError('Cannot replace app in this folder. Current version retained.') from None
            time.sleep(0.2)
    finally:
        try:
            incoming.replace(target)
        except Exception:
            backup.replace(target)
            raise UpdateError('Update replacement failed. Previous app restored.') from None
        incoming.unlink(missing_ok=True)

def apply_update(job_path, public_key, cache_root=None, wait=wait_for_parent, health=None):
    root = (Path(cache_root) if cache_root is not None else update_directory()).resolve()
    path = Path(job_path).resolve()
    version = 'unknown'
    guard = None
    try:
        if path.name != 'job.json' or path.parent.parent != root or str(uuid.UUID(path.parent.name)) != path.parent.name:
            raise UpdateError('Invalid update job location.')
        job = read_json(path)
        manifest = verify_manifest(job.get('manifest'), public_key, VERSION)
        version = manifest['version']
        if manifest['release_id'] != path.parent.name:
            raise UpdateError('Update job does not match release.')
        target = Path(job['target'])
        if not target.is_absolute() or not re.fullmatch('Lomastrap[- ._a-zA-Z0-9()]*\\.exe', target.name, re.IGNORECASE) or target.is_symlink():
            raise UpdateError('Invalid app target.')
        from lomastrap_instance import SingleInstance
        class InstallGuard(SingleInstance):
            def existing_window(self):
                return False


        guard = InstallGuard('Local\\Lomastrap.Update.' + hashlib.sha256(str(target.resolve()).casefold().encode()).hexdigest())
        if not guard.acquire():
            raise UpdateError('An update installer is already running.')
        staged = path.parent / 'download.exe'
        if not staged.is_file() or staged.stat().st_size != manifest['size'] or file_hash(staged) != manifest['sha256']:
            raise UpdateError('Downloaded update changed; current app retained.')
        if not target.is_file() or file_hash(target) != job['old_hash']:
            raise UpdateError('App changed since update check; current app retained.')
        if type(job.get('pid')) is not int or job['pid'] <= 0:
            raise UpdateError('Invalid parent process.')
        if getattr(sys, 'frozen', False) and file_hash(sys.executable) != job['old_hash']:
            raise UpdateError('Installer does not match the running app.')
        wait(job['pid'])
        if health is None:
            report = path.parent / 'health.json'
            result = subprocess.run([str(staged), '--update-self-test', str(report)], timeout=30, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            healthy = result.returncode == 0 and read_json(report).get('ok') is True and read_json(report).get('version') == version
        else:
            healthy = health(staged, version)
        if not healthy:
            raise UpdateError('New app failed its startup self-test. Previous version retained.')
        if file_hash(staged) != manifest['sha256'] or file_hash(target) != job['old_hash']:
            raise UpdateError('Update files changed during installation.')
        atomic_install(staged, target, manifest['sha256'])
        atomic_json(root / 'result.json', {'ok': True, 'version': version, 'message': 'Update installed.'})
        path.unlink(missing_ok=True)
    except Exception as exc:
        message = str(exc) if isinstance(exc, UpdateError) else 'Update installation failed; previous app retained.'
        atomic_json(root / 'result.json', {'ok': False, 'version': version, 'message': message})
        try:
            pass
        finally:
            if guard:
                guard.close()
        return 1
    if guard:
        guard.close()
        return 0
    return 0

