from __future__ import annotations
import abc
import typing
from cryptography import utils
from cryptography.exceptions import UnsupportedAlgorithm, _Reasons
from cryptography.hazmat._oid import ObjectIdentifier
from cryptography.hazmat.bindings._rust import openssl as rust_openssl
from cryptography.hazmat.primitives import _serialization, hashes
from cryptography.hazmat.primitives.asymmetric import utils as asym_utils

class EllipticCurveOID:
    SECP192R1 = ObjectIdentifier('1.2.840.10045.3.1.1')
    SECP224R1 = ObjectIdentifier('1.3.132.0.33')
    SECP256K1 = ObjectIdentifier('1.3.132.0.10')
    SECP256R1 = ObjectIdentifier('1.2.840.10045.3.1.7')
    SECP384R1 = ObjectIdentifier('1.3.132.0.34')
    SECP521R1 = ObjectIdentifier('1.3.132.0.35')
    BRAINPOOLP256R1 = ObjectIdentifier('1.3.36.3.3.2.8.1.1.7')
    BRAINPOOLP384R1 = ObjectIdentifier('1.3.36.3.3.2.8.1.1.11')
    BRAINPOOLP512R1 = ObjectIdentifier('1.3.36.3.3.2.8.1.1.13')

class EllipticCurve(metaclass=abc.ABCMeta):
    @property
    @abc.abstractmethod
    def name(self) -> 'str':
        '''
        The name of the curve. e.g. secp256r1.
        '''

    @property
    @abc.abstractmethod
    def key_size(self) -> 'int':
        '''
        Bit size of a secret scalar for the curve.
        '''

    @property
    @abc.abstractmethod
    def group_order(self) -> 'int':
        """
        The order of the curve's group.
        """


class EllipticCurveSignatureAlgorithm(metaclass=abc.ABCMeta):
    @property
    @abc.abstractmethod
    def algorithm(self) -> 'asym_utils.Prehashed | hashes.HashAlgorithm':
        '''
        The digest algorithm used with this signature.
        '''


class EllipticCurvePrivateKey(metaclass=abc.ABCMeta):
    @abc.abstractmethod
    def exchange(self, algorithm: 'ECDH', peer_public_key: 'EllipticCurvePublicKey') -> 'bytes':
        """
        Performs a key exchange operation using the provided algorithm with the
        provided peer's public key.
        """

    @abc.abstractmethod
    def public_key(self) -> 'EllipticCurvePublicKey':
        '''
        The EllipticCurvePublicKey for this private key.
        '''

    @property
    @abc.abstractmethod
    def curve(self) -> 'EllipticCurve':
        '''
        The EllipticCurve that this key is on.
        '''

    @property
    @abc.abstractmethod
    def key_size(self) -> 'int':
        '''
        Bit size of a secret scalar for the curve.
        '''

    @abc.abstractmethod
    def sign(self, data: 'utils.Buffer', signature_algorithm: 'EllipticCurveSignatureAlgorithm') -> 'bytes':
        '''
        Signs the data
        '''

    @abc.abstractmethod
    def private_numbers(self) -> 'EllipticCurvePrivateNumbers':
        '''
        Returns an EllipticCurvePrivateNumbers.
        '''

    @abc.abstractmethod
    def private_bytes(self, encoding: '_serialization.Encoding', format: '_serialization.PrivateFormat', encryption_algorithm: '_serialization.KeySerializationEncryption') -> 'bytes':
        '''
        Returns the key serialized as bytes.
        '''

    @abc.abstractmethod
    def __copy__(self) -> 'EllipticCurvePrivateKey':
        '''
        Returns a copy.
        '''

    @abc.abstractmethod
    def __deepcopy__(self, memo: 'dict') -> 'EllipticCurvePrivateKey':
        '''
        Returns a deep copy.
        '''


EllipticCurvePrivateKeyWithSerialization = EllipticCurvePrivateKey
EllipticCurvePrivateKey.register(rust_openssl.ec.ECPrivateKey)

class EllipticCurvePublicKey(metaclass=abc.ABCMeta):
    @property
    @abc.abstractmethod
    def curve(self) -> 'EllipticCurve':
        '''
        The EllipticCurve that this key is on.
        '''

    @property
    @abc.abstractmethod
    def key_size(self) -> 'int':
        '''
        Bit size of a secret scalar for the curve.
        '''

    @abc.abstractmethod
    def public_numbers(self) -> 'EllipticCurvePublicNumbers':
        '''
        Returns an EllipticCurvePublicNumbers.
        '''

    @abc.abstractmethod
    def public_bytes(self, encoding: '_serialization.Encoding', format: '_serialization.PublicFormat') -> 'bytes':
        '''
        Returns the key serialized as bytes.
        '''

    @abc.abstractmethod
    def verify(self, signature: 'utils.Buffer', data: 'utils.Buffer', signature_algorithm: 'EllipticCurveSignatureAlgorithm') -> 'None':
        '''
        Verifies the signature of the data.
        '''

    @classmethod
    def from_encoded_point(cls, curve: 'EllipticCurve', data: 'bytes') -> 'EllipticCurvePublicKey':
        utils._check_bytes('data', data)
        if len(data) == 0:
            raise ValueError('data must not be an empty byte string')
        if data[0] not in (2, 3, 4):
            raise ValueError('Unsupported elliptic curve point type')
        return rust_openssl.ec.from_public_bytes(curve, data)

    @abc.abstractmethod
    def __eq__(self, other: 'object') -> 'bool':
        '''
        Checks equality.
        '''

    @abc.abstractmethod
    def __copy__(self) -> 'EllipticCurvePublicKey':
        '''
        Returns a copy.
        '''

    @abc.abstractmethod
    def __deepcopy__(self, memo: 'dict') -> 'EllipticCurvePublicKey':
        '''
        Returns a deep copy.
        '''


EllipticCurvePublicKeyWithSerialization = EllipticCurvePublicKey
EllipticCurvePublicKey.register(rust_openssl.ec.ECPublicKey)
EllipticCurvePrivateNumbers = rust_openssl.ec.EllipticCurvePrivateNumbers
EllipticCurvePublicNumbers = rust_openssl.ec.EllipticCurvePublicNumbers

class SECP521R1(EllipticCurve):
    name = 'secp521r1'
    key_size = 521
    group_order = 6864797660130609714981900799081393217269435300143305409394463459185543183397655394245057746333217197532963996371363321113864768612440380340372808892707005449

class SECP384R1(EllipticCurve):
    name = 'secp384r1'
    key_size = 384
    group_order = 39402006196394479212279040100143613805079739270465446667946905279627659399113263569398956308152294913554433653942643

class SECP256R1(EllipticCurve):
    name = 'secp256r1'
    key_size = 256
    group_order = 115792089210356248762697446949407573529996955224135760342422259061068512044369

class SECP256K1(EllipticCurve):
    name = 'secp256k1'
    key_size = 256
    group_order = 115792089237316195423570985008687907852837564279074904382605163141518161494337

class SECP224R1(EllipticCurve):
    name = 'secp224r1'
    key_size = 224
    group_order = 26959946667150639794667015087019625940457807714424391721682722368061

class SECP192R1(EllipticCurve):
    name = 'secp192r1'
    key_size = 192
    group_order = 6277101735386680763835789423176059013767194773182842284081

class BrainpoolP256R1(EllipticCurve):
    name = 'brainpoolP256r1'
    key_size = 256
    group_order = 76884956397045344220809746629001649092737531784414529538755519063063536359079

class BrainpoolP384R1(EllipticCurve):
    name = 'brainpoolP384r1'
    key_size = 384
    group_order = 21659270770119316173069236842332604979796116387017648600075645274821611501358515537962695117368903252229601718723941

class BrainpoolP512R1(EllipticCurve):
    name = 'brainpoolP512r1'
    key_size = 512
    group_order = 8948962207650232551656602815159153422162609644098354511344597187200057010413418528378981730643524959857451398370029280583094215613882043973354392115544169

_CURVE_TYPES: 'dict[str, EllipticCurve]' = {'prime192v1': SECP192R1(), 'prime256v1': SECP256R1(), 'secp192r1': SECP192R1(), 'secp224r1': SECP224R1(), 'secp256r1': SECP256R1(), 'secp384r1': SECP384R1(), 'secp521r1': SECP521R1(), 'secp256k1': SECP256K1(), 'brainpoolP256r1': BrainpoolP256R1(), 'brainpoolP384r1': BrainpoolP384R1(), 'brainpoolP512r1': BrainpoolP512R1()}

class ECDSA(EllipticCurveSignatureAlgorithm):
    def __init__(self, algorithm: 'asym_utils.Prehashed | hashes.HashAlgorithm', deterministic_signing: 'bool'=False):
        from cryptography.hazmat.backends.openssl.backend import backend
        if deterministic_signing and not backend.ecdsa_deterministic_supported():
            raise UnsupportedAlgorithm('ECDSA with deterministic signature (RFC 6979) is not supported by this version of OpenSSL.', _Reasons.UNSUPPORTED_PUBLIC_KEY_ALGORITHM)
        self._algorithm = algorithm
        self._deterministic_signing = deterministic_signing

    @property
    def algorithm(self) -> 'asym_utils.Prehashed | hashes.HashAlgorithm':
        return self._algorithm

    @property
    def deterministic_signing(self) -> 'bool':
        return self._deterministic_signing


generate_private_key = rust_openssl.ec.generate_private_key

def derive_private_key(private_value: 'int', curve: 'EllipticCurve', backend: 'typing.Any'=None) -> 'EllipticCurvePrivateKey':
    if not isinstance(private_value, int):
        raise TypeError('private_value must be an integer type.')
    if private_value <= 0:
        raise ValueError('private_value must be a positive integer.')
    return rust_openssl.ec.derive_private_key(private_value, curve)

class ECDH:
    pass

_OID_TO_CURVE = {EllipticCurveOID.SECP192R1: SECP192R1, EllipticCurveOID.SECP224R1: SECP224R1, EllipticCurveOID.SECP256K1: SECP256K1, EllipticCurveOID.SECP256R1: SECP256R1, EllipticCurveOID.SECP384R1: SECP384R1, EllipticCurveOID.SECP521R1: SECP521R1, EllipticCurveOID.BRAINPOOLP256R1: BrainpoolP256R1, EllipticCurveOID.BRAINPOOLP384R1: BrainpoolP384R1, EllipticCurveOID.BRAINPOOLP512R1: BrainpoolP512R1}

def get_curve_for_oid(oid: 'ObjectIdentifier') -> 'type[EllipticCurve]':
    try:
        return _OID_TO_CURVE[oid]
    except KeyError:
        raise LookupError('The provided object identifier has no matching elliptic curve class')

