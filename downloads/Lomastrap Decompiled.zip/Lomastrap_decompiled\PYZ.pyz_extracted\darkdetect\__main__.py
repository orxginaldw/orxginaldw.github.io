import darkdetect
print('Current theme: {}'.format(darkdetect.theme()))
