from __future__ import annotations
from cryptography.hazmat.bindings._rust import openssl as rust_openssl
from cryptography.hazmat.primitives.kdf import KeyDerivationFunction
ConcatKDFHash = rust_openssl.kdf.ConcatKDFHash
ConcatKDFHMAC = rust_openssl.kdf.ConcatKDFHMAC
KeyDerivationFunction.register(ConcatKDFHash)
KeyDerivationFunction.register(ConcatKDFHMAC)
__all__ = ['ConcatKDFHMAC', 'ConcatKDFHash']
