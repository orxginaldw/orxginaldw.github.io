'''Owned Windows hotkeys with native delivery and a release-hook safety net.'''

import ctypes
from ctypes import wintypes
from collections import deque
import importlib
import itertools
import logging
import queue
import sys
import threading
import time
import unicodedata
GUIDANCE = ' Close other apps using the key. If Roblox runs as Administrator, run both programs at the same privilege level, preferably normally. On laptops, try Fn with the function key or check Fn Lock.'
KEYS = {'backspace': 8, 'tab': 9, 'enter': 13, 'shift': 16, 'ctrl': 17, 'alt': 18, 'pause': 19, 'capslock': 20, 'esc': 27, 'space': 32, 'pageup': 33, 'pagedown': 34, 'end': 35, 'home': 36, 'left': 37, 'up': 38, 'right': 39, 'down': 40, 'printscreen': 44, 'insert': 45, 'delete': 46, 'win': 91, 'menu': 93, 'multiply': 106, 'add': 107, 'subtract': 109, 'decimal': 110, 'divide': 111, 'numlock': 144, 'scrolllock': 145, 'volumeup': 175, 'volumedown': 174, 'volumemute': 173, 'playpause': 179, 'nexttrack': 176, 'prevtrack': 177, **{'num' + str(i): 96 + i for i in range(10)}}
ALIASES = {'ins': 'insert', 'del': 'delete', 'hm': 'home', 'pu': 'pageup', 'pd': 'pagedown', 'pgup': 'pageup', 'pgdn': 'pagedown', 'prior': 'pageup', 'next': 'pagedown', 'return': 'enter', 'escape': 'esc', 'spacebar': 'space', 'control': 'ctrl', 'windows': 'win', 'super': 'win', 'page up': 'pageup', 'page down': 'pagedown', 'print screen': 'printscreen', 'caps lock': 'capslock', 'scroll lock': 'scrolllock', 'num lock': 'numlock'}

def key_parts(value):
    text = unicodedata.normalize('NFC', str(value)).strip().lower()
    if text == '+':
        text = 'plus'
    elif text.endswith('++'):
        text = text[:-1] + 'plus'
    parts = [part.strip() for part in text.split('+')]
    return [ALIASES.get(part, part) for part in parts]

def character_key(key):
    if sys.platform != 'win32':
        raise ValueError('This character needs the Windows keyboard layout.')
    user = ctypes.WinDLL('user32', use_last_error=True)
    user.GetKeyboardLayout.argtypes = [wintypes.DWORD]
    user.GetKeyboardLayout.restype = ctypes.c_void_p
    user.VkKeyScanExW.argtypes = [wintypes.WCHAR, ctypes.c_void_p]
    user.VkKeyScanExW.restype = ctypes.c_short
    user.GetForegroundWindow.restype = ctypes.c_void_p
    user.GetWindowThreadProcessId.argtypes = [ctypes.c_void_p, ctypes.POINTER(wintypes.DWORD)]
    user.GetWindowThreadProcessId.restype = wintypes.DWORD
    active = user.GetWindowThreadProcessId(user.GetForegroundWindow(), None)
    result = user.VkKeyScanExW(key, user.GetKeyboardLayout(active))
    if result == -1:
        raise ValueError('Key is unavailable in your active Windows keyboard layout.')
    flags = result >> 8 & 7
    mods = (4 if flags & 1 else 0) | (2 if flags & 2 else 0) | (1 if flags & 4 else 0)
    return mods, result & 255

def parse_hotkey(value):
    modifiers = 16384
    if len(str(value)) > 80:
        raise ValueError('Hotkey is too long.')
    parts = key_parts(value)
    mapping = {'alt': 1, 'ctrl': 2, 'shift': 4, 'win': 8}
    for part in parts[:-1]:
        if part not in mapping:
            raise ValueError(f'Unsupported modifier: {part}')
        modifiers |= mapping[part]
    key = parts[-1]
    if key in KEYS:
        return modifiers, KEYS[key]
    if key.startswith('f') and key[1:].isdigit():
        if 1 <= int(key[1:]) <= 24:
            return modifiers, 112 + int(key[1:]) - 1
    if len(key) == 1 and key.isascii() and key.isalnum():
        return modifiers, ord(key.upper())
    if key == 'plus':
        key = '+'
    if len(key) == 1:
        implicit, vk = character_key(key)
        return modifiers | implicit, vk
    raise ValueError('Unsupported hotkey. Use a key name or one keyboard character.')

def canonical_hotkey(value):
    parse_hotkey(value)
    parts = key_parts(value)
    mods = [name for name in ('ctrl', 'alt', 'shift', 'win') if name in parts[:-1]]
    return '+'.join(mods + [parts[-1]])

def display_hotkey(value):
    if str(value).isascii():
        return str(value).upper()
    return str(value)

def validate_bindings(joiner, ping, combat=None, esp=None, panel=None):
    wanted = [('Join Macro', joiner), ('Gank Ping', ping)]
    if combat is not None:
        wanted.append(('Combat', combat))
    if esp is not None:
        wanted.append(('ESP', esp))
    if panel is not None:
        wanted.append(('Active features panel', panel))
    parsed = [parse_hotkey(value) for _, value in wanted]
    for first in range(len(parsed)):
        for second in range(first + 1, len(parsed)):
            if parsed[first] != parsed[second]:
                continue
            raise ValueError(f'{wanted[first][0]} and {wanted[second][0]} must use different keybinds.')
    return tuple((canonical_hotkey(value) for _, value in wanted))

class PairedDelivery:
    '''Pair native key-down and hook key-up notifications without double toggles.

    A missing native notification still produces an action on hook release.
    Credits expire after a second so a lost hook callback cannot suppress future
    fallback presses. This is source pairing, not a debounce of real presses.
    '''

    def __init__(self):
        self.credits = {}

    def accept(self, action, source, now=None):
        now = time.monotonic() if now is None else now
        pair = self.credits.setdefault(action, {'native': deque(), 'hook': deque()})
        for values in pair.values():
            if not values:
                continue
            while now - values[0] > 1:
                values.popleft()
                if not values:
                    continue
        other = 'hook' if source == 'native' else 'native'
        if pair[other]:
            pair[other].popleft()
            return False
        pair[source].append(now)
        return True


class GlobalHotkeys:
    def __init__(self, bindings, events, keyboard_backend=None):
        self.bindings, self.events = list(bindings), events
        self.keyboard_backend = keyboard_backend
        self.stop = threading.Event()
        self.thread = None
        self.thread_id = None
        self.hook_releases = queue.Queue()
        self.delivery = PairedDelivery()
        self.native = {}
        self.hooks = {}
        self.problems = {}
        self.hook_errors = {}
        self.user = None
        self.native_error = ''
        self.commands = queue.Queue()
        self.requests = itertools.count(1)

    def start(self):
        if sys.platform != 'win32':
            self.events.put(('hotkey_status', 'Hotkeys unavailable: Windows is required.'))
            return
        self.thread = threading.Thread(target=self._run, name='hotkeys', daemon=True)
        self.thread.start()

    def _register(self, identifier, key, action):
        mods, vk = parse_hotkey(key)
        getattr(ctypes, 'set_last_error', (lambda value: None))(0)
        result = bool(self.user.RegisterHotKey(None, identifier, mods, vk))
        error = getattr(ctypes, 'get_last_error', (lambda: 0))()
        logging.log(logging.INFO if result else logging.ERROR, 'RegisterHotKey key=%s id=%s result=%s GetLastError=%s', key, identifier, result, error)
        if result:
            self.native[identifier] = key, action
            self.problems.pop(identifier, None)
            return result, error
        self.problems[identifier] = f'{key.upper()} unavailable: RegisterHotKey error {error}'
        return result, error

    def _install_hook(self, identifier, key, action):
        if self.keyboard_backend is False:
            return
        try:
            backend = self.keyboard_backend or importlib.import_module('keyboard')
            hook_key = key
            for source, target in (('pageup', 'page up'), ('pagedown', 'page down'), ('printscreen', 'print screen')):
                hook_key = hook_key.replace(source, target)
            handle = backend.add_hotkey(hook_key, (lambda: self.hook_releases.put(action)), trigger_on_release=True, suppress=False)
            self.hooks[identifier] = backend, handle
            return
        except Exception as exc:
            logging.error('Hotkey hook failed for %s: %s', key, type(exc).__name__)
            self.hook_errors[identifier] = type(exc).__name__

    def _remove(self, identifier):
        native = self.native.pop(identifier, None)
        if native:
            result = bool(self.user.UnregisterHotKey(None, identifier))
            logging.info('UnregisterHotKey id=%s result=%s GetLastError=%s', identifier, result, getattr(ctypes, 'get_last_error', (lambda: 0))())
        hook = self.hooks.pop(identifier, None)
        if hook:
            try:
                hook[0].remove_hotkey(hook[1])
                return
            except Exception:
                logging.exception('Could not remove owned hotkey hook')

    def _report(self, extra=''):
        parts = []
        for identifier, (key, _) in enumerate(self.bindings, 1):
            if identifier in self.problems:
                parts.append(self.problems[identifier] + ('; release-hook fallback ready' if identifier in self.hooks else '; no fallback'))
            elif identifier in self.native:
                parts.append(f'{key.upper()} ready')
            elif identifier in self.hooks:
                parts.append(f'{key.upper()} ready (release-hook fallback)')
            else:
                parts.append(f'{key.upper()} unavailable')
        text = 'Hotkeys: ' + ', '.join(parts)
        if extra:
            text += '. ' + extra
        if self.problems or extra:
            text += '.' + GUIDANCE
        self.events.put(('hotkey_status', text))

    def _emit(self, action, source):
        if self.delivery.accept(action, source):
            key = next((key for key, bound in self.bindings if bound == action))
            self.events.put((action, {'key': key, 'time': time.strftime('%H:%M:%S'), 'source': source}))
            logging.info('Hotkey received key=%s action=%s source=%s', key, action, source)

    def rebind(self, bindings):
        bindings = list(bindings)
        validate_bindings(bindings[0][0], bindings[1][0])
        request = next(self.requests)
        self.commands.put((request, bindings))
        return request

    def _clear_bindings(self):
        for identifier in set(self.native) | set(self.hooks):
            self._remove(identifier)
        self.problems.clear()
        self.hook_errors.clear()
        self.delivery = PairedDelivery()
        try:
            while True:
                self.hook_releases.get_nowait()
        except queue.Empty:
            pass
        if self.user is not None:
            msg = wintypes.MSG()
            while self.user.PeekMessageW(ctypes.byref(msg), None, 786, 786, 1):
                pass

    def _apply(self, bindings, strict):
        self.bindings = list(bindings)
        errors = []
        for identifier, (key, action) in enumerate(self.bindings, 1):
            if self.user is not None:
                result, error = self._register(identifier, key, action)
                if not result:
                    errors.append(f'{key.upper()}: RegisterHotKey error {error}')
            if self.user is None:
                self.problems[identifier] = f'{key.upper()} unavailable: {self.native_error or 'native hotkey API unavailable'}'
            self._install_hook(identifier, key, action)
            if identifier in self.hooks and identifier not in self.native:
                errors = [item for item in errors if not item.startswith(key.upper() + ': RegisterHotKey')]
            if identifier in self.native:
                continue
            if identifier in self.hooks:
                continue
            errors.append(f'{key.upper()}: no available native or keyboard-hook backend')
            if not strict:
                continue
            return errors
        return errors

    def _commands(self):
        try:
            request, bindings = self.commands.get_nowait()
            previous = list(self.bindings)
            self._clear_bindings()
            try:
                errors = self._apply(bindings, strict=True)
            except Exception as exc:
                logging.exception('Rebind failed')
                errors = [f'{type(exc).__name__}: {exc}']
            else:
                error = ''
                if errors:
                    self._clear_bindings()
                    rollback_errors = self._apply(previous, strict=False)
                    error = '; '.join(errors)
                    if rollback_errors:
                        error += '; restoring previous keys: ' + '; '.join(rollback_errors)
                    else:
                        error += '; previous bindings restored'
                self.events.put(('rebind_result', {'request': request, 'ok': not errors, 'bindings': list(self.bindings), 'error': error}))
                self._report(error)
        except queue.Empty:
            return

    def _run(self):
        native_error = ''
        try:
            self.user = ctypes.WinDLL('user32', use_last_error=True)
            self.user.RegisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int, wintypes.UINT, wintypes.UINT]
            self.user.UnregisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int]
            self.user.PeekMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT, wintypes.UINT]
        except Exception as exc:
            self.user = None
            native_error = f'{type(exc).__name__}: {exc}'
            logging.exception('Native hotkey API unavailable')
        self.native_error = native_error
        if sys.platform == 'win32':
            self.thread_id = ctypes.windll.kernel32.GetCurrentThreadId()
        try:
            for identifier, (key, action) in enumerate(self.bindings, 1):
                try:
                    if self.user is not None:
                        self._register(identifier, key, action)
                    else:
                        self.problems[identifier] = f'{key.upper()} unavailable: {native_error}'
                    self._install_hook(identifier, key, action)
                except (ValueError, OSError) as exc:
                    self.problems[identifier] = f'{key.upper()} unavailable: {exc}'
                    continue
            self._report()
            msg = wintypes.MSG()
            if not self.stop.is_set():
                self._commands()
                while self.user is not None:
                    bound = self.native.get(msg.wParam)
                    if bound:
                        self._emit(bound[1], 'native')
                try:
                    while True:
                        self._emit(self.hook_releases.get_nowait(), 'hook')
                except queue.Empty:
                    pass
        except Exception as exc:
            logging.exception('Hotkey message loop failed')
            self.events.put(('hotkey_status', f'Hotkeys failed: {exc}.' + GUIDANCE))
        for identifier in set(self.native) | set(self.hooks):
            self._remove(identifier)

    def close(self):
        self.stop.set()
        if self.thread:
            self.thread.join(timeout=3)


