from __future__ import annotations
__lazy_modules__ = {'array'}
import array
from . import (GimpGradientFile, GimpPaletteFile, ImageColor, PaletteFile)
TYPE_CHECKING = False
if TYPE_CHECKING:
    from collections.abc import Sequence
    from typing import IO
    from . import Image

class ImagePalette:
    '''
    Color palette for palette mapped images

    :param mode: The mode to use for the palette. See:
        :ref:`concept-modes`. Must be "RGB", "RGBA" or "CMYK". Defaults to "RGB"
    :param palette: An optional palette. If given, it must be a bytearray,
        an array or a list of ints between 0-255. The list must consist of
        all channels for one color followed by the next color (e.g. RGBRGBRGB).
        Defaults to an empty palette.
    '''

    ''
    ''
    def __init__(self, mode: 'str'='RGB', palette: 'Sequence[int] | bytes | bytearray | None'=None) -> 'None':
        if mode not in {'RGB', 'CMYK', 'RGBA'}:
            msg = 'unsupported palette mode'
            raise ValueError(msg)
        self.mode = mode
        self.rawmode = None
        self.palette = palette or bytearray()
        self.dirty = None

    @property
    def palette(self) -> 'Sequence[int] | bytes | bytearray':
        return self._palette

    @palette.setter
    def palette(self, palette: 'Sequence[int] | bytes | bytearray') -> 'None':
        self._colors = None
        self._palette = palette

    @property
    def colors(self) -> 'dict[tuple[int, ...], int]':
        if self._colors is None:
            palette = self.palette
            if self.rawmode and self.rawmode != self.mode:
                from . import Image
                im = Image.core.new('P', (0, 0))
                im.putpalette(self.mode, self.rawmode, bytes(palette))
                palette = im.getpalette(self.mode)
            mode_len = len(self.mode)
            self._colors = {}
            for i in range(0, len(palette), mode_len):
                color = tuple(palette[i:i + mode_len])
                if color in self._colors:
                    continue
                self._colors[color] = i // mode_len
        return self._colors

    @colors.setter
    def colors(self, colors: 'dict[tuple[int, ...], int]') -> 'None':
        self._colors = colors

    def copy(self) -> 'ImagePalette':
        new = ImagePalette()
        new.mode = self.mode
        new.rawmode = self.rawmode
        if self.palette is not None:
            new.palette = self.palette[:]
        new.dirty = self.dirty
        return new

    def _tobytes(self) -> 'bytes':
        if isinstance(self.palette, bytes):
            return self.palette
        arr = array.array('B', self.palette)
        return arr.tobytes()

    def getdata(self) -> 'tuple[str, bytes]':
        '''
        Get palette contents in format suitable for the low-level
        ``im.putpalette`` primitive.

        .. warning:: This method is experimental.
        '''

        if self.rawmode:
            return self.rawmode, self._tobytes()
        return self.mode, self.tobytes()

    def tobytes(self) -> 'bytes':
        '''Convert palette to bytes.

        .. warning:: This method is experimental.
        '''

        if self.rawmode:
            msg = 'palette contains raw palette data'
            raise ValueError(msg)
        return self._tobytes()

    tostring = tobytes
    def _new_color_index(self, image: 'Image.Image | None'=None, e: 'Exception | None'=None) -> 'int':
        if not isinstance(self.palette, bytearray):
            self._palette = bytearray(self.palette)
        index = len(self.palette) // len(self.mode)
        special_colors = ()
        if image:
            special_colors = image.info.get('background'), image.info.get('transparency')
            assert isinstance(self._palette, bytearray)
            while index in special_colors:
                self._palette += bytearray(len(self.mode))
                index += 1
        if index >= 256:
            if image:
                for i, count in reversed(list(enumerate(image.histogram()))):
                    if count != 0:
                        continue
                    if i in special_colors:
                        continue
                    index = i
                    break
            if index >= 256:
                msg = 'cannot allocate more than 256 colors'
                raise ValueError(msg) from e
        return index

    def getcolor(self, color: 'tuple[int, ...]', image: 'Image.Image | None'=None) -> 'int':
        '''Given an rgb tuple, allocate palette entry.

        .. warning:: This method is experimental.
        '''

        if self.rawmode:
            msg = 'palette contains raw palette data'
            raise ValueError(msg)
        if isinstance(color, tuple):
            if self.mode == 'RGB':
                if len(color) == 4:
                    if color[3] != 255:
                        msg = 'cannot add non-opaque RGBA color to RGB palette'
                        raise ValueError(msg)
                    color = color[:3]
            elif self.mode == 'RGBA' and len(color) == 3:
                color += (255,)
            try:
                return self.colors[color]
            except KeyError as e:
                index = self._new_color_index(image, e)
                assert isinstance(self._palette, bytearray)
                mode_len = len(self.mode)
                if index * mode_len < len(self.palette):
                    self._palette = self._palette[:index * mode_len] + bytes(color) + self._palette[index * mode_len + mode_len:]
                    self._colors = None
                else:
                    self._palette += bytes(color)
                self.colors[color] = index
                self.dirty = 1
                return index
        msg = f'unknown color specifier: {repr(color)}'
        raise ValueError(msg)
        e = None
        del e

    def save(self, fp: 'str | IO[str]') -> 'None':
        '''Save palette to text file.

        .. warning:: This method is experimental.
        '''

        if self.rawmode:
            msg = 'palette contains raw palette data'
            raise ValueError(msg)
        open_fp = False
        if isinstance(fp, str):
            fp = open(fp, 'w')
            open_fp = True
        try:
            fp.write('# Palette\n')
            fp.write(f'# Mode: {self.mode}\n')
            palette_len = len(self.palette)
            for i in range(256):
                fp.write(f'{i}')
                for j in range(i * len(self.mode), (i + 1) * len(self.mode)):
                    fp.write(f' {self.palette[j] if j < palette_len else 0}')
                fp.write('\n')
        finally:
            if open_fp:
                fp.close()


def raw(rawmode: 'str', data: 'Sequence[int] | bytes | bytearray') -> 'ImagePalette':
    palette = ImagePalette()
    if rawmode != 'RGB':
        palette.rawmode = rawmode
    palette.palette = data
    palette.dirty = 1
    return palette

def make_linear_lut(black: 'int', white: 'float') -> 'list[int]':
    if black == 0:
        return [int(white * i // 255) for i in range(256)]
    msg = 'unavailable when black is non-zero'
    raise NotImplementedError(msg)

def make_gamma_lut(exp: 'float') -> 'list[int]':
    return [int((i / 255.0) ** exp * 255.0 + 0.5) for i in range(256)]

def negative(mode: 'str'='RGB') -> 'ImagePalette':
    palette = list(range(256 * len(mode)))
    palette.reverse()
    return ImagePalette(mode, [i // len(mode) for i in palette])

def random(mode: 'str'='RGB') -> 'ImagePalette':
    from random import randint
    palette = [randint(0, 255) for _ in range(256 * len(mode))]
    return ImagePalette(mode, palette)

def sepia(white: 'str'='#fff0c0') -> 'ImagePalette':
    bands = [make_linear_lut(0, band) for band in ImageColor.getrgb(white)]
    return ImagePalette('RGB', [bands[i % 3][i // 3] for i in range(768)])

def wedge(mode: 'str'='RGB') -> 'ImagePalette':
    palette = list(range(256 * len(mode)))
    return ImagePalette(mode, [i // len(mode) for i in palette])

def load(filename: 'str') -> 'tuple[bytes, str]':
    with open(filename, 'rb') as fp:
        paletteHandlers = [GimpPaletteFile.GimpPaletteFile, GimpGradientFile.GimpGradientFile, PaletteFile.PaletteFile]
        for paletteHandler in paletteHandlers:
            try:
                fp.seek(0)
                lut = paletteHandler(fp).getpalette()
                if lut:
                    break
            except (SyntaxError, ValueError):
                continue
        else:
            msg = 'cannot load palette'
            raise OSError(msg)
    return lut

