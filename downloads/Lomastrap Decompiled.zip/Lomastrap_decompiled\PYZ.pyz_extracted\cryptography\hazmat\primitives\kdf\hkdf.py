from __future__ import annotations
from cryptography.hazmat.bindings._rust import openssl as rust_openssl
from cryptography.hazmat.primitives.kdf import KeyDerivationFunction
HKDF = rust_openssl.kdf.HKDF
HKDFExpand = rust_openssl.kdf.HKDFExpand
KeyDerivationFunction.register(HKDF)
KeyDerivationFunction.register(HKDFExpand)
__all__ = ['HKDF', 'HKDFExpand']
