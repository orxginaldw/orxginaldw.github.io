using System;

namespace Merostrap.Access;

internal sealed class AccessException : Exception
{
	public AccessException()
	{
	}

	public AccessException(string code)
		: base(code)
	{
	}

	public AccessException(string message, Exception innerException)
		: base(message, innerException)
	{
	}
}
