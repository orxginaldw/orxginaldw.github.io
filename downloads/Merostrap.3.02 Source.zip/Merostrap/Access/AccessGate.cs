using System;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Threading.Tasks;
using Merostrap.UI.Elements.Dialogs;

namespace Merostrap.Access;

internal static class AccessGate
{
	[CompilerGenerated]
	private sealed class _003C_003Ec__DisplayClass2_0
	{
		public TaskCompletionSource<bool> completion;

		public SignInDialog window;

		internal void _003CEnsureCoreAsync_003Eb__0(object? _, EventArgs _)
		{
			completion.TrySetResult(window.Authenticated);
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _003CEnsureCoreAsync_003Ed__2 : IAsyncStateMachine
	{
		public int _003C_003E1__state;

		public AsyncTaskMethodBuilder<bool> _003C_003Et__builder;

		public bool forceSignIn;

		public bool silent;

		private _003C_003Ec__DisplayClass2_0 _003C_003E8__1;

		private TaskAwaiter<bool> _003C_003Eu__1;

		private void MoveNext()
		{
			int num = _003C_003E1__state;
			bool result;
			try
			{
				TaskAwaiter<bool> awaiter;
				if (num != 0)
				{
					if (num == 1)
					{
						awaiter = _003C_003Eu__1;
						_003C_003Eu__1 = default;
						num = (_003C_003E1__state = -1);
						goto IL_01b7;
					}
					_003C_003E8__1 = new _003C_003Ec__DisplayClass2_0();
				}
				try
				{
					bool flag;
					if (num != 0)
					{
						flag = !forceSignIn;
						if (!flag)
						{
							goto IL_0092;
						}
						awaiter = AccessClient.RestoreSessionAsync().GetAwaiter();
						if (!awaiter.IsCompleted)
						{
							num = (_003C_003E1__state = 0);
							_003C_003Eu__1 = awaiter;
							_003C_003Et__builder.AwaitUnsafeOnCompleted(ref awaiter, ref this);
							return;
						}
					}
					else
					{
						awaiter = _003C_003Eu__1;
						_003C_003Eu__1 = default;
						num = (_003C_003E1__state = -1);
					}
					flag = awaiter.GetResult();
					goto IL_0092;
					IL_0092:
					if (!flag)
					{
						goto end_IL_001d;
					}
					result = true;
					goto end_IL_0007;
					end_IL_001d:;
				}
				catch (Exception ex) when ((ex is HttpRequestException || ex is TaskCanceledException || ex is AccessException || ex is InvalidOperationException || ex is IOException || ex is UnauthorizedAccessException || ex is JsonException) ? true : false)
				{
				}
				if (!silent)
				{
					_003C_003E8__1.completion = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
					_003C_003E8__1.window = new SignInDialog();
					_003C_003E8__1.window.Closed += (object? _, EventArgs _) =>
					{
						_003C_003E8__1.completion.TrySetResult(_003C_003E8__1.window.Authenticated);
					};
					_003C_003E8__1.window.Show();
					awaiter = _003C_003E8__1.completion.Task.GetAwaiter();
					if (!awaiter.IsCompleted)
					{
						num = (_003C_003E1__state = 1);
						_003C_003Eu__1 = awaiter;
						_003C_003Et__builder.AwaitUnsafeOnCompleted(ref awaiter, ref this);
						return;
					}
					goto IL_01b7;
				}
				result = false;
				goto end_IL_0007;
				IL_01b7:
				result = awaiter.GetResult();
				end_IL_0007:;
			}
			catch (Exception exception)
			{
				_003C_003E1__state = -2;
				_003C_003E8__1 = null;
				_003C_003Et__builder.SetException(exception);
				return;
			}
			_003C_003E1__state = -2;
			_003C_003E8__1 = null;
			_003C_003Et__builder.SetResult(result);
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			_003C_003Et__builder.SetStateMachine(stateMachine);
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}
	}

	private static Task<bool>? _pending;

	public static Task<bool> EnsureAsync(bool silent = false, bool forceSignIn = false)
	{
		return Task.FromResult(result: true);
	}

	[AsyncStateMachine(typeof(_003CEnsureCoreAsync_003Ed__2))]
	private static Task<bool> EnsureCoreAsync(bool silent, bool forceSignIn)
	{
		return Task.FromResult(result: true);
	}
}
