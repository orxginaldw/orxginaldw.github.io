using System;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Net.Security;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Merostrap.Integrations.AccountManager;

namespace Merostrap.Access;

internal static class AccessClient
{
	private sealed record ErrorResponse(string Code);

	private sealed record SessionResponse(string? Token, string Username, DateTimeOffset ExpiresAt);

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _003CPublicGameRequestAsync_003Ed__9 : IAsyncStateMachine
	{
		public int _003C_003E1__state;

		public AsyncTaskMethodBuilder<byte[]> _003C_003Et__builder;

		public string path;

		public CancellationToken token;

		private HttpRequestMessage _003Crequest_003E5__2;

		private HttpResponseMessage _003Cresponse_003E5__3;

		private TaskAwaiter<HttpResponseMessage> _003C_003Eu__1;

		private TaskAwaiter<byte[]> _003C_003Eu__2;

		private void MoveNext()
		{
			int num = _003C_003E1__state;
			byte[] result2;
			try
			{
				if ((uint)num > 1u)
				{
					if (_token == null)
					{
						_token = AccountSecurity.GetCredential(CredentialName);
					}
					if (string.IsNullOrEmpty(_token))
					{
						throw new AccessException("invalid_session");
					}
					_003Crequest_003E5__2 = new HttpRequestMessage(HttpMethod.Get, Endpoint(path));
				}
				try
				{
					TaskAwaiter<HttpResponseMessage> awaiter;
					if (num != 0)
					{
						if (num == 1)
						{
							goto IL_010e;
						}
						_003Crequest_003E5__2.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _token);
						_003Crequest_003E5__2.Headers.Add("X-Merostrap-Device", DeviceIdentity.GetHash());
						awaiter = Client.SendAsync(_003Crequest_003E5__2, token).GetAwaiter();
						if (!awaiter.IsCompleted)
						{
							num = (_003C_003E1__state = 0);
							_003C_003Eu__1 = awaiter;
							_003C_003Et__builder.AwaitUnsafeOnCompleted(ref awaiter, ref this);
							return;
						}
					}
					else
					{
						awaiter = _003C_003Eu__1;
						_003C_003Eu__1 = default;
						num = (_003C_003E1__state = -1);
					}
					HttpResponseMessage result = awaiter.GetResult();
					_003Cresponse_003E5__3 = result;
					goto IL_010e;
					IL_010e:
					try
					{
						TaskAwaiter<byte[]> awaiter2;
						if (num != 1)
						{
							_003Cresponse_003E5__3.EnsureSuccessStatusCode();
							awaiter2 = _003Cresponse_003E5__3.Content.ReadAsByteArrayAsync(token).GetAwaiter();
							if (!awaiter2.IsCompleted)
							{
								num = (_003C_003E1__state = 1);
								_003C_003Eu__2 = awaiter2;
								_003C_003Et__builder.AwaitUnsafeOnCompleted(ref awaiter2, ref this);
								return;
							}
						}
						else
						{
							awaiter2 = _003C_003Eu__2;
							_003C_003Eu__2 = default;
							num = (_003C_003E1__state = -1);
						}
						result2 = awaiter2.GetResult();
					}
					finally
					{
						if (num < 0 && _003Cresponse_003E5__3 != null)
						{
							((IDisposable)_003Cresponse_003E5__3).Dispose();
						}
					}
				}
				finally
				{
					if (num < 0 && _003Crequest_003E5__2 != null)
					{
						((IDisposable)_003Crequest_003E5__2).Dispose();
					}
				}
			}
			catch (Exception exception)
			{
				_003C_003E1__state = -2;
				_003Crequest_003E5__2 = null;
				_003Cresponse_003E5__3 = null;
				_003C_003Et__builder.SetException(exception);
				return;
			}
			_003C_003E1__state = -2;
			_003Crequest_003E5__2 = null;
			_003Cresponse_003E5__3 = null;
			_003C_003Et__builder.SetResult(result2);
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			_003C_003Et__builder.SetStateMachine(stateMachine);
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _003CRestoreSessionAsync_003Ed__16 : IAsyncStateMachine
	{
		public int _003C_003E1__state;

		public AsyncTaskMethodBuilder<bool> _003C_003Et__builder;

		public CancellationToken cancellationToken;

		private HttpRequestMessage _003Crequest_003E5__2;

		private HttpResponseMessage _003Cresponse_003E5__3;

		private TaskAwaiter<HttpResponseMessage> _003C_003Eu__1;

		private TaskAwaiter _003C_003Eu__2;

		private TaskAwaiter<SessionResponse?> _003C_003Eu__3;

		private void MoveNext()
		{
			int num = _003C_003E1__state;
			bool result;
			try
			{
				if ((uint)num <= 2u)
				{
					goto IL_005d;
				}
				if ((object)ServiceUri == null)
				{
					result = false;
				}
				else
				{
					if (_token == null)
					{
						_token = AccountSecurity.GetCredential(CredentialName);
					}
					if (!string.IsNullOrEmpty(_token))
					{
						_003Crequest_003E5__2 = new HttpRequestMessage(HttpMethod.Get, Endpoint("v1/auth/session"));
						goto IL_005d;
					}
					result = false;
				}
				goto end_IL_0007;
				IL_005d:
				try
				{
					TaskAwaiter<HttpResponseMessage> awaiter;
					if (num != 0)
					{
						if ((uint)(num - 1) <= 1u)
						{
							goto IL_011c;
						}
						_003Crequest_003E5__2.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _token);
						_003Crequest_003E5__2.Headers.Add("X-Merostrap-Device", DeviceIdentity.GetHash());
						awaiter = Client.SendAsync(_003Crequest_003E5__2, cancellationToken).GetAwaiter();
						if (!awaiter.IsCompleted)
						{
							num = (_003C_003E1__state = 0);
							_003C_003Eu__1 = awaiter;
							_003C_003Et__builder.AwaitUnsafeOnCompleted(ref awaiter, ref this);
							return;
						}
					}
					else
					{
						awaiter = _003C_003Eu__1;
						_003C_003Eu__1 = default;
						num = (_003C_003E1__state = -1);
					}
					HttpResponseMessage result2 = awaiter.GetResult();
					_003Cresponse_003E5__3 = result2;
					goto IL_011c;
					IL_011c:
					try
					{
						TaskAwaiter awaiter2;
						if (num == 1)
						{
							awaiter2 = _003C_003Eu__2;
							_003C_003Eu__2 = default;
							num = (_003C_003E1__state = -1);
							goto IL_01c3;
						}
						TaskAwaiter<SessionResponse> awaiter3;
						if (num == 2)
						{
							awaiter3 = _003C_003Eu__3;
							_003C_003Eu__3 = default;
							num = (_003C_003E1__state = -1);
							goto IL_0231;
						}
						HttpStatusCode statusCode = _003Cresponse_003E5__3.StatusCode;
						if ((statusCode != HttpStatusCode.Unauthorized && statusCode != HttpStatusCode.Forbidden) || 1 == 0)
						{
							awaiter2 = RequireSuccess(_003Cresponse_003E5__3, cancellationToken).GetAwaiter();
							if (!awaiter2.IsCompleted)
							{
								num = (_003C_003E1__state = 1);
								_003C_003Eu__2 = awaiter2;
								_003C_003Et__builder.AwaitUnsafeOnCompleted(ref awaiter2, ref this);
								return;
							}
							goto IL_01c3;
						}
						ClearSession();
						result = false;
						goto end_IL_011c;
						IL_0231:
						SessionResponse result3 = awaiter3.GetResult();
						if ((object)result3 == null || string.IsNullOrEmpty(result3.Username) || result3.ExpiresAt <= DateTimeOffset.UtcNow)
						{
							ClearSession();
							result = false;
						}
						else
						{
							Username = result3.Username;
							result = true;
						}
						goto end_IL_011c;
						IL_01c3:
						awaiter2.GetResult();
						awaiter3 = _003Cresponse_003E5__3.Content.ReadFromJsonAsync<SessionResponse>(cancellationToken).GetAwaiter();
						if (!awaiter3.IsCompleted)
						{
							num = (_003C_003E1__state = 2);
							_003C_003Eu__3 = awaiter3;
							_003C_003Et__builder.AwaitUnsafeOnCompleted(ref awaiter3, ref this);
							return;
						}
						goto IL_0231;
						end_IL_011c:;
					}
					finally
					{
						if (num < 0 && _003Cresponse_003E5__3 != null)
						{
							((IDisposable)_003Cresponse_003E5__3).Dispose();
						}
					}
				}
				finally
				{
					if (num < 0 && _003Crequest_003E5__2 != null)
					{
						((IDisposable)_003Crequest_003E5__2).Dispose();
					}
				}
				end_IL_0007:;
			}
			catch (Exception exception)
			{
				_003C_003E1__state = -2;
				_003Crequest_003E5__2 = null;
				_003Cresponse_003E5__3 = null;
				_003C_003Et__builder.SetException(exception);
				return;
			}
			_003C_003E1__state = -2;
			_003Crequest_003E5__2 = null;
			_003Cresponse_003E5__3 = null;
			_003C_003Et__builder.SetResult(result);
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			_003C_003Et__builder.SetStateMachine(stateMachine);
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _003CSearchGamesAsync_003Ed__11 : IAsyncStateMachine
	{
		public int _003C_003E1__state;

		public AsyncTaskMethodBuilder<string> _003C_003Et__builder;

		public string query;

		public string cursor;

		public CancellationToken token;

		private Encoding _003C_003E7__wrap1;

		private TaskAwaiter<byte[]> _003C_003Eu__1;

		private void MoveNext()
		{
			int num = _003C_003E1__state;
			string result2;
			try
			{
				TaskAwaiter<byte[]> awaiter;
				if (num != 0)
				{
					_003C_003E7__wrap1 = Encoding.UTF8;
					awaiter = PublicGameRequestAsync("v1/roblox/search?value=" + Uri.EscapeDataString(query) + "&cursor=" + Uri.EscapeDataString(cursor), token).GetAwaiter();
					if (!awaiter.IsCompleted)
					{
						num = (_003C_003E1__state = 0);
						_003C_003Eu__1 = awaiter;
						_003C_003Et__builder.AwaitUnsafeOnCompleted(ref awaiter, ref this);
						return;
					}
				}
				else
				{
					awaiter = _003C_003Eu__1;
					_003C_003Eu__1 = default;
					num = (_003C_003E1__state = -1);
				}
				byte[] result = awaiter.GetResult();
				result2 = _003C_003E7__wrap1.GetString(result);
			}
			catch (Exception exception)
			{
				_003C_003E1__state = -2;
				_003C_003Et__builder.SetException(exception);
				return;
			}
			_003C_003E1__state = -2;
			_003C_003Et__builder.SetResult(result2);
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			_003C_003Et__builder.SetStateMachine(stateMachine);
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _003CSignInAsync_003Ed__17 : IAsyncStateMachine
	{
		public int _003C_003E1__state;

		public AsyncTaskMethodBuilder _003C_003Et__builder;

		public string username;

		public string password;

		public CancellationToken cancellationToken;

		private HttpResponseMessage _003Cresponse_003E5__2;

		private TaskAwaiter<HttpResponseMessage> _003C_003Eu__1;

		private TaskAwaiter _003C_003Eu__2;

		private TaskAwaiter<SessionResponse?> _003C_003Eu__3;

		private void MoveNext()
		{
			int num = _003C_003E1__state;
			try
			{
				TaskAwaiter<HttpResponseMessage> awaiter;
				if (num != 0)
				{
					if ((uint)(num - 1) <= 1u)
					{
						goto IL_00c5;
					}
					Uri endpoint = Endpoint("v1/auth/login");
					var payload = new
					{
						username = username,
						password = password,
						device = DeviceIdentity.GetHash()
					};
					awaiter = AccessTransport.SendAsync(Client, () => new HttpRequestMessage(HttpMethod.Post, endpoint)
					{
						Content = JsonContent.Create(payload)
					}, cancellationToken).GetAwaiter();
					if (!awaiter.IsCompleted)
					{
						num = (_003C_003E1__state = 0);
						_003C_003Eu__1 = awaiter;
						_003C_003Et__builder.AwaitUnsafeOnCompleted(ref awaiter, ref this);
						return;
					}
				}
				else
				{
					awaiter = _003C_003Eu__1;
					_003C_003Eu__1 = default;
					num = (_003C_003E1__state = -1);
				}
				HttpResponseMessage result = awaiter.GetResult();
				_003Cresponse_003E5__2 = result;
				goto IL_00c5;
				IL_00c5:
				try
				{
					TaskAwaiter<SessionResponse> awaiter2;
					TaskAwaiter awaiter3;
					if (num != 1)
					{
						if (num == 2)
						{
							awaiter2 = _003C_003Eu__3;
							_003C_003Eu__3 = default;
							num = (_003C_003E1__state = -1);
							goto IL_01a0;
						}
						awaiter3 = RequireSuccess(_003Cresponse_003E5__2, cancellationToken).GetAwaiter();
						if (!awaiter3.IsCompleted)
						{
							num = (_003C_003E1__state = 1);
							_003C_003Eu__2 = awaiter3;
							_003C_003Et__builder.AwaitUnsafeOnCompleted(ref awaiter3, ref this);
							return;
						}
					}
					else
					{
						awaiter3 = _003C_003Eu__2;
						_003C_003Eu__2 = default;
						num = (_003C_003E1__state = -1);
					}
					awaiter3.GetResult();
					awaiter2 = _003Cresponse_003E5__2.Content.ReadFromJsonAsync<SessionResponse>(cancellationToken).GetAwaiter();
					if (!awaiter2.IsCompleted)
					{
						num = (_003C_003E1__state = 2);
						_003C_003Eu__3 = awaiter2;
						_003C_003Et__builder.AwaitUnsafeOnCompleted(ref awaiter2, ref this);
						return;
					}
					goto IL_01a0;
					IL_01d8:
					throw new AccessException("unavailable");
					IL_01a0:
					SessionResponse result2 = awaiter2.GetResult();
					if ((object)result2 == null)
					{
						goto IL_01d8;
					}
					string? token = result2.Token;
					if (token == null || token.Length != 64 || result2.ExpiresAt <= DateTimeOffset.UtcNow)
					{
						goto IL_01d8;
					}
					_token = result2.Token;
					Username = result2.Username;
					AccountSecurity.SetCredential(CredentialName, _token);
				}
				finally
				{
					if (num < 0 && _003Cresponse_003E5__2 != null)
					{
						((IDisposable)_003Cresponse_003E5__2).Dispose();
					}
				}
			}
			catch (Exception exception)
			{
				_003C_003E1__state = -2;
				_003Cresponse_003E5__2 = null;
				_003C_003Et__builder.SetException(exception);
				return;
			}
			_003C_003E1__state = -2;
			_003Cresponse_003E5__2 = null;
			_003C_003Et__builder.SetResult();
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			_003C_003Et__builder.SetStateMachine(stateMachine);
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _003CSignOutAsync_003Ed__18 : IAsyncStateMachine
	{
		public int _003C_003E1__state;

		public AsyncTaskMethodBuilder _003C_003Et__builder;

		private HttpRequestMessage _003Crequest_003E5__2;

		private TaskAwaiter<HttpResponseMessage> _003C_003Eu__1;

		private void MoveNext()
		{
			int num = _003C_003E1__state;
			try
			{
				if (num == 0)
				{
					goto IL_002a;
				}
				string token = _token;
				ClearSession();
				if (!string.IsNullOrEmpty(token) && (object)ServiceUri != null)
				{
					goto IL_002a;
				}
				goto end_IL_0007;
				IL_002a:
				try
				{
					if (num != 0)
					{
						_003Crequest_003E5__2 = new HttpRequestMessage(HttpMethod.Post, Endpoint("v1/auth/logout"));
					}
					try
					{
						TaskAwaiter<HttpResponseMessage> awaiter;
						if (num != 0)
						{
							_003Crequest_003E5__2.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
							awaiter = Client.SendAsync(_003Crequest_003E5__2).GetAwaiter();
							if (!awaiter.IsCompleted)
							{
								num = (_003C_003E1__state = 0);
								_003C_003Eu__1 = awaiter;
								_003C_003Et__builder.AwaitUnsafeOnCompleted(ref awaiter, ref this);
								return;
							}
						}
						else
						{
							awaiter = _003C_003Eu__1;
							_003C_003Eu__1 = default;
							num = (_003C_003E1__state = -1);
						}
						HttpResponseMessage result = awaiter.GetResult();
						try
						{
						}
						finally
						{
							if (num < 0)
							{
								((IDisposable)result)?.Dispose();
							}
						}
					}
					finally
					{
						if (num < 0 && _003Crequest_003E5__2 != null)
						{
							((IDisposable)_003Crequest_003E5__2).Dispose();
						}
					}
					_003Crequest_003E5__2 = null;
				}
				catch (Exception ex) when ((ex is HttpRequestException || ex is TaskCanceledException) ? true : false)
				{
				}
				end_IL_0007:;
			}
			catch (Exception exception)
			{
				_003C_003E1__state = -2;
				_003C_003Et__builder.SetException(exception);
				return;
			}
			_003C_003E1__state = -2;
			_003C_003Et__builder.SetResult();
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			_003C_003Et__builder.SetStateMachine(stateMachine);
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}
	}

	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _003CSubplacesAsync_003Ed__12 : IAsyncStateMachine
	{
		public int _003C_003E1__state;

		public AsyncTaskMethodBuilder<string> _003C_003Et__builder;

		public long id;

		public CancellationToken token;

		private Encoding _003C_003E7__wrap1;

		private TaskAwaiter<byte[]> _003C_003Eu__1;

		private void MoveNext()
		{
			int num = _003C_003E1__state;
			string result2;
			try
			{
				TaskAwaiter<byte[]> awaiter;
				if (num != 0)
				{
					_003C_003E7__wrap1 = Encoding.UTF8;
					awaiter = PublicGameRequestAsync($"v1/roblox/subplaces/{id}", token).GetAwaiter();
					if (!awaiter.IsCompleted)
					{
						num = (_003C_003E1__state = 0);
						_003C_003Eu__1 = awaiter;
						_003C_003Et__builder.AwaitUnsafeOnCompleted(ref awaiter, ref this);
						return;
					}
				}
				else
				{
					awaiter = _003C_003Eu__1;
					_003C_003Eu__1 = default;
					num = (_003C_003E1__state = -1);
				}
				byte[] result = awaiter.GetResult();
				result2 = _003C_003E7__wrap1.GetString(result);
			}
			catch (Exception exception)
			{
				_003C_003E1__state = -2;
				_003C_003Et__builder.SetException(exception);
				return;
			}
			_003C_003E1__state = -2;
			_003C_003Et__builder.SetResult(result2);
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			_003C_003Et__builder.SetStateMachine(stateMachine);
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}
	}

	private static readonly HttpClient Client = new HttpClient(new SocketsHttpHandler
	{
		AllowAutoRedirect = false,
		UseProxy = true,
		ConnectTimeout = TimeSpan.FromSeconds(20L),
		PooledConnectionLifetime = TimeSpan.FromMinutes(2L),
		PooledConnectionIdleTimeout = TimeSpan.FromSeconds(30L),
		SslOptions = new SslClientAuthenticationOptions
		{
			CertificateRevocationCheckMode = X509RevocationMode.Online
		}
	})
	{
		Timeout = TimeSpan.FromSeconds(30L)
	};

	private static string? _token;

	public static string? Username { get; private set; }

	public static Uri? ServiceUri
	{
		get
		{
			if (!Uri.TryCreate((typeof(App).Assembly.GetCustomAttributes<AssemblyMetadataAttribute>().FirstOrDefault((AssemblyMetadataAttribute attribute) => attribute.Key == "AccessServiceUrl")?.Value)?.TrimEnd('/') + "/", UriKind.Absolute, out Uri result))
			{
				return null;
			}
			if (result.Scheme == Uri.UriSchemeHttps && string.IsNullOrEmpty(result.UserInfo))
			{
				return result;
			}
			return null;
		}
	}

	private static string CredentialName => "access-session:" + ServiceUri?.AbsoluteUri;

	internal static HttpRequestMessage UpdateRequest(string path)
	{
		throw new AccessException("unavailable");
	}

	[AsyncStateMachine(typeof(_003CPublicGameRequestAsync_003Ed__9))]
	private static Task<byte[]> PublicGameRequestAsync(string path, CancellationToken token)
	{
		return Task.FromResult(new byte[0]);
	}

	internal static Task<byte[]> GameIconAsync(ulong id, CancellationToken token)
	{
		return Task.FromResult(new byte[0]);
	}

	[AsyncStateMachine(typeof(_003CSearchGamesAsync_003Ed__11))]
	internal static Task<string> SearchGamesAsync(string query, CancellationToken token = default(CancellationToken), string cursor = "")
	{
		return Task.FromResult("[]");
	}

	[AsyncStateMachine(typeof(_003CSubplacesAsync_003Ed__12))]
	internal static Task<string> SubplacesAsync(long id, CancellationToken token)
	{
		return Task.FromResult("[]");
	}

	private static Uri Endpoint(string path)
	{
		return new Uri(ServiceUri ?? throw new AccessException("not_configured"), path);
	}

	[AsyncStateMachine(typeof(_003CRestoreSessionAsync_003Ed__16))]
	public static Task<bool> RestoreSessionAsync(CancellationToken cancellationToken = default(CancellationToken))
	{
		return Task.FromResult(result: false);
	}

	[AsyncStateMachine(typeof(_003CSignInAsync_003Ed__17))]
	public static Task SignInAsync(string username, string password, CancellationToken cancellationToken)
	{
		return Task.FromException(new AccessException("unavailable"));
	}

	[AsyncStateMachine(typeof(_003CSignOutAsync_003Ed__18))]
	public static Task SignOutAsync()
	{
		/*Error: ldarg 0 (out-of-bounds)*/;
		ClearSession();
		return Task.CompletedTask;
	}

	private static void ClearSession()
	{
		_token = null;
		Username = null;
		AccountSecurity.DeleteCredential(CredentialName);
	}

	private static async Task RequireSuccess(HttpResponseMessage response, CancellationToken token)
	{
		if (response.IsSuccessStatusCode)
		{
			return;
		}
		App.Logger.Warn($"Access service returned HTTP {(int)response.StatusCode}.");
		if (response.StatusCode == HttpStatusCode.TooManyRequests)
		{
			throw new AccessException("rate_limited");
		}
		string code = "unavailable";
		try
		{
			code = (await response.Content.ReadFromJsonAsync<ErrorResponse>(token))?.Code ?? code;
		}
		catch (JsonException)
		{
		}
		throw new AccessException(code);
	}
}
