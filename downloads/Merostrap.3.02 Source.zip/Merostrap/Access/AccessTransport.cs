using System;
using System.Diagnostics;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;

namespace Merostrap.Access;

internal static class AccessTransport
{
	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _003CSendAsync_003Ed__0 : IAsyncStateMachine
	{
		public int _003C_003E1__state;

		public AsyncTaskMethodBuilder<HttpResponseMessage> _003C_003Et__builder;

		public CancellationToken cancellationToken;

		public Func<HttpRequestMessage> createRequest;

		public HttpClient client;

		private int _003Cattempt_003E5__2;

		private HttpRequestMessage _003Crequest_003E5__3;

		private TaskAwaiter<HttpResponseMessage> _003C_003Eu__1;

		private TaskAwaiter _003C_003Eu__2;

		private void MoveNext()
		{
			int num = _003C_003E1__state;
			HttpResponseMessage result;
			try
			{
				if ((uint)num > 1u)
				{
					_003Cattempt_003E5__2 = 0;
					goto IL_0012;
				}
				goto IL_002f;
				IL_018c:
				_003Crequest_003E5__3 = null;
				_003Cattempt_003E5__2++;
				goto IL_0012;
				IL_0012:
				cancellationToken.ThrowIfCancellationRequested();
				_003Crequest_003E5__3 = createRequest();
				goto IL_002f;
				IL_002f:
				try
				{
					TaskAwaiter awaiter;
					int num2;
					if (num != 0)
					{
						if (num == 1)
						{
							awaiter = _003C_003Eu__2;
							_003C_003Eu__2 = default;
							num = (_003C_003E1__state = -1);
							goto IL_016b;
						}
						num2 = 0;
					}
					try
					{
						TaskAwaiter<HttpResponseMessage> awaiter2;
						if (num != 0)
						{
							awaiter2 = client.SendAsync(_003Crequest_003E5__3, cancellationToken).GetAwaiter();
							if (!awaiter2.IsCompleted)
							{
								num = (_003C_003E1__state = 0);
								_003C_003Eu__1 = awaiter2;
								_003C_003Et__builder.AwaitUnsafeOnCompleted(ref awaiter2, ref this);
								return;
							}
						}
						else
						{
							awaiter2 = _003C_003Eu__1;
							_003C_003Eu__1 = default;
							num = (_003C_003E1__state = -1);
						}
						result = awaiter2.GetResult();
					}
					catch (HttpRequestException ex) when (((Func<bool>)delegate
					{
						// Could not convert BlockContainer to single expression
						bool flag = _003Cattempt_003E5__2 == 0;
						if (flag)
						{
							flag = (uint)(ex.HttpRequestError - 1) <= 1u;
						}
						return flag;
					}).Invoke())
					{
						num2 = 1;
						goto IL_0100;
					}
					goto end_IL_002f;
					IL_0100:
					if (num2 == 1)
					{
						awaiter = Task.Delay(TimeSpan.FromMilliseconds(500L), cancellationToken).GetAwaiter();
						if (!awaiter.IsCompleted)
						{
							num = (_003C_003E1__state = 1);
							_003C_003Eu__2 = awaiter;
							_003C_003Et__builder.AwaitUnsafeOnCompleted(ref awaiter, ref this);
							return;
						}
						goto IL_016b;
					}
					goto IL_018c;
					IL_016b:
					awaiter.GetResult();
					goto IL_018c;
					end_IL_002f:;
				}
				finally
				{
					if (num < 0 && _003Crequest_003E5__3 != null)
					{
						((IDisposable)_003Crequest_003E5__3).Dispose();
					}
				}
			}
			catch (Exception exception)
			{
				_003C_003E1__state = -2;
				_003C_003Et__builder.SetException(exception);
				return;
			}
			_003C_003E1__state = -2;
			_003C_003Et__builder.SetResult(result);
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			_003C_003Et__builder.SetStateMachine(stateMachine);
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}
	}

	[AsyncStateMachine(typeof(_003CSendAsync_003Ed__0))]
	internal static Task<HttpResponseMessage> SendAsync(HttpClient client, Func<HttpRequestMessage> createRequest, CancellationToken cancellationToken)
	{
		return Task.FromException<HttpResponseMessage>(new AccessException("unavailable"));
	}
}
