using System;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace Merostrap.Access;

internal static class DeviceIdentity
{
	public static string GetHash()
	{
		string text;
		if (OperatingSystem.IsWindows())
		{
			using RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
			using RegistryKey registryKey2 = registryKey.OpenSubKey("SOFTWARE\\Microsoft\\Cryptography");
			text = registryKey2?.GetValue("MachineGuid") as string;
		}
		else if (OperatingSystem.IsLinux())
		{
			text = File.ReadAllText("/etc/machine-id").Trim();
		}
		else if (OperatingSystem.IsMacOS())
		{
			using Process process = Process.Start(new ProcessStartInfo("/usr/sbin/ioreg", "-rd1 -c IOPlatformExpertDevice")
			{
				RedirectStandardOutput = true,
				RedirectStandardError = true,
				UseShellExecute = false,
				CreateNoWindow = true
			}) ?? throw new InvalidOperationException("device_unavailable");
			Task<string> task = process.StandardOutput.ReadToEndAsync();
			Task<string> task2 = process.StandardError.ReadToEndAsync();
			if (!process.WaitForExit(5000))
			{
				process.Kill();
				throw new InvalidOperationException("device_unavailable");
			}
			string result = task.GetAwaiter().GetResult();
			task2.GetAwaiter().GetResult();
			Match match = Regex.Match(result, "\"IOPlatformUUID\"\\s*=\\s*\"([^\"]+)\"");
			text = (match.Success ? match.Groups[1].Value : null);
		}
		else
		{
			text = null;
		}
		if (string.IsNullOrWhiteSpace(text))
		{
			throw new InvalidOperationException("device_unavailable");
		}
		return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes("Merostrap/device/v1/" + text.Trim().ToUpperInvariant())));
	}
}
