using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Animation;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Input;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Styling;
using Avalonia.Threading;
using CompiledAvaloniaXaml;
using FluentAvalonia.Styling;
using Merostrap.AppData;
using Merostrap.Enums;
using Merostrap.Enums.BootstrapperDialogs;
using Merostrap.Enums.Messagebox;
using Merostrap.Extensions;
using Merostrap.Integrations;
using Merostrap.Macros;
using Merostrap.Models.APIs.GitHub;
using Merostrap.Models.Attributes;
using Merostrap.Models.Persistable;
using Merostrap.Models.SettingTasks.Base;
using Merostrap.Resources;
using Merostrap.UI;
using Merostrap.UI.Converters;
using Merostrap.UI.Elements.About;
using Merostrap.UI.Elements.Base;
using Merostrap.Utility;
using Microsoft.Win32;
using NLog;

namespace Merostrap;

internal class App : Application
{
	[CompilerGenerated]
	private class XamlClosure_1
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<App> serviceProvider = CreateContext(P_0);
			return new StaticResourceExtension
			{
				ResourceKey = "ToolTipBackgroundBrush"
			}.ProvideValue(serviceProvider);
		}

		public static XamlIlContext.Context<App> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<App> context = new XamlIlContext.Context<App>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FApp_002Eaxaml.Singleton }, "avares://Merostrap/App.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (App)service;
				}
			}
			return context;
		}

		public static object Build_2(IServiceProvider P_0)
		{
			XamlIlContext.Context<App> serviceProvider = CreateContext(P_0);
			return new StaticResourceExtension
			{
				ResourceKey = "ToolTipForegroundBrush"
			}.ProvideValue(serviceProvider);
		}

		public static object Build_3(IServiceProvider P_0)
		{
			XamlIlContext.Context<App> context = CreateContext(P_0);
			return new FontFamily(((IUriContext)context).BaseUri, "avares://Merostrap/Resources/Fonts/Rubik-VariableFont_wght.ttf");
		}

		public static object Build_4(IServiceProvider P_0)
		{
			XamlIlContext.Context<App> context = CreateContext(P_0);
			return new FontFamily(((IUriContext)context).BaseUri, "avares://Merostrap/Resources/Fonts#BuilderIcons-Regular");
		}

		public static object Build_5(IServiceProvider P_0)
		{
			XamlIlContext.Context<App> context = CreateContext(P_0);
			return new FontFamily(((IUriContext)context).BaseUri, "avares://Merostrap/Resources/Fonts#BuilderIcons-Filled");
		}

		public static object Build_6(IServiceProvider P_0)
		{
			XamlIlContext.Context<App> context = CreateContext(P_0);
			return new StringFormatConverter();
		}

		public static object Build_7(IServiceProvider P_0)
		{
			XamlIlContext.Context<App> context = CreateContext(P_0);
			return new EnumNameConverter();
		}

		public static object Build_8(IServiceProvider P_0)
		{
			XamlIlContext.Context<App> context = CreateContext(P_0);
			return new EnumToBoolConverter();
		}

		public static object Build_9(IServiceProvider P_0)
		{
			XamlIlContext.Context<App> context = CreateContext(P_0);
			return new NumberAbbreviationConverter();
		}
	}

	public static bool AboutOpen;

	private const string MockReleaseTagEnvironmentVariable = "MOCK_RELEASE_TAG";

	private const string MockCurrentVersionEnvironmentVariable = "MOCK_CURRENT_VERSION";

	public const string ProjectName = "Merostrap";

	public const string DiscordApplicationId = "";

	public const string ProjectOwner = "Merostrap";

	public const string ProjectRepository = "";

	public const string ProjectDownloadLink = "";

	public const string ProjectHelpLink = "https://github.com/bloxstraplabs/bloxstrap/wiki";

	public const string ProjectSupportLink = "";

	public const string ProjectRemoteDataLink = "";

	public const string UninstallKey = "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Merostrap";

	public const string ApisKey = "Software\\Merostrap";

	public static readonly BuildMetadataAttribute BuildMetadata = Assembly.GetExecutingAssembly().GetCustomAttribute<BuildMetadataAttribute>();

	public static readonly string Version = (Assembly.GetExecutingAssembly().GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion ?? "unknown+asteo").Split("+")[0];

	public static readonly string InternalVersion;

	public static readonly RobloxPlayerData PlayerData;

	public static readonly RobloxStudioData StudioData;

	public static readonly Logger Logger;

	public static readonly Dictionary<string, BaseTask> PendingSettingTasks;

	public static readonly JsonManager<Settings> Settings;

	public static readonly JsonManager<State> State;

	public static readonly SoberSettingsManager SoberSettings;

	public static readonly LazyJsonManager<DistributionState> PlayerState;

	public static readonly LazyJsonManager<DistributionState> StudioState;

	public static readonly RemoteDataManager RemoteData;

	public static readonly FastFlagManager FastFlags;

	public static readonly GBSEditor GlobalSettings;

	public static readonly CookiesManager Cookies;

	public static readonly HttpClient HttpClient;

	private static bool _showingExceptionDialog;

	private static readonly Lock ActivationLock;

	private static string? _pendingActivationUri;

	private static bool _launchArgsProcessed;

	private static List<Style>? _disableAnimationStyles;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public static string RobloxPlayerAppName
	{
		get
		{
			if (!OperatingSystem.IsMacOS())
			{
				return "RobloxPlayerBeta.exe";
			}
			return "RobloxPlayer.app";
		}
	}

	public static string RobloxStudioAppName
	{
		get
		{
			if (!OperatingSystem.IsMacOS())
			{
				return "RobloxStudioBeta.exe";
			}
			return "RobloxStudio.app";
		}
	}

	public static LaunchSettings LaunchSettings { get; internal set; } = null;

	public static Bootstrapper? Bootstrapper { get; set; }

	public MerostrapRichPresence? RichPresence { get; private set; }

	public static bool IsActionBuild => !string.IsNullOrEmpty(BuildMetadata.CommitRef);

	public static bool IsProductionBuild
	{
		get
		{
			if (IsActionBuild)
			{
				return BuildMetadata.CommitRef.StartsWith("tag", StringComparison.Ordinal);
			}
			return false;
		}
	}

	public static string? MockReleaseTag => GetEnvironmentVariable("MOCK_RELEASE_TAG");

	public static bool IsMockReleaseEnabled => !string.IsNullOrWhiteSpace(MockReleaseTag);

	public static string? MockCurrentVersion => GetEnvironmentVariable("MOCK_CURRENT_VERSION");

	public static bool IsPlayerInstalled => PlayerData.IsInstalled;

	public static bool IsStudioInstalled => StudioData.IsInstalled;

	public static MerostrapRichPresence? FrostRPC
	{
		get
		{
			return (Application.Current as App)?.RichPresence;
		}
		set
		{
			if (Application.Current is App app && app.RichPresence != value)
			{
				app.RichPresence?.Dispose();
				app.RichPresence = value;
			}
		}
	}

	private void About_OnClick(object? sender, EventArgs e)
	{
		if (!AboutOpen)
		{
			new MainWindow().Show();
			AboutOpen = true;
		}
	}

	private static string? GetEnvironmentVariable(params string[] names)
	{
		for (int i = 0; i < names.Length; i++)
		{
			string environmentVariable = Environment.GetEnvironmentVariable(names[i]);
			if (!string.IsNullOrWhiteSpace(environmentVariable))
			{
				return environmentVariable;
			}
		}
		return null;
	}

	private async void OnUnhandledException(object? sender, UnhandledExceptionEventArgs e)
	{
		if (e.ExceptionObject is Exception ex)
		{
			await FinalizeExceptionHandling(ex);
		}
	}

	private void OnUnobservedTaskException(object? sender, UnobservedTaskExceptionEventArgs e)
	{
		e.SetObserved();
		Logger.Error(e.Exception, "An unobserved background task exception occurred.");
	}

	public static void Terminate(ErrorCode exitCode = ErrorCode.ERROR_SUCCESS)
	{
		Logger.Debug($"Terminating with exit code {(int)exitCode} ({exitCode})");
		MacroWorkspace.StopInputs();
		Environment.Exit((int)exitCode);
	}

	public static void SoftTerminate(ErrorCode exitCode = ErrorCode.ERROR_SUCCESS)
	{
		int value = (int)exitCode;
		Logger.Debug($"Terminating with exit code {value} ({exitCode})");
		Avalonia.Threading.Dispatcher.UIThread.Invoke(() =>
		{
			if (Application.Current?.ApplicationLifetime is IClassicDesktopStyleApplicationLifetime classicDesktopStyleApplicationLifetime)
			{
				classicDesktopStyleApplicationLifetime.Shutdown((int)exitCode);
			}
		});
	}

	private async void GlobalExceptionHandler(object sender, DispatcherUnhandledExceptionEventArgs e)
	{
		e.Handled = true;
		Logger.Error("An exception occurred: " + e.Exception.Message);
		await FinalizeExceptionHandling(e.Exception);
	}

	public static async Task FinalizeExceptionHandling(AggregateException ex)
	{
		foreach (Exception innerException in ex.InnerExceptions)
		{
			Logger.Error("Unhandled exception: ", innerException);
		}
		await FinalizeExceptionHandling(ex.GetBaseException(), log: false);
	}

	public static async Task FinalizeExceptionHandling(Exception ex, bool log = true)
	{
		if (log)
		{
			Logger.Error(ex, "Unhandled exception");
		}
		if (ex is IOException && ex.InnerException is SocketException { ErrorCode: 125 })
		{
			Logger.Error("Ignoring expected cancellation IOException on shutdown (ECANCELED).");
		}
		else if (ex is OperationCanceledException)
		{
			Logger.Error("Ignoring OperationCanceledException on shutdown.");
		}
		else
		{
			if (_showingExceptionDialog)
			{
				return;
			}
			_showingExceptionDialog = true;
			if (Bootstrapper?.Dialog != null)
			{
				if (Bootstrapper.Dialog.TaskbarProgressValue == 0.0)
				{
					Bootstrapper.Dialog.TaskbarProgressValue = 1.0;
				}
				Bootstrapper.Dialog.TaskbarProgressState = TaskbarItemProgressState.Error;
			}
			if (IsNetworkException(ex))
			{
				await Frontend.ShowConnectivityDialog(Strings.Dialog_Connectivity_UnableToConnect, "Network Error", MessageBoxImage.Warning, ex);
				using InterProcessLock interProcessLock = new InterProcessLock("Bootstrapper", TimeSpan.Zero);
				if (!interProcessLock.IsAcquired)
				{
					Logger.Error("Bootstrapper is running, closing.");
					Terminate(ErrorCode.ERROR_INSTALL_FAILURE);
				}
				return;
			}
			await Frontend.ShowExceptionDialog(ex);
			Terminate(ErrorCode.ERROR_INSTALL_FAILURE);
		}
	}

	private static bool IsNetworkException(Exception? ex)
	{
		while (ex != null)
		{
			if (ex is HttpRequestException || ex is SocketException || ex is WebException || ex is TaskCanceledException)
			{
				return true;
			}
			ex = ex.InnerException;
		}
		return false;
	}

	public static string ExtractIcon(string name, string fileName)
	{
		string text = Path.Combine(Paths.Base, fileName);
		if (!File.Exists(text))
		{
			using Stream stream = Resource.GetStream(name);
			Directory.CreateDirectory(Path.GetDirectoryName(text));
			using FileStream destination = File.Create(text);
			stream.CopyTo(destination);
		}
		return text;
	}

	public static Task AssertWindowsAUMIDAsync()
	{
		if (OperatingSystem.IsWindows())
		{
			using RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Software\\Classes\\AppUserModelId\\xyz.merostrap.desktop");
			registryKey.SetValue("DisplayName", "Merostrap");
			registryKey.DeleteValue("IconUri", throwOnMissingValue: false);
		}
		return Task.CompletedTask;
	}

	public static void ApplyAnimationSettings()
	{
		Application current = Application.Current;
		if (current != null)
		{
			RemoveAnimationSettings();
			_disableAnimationStyles = new List<Style>();
			Style style = new Style((Selector? x) => x.OfType<Control>());
			style.Setters.Add(new Setter(Animatable.TransitionsProperty, null));
			_disableAnimationStyles.Add(style);
			current.Styles.Add(style);
			current.Resources["FadeDuration"] = TimeSpan.Zero;
			current.Resources["SlideDuration"] = TimeSpan.Zero;
			Logger.Debug("Animations disabled globally.");
		}
	}

	public static void RemoveAnimationSettings()
	{
		Application current = Application.Current;
		if (current == null)
		{
			return;
		}
		if (_disableAnimationStyles != null)
		{
			foreach (Style disableAnimationStyle in _disableAnimationStyles)
			{
				current.Styles.Remove(disableAnimationStyle);
			}
			_disableAnimationStyles = null;
		}
		current.Resources.Remove("FadeDuration");
		current.Resources.Remove("SlideDuration");
		Logger.Debug("Animations re‑enabled.");
	}

	public override void Initialize()
	{
		_0021XamlIlPopulateTrampoline(this);
		AppDomain.CurrentDomain.UnhandledException += OnUnhandledException;
		TaskScheduler.UnobservedTaskException += OnUnobservedTaskException;
		if (OperatingSystem.IsMacOS() && TryGetFeature(typeof(IActivatableLifetime)) is IActivatableLifetime activatableLifetime)
		{
			activatableLifetime.Activated += OnAppActivated;
		}
	}

	private static void OnAppActivated(object? sender, ActivatedEventArgs e)
	{
		if (!OperatingSystem.IsMacOS() || !(e is ProtocolActivatedEventArgs e2) || e.Kind != ActivationKind.OpenUri)
		{
			return;
		}
		string originalString = e2.Uri.OriginalString;
		using (ActivationLock.EnterScope())
		{
			if (!_launchArgsProcessed)
			{
				if (LaunchSettings != null && LaunchSettings.RobloxLaunchMode == LaunchMode.None)
				{
					LaunchSettings.TryResolveRobloxUri(new _003C_003Ez__ReadOnlySingleElementList<string>(originalString));
				}
				else if (LaunchSettings == null)
				{
					_pendingActivationUri = originalString;
				}
				return;
			}
		}
		Logger.Info("Received activation URI: " + originalString);
		LaunchHandler.HandleActivationUri(originalString);
	}

	public static async Task<GithubRelease?> GetLatestRelease(bool includePreRelease = false)
	{
		if (string.IsNullOrWhiteSpace(""))
		{
			return null;
		}
		try
		{
			if (IsMockReleaseEnabled)
			{
				string text = MockReleaseTag ?? "v0.0.0-mock";
				Logger.Debug("Using mocked release " + text);
				return new GithubRelease
				{
					TagName = text,
					Name = text,
					Body = "Mock release",
					Prerelease = true,
					CreatedAt = DateTime.UtcNow.ToString("o"),
					Assets = new List<GithubReleaseAsset>()
				};
			}
			string uriString = (includePreRelease ? "https://api.github.com/repos//releases" : "https://api.github.com/repos//releases/latest");
			if (includePreRelease)
			{
				List<GithubRelease> list = await Http.GetJson<List<GithubRelease>>(new Uri(uriString));
				if (list == null || list.Count == 0)
				{
					Logger.Info("No releases found");
					return null;
				}
				return list[0];
			}
			return await Http.GetJson<GithubRelease>(new Uri(uriString));
		}
		catch (Exception value)
		{
			Logger.Error($"Unhandled exception {value}");
			return null;
		}
	}

	public override async void OnFrameworkInitializationCompleted()
	{
		if (!(ApplicationLifetime is IClassicDesktopStyleApplicationLifetime classicDesktopStyleApplicationLifetime))
		{
			return;
		}
		classicDesktopStyleApplicationLifetime.ShutdownMode = ShutdownMode.OnExplicitShutdown;
		classicDesktopStyleApplicationLifetime.Exit += (object? _, ControlledApplicationLifetimeExitEventArgs _) =>
		{
			MacroWorkspace.Shutdown();
			FrostRPC = null;
		};
		Paths.Initialize();
		GlobalDiagnosticsContext.Set("logRoot", Paths.Logs);
		GlobalDiagnosticsContext.Set("startTime", DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss", CultureInfo.InvariantCulture));
		Logger.Debug($"Starting {"Merostrap"} {Version} ({Paths.Process})");
		Logger.Debug("OS Description: " + RuntimeInformation.OSDescription);
		Logger.Debug("Built for RID: " + RuntimeInformation.RuntimeIdentifier);
		StringBuilder stringBuilder = new StringBuilder("Merostrap/" + Version);
		if (IsActionBuild)
		{
			Logger.Debug($"Compiled {BuildMetadata.Timestamp.ToFriendlyString()} from commit {BuildMetadata.CommitHash} ({BuildMetadata.CommitRef})");
			stringBuilder.Append(IsProductionBuild ? " (Production)" : $" (Artifact {BuildMetadata.CommitHash}, {BuildMetadata.CommitRef})");
		}
		else
		{
			Logger.Debug("Compiled " + BuildMetadata.Timestamp.ToFriendlyString());
			stringBuilder.Append(string.Format(CultureInfo.InvariantCulture, " (Build {0})", Convert.ToBase64String(Encoding.UTF8.GetBytes(BuildMetadata.Machine))));
		}
		HttpClient.Timeout = TimeSpan.FromSeconds(60L);
		if (HttpClient.DefaultRequestHeaders.UserAgent.Count == 0)
		{
			HttpClient.DefaultRequestHeaders.Add("User-Agent", stringBuilder.ToString());
		}
		using (ActivationLock.EnterScope())
		{
			if (LaunchSettings.RobloxLaunchMode == LaunchMode.None && _pendingActivationUri != null)
			{
				LaunchSettings.TryResolveRobloxUri(new _003C_003Ez__ReadOnlySingleElementList<string>(_pendingActivationUri));
			}
		}
		Settings.Load();
		State.Load();
		bool num = LaunchSettings.WatcherFlag.Active && Settings.Prop.Performance.UseLeanRuntime;
		if (!num)
		{
			Task.Run((Func<Task?>)RemoteData.LoadData);
		}
		if (Settings.Prop.Theme > Theme.Custom)
		{
			Settings.Prop.Theme = Theme.Dark;
			Settings.Save();
		}
		AvaloniaWindow.ApplyTheme();
		Locale.Set(Settings.Prop.Locale);
		if (Settings.Prop.DisableAnimations || Settings.Prop.Performance.UseReducedAnimations)
		{
			ApplyAnimationSettings();
		}
		if (State.Prop.IsFirstLaunch)
		{
			LaunchSettings.OnboardingFlag.Active = true;
			Logger.Info("First launch detected, launching onboarding.");
		}
		if (!num)
		{
			Task.Run(async () =>
			{
				_ = 2;
				try
				{
					FastFlags.Load();
					GlobalSettings.Load();
					if (OperatingSystem.IsLinux())
					{
						SoberSettings.Load(alertFailure: false);
					}
					AssertWindowsAUMIDAsync();
					await Updater.RunMigrations();
					if (!LaunchSettings.BypassUpdateCheck && !OperatingSystem.IsLinux() && !OperatingSystem.IsMacOS())
					{
						await Updater.HandleUpgrade();
					}
					if (Settings.Prop.AllowCookieAccess)
					{
						await Cookies.LoadCookies();
					}
					if (OperatingSystem.IsLinux())
					{
						LinuxRegistry.RegisterAll();
					}
				}
				catch (Exception exception)
				{
					Logger.Error(exception, "Background initialisation failed");
				}
			});
		}
		using (ActivationLock.EnterScope())
		{
			_launchArgsProcessed = true;
		}
		await LaunchHandler.ProcessLaunchArgs();
		base.OnFrameworkInitializationCompleted();
	}

	static App()
	{
		string text = Assembly.GetExecutingAssembly().GetName().Version.ToString();
		InternalVersion = text.Substring(0, text.Length - 2);
		Bootstrapper = null;
		PlayerData = new RobloxPlayerData();
		StudioData = new RobloxStudioData();
		Logger = LogManager.GetCurrentClassLogger();
		PendingSettingTasks = new Dictionary<string, BaseTask>();
		Settings = new JsonManager<Settings>();
		State = new JsonManager<State>();
		SoberSettings = new SoberSettingsManager();
		PlayerState = new LazyJsonManager<DistributionState>("PlayerState");
		StudioState = new LazyJsonManager<DistributionState>("StudioState");
		RemoteData = new RemoteDataManager();
		FastFlags = new FastFlagManager();
		GlobalSettings = new GBSEditor();
		Cookies = new CookiesManager();
		HttpClient = new HttpClient(new HttpClientLoggingHandler(new HttpClientHandler
		{
			AutomaticDecompression = DecompressionMethods.All
		}));
		ActivationLock = new Lock();
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, App P_1)
	{
		XamlIlContext.Context<App> context = new XamlIlContext.Context<App>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FApp_002Eaxaml.Singleton }, "avares://Merostrap/App.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		App app2;
		App app = (app2 = P_1);
		context.PushParent(app2);
		app2.Name = "Merostrap";
		app2.RequestedThemeVariant = ThemeVariant.Dark;
		NativeMenu nativeMenu = new NativeMenu();
		IList<NativeMenuItemBase> items = nativeMenu.Items;
		NativeMenuItem nativeMenuItem = new NativeMenuItem();
		nativeMenuItem.Header = "About Merostrap";
		nativeMenuItem.Click += context.RootObject.About_OnClick;
		items.Add(nativeMenuItem);
		IList<NativeMenuItemBase> items2 = nativeMenu.Items;
		NativeMenuItem nativeMenuItem2 = new NativeMenuItem();
		nativeMenuItem2.Header = "Settings";
		nativeMenuItem2.Gesture = KeyGesture.Parse("Meta+,");
		items2.Add(nativeMenuItem2);
		NativeMenu.SetMenu(app2, nativeMenu);
		Styles styles = app2.Styles;
		FluentAvaloniaTheme fluentAvaloniaTheme = new FluentAvaloniaTheme();
		fluentAvaloniaTheme.PreferSystemTheme = true;
		fluentAvaloniaTheme.PreferUserAccentColor = true;
		styles.Add(fluentAvaloniaTheme);
		app2.Styles.Add(_0021AvaloniaResources.Build_003A_002FUI_002FElements_002FControls_002FHyperlink_002Eaxaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(context)));
		app2.Styles.Add(_0021AvaloniaResources.Build_003A_002FUI_002FElements_002FControls_002FOptionControl_002Eaxaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(context)));
		app2.Styles.Add(_0021AvaloniaResources.Build_003A_002FUI_002FElements_002FControls_002FSquareCard_002Eaxaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(context)));
		app2.Styles.Add(_0021AvaloniaResources.Build_003A_002FUI_002FElements_002FControls_002FCard_002Eaxaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(context)));
		app2.Styles.Add(_0021AvaloniaResources.Build_003A_002FUI_002FElements_002FControls_002FCardExpander_002Eaxaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(context)));
		app2.Styles.Add(_0021AvaloniaResources.Build_003A_002FUI_002FElements_002FControls_002FTitleBar_002Eaxaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(context)));
		app2.Styles.Add(_0021AvaloniaResources.Build_003A_002FUI_002FElements_002FControls_002FCardAction_002Eaxaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(context)));
		app2.Styles.Add(_0021AvaloniaResources.Build_003A_002FUI_002FElements_002FControls_002FIconButton_002Eaxaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(context)));
		app2.Styles.Add(_0021AvaloniaResources.Build_003A_002FThemes_002FFluent_002FAvaloniaEdit_002Examl(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(context)));
		app2.Styles.Add(_0021AvaloniaResources.Build_003A_002FUI_002FAppThemes_002FDefault_002Eaxaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(context)));
		app2.Styles.Add(_0021AvaloniaResources.Build_003A_002FUI_002FAppThemes_002FWelcome_002Eaxaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(context)));
		ResourceDictionary resourceDictionary;
		ResourceDictionary resources = (resourceDictionary = new ResourceDictionary());
		context.PushParent(resourceDictionary);
		if (resourceDictionary is ResourceDictionary resourceDictionary2)
		{
			resourceDictionary2.EnsureCapacity(resourceDictionary2.Count + 9);
		}
		resourceDictionary.MergedDictionaries.Add(_0021AvaloniaResources.Build_003A_002FTemplates_002FHueSlider_002Eaxaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(context)));
		resourceDictionary.MergedDictionaries.Add(_0021AvaloniaResources.Build_003A_002FTemplates_002FSquareSlider_002Eaxaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(context)));
		resourceDictionary.MergedDictionaries.Add(_0021AvaloniaResources.Build_003A_002FTemplates_002FSquarePicker_002Eaxaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(context)));
		resourceDictionary.MergedDictionaries.Add(_0021AvaloniaResources.Build_003A_002FLucide_002FResourcesIcons_002Eaxaml(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(context)));
		resourceDictionary.AddDeferred("ToolTipBackground", XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<object>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_1.Build_1), context));
		resourceDictionary.AddDeferred("ToolTipForeground", XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<object>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_1.Build_2), context));
		resourceDictionary.AddDeferred("Rubik", XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<object>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_1.Build_3), context));
		resourceDictionary.AddDeferred("BuilderIconsRegular", XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<object>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_1.Build_4), context));
		resourceDictionary.AddDeferred("BuilderIconsFilled", XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<object>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_1.Build_5), context));
		resourceDictionary.AddDeferred("StringFormatConverter", XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<object>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_1.Build_6), context));
		resourceDictionary.AddDeferred("EnumNameConverter", XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<object>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_1.Build_7), context));
		resourceDictionary.AddDeferred("EnumToBoolConverter", XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<object>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_1.Build_8), context));
		resourceDictionary.AddDeferred("NumberAbbreviationConverter", XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<object>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_1.Build_9), context));
		context.PopParent();
		app2.Resources = resources;
		context.PopParent();
		if (app is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(App P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
