using System;
using System.Runtime.InteropServices;

namespace Merostrap.Macros;

internal sealed class DiscordFocusGuard : IDisposable
{
	private readonly nint _discord;

	private readonly nint _foreground;

	private readonly bool _minimized;

	private readonly Action<bool> _report;

	public DiscordFocusGuard(nint discord, Action<bool> report)
	{
		_discord = discord;
		_report = report;
		_foreground = GetForegroundWindow();
		_minimized = IsIconic(discord);
	}

	public static bool ShouldRestore(nint original, nint current, nint discord)
	{
		if (original != 0 && original != discord)
		{
			return current == discord;
		}
		return false;
	}

	public void Restore()
	{
		nint foregroundWindow = GetForegroundWindow();
		if (ShouldRestore(_foreground, foregroundWindow, _discord) && IsWindow(_foreground))
		{
			SetForegroundWindow(_foreground);
		}
		if (_minimized && !IsIconic(_discord))
		{
			ShowWindow(_discord, 7);
		}
	}

	public void Dispose()
	{
		Restore();
		_report(GetForegroundWindow() == _foreground);
	}

	[DllImport("user32.dll")]
	private static extern nint GetForegroundWindow();

	[DllImport("user32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool IsIconic(nint window);

	[DllImport("user32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool IsWindow(nint window);

	[DllImport("user32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool SetForegroundWindow(nint window);

	[DllImport("user32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool ShowWindow(nint window, int command);
}
