using System;
using System.Collections.Generic;

namespace Merostrap.Macros;

public static class MacroCatalog
{
	public static IReadOnlyList<MacroDefinition> All { get; } = Build();

	internal static Dictionary<string, MacroEntry> CreateEntries()
	{
		Dictionary<string, MacroEntry> dictionary = new Dictionary<string, MacroEntry>(StringComparer.Ordinal);
		foreach (MacroDefinition item in All)
		{
			MacroEntry macroEntry = new MacroEntry();
			foreach (MacroField field in item.Fields)
			{
				macroEntry.Values[field.Key] = field.DefaultValue;
			}
			dictionary.Add(item.Id, macroEntry);
		}
		return dictionary;
	}

	private static IReadOnlyList<MacroDefinition> Build()
	{
		List<MacroDefinition> list = new List<MacroDefinition>();
		list.Add(Define("hold-m1", "Faster Hold M1", "Combat", "Hold your alternate attack key while holding the primary mouse button.", new MacroField("keyToPress", "Alternate attack key", "`", "One keyboard character bound to primary attack in Roblox. Default: backtick (`).")));
		list.Add(Define("right-mouse-parry", "Right mouse button parry", "Combat", "Press F immediately when you right-click. Keeps the normal right-click action."));
		list.Add(Define("auto-feint", "Auto Feint", "Combat", "Trigger a feint with the secondary mouse button when parry (F) is pressed."));
		list.Add(Define("auto-roll-cancel", "Auto Roll Cancel", "Combat", "Cancel a roll with the secondary mouse button."));
		list.Add(Define("auto-uppercut", "Auto Uppercut", "Combat", "Repeat primary attacks while holding Ctrl for an uppercut."));
		list.Add(Define("dynamic-auto-uppercut", "Dynamic Auto Uppercut", "Combat", "Combine directional input and primary attack with an uppercut.", Boolean("toRoll", "Roll after uppercut", "Send the roll key after the uppercut.")));
		list.Add(Define("uppercut-assassinate", "Uppercut Assassinate", "Combat", "Chain an uppercut into an assassination.", Bind()));
		list.Add(Define("roll-crit", "Roll Crit", "Combat", "Follow the critical attack key (R) with a roll (Q)."));
		list.Add(Define("roll-m1", "Roll M1", "Combat", "Run the recorded Roll M1 sequence from your hotkey.", Bind(), Boolean("highPing", "High ping (100+ ms)", "Off uses the low-ping sequence; on uses the high-ping sequence.")));
		list.Add(Define("roll-parry", "Roll Parry", "Combat", "Chain a roll and parry from your hotkey.", Bind()));
		list.Add(Define("bell-stack-dodge", "Bell Stack Dodge", "Combat", "Follow the bell key (C) with a dodge (Q)."));
		list.Add(Define("bell-stack-parry", "Bell Stack Parry", "Combat", "Parry (F) before using the bell key (C)."));
		list.Add(Define("silentheart-flow-state", "Automatic Flow State", "Silentheart", "Activate Flow State before slide attacks, dodge attacks, aerial follow-ups and Ctrl + Feint. Set its toolbar key first.", FlowState(), new MacroField("dodgekeybind", "Dodge key", "q", "Your Roblox dodge key. Default: Q."), new MacroField("crouchkeybind", "Crouch key", "ctrl", "Your Roblox crouch / slide key. Rising Star still uses Ctrl."), new MacroField("jumpkeybind", "Jump key", "space", "Your Roblox jump key. Default: Space."), new MacroField("feintkeybind", "Feint / cancel key", "mouse2", "Your Roblox feint / cancel key. Default: right mouse button.")));
		list.Add(Define("ankle-cutter", "Ankle Cutter", "Silentheart", "Trigger the Ankle Cutter sequence with your Flow State key.", Bind(), FlowState()));
		list.Add(Define("mayhem", "Mayhem", "Silentheart", "Trigger the Mayhem sequence with your Flow State key.", Bind(), FlowState()));
		list.Add(Define("relentless-hunt", "Relentless Hunt", "Silentheart", "Trigger the Relentless Hunt sequence with your Flow State key.", Bind(), FlowState()));
		list.Add(Define("rising-star", "Rising Star", "Silentheart", "Trigger the Rising Star sequence with your Flow State key.", Bind(), FlowState()));
		list.Add(Define("ritual-cast", "Ritual Cast", "Mantras", "Press the configured hotkey to detect and complete one ritual. Escape cancels the current run.", Bind(), Coordinates("startcoordinates", "Prompt top-left"), Coordinates("endcoordinates", "Prompt bottom-right"), new MacroField("ping_ms", "Ping compensation (ms)", "100", "Tunes key press duration from 50 to 150 ms; waits for visible prompt advancement before the next key. Whole number from 0 to 1000. Include the entire outlined ritual frame and both prompt rows; exclude the title.")));
		list.Add(Define("auto-buy", "Auto Buy", "Inventory", "Drag the purchase quantity slider and confirm purchases.", Bind(), Coordinates("startcoordinates", "Slider start"), Coordinates("endcoordinates", "Slider end"), Coordinates("submitcoordinates", "Buy button")));
		list.Add(Define("auto-drop-notes", "Auto Drop Notes", "Inventory", "Select notes, set the amount and confirm each drop.", Bind(), Repetitions(), Coordinates("notecoordinates", "Notes item"), Coordinates("startcoordinates", "Slider start"), Coordinates("endcoordinates", "Slider end"), Coordinates("confirmationcoordinates", "Confirm button")));
		list.Add(Define("auto-eat", "Auto Eat", "Inventory", "Find your chosen food in the inventory and use it.", Bind(), new MacroField("foodname", "Food name", "", "Exact food name to type into the inventory search."), Coordinates("boxcoordinates", "Inventory search"), Coordinates("foodcoordinates", "Food item")));
		list.Add(Define("auto-sell", "Auto Sell", "Inventory", "Select an item and confirm each sale.", Bind(), Repetitions(), Coordinates("itemcoordinates", "Item to sell"), Coordinates("confirmationcoordinates", "Confirm button")));
		list.Add(Define("motif-swap", "Motif Swap", "Inventory", "Equip a motif, use it, then equip your weapon.", Bind(), new MacroField("motifnum", "Motif toolbar slot", "1", "Toolbar slot key: a digit from 0 to 9. Default: 1."), new MacroField("weaponnum", "Weapon toolbar slot", "2", "Toolbar slot key: a digit from 0 to 9. Default: 2.")));
		list.Add(Define("tacet-toggle", "Tacet Toggle", "Utility", "Crouch, activate Tacet, and optionally stand again.", Bind(), Boolean("uncrouch", "Stand after Tacet", "Uncrouch after activating Tacet.")));
		list.Add(Define("auto-log", "Auto Log", "Utility", "Click the configured logout location and confirm with Shift.", Bind(), Coordinates("coordinates", "Logout button")));
		list.Add(Define("auto-pender", "Auto Pender", "Utility", "Toggle repeated clicks alternating between two screen points. Press the hotkey again to stop.", Bind(), Coordinates("firstcoordinates", "Point 1"), Coordinates("secondcoordinates", "Point 2"), new MacroField("interval_ms", "Delay between clicks (ms)", "100", "Wait after each click before moving to the other point. Whole number from 20 to 5000 milliseconds. Escape or leaving Roblox stops the loop.")));
		list.Add(Define("flash-map", "Flash Map", "Utility", "Show the map while holding M and close it when released."));
		list.Add(Define("golden-tongue", "Golden Tongue", "Chat", "Send your configured phrase through Roblox chat.", ChatFields()));
		list.Add(Define("mb-all", "Mb All", "Chat", "Send “mb all” through Roblox chat.", Bind()));
		list.Add(Define("trash-talk", "Trash Talk", "Chat", "Send a random line from your chosen text file.", Bind(), new MacroField("txtpath", "Message file", "", "Full path to a UTF-8 text file with one chat message per line.")));
		list.Add(Define("gank-pinger", "Gank Pinger", "Chat", "Send your saved message to a Discord webhook once per hotkey press.", Bind(), new MacroField("delivery_mode", "Delivery", "0", "Send through a webhook or your personal account."), new MacroField("webhook_url", "Discord webhook", "", "Full HTTPS Discord webhook URL."), new MacroField("discord_token", "Discord token", "", "Stored encrypted for your Windows account."), new MacroField("channel_id", "Channel ID", "", "Discord channel to receive the alert."), new MacroField("message", "Message", "", "Message to send, up to 2000 characters."), new MacroField("capture_window", "Screenshot window", "", "Select a window to attach, or leave screenshots off.")));
		List<MacroDefinition> list2 = list;
		for (int i = 1; i <= 10; i++)
		{
			list2.Add(Define($"chat-message-{i}", $"Chat Message {i}", "Chat", "Send a saved message through Roblox chat.", ChatFields()));
		}
		return list2.AsReadOnly();
	}

	private static MacroDefinition Define(string id, string name, string category, string description, params MacroField[] fields)
	{
		return new MacroDefinition(id, name, category, description, Array.AsReadOnly(fields));
	}

	private static MacroField Bind()
	{
		return new MacroField("keybind", "Hotkey", "", "One keyboard key, numpad key, or side mouse button (Mouse 4/5). Leave blank until configured.");
	}

	private static MacroField Binds()
	{
		return new MacroField("keybinds", "Mantra keys", "", "Comma-separated keyboard keys, such as 1,2,3. Each key triggers the sequence.");
	}

	private static MacroField FlowState()
	{
		return new MacroField("flowstatekeybind", "Flow State key", "", "Keyboard key bound to Flow State in Roblox, such as 4.");
	}

	private static MacroField Coordinates(string key, string label)
	{
		return new MacroField(key, label, "", "Screen pixel coordinates as X Y, such as 960 540. Configure for your current display and game window.");
	}

	private static MacroField Repetitions()
	{
		return new MacroField("repetitions", "Repetitions", "1", "Positive whole number of repetitions. Default: 1.");
	}

	private static MacroField Boolean(string key, string label, string action)
	{
		return new MacroField(key, label, "false", "true or false. " + action + " Default: false.");
	}

	private static MacroField[] ChatFields()
	{
		return new MacroField[3]
		{
			Bind(),
			new MacroField("content", "Message", "", "Chat text to send. Unicode text is supported."),
			Boolean("autosprint", "Resume sprint", "Resume forward sprint after sending the message.")
		};
	}
}
