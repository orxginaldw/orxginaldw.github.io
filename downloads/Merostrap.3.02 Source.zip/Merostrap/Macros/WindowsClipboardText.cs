using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Merostrap.Macros;

public static class WindowsClipboardText
{
	public static Task CopyAsync(string text, CancellationToken token)
	{
		return Task.Run(() =>
		{
			Copy(text, token);
		}, token);
	}

	private static void Copy(string text, CancellationToken token)
	{
		if (!OperatingSystem.IsWindows())
		{
			throw new PlatformNotSupportedException();
		}
		int length = text.Length;
		if ((length < 1 || length > 500) ? true : false)
		{
			throw new ArgumentException("Invalid training phrase.");
		}
		nint num = CreateWindowEx(0u, "STATIC", "", 0u, 0, 0, 0, 0, new IntPtr(-3), IntPtr.Zero, IntPtr.Zero, IntPtr.Zero);
		if (num == IntPtr.Zero)
		{
			throw new Win32Exception(Marshal.GetLastWin32Error(), "Cannot create clipboard owner.");
		}
		try
		{
			for (int i = 0; i < 10; i++)
			{
				token.ThrowIfCancellationRequested();
				if (!OpenClipboard(num))
				{
					if (token.WaitHandle.WaitOne(20))
					{
						token.ThrowIfCancellationRequested();
					}
					continue;
				}
				nint num2 = IntPtr.Zero;
				try
				{
					token.ThrowIfCancellationRequested();
					byte[] bytes = Encoding.Unicode.GetBytes(text + "\0");
					num2 = GlobalAlloc(2u, (nuint)bytes.Length);
					if (num2 == IntPtr.Zero)
					{
						throw new Win32Exception();
					}
					nint num3 = GlobalLock(num2);
					if (num3 == IntPtr.Zero)
					{
						throw new Win32Exception();
					}
					try
					{
						Marshal.Copy(bytes, 0, num3, bytes.Length);
					}
					finally
					{
						GlobalUnlock(num2);
					}
					if (!EmptyClipboard() || SetClipboardData(13u, num2) == IntPtr.Zero)
					{
						throw new Win32Exception(Marshal.GetLastWin32Error(), "Could not copy the charisma phrase.");
					}
					num2 = IntPtr.Zero;
					return;
				}
				finally
				{
					if (num2 != IntPtr.Zero)
					{
						GlobalFree(num2);
					}
					CloseClipboard();
				}
			}
			throw new InvalidOperationException("Clipboard is busy; Auto Charisma paused.");
		}
		finally
		{
			DestroyWindow(num);
		}
	}

	[DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
	private static extern nint CreateWindowEx(uint extended, string className, string title, uint style, int x, int y, int width, int height, nint parent, nint menu, nint instance, nint parameter);

	[DllImport("user32.dll")]
	private static extern bool DestroyWindow(nint window);

	[DllImport("user32.dll", SetLastError = true)]
	private static extern bool OpenClipboard(nint window);

	[DllImport("user32.dll")]
	private static extern bool CloseClipboard();

	[DllImport("user32.dll", SetLastError = true)]
	private static extern bool EmptyClipboard();

	[DllImport("user32.dll", SetLastError = true)]
	private static extern nint SetClipboardData(uint format, nint memory);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern nint GlobalAlloc(uint flags, nuint bytes);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern nint GlobalLock(nint memory);

	[DllImport("kernel32.dll")]
	private static extern bool GlobalUnlock(nint memory);

	[DllImport("kernel32.dll")]
	private static extern nint GlobalFree(nint memory);
}
