using System;
using System.Collections.Generic;

namespace Merostrap.Macros;

public sealed class MacroEntry
{
	public bool Enabled { get; set; }

	public Dictionary<string, string> Values { get; set; } = new Dictionary<string, string>(StringComparer.Ordinal);
}
