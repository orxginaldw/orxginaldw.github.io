namespace Merostrap.Macros;

public sealed record MacroBindingSummary(string Name, string Keys);
