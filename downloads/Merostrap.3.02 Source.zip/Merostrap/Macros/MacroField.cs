namespace Merostrap.Macros;

public sealed record MacroField(string Key, string Label, string DefaultValue, string Help);
