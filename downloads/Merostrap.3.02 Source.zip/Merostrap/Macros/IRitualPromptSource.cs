using System;
using System.Threading;
using Merostrap.Macros.Health;

namespace Merostrap.Macros;

public interface IRitualPromptSource : IDisposable
{
	HealthRegion? DetectRegion(CancellationToken token)
	{
		return null;
	}

	RitualFrame Read(HealthRegion region);
}
