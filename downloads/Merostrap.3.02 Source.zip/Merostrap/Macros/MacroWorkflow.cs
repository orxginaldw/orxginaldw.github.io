using System;
using System.Threading.Tasks;

namespace Merostrap.Macros;

internal sealed record MacroWorkflow(string Id, string[] Triggers, Func<MacroActions, string?, Task> Execute, MacroRunMode Mode = MacroRunMode.Once, bool OnRelease = false, bool Suppress = false, SilentheartFlowDetector? FlowDetector = null, string? FlowStateKey = null);
