namespace Merostrap.Macros;

internal enum MacroRunMode
{
	Once,
	Toggle,
	Hold,
	Automatic
}
