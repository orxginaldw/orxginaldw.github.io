using Merostrap.Macros.Health;

namespace Merostrap.Macros;

public sealed record CharismaFrame(string Quote, string Entered, bool Reliable = true, HealthRegion? InputArea = null);
