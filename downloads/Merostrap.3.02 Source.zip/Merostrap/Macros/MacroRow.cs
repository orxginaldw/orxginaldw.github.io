using System;
using System.Collections.Generic;
using System.Linq;
using CommunityToolkit.Mvvm.ComponentModel;
using LucideAvalonia.Enum;
using Merostrap.Macros.Health;

namespace Merostrap.Macros;

public sealed class MacroRow : ObservableObject
{
	private bool _expanded;

	private readonly MacroEntry _entry;

	private readonly Action _changed;

	public bool Expanded
	{
		get
		{
			return _expanded;
		}
		set
		{
			if (SetProperty(ref _expanded, value, "Expanded"))
			{
				OnPropertyChanged("DisclosureIcon");
				OnPropertyChanged("ShowDetails");
			}
		}
	}

	public LucideIconNames DisclosureIcon
	{
		get
		{
			if (!Expanded)
			{
				return LucideIconNames.ChevronDown;
			}
			return LucideIconNames.ChevronUp;
		}
	}

	public MacroDefinition Definition { get; }

	public string Name => Definition.Name;

	public string Category => Definition.Category;

	public string Description => Definition.Description;

	public bool Supported => MacroEngine.GetSupport(Definition.Id).Supported;

	public string SupportNote => MacroEngine.GetSupport(Definition.Id).Reason;

	public bool Unavailable => !Supported;

	public bool Enabled
	{
		get
		{
			return _entry.Enabled;
		}
		set
		{
			if (_entry.Enabled != value)
			{
				_entry.Enabled = value;
				OnPropertyChanged("Enabled");
				OnPropertyChanged("ShowDetails");
				_changed();
			}
		}
	}

	public IReadOnlyList<MacroFieldRow> Fields { get; }

	public bool IsFlowState => Definition.Id == "silentheart-flow-state";

	public bool IsRitual => Definition.Id == "ritual-cast";

	public string RitualAreaLabel
	{
		get
		{
			if (!string.IsNullOrWhiteSpace(_entry.Values.GetValueOrDefault("startcoordinates")) && !string.IsNullOrWhiteSpace(_entry.Values.GetValueOrDefault("endcoordinates")))
			{
				return "Prompt area selected";
			}
			return "No prompt area selected";
		}
	}

	public MacroFieldRow? HeaderKey => Fields.FirstOrDefault((MacroFieldRow f) => f.Key == ((Definition.Id == "silentheart-flow-state") ? "flowstatekeybind" : "keybind"));

	public bool HasHeaderKey => HeaderKey != null;

	public bool ShowEnableToggle => true;

	public string HeaderKeyValue
	{
		get
		{
			return HeaderKey?.Value ?? "";
		}
		set
		{
			if (HeaderKey != null)
			{
				HeaderKey.Value = value;
				OnPropertyChanged("HeaderKeyValue");
			}
		}
	}

	public bool HasCoordinateSettings
	{
		get
		{
			if (!IsRitual)
			{
				return Fields.Any((MacroFieldRow f) => f.Key.EndsWith("coordinates", StringComparison.Ordinal));
			}
			return true;
		}
	}

	public IReadOnlyList<MacroFieldRow> DetailFields => Fields.Where((MacroFieldRow f) => f != HeaderKey).ToArray();

	public bool HasDetailSettings
	{
		get
		{
			if (!IsRitual)
			{
				return DetailFields.Count > 0;
			}
			return true;
		}
	}

	public bool ShowDetails
	{
		get
		{
			if (HasDetailSettings)
			{
				return Enabled;
			}
			return false;
		}
	}

	public bool PlainHeader => !HasDetailSettings;

	public bool HasFields => Fields.Count > 0;

	public bool NoFields => !HasFields;

	public MacroRow(MacroDefinition definition, MacroEntry entry, Action changed)
	{
		MacroRow macroRow = this;
		Definition = definition;
		_entry = entry;
		_changed = changed;
		Fields = definition.Fields.Select((MacroField field) => new MacroFieldRow(field, entry.Values, () =>
		{
			macroRow.OnPropertyChanged("RitualAreaLabel");
			foreach (MacroFieldRow field in macroRow.Fields)
			{
				field.RefreshVisibility();
			}
			changed();
		}, definition.Id == "ritual-cast" && field.Key.EndsWith("coordinates", StringComparison.Ordinal))).ToArray();
	}

	public void SetRitualArea(HealthRegion region)
	{
		if (!IsRitual)
		{
			throw new InvalidOperationException("This macro does not use a prompt area.");
		}
		region.Validate();
		Fields.Single((MacroFieldRow f) => f.Key == "startcoordinates").Value = $"{region.X} {region.Y}";
		Fields.Single((MacroFieldRow f) => f.Key == "endcoordinates").Value = $"{region.X + region.Width} {region.Y + region.Height}";
	}
}
