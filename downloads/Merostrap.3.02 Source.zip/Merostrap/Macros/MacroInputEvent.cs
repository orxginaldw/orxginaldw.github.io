namespace Merostrap.Macros;

public readonly record struct MacroInputEvent(string Key, bool IsDown, bool IsInjected = false, long Sequence = 0L);
