using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using Avalonia.Controls;
using Avalonia.Platform;
using Avalonia.Threading;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using LucideAvalonia.Enum;
using Merostrap.Macros.Health;
using Merostrap.UI.Elements.Macros;

namespace Merostrap.Macros;

public sealed class MacroWorkspace : ObservableObject, IDisposable
{
	private sealed class SettingsEdit(MacroWorkspace workspace) : IDisposable
	{
		private MacroWorkspace? _workspace = workspace;

		public void Dispose()
		{
			MacroWorkspace macroWorkspace = Interlocked.Exchange(ref _workspace, null);
			if (macroWorkspace != null && !macroWorkspace._disposed && --macroWorkspace._settingsEditDepth == 0 && macroWorkspace._sessionRequested)
			{
				macroWorkspace.Health.PreserveDeafenLatch(macroWorkspace.ResumeAfterEdit);
			}
		}
	}

	private static MacroWorkspace? _current;

	private readonly MacroStore _store;

	private readonly MacroPreferences _preferences;

	private readonly Func<MacroEngine> _engineFactory;

	private readonly Func<bool> _isRobloxForeground;

	private readonly bool _useNativeShortcuts;

	private nint _guiWindowHandle;

	private RitualPromptOverlay? _ritualPromptOverlay;

	private readonly DispatcherTimer _overlayFocus = new DispatcherTimer
	{
		Interval = TimeSpan.FromMilliseconds(100L)
	};

	private bool _overlayContext;

	private MacroEngine? _engine;

	private MacroWindow? _window;

	private MacroOverlay? _overlay;

	private bool _enabled;

	private bool _sessionRequested;

	private bool _sessionStopped;

	private int _settingsEditDepth;

	private bool _paused;

	private WindowsMacroInput? _shortcuts;

	private readonly HashSet<string> _shortcutKeysDown = new HashSet<string>();

	private bool _disposed;

	private readonly bool _singleInstance;

	private MacroSessionLease? _sessionLease;

	private readonly DispatcherTimer _openRequests = new DispatcherTimer
	{
		Interval = TimeSpan.FromMilliseconds(200L)
	};

	private string _search = "";

	private string _category = "Combat";

	private string _status = "Off · enable macros in Merostrap";

	private string _saveStatus = "Changes save locally";

	private readonly List<MacroRow> _rows = new List<MacroRow>();

	public static MacroWorkspace Current => _current ?? (_current = new MacroWorkspace(Path.Combine(Paths.ConfigRoot, "Macros.json"), null, null, null, singleInstance: true));

	public ObservableCollection<string> Profiles { get; }

	public HealthAutomation Health { get; }

	public ParryBarController ParryBar { get; }

	public FlowStateOverlayController FlowStateOverlay { get; }

	public IReadOnlyList<string> Categories { get; }

	public IReadOnlyList<string> GuiThemes { get; } = new string[5] { "Obsidian", "Midnight", "Crimson", "Evergreen", "Amethyst" };

	public string GuiTheme
	{
		get
		{
			return _preferences.GuiTheme;
		}
		set
		{
			if (GuiThemes.Contains(value) && !(value == _preferences.GuiTheme))
			{
				_preferences.GuiTheme = value;
				OnPropertyChanged("GuiTheme");
				Save();
				MacroSessionLease sessionLease = _sessionLease;
				if (sessionLease != null && !sessionLease.IsOwner)
				{
					_sessionLease.RequestGuiKeyUpdate();
				}
			}
		}
	}

	public ObservableCollection<MacroRow> VisibleMacros { get; } = new ObservableCollection<MacroRow>();

	public IRelayCommand OpenWindowCommand { get; }

	public IRelayCommand ToggleOverlayCommand { get; }

	public IRelayCommand ToggleLockCommand { get; }

	public IRelayCommand ResetPositionCommand { get; }

	public bool RuntimeAvailable => OperatingSystem.IsWindows();

	public string GuiKeybind
	{
		get
		{
			return _preferences.GuiKeybind;
		}
		set
		{
			value = MacroKeys.Normalize(value);
			if (!ValidGuiKey(value))
			{
				Status = "Choose one GUI key other than Escape, F8 or F9.";
				OnPropertyChanged("GuiKeybind");
			}
			else
			{
				if (value == _preferences.GuiKeybind)
				{
					return;
				}
				ApplyGuiKeybind(value);
				Save();
				if (_singleInstance)
				{
					MacroSessionLease? sessionLease = _sessionLease;
					if (sessionLease != null && !sessionLease.IsOwner)
					{
						_sessionLease.RequestGuiKeyUpdate();
					}
				}
			}
		}
	}

	public bool FunctionalityEnabled
	{
		get
		{
			return !_paused;
		}
		set
		{
			if (value != FunctionalityEnabled)
			{
				_paused = !value;
				Health.PreserveDeafenLatch(() =>
				{
					Enabled = value;
				});
				OnPropertyChanged("FunctionalityEnabled");
			}
		}
	}

	public bool FasterHoldEnabled
	{
		get
		{
			return _rows.First((MacroRow r) => r.Definition.Id == "hold-m1").Enabled;
		}
		set
		{
			_rows.First((MacroRow r) => r.Definition.Id == "hold-m1").Enabled = value;
		}
	}

	public bool Enabled
	{
		get
		{
			return _enabled;
		}
		set
		{
			if ((value && _sessionStopped) || (value && !OwnSession(requestOpen: true)))
			{
				return;
			}
			_sessionRequested = value;
			if (value && (_paused || _settingsEditDepth > 0))
			{
				return;
			}
			if (value)
			{
				StartShortcuts();
				RestoreOverlay();
			}
			if ((_enabled == value) & value)
			{
				return;
			}
			if (value)
			{
				if (!RuntimeAvailable)
				{
					Status = "Input macros are available on Windows.";
					return;
				}
				bool flag = _rows.Any((MacroRow row) => row.Enabled && row.Supported);
				if (!flag && !Health.IsReady && !ParryBar.IsReady)
				{
					Status = (Health.Enabled ? "Select the health bar and configure its Discord key." : "Choose at least one available macro first.");
					OnPropertyChanged("Enabled");
					return;
				}
				try
				{
					if (flag)
					{
						if (_engine == null)
						{
							_engine = CreateEngine();
						}
						_engine.Start(_preferences.Profiles[SelectedProfileIndex]);
					}
					if (Health.Enabled)
					{
						Health.SetArmed(armed: true);
					}
					ParryBar.SetArmed(active: true);
					ref bool enabled = ref _enabled;
					MacroEngine? engine = _engine;
					SetProperty(ref enabled, (engine != null && engine.IsRunning) || Health.IsArmed || ParryBar.IsRunning, "Enabled");
					OnPropertyChanged("Enabled");
					string status;
					if (flag)
					{
						MacroEngine? engine2 = _engine;
						if (engine2 == null || !engine2.IsRunning)
						{
							status = _engine.Status;
							goto IL_01dd;
						}
					}
					MacroEngine? engine3 = _engine;
					status = ((engine3 != null && engine3.IsRunning) ? _engine.Status : Health.Status);
					goto IL_01dd;
					IL_01dd:
					Status = status;
				}
				catch (Exception ex)
				{
					_engine?.Stop();
					Health.SetArmed(armed: false);
					ParryBar.SetArmed(active: false);
					Status = "Could not enable macros: " + ex.Message;
					OnPropertyChanged("Enabled");
				}
			}
			else
			{
				_engine?.Stop();
				Health.SetArmed(armed: false);
				ParryBar.SetArmed(active: false);
				SetProperty(ref _enabled, newValue: false, "Enabled");
				string text = _engine?.Status;
				Status = ((text != null && text != "Off") ? text : (Health.Fault ?? "Off · enable macros in Merostrap"));
			}
			OnPropertyChanged("SessionLabel");
		}
	}

	public string Status
	{
		get
		{
			return _status;
		}
		private set
		{
			if (SetProperty(ref _status, value, "Status"))
			{
				OnPropertyChanged("DisplayStatus");
			}
		}
	}

	public string DisplayStatus
	{
		get
		{
			if (!Status.StartsWith("Off", StringComparison.Ordinal) && !Status.StartsWith("Settings changed", StringComparison.Ordinal))
			{
				return Status;
			}
			return "Off";
		}
	}

	public string SaveStatus
	{
		get
		{
			return _saveStatus;
		}
		private set
		{
			SetProperty(ref _saveStatus, value, "SaveStatus");
		}
	}

	public string SessionLabel
	{
		get
		{
			if (!Enabled)
			{
				return "OFF";
			}
			return "ENABLED";
		}
	}

	public string Search
	{
		get
		{
			return _search;
		}
		set
		{
			if (SetProperty(ref _search, value, "Search"))
			{
				Filter();
				OnPropertyChanged("IsHealthPage");
				OnPropertyChanged("IsParryPage");
				OnPropertyChanged("IsSettingsPage");
				OnPropertyChanged("IsMacroPage");
				OnPropertyChanged("IsHallowtidePage");
				OnPropertyChanged("IsSilentheartPage");
				Health.SetPreview(IsHealthPage);
			}
		}
	}

	private bool HasSearch => !string.IsNullOrWhiteSpace(Search);

	public string SelectedCategory
	{
		get
		{
			return _category;
		}
		set
		{
			if (SetProperty(ref _category, value, "SelectedCategory"))
			{
				Filter();
				OnPropertyChanged("IsHealthPage");
				OnPropertyChanged("IsParryPage");
				OnPropertyChanged("IsSettingsPage");
				OnPropertyChanged("IsMacroPage");
				OnPropertyChanged("IsHallowtidePage");
				OnPropertyChanged("IsSilentheartPage");
				Health.SetPreview(IsHealthPage);
			}
		}
	}

	public bool IsSilentheartPage
	{
		get
		{
			if (!HasSearch)
			{
				return SelectedCategory == "Silentheart";
			}
			return false;
		}
	}

	public bool IsHealthPage
	{
		get
		{
			if (!HasSearch)
			{
				return SelectedCategory == "Health";
			}
			return false;
		}
	}

	public bool IsParryPage
	{
		get
		{
			if (!HasSearch)
			{
				return SelectedCategory == "Parry Bar";
			}
			return false;
		}
	}

	public bool IsSettingsPage
	{
		get
		{
			if (!HasSearch)
			{
				return SelectedCategory == "Settings";
			}
			return false;
		}
	}

	public bool IsHallowtidePage
	{
		get
		{
			if (!HasSearch)
			{
				return SelectedCategory == "Hallowtide";
			}
			return false;
		}
	}

	public bool IsMacroPage
	{
		get
		{
			if (!IsHealthPage && !IsParryPage && !IsSettingsPage)
			{
				return !IsHallowtidePage;
			}
			return false;
		}
	}

	public bool IsEmpty
	{
		get
		{
			if (IsMacroPage)
			{
				return VisibleMacros.Count == 0;
			}
			return false;
		}
	}

	public string ResultCount => $"{VisibleMacros.Count} macros";

	public IReadOnlyList<MacroBindingSummary> OverlayBindings => _rows.Where((MacroRow r) => r.Enabled && r.Supported).Select((MacroRow r) =>
	{
		MacroFieldRow headerKey = r.HeaderKey;
		if (headerKey != null)
		{
			return new MacroBindingSummary(r.Name, string.IsNullOrWhiteSpace(headerKey.Value) ? "Unset" : headerKey.Value.ToUpperInvariant());
		}
		try
		{
			MacroWorkflow macroWorkflow = MacroWorkflows.Create(r.Definition.Id, r.Fields.ToDictionary((MacroFieldRow f) => f.Key, (MacroFieldRow f) => f.Value));
			string name = r.Name;
			string text = string.Join(" / ", macroWorkflow.Triggers.Select((string k) => (!(k == "primary")) ? k.ToUpperInvariant() : "M1"));
			return new MacroBindingSummary(name, (text != null && text.Length > 0) ? text : "Typing");
		}
		catch (ArgumentException)
		{
			return new MacroBindingSummary(r.Name, "Unset");
		}
		catch (FormatException)
		{
			return new MacroBindingSummary(r.Name, "Unset");
		}
		catch (OverflowException)
		{
			return new MacroBindingSummary(r.Name, "Unset");
		}
	}).Concat((!Health.Enabled || !Health.AutoDeafen) ? Array.Empty<MacroBindingSummary>() : new MacroBindingSummary[1]
	{
		new MacroBindingSummary("Auto Deafen", string.IsNullOrWhiteSpace(Health.DeafenKey) ? "Unset" : Health.DeafenKey.ToUpperInvariant())
	})
		.ToArray();

	public bool NoOverlayBindings => OverlayBindings.Count == 0;

	public string EnabledCount => $"{_rows.Count((MacroRow r) => r.Enabled)} selected";

	public int SelectedProfileIndex
	{
		get
		{
			return _preferences.SelectedProfile;
		}
		set
		{
			if (value < 0 || value >= Profiles.Count || value == SelectedProfileIndex)
			{
				return;
			}
			bool resume = _sessionRequested;
			Health.PreserveDeafenLatch(() =>
			{
				Enabled = false;
				_preferences.SelectedProfile = value;
				LoadRows();
				Save();
				if (resume)
				{
					ResumeAfterEdit();
				}
			});
			OnPropertyChanged("SelectedProfileIndex");
			OnPropertyChanged("PresetName");
			OnPropertyChanged("FasterHoldEnabled");
		}
	}

	public string PresetName
	{
		get
		{
			return _preferences.Profiles[SelectedProfileIndex].Name;
		}
		set
		{
			if (!(value == PresetName))
			{
				_preferences.Profiles[SelectedProfileIndex].Name = value;
				Profiles[SelectedProfileIndex] = value;
				Save();
				OnPropertyChanged("PresetName");
			}
		}
	}

	public bool OverlayVisible
	{
		get
		{
			return _preferences.OverlayVisible;
		}
		set
		{
			if (value != OverlayVisible || (value && _overlay == null))
			{
				_preferences.OverlayVisible = value;
				Save();
				OnPropertyChanged("OverlayVisible");
				RestoreOverlay();
			}
		}
	}

	public bool OverlayLocked
	{
		get
		{
			return _preferences.OverlayLocked;
		}
		set
		{
			if (value != OverlayLocked)
			{
				_preferences.OverlayLocked = value;
				Save();
				OnPropertyChanged("OverlayLocked");
				OnPropertyChanged("LockIcon");
				OnPropertyChanged("LockLabel");
			}
		}
	}

	public LucideIconNames LockIcon
	{
		get
		{
			if (!OverlayLocked)
			{
				return LucideIconNames.LockKeyholeOpen;
			}
			return LucideIconNames.LockKeyhole;
		}
	}

	public string LockLabel
	{
		get
		{
			if (!OverlayLocked)
			{
				return "Lock overlay position";
			}
			return "Unlock overlay position";
		}
	}

	public int? OverlayX => _preferences.OverlayX;

	public int? GuiX => _preferences.GuiX;

	public int? GuiY => _preferences.GuiY;

	public int? OverlayY => _preferences.OverlayY;

	public static void Shutdown()
	{
		_current?.Dispose();
	}

	public static void StopInputs()
	{
		_current?._shortcuts?.Dispose();
		_current?._engine?.Dispose();
		_current?.Health.StopInputs();
		_current?.ParryBar.StopCapture();
	}

	private bool OwnSession(bool requestOpen = false)
	{
		if (_disposed)
		{
			return false;
		}
		if (!_singleInstance || !OperatingSystem.IsWindows())
		{
			return true;
		}
		Dispatcher.UIThread.VerifyAccess();
		if (_sessionLease == null)
		{
			_sessionLease = new MacroSessionLease();
		}
		if (_sessionLease.TryAcquire())
		{
			_openRequests.Start();
			return true;
		}
		if (requestOpen)
		{
			_sessionLease.RequestOpen();
		}
		Status = "Macros are already open in another Merostrap window.";
		return false;
	}

	public MacroWorkspace(string path, Func<MacroEngine>? engineFactory = null, HealthMonitor? parryMonitor = null, Func<bool>? isRobloxForeground = null, bool singleInstance = false)
	{
		_singleInstance = singleInstance;
		_useNativeShortcuts = singleInstance && engineFactory == null;
		_openRequests.Tick += (object? _, EventArgs _) =>
		{
			ProcessSessionRequests();
		};
		_isRobloxForeground = isRobloxForeground ?? new Func<bool>(WindowsHealthCapture.IsForegroundRoblox);
		_overlayFocus.Tick += (object? _, EventArgs _) =>
		{
			RefreshOverlayVisibility();
		};
		_engineFactory = engineFactory ?? ((Func<MacroEngine>)(() => new MacroEngine(new WindowsMacroInput(), () => new WindowsRitualPromptSource(), null, null, GankWindowCapture.CaptureAsync, () => new WindowsCharismaPromptSource(), WindowsClipboardText.CopyAsync)));
		_store = new MacroStore(path);
		try
		{
			_preferences = _store.Load();
		}
		catch (Exception ex) when ((ex is IOException || ex is UnauthorizedAccessException) ? true : false)
		{
			_preferences = new MacroPreferences();
			_status = "Could not load macro settings: " + ex.Message;
			_saveStatus = "Storage unavailable";
		}
		string lastLoadWarning = _store.LastLoadWarning;
		if (lastLoadWarning != null && lastLoadWarning.Length > 0)
		{
			_status = lastLoadWarning;
		}
		if (!ValidGuiKey(_preferences.GuiKeybind))
		{
			_preferences.GuiKeybind = "f10";
		}
		else
		{
			_preferences.GuiKeybind = MacroKeys.Normalize(_preferences.GuiKeybind);
		}
		Profiles = new ObservableCollection<string>(_preferences.Profiles.Select((MacroProfile p) => p.Name));
		Categories = MacroCatalog.All.Select((MacroDefinition m) => m.Category).Distinct().Append("Hallowtide")
			.Append("Health")
			.Append("Parry Bar")
			.Append("Settings")
			.ToArray();
		if (!GuiThemes.Contains(_preferences.GuiTheme))
		{
			_preferences.GuiTheme = "Obsidian";
		}
		ParryBar = new ParryBarController(_preferences.ParryBar, Save, () =>
		{
			bool resume = _sessionRequested || ParryBar.Enabled;
			Health.PreserveDeafenLatch(() =>
			{
				Enabled = false;
				if (resume)
				{
					Enabled = true;
				}
			});
			RestoreOverlay();
		}, parryMonitor);
		MacroPreferences preferences = _preferences;
		FlowStateOverlay = new FlowStateOverlayController(preferences.FlowStateOverlay ?? (preferences.FlowStateOverlay = new FlowStateOverlaySettings()), Save, RestoreOverlay, _useNativeShortcuts);
		Health = new HealthAutomation(Path.Combine(Path.GetDirectoryName(Path.GetFullPath(path)), "Health.json"), HealthChanged, null, null, null, ResumeAfterEdit, () => _sessionRequested);
		ParryBar.Recovered += (DetectedHudBars bars) =>
		{
			Health.ApplyDetectedRegion(bars.Health);
		};
		Health.Recovered += (DetectedHudBars bars) =>
		{
			ParryBar.ApplyDetectedBars(bars);
		};
		Health.PropertyChanged += (object? _, PropertyChangedEventArgs e) =>
		{
			if (e.PropertyName == "IsArmed")
			{
				ref bool enabled = ref _enabled;
				MacroEngine? engine = _engine;
				SetProperty(ref enabled, (engine != null && engine.IsRunning) || Health.IsArmed || ParryBar.IsRunning, "Enabled");
				OnPropertyChanged("SessionLabel");
			}
			if (Health.Fault != null)
			{
				Status = Health.Fault;
			}
			else if (Enabled)
			{
				MacroEngine? engine2 = _engine;
				if ((engine2 == null || !engine2.IsRunning) && e.PropertyName == "Status")
				{
					Status = Health.Status;
				}
			}
		};
		OpenWindowCommand = new RelayCommand(OpenWindow);
		ToggleOverlayCommand = new RelayCommand(() =>
		{
			OverlayVisible = !OverlayVisible;
		});
		ToggleLockCommand = new RelayCommand(() =>
		{
			OverlayLocked = !OverlayLocked;
		});
		ResetPositionCommand = new RelayCommand(ResetPosition);
		LoadRows();
		if (_useNativeShortcuts)
		{
			StartShortcuts();
		}
	}

	private void ApplyGuiKeybind(string value)
	{
		_preferences.GuiKeybind = value;
		if (_engine != null)
		{
			_engine.InterfaceKey = value;
		}
		_shortcuts?.Dispose();
		_shortcuts = null;
		_shortcutKeysDown.Clear();
		if (_useNativeShortcuts)
		{
			StartShortcuts();
		}
		OnPropertyChanged("GuiKeybind");
	}

	private static bool ValidGuiKey(string? value)
	{
		bool flag = value != null;
		if (flag)
		{
			bool flag2 = value.Length == 0;
			if (!flag2)
			{
				bool flag3 = MacroKeys.TryVirtualKey(value, out var _);
				if (flag3)
				{
					bool flag4;
					switch (MacroKeys.Normalize(value))
					{
					case "esc":
					case "f8":
					case "f9":
						flag4 = true;
						break;
					default:
						flag4 = false;
						break;
					}
					flag3 = !flag4;
				}
				flag2 = flag3;
			}
			flag = flag2;
		}
		return flag;
	}

	public void ToggleGui()
	{
		MacroWindow? window = _window;
		if (window != null && window.IsPanelOpen)
		{
			_window.HidePanel();
		}
		else
		{
			OpenWindow(activate: false);
		}
	}

	private void StartShortcuts()
	{
		if (!_useNativeShortcuts || _shortcuts != null || !OwnSession())
		{
			return;
		}
		HashSet<string> hashSet = new HashSet<string> { "f8", "f9" };
		if (GuiKeybind.Length > 0)
		{
			hashSet.Add(GuiKeybind);
		}
		WindowsMacroInput windowsMacroInput = new WindowsMacroInput
		{
			GlobalKeys = hashSet
		};
		windowsMacroInput.Input += (MacroInputEvent e) =>
		{
			Dispatcher.UIThread.Post(() =>
			{
				HandleShortcut(e);
			});
		};
		try
		{
			windowsMacroInput.Start((MacroInputEvent e) => !e.IsInjected && e.Key == GuiKeybind && (_isRobloxForeground() || (_guiWindowHandle != IntPtr.Zero && GetForegroundWindow() == _guiWindowHandle)));
			_shortcuts = windowsMacroInput;
		}
		catch (Exception ex)
		{
			windowsMacroInput.Dispose();
			Status = "Shortcut unavailable: " + ex.Message;
		}
	}

	public void HandleShortcut(MacroInputEvent input)
	{
		bool flag = _disposed || input.IsInjected;
		if (!flag)
		{
			string key = input.Key;
			bool flag2 = ((key == "f8" || key == "f9") ? true : false);
			flag = !flag2 && input.Key != GuiKeybind;
		}
		if (flag)
		{
			return;
		}
		if (!input.IsDown)
		{
			_shortcutKeysDown.Remove(input.Key);
		}
		else
		{
			if (!_shortcutKeysDown.Add(input.Key) || KeybindButton.SuppressShortcuts)
			{
				return;
			}
			if (GuiKeybind.Length > 0 && input.Key == GuiKeybind)
			{
				if (_settingsEditDepth > 0)
				{
					return;
				}
				if (!_isRobloxForeground())
				{
					MacroWindow? window = _window;
					if (window == null || !window.IsActive)
					{
						return;
					}
				}
				ToggleGui();
			}
			else if (!_sessionStopped)
			{
				if (input.Key == "f8")
				{
					FunctionalityEnabled = !FunctionalityEnabled;
				}
				else
				{
					FasterHoldEnabled = !FasterHoldEnabled;
				}
			}
		}
	}

	private MacroEngine CreateEngine()
	{
		MacroEngine engine = _engineFactory();
		engine.InterfaceKey = GuiKeybind;
		engine.RitualPromptChanged += (RitualPromptHighlight? prompt) =>
		{
			Dispatcher.UIThread.Post(() =>
			{
				if (!_disposed && _engine == engine)
				{
					if ((object)prompt == null || !Enabled)
					{
						_ritualPromptOverlay?.Hide();
					}
					else
					{
						(_ritualPromptOverlay ?? (_ritualPromptOverlay = new RitualPromptOverlay())).Update(prompt);
					}
				}
			});
		};
		engine.StatusChanged += (string message) =>
		{
			Dispatcher.UIThread.Post(() =>
			{
				if (!_disposed && Enabled)
				{
					SetProperty(ref _enabled, engine.IsRunning || Health.IsArmed || ParryBar.IsRunning, "Enabled");
					Status = message;
					OnPropertyChanged("SessionLabel");
				}
			});
		};
		return engine;
	}

	public void ReportError(string message)
	{
		Status = message;
	}

	public IDisposable PauseForSettingsEdit()
	{
		ObjectDisposedException.ThrowIf(_disposed, this);
		if (_settingsEditDepth++ == 0)
		{
			bool requested = _sessionRequested;
			Health.PreserveDeafenLatch(() =>
			{
				Enabled = false;
				_sessionRequested = requested;
			});
		}
		return new SettingsEdit(this);
	}

	public void SaveGuiPosition(int x, int y)
	{
		_preferences.GuiX = x;
		_preferences.GuiY = y;
		Save();
	}

	public void SaveOverlayPosition(int x, int y)
	{
		_preferences.OverlayX = x;
		_preferences.OverlayY = y;
		Save();
	}

	public void RestoreOverlay()
	{
		if (OwnSession())
		{
			if (OverlayVisible || ParryBar.Enabled || FlowStateOverlay.Enabled)
			{
				_overlayFocus.Start();
			}
			else
			{
				_overlayFocus.Stop();
			}
			RefreshOverlayVisibility();
		}
	}

	public void RefreshOverlayVisibility()
	{
		if (_disposed || !OwnSession())
		{
			return;
		}
		if (!OverlayVisible && !ParryBar.Enabled && !FlowStateOverlay.Enabled)
		{
			_overlayFocus.Stop();
			_overlayContext = false;
			_overlay?.Hide();
			ParryBar.SetForeground(foreground: false);
			FlowStateOverlay.SetForeground(foreground: false);
			return;
		}
		bool flag = _isRobloxForeground();
		int num;
		if (!flag && _overlayContext && OperatingSystem.IsWindows())
		{
			nint foregroundWindow = GetForegroundWindow();
			if (foregroundWindow != IntPtr.Zero)
			{
				MacroOverlay? overlay = _overlay;
				if (overlay != null && overlay.IsVisible)
				{
					IPlatformHandle? platformHandle = _overlay.TryGetPlatformHandle();
					if (platformHandle != null && platformHandle.Handle == foregroundWindow)
					{
						num = 1;
						goto IL_00de;
					}
				}
				num = (ParryBar.IsOverlayForeground(foregroundWindow) ? 1 : 0);
			}
			else
			{
				num = 0;
			}
			goto IL_00de;
		}
		goto IL_00df;
		IL_00df:
		_overlayContext = flag;
		if (flag && OverlayVisible)
		{
			ShowOverlay();
		}
		else
		{
			_overlay?.Hide();
		}
		ParryBar.SetForeground(flag);
		FlowStateOverlay.SetForeground(flag);
		return;
		IL_00de:
		flag = (byte)num != 0;
		goto IL_00df;
	}

	[DllImport("user32.dll")]
	private static extern nint GetForegroundWindow();

	private void ShowOverlay()
	{
		if (_overlay == null)
		{
			_overlay = new MacroOverlay(this);
			_overlay.Closed += (object? _, EventArgs _) =>
			{
				_overlay = null;
			};
		}
		if (!_overlay.IsVisible)
		{
			_overlay.Show();
		}
	}

	private void ResetPosition()
	{
		_preferences.OverlayX = null;
		_preferences.OverlayY = null;
		Save();
		_overlay?.ResetPosition();
	}

	public void OpenWindow()
	{
		OpenWindow(activate: true);
	}

	private void OpenWindow(bool activate)
	{
		if (!OwnSession(requestOpen: true))
		{
			return;
		}
		StartShortcuts();
		if (_window == null)
		{
			_window = new MacroWindow(this);
			_window.Closed += (object? _, EventArgs _) =>
			{
				_window = null;
				_guiWindowHandle = IntPtr.Zero;
				Health.SetPreview(preview: false);
			};
		}
		_window.ShowPanel(activate);
		_guiWindowHandle = _window.TryGetPlatformHandle()?.Handle ?? IntPtr.Zero;
		Health.SetPreview(IsHealthPage);
		if (_window.WindowState == WindowState.Minimized)
		{
			_window.WindowState = WindowState.Normal;
		}
		RestoreOverlay();
	}

	public void OpenForRobloxLaunch(bool launchEnabled)
	{
		if (launchEnabled && RuntimeAvailable)
		{
			OpenWindow();
			StartSession();
		}
	}

	public void StopSession()
	{
		if (_disposed)
		{
			return;
		}
		_sessionStopped = true;
		if (_singleInstance && OperatingSystem.IsWindows())
		{
			if (_sessionLease == null)
			{
				_sessionLease = new MacroSessionLease();
			}
			if (!_sessionLease.IsOwner)
			{
				_sessionLease.RequestStop();
			}
		}
		Enabled = false;
		_shortcutKeysDown.Clear();
		_overlayFocus.Stop();
		_window?.Close();
		_overlay?.Close();
		_ritualPromptOverlay?.Close();
		_ritualPromptOverlay = null;
		ParryBar.SetForeground(foreground: false);
		FlowStateOverlay.SetForeground(foreground: false);
	}

	internal void ProcessSessionRequests()
	{
		MacroSessionLease? sessionLease = _sessionLease;
		if (sessionLease != null && sessionLease.TakeGuiKeyUpdate())
		{
			try
			{
				MacroPreferences macroPreferences = _store.Load();
				string guiKeybind = macroPreferences.GuiKeybind;
				if (ValidGuiKey(guiKeybind))
				{
					ApplyGuiKeybind(MacroKeys.Normalize(guiKeybind));
				}
				if (GuiThemes.Contains(macroPreferences.GuiTheme))
				{
					_preferences.GuiTheme = macroPreferences.GuiTheme;
					OnPropertyChanged("GuiTheme");
				}
			}
			catch (Exception ex) when ((ex is IOException || ex is UnauthorizedAccessException) ? true : false)
			{
				Status = "Could not update GUI hotkey: " + ex.Message;
			}
		}
		bool num = _sessionLease?.TakeStopRequest() ?? false;
		bool flag = _sessionLease?.TakeStartRequest() ?? false;
		if (num | flag)
		{
			_sessionLease.TakeOpenRequest();
			App.Settings.Load(alertFailure: false);
			if (App.Settings.Prop.EnableMacrosOnLaunch)
			{
				StartSession();
			}
			else
			{
				StopSession();
			}
		}
		else
		{
			MacroSessionLease? sessionLease2 = _sessionLease;
			if (sessionLease2 != null && sessionLease2.TakeOpenRequest())
			{
				OpenWindow();
			}
		}
	}

	public void StartSession()
	{
		if (_disposed)
		{
			return;
		}
		if (_singleInstance && OperatingSystem.IsWindows())
		{
			if (_sessionLease == null)
			{
				_sessionLease = new MacroSessionLease();
			}
			if (!_sessionLease.TryAcquire())
			{
				_sessionLease.RequestStart();
				return;
			}
			_openRequests.Start();
		}
		_sessionStopped = false;
		Enabled = true;
	}

	private void LoadRows()
	{
		_rows.Clear();
		MacroProfile macroProfile = _preferences.Profiles[SelectedProfileIndex];
		foreach (MacroDefinition definition in MacroCatalog.All)
		{
			if (!macroProfile.Entries.TryGetValue(definition.Id, out MacroEntry entry))
			{
				macroProfile.Entries[definition.Id] = (entry = new MacroEntry());
			}
			_rows.Add(new MacroRow(definition, entry, () =>
			{
				if (entry.Enabled)
				{
					string other = definition.Id switch
					{
						"auto-uppercut" => "dynamic-auto-uppercut", 
						"dynamic-auto-uppercut" => "auto-uppercut", 
						"bell-stack-dodge" => "bell-stack-parry", 
						"bell-stack-parry" => "bell-stack-dodge", 
						_ => null, 
					};
					if (other != null)
					{
						MacroRow macroRow = _rows.FirstOrDefault((MacroRow r) => r.Definition.Id == other);
						if (macroRow != null && macroRow.Enabled)
						{
							macroRow.Enabled = false;
						}
					}
				}
				Changed();
			}));
		}
		Filter();
		OnPropertyChanged("EnabledCount");
		OnPropertyChanged("OverlayBindings");
		OnPropertyChanged("NoOverlayBindings");
	}

	private void Changed()
	{
		bool resume = _sessionRequested;
		Health.PreserveDeafenLatch(() =>
		{
			HealthChanged();
			if (resume)
			{
				ResumeAfterEdit();
			}
		});
	}

	private void HealthChanged()
	{
		bool sessionRequested = _sessionRequested;
		Enabled = false;
		_sessionRequested = sessionRequested;
		Save();
		OnPropertyChanged("FasterHoldEnabled");
		OnPropertyChanged("EnabledCount");
		OnPropertyChanged("OverlayBindings");
		OnPropertyChanged("NoOverlayBindings");
	}

	private void ResumeAfterEdit()
	{
		if ((_engine == null || _engine.Status == "Off") && Health.Fault == null)
		{
			Enabled = true;
		}
	}

	private void Filter()
	{
		VisibleMacros.Clear();
		foreach (MacroRow item in _rows.Where((MacroRow r) => (HasSearch || r.Category == SelectedCategory) && (r.Name.Contains(Search.Trim(), StringComparison.OrdinalIgnoreCase) || r.Description.Contains(Search.Trim(), StringComparison.OrdinalIgnoreCase))))
		{
			VisibleMacros.Add(item);
		}
		OnPropertyChanged("IsEmpty");
		OnPropertyChanged("ResultCount");
	}

	private void Save()
	{
		try
		{
			_store.Save(_preferences);
			SaveStatus = "Saved locally";
		}
		catch (Exception ex)
		{
			SaveStatus = "Not saved";
			Status = "Could not save macro settings: " + ex.Message;
		}
	}

	public void Dispose()
	{
		if (!_disposed)
		{
			_disposed = true;
			_overlayFocus.Stop();
			_shortcuts?.Dispose();
			_engine?.Dispose();
			Health.Dispose();
			ParryBar.Dispose();
			FlowStateOverlay.Dispose();
			_ritualPromptOverlay?.Close();
			_window?.Close();
			_overlay?.Close();
			_openRequests.Stop();
			_sessionLease?.Dispose();
		}
	}
}
