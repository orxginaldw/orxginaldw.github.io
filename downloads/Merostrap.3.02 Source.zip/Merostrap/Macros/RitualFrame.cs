using System.Collections.Generic;

namespace Merostrap.Macros;

public sealed record RitualFrame(IReadOnlyList<RitualGlyph> Glyphs, bool Reliable = true, bool PromptAbsent = false);
