using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Merostrap.Macros.Health;

namespace Merostrap.Macros;

internal static class MacroWorkflows
{
	private static readonly HashSet<string> Supported = new HashSet<string>(StringComparer.Ordinal)
	{
		"right-mouse-parry", "auto-buy", "auto-drop-notes", "auto-eat", "auto-feint", "auto-log", "auto-roll-cancel", "auto-sell", "tacet-toggle", "trash-talk",
		"mantra-variants", "bell-stack-dodge", "bell-stack-parry", "flash-map", "golden-tongue", "hold-m1", "mantra-roll-tech", "mantra-slide-tech", "mb-all", "motif-swap",
		"roll-crit", "roll-m1", "roll-parry", "ankle-cutter", "mayhem", "relentless-hunt", "rising-star", "silentheart-flow-state", "auto-agility", "charisma-autofill",
		"auto-fortitude", "auto-willpower", "uppercut-assassinate", "auto-uppercut", "dynamic-auto-uppercut", "auto-pender", "ritual-cast", "gank-pinger"
	};

	public static MacroSupport GetSupport(string id)
	{
		if (!Supported.Contains(id) && !IsChat(id))
		{
			return new MacroSupport(Supported: false, "Unknown macro.");
		}
		return new MacroSupport(Supported: true, "");
	}

	private static bool IsChat(string id)
	{
		if (id.StartsWith("chat-message-", StringComparison.Ordinal) && int.TryParse(id.AsSpan(13), out var result))
		{
			if (result >= 1)
			{
				return result <= 10;
			}
			return false;
		}
		return false;
	}

	public static MacroWorkflow Create(string id, Dictionary<string, string> values, Func<IRitualPromptSource>? ritualSourceFactory = null, Func<Uri, string, CancellationToken, Task>? webhookSender = null, Func<GankAlert, CancellationToken, Task>? gankSender = null, Func<string, CancellationToken, Task<byte[]>>? windowCapture = null, Func<ICharismaPromptSource>? charismaSourceFactory = null, Func<string, CancellationToken, Task>? clipboardSetter = null)
	{
		foreach (MacroField item2 in MacroCatalog.All.FirstOrDefault((MacroDefinition d) => d.Id == id)?.Fields ?? Array.Empty<MacroField>())
		{
			values.TryAdd(item2.Key, item2.DefaultValue);
		}
		if (IsChat(id) || id == "golden-tongue")
		{
			string content = Text("content");
			bool sprint = Bool("autosprint");
			return Bound(async (MacroActions a, string? _) =>
			{
				await a.Chat(content);
				if (sprint)
				{
					await a.Tap("w");
					await a.Wait(50);
					a.Down("w");
					await a.Wait(-1);
				}
			}, sprint ? MacroRunMode.Toggle : MacroRunMode.Once);
		}
		switch (id)
		{
		case "silentheart-flow-state":
		{
			string flowKey = Key("flowstatekeybind");
			string text = Key("dodgekeybind");
			string text2 = Key("crouchkeybind");
			string text3 = Key("jumpkeybind");
			string text4 = Key("feintkeybind");
			bool flag;
			switch (flowKey)
			{
			case "esc":
			case "f8":
			case "f9":
			case "ctrl":
			case "w":
			case "mouse1":
				flag = true;
				break;
			default:
				flag = false;
				break;
			}
			if (flag || new string[4] { text, text2, text3, text4 }.Contains(flowKey))
			{
				throw new ArgumentException("Flow State needs a separate toolbar key, such as 4.");
			}
			return new MacroWorkflow(id, new string[2] { "mouse1", text4 }, async (MacroActions a, string? text5) =>
			{
				if (text5 != null)
				{
					await a.Tap(flowKey);
					await a.Tap(text5);
				}
			}, MacroRunMode.Once, OnRelease: false, Suppress: false, new SilentheartFlowDetector(text, text2, text3, text4), flowKey);
		}
		case "gank-pinger":
		{
			GankAlert alert = GankWebhook.Create(values);
			return Bound(async (MacroActions a, string? _) =>
			{
				a.CheckForeground();
				GankAlert gankAlert = alert;
				if (alert.WindowId.Length > 0)
				{
					if (windowCapture == null)
					{
						throw new InvalidOperationException("Window capture is unavailable.");
					}
					a.ReportStatus("Gank Pinger: capturing window");
					byte[] array = await windowCapture(alert.WindowId, a.Token);
					if (array.Length == 0)
					{
						throw new InvalidOperationException("Selected window could not be captured.");
					}
					gankAlert = alert with
					{
						Screenshot = array
					};
				}
				a.CheckForeground();
				a.ReportStatus("Gank Pinger: sending");
				if (gankSender != null)
				{
					await gankSender(gankAlert, a.Token);
				}
				else if (gankAlert.Authorization.Length != 0 || gankAlert.Screenshot != null || webhookSender == null)
				{
					await GankWebhook.SendAlertAsync(gankAlert, a.Token);
				}
				else
				{
					await webhookSender(gankAlert.Endpoint, gankAlert.Message, a.Token);
				}
				a.Complete("Gank Pinger: message sent");
			});
		}
		case "ritual-cast":
		{
			if (MacroKeys.Parse(Value("keybind"), "keybind").Any((string k) => (k == "f8" || k == "f9") ? true : false))
			{
				throw new ArgumentException("F8 and F9 are reserved for macro session controls. Choose another hotkey.");
			}
			HealthRegion savedRegion = null;
			if (Value("startcoordinates").Length > 0 || Value("endcoordinates").Length > 0)
			{
				try
				{
					(int, int) tuple = Point("startcoordinates");
					(int, int) tuple2 = Point("endcoordinates");
					savedRegion = new HealthRegion(tuple.Item1, tuple.Item2, tuple2.Item1 - tuple.Item1, tuple2.Item2 - tuple.Item2);
					savedRegion.Validate();
				}
				catch (ArgumentException)
				{
					savedRegion = null;
				}
			}
			bool flag = !int.TryParse(Value("ping_ms"), NumberStyles.Integer, CultureInfo.InvariantCulture, out var ritualPing);
			if (!flag)
			{
				bool flag2 = ((ritualPing < 0 || ritualPing > 1000) ? true : false);
				flag = flag2;
			}
			if (flag)
			{
				throw new ArgumentException("ping_ms must be between 0 and 1000 milliseconds.");
			}
			if (ritualSourceFactory == null)
			{
				throw new ArgumentException("Ritual recognition is not configured for this session.");
			}
			return Bound(async (MacroActions a, string? _) =>
			{
				using IRitualPromptSource source = ritualSourceFactory();
				RitualSequenceTracker tracker = new RitualSequenceTracker();
				long nextRitualInput = 0L;
				a.CheckForeground();
				a.ReportStatus("Ritual: detecting prompt");
				HealthRegion region = source.DetectRegion(a.Token) ?? savedRegion;
				a.CheckForeground();
				long detectStarted = Environment.TickCount64;
				while ((object)region == null && Environment.TickCount64 - detectStarted < 5000)
				{
					await a.Wait(250);
					a.CheckForeground();
					region = source.DetectRegion(a.Token);
					a.CheckForeground();
				}
				if ((object)region == null)
				{
					a.Complete("Ritual: prompt not found");
				}
				else
				{
					region.Validate();
					string lastRitualReason = "";
					long ritualReasonSince = Environment.TickCount64;
					bool sentAny = false;
					long? ritualAbsentSince = null;
					RitualGlyph? sentGlyph = null;
					a.ReportStatus("Ritual: reading prompts");
					while (true)
					{
						a.CheckForeground();
						RitualFrame ritualFrame = source.Read(region);
						a.CheckForeground();
						long tickCount = Environment.TickCount64;
						if (sentAny && ritualFrame.Reliable && ritualFrame.PromptAbsent)
						{
							ritualAbsentSince.GetValueOrDefault();
							if (!ritualAbsentSince.HasValue)
							{
								long value = tickCount;
								ritualAbsentSince = value;
							}
							a.ReportRitualPrompt(null);
							if (tickCount - ritualAbsentSince >= 100)
							{
								break;
							}
							await a.Wait(8);
							continue;
						}
						ritualAbsentSince = null;
						char? c = tracker.Observe(ritualFrame, tickCount) ?? tracker.RetryPending(tickCount, Math.Max(250, ritualPing + 150));
						RitualGlyph? ritualGlyph = (from g in ritualFrame.Glyphs
							orderby g.X, g.Y
							select g).Cast<RitualGlyph?>().FirstOrDefault();
						RitualPromptHighlight ritualPromptHighlight = null;
						RitualGlyph valueOrDefault;
						int num;
						if (ritualGlyph.HasValue)
						{
							valueOrDefault = ritualGlyph.GetValueOrDefault();
							if (valueOrDefault.X >= 0 && valueOrDefault.Y >= 0 && valueOrDefault.Width > 0 && valueOrDefault.Height > 0 && valueOrDefault.X + valueOrDefault.Width <= region.Width && valueOrDefault.Y + valueOrDefault.Height <= region.Height)
							{
								if (sentGlyph.HasValue)
								{
									RitualGlyph valueOrDefault2 = sentGlyph.GetValueOrDefault();
									if (valueOrDefault2.Character == valueOrDefault.Character && Math.Abs(valueOrDefault2.X - valueOrDefault.X) <= 2 && Math.Abs(valueOrDefault2.Y - valueOrDefault.Y) <= 2)
									{
										num = ((tracker.Status == $"waiting for {valueOrDefault2.Character} to advance") ? 1 : 0);
										goto IL_0564;
									}
								}
								num = 0;
								goto IL_0564;
							}
						}
						goto IL_05a8;
						IL_0564:
						bool sent = (byte)num != 0;
						ritualPromptHighlight = new RitualPromptHighlight(new HealthRegion(region.X + valueOrDefault.X, region.Y + valueOrDefault.Y, valueOrDefault.Width, valueOrDefault.Height), sent);
						goto IL_05a8;
						IL_05a8:
						a.ReportRitualPrompt(ritualPromptHighlight);
						if (lastRitualReason != tracker.Status)
						{
							lastRitualReason = tracker.Status;
							ritualReasonSince = tickCount;
						}
						if (tickCount - ritualReasonSince >= 500)
						{
							a.ReportStatus("Ritual: " + lastRitualReason);
						}
						if (c.HasValue)
						{
							char valueOrDefault3 = c.GetValueOrDefault();
							if (tickCount >= nextRitualInput)
							{
								string ritualKey = char.ToLowerInvariant(valueOrDefault3).ToString();
								a.BeginRitualTap(ritualKey);
								sentGlyph = ritualGlyph;
								if ((object)ritualPromptHighlight != null)
								{
									a.ReportRitualPrompt(ritualPromptHighlight with
									{
										Sent = true
									});
								}
								tracker.ConfirmSent();
								a.ReportStatus("Ritual: reading prompts");
								await a.Wait(15 + Math.Min(ritualPing / 8, 50));
								a.EndRitualTap(ritualKey);
								sentAny = true;
								nextRitualInput = Environment.TickCount64 + 5;
							}
						}
						await a.Wait(4);
					}
					a.Complete("Ritual: complete");
				}
			});
		}
		case "auto-pender":
		{
			(int X, int Y) firstPoint = Point("firstcoordinates");
			(int X, int Y) secondPoint = Point("secondcoordinates");
			bool flag = !int.TryParse(Value("interval_ms"), NumberStyles.Integer, CultureInfo.InvariantCulture, out var clickDelay);
			if (!flag)
			{
				bool flag2 = ((clickDelay < 20 || clickDelay > 5000) ? true : false);
				flag = flag2;
			}
			if (flag)
			{
				throw new ArgumentException("interval_ms must be between 20 and 5000 milliseconds.");
			}
			return Bound(async (MacroActions a, string? _) =>
			{
				while (true)
				{
					a.Move(firstPoint);
					await a.Click();
					await a.Wait(clickDelay);
					a.Move(secondPoint);
					await a.Click();
					await a.Wait(clickDelay);
				}
			}, MacroRunMode.Toggle);
		}
		case "right-mouse-parry":
			return new MacroWorkflow(id, new string[1] { "mouse2" }, (MacroActions a, string? _) =>
			{
				a.Down("f");
				a.Up("f");
				return Task.CompletedTask;
			});
		case "roll-parry":
			return Bound(async (MacroActions a, string? _) =>
			{
				await a.Tap("f");
				await a.Tap("q");
			});
		case "roll-m1":
		{
			bool highPing = Bool("highPing");
			return Bound(async (MacroActions a, string? _) =>
			{
				a.Down("mouse1");
				await a.Wait(highPing ? 61 : 29);
				a.Down("q");
				await a.Wait(highPing ? 43 : 0);
				a.Down("mouse2");
				await a.Wait(highPing ? 35 : 82);
				a.Up("mouse1");
				await a.Wait(highPing ? 54 : 28);
				a.Up(highPing ? "q" : "mouse2");
				await a.Wait(highPing ? 98 : 29);
				a.Up(highPing ? "mouse2" : "q");
			});
		}
		case "roll-crit":
			return new MacroWorkflow(id, new string[1] { "r" }, async (MacroActions a, string? _) =>
			{
				await a.Tap("r");
				await a.Wait(10);
				await a.Tap("q");
			}, MacroRunMode.Once, OnRelease: false, Suppress: true);
		case "auto-feint":
			return new MacroWorkflow(id, new string[1] { "f" }, async (MacroActions a, string? _) =>
			{
				await a.Tap(a.Secondary, 50);
			});
		case "auto-roll-cancel":
			return new MacroWorkflow(id, new string[1] { "q" }, async (MacroActions a, string? _) =>
			{
				await a.Wait(50);
				await a.Tap(a.Secondary, 50);
			});
		case "bell-stack-dodge":
			return new MacroWorkflow(id, new string[1] { "c" }, async (MacroActions a, string? _) =>
			{
				await a.Wait(50);
				await a.Tap("q");
			});
		case "bell-stack-parry":
			return new MacroWorkflow(id, new string[1] { "c" }, async (MacroActions a, string? _) =>
			{
				await a.Tap("f");
				await a.Wait(100);
				await a.Tap("c");
			}, MacroRunMode.Once, OnRelease: false, Suppress: true);
		case "flash-map":
			return new MacroWorkflow(id, new string[1] { "m" }, async (MacroActions a, string? _) =>
			{
				await a.Wait(200);
				await a.Tap("m");
			}, MacroRunMode.Once, OnRelease: true);
		case "mb-all":
			return Bound(async (MacroActions a, string? _) =>
			{
				await a.Chat("mb all");
			});
		case "tacet-toggle":
		{
			bool uncrouch = Bool("uncrouch");
			return Bound(async (MacroActions a, string? _) =>
			{
				await a.Wait(50);
				await a.Tap("ctrl");
				await a.Wait(50);
				await a.Tap("t");
				if (uncrouch)
				{
					await a.Wait(250);
					await a.Tap("ctrl");
				}
			});
		}
		case "motif-swap":
		{
			string motif = Key("motifnum");
			string weapon = Key("weaponnum");
			return Bound(async (MacroActions a, string? _) =>
			{
				await a.Tap(motif);
				await a.Wait(100);
				await a.Click();
				await a.Wait(100);
				await a.Tap(weapon);
			});
		}
		case "trash-talk":
		{
			string path = Value("txtpath");
			if (path.Length == 0)
			{
				throw new ArgumentException("txtpath requires a text file.");
			}
			return Bound(async (MacroActions a, string? _) =>
			{
				string[] array = (await File.ReadAllLinesAsync(path, a.Token)).Where((string s) => !string.IsNullOrWhiteSpace(s) && s.Length <= 2000 && !s.Any(char.IsControl)).ToArray();
				if (array.Length == 0)
				{
					throw new InvalidOperationException("Text file contains no usable messages.");
				}
				await a.Chat(array[Random.Shared.Next(array.Length)]);
			});
		}
		case "mantra-variants":
			return new MacroWorkflow(id, MacroKeys.Parse(Value("keybinds"), "keybinds"), async (MacroActions a, string? _) =>
			{
				for (int i = 0; i < 3; i++)
				{
					await a.Wait(100);
					await a.Tap("f");
				}
			});
		case "mantra-roll-tech":
			return new MacroWorkflow(id, MacroKeys.Parse(Value("keybinds"), "keybinds"), async (MacroActions a, string? _) =>
			{
				await a.Wait(50);
				await a.Tap("q");
			});
		case "mantra-slide-tech":
			return new MacroWorkflow(id, MacroKeys.Parse(Value("keybinds"), "keybinds"), async (MacroActions a, string? _) =>
			{
				await a.Tap("ctrl");
			});
		case "hold-m1":
		{
			string attack = Key("keyToPress");
			return new MacroWorkflow(id, new string[1] { "primary" }, async (MacroActions a, string? _) =>
			{
				a.Down(attack);
				await a.Wait(-1);
			}, MacroRunMode.Hold);
		}
		case "auto-uppercut":
			return new MacroWorkflow(id, new string[1] { "ctrl" }, async (MacroActions a, string? _) =>
			{
				while (true)
				{
					await a.Click();
					await a.Wait(10);
				}
			}, MacroRunMode.Hold);
		case "dynamic-auto-uppercut":
		{
			bool roll = Bool("toRoll");
			return new MacroWorkflow(id, new string[1] { "ctrl" }, async (MacroActions a, string? _) =>
			{
				await a.Tap("mouse2");
				if (roll)
				{
					await a.Wait(30);
					await a.Tap("q");
				}
			});
		}
		case "uppercut-assassinate":
			return Bound(async (MacroActions a, string? _) =>
			{
				a.Down("ctrl");
				await a.Click();
				await a.Wait(50);
				await a.Click();
				a.Up("ctrl");
				await a.Wait(500);
				await a.Chat("mb all");
				await a.Wait(150);
				await a.Tap("ctrl");
				await a.Wait(200);
				await a.Click();
			});
		case "ankle-cutter":
		{
			string ankleFlow = Key("flowstatekeybind");
			return Bound(async (MacroActions a, string? _) =>
			{
				await a.Tap("w");
				await a.Wait(50);
				a.Down("w");
				await a.Wait(50);
				a.Down("ctrl");
				await a.Wait(75);
				await a.Tap(ankleFlow);
				a.Down(a.Primary);
				await a.Wait(50);
				a.Up("ctrl");
				a.Up("w");
				await a.Wait(25);
				a.Up(a.Primary);
				await a.Wait(250);
			});
		}
		case "mayhem":
		{
			string mayhemFlow = Key("flowstatekeybind");
			return Bound(async (MacroActions a, string? _) =>
			{
				await a.Tap(mayhemFlow);
				a.Down("d");
				await a.Tap("q");
				a.Up("d");
				await a.Wait(100);
				for (int i = 0; i < 5; i++)
				{
					await a.Click();
					await a.Wait(50);
				}
				await a.Wait(250);
			});
		}
		case "relentless-hunt":
		{
			string huntFlow = Key("flowstatekeybind");
			return Bound(async (MacroActions a, string? _) =>
			{
				await a.Tap("space");
				await a.Wait(50);
				for (int i = 0; i < 4; i++)
				{
					await a.Click();
					await a.Wait(50);
				}
				await a.Tap(huntFlow);
				for (int i = 0; i < 5; i++)
				{
					await a.Click();
					await a.Wait(50);
				}
				await a.Wait(280);
			});
		}
		case "rising-star":
		{
			string starFlow = Key("flowstatekeybind");
			return Bound(async (MacroActions a, string? _) =>
			{
				await a.Tap(starFlow);
				a.Down("ctrl");
				for (int i = 0; i < 8; i++)
				{
					await a.Wait(1);
					await a.Tap(a.Secondary, 1);
				}
				a.Up("ctrl");
				await a.Wait(250);
			});
		}
		case "auto-agility":
			return Bound(async (MacroActions a, string? _) =>
			{
				await a.Tap("w");
				while (true)
				{
					await a.Click();
					await a.Wait(50);
					a.Down("w");
					for (int i = 0; i < 11; i++)
					{
						await a.Tap("q");
						await a.Wait(2500);
					}
					a.Up("w");
					await a.Wait(1000);
				}
			}, MacroRunMode.Toggle);
		case "auto-fortitude":
			return Bound(async (MacroActions a, string? _) =>
			{
				while (true)
				{
					await a.Click();
					await a.Wait(25000);
					await a.Tap("e");
					await a.Wait(30000);
					await a.Tap("e");
					await a.Wait(500);
				}
			}, MacroRunMode.Toggle);
		case "auto-willpower":
			return Bound(async (MacroActions a, string? _) =>
			{
				while (true)
				{
					await a.Click();
					await a.Wait(45000);
				}
			}, MacroRunMode.Toggle);
		case "charisma-autofill":
			if (MacroKeys.Parse(Value("keybind"), "keybind").Any((string k) => (k == "f8" || k == "f9") ? true : false))
			{
				throw new ArgumentException("F8 and F9 are reserved for macro session controls.");
			}
			if (charismaSourceFactory == null || clipboardSetter == null)
			{
				throw new ArgumentException("Charisma recognition is not configured for this session.");
			}
			return Bound(async (MacroActions a, string? _) =>
			{
				using ICharismaPromptSource source = charismaSourceFactory();
				string observed = "";
				long stableSince = 0L;
				bool submitted = false;
				long? absentSince = null;
				while (true)
				{
					a.CheckForeground();
					CharismaFrame charismaFrame = source.Read(a.Token);
					a.CheckForeground();
					long tickCount = Environment.TickCount64;
					if (submitted)
					{
						if (charismaFrame.Reliable && charismaFrame.Quote.Length == 0)
						{
							absentSince.GetValueOrDefault();
							if (!absentSince.HasValue)
							{
								long value = tickCount;
								absentSince = value;
							}
							if (tickCount - absentSince >= 200)
							{
								a.ReportRitualPrompt(null);
								await a.Wait(150);
								await a.Tap("mouse1");
								submitted = false;
								observed = "";
								absentSince = null;
								a.ReportStatus("Charisma: waiting for next quote");
								await a.Wait(200);
							}
						}
						else
						{
							absentSince = null;
						}
						await a.Wait(30);
					}
					else
					{
						if (charismaFrame.Reliable && charismaFrame.Quote.Length != 0)
						{
							HealthRegion area = charismaFrame.InputArea;
							if ((object)area != null)
							{
								string text5 = charismaFrame.Quote + "|" + area;
								a.ReportRitualPrompt(new RitualPromptHighlight(area, Sent: false));
								if (text5 != observed)
								{
									observed = text5;
									stableSince = tickCount;
									await a.Wait(25);
								}
								else if (tickCount - stableSince < 25)
								{
									await a.Wait(8);
								}
								else
								{
									a.ReportStatus("Charisma: pasting phrase");
									await clipboardSetter(charismaFrame.Quote, a.Token);
									a.CheckForeground();
									a.Move((X: area.X + area.Width / 2, Y: area.Y + area.Height / 2));
									await a.Wait(8);
									await a.Tap("mouse1");
									await a.Wait(20);
									a.Down("ctrl");
									await a.Tap("a");
									a.Up("ctrl");
									await a.Wait(10);
									a.Down("ctrl");
									await a.Tap("v");
									a.Up("ctrl");
									a.ReportRitualPrompt(new RitualPromptHighlight(area, Sent: true));
									await a.Wait(60);
									await a.Tap("enter");
									submitted = true;
									a.ReportStatus("Charisma: waiting for completion");
									await a.Wait(100);
								}
								continue;
							}
						}
						observed = "";
						a.ReportRitualPrompt(null);
						await a.Wait(100);
					}
				}
			}, MacroRunMode.Automatic);
		case "auto-log":
		{
			(int X, int Y) logPoint = Point("coordinates");
			return Bound(async (MacroActions a, string? _) =>
			{
				a.Move(logPoint);
				await a.Click();
				await a.Tap("shift");
				a.Move(logPoint);
				await a.Click();
			});
		}
		case "auto-eat":
		{
			(int X, int Y) box = Point("boxcoordinates");
			(int X, int Y) food = Point("foodcoordinates");
			string name = Text("foodname");
			return Bound(async (MacroActions a, string? _) =>
			{
				await a.Tap("tab");
				a.Move(box);
				await a.Click();
				await a.Text(name);
				a.Move(food);
				await a.Click();
				a.Center();
				await a.Click();
			});
		}
		case "auto-sell":
		{
			(int X, int Y) item = Point("itemcoordinates");
			(int X, int Y) confirmation = Point("confirmationcoordinates");
			int sellCount = Repetitions();
			return Bound(async (MacroActions a, string? _) =>
			{
				for (int i = 0; i < sellCount; i++)
				{
					a.Move(item);
					await a.Wait(20);
					await a.Click();
					a.Move(confirmation);
					await a.Wait(20);
					await a.Click();
					await a.Wait(150);
					await a.Click();
					await a.Wait(150);
					await a.Click();
					await a.Wait(250);
				}
			});
		}
		case "auto-drop-notes":
		{
			(int X, int Y) note = Point("notecoordinates");
			(int X, int Y) start = Point("startcoordinates");
			(int X, int Y) end = Point("endcoordinates");
			(int X, int Y) confirm = Point("confirmationcoordinates");
			int dropCount = Repetitions();
			return Bound(async (MacroActions a, string? _) =>
			{
				for (int i = 0; i < dropCount; i++)
				{
					a.Move(note);
					await a.Wait(20);
					await a.Click();
					a.Move(start);
					await a.Wait(20);
					a.Down(a.Primary);
					await a.Wait(10);
					a.Move(end);
					a.Up(a.Primary);
					await a.Wait(100);
					a.Move(confirm);
					await a.Wait(100);
					await a.Click();
				}
			});
		}
		case "auto-buy":
		{
			(int X, int Y) buyStart = Point("startcoordinates");
			(int X, int Y) buyEnd = Point("endcoordinates");
			(int X, int Y) submit = Point("submitcoordinates");
			return Bound(async (MacroActions a, string? _) =>
			{
				for (int i = 0; i < 5; i++)
				{
					await a.Tap("e");
					a.Move(buyStart);
					await a.Wait(100);
					a.Down(a.Primary);
					await a.Wait(75);
					a.Move(buyEnd);
					a.Up(a.Primary);
					await a.Wait(75);
					await a.Click();
					await a.Wait(75);
					a.Move(submit);
					await a.Wait(75);
					await a.Click();
					await a.Wait(250);
				}
			});
		}
		default:
			throw new ArgumentException("Unknown macro.");
		}
		bool Bool(string key)
		{
			if (!bool.TryParse(Value(key), out var result))
			{
				throw new ArgumentException(key + " must be true or false.");
			}
			return result;
		}
		MacroWorkflow Bound(Func<MacroActions, string?, Task> execute, MacroRunMode mode = MacroRunMode.Once)
		{
			return new MacroWorkflow(id, MacroKeys.Parse(Value("keybind"), "keybind"), execute, mode);
		}
		string Key(string field)
		{
			string[] array = MacroKeys.Parse(Value(field), field);
			if (array.Length != 1)
			{
				throw new ArgumentException(field + " requires one key.");
			}
			return array[0];
		}
		(int X, int Y) Point(string key)
		{
			string[] array = Value(key).Split(new char[3] { ' ', ',', '\t' }, StringSplitOptions.RemoveEmptyEntries);
			int result = default;
			int result2 = default;
			bool flag3 = array.Length != 2 || !int.TryParse(array[0], out result) || !int.TryParse(array[1], out result2);
			if (!flag3)
			{
				bool flag4 = ((result < -32768 || result > 32767) ? true : false);
				flag3 = flag4;
			}
			bool flag5 = flag3;
			if (!flag5)
			{
				bool flag4 = ((result2 < -32768 || result2 > 32767) ? true : false);
				flag5 = flag4;
			}
			if (flag5)
			{
				throw new ArgumentException(key + " requires screen coordinates: X Y.");
			}
			return (X: result, Y: result2);
		}
		int Repetitions()
		{
			if (!int.TryParse(Value("repetitions"), NumberStyles.Integer, CultureInfo.InvariantCulture, out var result) || result < 1 || result > 1000)
			{
				throw new ArgumentException("repetitions must be between 1 and 1000.");
			}
			return result;
		}
		string Text(string key)
		{
			string text5 = Value(key);
			int length = text5.Length;
			bool flag3 = ((length > 2000 || length == 0) ? true : false);
			if (flag3 || text5.Any(char.IsControl))
			{
				throw new ArgumentException(key + " must contain 1–2000 characters on one line.");
			}
			return text5;
		}
		string Value(string key)
		{
			if (!values.TryGetValue(key, out string value))
			{
				return "";
			}
			return value.Trim();
		}
	}
}
