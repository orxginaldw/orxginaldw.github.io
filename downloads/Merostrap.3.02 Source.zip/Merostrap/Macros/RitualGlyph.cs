namespace Merostrap.Macros;

public readonly record struct RitualGlyph(char? Character, int X, int Y, int Width, int Height, float Confidence);
