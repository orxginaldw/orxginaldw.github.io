using System;

namespace Merostrap.Macros;

public sealed class FlowStateCooldownCounter
{
	private long? _started;

	private double? _previous;

	public FlowStateCooldownSample Observe(FlowStateCooldownSample sample, long now)
	{
		double? readyPercent = sample.ReadyPercent;
		double valueOrDefault;
		if (readyPercent.HasValue)
		{
			valueOrDefault = readyPercent.GetValueOrDefault();
			readyPercent = _previous;
			if (!readyPercent.HasValue && valueOrDefault < 95.0)
			{
				goto IL_005a;
			}
			readyPercent = _previous;
			if (readyPercent.HasValue)
			{
				double valueOrDefault2 = readyPercent.GetValueOrDefault();
				if (valueOrDefault2 - valueOrDefault > 30.0)
				{
					goto IL_005a;
				}
			}
			goto IL_0066;
		}
		goto IL_0072;
		IL_0072:
		long? started = _started;
		if (started.HasValue)
		{
			long valueOrDefault3 = started.GetValueOrDefault();
			long num = Math.Clamp((now - valueOrDefault3) / 1000 * 10, 0L, 100L);
			return new FlowStateCooldownSample(num, (num == 100) ? "Ready" : "Cooling down");
		}
		if (!(sample.ReadyPercent >= 95.0))
		{
			return new FlowStateCooldownSample(null, sample.Status);
		}
		return new FlowStateCooldownSample(100.0, "Ready");
		IL_0066:
		_previous = valueOrDefault;
		goto IL_0072;
		IL_005a:
		_started = now;
		goto IL_0066;
	}
}
