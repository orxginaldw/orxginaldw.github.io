using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Merostrap.Macros;

public sealed class MacroEngine : IDisposable
{
	private sealed record Run(MacroWorkflow Workflow, string Trigger, CancellationTokenSource Cancellation)
	{
		public string? CompletionStatus { get; set; }

		public bool FlowPrepared { get; set; }
	}

	private readonly object _gate = new object();

	private readonly object _lifecycle = new object();

	private readonly IMacroInput _input;

	private readonly Func<IRitualPromptSource>? _ritualSourceFactory;

	private readonly Func<ICharismaPromptSource>? _charismaSourceFactory;

	private readonly Func<string, CancellationToken, Task>? _clipboardSetter;

	private readonly Func<Uri, string, CancellationToken, Task> _webhookSender;

	private readonly Func<GankAlert, CancellationToken, Task>? _gankSender;

	private readonly Func<string, CancellationToken, Task<byte[]>>? _windowCapture;

	private readonly HashSet<string> _physical = new HashSet<string>(StringComparer.Ordinal);

	private readonly HashSet<string> _held = new HashSet<string>(StringComparer.Ordinal);

	private readonly HashSet<string> _ritualHeld = new HashSet<string>(StringComparer.Ordinal);

	private readonly HashSet<MacroInputEvent> _pendingFlowInputs = new HashSet<MacroInputEvent>();

	private MacroWorkflow? _flowWorkflow;

	private List<MacroWorkflow> _workflows = new List<MacroWorkflow>();

	private CancellationTokenSource? _session;

	private Run? _active;

	private Action<MacroInputEvent>? _inputHandler;

	private string? _releaseError;

	private string _status = "Off";

	private string _issues = "";

	private bool _disposed;

	private bool _started;

	private bool _monitorStarted;

	private bool _foreground;

	private bool _automaticPaused;

	private long _lastWPress;

	private bool _sprinting;

	private string _interfaceKey = "";

	private RitualPromptHighlight? _ritualPrompt;

	public string InterfaceKey
	{
		get
		{
			lock (_gate)
			{
				return _interfaceKey;
			}
		}
		set
		{
			lock (_gate)
			{
				_interfaceKey = MacroKeys.Normalize(value);
			}
		}
	}

	public string Status
	{
		get
		{
			lock (_gate)
			{
				return _status;
			}
		}
	}

	public bool IsRunning
	{
		get
		{
			lock (_gate)
			{
				return _session != null && _started;
			}
		}
	}

	internal string PrimaryButton => _input.PrimaryButton;

	internal (int Width, int Height) ScreenSize => _input.ScreenSize;

	public event Action<string>? StatusChanged;

	public event Action<RitualPromptHighlight?>? RitualPromptChanged;

	public MacroEngine()
		: this(new WindowsMacroInput())
	{
	}

	public MacroEngine(IMacroInput input, Func<IRitualPromptSource>? ritualSourceFactory = null, Func<Uri, string, CancellationToken, Task>? webhookSender = null, Func<GankAlert, CancellationToken, Task>? gankSender = null, Func<string, CancellationToken, Task<byte[]>>? windowCapture = null, Func<ICharismaPromptSource>? charismaSourceFactory = null, Func<string, CancellationToken, Task>? clipboardSetter = null)
	{
		_input = input ?? throw new ArgumentNullException("input");
		_ritualSourceFactory = ritualSourceFactory;
		_charismaSourceFactory = charismaSourceFactory;
		_clipboardSetter = clipboardSetter;
		_webhookSender = webhookSender ?? new Func<Uri, string, CancellationToken, Task>(GankWebhook.SendAsync);
		_gankSender = gankSender;
		_windowCapture = windowCapture;
	}

	private void SetRitualPromptLocked(RitualPromptHighlight? prompt)
	{
		if (_ritualPrompt == prompt)
		{
			return;
		}
		_ritualPrompt = prompt;
		Action<RitualPromptHighlight> action = RitualPromptChanged;
		if (action == null)
		{
			return;
		}
		Delegate[] invocationList = action.GetInvocationList();
		for (int i = 0; i < invocationList.Length; i++)
		{
			Action<RitualPromptHighlight> action2 = (Action<RitualPromptHighlight>)invocationList[i];
			try
			{
				action2(prompt);
			}
			catch
			{
			}
		}
	}

	internal void ReportRitualPrompt(CancellationToken token, RitualPromptHighlight? prompt)
	{
		lock (_gate)
		{
			Run active = _active;
			bool flag = (object)active != null;
			if (flag)
			{
				string id = active.Workflow.Id;
				bool flag2 = ((id == "ritual-cast" || id == "charisma-autofill") ? true : false);
				flag = flag2;
			}
			if (flag && active.Cancellation.Token == token && !token.IsCancellationRequested)
			{
				SetRitualPromptLocked(prompt);
			}
		}
	}

	public static MacroSupport GetSupport(string id)
	{
		bool flag;
		switch (id)
		{
		case "mantra-variants":
		case "mantra-roll-tech":
		case "mantra-slide-tech":
			flag = true;
			break;
		default:
			flag = false;
			break;
		}
		if (!flag)
		{
			return MacroWorkflows.GetSupport(id);
		}
		return new MacroSupport(Supported: false, "Removed from Merostrap");
	}

	public void Start(MacroProfile profile)
	{
		ArgumentNullException.ThrowIfNull(profile, "profile");
		lock (_lifecycle)
		{
			ObjectDisposedException.ThrowIf(_disposed, this);
			StopCore();
			if (_held.Count != 0)
			{
				return;
			}
			if (!_input.IsAvailable)
			{
				SetStatus("Unavailable: Windows input automation requires Windows.");
				return;
			}
			List<string> list = new List<string>();
			List<MacroWorkflow> list2 = new List<MacroWorkflow>();
			foreach (var (text2, macroEntry2) in profile.Entries)
			{
				if (!macroEntry2.Enabled)
				{
					continue;
				}
				MacroSupport support = GetSupport(text2);
				if (!support.Supported)
				{
					list.Add(text2 + " unavailable: " + support.Reason);
					continue;
				}
				try
				{
					MacroWorkflow macroWorkflow = MacroWorkflows.Create(text2, new Dictionary<string, string>(macroEntry2.Values, StringComparer.Ordinal), _ritualSourceFactory, _webhookSender, _gankSender, _windowCapture, _charismaSourceFactory, _clipboardSetter);
					if (macroWorkflow.Triggers.Contains("esc", StringComparer.Ordinal))
					{
						throw new ArgumentException("Esc is reserved for stopping macros. Choose another hotkey.");
					}
					list2.Add(macroWorkflow with
					{
						Triggers = macroWorkflow.Triggers.Select((string k) => (!(k == "primary")) ? k : _input.PrimaryButton).ToArray()
					});
				}
				catch (Exception ex) when ((ex is ArgumentException || ex is FormatException || ex is OverflowException) ? true : false)
				{
					list.Add(text2 + ": " + ex.Message);
				}
			}
			lock (_gate)
			{
				_workflows = list2.OrderByDescending((MacroWorkflow w) => w.FlowDetector != null).ToList();
				_issues = string.Join("; ", list);
				Volatile.Write(ref _flowWorkflow, list2.FirstOrDefault((MacroWorkflow w) => w.FlowDetector != null));
				_foreground = _input.IsForegroundRoblox;
				_automaticPaused = false;
				SetStatusLocked(ReadyStatus());
				if (list2.Count == 0)
				{
					return;
				}
				_session = new CancellationTokenSource();
				CancellationTokenSource session = _session;
				_inputHandler = (MacroInputEvent e) =>
				{
					OnInput(e, session);
				};
				_input.Input += _inputHandler;
			}
			try
			{
				_input.Start(ShouldSuppress);
				CancellationTokenSource session2 = _session;
				lock (_gate)
				{
					if (list2.Any((MacroWorkflow w) => w.Id == "ritual-cast"))
					{
						foreach (string item in _input.SnapshotRitualKeysDown().Select(MacroKeys.Normalize))
						{
							bool flag = item.Length == 1;
							if (flag)
							{
								bool flag2;
								switch (item[0])
								{
								case '0':
								case '1':
								case '2':
								case '3':
								case '4':
								case '5':
								case '6':
								case '7':
								case '8':
								case '9':
								case 'a':
								case 'b':
								case 'c':
								case 'd':
								case 'e':
								case 'f':
								case 'g':
								case 'h':
								case 'i':
								case 'j':
								case 'k':
								case 'l':
								case 'm':
								case 'n':
								case 'o':
								case 'p':
								case 'q':
								case 'r':
								case 's':
								case 't':
								case 'u':
								case 'v':
								case 'w':
								case 'x':
								case 'y':
								case 'z':
									flag2 = true;
									break;
								default:
									flag2 = false;
									break;
								}
								flag = flag2;
							}
							if (flag && !_held.Contains(item))
							{
								_physical.Add(item);
							}
						}
					}
					_started = true;
					_monitorStarted = true;
				}
				WatchFocus(session2);
			}
			catch (Exception ex2)
			{
				StopCore();
				SetStatus("Error starting input: " + ex2.Message);
			}
		}
	}

	public void Stop()
	{
		lock (_lifecycle)
		{
			StopCore();
		}
	}

	private void StopCore()
	{
		lock (_gate)
		{
			if (_inputHandler != null)
			{
				_input.Input -= _inputHandler;
			}
			_inputHandler = null;
			CancellationTokenSource session = _session;
			_session = null;
			session?.Cancel();
			CancelActive();
			if (!_monitorStarted)
			{
				session?.Dispose();
			}
			_started = false;
			_monitorStarted = false;
			_physical.Clear();
			_pendingFlowInputs.Clear();
			_workflows.Clear();
			_sprinting = false;
			_lastWPress = 0L;
			Volatile.Write(ref _flowWorkflow, null);
			_issues = "";
			SetStatusLocked(_releaseError ?? "Off");
		}
		try
		{
			_input.Stop();
		}
		catch (Exception ex)
		{
			SetStatus("Error stopping input: " + ex.Message);
		}
	}

	private bool ShouldSuppress(MacroInputEvent e)
	{
		if (e.IsInjected)
		{
			return false;
		}
		string key = MacroKeys.Normalize(e.Key);
		MacroWorkflow macroWorkflow = Volatile.Read(in _flowWorkflow);
		bool isForegroundRoblox = _input.IsForegroundRoblox;
		bool flag = false;
		if (!isForegroundRoblox || key == "esc")
		{
			macroWorkflow?.FlowDetector?.Reset();
		}
		else if (key != Volatile.Read(in _interfaceKey))
		{
			flag = (object)macroWorkflow != null && macroWorkflow.FlowDetector?.Observe(e, Environment.TickCount64) == true;
		}
		if (!Monitor.TryEnter(_gate))
		{
			return false;
		}
		try
		{
			if (_session == null || key == _interfaceKey)
			{
				return false;
			}
			if (!isForegroundRoblox || key == "esc")
			{
				ResetFlowGestures();
				return false;
			}
			bool flag2 = _active == null;
			if (!flag2)
			{
				MacroRunMode mode = _active.Workflow.Mode;
				bool flag3 = (uint)(mode - 2) <= 1u;
				flag2 = flag3;
			}
			bool flag4 = flag2;
			if (flag && (object)macroWorkflow == _flowWorkflow && (flag4 || _active?.Workflow.Id == "auto-roll-cancel") && _pendingFlowInputs.Add(e))
			{
				return true;
			}
			return (e.IsDown & flag4) && _workflows.Any((MacroWorkflow w) => w.Suppress && w.Triggers.Contains(key, StringComparer.Ordinal));
		}
		finally
		{
			Monitor.Exit(_gate);
		}
	}

	private void OnInput(MacroInputEvent e, CancellationTokenSource originatingSession)
	{
		if (e.IsInjected)
		{
			return;
		}
		string text = MacroKeys.Normalize(e.Key);
		lock (_gate)
		{
			if (_session != originatingSession || text == _interfaceKey)
			{
				return;
			}
			if (text == "esc" && e.IsDown && _input.IsForegroundRoblox)
			{
				_automaticPaused = true;
				CancelActive();
				SetStatusLocked(ReadyStatus());
				return;
			}
			if (!_input.IsForegroundRoblox)
			{
				LoseFocus();
				return;
			}
			bool flag = _physical.Contains(text);
			if (e.IsDown)
			{
				_physical.Add(text);
			}
			else
			{
				_physical.Remove(text);
			}
			if (text == "esc" && e.IsDown)
			{
				_automaticPaused = true;
				CancelActive();
				SetStatusLocked(ReadyStatus());
				return;
			}
			if (text == "w")
			{
				if (!e.IsDown)
				{
					_sprinting = false;
				}
				else if (!flag)
				{
					long tickCount = Environment.TickCount64;
					_sprinting = _lastWPress != 0L && tickCount - _lastWPress <= 600;
					_lastWPress = tickCount;
				}
			}
			if (!e.IsDown && _active != null && ((_active.Workflow.Mode == MacroRunMode.Hold && _active.Trigger == text) || ((_active.Workflow.Id == "golden-tongue" || _active.Workflow.Id.StartsWith("chat-message-", StringComparison.Ordinal)) && text == "w")))
			{
				CancelActive();
				ResumeHeld();
				SetStatusLocked(ReadyStatus());
			}
			if (e.IsDown & flag)
			{
				return;
			}
			foreach (MacroWorkflow workflow in _workflows)
			{
				string text2 = null;
				if (workflow.FlowDetector != null)
				{
					if (!e.IsDown || !_pendingFlowInputs.Remove(e))
					{
						continue;
					}
					text2 = text;
				}
				else if (e.IsDown == workflow.OnRelease || !workflow.Triggers.Contains(text, StringComparer.Ordinal))
				{
					continue;
				}
				if ((workflow.OnRelease && !flag) || (workflow.Id == "mantra-slide-tech" && !_sprinting) || (workflow.Id == "dynamic-auto-uppercut" && _sprinting))
				{
					continue;
				}
				if (workflow.Id == "charisma-autofill" && _active?.Workflow.Id == workflow.Id)
				{
					_automaticPaused = true;
					CancelActive();
					SetStatusLocked(ReadyStatus());
					break;
				}
				if (workflow.Id == "charisma-autofill")
				{
					_automaticPaused = false;
				}
				if (_active != null)
				{
					if (_active.Workflow.Id == workflow.Id && workflow.Mode == MacroRunMode.Toggle)
					{
						CancelActive();
						SetStatusLocked(ReadyStatus());
						break;
					}
					if (workflow.FlowDetector == null && _active.Workflow.Mode != MacroRunMode.Automatic && (!(_active.Workflow.Id == "ritual-cast") || !(workflow.Id != "ritual-cast")) && (_active.Workflow.Mode != MacroRunMode.Hold || !(_active.Workflow.Id != workflow.Id)))
					{
						break;
					}
					CancelActive();
				}
				if (_held.Count != 0)
				{
					SetStatusLocked(_releaseError ?? "Error: input has not been released.");
					break;
				}
				Run run = new Run(workflow, text, CancellationTokenSource.CreateLinkedTokenSource(_session.Token));
				_active = run;
				SetStatusLocked("Running: " + workflow.Id + IssueSuffix());
				Task.Run(() => Execute(run, text2));
				break;
			}
		}
	}

	private async Task Execute(Run run, string? text)
	{
		string error = null;
		try
		{
			await run.Workflow.Execute(new MacroActions(this, run.Cancellation.Token), text);
		}
		catch (OperationCanceledException) when (run.Cancellation.IsCancellationRequested || !_input.IsForegroundRoblox)
		{
		}
		catch (Exception ex2)
		{
			error = "Error in " + run.Workflow.Id + ": " + ex2.Message;
		}
		finally
		{
			lock (_gate)
			{
				if ((object)_active == run)
				{
					string id = run.Workflow.Id;
					if ((id == "ritual-cast" || id == "charisma-autofill") ? true : false)
					{
						SetRitualPromptLocked(null);
					}
					if (run.Workflow.Mode == MacroRunMode.Automatic && error != null)
					{
						_automaticPaused = true;
					}
					string text2 = ReleaseHeld();
					_active = null;
					SetStatusLocked(error ?? text2 ?? ((!run.Cancellation.IsCancellationRequested) ? run.CompletionStatus : null) ?? ReadyStatus());
					if (error == null && text2 == null && !run.Cancellation.IsCancellationRequested && run.Workflow.Mode != MacroRunMode.Hold)
					{
						ResumeHeld();
					}
				}
			}
			run.Cancellation.Dispose();
		}
	}

	private void ResumeHeld()
	{
		if ((object)_active != null || _session == null || _held.Count != 0 || !_input.IsForegroundRoblox)
		{
			return;
		}
		MacroWorkflow macroWorkflow = _workflows.FirstOrDefault((MacroWorkflow w) => w.Mode == MacroRunMode.Hold && w.Triggers.Any(_physical.Contains));
		if ((object)macroWorkflow != null)
		{
			string trigger = macroWorkflow.Triggers.First(_physical.Contains);
			Run run = new Run(macroWorkflow, trigger, CancellationTokenSource.CreateLinkedTokenSource(_session.Token));
			_active = run;
			SetStatusLocked("Running: " + macroWorkflow.Id + IssueSuffix());
			Task.Run(() => Execute(run, null));
		}
	}

	private async Task WatchFocus(CancellationTokenSource session)
	{
		try
		{
			Exception failure;
			while (true)
			{
				await Task.Delay(25, session.Token);
				failure = _input.Failure;
				if (failure != null)
				{
					break;
				}
				lock (_gate)
				{
					if (_session != session)
					{
						return;
					}
					bool isForegroundRoblox = _input.IsForegroundRoblox;
					if (!isForegroundRoblox)
					{
						LoseFocus();
					}
					else if (!_foreground)
					{
						_foreground = true;
						_physical.Clear();
						SetStatusLocked(ReadyStatus());
					}
					if (!isForegroundRoblox || _automaticPaused || (object)_active != null || _held.Count != 0 || !_started)
					{
						continue;
					}
					MacroWorkflow macroWorkflow = _workflows.FirstOrDefault((MacroWorkflow w) => w.Mode == MacroRunMode.Automatic);
					if ((object)macroWorkflow != null)
					{
						Run run = new Run(macroWorkflow, "", CancellationTokenSource.CreateLinkedTokenSource(session.Token));
						_active = run;
						Task.Run(() => Execute(run, null));
					}
				}
			}
			throw new InvalidOperationException("Native input hook stopped.", failure);
		}
		catch (OperationCanceledException) when (session.IsCancellationRequested)
		{
		}
		catch (Exception ex2)
		{
			lock (_lifecycle)
			{
				lock (_gate)
				{
					if (_session != session)
					{
						return;
					}
					if (_inputHandler != null)
					{
						_input.Input -= _inputHandler;
					}
					_inputHandler = null;
					_session = null;
					_started = false;
					_monitorStarted = false;
					session.Cancel();
					CancelActive();
					SetStatusLocked("Error checking Roblox focus: " + ex2.Message);
				}
				try
				{
					_input.Stop();
				}
				catch (Exception ex3)
				{
					SetStatus("Error stopping native input: " + ex3.Message);
				}
			}
		}
		finally
		{
			session.Dispose();
		}
	}

	private void LoseFocus()
	{
		CancelActive();
		_physical.Clear();
		ResetFlowGestures();
		_sprinting = false;
		_lastWPress = 0L;
		if (_foreground)
		{
			_foreground = false;
			SetStatusLocked(ReadyStatus());
		}
	}

	private void CancelActive()
	{
		SetRitualPromptLocked(null);
		_active?.Cancellation.Cancel();
		_active = null;
		string text = ReleaseHeld();
		if (text != null)
		{
			SetStatusLocked(text);
		}
	}

	private void ResetFlowGestures()
	{
		_pendingFlowInputs.Clear();
		foreach (MacroWorkflow workflow in _workflows)
		{
			workflow.FlowDetector?.Reset();
		}
	}

	private string? ReleaseHeld()
	{
		string text = null;
		string[] array = _held.ToArray();
		foreach (string text2 in array)
		{
			try
			{
				ReleaseKey(text2);
			}
			catch (Exception ex)
			{
				text = "Error releasing " + text2 + ": " + ex.Message;
			}
		}
		_releaseError = text;
		return text;
	}

	private string ReadyStatus()
	{
		return _releaseError ?? (((_workflows.Count == 0) ? "No ready macros" : ((!_foreground) ? "Waiting for foreground Roblox" : ("Armed: " + _workflows.Count + " macros"))) + ((_automaticPaused && _workflows.Any((MacroWorkflow w) => w.Mode == MacroRunMode.Automatic)) ? " · Automatic training paused; press its hotkey or toggle macros off/on to resume" : "") + IssueSuffix());
	}

	private string IssueSuffix()
	{
		if (_issues.Length != 0)
		{
			return ". " + _issues;
		}
		return "";
	}

	private void SetStatus(string status)
	{
		lock (_gate)
		{
			SetStatusLocked(status);
		}
	}

	private void SetStatusLocked(string status)
	{
		if (_status == status)
		{
			return;
		}
		_status = status;
		if (StatusChanged == null)
		{
			return;
		}
		Delegate[] invocationList = StatusChanged.GetInvocationList();
		for (int i = 0; i < invocationList.Length; i++)
		{
			Action<string> action = (Action<string>)invocationList[i];
			try
			{
				action(status);
			}
			catch
			{
			}
		}
	}

	internal void Send(CancellationToken token, Action<IMacroInput> send)
	{
		lock (_gate)
		{
			token.ThrowIfCancellationRequested();
			if (_session == null || !_input.IsForegroundRoblox)
			{
				throw new OperationCanceledException(token);
			}
			send(_input);
		}
	}

	internal void ReportStatus(CancellationToken token, string status)
	{
		lock (_gate)
		{
			Run active = _active;
			if ((object)active != null && active.Cancellation.Token == token && !token.IsCancellationRequested && _input.IsForegroundRoblox)
			{
				SetStatusLocked(status + IssueSuffix());
			}
		}
	}

	internal void Complete(CancellationToken token, string status)
	{
		lock (_gate)
		{
			Run active = _active;
			if ((object)active != null && active.Cancellation.Token == token && !token.IsCancellationRequested)
			{
				active.CompletionStatus = status;
			}
		}
	}

	internal void Key(CancellationToken token, string key, bool down)
	{
		Send(token, (IMacroInput input) =>
		{
			if (down)
			{
				_held.Add(key);
				input.Key(key, down: true);
			}
			else
			{
				input.Key(key, down: false);
				_held.Remove(key);
			}
		});
	}

	internal string? PrepareFlowForGeneratedFeint(CancellationToken token, string key)
	{
		lock (_gate)
		{
			token.ThrowIfCancellationRequested();
			Run active = _active;
			if ((object)active != null && !(active.Cancellation.Token != token) && !(active.Workflow.Id != "auto-roll-cancel") && !active.FlowPrepared && _physical.Contains("ctrl") && !(key != ((_input.PrimaryButton == "mouse1") ? "mouse2" : "mouse1")))
			{
				string text = _flowWorkflow?.FlowStateKey;
				if (text != null)
				{
					active.FlowPrepared = true;
					return text;
				}
			}
			return null;
		}
	}

	public void Dispose()
	{
		lock (_lifecycle)
		{
			if (!_disposed)
			{
				StopCore();
				_disposed = true;
				_input.Dispose();
			}
		}
	}

	internal void BeginRitualTap(CancellationToken token, string key)
	{
		Send(token, (IMacroInput input) =>
		{
			if (_physical.Contains(key))
			{
				input.Key(key, down: false);
			}
			token.ThrowIfCancellationRequested();
			_ritualHeld.Add(key);
			_held.Add(key);
			input.Key(key, down: true);
		});
	}

	internal void EndRitualTap(CancellationToken token, string key)
	{
		Send(token, (IMacroInput _) =>
		{
			ReleaseKey(key);
		});
	}

	private void ReleaseKey(string key)
	{
		if (!_ritualHeld.Contains(key) || !_physical.Contains(key) || !_input.IsForegroundRoblox)
		{
			_input.Key(key, down: false);
		}
		_ritualHeld.Remove(key);
		_held.Remove(key);
	}
}
