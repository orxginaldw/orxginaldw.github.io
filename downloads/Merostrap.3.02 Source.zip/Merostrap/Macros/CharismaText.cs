using System.Linq;
using System.Text.RegularExpressions;

namespace Merostrap.Macros;

public static class CharismaText
{
	public static string[] Tokens(string text)
	{
		return (from m in Regex.Matches(text.Replace("’", "'").Replace("'", ""), "[\\p{L}\\p{N}]+")
			select m.Value.ToLowerInvariant()).ToArray();
	}
}
