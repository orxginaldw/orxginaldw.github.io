using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Media.Imaging;
using Avalonia.Platform;

namespace Merostrap.Macros;

internal static class GankWindowCapture
{
	private delegate bool WindowCallback(nint window, nint parameter);

	private struct Rect
	{
		public int Left;

		public int Top;

		public int Right;

		public int Bottom;
	}

	private struct BitmapHeader
	{
		public uint Size;

		public int Width;

		public int Height;

		public ushort Planes;

		public ushort BitCount;

		public uint Compression;

		public uint ImageSize;

		public int XPixelsPerMeter;

		public int YPixelsPerMeter;

		public uint ColorsUsed;

		public uint ImportantColors;
	}

	private struct BitmapInfo
	{
		public BitmapHeader Header;

		public uint Color;
	}

	private static readonly SemaphoreSlim CaptureGate = new SemaphoreSlim(1, 1);

	public static IReadOnlyList<GankWindowOption> List()
	{
		List<GankWindowOption> result = new List<GankWindowOption>
		{
			new GankWindowOption("", "No screenshot")
		};
		if (!OperatingSystem.IsWindows())
		{
			return result;
		}
		EnumWindows((nint handle, nint _) =>
		{
			if (!IsWindowVisible(handle) || IsIconic(handle))
			{
				return true;
			}
			StringBuilder stringBuilder = new StringBuilder(512);
			GetWindowText(handle, stringBuilder, stringBuilder.Capacity);
			if (stringBuilder.Length == 0)
			{
				return true;
			}
			GetWindowThreadProcessId(handle, out var pid);
			if (pid == Environment.ProcessId)
			{
				return true;
			}
			try
			{
				using Process process = Process.GetProcessById((int)pid);
				result.Add(new GankWindowOption($"{pid}:{((IntPtr)handle).ToInt64()}:{process.StartTime.ToUniversalTime().Ticks}", $"{stringBuilder} ({process.ProcessName})"));
			}
			catch
			{
			}
			return true;
		}, 0);
		return result.Take(1).Concat(result.Skip(1).OrderBy((GankWindowOption w) => w.Label, StringComparer.OrdinalIgnoreCase)).ToArray();
	}

	public static async Task<byte[]> CaptureAsync(string id, CancellationToken token)
	{
		if (!OperatingSystem.IsWindows())
		{
			throw new InvalidOperationException("Window screenshots require Windows.");
		}
		if (!(await CaptureGate.WaitAsync(0, token)))
		{
			throw new InvalidOperationException("A window capture is still busy. Try again later.");
		}
		Task<byte[]> task = Task.Run(() =>
		{
			try
			{
				token.ThrowIfCancellationRequested();
				return Capture(id, token);
			}
			finally
			{
				CaptureGate.Release();
			}
		});
		try
		{
			return await task.WaitAsync(TimeSpan.FromSeconds(3L), token);
		}
		catch (TimeoutException)
		{
			throw new InvalidOperationException("Selected window did not respond to capture.");
		}
	}

	private static nint Resolve(string id)
	{
		string[] array = id.Split(':');
		if (array.Length != 3 || !int.TryParse(array[0], out var result) || !long.TryParse(array[1], out var result2) || !long.TryParse(array[2], out var result3))
		{
			throw new InvalidOperationException("Select a screenshot window again.");
		}
		nint num = new IntPtr(result2);
		GetWindowThreadProcessId(num, out var pid);
		try
		{
			using Process process = Process.GetProcessById(result);
			if (pid != result || process.StartTime.ToUniversalTime().Ticks != result3 || !IsWindowVisible(num) || IsIconic(num))
			{
				throw new InvalidOperationException();
			}
			return num;
		}
		catch
		{
			throw new InvalidOperationException("Selected window is closed or minimized. Select it again.");
		}
	}

	private static byte[] Capture(string id, CancellationToken token)
	{
		nint window = Resolve(id);
		if (!GetWindowRect(window, out var rect))
		{
			throw new InvalidOperationException("Cannot read the selected window size.");
		}
		int num = rect.Right - rect.Left;
		int num2 = rect.Bottom - rect.Top;
		if (num <= 0 || num2 <= 0 || (long)num * (long)num2 > 16000000)
		{
			throw new InvalidOperationException("Selected window size cannot be captured.");
		}
		nint dC = GetDC(0);
		nint num3 = 0;
		nint num4 = 0;
		nint num5 = 0;
		try
		{
			num3 = CreateCompatibleDC(dC);
			BitmapInfo info = new BitmapInfo
			{
				Header = new BitmapHeader
				{
					Size = (uint)Marshal.SizeOf<BitmapHeader>(),
					Width = num,
					Height = -num2,
					Planes = 1,
					BitCount = 32
				}
			};
			num4 = CreateDIBSection(dC, ref info, 0u, out var pixels, 0, 0u);
			if (dC == 0 || num3 == 0 || num4 == 0 || pixels == 0)
			{
				throw new InvalidOperationException("Could not allocate a screenshot.");
			}
			num5 = SelectObject(num3, num4);
			if (!PrintWindow(window, num3, 2u))
			{
				throw new InvalidOperationException("Selected window does not support screenshots.");
			}
			token.ThrowIfCancellationRequested();
			Resolve(id);
			byte[] array = new byte[checked(num * num2 * 4)];
			Marshal.Copy(pixels, array, 0, array.Length);
			bool flag = false;
			for (int i = 0; i < array.Length; i += 4)
			{
				if (array[i] != 0 || array[i + 1] != 0 || array[i + 2] != 0)
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				throw new InvalidOperationException("Selected window returned a blank screenshot. No alert was sent.");
			}
			using Bitmap bitmap = new Bitmap(PixelFormat.Bgra8888, AlphaFormat.Opaque, pixels, new PixelSize(num, num2), new Vector(96.0, 96.0), num * 4);
			using MemoryStream memoryStream = new MemoryStream();
			bitmap.Save(memoryStream);
			token.ThrowIfCancellationRequested();
			return memoryStream.ToArray();
		}
		finally
		{
			if (num5 != 0 && num5 != -1)
			{
				SelectObject(num3, num5);
			}
			if (num4 != 0)
			{
				DeleteObject(num4);
			}
			if (num3 != 0)
			{
				DeleteDC(num3);
			}
			if (dC != 0)
			{
				ReleaseDC(0, dC);
			}
		}
	}

	[DllImport("user32.dll")]
	private static extern bool EnumWindows(WindowCallback callback, nint parameter);

	[DllImport("user32.dll")]
	private static extern bool IsWindowVisible(nint window);

	[DllImport("user32.dll")]
	private static extern bool IsIconic(nint window);

	[DllImport("user32.dll", CharSet = CharSet.Unicode)]
	private static extern int GetWindowText(nint window, StringBuilder text, int length);

	[DllImport("user32.dll")]
	private static extern uint GetWindowThreadProcessId(nint window, out uint pid);

	[DllImport("user32.dll")]
	private static extern bool GetWindowRect(nint window, out Rect rect);

	[DllImport("user32.dll")]
	private static extern bool PrintWindow(nint window, nint dc, uint flags);

	[DllImport("user32.dll")]
	private static extern nint GetDC(nint window);

	[DllImport("user32.dll")]
	private static extern int ReleaseDC(nint window, nint dc);

	[DllImport("gdi32.dll")]
	private static extern nint CreateCompatibleDC(nint dc);

	[DllImport("gdi32.dll")]
	private static extern nint CreateDIBSection(nint dc, ref BitmapInfo info, uint usage, out nint pixels, nint section, uint offset);

	[DllImport("gdi32.dll")]
	private static extern nint SelectObject(nint dc, nint item);

	[DllImport("gdi32.dll")]
	private static extern bool DeleteObject(nint item);

	[DllImport("gdi32.dll")]
	private static extern bool DeleteDC(nint dc);
}
