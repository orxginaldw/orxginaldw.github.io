using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Threading;
using CommunityToolkit.Mvvm.ComponentModel;
using Merostrap.Macros.Health;
using Merostrap.UI.Elements.Macros;

namespace Merostrap.Macros;

public sealed class FlowStateOverlayController : ObservableObject, IDisposable
{
	private readonly FlowStateOverlaySettings _settings;

	private readonly Action _save;

	private readonly Action _changed;

	private readonly bool _native;

	private readonly DispatcherTimer _timer = new DispatcherTimer
	{
		Interval = TimeSpan.FromMilliseconds(200L)
	};

	private readonly FlowStateCooldownReader _reader = new FlowStateCooldownReader();

	private readonly FlowStateCooldownCounter _counter = new FlowStateCooldownCounter();

	private FlowStateCooldownOverlay? _overlay;

	private bool _busy;

	private bool _disposed;

	private bool _foreground;

	private long _retry;

	private double? _percent;

	private string _status = "Waiting for Roblox";

	public bool Enabled
	{
		get
		{
			return _settings.Enabled;
		}
		set
		{
			if (value != Enabled)
			{
				_settings.Enabled = value;
				_save();
				OnPropertyChanged("Enabled");
				_changed();
			}
		}
	}

	public IReadOnlyList<string> Layouts { get; } = new string[2] { "Horizontal", "Vertical" };

	public int LayoutIndex
	{
		get
		{
			return _settings.Vertical ? 1 : 0;
		}
		set
		{
			bool flag = (uint)value <= 1u;
			if (flag && value != LayoutIndex)
			{
				_settings.Vertical = value == 1;
				_save();
				OnPropertyChanged("LayoutIndex");
				OnPropertyChanged("Orientation");
				OnPropertyChanged("BarWidth");
				OnPropertyChanged("BarHeight");
			}
		}
	}

	public Orientation Orientation
	{
		get
		{
			if (!_settings.Vertical)
			{
				return Orientation.Horizontal;
			}
			return Orientation.Vertical;
		}
	}

	public double BarWidth => _settings.Vertical ? 18 : 260;

	public double BarHeight => _settings.Vertical ? 260 : 18;

	public string BarColor
	{
		get
		{
			if (!Color.TryParse(_settings.Color, out var _))
			{
				return "#39BA68";
			}
			return _settings.Color;
		}
		set
		{
			if (Color.TryParse(value, out var _) && !(value == BarColor))
			{
				_settings.Color = value;
				_save();
				OnPropertyChanged("BarColor");
				OnPropertyChanged("FillBrush");
			}
		}
	}

	public IBrush FillBrush => Brush.Parse(BarColor);

	public double Fill => _percent.GetValueOrDefault();

	public string Status => _status;

	public int? X => _settings.X;

	public int? Y => _settings.Y;

	public FlowStateOverlayController(FlowStateOverlaySettings settings, Action save, Action changed, bool native = false)
	{
		_settings = settings;
		_save = save;
		_changed = changed;
		_native = native;
		_status = (settings.Enabled ? "Waiting for Roblox" : "Off");
		_timer.Tick += async (object? _, EventArgs _) =>
		{
			await ReadAsync();
		};
	}

	public void SavePosition(int x, int y)
	{
		_settings.X = x;
		_settings.Y = y;
		_save();
	}

	public void SetReading(FlowStateCooldownSample sample)
	{
		_percent = sample.ReadyPercent;
		_status = sample.Status;
		OnPropertyChanged("Fill");
		OnPropertyChanged("Status");
	}

	public void SetForeground(bool foreground)
	{
		_foreground = foreground;
		if (!Enabled || !foreground || _disposed)
		{
			_timer.Stop();
			_overlay?.Hide();
			if (!Enabled)
			{
				SetReading(new FlowStateCooldownSample(null, "Off"));
			}
		}
		else if (_native)
		{
			if (_overlay == null)
			{
				_overlay = new FlowStateCooldownOverlay(this);
			}
			if (!_overlay.IsVisible)
			{
				_overlay.Show();
			}
			_timer.Start();
		}
	}

	private async Task ReadAsync()
	{
		if (_busy || _disposed || !_foreground || !Enabled || Environment.TickCount64 < _retry)
		{
			return;
		}
		_busy = true;
		try
		{
			FlowStateCooldownSample flowStateCooldownSample = await Task.Run(() =>
			{
				nint num = WindowsHealthCapture.ForegroundRobloxWindow();
				HealthRegion healthRegion = WindowsHealthCapture.ForegroundRobloxClientArea();
				if (num == IntPtr.Zero || (object)healthRegion == null)
				{
					return new FlowStateCooldownSample(null, "Waiting for Roblox");
				}
				int num2 = Math.Min(216, Math.Max(40, healthRegion.Height / 10));
				HealthRegion region = new HealthRegion(healthRegion.X + healthRegion.Width / 5, healthRegion.Y + healthRegion.Height - num2, healthRegion.Width * 3 / 5, num2);
				HealthPixels hotbar = new WindowsHealthCapture().Capture(region);
				return (WindowsHealthCapture.ForegroundRobloxWindow() != num) ? new FlowStateCooldownSample(null, "Waiting for Roblox") : _reader.Analyze(hotbar);
			});
			if (!_disposed)
			{
				SetReading(_counter.Observe(flowStateCooldownSample, Environment.TickCount64));
			}
			if (!flowStateCooldownSample.ReadyPercent.HasValue)
			{
				_retry = Environment.TickCount64 + 1000;
			}
		}
		catch (Exception ex) when (!(ex is OutOfMemoryException))
		{
			if (!_disposed)
			{
				SetReading(_counter.Observe(new FlowStateCooldownSample(null, "Hotbar unavailable"), Environment.TickCount64));
			}
			_retry = Environment.TickCount64 + 1000;
		}
		finally
		{
			_busy = false;
			if (_disposed)
			{
				_reader.Dispose();
			}
		}
	}

	public void Dispose()
	{
		_disposed = true;
		_timer.Stop();
		_overlay?.Close();
		if (!_busy)
		{
			_reader.Dispose();
		}
	}
}
