using System;
using System.Collections.Generic;

namespace Merostrap.Macros;

internal sealed class SilentheartFlowDetector(string dodge, string crouch, string jump, string feint)
{
	private readonly HashSet<string> _down = new HashSet<string>(StringComparer.Ordinal);

	private readonly object _gate = new object();

	private long _lastForward = -10000L;

	private long _dodgeUntil;

	private long _slideUntil;

	private long _aerialUntil;

	private bool _sprinting;

	private bool _aerialAttack;

	public bool Observe(MacroInputEvent input, long now)
	{
		lock (_gate)
		{
			return ObserveCore(input, now);
		}
	}

	private bool ObserveCore(MacroInputEvent input, long now)
	{
		if (input.IsInjected)
		{
			return false;
		}
		string text = MacroKeys.Normalize(input.Key);
		if (!input.IsDown)
		{
			_down.Remove(text);
			if (text == "w")
			{
				_sprinting = false;
			}
			return false;
		}
		if (!_down.Add(text))
		{
			return false;
		}
		if (text == "w")
		{
			_sprinting = now - _lastForward <= 600;
			_lastForward = now;
		}
		if (text == dodge)
		{
			_dodgeUntil = now + 250;
		}
		if (text == crouch && _down.Contains("w") && _sprinting)
		{
			_slideUntil = now + 700;
		}
		if (text == jump)
		{
			_aerialUntil = now + 1200;
			_aerialAttack = false;
		}
		if (text == feint && _down.Contains("ctrl"))
		{
			return true;
		}
		if (text != "mouse1")
		{
			return false;
		}
		if (_dodgeUntil > now || _slideUntil > now)
		{
			_dodgeUntil = (_slideUntil = 0L);
			return true;
		}
		if (_aerialUntil > now)
		{
			if (_aerialAttack)
			{
				_aerialUntil = 0L;
				_aerialAttack = false;
				return true;
			}
			_aerialAttack = true;
			_aerialUntil = Math.Min(_aerialUntil, now + 700);
		}
		return false;
	}

	public void Reset()
	{
		lock (_gate)
		{
			_down.Clear();
			_lastForward = -10000L;
			_dodgeUntil = (_slideUntil = (_aerialUntil = 0L));
			_sprinting = (_aerialAttack = false);
		}
	}
}
