using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;

namespace Merostrap.Macros;

public sealed class WindowsMacroInput : IMacroInput, IDisposable
{
	private sealed class HookSession
	{
		private readonly WindowsMacroInput _owner;

		private readonly Func<MacroInputEvent, bool> _suppress;

		private readonly HashSet<string> _blocked = new HashSet<string>(StringComparer.Ordinal);

		private long _sequence;

		private readonly object _hooks = new object();

		private readonly HookCallback _keyboardCallback;

		private readonly HookCallback _mouseCallback;

		private readonly MacroInputDispatcher _dispatcher;

		private nint _keyboard;

		private nint _mouse;

		public uint ThreadId;

		public bool Stopping;

		public Thread Thread { get; }

		public ManualResetEventSlim Ready { get; } = new ManualResetEventSlim(initialState: false);

		public Exception? Error { get; private set; }

		public HookSession(WindowsMacroInput owner, Func<MacroInputEvent, bool> suppress)
		{
			_owner = owner;
			_suppress = suppress;
			_keyboardCallback = Keyboard;
			_mouseCallback = Mouse;
			Action<MacroInputEvent> receive = owner.Input;
			_dispatcher = new MacroInputDispatcher((MacroInputEvent input) =>
			{
				if (!Volatile.Read(in Stopping))
				{
					receive?.Invoke(input);
				}
			}, (Exception e) =>
			{
				Error = e;
			});
			Thread = new Thread(Pump)
			{
				IsBackground = true,
				Name = "Merostrap macro input"
			};
		}

		private void Pump()
		{
			try
			{
				ThreadId = GetCurrentThreadId();
				PeekMessage(out var _, IntPtr.Zero, 0u, 0u, 0u);
				lock (_hooks)
				{
					if (Volatile.Read(in Stopping))
					{
						return;
					}
					_keyboard = SetWindowsHookEx(13, _keyboardCallback, GetModuleHandle(null), 0u);
					if (_keyboard == IntPtr.Zero)
					{
						throw new Win32Exception(Marshal.GetLastWin32Error());
					}
					_mouse = SetWindowsHookEx(14, _mouseCallback, GetModuleHandle(null), 0u);
					if (_mouse == IntPtr.Zero)
					{
						throw new Win32Exception(Marshal.GetLastWin32Error());
					}
				}
				Ready.Set();
				while (!Volatile.Read(in Stopping))
				{
					int message2 = GetMessage(out var message3, IntPtr.Zero, 0u, 0u);
					if (message2 < 0)
					{
						throw new Win32Exception(Marshal.GetLastWin32Error());
					}
					if (message2 == 0)
					{
						break;
					}
					TranslateMessage(ref message3);
					DispatchMessage(ref message3);
				}
				if (!Volatile.Read(in Stopping))
				{
					Error = new InvalidOperationException("Windows input hook message loop exited.");
				}
			}
			catch (Exception error)
			{
				Error = error;
			}
			finally
			{
				Unhook();
				Ready.Set();
			}
		}

		public void Unhook()
		{
			lock (_hooks)
			{
				_dispatcher.Dispose();
				if (_keyboard != IntPtr.Zero)
				{
					UnhookWindowsHookEx(_keyboard);
					_keyboard = IntPtr.Zero;
				}
				if (_mouse != IntPtr.Zero)
				{
					UnhookWindowsHookEx(_mouse);
					_mouse = IntPtr.Zero;
				}
			}
		}

		private nint Keyboard(int code, nuint message, nint data)
		{
			if (code >= 0 && !Volatile.Read(in Stopping))
			{
				KeyboardHook keyboardHook = Marshal.PtrToStructure<KeyboardHook>(data);
				uint num = ((UIntPtr)message).ToUInt32();
				bool flag = (keyboardHook.Flags & 0x10) == 0;
				if (flag)
				{
					bool flag2 = ((num - 256 <= 1 || num - 260 <= 1) ? true : false);
					flag = flag2;
				}
				if (flag)
				{
					string text = MacroKeys.FromKeyboard(keyboardHook.VirtualKey, keyboardHook.Scan, (keyboardHook.Flags & 1) != 0);
					flag = text.Length > 0;
					if (flag)
					{
						string key = text;
						bool flag2 = ((num == 256 || num == 260) ? true : false);
						flag = Publish(new MacroInputEvent(key, flag2, IsInjected: false, 0L));
					}
					if (flag)
					{
						return 1;
					}
				}
			}
			return CallNextHookEx(IntPtr.Zero, code, message, data);
		}

		private nint Mouse(int code, nuint message, nint data)
		{
			if (code >= 0 && !Volatile.Read(in Stopping))
			{
				MouseHook mouseHook = Marshal.PtrToStructure<MouseHook>(data);
				if ((mouseHook.Flags & 1) == 0)
				{
					uint num = ((UIntPtr)message).ToUInt32();
					string text;
					switch (num)
					{
					case 513u:
					case 514u:
						text = "mouse1";
						break;
					case 516u:
					case 517u:
						text = "mouse2";
						break;
					case 519u:
					case 520u:
						text = "mouse3";
						break;
					case 523u:
					case 524u:
						text = ((mouseHook.MouseData >> 16 == 1) ? "mouse4" : "mouse5");
						break;
					default:
						text = "";
						break;
					}
					string text2 = text;
					bool flag = text2.Length > 0;
					if (flag)
					{
						text = text2;
						bool isDown;
						switch (num)
						{
						case 513u:
						case 516u:
						case 519u:
						case 523u:
							isDown = true;
							break;
						default:
							isDown = false;
							break;
						}
						flag = Publish(new MacroInputEvent(text, isDown, IsInjected: false, 0L));
					}
					if (flag)
					{
						return 1;
					}
				}
			}
			return CallNextHookEx(IntPtr.Zero, code, message, data);
		}

		private bool Publish(MacroInputEvent input)
		{
			try
			{
				input = input with
				{
					Sequence = ++_sequence
				};
				bool isForegroundRoblox = _owner.IsForegroundRoblox;
				if (!isForegroundRoblox)
				{
					_blocked.Clear();
				}
				bool flag = _suppress(input);
				int num;
				if (isForegroundRoblox)
				{
					num = ((input.IsDown ? (_blocked.Contains(input.Key) | flag) : _blocked.Remove(input.Key)) ? 1 : 0);
					if (num != 0 && input.IsDown)
					{
						_blocked.Add(input.Key);
					}
				}
				else
				{
					num = 0;
				}
				_dispatcher.Publish(input, ShouldDispatchPhysicalInput(input, isForegroundRoblox, _owner.GlobalKeys));
				return (byte)num != 0;
			}
			catch (Exception error)
			{
				Error = error;
				return false;
			}
		}
	}

	[UnmanagedFunctionPointer(CallingConvention.Winapi)]
	private delegate nint HookCallback(int code, nuint message, nint data);

	private struct NativeInput
	{
		public uint Type;

		public InputUnion Data;
	}

	[StructLayout(LayoutKind.Explicit)]
	private struct InputUnion
	{
		[FieldOffset(0)]
		public MouseInput Mouse;

		[FieldOffset(0)]
		public KeyboardInput Keyboard;
	}

	private struct MouseInput
	{
		public int X;

		public int Y;

		public uint MouseData;

		public uint Flags;

		public uint Time;

		public nuint Extra;
	}

	private struct KeyboardInput
	{
		public ushort VirtualKey;

		public ushort Scan;

		public uint Flags;

		public uint Time;

		public nuint Extra;
	}

	private struct KeyboardHook
	{
		public uint VirtualKey;

		public uint Scan;

		public uint Flags;

		public uint Time;

		public nuint Extra;
	}

	private struct Point
	{
		public int X;

		public int Y;
	}

	private struct MouseHook
	{
		public Point Point;

		public uint MouseData;

		public uint Flags;

		public uint Time;

		public nuint Extra;
	}

	private struct Message
	{
		public nint Window;

		public uint Id;

		public nuint WParam;

		public nint LParam;

		public uint Time;

		public Point Point;

		public uint Private;
	}

	private readonly object _lifecycle = new object();

	private HookSession? _session;

	private bool _disposed;

	[ThreadStatic]
	private static char[]? _processImageBuffer;

	public IReadOnlySet<string>? GlobalKeys { get; init; }

	public bool IsAvailable => OperatingSystem.IsWindows();

	public Exception? Failure => _session?.Error;

	public string PrimaryButton
	{
		get
		{
			if (!IsAvailable || GetSystemMetrics(23) == 0)
			{
				return "mouse1";
			}
			return "mouse2";
		}
	}

	public (int Width, int Height) ScreenSize
	{
		get
		{
			if (!IsAvailable)
			{
				return (Width: 0, Height: 0);
			}
			return (Width: GetSystemMetrics(0), Height: GetSystemMetrics(1));
		}
	}

	public bool IsForegroundRoblox => CheckForegroundRoblox();

	public event Action<MacroInputEvent>? Input;

	internal static bool CheckForegroundRoblox()
	{
		if (!OperatingSystem.IsWindows())
		{
			return false;
		}
		nint foregroundWindow = GetForegroundWindow();
		if (foregroundWindow == IntPtr.Zero)
		{
			return false;
		}
		GetWindowThreadProcessId(foregroundWindow, out var processId);
		nint num = OpenProcess(4096u, inheritHandle: false, processId);
		if (num == IntPtr.Zero)
		{
			return false;
		}
		try
		{
			char[] array = _processImageBuffer ?? (_processImageBuffer = new char[1024]);
			uint size = (uint)array.Length;
			if (!QueryFullProcessImageName(num, 0u, array, ref size))
			{
				if (Marshal.GetLastWin32Error() != 122 || array.Length >= 32768)
				{
					return false;
				}
				array = (_processImageBuffer = new char[32768]);
				size = (uint)array.Length;
				if (!QueryFullProcessImageName(num, 0u, array, ref size))
				{
					return false;
				}
			}
			ReadOnlySpan<char> fileName = Path.GetFileName(array.AsSpan(0, checked((int)size)));
			if ((!MemoryExtensions.Equals(fileName, "RobloxPlayerBeta.exe", StringComparison.OrdinalIgnoreCase) && !MemoryExtensions.Equals(fileName, "RobloxPlayer.exe", StringComparison.OrdinalIgnoreCase)) || GetForegroundWindow() != foregroundWindow)
			{
				return false;
			}
			GetWindowThreadProcessId(foregroundWindow, out var processId2);
			return processId2 == processId;
		}
		finally
		{
			CloseHandle(num);
		}
	}

	public void Start(Func<MacroInputEvent, bool> suppress)
	{
		ArgumentNullException.ThrowIfNull(suppress, "suppress");
		lock (_lifecycle)
		{
			ObjectDisposedException.ThrowIf(_disposed, this);
			if (!IsAvailable)
			{
				throw new PlatformNotSupportedException("Windows input automation requires Windows.");
			}
			Stop();
			HookSession hookSession = (_session = new HookSession(this, suppress));
			hookSession.Thread.Start();
			if (!hookSession.Ready.Wait(TimeSpan.FromSeconds(2L)))
			{
				Stop();
				throw new TimeoutException("Windows input hooks did not start within two seconds.");
			}
			if (hookSession.Error != null)
			{
				Stop();
				throw new InvalidOperationException("Could not install Windows input hooks.", hookSession.Error);
			}
		}
	}

	public IReadOnlyCollection<string> SnapshotRitualKeysDown()
	{
		if (!IsAvailable)
		{
			return Array.Empty<string>();
		}
		List<string> list = new List<string>();
		string text = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		foreach (char c in text)
		{
			if ((GetAsyncKeyState(c) & 0x8000) != 0)
			{
				list.Add(char.ToLowerInvariant(c).ToString());
			}
		}
		return list;
	}

	public void Stop()
	{
		lock (_lifecycle)
		{
			HookSession session = _session;
			_session = null;
			if (session != null)
			{
				Volatile.Write(ref session.Stopping, value: true);
				session.Unhook();
				if (session.ThreadId != 0)
				{
					PostThreadMessage(session.ThreadId, 18u, UIntPtr.Zero, IntPtr.Zero);
				}
			}
		}
	}

	public void Key(string key, bool down)
	{
		if (!IsAvailable)
		{
			throw new PlatformNotSupportedException();
		}
		key = MacroKeys.Normalize(key);
		if (!MacroKeys.TryVirtualKey(key, out var code))
		{
			throw new ArgumentException("Unknown input key: " + key, "key");
		}
		NativeInput input;
		if (key.StartsWith("mouse", StringComparison.Ordinal))
		{
			uint flags = key switch
			{
				"mouse1" => down ? 2u : 4u, 
				"mouse2" => down ? 8u : 16u, 
				"mouse3" => down ? 32u : 64u, 
				_ => down ? 128u : 256u, 
			};
			input = new NativeInput
			{
				Type = 0u,
				Data = new InputUnion
				{
					Mouse = new MouseInput
					{
						Flags = flags,
						MouseData = ((key == "mouse4") ? 1u : ((key == "mouse5") ? 2u : 0u))
					}
				}
			};
		}
		else
		{
			uint num = MapVirtualKey(code, 0u);
			if (num == 0)
			{
				throw new InvalidOperationException("Windows cannot map input key: " + key);
			}
			bool flag;
			switch (code)
			{
			case 33:
			case 34:
			case 35:
			case 36:
			case 37:
			case 38:
			case 39:
			case 40:
			case 41:
			case 42:
			case 43:
			case 44:
			case 45:
			case 46:
			case 111:
				flag = true;
				break;
			default:
				flag = false;
				break;
			}
			bool flag2 = flag || key == "numpad enter";
			input = new NativeInput
			{
				Type = 1u,
				Data = new InputUnion
				{
					Keyboard = new KeyboardInput
					{
						Scan = (ushort)num,
						Flags = ((uint)(8 | ((!down) ? 2 : 0)) | (flag2 ? 1u : 0u))
					}
				}
			};
		}
		Send(input);
	}

	public void Move(int x, int y)
	{
		if (!IsAvailable)
		{
			throw new PlatformNotSupportedException();
		}
		int systemMetrics = GetSystemMetrics(76);
		int systemMetrics2 = GetSystemMetrics(77);
		int systemMetrics3 = GetSystemMetrics(78);
		int systemMetrics4 = GetSystemMetrics(79);
		if (x < systemMetrics || x >= (long)systemMetrics + (long)systemMetrics3 || y < systemMetrics2 || y >= (long)systemMetrics2 + (long)systemMetrics4)
		{
			throw new ArgumentOutOfRangeException("x", "Coordinates are outside the current desktop.");
		}
		Send(new NativeInput
		{
			Type = 0u,
			Data = new InputUnion
			{
				Mouse = new MouseInput
				{
					X = (int)((long)(x - systemMetrics) * 65535L / (systemMetrics3 - 1)),
					Y = (int)((long)(y - systemMetrics2) * 65535L / (systemMetrics4 - 1)),
					Flags = 49153u
				}
			}
		});
	}

	public void Scroll(int delta)
	{
		if (!IsAvailable)
		{
			throw new PlatformNotSupportedException();
		}
		if ((delta < -1200 || delta > 1200 || delta == 0) ? true : false)
		{
			throw new ArgumentOutOfRangeException("delta");
		}
		Send(new NativeInput
		{
			Type = 0u,
			Data = new InputUnion
			{
				Mouse = new MouseInput
				{
					MouseData = (uint)delta,
					Flags = 2048u
				}
			}
		});
	}

	public void Character(char character)
	{
		NativeInput[] inputs = new NativeInput[2]
		{
			new NativeInput
			{
				Type = 1u,
				Data = new InputUnion
				{
					Keyboard = new KeyboardInput
					{
						Scan = character,
						Flags = 4u
					}
				}
			},
			new NativeInput
			{
				Type = 1u,
				Data = new InputUnion
				{
					Keyboard = new KeyboardInput
					{
						Scan = character,
						Flags = 6u
					}
				}
			}
		};
		if (!IsAvailable)
		{
			throw new PlatformNotSupportedException();
		}
		if (SendInput(2u, inputs, Marshal.SizeOf<NativeInput>()) != 2)
		{
			throw new Win32Exception(Marshal.GetLastWin32Error(), "Windows blocked text input.");
		}
	}

	private static void Send(NativeInput input)
	{
		if (SendInput(1u, new NativeInput[1] { input }, Marshal.SizeOf<NativeInput>()) != 1)
		{
			throw new Win32Exception(Marshal.GetLastWin32Error(), "Windows blocked macro input. Roblox and Merostrap must use compatible privilege levels.");
		}
	}

	public void Dispose()
	{
		lock (_lifecycle)
		{
			if (!_disposed)
			{
				Stop();
				_disposed = true;
			}
		}
	}

	internal static bool ShouldDispatchPhysicalInput(MacroInputEvent input, bool foreground, IReadOnlySet<string>? globalKeys)
	{
		if (!input.IsInjected)
		{
			if (globalKeys != null)
			{
				return globalKeys.Contains(input.Key);
			}
			if (!foreground)
			{
				return input.Key == "esc";
			}
			return true;
		}
		return false;
	}

	[DllImport("user32.dll", SetLastError = true)]
	private static extern uint SendInput(uint count, NativeInput[] inputs, int size);

	[DllImport("user32.dll")]
	private static extern uint MapVirtualKey(uint code, uint mapType);

	[DllImport("user32.dll")]
	private static extern short GetAsyncKeyState(int virtualKey);

	[DllImport("user32.dll")]
	private static extern nint GetForegroundWindow();

	[DllImport("user32.dll")]
	private static extern uint GetWindowThreadProcessId(nint window, out uint processId);

	[DllImport("kernel32.dll")]
	private static extern nint OpenProcess(uint access, [MarshalAs(UnmanagedType.Bool)] bool inheritHandle, uint processId);

	[DllImport("kernel32.dll", CharSet = CharSet.Unicode, EntryPoint = "QueryFullProcessImageNameW", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool QueryFullProcessImageName(nint process, uint flags, [Out] char[] name, ref uint size);

	[DllImport("kernel32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool CloseHandle(nint handle);

	[DllImport("user32.dll")]
	private static extern int GetSystemMetrics(int index);

	[DllImport("user32.dll", SetLastError = true)]
	private static extern nint SetWindowsHookEx(int id, HookCallback callback, nint module, uint threadId);

	[DllImport("user32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool UnhookWindowsHookEx(nint hook);

	[DllImport("user32.dll")]
	private static extern nint CallNextHookEx(nint hook, int code, nuint message, nint data);

	[DllImport("user32.dll")]
	private static extern int GetMessage(out Message message, nint window, uint min, uint max);

	[DllImport("user32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool PeekMessage(out Message message, nint window, uint min, uint max, uint remove);

	[DllImport("user32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool TranslateMessage(ref Message message);

	[DllImport("user32.dll")]
	private static extern nint DispatchMessage(ref Message message);

	[DllImport("user32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool PostThreadMessage(uint threadId, uint message, nuint wParam, nint lParam);

	[DllImport("kernel32.dll")]
	private static extern uint GetCurrentThreadId();

	[DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
	private static extern nint GetModuleHandle(string? module);
}
