using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using Merostrap.Macros.Health;
using Tesseract;

namespace Merostrap.Macros;

public sealed class HealthTextReader : IDisposable
{
	private readonly object _gate = new object();

	private TesseractEngine? _engine;

	private bool _disposed;

	private int _preferredThreshold = 145;

	public HealthSample Analyze(HealthPixels pixels)
	{
		lock (_gate)
		{
			if (_disposed)
			{
				return new HealthSample(null, "Health reader stopped.");
			}
			int width = pixels.Width;
			bool flag = ((width < 30 || width > 4096) ? true : false);
			bool flag2 = flag;
			if (!flag2)
			{
				int height = pixels.Height;
				bool flag3 = ((height < 4 || height > 300) ? true : false);
				flag2 = flag3;
			}
			if (flag2 || pixels.Bgra == null || pixels.Bgra.Length != (long)pixels.Width * (long)pixels.Height * 4)
			{
				return new HealthSample(null, "Invalid health image.");
			}
			HealthSample healthSample = HealthBarAnalyzer.AnalyzeSelection(pixels);
			if (healthSample.Percent.HasValue)
			{
				return healthSample;
			}
			if (_engine == null)
			{
				string path = (TesseractEnviornment.CustomSearchPath = HealthOcrResources.EnsureAvailable());
				_engine = new TesseractEngine(Path.Combine(path, "tessdata"), "eng", EngineMode.LstmOnly);
			}
			HealthSample healthSample2 = new HealthSample(null, "Health number is unclear.");
			int[] array = new int[4] { 0, 145, 110, 180 };
			array[0] = _preferredThreshold;
			foreach (int item in array.Distinct())
			{
				healthSample2 = Read(pixels, item);
				if (healthSample2.Percent.HasValue)
				{
					_preferredThreshold = item;
					return healthSample2;
				}
			}
			return healthSample2;
		}
	}

	private HealthSample Read(HealthPixels pixels, int threshold)
	{
		using Pix image = Pix.LoadFromMemory(TextBitmap(pixels, threshold));
		using Page page = _engine.Process(image, (threshold == 180) ? PageSegMode.SingleLine : PageSegMode.SparseText);
		using ResultIterator resultIterator = page.GetIterator();
		resultIterator.Begin();
		HealthSample healthSample = null;
		do
		{
			HealthSample healthSample2 = Parse(resultIterator.GetText(PageIteratorLevel.TextLine) ?? "");
			if (healthSample2.Percent.HasValue)
			{
				if ((object)healthSample != null)
				{
					return new HealthSample(null, "Multiple health numbers detected.");
				}
				if (resultIterator.GetConfidence(PageIteratorLevel.TextLine) < 65f)
				{
					return new HealthSample(null, "Health number is unclear.");
				}
				if (!resultIterator.TryGetBoundingBox(PageIteratorLevel.TextLine, out var bounds))
				{
					return new HealthSample(null, "Health text location is unclear.");
				}
				int num = Math.Clamp((bounds.Y1 - 16) / 4, 0, pixels.Height - 1);
				int bottom = Math.Clamp((bounds.Y2 - 16) / 4, num + 1, pixels.Height);
				healthSample = VerifyFill(pixels, healthSample2, num, bottom);
			}
		}
		while (resultIterator.Next(PageIteratorLevel.TextLine));
		return healthSample ?? new HealthSample(null, "Health number not detected. Include the percentage and HEALTH text.");
	}

	public static HealthSample Parse(string text)
	{
		MatchCollection matchCollection = Regex.Matches(text, "(?<![\\d.])(100|[1-9]?\\d)\\s*%\\s*HEALTH\\b", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
		if (matchCollection.Count != 1)
		{
			return new HealthSample(null, "Health number not detected. Include the percentage and HEALTH text.");
		}
		double value = double.Parse(matchCollection[0].Groups[1].Value, CultureInfo.InvariantCulture);
		return new HealthSample(value, $"Health {value:0}% · text verified");
	}

	private static HealthSample VerifyFill(HealthPixels pixels, HealthSample sample, int top, int bottom)
	{
		int num = pixels.Width;
		int num2 = -1;
		for (int i = 0; i < pixels.Width; i++)
		{
			int num3 = 0;
			for (int j = Math.Max(0, top - 2); j < Math.Min(pixels.Height, bottom + 2); j++)
			{
				int num4 = (j * pixels.Width + i) * 4;
				byte b = pixels.Bgra[num4];
				byte b2 = pixels.Bgra[num4 + 1];
				byte b3 = pixels.Bgra[num4 + 2];
				if (b3 >= 85 && b3 > b2 && b2 > b && (double)(b3 - b) > (double)(int)b3 * 0.35)
				{
					double num5 = (double)(b2 - b) * 60.0 / (double)(b3 - b);
					if (num5 >= 10.0 && num5 <= 50.0)
					{
						num3++;
					}
				}
			}
			if (num3 >= 3)
			{
				num = Math.Min(num, i);
				num2 = i;
			}
		}
		if (num2 < num)
		{
			if (!(sample.Percent <= 5.0))
			{
				return new HealthSample(null, "Health fill not detected.");
			}
			return sample;
		}
		if ((double)num > (double)pixels.Width * 0.2)
		{
			return new HealthSample(null, "Select the whole health bar.");
		}
		int num6 = pixels.Width - num * 2;
		if (!(Math.Abs(Math.Clamp((double)(num2 - num + 1) * 100.0 / (double)num6, 0.0, 100.0) - sample.Percent.Value) <= 3.0))
		{
			return new HealthSample(null, "Health number and fill disagree.");
		}
		return sample;
	}

	private static byte[] TextBitmap(HealthPixels pixels, int threshold)
	{
		int num = pixels.Width * 4 + 32;
		int num2 = pixels.Height * 4 + 32;
		int num3 = (num * 3 + 3) & -4;
		using MemoryStream memoryStream = new MemoryStream();
		using BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write((ushort)19778);
		binaryWriter.Write(54 + num3 * num2);
		binaryWriter.Write(0);
		binaryWriter.Write(54);
		binaryWriter.Write(40);
		binaryWriter.Write(num);
		binaryWriter.Write(num2);
		binaryWriter.Write((ushort)1);
		binaryWriter.Write((ushort)24);
		binaryWriter.Write(0);
		binaryWriter.Write(num3 * num2);
		binaryWriter.Write(0);
		binaryWriter.Write(0);
		binaryWriter.Write(0);
		binaryWriter.Write(0);
		byte[] array = new byte[num3];
		for (int num4 = num2 - 1; num4 >= 0; num4--)
		{
			Array.Fill(array, byte.MaxValue);
			for (int i = 16; i < num - 16; i++)
			{
				if (num4 < 16)
				{
					break;
				}
				if (num4 >= num2 - 16)
				{
					break;
				}
				int num5 = ((num4 - 16) / 4 * pixels.Width + (i - 16) / 4) * 4;
				byte val = pixels.Bgra[num5];
				byte val2 = pixels.Bgra[num5 + 1];
				byte val3 = pixels.Bgra[num5 + 2];
				byte b = Math.Min(val3, Math.Min(val2, val));
				byte b2 = Math.Max(val3, Math.Max(val2, val));
				byte b3 = (byte)((b < threshold || b2 - b >= 65) ? 255u : 0u);
				array[i * 3] = (array[i * 3 + 1] = (array[i * 3 + 2] = b3));
			}
			binaryWriter.Write(array);
		}
		return memoryStream.ToArray();
	}

	public void Dispose()
	{
		lock (_gate)
		{
			_disposed = true;
			_engine?.Dispose();
			_engine = null;
		}
	}
}
