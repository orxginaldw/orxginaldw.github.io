using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace Merostrap.Macros;

internal static class GankWebhook
{
	private static readonly HttpClient Client = new HttpClient(new HttpClientHandler
	{
		AllowAutoRedirect = false
	})
	{
		Timeout = TimeSpan.FromSeconds(10L)
	};

	public static Uri Validate(string url, string message)
	{
		bool flag = !Uri.TryCreate(url.Trim(), UriKind.Absolute, out Uri result) || result.Scheme != "https" || result.Port != 443 || result.UserInfo.Length != 0;
		if (!flag)
		{
			bool flag2;
			switch (result.Host)
			{
			case "discord.com":
			case "discordapp.com":
			case "canary.discord.com":
			case "ptb.discord.com":
				flag2 = true;
				break;
			default:
				flag2 = false;
				break;
			}
			flag = !flag2;
		}
		if (flag || !Regex.IsMatch(result.AbsolutePath, "^/api(?:/v[0-9]+)?/webhooks/[0-9]+/[A-Za-z0-9_-]+$"))
		{
			throw new ArgumentException("Enter a valid Discord webhook URL.");
		}
		if (string.IsNullOrWhiteSpace(message) || message.Length > 2000)
		{
			throw new ArgumentException("Message must contain 1 to 2000 characters.");
		}
		return new UriBuilder(result)
		{
			Query = "wait=true",
			Fragment = ""
		}.Uri;
	}

	public static GankAlert Create(Dictionary<string, string> values)
	{
		string valueOrDefault = values.GetValueOrDefault("message", "");
		if (string.IsNullOrWhiteSpace(valueOrDefault) || valueOrDefault.Length > 2000)
		{
			throw new ArgumentException("Message must contain 1 to 2000 characters.");
		}
		string valueOrDefault2 = values.GetValueOrDefault("delivery_mode", "0");
		string valueOrDefault3 = values.GetValueOrDefault("capture_window", "");
		if (valueOrDefault2 == "0")
		{
			return new GankAlert(Validate(values.GetValueOrDefault("webhook_url", ""), valueOrDefault), valueOrDefault, "", valueOrDefault3);
		}
		if (valueOrDefault2 != "1")
		{
			throw new ArgumentException("Choose a delivery mode.");
		}
		string text = values.GetValueOrDefault("channel_id", "").Trim();
		if (!Regex.IsMatch(text, "^[0-9]{17,20}$"))
		{
			throw new ArgumentException("Enter a Discord channel ID.");
		}
		string text2 = GankSecrets.Read(values.GetValueOrDefault("discord_token", "")).Trim();
		int length = text2.Length;
		bool flag = ((length < 20 || length > 4096) ? true : false);
		if (flag || text2.Any(char.IsWhiteSpace) || text2.Any(char.IsControl))
		{
			throw new ArgumentException("Enter a valid Discord token.");
		}
		return new GankAlert(new Uri("https://discord.com/api/v10/channels/" + text + "/messages"), valueOrDefault, text2, valueOrDefault3);
	}

	public static Task SendAsync(Uri uri, string message, CancellationToken token)
	{
		return SendAsync(Client, uri, message, token);
	}

	internal static Task SendAsync(HttpClient client, Uri uri, string message, CancellationToken token)
	{
		return SendAlertAsync(client, new GankAlert(uri, message), token);
	}

	public static Task SendAlertAsync(GankAlert alert, CancellationToken token)
	{
		return SendAlertAsync(Client, alert, token);
	}

	internal static async Task SendAlertAsync(HttpClient client, GankAlert alert, CancellationToken token)
	{
		using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, alert.Endpoint);
		if (alert.Authorization.Length > 0)
		{
			request.Headers.TryAddWithoutValidation("Authorization", alert.Authorization);
		}
		byte[] screenshot = alert.Screenshot;
		if (screenshot != null && screenshot.Length > 0)
		{
			if (screenshot.Length > 8388608)
			{
				throw new InvalidOperationException("Screenshot is too large to attach.");
			}
			MultipartFormDataContent multipartFormDataContent = new MultipartFormDataContent();
			multipartFormDataContent.Add(new StringContent(JsonSerializer.Serialize(new
			{
				content = alert.Message,
				attachments = new[]
				{
					new
					{
						id = 0,
						filename = "alert.png"
					}
				}
			}), Encoding.UTF8, "application/json"), "payload_json");
			ByteArrayContent byteArrayContent = new ByteArrayContent(screenshot);
			byteArrayContent.Headers.ContentType = new MediaTypeHeaderValue("image/png");
			multipartFormDataContent.Add(byteArrayContent, "files[0]", "alert.png");
			request.Content = multipartFormDataContent;
		}
		else
		{
			request.Content = JsonContent.Create(new
			{
				content = alert.Message
			});
		}
		try
		{
			using HttpResponseMessage httpResponseMessage = await client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, token).ConfigureAwait(continueOnCapturedContext: false);
			if (httpResponseMessage.StatusCode == HttpStatusCode.TooManyRequests)
			{
				throw new InvalidOperationException("Discord rate limited the alert. Try again later.");
			}
			if (httpResponseMessage.StatusCode == HttpStatusCode.Unauthorized)
			{
				throw new InvalidOperationException("Discord rejected the token or webhook credentials.");
			}
			if (httpResponseMessage.StatusCode == HttpStatusCode.Forbidden)
			{
				throw new InvalidOperationException("Discord denied access to this channel.");
			}
			if (!httpResponseMessage.IsSuccessStatusCode)
			{
				throw new InvalidOperationException($"Discord rejected the alert (HTTP {(int)httpResponseMessage.StatusCode}).");
			}
		}
		catch (HttpRequestException)
		{
			throw new InvalidOperationException("Could not reach Discord. Check your connection.");
		}
		catch (OperationCanceledException) when (!token.IsCancellationRequested)
		{
			throw new InvalidOperationException("Discord alert request timed out.");
		}
	}
}
