namespace Merostrap.Macros;

public readonly record struct MacroSupport(bool Supported, string Reason);
