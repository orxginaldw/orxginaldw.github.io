namespace Merostrap.Macros;

public sealed class FlowStateOverlaySettings
{
	public bool Enabled { get; set; }

	public bool Vertical { get; set; }

	public string Color { get; set; } = "#39BA68";

	public int? X { get; set; }

	public int? Y { get; set; }
}
