using System;
using System.Collections.Generic;
using Merostrap.Macros.Health;

namespace Merostrap.Macros;

public static class HudBarDetector
{
	public static DetectedHudBars? Detect(HealthPixels p)
	{
		if (p.Width < 160 || p.Width > 4096 || p.Height < 40 || p.Height > 1200 || p.Bgra.Length != (long)p.Width * (long)p.Height * 4)
		{
			return null;
		}
		List<DetectedHudBars> list = new List<DetectedHudBars>();
		for (int i = 0; i < p.Height - 12; i++)
		{
			int num = -1;
			int num2 = -1;
			int num3 = 0;
			for (int j = 0; j <= p.Width; j++)
			{
				if (j < p.Width && GradientColour(p, j, i))
				{
					if (num < 0)
					{
						num = j;
					}
					num2 = j;
					num3 = 0;
				}
				else
				{
					if (num < 0 || (++num3 <= 3 && j != p.Width) || (j != p.Width && ParryBarAnalyzer.InsideSpectralLabel(j, (double)p.Width / 2.0, (double)p.Width - 2.0 * (double)num)))
					{
						continue;
					}
					int num4 = num2 - num + 1;
					if (num4 >= 120 && (double)num4 < (double)p.Width * 0.8 && Math.Abs((double)(num + num2) / 2.0 - (double)p.Width / 2.0) < Math.Max(8.0, (double)num4 * 0.025))
					{
						HealthRegion parry = new HealthRegion(num, Math.Max(0, i - 1), num4, 4);
						ParryTrack parryTrack = ParryBarAnalyzer.Calibrate(Crop(p, parry));
						if ((object)parryTrack != null)
						{
							HealthRegion healthRegion = FindHealth(p, parry);
							if ((object)healthRegion != null)
							{
								int num5 = list.FindIndex((DetectedHudBars c) => Math.Abs(c.Parry.Y - parry.Y) < 5);
								DetectedHudBars detectedHudBars = new DetectedHudBars(healthRegion, parry, parryTrack);
								if (num5 < 0)
								{
									list.Add(detectedHudBars);
								}
								else if (parry.Width > list[num5].Parry.Width)
								{
									list[num5] = detectedHudBars;
								}
							}
						}
					}
					num = -1;
					num2 = -1;
					num3 = 0;
				}
			}
		}
		if (list.Count != 1)
		{
			return null;
		}
		return list[0];
	}

	private static HealthRegion? FindHealth(HealthPixels p, HealthRegion parry)
	{
		int num = -1;
		int num2 = -1;
		int num3 = p.Width;
		int num4 = parry.X + parry.Width / 2;
		int num5 = Math.Max(0, parry.X - parry.Width / 15);
		int num6 = Math.Min(p.Width - 1, parry.X + parry.Width + parry.Width / 15);
		int num7 = Math.Min(p.Height - 1, parry.Y + Math.Max(35, parry.Width / 8));
		for (int i = parry.Y + 5; i <= num7; i++)
		{
			int num8 = 0;
			int num9 = -1;
			for (int j = num5; j <= num6; j++)
			{
				int num10 = (i * p.Width + j) * 4;
				int num11 = p.Bgra[num10];
				int num12 = p.Bgra[num10 + 1];
				int num13 = p.Bgra[num10 + 2];
				if (num13 < 85 || num13 <= num12 || num12 <= num11 || !((double)(num13 - num11) > (double)num13 * 0.35))
				{
					continue;
				}
				double num14 = (double)(num12 - num11) * 60.0 / (double)(num13 - num11);
				if (num14 >= 10.0 && num14 <= 50.0)
				{
					num8++;
					if (num9 < 0)
					{
						num9 = j;
					}
				}
			}
			if (num8 >= Math.Max(12, parry.Width / 20) && num9 >= num5 && Math.Abs(num9 - parry.X) < parry.Width / 15)
			{
				if (num < 0)
				{
					num = i;
				}
				num2 = i;
				num3 = Math.Min(num3, num9);
			}
			else if (num >= 0 && i - num2 > 3)
			{
				break;
			}
		}
		if (num < 0 || num2 - num < 3 || num2 - num > parry.Width / 8)
		{
			return null;
		}
		int num15 = 2 * (num4 - num3);
		if ((double)num15 < (double)parry.Width * 0.9 || (double)num15 > (double)parry.Width * 1.15 || num3 < 2 || num3 + num15 + 2 > p.Width)
		{
			return null;
		}
		HealthRegion healthRegion = new HealthRegion(num3 - 2, Math.Max(0, num - 2), num15 + 4, num2 - num + 5);
		if (healthRegion.Y + healthRegion.Height > p.Height || !HealthBarAnalyzer.AnalyzeSelection(Crop(p, healthRegion)).Percent.HasValue)
		{
			return null;
		}
		return healthRegion;
	}

	private static bool GradientColour(HealthPixels p, int x, int y)
	{
		int num = (y * p.Width + x) * 4;
		int num2 = p.Bgra[num];
		int num3 = p.Bgra[num + 1];
		int num4 = p.Bgra[num + 2];
		if ((num4 <= num3 + 12 || num2 <= num3 + 12) && (num3 <= num4 + 12 || num3 <= num2 + 8))
		{
			if (num2 > num4 + 12)
			{
				return num2 >= num3 - 12;
			}
			return false;
		}
		return true;
	}

	public static HealthPixels Crop(HealthPixels source, HealthRegion region)
	{
		if (region.X < 0 || region.Y < 0 || region.Width < 1 || region.Height < 1 || (long)region.X + (long)region.Width > source.Width || (long)region.Y + (long)region.Height > source.Height)
		{
			throw new ArgumentOutOfRangeException("region");
		}
		byte[] array = new byte[checked(region.Width * region.Height * 4)];
		for (int i = 0; i < region.Height; i++)
		{
			Array.Copy(source.Bgra, ((region.Y + i) * source.Width + region.X) * 4, array, i * region.Width * 4, region.Width * 4);
		}
		return new HealthPixels(region.Width, region.Height, array);
	}
}
