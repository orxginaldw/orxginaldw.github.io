using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Avalonia.Controls;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Platform;
using Avalonia.Threading;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Merostrap.Macros.Health;
using Merostrap.UI.Elements.Macros;

namespace Merostrap.Macros;

public sealed class ParryBarController : ObservableObject, IDisposable
{
	private readonly ParryBarSettings _settings;

	private readonly Action _save;

	private readonly Action _changed;

	private readonly HealthMonitor _monitor;

	private readonly Func<DetectedHudBars?> _recover;

	private long _lastGoodSample;

	private long _lastRecovery;

	private bool _recovering;

	private DetectedHudBars? _recoveryCandidate;

	private readonly DispatcherTimer _stale = new DispatcherTimer
	{
		Interval = TimeSpan.FromMilliseconds(16L)
	};

	private readonly ParryFillMotion _motion = new ParryFillMotion();

	private bool _spectralCovered;

	private ParryBarOverlay? _overlay;

	private long _generation;

	private long _lastSample;

	private bool _running;

	private bool _disposed;

	private bool _foreground;

	private double? _percent;

	private string _status = "Select bar";

	private Bitmap? _barImage;

	private bool _imageLoaded;

	public Bitmap? BarImage
	{
		get
		{
			LoadImage();
			return _barImage;
		}
	}

	public bool HasImage => BarImage != null;

	public string? AnimatedImagePath
	{
		get
		{
			if (!HasImage || !string.Equals(Path.GetExtension(_settings.ImagePath), ".gif", StringComparison.OrdinalIgnoreCase))
			{
				return null;
			}
			return _settings.ImagePath;
		}
	}

	public double ScalePercent
	{
		get
		{
			if (double.IsFinite(_settings.ScalePercent))
			{
				double scalePercent = _settings.ScalePercent;
				if (scalePercent >= 50.0 && scalePercent <= 300.0)
				{
					return _settings.ScalePercent;
				}
			}
			return 100.0;
		}
		set
		{
			if (double.IsFinite(value))
			{
				double num = Math.Clamp(Math.Round(value), 50.0, 300.0);
				if (ScalePercent != num)
				{
					_settings.ScalePercent = num;
					_save();
					OnPropertyChanged("ScalePercent");
					OnPropertyChanged("ScaleLabel");
					OnPropertyChanged("BarWidth");
					OnPropertyChanged("BarHeight");
					OnPropertyChanged("ImageWidth");
					OnPropertyChanged("ImageHeight");
					OnPropertyChanged("ImageFillWidth");
					OnPropertyChanged("DisplayImageFillWidth");
				}
			}
		}
	}

	public string ScaleLabel => $"{ScalePercent:0}%";

	public double BarWidth => 260.0 * ScalePercent / 100.0;

	public double BarHeight => 18.0 * ScalePercent / 100.0;

	public double ImageWidth => BarWidth - 2.0;

	public double ImageHeight => BarHeight - 2.0;

	public double ImageFillWidth => ImageWidth * FillRatio;

	public string ImageLabel
	{
		get
		{
			if (!HasImage)
			{
				return "Choose image";
			}
			return "Change image";
		}
	}

	public IRelayCommand ShowOverlayCommand { get; }

	public string BarColor
	{
		get
		{
			if (!Color.TryParse(_settings.Color, out var _))
			{
				return "#39BA68";
			}
			return _settings.Color;
		}
		set
		{
			if (Color.TryParse(value, out var color))
			{
				string text = $"#{color.R:X2}{color.G:X2}{color.B:X2}";
				if (!(text == BarColor))
				{
					_settings.Color = text;
					_save();
					OnPropertyChanged("BarColor");
					OnPropertyChanged("FillBrush");
				}
			}
		}
	}

	public IBrush FillBrush => Brush.Parse(BarColor);

	public bool Enabled
	{
		get
		{
			return _settings.Enabled;
		}
		set
		{
			if (value != Enabled)
			{
				_settings.Enabled = value;
				if (value)
				{
					_settings.Visible = true;
				}
				else
				{
					SetArmed(active: false);
					_overlay?.Hide();
				}
				_save();
				OnPropertyChanged("Enabled");
				OnPropertyChanged("IsReady");
				_changed();
				RestoreOverlay();
			}
		}
	}

	public bool IsReady
	{
		get
		{
			if (Enabled && (object)_settings.Region != null)
			{
				return (object)_settings.Track != null;
			}
			return false;
		}
	}

	public bool IsRunning => _running;

	public double Fill
	{
		get
		{
			double? percent = _percent;
			if (!percent.HasValue)
			{
				if (!_spectralCovered)
				{
					return 0.0;
				}
				return _motion.Value;
			}
			return percent.GetValueOrDefault();
		}
	}

	public double FillRatio => Fill / 100.0;

	public double DisplayFillRatio => _motion.DisplayValue / 100.0;

	public double DisplayImageFillWidth => ImageWidth * DisplayFillRatio;

	public string Status => _status;

	public string SelectionLabel
	{
		get
		{
			if ((object)_settings.Region != null)
			{
				return "Reselect bar";
			}
			return "Select bar";
		}
	}

	public int? X => _settings.X;

	public int? Y => _settings.Y;

	public event Action<DetectedHudBars>? Recovered;

	private void LoadImage()
	{
		if (_imageLoaded || _disposed)
		{
			return;
		}
		_imageLoaded = true;
		try
		{
			if (File.Exists(_settings.ImagePath))
			{
				_barImage = new Bitmap(_settings.ImagePath);
			}
		}
		catch (Exception)
		{
			_barImage = null;
		}
	}

	public void SetImage(string path)
	{
		using FileStream stream = File.OpenRead(path);
		using Bitmap bitmap = Bitmap.DecodeToWidth(stream, 1024);
		string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Merostrap", "ParryImages");
		Directory.CreateDirectory(text);
		bool flag = string.Equals(Path.GetExtension(path), ".gif", StringComparison.OrdinalIgnoreCase);
		string text2 = Path.Combine(text, Guid.NewGuid().ToString("N") + (flag ? ".gif" : ".png"));
		if (flag)
		{
			File.Copy(path, text2);
		}
		else
		{
			bitmap.Save(text2);
		}
		Bitmap barImage = new Bitmap(text2);
		Bitmap? barImage2 = _barImage;
		_barImage = barImage;
		_imageLoaded = true;
		_settings.ImagePath = text2;
		NotifyImage();
		barImage2?.Dispose();
	}

	public void ClearImage()
	{
		Bitmap? barImage = _barImage;
		_barImage = null;
		_imageLoaded = true;
		_settings.ImagePath = null;
		NotifyImage();
		barImage?.Dispose();
	}

	private void NotifyImage()
	{
		_save();
		OnPropertyChanged("BarImage");
		OnPropertyChanged("HasImage");
		OnPropertyChanged("ImageLabel");
		OnPropertyChanged("AnimatedImagePath");
	}

	public ParryBarController(ParryBarSettings settings, Action save, Action changed, HealthMonitor? monitor = null, Func<DetectedHudBars?>? recover = null)
	{
		_settings = settings;
		_save = save;
		_changed = changed;
		_recover = recover ?? ((monitor == null) ? new Func<DetectedHudBars>(HudBarCapture.Detect) : ((Func<DetectedHudBars>)(() => (DetectedHudBars?)null)));
		_monitor = monitor ?? new HealthMonitor(null, null, TimeSpan.FromMilliseconds(33L), (HealthPixels pixels) =>
		{
			ParryTrack track = _settings.Track;
			if ((object)track == null)
			{
				return new HealthSample(null, "Parry");
			}
			double? percent = ParryBarAnalyzer.Read(pixels, track);
			return new HealthSample(percent, (!percent.HasValue && ParryBarAnalyzer.IsSpectralCovered(pixels, track)) ? "Spectral" : "Parry");
		});
		_monitor.Updated += (HealthSample sample) =>
		{
			long generation = _generation;
			Dispatcher.UIThread.Post(() =>
			{
				if (!_disposed && _running && generation == _generation)
				{
					_spectralCovered = sample.Status == "Spectral";
					Receive(sample.Percent);
				}
			});
		};
		_stale.Tick += (object? _, EventArgs _) =>
		{
			if (_running)
			{
				long tickCount = Environment.TickCount64;
				if (tickCount - _lastSample > 200)
				{
					_spectralCovered = false;
					SetReading(null, "Unknown");
				}
				_motion.Advance(tickCount);
				OnPropertyChanged("DisplayFillRatio");
				OnPropertyChanged("DisplayImageFillWidth");
				if (_spectralCovered)
				{
					OnPropertyChanged("Fill");
					OnPropertyChanged("FillRatio");
					OnPropertyChanged("ImageFillWidth");
				}
			}
		};
		ShowOverlayCommand = new RelayCommand(() =>
		{
			_settings.Visible = true;
			_save();
			RestoreOverlay();
		});
		_status = (IsReady ? "Paused" : "Select bar");
	}

	public void SavePosition(int x, int y)
	{
		_settings.X = x;
		_settings.Y = y;
		_save();
	}

	public void StopCapture()
	{
		_running = false;
		Interlocked.Increment(ref _generation);
		_recoveryCandidate = null;
		_monitor.Stop();
	}

	public void SetArmed(bool active)
	{
		StopCapture();
		_stale.Stop();
		_spectralCovered = false;
		_motion.Reset();
		SetReading(null, ((object)_settings.Region == null) ? "Select bar" : "Paused");
		if (!active || !IsReady || _disposed)
		{
			return;
		}
		try
		{
			_running = true;
			_lastGoodSample = (_lastSample = Environment.TickCount64);
			_monitor.Start(_settings.Region);
			_stale.Start();
			SetReading(null, "Unknown");
		}
		catch (Exception)
		{
			_running = false;
			SetReading(null, "Reselect bar");
		}
	}

	private void Receive(double? percent)
	{
		_lastSample = Environment.TickCount64;
		if (percent.HasValue)
		{
			_lastGoodSample = _lastSample;
			_recoveryCandidate = null;
		}
		else if (!_spectralCovered && _foreground && !_recovering && _lastSample - _lastGoodSample >= 1000 && _lastSample - _lastRecovery >= 2000)
		{
			RecoverAsync();
		}
		ParryBarController parryBarController = this;
		double? percent2 = percent;
		string status;
		if (percent.HasValue)
		{
			status = ((percent >= 99.5) ? "Ready" : "Cooldown");
		}
		else
		{
			status = "Unknown";
		}
		parryBarController.SetReading(percent2, status);
	}

	private async Task RecoverAsync()
	{
		_recovering = true;
		_lastRecovery = Environment.TickCount64;
		long generation = _generation;
		try
		{
			DetectedHudBars detectedHudBars = await Task.Run(_recover);
			if (_disposed || !_running || !_foreground || generation != _generation)
			{
				return;
			}
			double? percent = _percent;
			if (!percent.HasValue)
			{
				if ((object)detectedHudBars == null || !HudBarCapture.SameLocation(detectedHudBars, _recoveryCandidate))
				{
					_recoveryCandidate = detectedHudBars;
					return;
				}
				ApplyDetectedBars(detectedHudBars);
				Recovered?.Invoke(detectedHudBars);
				SetArmed(active: true);
			}
		}
		catch (Exception)
		{
			_recoveryCandidate = null;
		}
		finally
		{
			_recovering = false;
		}
	}

	private void SetReading(double? percent, string status)
	{
		_motion.Observe(percent, _spectralCovered && status == "Unknown", Environment.TickCount64);
		_motion.Advance(Environment.TickCount64);
		if (_spectralCovered && !percent.HasValue && _motion.Value > 0.0)
		{
			status = "Estimated";
		}
		_percent = percent;
		_status = status;
		OnPropertyChanged("Fill");
		OnPropertyChanged("FillRatio");
		OnPropertyChanged("ImageFillWidth");
		OnPropertyChanged("Status");
		OnPropertyChanged("DisplayFillRatio");
		OnPropertyChanged("DisplayImageFillWidth");
	}

	public void RestoreOverlay()
	{
		if (!Enabled || !_settings.Visible || _disposed)
		{
			return;
		}
		if (!_foreground)
		{
			_overlay?.Hide();
			return;
		}
		if (_overlay == null)
		{
			_overlay = new ParryBarOverlay(this);
			_overlay.Closed += (object? _, EventArgs _) =>
			{
				_overlay = null;
			};
		}
		if (!_overlay.IsVisible)
		{
			_overlay.TryShow();
		}
	}

	public void SetForeground(bool foreground)
	{
		_foreground = foreground;
		if (!foreground)
		{
			_recoveryCandidate = null;
		}
		if (!foreground)
		{
			_overlay?.Hide();
		}
		else
		{
			RestoreOverlay();
		}
	}

	public bool IsOverlayForeground(nint handle)
	{
		ParryBarOverlay? overlay = _overlay;
		if (overlay != null && overlay.IsVisible)
		{
			IPlatformHandle? platformHandle = _overlay.TryGetPlatformHandle();
			if (platformHandle == null)
			{
				return false;
			}
			return platformHandle.Handle == handle;
		}
		return false;
	}

	public void HideOverlay()
	{
		_settings.Visible = false;
		_save();
		_overlay?.Hide();
	}

	public void ApplyDetectedBars(DetectedHudBars bars)
	{
		bars.Parry.Validate();
		_settings.Region = bars.Parry;
		_settings.Track = bars.Track;
		_save();
		OnPropertyChanged("SelectionLabel");
		OnPropertyChanged("IsReady");
	}

	public async Task SelectRegionAsync(Window owner, bool automatic = false)
	{
		MacroWorkspace workspace = owner.DataContext as MacroWorkspace;
		bool wasRunning = workspace?.Enabled ?? false;
		if (workspace != null)
		{
			workspace.Health.PreserveDeafenLatch(() =>
			{
				workspace.Enabled = false;
			});
		}
		SetArmed(active: false);
		_overlay?.Hide();
		owner.Hide();
		try
		{
			DetectedHudBars detectedHudBars = ((!automatic) ? null : (await HudAutoDetection.PickAsync(owner)));
			DetectedHudBars detected = detectedHudBars;
			HealthRegion healthRegion = ((!automatic) ? (await HealthRegionPicker.PickAsync(owner, "Select the full parry cooldown bar while it is ready. Esc cancels.")) : detected?.Parry);
			HealthRegion region = healthRegion;
			if ((object)region != null)
			{
				await Task.Delay(150);
				ParryTrack parryTrack = detected?.Track ?? ParryBarAnalyzer.Calibrate(new WindowsHealthCapture().Capture(region));
				if ((object)parryTrack == null)
				{
					SetReading(null, "Select the full coloured bar while ready");
					return;
				}
				_settings.Region = region;
				_settings.Track = parryTrack;
				_save();
				if ((object)detected != null && workspace != null)
				{
					workspace.Health.ApplyDetectedRegion(detected.Health);
				}
				OnPropertyChanged("SelectionLabel");
				OnPropertyChanged("IsReady");
			}
			_changed();
		}
		catch (Exception)
		{
			SetReading(null, "Could not select bar");
		}
		finally
		{
			if (!_disposed)
			{
				if (wasRunning && workspace != null && !workspace.Enabled)
				{
					workspace.Health.PreserveDeafenLatch(() =>
					{
						workspace.Enabled = true;
					});
				}
				owner.Show();
				owner.Activate();
				RestoreOverlay();
			}
		}
	}

	public void Dispose()
	{
		if (!_disposed)
		{
			_disposed = true;
			SetArmed(active: false);
			_monitor.Dispose();
			_overlay?.Close();
			_barImage?.Dispose();
		}
	}
}
