using System;

namespace Merostrap.Macros.Health;

public sealed class HealthThresholdLatch
{
	private readonly object _gate = new object();

	private bool _armed = true;

	private bool _low;

	private int _lowStreak;

	public bool IsLow
	{
		get
		{
			lock (_gate)
			{
				return _low;
			}
		}
	}

	public HealthThresholdTransition Observe(HealthSample sample, int threshold = 50)
	{
		ArgumentNullException.ThrowIfNull(sample, "sample");
		if ((threshold < 1 || threshold > 100) ? true : false)
		{
			throw new ArgumentOutOfRangeException("threshold");
		}
		lock (_gate)
		{
			double? percent = sample.Percent;
			double valueOrDefault = default;
			int num;
			if (percent.HasValue)
			{
				valueOrDefault = percent.GetValueOrDefault();
				num = ((!double.IsFinite(valueOrDefault)) ? 1 : 0);
			}
			else
			{
				num = 1;
			}
			bool flag = (byte)num != 0;
			if (!flag)
			{
				bool flag2 = ((valueOrDefault < 0.0 || valueOrDefault > 100.0) ? true : false);
				flag = flag2;
			}
			if (flag)
			{
				_lowStreak = 0;
				return HealthThresholdTransition.None;
			}
			if (valueOrDefault > (double)Math.Min(100, threshold + 5))
			{
				bool low = _low;
				_armed = true;
				_low = false;
				_lowStreak = 0;
				return low ? HealthThresholdTransition.Recovered : HealthThresholdTransition.None;
			}
			if (_low || !_armed || valueOrDefault > (double)threshold)
			{
				_lowStreak = 0;
				return HealthThresholdTransition.None;
			}
			if (++_lowStreak < 2)
			{
				return HealthThresholdTransition.None;
			}
			_low = true;
			_lowStreak = 0;
			return HealthThresholdTransition.Low;
		}
	}

	public void Reset()
	{
		lock (_gate)
		{
			_armed = true;
			_low = false;
			_lowStreak = 0;
		}
	}
}
