using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

namespace Merostrap.Macros.Health;

public sealed class HealthMonitor : IDisposable
{
	private readonly object _gate = new object();

	private readonly SemaphoreSlim _captureGate = new SemaphoreSlim(1, 1);

	private readonly Func<bool> _foreground;

	private readonly Func<HealthRegion, HealthPixels> _capture;

	private readonly TimeSpan _interval;

	private readonly Func<HealthPixels, HealthSample> _analyze;

	private CancellationTokenSource? _session;

	private bool _disposed;

	public bool IsRunning
	{
		get
		{
			lock (_gate)
			{
				return _session != null;
			}
		}
	}

	public event Action<HealthSample>? Updated;

	public HealthMonitor(Func<bool>? isForegroundRoblox = null, Func<HealthRegion, HealthPixels>? capture = null, TimeSpan? interval = null, Func<HealthPixels, HealthSample>? analyze = null)
	{
		_analyze = analyze ?? new Func<HealthPixels, HealthSample>(HealthBarAnalyzer.Analyze);
		_foreground = isForegroundRoblox ?? new Func<bool>(WindowsHealthCapture.IsForegroundRoblox);
		_capture = capture ?? new Func<HealthRegion, HealthPixels>(new WindowsHealthCapture().Capture);
		_interval = interval ?? TimeSpan.FromMilliseconds(100L);
		if (_interval < TimeSpan.FromMilliseconds(20L) || _interval > TimeSpan.FromSeconds(30L))
		{
			throw new ArgumentOutOfRangeException("interval", "Health polling interval must be between 20 ms and 30 seconds.");
		}
	}

	public void Start(HealthRegion region)
	{
		ArgumentNullException.ThrowIfNull(region, "region");
		region.Validate();
		lock (_gate)
		{
			ObjectDisposedException.ThrowIf(_disposed, this);
			_session?.Cancel();
			CancellationTokenSource session = new CancellationTokenSource();
			_session = session;
			PublishLocked(new HealthSample(null, "Waiting for health reading."));
			Task.Run(() => Poll(region, session));
		}
	}

	public void Stop()
	{
		lock (_gate)
		{
			_session?.Cancel();
			_session = null;
			PublishLocked(new HealthSample(null, "Health monitor off."));
		}
	}

	private async Task Poll(HealthRegion region, CancellationTokenSource session)
	{
		_ = 1;
		try
		{
			while (true)
			{
				session.Token.ThrowIfCancellationRequested();
				long started = Stopwatch.GetTimestamp();
				HealthSample sample;
				try
				{
					if (!_foreground())
					{
						sample = Waiting();
					}
					else
					{
						await _captureGate.WaitAsync(session.Token);
						try
						{
							session.Token.ThrowIfCancellationRequested();
							if (!_foreground())
							{
								sample = Waiting();
							}
							else
							{
								HealthPixels healthPixels = _capture(region);
								session.Token.ThrowIfCancellationRequested();
								if (_foreground())
								{
									sample = ((healthPixels.Width != region.Width || healthPixels.Height != region.Height) ? new HealthSample(null, "Health capture dimensions changed. Select the bar again.") : _analyze(healthPixels));
								}
								else
								{
									sample = Waiting();
								}
								if (!_foreground())
								{
									sample = Waiting();
								}
							}
						}
						finally
						{
							_captureGate.Release();
						}
					}
				}
				catch (OperationCanceledException) when (session.IsCancellationRequested)
				{
					throw;
				}
				catch (Exception ex2)
				{
					sample = new HealthSample(null, "Health capture error: " + ex2.GetBaseException().Message);
				}
				lock (_gate)
				{
					if (_session != session || session.IsCancellationRequested)
					{
						break;
					}
					PublishLocked(sample);
				}
				TimeSpan timeSpan = _interval - Stopwatch.GetElapsedTime(started);
				await Task.Delay((timeSpan > TimeSpan.Zero) ? timeSpan : TimeSpan.FromMilliseconds(1L), session.Token);
			}
		}
		catch (OperationCanceledException) when (session.IsCancellationRequested)
		{
		}
		finally
		{
			session.Dispose();
		}
	}

	private static HealthSample Waiting()
	{
		return new HealthSample(null, "Waiting for foreground Roblox.");
	}

	private void PublishLocked(HealthSample sample)
	{
		if (Updated == null)
		{
			return;
		}
		Delegate[] invocationList = Updated.GetInvocationList();
		for (int i = 0; i < invocationList.Length; i++)
		{
			Action<HealthSample> action = (Action<HealthSample>)invocationList[i];
			try
			{
				action(sample);
			}
			catch
			{
			}
		}
	}

	public void Dispose()
	{
		lock (_gate)
		{
			if (!_disposed)
			{
				Stop();
				_disposed = true;
			}
		}
	}
}
