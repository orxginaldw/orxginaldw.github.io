using System;

namespace Merostrap.Macros.Health;

public sealed record HealthRegion(int X, int Y, int Width, int Height)
{
	public void Validate()
	{
		int width = Width;
		bool flag = ((width < 30 || width > 4096) ? true : false);
		bool flag2 = flag;
		if (!flag2)
		{
			int height = Height;
			bool flag3 = ((height < 4 || height > 300) ? true : false);
			flag2 = flag3;
		}
		if (flag2)
		{
			throw new ArgumentException("Select a health bar interior between 30 and 4096 pixels wide and 4 and 300 pixels high.");
		}
		if ((long)X + (long)Width > int.MaxValue || (long)Y + (long)Height > int.MaxValue)
		{
			throw new ArgumentException("The health region exceeds screen coordinate limits.");
		}
	}
}
