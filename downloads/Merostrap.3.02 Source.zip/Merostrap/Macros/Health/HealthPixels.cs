namespace Merostrap.Macros.Health;

public sealed record HealthPixels(int Width, int Height, byte[] Bgra);
