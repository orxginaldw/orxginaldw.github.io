using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;

namespace Merostrap.Macros.Health;

public sealed class WindowsHealthCapture
{
	private struct NativeRect
	{
		public int Left;

		public int Top;

		public int Right;

		public int Bottom;
	}

	private struct NativePoint
	{
		public int X;

		public int Y;
	}

	private struct BitmapInfoHeader
	{
		public uint Size;

		public int Width;

		public int Height;

		public ushort Planes;

		public ushort BitCount;

		public uint Compression;

		public uint ImageSize;

		public int XPixelsPerMeter;

		public int YPixelsPerMeter;

		public uint ColorsUsed;

		public uint ImportantColors;
	}

	private struct BitmapInfo
	{
		public BitmapInfoHeader Header;

		public uint Color;
	}

	public static void FocusRobloxForDetection()
	{
		if (!OperatingSystem.IsWindows() || IsForegroundRoblox())
		{
			return;
		}
		Process[] array = Process.GetProcessesByName("RobloxPlayerBeta").Concat(Process.GetProcessesByName("RobloxPlayer")).ToArray();
		try
		{
			nint[] array2 = (from p in array
				select p.MainWindowHandle into h
				where h != IntPtr.Zero
				select h).ToArray();
			if (array2.Length == 1)
			{
				if (IsIconic(array2[0]))
				{
					ShowWindow(array2[0], 9);
				}
				SetForegroundWindow(array2[0]);
			}
		}
		finally
		{
			Process[] array3 = array;
			for (int num = 0; num < array3.Length; num++)
			{
				array3[num].Dispose();
			}
		}
	}

	[DllImport("user32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool SetForegroundWindow(nint window);

	[DllImport("user32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool IsIconic(nint window);

	[DllImport("user32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool ShowWindow(nint window, int command);

	public static HealthRegion? ForegroundRobloxArea(bool top = false)
	{
		if (!IsForegroundRoblox())
		{
			return null;
		}
		nint foregroundWindow = GetForegroundWindow();
		if (!GetClientRect(foregroundWindow, out var rect))
		{
			return null;
		}
		NativePoint point = default;
		if (!ClientToScreen(foregroundWindow, ref point))
		{
			return null;
		}
		int num = Math.Min(4096, rect.Right);
		int num2 = Math.Min(600, rect.Bottom / 2);
		if (num < 160 || num2 < 40)
		{
			return null;
		}
		return new HealthRegion(point.X + (rect.Right - num) / 2, top ? point.Y : (point.Y + rect.Bottom - num2), num, num2);
	}

	public static HealthRegion? ForegroundRobloxClientArea()
	{
		if (!IsForegroundRoblox() || !GetClientRect(GetForegroundWindow(), out var rect))
		{
			return null;
		}
		NativePoint point = default;
		if (!ClientToScreen(GetForegroundWindow(), ref point))
		{
			return null;
		}
		int right = rect.Right;
		if (right >= 300 && right <= 4096)
		{
			right = rect.Bottom;
			if (right >= 200 && right <= 2160)
			{
				return new HealthRegion(point.X, point.Y, rect.Right, rect.Bottom);
			}
		}
		return null;
	}

	public static nint ForegroundRobloxWindow()
	{
		if (!IsForegroundRoblox())
		{
			return IntPtr.Zero;
		}
		return GetForegroundWindow();
	}

	[DllImport("user32.dll")]
	private static extern nint GetForegroundWindow();

	[DllImport("user32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool GetClientRect(nint window, out NativeRect rect);

	[DllImport("user32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool ClientToScreen(nint window, ref NativePoint point);

	public HealthPixels Capture(HealthRegion region)
	{
		ArgumentNullException.ThrowIfNull(region, "region");
		region.Validate();
		if (!OperatingSystem.IsWindows())
		{
			throw new PlatformNotSupportedException("Health capture requires Windows.");
		}
		int systemMetrics = GetSystemMetrics(76);
		int systemMetrics2 = GetSystemMetrics(77);
		int systemMetrics3 = GetSystemMetrics(78);
		int systemMetrics4 = GetSystemMetrics(79);
		if (region.X < systemMetrics || region.Y < systemMetrics2 || (long)region.X + (long)region.Width > (long)systemMetrics + (long)systemMetrics3 || (long)region.Y + (long)region.Height > (long)systemMetrics2 + (long)systemMetrics4)
		{
			throw new ArgumentException("The selected health region is outside the current desktop.", "region");
		}
		nint dC = GetDC(IntPtr.Zero);
		if (dC == IntPtr.Zero)
		{
			throw new Win32Exception(Marshal.GetLastWin32Error(), "Cannot access the screen for health capture.");
		}
		nint num = IntPtr.Zero;
		nint num2 = IntPtr.Zero;
		nint num3 = IntPtr.Zero;
		try
		{
			num = CreateCompatibleDC(dC);
			if (num == IntPtr.Zero)
			{
				throw new Win32Exception(Marshal.GetLastWin32Error(), "Cannot create the health capture buffer.");
			}
			BitmapInfo info = new BitmapInfo
			{
				Header = new BitmapInfoHeader
				{
					Size = (uint)Marshal.SizeOf<BitmapInfoHeader>(),
					Width = region.Width,
					Height = -region.Height,
					Planes = 1,
					BitCount = 32,
					Compression = 0u
				}
			};
			num2 = CreateDIBSection(dC, ref info, 0u, out var bits, IntPtr.Zero, 0u);
			if (num2 == IntPtr.Zero || bits == IntPtr.Zero)
			{
				throw new Win32Exception(Marshal.GetLastWin32Error(), "Cannot allocate the health capture pixels.");
			}
			num3 = SelectObject(num, num2);
			if (num3 == IntPtr.Zero || num3 == new IntPtr(-1))
			{
				throw new Win32Exception(Marshal.GetLastWin32Error(), "Cannot select the health capture buffer.");
			}
			if (!BitBlt(num, 0, 0, region.Width, region.Height, dC, region.X, region.Y, 1087111200u))
			{
				throw new Win32Exception(Marshal.GetLastWin32Error(), "Screen health capture failed.");
			}
			byte[] array = new byte[checked(region.Width * region.Height * 4)];
			Marshal.Copy(bits, array, 0, array.Length);
			return new HealthPixels(region.Width, region.Height, array);
		}
		finally
		{
			if (num3 != IntPtr.Zero && num3 != new IntPtr(-1))
			{
				SelectObject(num, num3);
			}
			if (num2 != IntPtr.Zero)
			{
				DeleteObject(num2);
			}
			if (num != IntPtr.Zero)
			{
				DeleteDC(num);
			}
			ReleaseDC(IntPtr.Zero, dC);
		}
	}

	internal static bool IsForegroundRoblox()
	{
		return WindowsMacroInput.CheckForegroundRoblox();
	}

	[DllImport("user32.dll", SetLastError = true)]
	private static extern nint GetDC(nint window);

	[DllImport("user32.dll")]
	private static extern int ReleaseDC(nint window, nint dc);

	[DllImport("user32.dll")]
	private static extern int GetSystemMetrics(int index);

	[DllImport("gdi32.dll", SetLastError = true)]
	private static extern nint CreateCompatibleDC(nint dc);

	[DllImport("gdi32.dll", SetLastError = true)]
	private static extern nint CreateDIBSection(nint dc, ref BitmapInfo info, uint usage, out nint bits, nint section, uint offset);

	[DllImport("gdi32.dll", SetLastError = true)]
	private static extern nint SelectObject(nint dc, nint item);

	[DllImport("gdi32.dll", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool BitBlt(nint destination, int x, int y, int width, int height, nint source, int sourceX, int sourceY, uint operation);

	[DllImport("gdi32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool DeleteObject(nint item);

	[DllImport("gdi32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool DeleteDC(nint dc);
}
