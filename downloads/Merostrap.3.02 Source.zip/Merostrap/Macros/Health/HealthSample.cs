namespace Merostrap.Macros.Health;

public sealed record HealthSample(double? Percent, string Status);
