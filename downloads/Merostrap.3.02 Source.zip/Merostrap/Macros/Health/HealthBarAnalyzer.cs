using System;
using System.Globalization;
using System.Linq;

namespace Merostrap.Macros.Health;

public static class HealthBarAnalyzer
{
	public static HealthSample AnalyzeSelection(HealthPixels pixels)
	{
		ArgumentNullException.ThrowIfNull(pixels, "pixels");
		int width = pixels.Width;
		bool flag = ((width < 30 || width > 4096) ? true : false);
		bool flag2 = flag;
		if (!flag2)
		{
			int height = pixels.Height;
			bool flag3 = ((height < 4 || height > 300) ? true : false);
			flag2 = flag3;
		}
		if (flag2 || pixels.Bgra == null || pixels.Bgra.LongLength != (long)pixels.Width * (long)pixels.Height * 4)
		{
			return new HealthSample(null, "Invalid health image.");
		}
		int[] counts = new int[pixels.Height];
		for (int i = 0; i < pixels.Height; i++)
		{
			for (int j = 0; j < pixels.Width; j++)
			{
				int num = (i * pixels.Width + j) * 4;
				if (IsOrange(pixels.Bgra[num + 2], pixels.Bgra[num + 1], pixels.Bgra[num]))
				{
					counts[i]++;
				}
			}
		}
		int maximum = counts.Max();
		if (maximum < 3)
		{
			return new HealthSample(null, "Health fill not detected.");
		}
		int[] array = (from y in Enumerable.Range(0, pixels.Height)
			where (double)counts[y] >= (double)maximum * 0.98
			select y).ToArray();
		if (array.Length < 4)
		{
			return new HealthSample(null, "Health fill is unclear.");
		}
		int num2 = -1;
		for (int num3 = 0; num3 < pixels.Width; num3++)
		{
			int num4 = 0;
			int[] array2 = array;
			for (width = 0; width < array2.Length; width++)
			{
				int num5 = (array2[width] * pixels.Width + num3) * 4;
				if (IsOrange(pixels.Bgra[num5 + 2], pixels.Bgra[num5 + 1], pixels.Bgra[num5]))
				{
					num4++;
				}
			}
			if (num4 > array.Length / 2)
			{
				num2 = num3;
				break;
			}
		}
		if (num2 < 0 || (double)num2 > (double)pixels.Width * 0.2)
		{
			return new HealthSample(null, "Select the whole health bar.");
		}
		int num6 = pixels.Width - num2 * 2;
		HealthPixels healthPixels = new HealthPixels(num6, array.Length, new byte[num6 * array.Length * 4]);
		for (int num7 = 0; num7 < array.Length; num7++)
		{
			Array.Copy(pixels.Bgra, (array[num7] * pixels.Width + num2) * 4, healthPixels.Bgra, num7 * num6 * 4, num6 * 4);
		}
		HealthSample healthSample = Analyze(healthPixels);
		double? percent = healthSample.Percent;
		if (percent.HasValue)
		{
			double valueOrDefault = percent.GetValueOrDefault();
			return new HealthSample(valueOrDefault, $"Health {valueOrDefault:0.#}% · orange bar");
		}
		return healthSample;
	}

	public static HealthRegion? FindInterior(HealthPixels pixels)
	{
		int width = pixels.Width;
		bool flag = ((width < 30 || width > 4096) ? true : false);
		bool flag2 = flag;
		if (!flag2)
		{
			int height = pixels.Height;
			bool flag3 = ((height < 4 || height > 300) ? true : false);
			flag2 = flag3;
		}
		if (flag2 || pixels.Bgra == null || pixels.Bgra.LongLength != (long)pixels.Width * (long)pixels.Height * 4)
		{
			return null;
		}
		int[] array = new int[pixels.Height];
		for (int i = 0; i < pixels.Height; i++)
		{
			for (int j = 0; j < pixels.Width; j++)
			{
				int num = (i * pixels.Width + j) * 4;
				if (IsOrange(pixels.Bgra[num + 2], pixels.Bgra[num + 1], pixels.Bgra[num]))
				{
					array[i]++;
				}
			}
		}
		int num2 = 0;
		int[] array2 = array;
		foreach (int val in array2)
		{
			num2 = Math.Max(num2, val);
		}
		if ((double)num2 < (double)pixels.Width * 0.7)
		{
			return null;
		}
		int num3 = -1;
		int num4 = -1;
		for (int k = 0; k < pixels.Height; k++)
		{
			if ((double)array[k] >= (double)num2 * 0.5)
			{
				if (num3 < 0)
				{
					num3 = k;
				}
				num4 = k;
			}
		}
		if (num4 - num3 + 1 < 4)
		{
			return null;
		}
		int num5 = pixels.Width;
		int num6 = -1;
		for (int l = 0; l < pixels.Width; l++)
		{
			int num7 = 0;
			int num8 = 0;
			for (int m = num3; m <= num4; m++)
			{
				if (!((double)array[m] < (double)num2 * 0.98))
				{
					num8++;
					int num9 = (m * pixels.Width + l) * 4;
					if (IsOrange(pixels.Bgra[num9 + 2], pixels.Bgra[num9 + 1], pixels.Bgra[num9]))
					{
						num7++;
					}
				}
			}
			if (num7 > 0 && num7 > num8 / 2)
			{
				num5 = Math.Min(num5, l);
				num6 = l;
			}
		}
		if (num6 - num5 + 1 < 30)
		{
			return null;
		}
		HealthPixels healthPixels = new HealthPixels(num6 - num5 + 1, num4 - num3 + 1, new byte[(num6 - num5 + 1) * (num4 - num3 + 1) * 4]);
		for (int n = 0; n < healthPixels.Height; n++)
		{
			Array.Copy(pixels.Bgra, ((num3 + n) * pixels.Width + num5) * 4, healthPixels.Bgra, n * healthPixels.Width * 4, healthPixels.Width * 4);
		}
		double? percent = Analyze(healthPixels).Percent;
		if (!percent.HasValue || !(percent.GetValueOrDefault() >= 98.0))
		{
			return null;
		}
		return new HealthRegion(num5, num3, healthPixels.Width, healthPixels.Height);
	}

	public static HealthSample Analyze(HealthPixels pixels)
	{
		ArgumentNullException.ThrowIfNull(pixels, "pixels");
		int width = pixels.Width;
		bool flag = ((width < 30 || width > 4096) ? true : false);
		bool flag2 = flag;
		if (!flag2)
		{
			int height = pixels.Height;
			bool flag3 = ((height < 4 || height > 300) ? true : false);
			flag2 = flag3;
		}
		if (flag2 || pixels.Bgra == null || pixels.Bgra.LongLength != (long)pixels.Width * (long)pixels.Height * 4)
		{
			return new HealthSample(null, "Invalid health image.");
		}
		int[] array = new int[pixels.Height];
		int num = 0;
		for (int i = 0; i < pixels.Height; i++)
		{
			for (int j = 0; j < pixels.Width; j++)
			{
				int num2 = (i * pixels.Width + j) * 4;
				if (IsOrange(pixels.Bgra[num2 + 2], pixels.Bgra[num2 + 1], pixels.Bgra[num2]))
				{
					array[i]++;
				}
			}
			num = Math.Max(num, array[i]);
		}
		if (num == 0)
		{
			return Unknown();
		}
		int num3 = 0;
		bool[] array2 = new bool[pixels.Height];
		for (int k = 0; k < pixels.Height; k++)
		{
			if ((double)array[k] >= (double)num * 0.98)
			{
				array2[k] = true;
				num3++;
			}
		}
		if (num3 < Math.Max(3, pixels.Height / 5))
		{
			return Unknown();
		}
		int num4 = num3 / 2 + 1;
		bool[] array3 = new bool[pixels.Width];
		for (int l = 0; l < pixels.Width; l++)
		{
			int num5 = 0;
			for (int m = 0; m < pixels.Height; m++)
			{
				if (array2[m])
				{
					int num6 = (m * pixels.Width + l) * 4;
					if (IsOrange(pixels.Bgra[num6 + 2], pixels.Bgra[num6 + 1], pixels.Bgra[num6]))
					{
						num5++;
					}
				}
			}
			array3[l] = num5 >= num4;
		}
		int num7 = Math.Clamp(pixels.Width / 100, 2, 12);
		int num8 = Array.FindIndex(array3, (bool column) => column);
		if (num8 < 0 || num8 > num7)
		{
			return Unknown();
		}
		int num9 = num8;
		int num10 = 0;
		int num11 = 0;
		for (int num12 = num8; num12 < array3.Length; num12++)
		{
			if (array3[num12])
			{
				num9 = num12 + 1;
				num10 = 0;
				num11++;
			}
			else if (++num10 > num7)
			{
				break;
			}
		}
		if (num11 < Math.Max(3, Math.Min(8, pixels.Width / 40)))
		{
			return Unknown();
		}
		for (int num13 = Math.Min(num9 + num7, array3.Length); num13 < array3.Length; num13++)
		{
			if (array3[num13])
			{
				return new HealthSample(null, "Health area is obstructed or contains multiple orange sections.");
			}
		}
		double value = Math.Round((double)num9 * 100.0 / (double)pixels.Width, 1);
		return new HealthSample(value, "Health " + value.ToString("0.#", CultureInfo.InvariantCulture) + "%");
	}

	private static HealthSample Unknown()
	{
		return new HealthSample(null, "Health bar not detected. Select the orange bar interior.");
	}

	private static bool IsOrange(byte red, byte green, byte blue)
	{
		byte b = Math.Min(green, blue);
		int num = red - b;
		if (red < 85 || red <= green || green <= blue || (double)num < (double)(int)red * 0.35)
		{
			return false;
		}
		double num2 = 60.0 * (double)(green - blue) / (double)num;
		if (num2 >= 10.0)
		{
			return num2 <= 50.0;
		}
		return false;
	}
}
