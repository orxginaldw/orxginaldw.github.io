namespace Merostrap.Macros.Health;

public enum HealthThresholdTransition
{
	None,
	Low,
	Recovered
}
