using System.Collections.Generic;

namespace Merostrap.Macros;

public sealed record MacroDefinition(string Id, string Name, string Category, string Description, IReadOnlyList<MacroField> Fields);
