using System;

namespace Merostrap.Macros;

public sealed record GankAlert(Uri Endpoint, string Message, string Authorization = "", string WindowId = "", byte[]? Screenshot = null);
