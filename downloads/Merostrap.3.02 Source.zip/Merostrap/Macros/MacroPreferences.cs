using System.Collections.Generic;

namespace Merostrap.Macros;

public sealed class MacroPreferences
{
	public List<MacroProfile> Profiles { get; set; } = CreateDefaultProfiles();

	public int SelectedProfile { get; set; }

	public string GuiKeybind { get; set; } = "f10";

	public string GuiTheme { get; set; } = "Obsidian";

	public bool OverlayVisible { get; set; }

	public bool OverlayLocked { get; set; }

	public int? OverlayX { get; set; }

	public int? OverlayY { get; set; }

	public int? GuiX { get; set; }

	public int? GuiY { get; set; }

	public ParryBarSettings ParryBar { get; set; } = new ParryBarSettings();

	public FlowStateOverlaySettings FlowStateOverlay { get; set; } = new FlowStateOverlaySettings();

	internal static List<MacroProfile> CreateDefaultProfiles()
	{
		List<MacroProfile> list = new List<MacroProfile>(10);
		for (int i = 0; i < 10; i++)
		{
			list.Add(new MacroProfile
			{
				Name = $"Preset {i + 1}"
			});
		}
		return list;
	}
}
