using System;
using System.Threading;
using Merostrap.Macros.Health;

namespace Merostrap.Macros;

public sealed class WindowsCharismaPromptSource : ICharismaPromptSource, IDisposable
{
	private readonly WindowsHealthCapture _capture = new WindowsHealthCapture();

	private readonly CharismaPromptReader _reader = new CharismaPromptReader();

	public CharismaFrame Read(CancellationToken token)
	{
		token.ThrowIfCancellationRequested();
		nint num = WindowsHealthCapture.ForegroundRobloxWindow();
		HealthRegion healthRegion = WindowsHealthCapture.ForegroundRobloxClientArea();
		if (num == IntPtr.Zero || (object)healthRegion == null)
		{
			return new CharismaFrame("", "", Reliable: false);
		}
		HealthPixels healthPixels = new HealthPixels(healthRegion.Width, healthRegion.Height, new byte[checked(healthRegion.Width * healthRegion.Height * 4)]);
		int num2 = healthRegion.Width / 3;
		int num3 = healthRegion.Height * 35 / 100;
		int num4 = healthRegion.Width / 3;
		int num5 = healthRegion.Height * 16 / 100;
		for (int i = 0; i < num5; i += 300)
		{
			token.ThrowIfCancellationRequested();
			if (num != WindowsHealthCapture.ForegroundRobloxWindow())
			{
				return new CharismaFrame("", "", Reliable: false);
			}
			int num6 = ((num5 - i < 4) ? (num5 - 4) : i);
			HealthPixels healthPixels2 = _capture.Capture(new HealthRegion(healthRegion.X + num2, healthRegion.Y + num3 + num6, num4, Math.Min(300, num5 - num6)));
			for (int j = 0; j < healthPixels2.Height; j++)
			{
				Array.Copy(healthPixels2.Bgra, j * num4 * 4, healthPixels.Bgra, ((num3 + num6 + j) * healthRegion.Width + num2) * 4, num4 * 4);
			}
		}
		CharismaFrame charismaFrame = _reader.Analyze(healthPixels);
		token.ThrowIfCancellationRequested();
		if (num != WindowsHealthCapture.ForegroundRobloxWindow() || healthRegion != WindowsHealthCapture.ForegroundRobloxClientArea())
		{
			return new CharismaFrame("", "", Reliable: false);
		}
		CharismaFrame charismaFrame2 = charismaFrame._003CClone_003E_0024();
		HealthRegion inputArea = charismaFrame.InputArea;
		charismaFrame2.InputArea = (((object)inputArea != null) ? inputArea with
		{
			X = inputArea.X + healthRegion.X,
			Y = inputArea.Y + healthRegion.Y
		} : null);
		return charismaFrame2;
	}

	public void Dispose()
	{
		_reader.Dispose();
	}
}
