using System;
using System.IO;
using System.Reflection;

namespace Merostrap.Macros;

public static class HealthOcrResources
{
	private static readonly object Gate = new object();

	private static string? _ready;

	public static string EnsureAvailable()
	{
		lock (Gate)
		{
			if (_ready != null)
			{
				return _ready;
			}
			Assembly assembly = typeof(HealthOcrResources).Assembly;
			string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Merostrap", "Ocr", assembly.ManifestModule.ModuleVersionId.ToString("N"));
			string[] array = new string[3] { "tessdata/eng.traineddata", "x64/tesseract50.dll", "x64/leptonica-1.82.0.dll" };
			foreach (string text2 in array)
			{
				using Stream stream = assembly.GetManifestResourceStream("Ocr." + text2.Replace('/', '.')) ?? throw new IOException("Missing bundled OCR resource: " + text2);
				string text3 = Path.Combine(text, text2);
				if (File.Exists(text3) && new FileInfo(text3).Length == stream.Length)
				{
					continue;
				}
				Directory.CreateDirectory(Path.GetDirectoryName(text3));
				string text4 = text3 + "." + Guid.NewGuid().ToString("N") + ".tmp";
				try
				{
					using (FileStream destination = File.Create(text4))
					{
						stream.CopyTo(destination);
					}
					File.Move(text4, text3, overwrite: true);
				}
				finally
				{
					if (File.Exists(text4))
					{
						File.Delete(text4);
					}
				}
			}
			return _ready = text;
		}
	}
}
