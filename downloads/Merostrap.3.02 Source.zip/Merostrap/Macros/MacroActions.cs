using System.Threading;
using System.Threading.Tasks;

namespace Merostrap.Macros;

internal sealed class MacroActions(MacroEngine engine, CancellationToken token)
{
	public CancellationToken Token => token;

	public string Primary => engine.PrimaryButton;

	public string Secondary
	{
		get
		{
			if (!(Primary == "mouse1"))
			{
				return "mouse1";
			}
			return "mouse2";
		}
	}

	public Task Wait(int milliseconds)
	{
		return Task.Delay(milliseconds, token);
	}

	public void Down(string key)
	{
		engine.Key(token, key, down: true);
	}

	public void Up(string key)
	{
		engine.Key(token, key, down: false);
	}

	public void BeginRitualTap(string key)
	{
		engine.BeginRitualTap(token, key);
	}

	public void EndRitualTap(string key)
	{
		engine.EndRitualTap(token, key);
	}

	public async Task Tap(string key, int milliseconds = 10)
	{
		string text = engine.PrepareFlowForGeneratedFeint(token, key);
		if (text != null)
		{
			await Tap(text);
		}
		Down(key);
		await Wait(milliseconds);
		Up(key);
	}

	public Task Click(int milliseconds = 10)
	{
		return Tap(Primary, milliseconds);
	}

	public void Move((int X, int Y) point)
	{
		engine.Send(token, (IMacroInput input) =>
		{
			input.Move(point.X, point.Y);
		});
	}

	public void Scroll(int delta)
	{
		engine.Send(token, (IMacroInput input) =>
		{
			input.Scroll(delta);
		});
	}

	public void CheckForeground()
	{
		engine.Send(token, (IMacroInput _) =>
		{
		});
	}

	public void ReportStatus(string status)
	{
		engine.ReportStatus(token, status);
	}

	public void Complete(string status)
	{
		engine.Complete(token, status);
	}

	public void ReportRitualPrompt(RitualPromptHighlight? prompt)
	{
		engine.ReportRitualPrompt(token, prompt);
	}

	public void Center()
	{
		var (num, num2) = engine.ScreenSize;
		Move((X: num / 2, Y: num2 / 2));
	}

	public async Task Text(string content)
	{
		foreach (char character in content)
		{
			engine.Send(token, (IMacroInput input) =>
			{
				input.Character(character);
			});
			await Wait(5);
		}
	}

	public async Task Chat(string content)
	{
		await Wait(50);
		await Tap("/");
		await Wait(50);
		await Text(content);
		await Wait(50);
		await Tap("enter");
	}
}
