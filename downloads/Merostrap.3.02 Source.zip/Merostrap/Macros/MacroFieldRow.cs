using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Merostrap.Macros;

public sealed class MacroFieldRow : ObservableObject
{
	private readonly MacroField _field;

	private readonly Dictionary<string, string> _values;

	private readonly Action _changed;

	private readonly bool _calibration;

	private IReadOnlyList<GankWindowOption>? _windows;

	public bool IsShown
	{
		get
		{
			bool flag = !_calibration;
			if (flag)
			{
				bool flag2;
				switch (Key)
				{
				case "webhook_url":
					flag2 = _values.GetValueOrDefault("delivery_mode", "0") == "0";
					break;
				case "discord_token":
				case "channel_id":
					flag2 = _values.GetValueOrDefault("delivery_mode", "0") == "1";
					break;
				default:
					flag2 = true;
					break;
				}
				flag = flag2;
			}
			return flag;
		}
	}

	public char SecretMask
	{
		get
		{
			if (!(Key == "discord_token"))
			{
				return '\0';
			}
			return '●';
		}
	}

	public string Key => _field.Key;

	public string Label => _field.Label;

	public bool IsPoint
	{
		get
		{
			if (!_calibration)
			{
				return Key.EndsWith("coordinates", StringComparison.Ordinal);
			}
			return false;
		}
	}

	public bool IsPath
	{
		get
		{
			string key = Key;
			if (key == "basepath" || key == "txtpath")
			{
				return true;
			}
			return false;
		}
	}

	public bool IsChoice
	{
		get
		{
			switch (Key)
			{
			case "scale":
			case "resolution":
			case "delivery_mode":
			case "capture_window":
				return true;
			default:
				return false;
			}
		}
	}

	public string PickLabel
	{
		get
		{
			if (!IsPoint)
			{
				if (!string.IsNullOrWhiteSpace(Value))
				{
					return Path.GetFileName(Value.TrimEnd(new char[2] { '\\', '/' }));
				}
				if (!(Key == "basepath"))
				{
					return "Choose file";
				}
				return "Choose folder";
			}
			if (!string.IsNullOrWhiteSpace(Value))
			{
				return "Repin · " + Value;
			}
			return "Pin point";
		}
	}

	public IReadOnlyList<string> Choices
	{
		get
		{
			if (!(Key == "capture_window"))
			{
				if (!(Key == "delivery_mode"))
				{
					if (Key == "scale")
					{
						return new string[2] { "100%", "125%" };
					}
					return new string[9] { "1128 × 634", "1366 × 768", "1600 × 900", "1600 × 1200", "1920 × 1080", "1920 × 1200", "2560 × 1080", "2560 × 1440", "3440 × 1440" };
				}
				return new string[2] { "Webhook", "Selfbot" };
			}
			return (_windows ?? (_windows = GankWindowCapture.List())).Select((GankWindowOption w) => w.Label).ToArray();
		}
	}

	public int ChoiceIndex
	{
		get
		{
			if (!(Key == "capture_window"))
			{
				if (!int.TryParse(Value, out var result))
				{
					return -1;
				}
				return result;
			}
			return (_windows ?? (_windows = GankWindowCapture.List())).ToList().FindIndex((GankWindowOption w) => w.Id == Value);
		}
		set
		{
			if (value >= 0 && value < Choices.Count)
			{
				Value = ((Key == "capture_window") ? _windows[value].Id : value.ToString(CultureInfo.InvariantCulture));
			}
		}
	}

	public string Help => _field.Help;

	public bool IsBoolean
	{
		get
		{
			string defaultValue = _field.DefaultValue;
			if (defaultValue == "true" || defaultValue == "false")
			{
				return true;
			}
			return false;
		}
	}

	public bool IsKeybind
	{
		get
		{
			if (!(_field.Key == "keyToPress"))
			{
				return _field.Key.EndsWith("keybind", StringComparison.Ordinal);
			}
			return true;
		}
	}

	public bool AllowsMainMouse => Key == "feintkeybind";

	public bool IsText
	{
		get
		{
			if (!_calibration && !IsBoolean && !IsKeybind && !IsPoint && !IsPath)
			{
				return !IsChoice;
			}
			return false;
		}
	}

	public bool BooleanValue
	{
		get
		{
			bool result;
			return bool.TryParse(Value, out result) & result;
		}
		set
		{
			Value = (value ? "true" : "false");
		}
	}

	public string Value
	{
		get
		{
			string valueOrDefault = _values.GetValueOrDefault(_field.Key, _field.DefaultValue);
			if (!(Key == "discord_token"))
			{
				return valueOrDefault;
			}
			return GankSecrets.Read(valueOrDefault);
		}
		set
		{
			if (!(Value == value))
			{
				_values[_field.Key] = ((Key == "discord_token") ? GankSecrets.Protect(value) : value);
				OnPropertyChanged("Value");
				OnPropertyChanged("BooleanValue");
				OnPropertyChanged("PickLabel");
				OnPropertyChanged("ChoiceIndex");
				_changed();
			}
		}
	}

	public MacroFieldRow(MacroField field, Dictionary<string, string> values, Action changed, bool calibration = false)
	{
		_field = field;
		_values = values;
		_changed = changed;
		_calibration = calibration;
	}

	public void RefreshVisibility()
	{
		OnPropertyChanged("IsShown");
	}

	public void RefreshChoices()
	{
		if (!(Key != "capture_window"))
		{
			_windows = GankWindowCapture.List();
			OnPropertyChanged("Choices");
			OnPropertyChanged("ChoiceIndex");
		}
	}
}
