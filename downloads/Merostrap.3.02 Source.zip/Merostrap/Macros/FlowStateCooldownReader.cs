using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using Merostrap.Macros.Health;

namespace Merostrap.Macros;

public sealed class FlowStateCooldownReader : IDisposable
{
	private HealthRegion? _slot;

	private int _width;

	private int _height;

	private static readonly double[] Template = LoadTemplate();

	public string Diagnostic { get; private set; } = "";

	public FlowStateCooldownSample Analyze(HealthPixels hotbar)
	{
		if (hotbar.Bgra.Length != (long)hotbar.Width * (long)hotbar.Height * 4)
		{
			return new FlowStateCooldownSample(null, "Hotbar unavailable");
		}
		if (_width != hotbar.Width || _height != hotbar.Height)
		{
			_slot = null;
			_width = hotbar.Width;
			_height = hotbar.Height;
		}
		HealthRegion slot = _slot;
		if ((object)slot != null && Score(hotbar, slot) < 0.65)
		{
			_slot = null;
		}
		if ((object)_slot == null)
		{
			_slot = Detect(hotbar);
		}
		HealthRegion slot2 = _slot;
		if ((object)slot2 == null)
		{
			return new FlowStateCooldownSample(null, "Looking for Flow State");
		}
		List<double> list = new List<double>();
		int num = 0;
		int num2 = 255;
		for (int i = slot2.Y + 3; i < slot2.Y + slot2.Height - 3; i++)
		{
			List<int> list2 = new List<int>();
			for (int j = slot2.X + 2; j < slot2.X + slot2.Width - 2; j++)
			{
				int num3 = (i * hotbar.Width + j) * 4;
				int num4 = Math.Min(hotbar.Bgra[num3], Math.Min(hotbar.Bgra[num3 + 1], hotbar.Bgra[num3 + 2]));
				list2.Add(num4);
				num = Math.Max(num, num4);
				num2 = Math.Min(num2, num4);
			}
			list2.Sort();
			list.Add(list2[(int)((double)(list2.Count - 1) * 0.95)]);
		}
		if (list.Count < 8 || num < 145 || num - num2 < 35)
		{
			_slot = null;
			return new FlowStateCooldownSample(null, "Hotbar unavailable");
		}
		int num5 = 0;
		double num6 = double.MaxValue;
		for (int k = 0; k <= list.Count; k++)
		{
			double num7 = 0.0;
			for (int l = 0; l < list.Count; l++)
			{
				double num8 = 225.0 - 36.0 * (double)l / (double)Math.Max(1, list.Count - 1);
				double num9 = ((l < k) ? num8 : (num8 * 0.8));
				num7 += Math.Pow(list[l] - num9, 2.0);
			}
			if (num7 < num6)
			{
				num6 = num7;
				num5 = k;
			}
		}
		double num10 = 100.0 * (double)num5 / (double)list.Count;
		if (num10 >= 95.0)
		{
			num10 = 100.0;
		}
		return new FlowStateCooldownSample(num10, (num10 >= 99.0) ? "Ready" : "Cooling down", slot2);
	}

	private static double[] LoadTemplate()
	{
		Assembly assembly = typeof(FlowStateCooldownReader).Assembly;
		using Stream utf8Json = assembly.GetManifestResourceStream(assembly.GetManifestResourceNames().Single((string n) => n.EndsWith("flow-state-card.json", StringComparison.Ordinal)));
		double[] array = JsonSerializer.Deserialize<double[]>(utf8Json);
		for (int num = 0; num < 12; num++)
		{
			double num2 = array.Skip(num * 10).Take(10).Average();
			for (int num3 = 0; num3 < 10; num3++)
			{
				array[num * 10 + num3] -= num2;
			}
		}
		return array;
	}

	private static double Score(HealthPixels pixels, HealthRegion slot)
	{
		double num = 0.0;
		double num2 = 0.0;
		double num3 = 0.0;
		Span<double> span = stackalloc double[10];
		for (int i = 0; i < 12; i++)
		{
			double num4 = 0.0;
			for (int j = 0; j < 10; j++)
			{
				int num5 = slot.X + (int)Math.Round((2.0 + (double)j * 29.0 / 9.0) * (double)slot.Width / 34.0);
				int num6 = ((slot.Y + (int)Math.Round((3.0 + (double)i * 27.0 / 11.0) * (double)slot.Height / 34.0)) * pixels.Width + num5) * 4;
				span[j] = (int)Math.Min(pixels.Bgra[num6], Math.Min(pixels.Bgra[num6 + 1], pixels.Bgra[num6 + 2]));
				num4 += span[j] / 10.0;
			}
			for (int k = 0; k < 10; k++)
			{
				double num7 = span[k] - num4;
				double num8 = Template[i * 10 + k];
				num += num7 * num8;
				num2 += num7 * num7;
				num3 += num8 * num8;
			}
		}
		if (!(num2 < 100.0))
		{
			return num / Math.Sqrt(num2 * num3);
		}
		return 0.0;
	}

	private HealthRegion? Detect(HealthPixels pixels)
	{
		double num = 0.78;
		HealthRegion healthRegion = null;
		int num2 = Math.Min(70, pixels.Height - 4);
		for (int i = 28; i <= num2; i += 2)
		{
			for (int j = 0; j + i < pixels.Height; j += 2)
			{
				for (int k = 0; k + i < pixels.Width; k += 2)
				{
					HealthRegion healthRegion2 = new HealthRegion(k, j, i, i);
					double num3 = Score(pixels, healthRegion2);
					if (num3 > num)
					{
						num = num3;
						healthRegion = healthRegion2;
					}
				}
			}
		}
		if ((object)healthRegion != null)
		{
			HealthRegion healthRegion3 = healthRegion;
			for (int l = Math.Max(28, healthRegion3.Width - 1); l <= healthRegion3.Width + 1; l++)
			{
				for (int m = Math.Max(0, healthRegion3.Y - 1); m <= healthRegion3.Y + 1; m++)
				{
					for (int n = Math.Max(0, healthRegion3.X - 1); n <= healthRegion3.X + 1; n++)
					{
						if (n + l < pixels.Width && m + l < pixels.Height)
						{
							HealthRegion healthRegion4 = new HealthRegion(n, m, l, l);
							double num4 = Score(pixels, healthRegion4);
							if (num4 > num)
							{
								num = num4;
								healthRegion = healthRegion4;
							}
						}
					}
				}
			}
		}
		Diagnostic = $"Card match {num:0.000}";
		return healthRegion;
	}

	public void Dispose()
	{
	}
}
