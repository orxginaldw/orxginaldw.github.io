using System.Threading;
using System.Threading.Tasks;

namespace Merostrap.Macros;

public interface IDiscordDeafenState
{
	Task<bool?> ReadAsync(CancellationToken cancellationToken);
}
