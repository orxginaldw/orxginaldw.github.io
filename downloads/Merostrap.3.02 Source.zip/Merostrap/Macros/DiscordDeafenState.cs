using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using Interop.UIAutomationClient;

namespace Merostrap.Macros;

public sealed class DiscordDeafenState : IDiscordDeafenState
{
	private readonly SemaphoreSlim _gate = new SemaphoreSlim(1, 1);

	public string ReadStatus { get; private set; } = "Not checked";

	public bool? ForegroundPreserved { get; private set; }

	public async Task<bool?> ReadAsync(CancellationToken cancellationToken)
	{
		bool flag = !OperatingSystem.IsWindows();
		if (!flag)
		{
			flag = !(await _gate.WaitAsync(0, cancellationToken));
		}
		if (flag)
		{
			return null;
		}
		Task<bool?> task = Task.Run(() =>
		{
			try
			{
				return ReadNative();
			}
			catch (Exception ex2) when ((ex2 is COMException || ex2 is InvalidOperationException || ex2 is Win32Exception) ? true : false)
			{
				ReadStatus = "Accessibility unavailable: " + ex2.GetType().Name;
				return (bool?)null;
			}
			finally
			{
				_gate.Release();
			}
		}, CancellationToken.None);
		try
		{
			return await task.WaitAsync(TimeSpan.FromMilliseconds(700L), cancellationToken);
		}
		catch (TimeoutException)
		{
			ReadStatus = "Discord state read timed out";
			return null;
		}
	}

	public async Task<bool?> EnsureDeafenedAsync(CancellationToken cancellationToken)
	{
		bool flag = !OperatingSystem.IsWindows();
		if (!flag)
		{
			flag = !(await _gate.WaitAsync(0, cancellationToken));
		}
		if (flag)
		{
			return null;
		}
		try
		{
			bool? flag2 = await Task.Run(() => ReadNative(ensureDeafened: true, cancellationToken), CancellationToken.None);
			if ((flag2 ?? true) ? true : false)
			{
				return flag2;
			}
			for (int attempt = 0; attempt < 5; attempt++)
			{
				await Task.Delay(150, cancellationToken);
				flag2 = await Task.Run(() => ReadNative(), CancellationToken.None);
				if (flag2 == true)
				{
					return true;
				}
			}
			return flag2;
		}
		catch (Exception ex) when ((ex is COMException || ex is InvalidOperationException || ex is Win32Exception) ? true : false)
		{
			ReadStatus = "Discord state change could not be confirmed";
			return null;
		}
		finally
		{
			_gate.Release();
		}
	}

	public static bool? RequestDeafened(Func<bool?> read, Action turnOn)
	{
		bool? flag = read();
		if (flag != false)
		{
			return flag;
		}
		turnOn();
		return read();
	}

	private bool? ReadNative(bool ensureDeafened = false, CancellationToken cancellationToken = default(CancellationToken))
	{
		List<nint> list = new List<nint>();
		string[] array = new string[3] { "Discord", "DiscordPTB", "DiscordCanary" };
		for (int i = 0; i < array.Length; i++)
		{
			Process[] processesByName = Process.GetProcessesByName(array[i]);
			foreach (Process process in processesByName)
			{
				using (process)
				{
					if (process.MainWindowHandle != 0)
					{
						list.Add(process.MainWindowHandle);
					}
				}
			}
		}
		if (list.Count != 1)
		{
			ReadStatus = $"Discord window count: {list.Count}";
			return null;
		}
		DiscordFocusGuard focus = (ensureDeafened ? new DiscordFocusGuard(list[0], (bool value) =>
		{
			ForegroundPreserved = value;
		}) : null);
		try
		{
			IUIAutomation iUIAutomation = new CUIAutomation8Class();
			IUIAutomationElement iUIAutomationElement = null;
			IUIAutomationElementArray iUIAutomationElementArray = null;
			IUIAutomationCondition iUIAutomationCondition = null;
			IUIAutomationCondition iUIAutomationCondition2 = null;
			IUIAutomationCondition iUIAutomationCondition3 = null;
			try
			{
				IUIAutomation2 iUIAutomation2 = (IUIAutomation2)iUIAutomation;
				iUIAutomation2.ConnectionTimeout = 250u;
				iUIAutomation2.TransactionTimeout = 250u;
				iUIAutomationElement = iUIAutomation.ElementFromHandle(list[0]);
				iUIAutomationCondition = iUIAutomation.CreatePropertyCondition(30005, "Deafen");
				iUIAutomationCondition2 = iUIAutomation.CreatePropertyCondition(30005, "Undeafen");
				iUIAutomationCondition3 = iUIAutomation.CreateOrCondition(iUIAutomationCondition, iUIAutomationCondition2);
				iUIAutomationElementArray = iUIAutomationElement.FindAll(TreeScope.TreeScope_Descendants, iUIAutomationCondition3);
				if (iUIAutomationElementArray.Length != 1)
				{
					ReadStatus = "Discord deafen control unavailable";
					return null;
				}
				IUIAutomationElement element = iUIAutomationElementArray.GetElement(0);
				object obj = null;
				try
				{
					obj = element.GetCurrentPattern(10015);
					ReadStatus = ((obj is IUIAutomationTogglePattern) ? "Toggle state read" : "Toggle state not exposed");
					IUIAutomationTogglePattern toggle = obj as IUIAutomationTogglePattern;
					if (toggle == null)
					{
						return null;
					}
					return ensureDeafened ? RequestDeafened(Read, () =>
					{
						cancellationToken.ThrowIfCancellationRequested();
						try
						{
							toggle.Toggle();
						}
						finally
						{
							focus?.Restore();
						}
					}) : Read();
					bool? Read()
					{
						return toggle.CurrentToggleState switch
						{
							ToggleState.ToggleState_On => (bool?)true, 
							ToggleState.ToggleState_Off => false, 
							_ => null, 
						};
					}
				}
				finally
				{
					Release(obj);
					Release(element);
				}
			}
			finally
			{
				Release(iUIAutomationElementArray);
				Release(iUIAutomationCondition3);
				Release(iUIAutomationCondition2);
				Release(iUIAutomationCondition);
				Release(iUIAutomationElement);
				Release(iUIAutomation);
			}
		}
		finally
		{
			if (focus != null)
			{
				((IDisposable)focus).Dispose();
			}
		}
	}

	private static void Release(object? value)
	{
		if (value != null && Marshal.IsComObject(value))
		{
			Marshal.ReleaseComObject(value);
		}
	}
}
