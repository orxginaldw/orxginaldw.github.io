namespace Merostrap.Macros;

public sealed record GankWindowOption(string Id, string Label);
