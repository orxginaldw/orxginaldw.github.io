using System;
using System.Threading;

namespace Merostrap.Macros;

public interface ICharismaPromptSource : IDisposable
{
	CharismaFrame Read(CancellationToken token);
}
