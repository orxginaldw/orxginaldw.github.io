using Merostrap.Macros.Health;

namespace Merostrap.Macros;

public sealed record FlowStateCooldownSample(double? ReadyPercent, string Status, HealthRegion? Slot = null);
