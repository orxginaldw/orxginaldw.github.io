using System;

namespace Merostrap.Macros;

public sealed class ParryFillMotion
{
	private double? _visible;

	private double _rate;

	private long _visibleAt;

	private long? _advancedAt;

	private bool _covered;

	public double Value { get; private set; }

	public double DisplayValue { get; private set; }

	public void Observe(double? percent, bool spectralCovered, long now)
	{
		double valueOrDefault;
		if (percent.HasValue)
		{
			valueOrDefault = percent.GetValueOrDefault();
			if (double.IsFinite(valueOrDefault))
			{
				valueOrDefault = Math.Clamp(valueOrDefault, 0.0, 100.0);
				double? visible = _visible;
				if (visible.HasValue)
				{
					double valueOrDefault2 = visible.GetValueOrDefault();
					if (now > _visibleAt)
					{
						double num = valueOrDefault - valueOrDefault2;
						if (num < -3.0)
						{
							_rate = 0.0;
						}
						else if (num > 0.1)
						{
							double num2 = Math.Clamp(num * 1000.0 / (double)(now - _visibleAt), 0.0, 300.0);
							_rate = ((_rate > 0.0) ? ((_rate + num2) / 2.0) : num2);
						}
						if (num < -20.0)
						{
							DisplayValue = valueOrDefault;
						}
						goto IL_0104;
					}
				}
				DisplayValue = valueOrDefault;
				goto IL_0104;
			}
		}
		if (spectralCovered && _visible.HasValue && now - _visibleAt <= 2500)
		{
			_covered = true;
		}
		else
		{
			Reset();
		}
		return;
		IL_0104:
		double value = (Value = valueOrDefault);
		_visible = value;
		_visibleAt = now;
		_covered = false;
	}

	public void Advance(long now)
	{
		if (_covered)
		{
			double? visible = _visible;
			if (visible.HasValue)
			{
				double valueOrDefault = visible.GetValueOrDefault();
				if (now - _visibleAt > 2500)
				{
					Reset();
				}
				else
				{
					Value = Math.Min(99.0, valueOrDefault + _rate * (double)Math.Max(0L, now - _visibleAt) / 1000.0);
				}
			}
		}
		long? advancedAt = _advancedAt;
		long num;
		if (advancedAt.HasValue)
		{
			long valueOrDefault2 = advancedAt.GetValueOrDefault();
			num = Math.Max(0L, now - valueOrDefault2);
		}
		else
		{
			num = 0L;
		}
		double num2 = num;
		_advancedAt = now;
		DisplayValue += (Value - DisplayValue) * (1.0 - Math.Exp((0.0 - num2) / 60.0));
		if (Math.Abs(Value - DisplayValue) < 0.01)
		{
			DisplayValue = Value;
		}
	}

	public void Reset()
	{
		_visible = null;
		_rate = 0.0;
		_covered = false;
		_advancedAt = null;
		double value = (DisplayValue = 0.0);
		Value = value;
	}
}
