using Merostrap.Macros.Health;

namespace Merostrap.Macros;

public sealed record DetectedHudBars(HealthRegion Health, HealthRegion Parry, ParryTrack Track);
