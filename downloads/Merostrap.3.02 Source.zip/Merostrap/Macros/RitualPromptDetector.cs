using System;
using System.Collections.Generic;
using System.Linq;
using Merostrap.Macros.Health;

namespace Merostrap.Macros;

public static class RitualPromptDetector
{
	public enum OutlineState
	{
		Absent,
		Visible,
		Uncertain
	}

	private readonly record struct Line(int Left, int Right, int Y);

	public static RitualFrame GateRecognition(RitualFrame frame, OutlineState outline)
	{
		if (outline == OutlineState.Absent)
		{
			return new RitualFrame(Array.Empty<RitualGlyph>(), Reliable: true, PromptAbsent: true);
		}
		return frame with
		{
			Reliable = (frame.Reliable && outline == OutlineState.Visible),
			PromptAbsent = false
		};
	}

	public static HealthRegion? Detect(HealthPixels pixels, bool requireGlyphs = true)
	{
		bool uncertain;
		return DetectCore(pixels, requireGlyphs, out uncertain);
	}

	public static OutlineState ReadOutline(HealthPixels pixels)
	{
		if ((object)DetectCore(pixels, requireGlyphs: false, out var uncertain) == null)
		{
			if (!uncertain)
			{
				return OutlineState.Absent;
			}
			return OutlineState.Uncertain;
		}
		return OutlineState.Visible;
	}

	private static HealthRegion? DetectCore(HealthPixels pixels, bool requireGlyphs, out bool uncertain)
	{
		uncertain = true;
		bool flag = (object)pixels == null;
		if (!flag)
		{
			int width = pixels.Width;
			bool flag2 = ((width < 160 || width > 4096) ? true : false);
			flag = flag2;
		}
		bool flag3 = flag;
		if (!flag3)
		{
			int width = pixels.Height;
			bool flag2 = ((width < 40 || width > 2160) ? true : false);
			flag3 = flag2;
		}
		if (flag3 || pixels.Bgra == null || pixels.Bgra.Length != (long)pixels.Width * (long)pixels.Height * 4)
		{
			return null;
		}
		int w = pixels.Width;
		int height = pixels.Height;
		List<Line> list = new List<Line>();
		for (int i = 2; i < height - 2; i++)
		{
			int num = -1;
			int num2 = -1;
			int num3 = 0;
			for (int j = 2; j < w - 2; j++)
			{
				if (Edge(j, i, horizontal: true))
				{
					if (num < 0)
					{
						num = j;
					}
					num2 = j;
					num3++;
				}
				if (num >= 0 && (j - num2 > 6 || j == w - 3))
				{
					int num4 = num2 - num + 1;
					if (num4 >= 120 && num4 <= 1100 && (double)num3 >= (double)num4 * 0.75)
					{
						list.Add(new Line(num, num2, i));
					}
					num = -1;
					num3 = 0;
				}
			}
		}
		if (list.Count > 2048)
		{
			return null;
		}
		List<HealthRegion> regions = new List<HealthRegion>();
		int num5 = 0;
		int num6 = 0;
		RitualPromptReader reader = new RitualPromptReader();
		try
		{
			foreach (Line item in list)
			{
				foreach (Line item2 in list)
				{
					if (++num5 > 262144)
					{
						return null;
					}
					int num7 = item2.Y - item.Y;
					int num8 = item.Right - item.Left;
					flag3 = ((num7 < 30 || num7 > 220) ? true : false);
					if (flag3 || num8 < num7 * 2 || num8 > num7 * 10 || Math.Abs(item.Left - item2.Left) > 5 || Math.Abs(item.Right - item2.Right) > 5)
					{
						continue;
					}
					if (++num6 > 256)
					{
						return null;
					}
					int num9 = 0;
					int num10 = 0;
					int num11 = 0;
					int num12 = 0;
					int num13 = 0;
					int num14 = 0;
					int y;
					for (y = item.Y + 3; y < item2.Y - 2; y++)
					{
						if (Enumerable.Range(Math.Max(2, item.Left - 2), 5).Any((int x) => x < w - 2 && Edge(x, y, horizontal: false)))
						{
							num9++;
							num11 = 0;
						}
						else
						{
							num13 = Math.Max(num13, ++num11);
						}
						if (Enumerable.Range(Math.Max(2, item.Right - 2), 5).Any((int x) => x < w - 2 && Edge(x, y, horizontal: false)))
						{
							num10++;
							num12 = 0;
						}
						else
						{
							num14 = Math.Max(num14, ++num12);
						}
					}
					if (!((double)num9 < (double)num7 * 0.55) && !((double)num10 < (double)num7 * 0.55) && num13 <= 8 && num14 <= 8)
					{
						HealthRegion region = new HealthRegion(item.Left + 3, item.Y + 3, num8 - 5, num7 - 5);
						if (!regions.Any((HealthRegion old) => Math.Abs(old.X - region.X) <= 6 && Math.Abs(old.Y - region.Y) <= 6 && Math.Abs(old.Width - region.Width) <= 10 && Math.Abs(old.Height - region.Height) <= 10))
						{
							regions.Add(region);
						}
					}
				}
			}
			HealthRegion[] array = regions.Where((HealthRegion inner) => !regions.Any((HealthRegion other) => other != inner && other.X <= inner.X + 3 && other.Y <= inner.Y + 3 && other.X + other.Width >= inner.X + inner.Width - 3 && other.Y + other.Height >= inner.Y + inner.Height - 3 && (other.Width > inner.Width + 6 || other.Height > inner.Height + 6))).ToArray();
			if (requireGlyphs)
			{
				array = array.Where((HealthRegion region2) =>
				{
					RitualFrame ritualFrame = reader.Analyze(HudCrop(pixels, region2));
					if (ritualFrame.Reliable)
					{
						int count = ritualFrame.Glyphs.Count;
						if (count >= 1 && count <= 12)
						{
							return ritualFrame.Glyphs.All((RitualGlyph g) => g.Character.HasValue);
						}
					}
					return false;
				}).ToArray();
			}
			if (array.Length > 1)
			{
				return null;
			}
			uncertain = false;
			return (array.Length == 1) ? array[0] : null;
		}
		finally
		{
			if (reader != null)
			{
				((IDisposable)reader).Dispose();
			}
		}
		int Bright(int x, int num16)
		{
			int num15 = (num16 * w + x) * 4;
			return (pixels.Bgra[num15] + pixels.Bgra[num15 + 1] + pixels.Bgra[num15 + 2]) / 3;
		}
		bool Edge(int x, int num16, bool horizontal)
		{
			int num15 = (num16 * w + x) * 4;
			int val = pixels.Bgra[num15];
			int val2 = pixels.Bgra[num15 + 1];
			int val3 = pixels.Bgra[num15 + 2];
			if (Math.Min(val, Math.Min(val2, val3)) < 65 || Math.Max(val, Math.Max(val2, val3)) - Math.Min(val, Math.Min(val2, val3)) > 45)
			{
				return false;
			}
			int num17 = Bright(x, num16);
			if (!horizontal)
			{
				if (Math.Abs(num17 - Bright(x - 2, num16)) < 15)
				{
					return Math.Abs(num17 - Bright(x + 2, num16)) >= 15;
				}
				return true;
			}
			if (Math.Abs(num17 - Bright(x, num16 - 2)) < 15)
			{
				return Math.Abs(num17 - Bright(x, num16 + 2)) >= 15;
			}
			return true;
		}
	}

	public static HealthPixels HudCrop(HealthPixels source, HealthRegion region)
	{
		region.Validate();
		if (region.X < 0 || region.Y < 0 || (long)region.X + (long)region.Width > source.Width || (long)region.Y + (long)region.Height > source.Height)
		{
			throw new ArgumentException("Prompt area is outside the image.");
		}
		byte[] array = new byte[region.Width * region.Height * 4];
		for (int i = 0; i < region.Height; i++)
		{
			Array.Copy(source.Bgra, ((region.Y + i) * source.Width + region.X) * 4, array, i * region.Width * 4, region.Width * 4);
		}
		return new HealthPixels(region.Width, region.Height, array);
	}
}
