using System;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace Merostrap.Macros;

internal sealed class MacroInputDispatcher : IDisposable
{
	private readonly Channel<MacroInputEvent> _events = Channel.CreateUnbounded<MacroInputEvent>(new UnboundedChannelOptions
	{
		SingleReader = true,
		SingleWriter = true
	});

	private int _stopped;

	public MacroInputDispatcher(Action<MacroInputEvent> receive, Action<Exception> fault)
	{
		MacroInputDispatcher macroInputDispatcher = this;
		Task.Run(async () =>
		{
			_ = 1;
			try
			{
				await foreach (MacroInputEvent item in macroInputDispatcher._events.Reader.ReadAllAsync())
				{
					if (Volatile.Read(in macroInputDispatcher._stopped) != 0)
					{
						break;
					}
					receive(item);
				}
			}
			catch (Exception obj)
			{
				try
				{
					fault(obj);
				}
				catch
				{
				}
			}
		});
	}

	public void Publish(MacroInputEvent input, bool isForegroundRoblox = true)
	{
		if (isForegroundRoblox && Volatile.Read(in _stopped) == 0)
		{
			_events.Writer.TryWrite(input);
		}
	}

	public void Dispose()
	{
		Interlocked.Exchange(ref _stopped, 1);
		_events.Writer.TryComplete();
	}
}
