using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using Merostrap.Macros.Health;
using Tesseract;

namespace Merostrap.Macros;

public sealed class RitualPromptReader : IDisposable
{
	private sealed record Template(string Character, double Aspect, string Mask, string Font, int Size);

	private readonly object _gate = new object();

	private TesseractEngine? _engine;

	private bool _disposed;

	private readonly Dictionary<string, (char Character, double Score, double Margin)> _shapes = new Dictionary<string, (char, double, double)>();

	private static readonly Lazy<(char Character, double Aspect, byte[] Mask)[]> Templates = new Lazy<(char, double, byte[])[]>(() =>
	{
		using Stream utf8Json = typeof(RitualPromptReader).Assembly.GetManifestResourceStream("Merostrap.Resources.Ritual.serif-glyphs.json") ?? throw new IOException("Missing ritual glyph templates.");
		return (from t in JsonSerializer.Deserialize<Template[]>(utf8Json)
			select (t.Character[0], Aspect: t.Aspect, Convert.FromBase64String(t.Mask))).ToArray();
	});

	public RitualFrame Analyze(HealthPixels pixels)
	{
		lock (_gate)
		{
			bool flag = _disposed || (object)pixels == null;
			if (!flag)
			{
				int width = pixels.Width;
				bool flag2 = ((width < 30 || width > 4096) ? true : false);
				flag = flag2;
			}
			bool flag3 = flag;
			if (!flag3)
			{
				int width = pixels.Height;
				bool flag2 = ((width < 4 || width > 300) ? true : false);
				flag3 = flag2;
			}
			if (flag3 || pixels.Bgra == null || pixels.Bgra.Length != (long)pixels.Width * (long)pixels.Height * 4)
			{
				return new RitualFrame(Array.Empty<RitualGlyph>(), Reliable: false);
			}
			RitualFrame ritualFrame = AnalyzeCore(pixels, recoverInk: false);
			if (ritualFrame.Reliable && ritualFrame.Glyphs.Count > 0 && ritualFrame.Glyphs.All((RitualGlyph g) => g.Character.HasValue))
			{
				return ritualFrame;
			}
			RitualFrame recovered = AnalyzeCore(pixels, recoverInk: true);
			if (recovered.Reliable && recovered.Glyphs.Count > 0 && recovered.Glyphs.All((RitualGlyph g) => g.Character.HasValue) && ritualFrame.Glyphs.All((RitualGlyph original) => recovered.Glyphs.Any((RitualGlyph g) => g.X <= original.X && g.Y <= original.Y && g.X + g.Width >= original.X + original.Width && g.Y + g.Height >= original.Y + original.Height && (!original.Character.HasValue || original.Character == g.Character))))
			{
				return recovered;
			}
			int[] array = new int[3] { 130, 100, 70 };
			foreach (int num in array)
			{
				byte[] array2 = new byte[pixels.Bgra.Length];
				for (int num2 = 0; num2 < array2.Length; num2 += 4)
				{
					byte b = (byte)((Math.Max(pixels.Bgra[num2], Math.Max(pixels.Bgra[num2 + 1], pixels.Bgra[num2 + 2])) >= num) ? byte.MaxValue : 0);
					array2[num2] = (array2[num2 + 1] = (array2[num2 + 2] = b));
				}
				RitualFrame candidate = AnalyzeCore(new HealthPixels(pixels.Width, pixels.Height, array2), recoverInk: false);
				if (candidate.Reliable && candidate.Glyphs.Count > 0 && candidate.Glyphs.All((RitualGlyph g) => g.Character.HasValue) && ritualFrame.Glyphs.All((RitualGlyph original) => candidate.Glyphs.Any((RitualGlyph g) => g.X <= original.X && g.Y <= original.Y && g.X + g.Width >= original.X + original.Width && g.Y + g.Height >= original.Y + original.Height && (!original.Character.HasValue || original.Character == g.Character))))
				{
					return candidate;
				}
			}
			return ritualFrame;
		}
	}

	private RitualFrame AnalyzeCore(HealthPixels pixels, bool recoverInk)
	{
		bool[] array = new bool[pixels.Width * pixels.Height];
		for (int i = 0; i < array.Length; i++)
		{
			int b = pixels.Bgra[i * 4];
			int g = pixels.Bgra[i * 4 + 1];
			int r = pixels.Bgra[i * 4 + 2];
			array[i] = IsInk(r, g, b, recoverInk);
		}
		bool[] array2 = new bool[array.Length];
		List<RitualGlyph> glyphs = new List<RitualGlyph>();
		for (int j = 0; j < array.Length; j++)
		{
			if (!array[j] || array2[j])
			{
				continue;
			}
			Stack<int> stack = new Stack<int>();
			stack.Push(j);
			array2[j] = true;
			int num = j % pixels.Width;
			int num2 = num;
			int num3 = j / pixels.Width;
			int num4 = num3;
			int num5 = 0;
			int num6 = 0;
			while (stack.Count > 0)
			{
				int num7 = stack.Pop();
				int num8 = num7 % pixels.Width;
				int num9 = num7 / pixels.Width;
				num = Math.Min(num, num8);
				num2 = Math.Max(num2, num8);
				num3 = Math.Min(num3, num9);
				num4 = Math.Max(num4, num9);
				num5++;
				int num10 = num7 * 4;
				if (IsCoreInk(pixels.Bgra[num10 + 2], pixels.Bgra[num10 + 1], pixels.Bgra[num10], recoverInk))
				{
					num6++;
				}
				for (int k = -2; k <= 2; k++)
				{
					for (int l = -2; l <= 2; l++)
					{
						int num11 = num8 + l;
						int num12 = num9 + k;
						if (num11 >= 0 && num12 >= 0 && num11 < pixels.Width && num12 < pixels.Height)
						{
							int num13 = num12 * pixels.Width + num11;
							if (array[num13] && !array2[num13])
							{
								array2[num13] = true;
								stack.Push(num13);
							}
						}
					}
				}
			}
			int num14 = num2 - num + 1;
			int num15 = num4 - num3 + 1;
			if (num6 < 5 || num5 < 5 || num15 < 5)
			{
				continue;
			}
			char? character = null;
			float confidence = 0f;
			if (num6 >= 5 && num15 >= 8 && num14 >= 2 && (double)num14 <= (double)num15 * 1.6 && (double)num15 <= (double)pixels.Height * 0.9 && num > 0 && num3 > 0 && num2 < pixels.Width - 1 && num4 < pixels.Height - 1)
			{
				try
				{
					(char, double, double) tuple = MatchShape(pixels, num, num3, num14, num15, recoverInk);
					if (tuple.Item2 <= 0.135 && tuple.Item3 >= 0.025)
					{
						character = tuple.Item1;
						confidence = (float)((1.0 - tuple.Item2) * 100.0);
					}
					else if (tuple.Item2 <= 0.14 && tuple.Item3 >= 0.015)
					{
						EnsureEngine();
						(char?, float) tuple2 = Recognize(pixels, num, num3, num14, num15, recoverInk);
						(char?, float) tuple3 = Recognize(pixels, Math.Max(0, num - 2), Math.Max(0, num3 - 2), Math.Min(pixels.Width, num + num14 + 2) - Math.Max(0, num - 2), Math.Min(pixels.Height, num3 + num15 + 2) - Math.Max(0, num3 - 2), recoverInk);
						confidence = Math.Min(tuple2.Item2, tuple3.Item2);
						if (tuple2.Item1 == tuple3.Item1 && tuple2.Item1 == tuple.Item1)
						{
							(character, _) = tuple2;
						}
					}
				}
				catch
				{
					return new RitualFrame(Array.Empty<RitualGlyph>(), Reliable: false);
				}
			}
			glyphs.Add(new RitualGlyph(character, num, num3, num14, num15, confidence));
		}
		for (int m = 0; m < glyphs.Count; m++)
		{
			for (int n = m + 1; n < glyphs.Count; n++)
			{
				RitualGlyph ritualGlyph = glyphs[m];
				RitualGlyph ritualGlyph2 = glyphs[n];
				if (ritualGlyph.X > ritualGlyph2.X)
				{
					RitualGlyph ritualGlyph3 = ritualGlyph2;
					ritualGlyph2 = ritualGlyph;
					ritualGlyph = ritualGlyph3;
				}
				int num16 = ritualGlyph2.X - ritualGlyph.X - ritualGlyph.Width;
				int num17 = Math.Max(ritualGlyph.Height, ritualGlyph2.Height);
				if (num16 < 0 || (double)num16 > Math.Max(2.0, (double)Math.Min(ritualGlyph.Height, ritualGlyph2.Height) * 0.2) || Math.Abs(ritualGlyph.Y - ritualGlyph2.Y) > 3 || Math.Abs(ritualGlyph.Height - ritualGlyph2.Height) > 3 || (double)Math.Min(ritualGlyph.Width, ritualGlyph2.Width) > (double)num17 * 0.55 || (double)Math.Max(ritualGlyph.Width, ritualGlyph2.Width) < (double)num17 * 0.65 || (double)(ritualGlyph2.X + ritualGlyph2.Width - ritualGlyph.X) > (double)num17 * 1.6)
				{
					continue;
				}
				int num18 = Math.Min(ritualGlyph.Y, ritualGlyph2.Y);
				int num19 = ritualGlyph2.X + ritualGlyph2.Width - ritualGlyph.X;
				num17 = Math.Max(ritualGlyph.Y + ritualGlyph.Height, ritualGlyph2.Y + ritualGlyph2.Height) - num18;
				char? character2 = null;
				float confidence2 = 0f;
				if (num17 >= 8 && num19 >= 2 && (double)num17 <= (double)pixels.Height * 0.9 && ritualGlyph.X > 0 && num18 > 0 && ritualGlyph.X + num19 < pixels.Width && num18 + num17 < pixels.Height)
				{
					(char, double, double) tuple5 = MatchShape(pixels, ritualGlyph.X, num18, num19, num17, recoverInk);
					if (tuple5.Item2 <= 0.135 && tuple5.Item3 >= 0.025)
					{
						character2 = tuple5.Item1;
						confidence2 = (float)((1.0 - tuple5.Item2) * 100.0);
					}
				}
				glyphs[m] = new RitualGlyph(character2, ritualGlyph.X, num18, num19, num17, confidence2);
				glyphs.RemoveAt(n--);
			}
		}
		bool reliable = glyphs.Count <= 32 && !glyphs.Any((RitualGlyph a) => glyphs.Any((RitualGlyph ritualGlyph4) => a != ritualGlyph4 && a.X < ritualGlyph4.X + ritualGlyph4.Width && ritualGlyph4.X < a.X + a.Width && a.Y < ritualGlyph4.Y + ritualGlyph4.Height && ritualGlyph4.Y < a.Y + a.Height));
		return new RitualFrame((from ritualGlyph4 in glyphs
			orderby ritualGlyph4.X, ritualGlyph4.Y
			select ritualGlyph4).ToArray(), reliable);
	}

	private static bool IsInk(int r, int g, int b, bool recoverInk = false)
	{
		int num = Math.Max(r, Math.Max(g, b));
		int num2 = Math.Min(r, Math.Min(g, b));
		if (!recoverInk)
		{
			if (num2 < 130 || num - num2 > 35)
			{
				if (num >= 160)
				{
					return num - num2 > 35;
				}
				return false;
			}
			return true;
		}
		if (num2 < 100 || num - num2 > 35)
		{
			if (num >= 70)
			{
				return num - num2 > 20;
			}
			return false;
		}
		return true;
	}

	private static bool IsCoreInk(int r, int g, int b, bool recoverInk = false)
	{
		int num = Math.Max(r, Math.Max(g, b));
		int num2 = Math.Min(r, Math.Min(g, b));
		if (num < 195)
		{
			if (num >= 160)
			{
				return num - num2 > 35;
			}
			return false;
		}
		return true;
	}

	private (char Character, double Score, double Margin) MatchShape(HealthPixels pixels, int left, int top, int width, int height, bool recoverInk)
	{
		byte[] array = new byte[384];
		for (int i = 0; i < 24; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				double num = ((double)j + 0.5) * (double)width / 16.0 - 0.5;
				double num2 = ((double)i + 0.5) * (double)height / 24.0 - 0.5;
				int num3 = (int)Math.Floor(num);
				int num4 = (int)Math.Floor(num2);
				double num5 = num - (double)num3;
				double num6 = num2 - (double)num4;
				array[i * 16 + j] = (byte)((Sample(num3, num4) * (1.0 - num5) + Sample(num3 + 1, num4) * num5) * (1.0 - num6) + (Sample(num3, num4 + 1) * (1.0 - num5) + Sample(num3 + 1, num4 + 1) * num5) * num6);
			}
		}
		string key = width + ":" + height + ":" + Convert.ToHexString(array);
		if (_shapes.TryGetValue(key, out (char, double, double) value))
		{
			return value;
		}
		Dictionary<char, double> dictionary = new Dictionary<char, double>();
		(char, double, byte[])[] value2 = Templates.Value;
		for (int k = 0; k < value2.Length; k++)
		{
			(char, double, byte[]) tuple = value2[k];
			double num7 = 0.0;
			for (int l = 0; l < array.Length; l++)
			{
				double num8 = (double)(array[l] - tuple.Item3[l]) / 255.0;
				num7 += num8 * num8;
			}
			num7 = num7 / (double)array.Length + Math.Abs(Math.Log((double)width / (double)height / tuple.Item2)) * 0.15;
			if (!dictionary.TryGetValue(tuple.Item1, out var value3) || num7 < value3)
			{
				dictionary[tuple.Item1] = num7;
			}
		}
		KeyValuePair<char, double>[] array2 = dictionary.OrderBy((KeyValuePair<char, double> p) => p.Value).Take(2).ToArray();
		(char, double, double) tuple2 = (array2[0].Key, array2[0].Value, array2[1].Value - array2[0].Value);
		if (_shapes.Count >= 512)
		{
			_shapes.Clear();
		}
		_shapes[key] = tuple2;
		return tuple2;
		double Sample(int x, int y)
		{
			x = Math.Clamp(x, 0, width - 1);
			y = Math.Clamp(y, 0, height - 1);
			int num9 = ((top + y) * pixels.Width + left + x) * 4;
			int b = pixels.Bgra[num9];
			int g = pixels.Bgra[num9 + 1];
			return IsInk(pixels.Bgra[num9 + 2], g, b, recoverInk) ? 255 : 0;
		}
	}

	private (char? Character, float Confidence) Recognize(HealthPixels pixels, int left, int top, int w, int h, bool recoverInk)
	{
		using Pix image = Pix.LoadFromMemory(Bitmap(pixels, left, top, w, h, recoverInk));
		using Page page = _engine.Process(image, PageSegMode.SingleLine);
		using ResultIterator resultIterator = page.GetIterator();
		resultIterator.Begin();
		List<(char, float)> list = new List<(char, float)>();
		do
		{
			string text = resultIterator.GetText(PageIteratorLevel.Symbol)?.Trim();
			if (text != null && text.Length == 1 && char.IsAsciiLetterOrDigit(text[0]) && !char.IsLower(text[0]))
			{
				list.Add((text[0], resultIterator.GetConfidence(PageIteratorLevel.Symbol)));
			}
		}
		while (resultIterator.Next(PageIteratorLevel.Symbol));
		IGrouping<char, (char, float)>[] array = list.GroupBy(((char Character, float Confidence) v) => v.Character).OrderByDescending((IGrouping<char, (char Character, float Confidence)> g) => g.Count()).ToArray();
		if (array.Length == 0)
		{
			return (Character: null, Confidence: 0f);
		}
		IGrouping<char, (char, float)> grouping = array[0];
		float num = grouping.Average(((char Character, float Confidence) v) => v.Confidence);
		return (Character: (grouping.Count() >= 4 && num >= 85f) ? new char?(grouping.Key) : ((char?)null), Confidence: num);
	}

	private void EnsureEngine()
	{
		if (_engine == null)
		{
			string path = (TesseractEnviornment.CustomSearchPath = HealthOcrResources.EnsureAvailable());
			_engine = new TesseractEngine(Path.Combine(path, "tessdata"), "eng", EngineMode.LstmOnly);
			_engine.SetVariable("tessedit_char_whitelist", "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789");
		}
	}

	private static byte[] Bitmap(HealthPixels pixels, int left, int top, int w, int h, bool recoverInk)
	{
		int num = (w * 4 + 16) * 5 + 16;
		int num2 = h * 4 + 32;
		int num3 = (num * 3 + 3) & -4;
		using MemoryStream memoryStream = new MemoryStream();
		using BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write((ushort)19778);
		binaryWriter.Write(54 + num3 * num2);
		binaryWriter.Write(0);
		binaryWriter.Write(54);
		binaryWriter.Write(40);
		binaryWriter.Write(num);
		binaryWriter.Write(num2);
		binaryWriter.Write((ushort)1);
		binaryWriter.Write((ushort)24);
		binaryWriter.Write(0);
		binaryWriter.Write(num3 * num2);
		for (int i = 0; i < 4; i++)
		{
			binaryWriter.Write(0);
		}
		byte[] array = new byte[num3];
		for (int num4 = num2 - 1; num4 >= 0; num4--)
		{
			Array.Fill(array, byte.MaxValue);
			if (num4 >= 16 && num4 < num2 - 16)
			{
				for (int j = 16; j < num - 16; j++)
				{
					if ((j - 16) % (w * 4 + 16) < w * 4)
					{
						int num5 = ((top + (num4 - 16) / 4) * pixels.Width + left + (j - 16) % (w * 4 + 16) / 4) * 4;
						int b = pixels.Bgra[num5];
						int g = pixels.Bgra[num5 + 1];
						byte b2 = (byte)((!IsInk(pixels.Bgra[num5 + 2], g, b, recoverInk)) ? byte.MaxValue : 0);
						array[j * 3] = (array[j * 3 + 1] = (array[j * 3 + 2] = b2));
					}
				}
			}
			binaryWriter.Write(array);
		}
		return memoryStream.ToArray();
	}

	public void Dispose()
	{
		lock (_gate)
		{
			_disposed = true;
			_engine?.Dispose();
			_engine = null;
		}
	}
}
