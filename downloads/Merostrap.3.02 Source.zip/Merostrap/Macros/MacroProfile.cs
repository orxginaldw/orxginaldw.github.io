using System.Collections.Generic;

namespace Merostrap.Macros;

public sealed class MacroProfile
{
	public string Name { get; set; } = "";

	public Dictionary<string, MacroEntry> Entries { get; set; } = MacroCatalog.CreateEntries();
}
