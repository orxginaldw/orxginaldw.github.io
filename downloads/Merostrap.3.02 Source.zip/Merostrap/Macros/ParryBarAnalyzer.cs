using System;
using Merostrap.Macros.Health;

namespace Merostrap.Macros;

public static class ParryBarAnalyzer
{
	public static ParryTrack? Calibrate(HealthPixels pixels)
	{
		if (!Valid(pixels))
		{
			return null;
		}
		(int, int, int) tuple = (0, 0, 0);
		int row = 0;
		for (int i = 0; i < pixels.Height; i++)
		{
			(int, int, int) tuple2 = Span(pixels, i, 0, pixels.Width - 1);
			if (tuple2.Item3 > tuple.Item3 && Gradient(pixels, i, tuple2.Item1, tuple2.Item2))
			{
				tuple = tuple2;
				row = i;
			}
		}
		if ((double)(tuple.Item2 - tuple.Item1) < (double)pixels.Width * 0.9 || (double)tuple.Item3 < (double)(tuple.Item2 - tuple.Item1) * 0.78)
		{
			return null;
		}
		return new ParryTrack(tuple.Item1, tuple.Item2, row, pixels.Width, pixels.Height);
	}

	public static double? Read(HealthPixels pixels, ParryTrack track)
	{
		if (!Valid(pixels) || pixels.Width != track.Width || pixels.Height != track.Height || track.Left < 0 || track.Right >= pixels.Width || track.Right - track.Left < 25 || track.Row < 0 || track.Row >= pixels.Height)
		{
			return null;
		}
		double? result = null;
		for (int i = Math.Max(0, track.Row - 1); i <= Math.Min(pixels.Height - 1, track.Row + 1); i++)
		{
			(int, int, int) tuple = Span(pixels, i, track.Left, track.Right);
			if ((!InsideSpectralLabel(tuple.Item2, (double)(track.Left + track.Right) / 2.0, track.Right - track.Left + 1) || !HasSpectralGap(pixels, i, track.Left, track.Right)) && tuple.Item1 <= track.Left + 3 && tuple.Item2 - tuple.Item1 >= 6 && !((double)tuple.Item3 < Math.Max(1.0, (double)(tuple.Item2 - tuple.Item1 + 1) - (double)(track.Right - track.Left + 1) * 0.2) * 0.8) && Gradient(pixels, i, tuple.Item1, tuple.Item2))
			{
				double value = 100.0 * (double)(tuple.Item2 - track.Left + 1) / (double)(track.Right - track.Left + 1);
				result = Math.Max(result.GetValueOrDefault(), Math.Clamp(value, 0.0, 100.0));
			}
		}
		return result;
	}

	private static bool Valid(HealthPixels pixels)
	{
		int width = pixels.Width;
		if (width >= 30 && width <= 4096)
		{
			width = pixels.Height;
			if (width >= 4 && width <= 300)
			{
				return pixels.Bgra.Length == (long)pixels.Width * (long)pixels.Height * 4;
			}
		}
		return false;
	}

	public static bool IsSpectralCovered(HealthPixels pixels, ParryTrack track)
	{
		if (!Valid(pixels) || pixels.Width != track.Width || pixels.Height != track.Height || track.Left < 0 || track.Right >= pixels.Width || track.Row < 0 || track.Row >= pixels.Height)
		{
			return false;
		}
		for (int i = Math.Max(0, track.Row - 1); i <= Math.Min(pixels.Height - 1, track.Row + 1); i++)
		{
			(int, int, int) tuple = Span(pixels, i, track.Left, track.Right);
			if (tuple.Item1 >= track.Left && tuple.Item1 <= track.Left + 3 && tuple.Item2 - tuple.Item1 >= 6 && Color(pixels, tuple.Item1 + Math.Max(1, (tuple.Item2 - tuple.Item1) / 12), i) == 1 && HasSpectralGap(pixels, i, track.Left, track.Right))
			{
				return true;
			}
		}
		return false;
	}

	private static (int Left, int Right, int Count) Span(HealthPixels p, int y, int left, int right)
	{
		int num = -1;
		int item = -1;
		int num2 = 0;
		int num3 = 0;
		for (int i = left; i <= right; i++)
		{
			if (Color(p, i, y) != 0)
			{
				if (num < 0)
				{
					num = i;
				}
				item = i;
				num2++;
				num3 = 0;
			}
			else if (num >= 0)
			{
				num3++;
				if (num3 > Math.Max(3, p.Width / 100) && !InsideSpectralLabel(i, (double)(left + right) / 2.0, right - left + 1))
				{
					break;
				}
			}
		}
		return (Left: num, Right: item, Count: num2);
	}

	internal static bool InsideSpectralLabel(int x, double centre, double width)
	{
		if (width >= 30.0)
		{
			return Math.Abs((double)x - centre) <= width * 0.1;
		}
		return false;
	}

	private static bool HasSpectralGap(HealthPixels p, int y, int left, int right)
	{
		int num = 0;
		int num2 = 0;
		int num3 = 0;
		for (int i = left; i <= right; i++)
		{
			if (InsideSpectralLabel(i, (double)(left + right) / 2.0, right - left + 1))
			{
				num = ((Color(p, i, y) == 0) ? (num + 1) : 0);
				num2 = Math.Max(num2, num);
				int num4 = (y * p.Width + i) * 4;
				int val = p.Bgra[num4];
				int val2 = p.Bgra[num4 + 1];
				int val3 = p.Bgra[num4 + 2];
				if (Math.Min(val3, Math.Min(val2, val)) >= 100 && Math.Max(val3, Math.Max(val2, val)) - Math.Min(val3, Math.Min(val2, val)) <= 20)
				{
					num3++;
				}
			}
		}
		if (num2 > Math.Max(3, p.Width / 100))
		{
			return num3 >= 2;
		}
		return false;
	}

	private static bool Gradient(HealthPixels p, int y, int left, int right)
	{
		if (left < 0 || right - left < 6)
		{
			return false;
		}
		int num = Math.Max(1, (right - left) / 12);
		if (Color(p, left + num, y) == 1)
		{
			return Color(p, right - num, y) == 3;
		}
		return false;
	}

	private static int Color(HealthPixels p, int x, int y)
	{
		int num = (y * p.Width + x) * 4;
		int num2 = p.Bgra[num];
		int num3 = p.Bgra[num + 1];
		int num4 = p.Bgra[num + 2];
		if (num4 > num3 + 12 && num2 > num3 + 12)
		{
			return 1;
		}
		if (num3 > num4 + 12 && num3 > num2 + 8)
		{
			return 3;
		}
		if (num2 > num4 + 12 && num2 >= num3 - 12)
		{
			return 2;
		}
		return 0;
	}
}
