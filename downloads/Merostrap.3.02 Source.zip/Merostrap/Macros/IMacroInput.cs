using System;
using System.Collections.Generic;

namespace Merostrap.Macros;

public interface IMacroInput : IDisposable
{
	bool IsAvailable { get; }

	bool IsForegroundRoblox { get; }

	Exception? Failure => null;

	string PrimaryButton { get; }

	(int Width, int Height) ScreenSize { get; }

	event Action<MacroInputEvent>? Input;

	void Start(Func<MacroInputEvent, bool> suppress);

	IReadOnlyCollection<string> SnapshotRitualKeysDown()
	{
		return Array.Empty<string>();
	}

	void Stop();

	void Key(string key, bool down);

	void Move(int x, int y);

	void Scroll(int delta)
	{
		throw new NotSupportedException("Mouse wheel input is unavailable.");
	}

	void Character(char character);
}
