using System;
using System.Globalization;
using System.Linq;

namespace Merostrap.Macros;

internal static class MacroKeys
{
	public static string Normalize(string key)
	{
		string text = key.Trim().ToLowerInvariant();
		switch (text)
		{
		case "left ctrl":
		case "right ctrl":
		case "lctrl":
		case "rctrl":
		case "control":
			return "ctrl";
		case "left shift":
		case "right shift":
			return "shift";
		case "right alt":
		case "left alt":
			return "alt";
		case "escape":
			return "esc";
		case "return":
			return "enter";
		case "spacebar":
			return "space";
		case "left mouse":
		case "left click":
			return "mouse1";
		case "right click":
		case "right mouse":
			return "mouse2";
		default:
			return text;
		}
	}

	public static bool TryVirtualKey(string key, out ushort code)
	{
		key = Normalize(key);
		if (key.Length == 1 && char.IsAsciiLetterOrDigit(key[0]))
		{
			code = char.ToUpperInvariant(key[0]);
			return true;
		}
		if (key.StartsWith('f') && int.TryParse(key.AsSpan(1), out var result) && result >= 1 && result <= 24)
		{
			code = (ushort)(111 + result);
			return true;
		}
		if (key.Length == 7 && key.StartsWith("numpad", StringComparison.Ordinal))
		{
			char c = key[6];
			if (c >= '0' && c <= '9')
			{
				code = (ushort)(96 + key[6] - 48);
				return true;
			}
		}
		code = key switch
		{
			"mouse1" => (ushort)1, 
			"mouse2" => (ushort)2, 
			"mouse3" => (ushort)4, 
			"mouse4" => (ushort)5, 
			"mouse5" => (ushort)6, 
			"numpad multiply" => (ushort)106, 
			"numpad add" => (ushort)107, 
			"numpad subtract" => (ushort)109, 
			"numpad decimal" => (ushort)110, 
			"numpad divide" => (ushort)111, 
			"numpad enter" => (ushort)13, 
			"backspace" => (ushort)8, 
			"tab" => (ushort)9, 
			"enter" => (ushort)13, 
			"shift" => (ushort)16, 
			"ctrl" => (ushort)17, 
			"alt" => (ushort)18, 
			"caps lock" => (ushort)20, 
			"esc" => (ushort)27, 
			"space" => (ushort)32, 
			"page up" => (ushort)33, 
			"page down" => (ushort)34, 
			"end" => (ushort)35, 
			"home" => (ushort)36, 
			"left" => (ushort)37, 
			"up" => (ushort)38, 
			"right" => (ushort)39, 
			"down" => (ushort)40, 
			"insert" => (ushort)45, 
			"delete" => (ushort)46, 
			";" => (ushort)186, 
			"=" => (ushort)187, 
			"," => (ushort)188, 
			"-" => (ushort)189, 
			"." => (ushort)190, 
			"/" => (ushort)191, 
			"`" => (ushort)192, 
			"[" => (ushort)219, 
			"\\" => (ushort)220, 
			"]" => (ushort)221, 
			"'" => (ushort)222, 
			_ => (ushort)0, 
		};
		return code != 0;
	}

	public static string FromVirtualKey(uint code)
	{
		switch (code)
		{
		case 65u:
		case 66u:
		case 67u:
		case 68u:
		case 69u:
		case 70u:
		case 71u:
		case 72u:
		case 73u:
		case 74u:
		case 75u:
		case 76u:
		case 77u:
		case 78u:
		case 79u:
		case 80u:
		case 81u:
		case 82u:
		case 83u:
		case 84u:
		case 85u:
		case 86u:
		case 87u:
		case 88u:
		case 89u:
		case 90u:
			return ((char)(code + 32)).ToString();
		case 48u:
		case 49u:
		case 50u:
		case 51u:
		case 52u:
		case 53u:
		case 54u:
		case 55u:
		case 56u:
		case 57u:
			return ((char)code).ToString();
		case 112u:
		case 113u:
		case 114u:
		case 115u:
		case 116u:
		case 117u:
		case 118u:
		case 119u:
		case 120u:
		case 121u:
		case 122u:
		case 123u:
		case 124u:
		case 125u:
		case 126u:
		case 127u:
		case 128u:
		case 129u:
		case 130u:
		case 131u:
		case 132u:
		case 133u:
		case 134u:
		case 135u:
			return "f" + (code - 111).ToString(CultureInfo.InvariantCulture);
		case 96u:
		case 97u:
		case 98u:
		case 99u:
		case 100u:
		case 101u:
		case 102u:
		case 103u:
		case 104u:
		case 105u:
			return "numpad" + (code - 96).ToString(CultureInfo.InvariantCulture);
		case 106u:
			return "numpad multiply";
		case 107u:
			return "numpad add";
		case 109u:
			return "numpad subtract";
		case 110u:
			return "numpad decimal";
		case 111u:
			return "numpad divide";
		case 8u:
			return "backspace";
		case 9u:
			return "tab";
		case 13u:
			return "enter";
		case 16u:
		case 160u:
		case 161u:
			return "shift";
		case 17u:
		case 162u:
		case 163u:
			return "ctrl";
		case 18u:
		case 164u:
		case 165u:
			return "alt";
		case 20u:
			return "caps lock";
		case 27u:
			return "esc";
		case 32u:
			return "space";
		case 33u:
			return "page up";
		case 34u:
			return "page down";
		case 35u:
			return "end";
		case 36u:
			return "home";
		case 37u:
			return "left";
		case 38u:
			return "up";
		case 39u:
			return "right";
		case 40u:
			return "down";
		case 45u:
			return "insert";
		case 46u:
			return "delete";
		case 186u:
			return ";";
		case 187u:
			return "=";
		case 188u:
			return ",";
		case 189u:
			return "-";
		case 190u:
			return ".";
		case 191u:
			return "/";
		case 192u:
			return "`";
		case 219u:
			return "[";
		case 220u:
			return "\\";
		case 221u:
			return "]";
		case 222u:
			return "'";
		default:
			return "";
		}
	}

	public static string FromKeyboard(uint code, uint scan, bool extended)
	{
		if (extended && code == 13)
		{
			return "numpad enter";
		}
		if (!extended)
		{
			string text = scan switch
			{
				82u => "numpad0", 
				79u => "numpad1", 
				80u => "numpad2", 
				81u => "numpad3", 
				75u => "numpad4", 
				76u => "numpad5", 
				77u => "numpad6", 
				71u => "numpad7", 
				72u => "numpad8", 
				73u => "numpad9", 
				83u => "numpad decimal", 
				_ => "", 
			};
			if (text.Length > 0)
			{
				return text;
			}
		}
		return FromVirtualKey(code);
	}

	public static string[] Parse(string value, string field)
	{
		if (value.Trim() == ",")
		{
			return new string[1] { "," };
		}
		string[] array = value.Split(new char[2] { ',', '\n' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).Select(Normalize).Distinct(StringComparer.Ordinal)
			.ToArray();
		if (array.Length == 0 || array.Any((string k) => !TryVirtualKey(k, out var _)))
		{
			throw new ArgumentException(field + " must contain valid keys separated by commas.");
		}
		return array;
	}
}
