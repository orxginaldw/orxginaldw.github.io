using System;
using System.IO;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Avalonia.Controls;
using Avalonia.Threading;
using CommunityToolkit.Mvvm.ComponentModel;
using Merostrap.Macros.Health;
using Merostrap.UI.Elements.Macros;

namespace Merostrap.Macros;

public sealed class HealthAutomation : ObservableObject, IDisposable
{
	public sealed class Settings
	{
		public bool Enabled { get; set; }

		public bool AutoDeafen { get; set; }

		public int DeafenPercent { get; set; } = 50;

		public string DeafenKey { get; set; } = "";

		public HealthRegion? Region { get; set; }
	}

	private readonly string _path;

	private readonly Action _changed;

	private readonly Action _resumeAfterEdit;

	private readonly Func<bool> _resumeRequested;

	private readonly HealthMonitor _monitor;

	private readonly HealthTextReader? _textReader;

	private readonly IMacroInput _input;

	private readonly IDiscordDeafenState? _discord;

	private readonly Func<DetectedHudBars?> _recover;

	private long _lastGoodSample;

	private long _lastRecovery;

	private bool _recovering;

	private DetectedHudBars? _recoveryCandidate;

	private CancellationTokenSource? _confirmation;

	private string _deafenStatus = "Unconfirmed";

	private readonly HealthThresholdLatch _threshold = new HealthThresholdLatch();

	private Settings _settings = new Settings();

	private bool _armed;

	private bool _preview;

	private bool _fired;

	private bool _disposed;

	private int _generation;

	private int _sampleSequence;

	private readonly object _inputGate = new object();

	private string? _pendingKey;

	private object? _pressOwner;

	private bool _storageBlocked;

	private string _status = "Select health bar";

	private double? _percent;

	public bool ShowDeafenStatus
	{
		get
		{
			if (_discord != null && Enabled)
			{
				return AutoDeafen;
			}
			return false;
		}
	}

	public string DeafenStatus
	{
		get
		{
			return _deafenStatus;
		}
		private set
		{
			SetProperty(ref _deafenStatus, value, "DeafenStatus");
		}
	}

	public string? Fault { get; private set; }

	public bool Enabled
	{
		get
		{
			return _settings.Enabled;
		}
		set
		{
			if (value != Enabled)
			{
				_settings.Enabled = value;
				Update();
				OnPropertyChanged("Enabled");
			}
		}
	}

	public bool AutoDeafen
	{
		get
		{
			return _settings.AutoDeafen;
		}
		set
		{
			if (value != AutoDeafen)
			{
				_settings.AutoDeafen = value;
				Update();
				OnPropertyChanged("AutoDeafen");
			}
		}
	}

	public string DeafenKey
	{
		get
		{
			return _settings.DeafenKey;
		}
		set
		{
			if (!(value == DeafenKey))
			{
				_settings.DeafenKey = value;
				Update();
				OnPropertyChanged("DeafenKey");
			}
		}
	}

	public decimal? DeafenPercent
	{
		get
		{
			int deafenPercent = _settings.DeafenPercent;
			return (deafenPercent >= 1 && deafenPercent <= 100) ? _settings.DeafenPercent : 50;
		}
		set
		{
			if (!value.HasValue)
			{
				return;
			}
			decimal? num = value;
			decimal num2 = 1;
			if ((num.GetValueOrDefault() < num2) & num.HasValue)
			{
				return;
			}
			num = value;
			num2 = 100;
			if (!((num.GetValueOrDefault() > num2) & num.HasValue))
			{
				num = value;
				num2 = decimal.Truncate(value.Value);
				if (((num.GetValueOrDefault() == num2) & num.HasValue) && !(value == DeafenPercent))
				{
					_settings.DeafenPercent = (int)value.Value;
					Update();
					OnPropertyChanged("DeafenPercent");
				}
			}
		}
	}

	public string RegionLabel
	{
		get
		{
			if ((object)_settings.Region != null)
			{
				return "Reselect bar";
			}
			return "Select bar";
		}
	}

	public string Reading
	{
		get
		{
			double? percent = _percent;
			if (percent.HasValue)
			{
				double valueOrDefault = percent.GetValueOrDefault();
				return $"{valueOrDefault:0}%";
			}
			return "N/A";
		}
	}

	public bool HasReading => _percent.HasValue;

	public string Status
	{
		get
		{
			return _status;
		}
		private set
		{
			SetProperty(ref _status, value, "Status");
		}
	}

	public bool IsArmed => _armed;

	public bool IsReady
	{
		get
		{
			if (Enabled && (object)_settings.Region != null)
			{
				if (AutoDeafen)
				{
					return ValidKey;
				}
				return true;
			}
			return false;
		}
	}

	private bool ValidKey
	{
		get
		{
			if (!string.IsNullOrWhiteSpace(DeafenKey) && MacroKeys.TryVirtualKey(DeafenKey, out var _) && MacroKeys.Normalize(DeafenKey) != "esc")
			{
				return !DeafenKey.StartsWith("mouse", StringComparison.OrdinalIgnoreCase);
			}
			return false;
		}
	}

	public event Action<DetectedHudBars>? Recovered;

	public HealthAutomation(string path, Action changed, HealthMonitor? monitor = null, IMacroInput? input = null, IDiscordDeafenState? discord = null, Action? resumeAfterEdit = null, Func<bool>? resumeRequested = null, Func<DetectedHudBars?>? recover = null)
	{
		_discord = discord;
		_recover = recover ?? ((monitor == null) ? new Func<DetectedHudBars>(HudBarCapture.Detect) : ((Func<DetectedHudBars>)(() => (DetectedHudBars?)null)));
		_deafenStatus = ((discord == null) ? "Paused" : "Unconfirmed");
		_resumeAfterEdit = resumeAfterEdit ?? ((Action)(() =>
		{
			SetArmed(armed: true);
		}));
		_resumeRequested = resumeRequested ?? ((Func<bool>)(() => _armed));
		_path = path;
		_changed = changed;
		_textReader = ((monitor == null) ? new HealthTextReader() : null);
		HealthMonitor healthMonitor = monitor;
		if (healthMonitor == null)
		{
			Func<HealthPixels, HealthSample> analyze = _textReader.Analyze;
			healthMonitor = new HealthMonitor(null, null, null, analyze);
		}
		_monitor = healthMonitor;
		_input = input ?? new WindowsMacroInput();
		try
		{
			if (File.Exists(path))
			{
				_settings = JsonSerializer.Deserialize<Settings>(File.ReadAllText(path)) ?? new Settings();
			}
		}
		catch (Exception ex) when ((ex is IOException || ex is JsonException || ex is UnauthorizedAccessException) ? true : false)
		{
			_storageBlocked = true;
			_status = "Could not load health settings; existing file preserved";
		}
		_monitor.Updated += (HealthSample sample) =>
		{
			int generation = _generation;
			int sequence = Interlocked.Increment(ref _sampleSequence);
			Dispatcher.UIThread.Post(() =>
			{
				if (!_disposed && generation == _generation && sequence == _sampleSequence)
				{
					Receive(sample);
				}
			});
		};
	}

	public void SetPreview(bool preview)
	{
		_preview = preview;
		RefreshMonitor();
	}

	public void SetArmed(bool armed)
	{
		StopInputs();
		_threshold.Reset();
		_fired = false;
		lock (_inputGate)
		{
			_armed = armed && IsReady && _pendingKey == null;
		}
		if (armed && !_armed && Fault == null)
		{
			Status = (((object)_settings.Region == null) ? "Select health bar" : "Set a Discord deafen key");
		}
		RefreshMonitor();
		OnPropertyChanged("IsArmed");
		if (_discord == null)
		{
			DeafenStatus = (_armed ? "Ready" : "Paused");
		}
	}

	private void RefreshMonitor()
	{
		_recoveryCandidate = null;
		_lastGoodSample = Environment.TickCount64;
		_monitor.Stop();
		_generation++;
		_percent = null;
		OnPropertyChanged("Reading");
		OnPropertyChanged("HasReading");
		if (Enabled && (_armed || _preview) && (object)_settings.Region != null)
		{
			try
			{
				_monitor.Start(_settings.Region);
				Status = Fault ?? "Waiting for Roblox";
			}
			catch (Exception ex)
			{
				_armed = false;
				Status = "Health capture: " + ex.Message;
			}
		}
	}

	private void Receive(HealthSample sample)
	{
		_percent = sample.Percent;
		OnPropertyChanged("Reading");
		OnPropertyChanged("HasReading");
		if (Fault != null)
		{
			Status = Fault;
			return;
		}
		Status = sample.Status;
		if (sample.Percent.HasValue)
		{
			_lastGoodSample = Environment.TickCount64;
			_recoveryCandidate = null;
		}
		else if (Enabled && (_armed || _preview) && _input.IsForegroundRoblox && !_recovering && Environment.TickCount64 - _lastGoodSample >= 1000 && Environment.TickCount64 - _lastRecovery >= 2000)
		{
			RecoverAsync();
		}
		if (!_armed || !AutoDeafen || !_input.IsForegroundRoblox)
		{
			return;
		}
		double? percent = sample.Percent;
		if (percent.HasValue)
		{
			double valueOrDefault = percent.GetValueOrDefault();
			if (double.IsFinite(valueOrDefault) && valueOrDefault <= 100.0 && valueOrDefault > (double)Math.Min(100, (int)DeafenPercent.Value + 5))
			{
				_fired = false;
				if (_confirmation == null && _discord == null)
				{
					DeafenStatus = "Ready";
				}
			}
		}
		if (_confirmation == null && _threshold.Observe(sample, (int)DeafenPercent.Value) == HealthThresholdTransition.Low && !_fired)
		{
			_fired = true;
			ConfirmDeafenAsync();
		}
	}

	private async Task ConfirmDeafenAsync()
	{
		CancellationTokenSource session = (_confirmation = new CancellationTokenSource());
		DeafenStatus = ((_discord == null) ? "Sending…" : "Checking…");
		try
		{
			bool? flag = ((_discord != null) ? (await _discord.ReadAsync(session.Token)) : ((bool?)null));
			bool? flag2 = flag;
			if (session.IsCancellationRequested || !_armed)
			{
				return;
			}
			if (flag2 == true)
			{
				DeafenStatus = "Already deafened";
			}
			else if (!(await SendDiscordShortcutAsync(session.Token)))
			{
				DeafenStatus = ((_discord == null) ? "Keybind failed" : "Unconfirmed");
				_fired = false;
			}
			else
			{
				if (session.IsCancellationRequested || !_armed)
				{
					return;
				}
				if (_discord == null)
				{
					DeafenStatus = "Keybind sent";
					return;
				}
				DeafenStatus = "Confirming…";
				for (int attempt = 0; attempt < 5; attempt++)
				{
					await Task.Delay(150, session.Token);
					bool? flag3 = await _discord.ReadAsync(session.Token);
					if (session.IsCancellationRequested || !_armed)
					{
						return;
					}
					if (flag3 == true)
					{
						DeafenStatus = "Deafen confirmed";
						return;
					}
				}
				DeafenStatus = "Unconfirmed";
			}
		}
		catch (OperationCanceledException)
		{
		}
		catch (Exception)
		{
			if (!session.IsCancellationRequested)
			{
				DeafenStatus = "Unconfirmed";
			}
		}
		finally
		{
			if (_confirmation == session)
			{
				_confirmation = null;
			}
			session.Dispose();
		}
	}

	private async Task<bool> SendDiscordShortcutAsync(CancellationToken cancellationToken)
	{
		object owner = new object();
		bool success = false;
		lock (_inputGate)
		{
			if (!_armed || !ValidKey || !_input.IsAvailable || !_input.IsForegroundRoblox || _pendingKey != null)
			{
				_threshold.Reset();
				return false;
			}
			string text = MacroKeys.Normalize(DeafenKey);
			try
			{
				_pressOwner = owner;
				_pendingKey = text;
				_input.Key(text, down: true);
				success = true;
			}
			catch (Exception ex)
			{
				Fault = "Discord shortcut: " + ex.Message;
				_armed = false;
			}
		}
		try
		{
			if (success)
			{
				await Task.Delay(100, cancellationToken);
			}
		}
		finally
		{
			lock (_inputGate)
			{
				if (_pressOwner == owner && !ReleaseKey())
				{
					success = false;
				}
				if (Fault != null)
				{
					Status = Fault;
					OnPropertyChanged("IsArmed");
				}
			}
		}
		return success;
	}

	private bool ReleaseKey()
	{
		if (_pendingKey == null)
		{
			return true;
		}
		try
		{
			_input.Key(_pendingKey, down: false);
			_pendingKey = null;
			_pressOwner = null;
			return true;
		}
		catch (Exception ex)
		{
			_armed = false;
			Fault = "Could not release Discord key: " + ex.Message;
			return false;
		}
	}

	public async Task SelectRegionAsync(Window owner, bool automatic = false)
	{
		bool resume = _resumeRequested();
		bool fired = _fired;
		_changed();
		SetArmed(armed: false);
		_monitor.Stop();
		owner.Hide();
		try
		{
			DetectedHudBars detectedHudBars = ((!automatic) ? null : (await HudAutoDetection.PickAsync(owner)));
			DetectedHudBars detected = detectedHudBars;
			HealthRegion healthRegion = ((!automatic) ? (await HealthRegionPicker.PickAsync(owner)) : detected?.Health);
			HealthRegion healthRegion2 = healthRegion;
			if ((object)healthRegion2 != null)
			{
				if ((object)detected != null && owner.DataContext is MacroWorkspace macroWorkspace)
				{
					macroWorkspace.ParryBar.ApplyDetectedBars(detected);
				}
				ApplyDetectedRegion(healthRegion2);
			}
		}
		catch (Exception ex)
		{
			Status = "Could not detect health bar: " + ex.Message;
		}
		finally
		{
			ResumeAfterEdit(resume, fired);
			owner.Show();
			owner.Activate();
		}
	}

	private async Task RecoverAsync()
	{
		_recovering = true;
		_lastRecovery = Environment.TickCount64;
		int generation = _generation;
		try
		{
			DetectedHudBars detectedHudBars = await Task.Run(_recover);
			if (_disposed || generation != _generation || !Enabled || (!_armed && !_preview) || !_input.IsForegroundRoblox)
			{
				return;
			}
			double? percent = _percent;
			if (!percent.HasValue)
			{
				if ((object)detectedHudBars == null || !HudBarCapture.SameLocation(detectedHudBars, _recoveryCandidate))
				{
					_recoveryCandidate = detectedHudBars;
					return;
				}
				Recovered?.Invoke(detectedHudBars);
				ApplyDetectedRegion(detectedHudBars.Health);
			}
		}
		catch (Exception)
		{
			_recoveryCandidate = null;
		}
		finally
		{
			_recovering = false;
		}
	}

	public void ApplyDetectedRegion(HealthRegion region)
	{
		region.Validate();
		_settings.Region = region;
		Update();
		OnPropertyChanged("RegionLabel");
	}

	private void Update()
	{
		bool resume = _resumeRequested();
		bool fired = _fired;
		_changed();
		SetArmed(armed: false);
		if (_storageBlocked)
		{
			Status = "Health settings unavailable; existing file preserved";
			return;
		}
		string text = _path + "." + Guid.NewGuid().ToString("N") + ".tmp";
		try
		{
			Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(_path)));
			File.WriteAllText(text, JsonSerializer.Serialize(_settings, new JsonSerializerOptions
			{
				WriteIndented = true
			}));
			File.Move(text, _path, overwrite: true);
		}
		catch (Exception ex)
		{
			Status = "Could not save health settings: " + ex.Message;
		}
		finally
		{
			try
			{
				if (File.Exists(text))
				{
					File.Delete(text);
				}
			}
			catch (IOException)
			{
			}
			catch (UnauthorizedAccessException)
			{
			}
		}
		OnPropertyChanged("IsReady");
		OnPropertyChanged("ShowDeafenStatus");
		ResumeAfterEdit(resume, fired);
	}

	private void ResumeAfterEdit(bool resume, bool fired)
	{
		if (resume && IsReady)
		{
			_resumeAfterEdit();
			_fired = fired;
			if (_discord == null)
			{
				HealthAutomation healthAutomation = this;
				string deafenStatus;
				if (_armed)
				{
					deafenStatus = (fired ? "Keybind sent" : "Ready");
				}
				else
				{
					deafenStatus = "Paused";
				}
				healthAutomation.DeafenStatus = deafenStatus;
			}
		}
	}

	internal void PreserveDeafenLatch(Action reconfigure)
	{
		bool fired = _fired;
		try
		{
			reconfigure();
		}
		finally
		{
			_fired |= fired;
			if (_discord == null && _armed && _fired)
			{
				DeafenStatus = "Keybind sent";
			}
		}
	}

	public void StopInputs()
	{
		try
		{
			_confirmation?.Cancel();
		}
		catch (ObjectDisposedException)
		{
		}
		DeafenStatus = ((_discord == null) ? "Paused" : "Unconfirmed");
		lock (_inputGate)
		{
			_armed = false;
			if (ReleaseKey())
			{
				Fault = null;
			}
		}
		_monitor.Stop();
		_generation++;
		if (Fault != null)
		{
			Status = Fault;
		}
	}

	public void Dispose()
	{
		if (!_disposed)
		{
			_disposed = true;
			StopInputs();
			_monitor.Dispose();
			_textReader?.Dispose();
			_input.Dispose();
		}
	}
}
