using Merostrap.Macros.Health;

namespace Merostrap.Macros;

public sealed record RitualPromptHighlight(HealthRegion Area, bool Sent);
