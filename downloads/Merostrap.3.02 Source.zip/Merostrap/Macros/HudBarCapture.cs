using System;
using Merostrap.Macros.Health;

namespace Merostrap.Macros;

public static class HudBarCapture
{
	public static bool SameLocation(DetectedHudBars bars, DetectedHudBars? previous)
	{
		if ((object)previous != null && Math.Abs((long)bars.Parry.X - (long)previous.Parry.X) <= 3 && Math.Abs((long)bars.Parry.Y - (long)previous.Parry.Y) <= 3 && Math.Abs((long)bars.Parry.Width - (long)previous.Parry.Width) <= 4)
		{
			return bars.Parry.Height == previous.Parry.Height;
		}
		return false;
	}

	public static DetectedHudBars? Detect()
	{
		HealthRegion healthRegion = WindowsHealthCapture.ForegroundRobloxArea();
		if ((object)healthRegion == null)
		{
			return null;
		}
		WindowsHealthCapture windowsHealthCapture = new WindowsHealthCapture();
		HealthPixels healthPixels = new HealthPixels(healthRegion.Width, healthRegion.Height, new byte[healthRegion.Width * healthRegion.Height * 4]);
		int num = (healthRegion.Height + 1) / 2;
		for (int i = 0; i < healthRegion.Height; i += num)
		{
			HealthPixels healthPixels2 = windowsHealthCapture.Capture(new HealthRegion(healthRegion.X, healthRegion.Y + i, healthRegion.Width, Math.Min(num, healthRegion.Height - i)));
			Array.Copy(healthPixels2.Bgra, 0, healthPixels.Bgra, i * healthRegion.Width * 4, healthPixels2.Bgra.Length);
		}
		if (!(WindowsHealthCapture.ForegroundRobloxArea() != healthRegion))
		{
			DetectedHudBars detectedHudBars = HudBarDetector.Detect(healthPixels);
			if ((object)detectedHudBars != null)
			{
				return detectedHudBars with
				{
					Health = detectedHudBars.Health with
					{
						X = detectedHudBars.Health.X + healthRegion.X,
						Y = detectedHudBars.Health.Y + healthRegion.Y
					},
					Parry = detectedHudBars.Parry with
					{
						X = detectedHudBars.Parry.X + healthRegion.X,
						Y = detectedHudBars.Parry.Y + healthRegion.Y
					}
				};
			}
		}
		return null;
	}
}
