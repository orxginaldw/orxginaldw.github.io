using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace Merostrap.Macros;

public sealed class MacroStore
{
	private static readonly JsonSerializerOptions JsonOptions = new JsonSerializerOptions
	{
		WriteIndented = true,
		PropertyNameCaseInsensitive = true
	};

	private readonly string _path;

	private readonly object _sync = new object();

	private string? _preservedCorruptJson;

	public string? LastLoadWarning { get; private set; }

	public string? RecoveryPath { get; private set; }

	public MacroStore(string path)
	{
		ArgumentException.ThrowIfNullOrWhiteSpace(path, "path");
		_path = Path.GetFullPath(path);
	}

	public MacroPreferences Load()
	{
		lock (_sync)
		{
			LastLoadWarning = null;
			RecoveryPath = null;
			if (!File.Exists(_path))
			{
				return new MacroPreferences();
			}
			string json = File.ReadAllText(_path);
			try
			{
				return Normalize(JsonSerializer.Deserialize<MacroPreferences>(json, JsonOptions) ?? throw new JsonException("The settings document is null."));
			}
			catch (JsonException)
			{
				PreserveCorruptDocument(json);
				return new MacroPreferences();
			}
		}
	}

	public void Save(MacroPreferences preferences)
	{
		ArgumentNullException.ThrowIfNull(preferences, "preferences");
		lock (_sync)
		{
			MacroPreferences preferences2 = JsonSerializer.Deserialize<MacroPreferences>(JsonSerializer.SerializeToUtf8Bytes(preferences, JsonOptions), JsonOptions);
			Directory.CreateDirectory(Path.GetDirectoryName(_path));
			PreserveInvalidExistingDocument();
			string text = $"{_path}.{Guid.NewGuid():N}.tmp";
			try
			{
				using (FileStream fileStream = new FileStream(text, FileMode.CreateNew, FileAccess.Write, FileShare.None))
				{
					JsonSerializer.Serialize(fileStream, Normalize(preferences2), JsonOptions);
					fileStream.Flush(flushToDisk: true);
				}
				File.Move(text, _path, overwrite: true);
				_preservedCorruptJson = null;
			}
			finally
			{
				if (File.Exists(text))
				{
					File.Delete(text);
				}
			}
		}
	}

	private void PreserveInvalidExistingDocument()
	{
		if (!File.Exists(_path))
		{
			return;
		}
		string text = File.ReadAllText(_path);
		try
		{
			if (JsonSerializer.Deserialize<MacroPreferences>(text, JsonOptions) == null)
			{
				throw new JsonException("The settings document is null.");
			}
		}
		catch (JsonException)
		{
			if (!string.Equals(text, _preservedCorruptJson, StringComparison.Ordinal))
			{
				PreserveCorruptDocument(text);
			}
		}
	}

	private void PreserveCorruptDocument(string json)
	{
		string text = $"{_path}.corrupt-{DateTime.UtcNow:yyyyMMddTHHmmssfff}-{Guid.NewGuid():N}.json";
		File.Copy(_path, text, overwrite: false);
		RecoveryPath = text;
		LastLoadWarning = "Macro settings could not be read. Defaults were restored; the original is saved at " + text + ".";
		_preservedCorruptJson = json;
	}

	private static MacroPreferences Normalize(MacroPreferences preferences)
	{
		MacroPreferences macroPreferences = preferences;
		if (macroPreferences.GuiKeybind == null)
		{
			string text = (macroPreferences.GuiKeybind = "f10");
		}
		macroPreferences = preferences;
		if (macroPreferences.GuiTheme == null)
		{
			string text = (macroPreferences.GuiTheme = "Obsidian");
		}
		macroPreferences = preferences;
		if (macroPreferences.ParryBar == null)
		{
			ParryBarSettings parryBarSettings = (macroPreferences.ParryBar = new ParryBarSettings());
		}
		macroPreferences = preferences;
		if (macroPreferences.Profiles == null)
		{
			List<MacroProfile> list = (macroPreferences.Profiles = new List<MacroProfile>());
		}
		if (preferences.Profiles.Count > 10)
		{
			preferences.Profiles.RemoveRange(10, preferences.Profiles.Count - 10);
		}
		while (preferences.Profiles.Count < 10)
		{
			preferences.Profiles.Add(new MacroProfile());
		}
		for (int i = 0; i < preferences.Profiles.Count; i++)
		{
			MacroProfile macroProfile = preferences.Profiles[i] ?? new MacroProfile();
			preferences.Profiles[i] = macroProfile;
			if (string.IsNullOrWhiteSpace(macroProfile.Name))
			{
				macroProfile.Name = $"Preset {i + 1}";
			}
			macroProfile.Entries = ((macroProfile.Entries == null) ? MacroCatalog.CreateEntries() : new Dictionary<string, MacroEntry>(macroProfile.Entries, StringComparer.Ordinal));
			foreach (string item in new List<string>(macroProfile.Entries.Keys))
			{
				MacroEntry macroEntry = macroProfile.Entries[item] ?? new MacroEntry();
				macroEntry.Values = ((macroEntry.Values == null) ? new Dictionary<string, string>(StringComparer.Ordinal) : new Dictionary<string, string>(macroEntry.Values, StringComparer.Ordinal));
				macroProfile.Entries[item] = macroEntry;
			}
			macroProfile.Entries.Remove("auto-guild-exile");
			macroProfile.Entries.Remove("export-guild-members");
			macroProfile.Entries.Remove("auto-agility");
			macroProfile.Entries.Remove("auto-fortitude");
			macroProfile.Entries.Remove("auto-willpower");
			macroProfile.Entries.Remove("charisma-autofill");
			foreach (MacroDefinition item2 in MacroCatalog.All)
			{
				if (!macroProfile.Entries.TryGetValue(item2.Id, out MacroEntry value))
				{
					value = new MacroEntry();
					macroProfile.Entries.Add(item2.Id, value);
				}
				foreach (MacroField field in item2.Fields)
				{
					if (!value.Values.TryGetValue(field.Key, out string value2) || value2 == null)
					{
						value.Values[field.Key] = field.DefaultValue;
					}
				}
			}
		}
		preferences.SelectedProfile = Math.Clamp(preferences.SelectedProfile, 0, 9);
		return preferences;
	}
}
