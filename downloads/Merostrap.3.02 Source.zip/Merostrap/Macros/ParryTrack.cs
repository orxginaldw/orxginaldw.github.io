namespace Merostrap.Macros;

public sealed record ParryTrack(int Left, int Right, int Row, int Width, int Height);
