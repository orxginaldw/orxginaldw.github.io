using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Merostrap.Macros.Health;
using Tesseract;

namespace Merostrap.Macros;

public sealed class CharismaPromptReader : IDisposable
{
	private record Line(string Text, int X, int Y, int Width, int Height, float Confidence);

	public static readonly string[] Phrases = new string[8] { "Me-wow, is that the latest Felinor fashion?", "So, what's keeping you busy these days?", "Hey hivekin, can I bug you for a moment?", "So, how's work?", "Wow, this breeze is great, right?", "Sometimes I have really deep thoughts about life and stuff.", "Some weather we're having, huh?", "You ever been to a Canor restaurant? The food's pretty howlright." };

	private TesseractEngine? _engine;

	public string Diagnostic { get; private set; } = "";

	public CharismaFrame Analyze(HealthPixels pixels)
	{
		if (pixels.Width < 300 || pixels.Height < 200 || pixels.Bgra.Length != (long)pixels.Width * (long)pixels.Height * 4)
		{
			return new CharismaFrame("", "", Reliable: false);
		}
		EnsureEngine();
		int left = pixels.Width / 3;
		int top = pixels.Height * 35 / 100;
		int width = pixels.Width / 3;
		int height = pixels.Height * 16 / 100;
		List<Line> source = Read(pixels, left, top, width, height, PageIteratorLevel.TextLine);
		Diagnostic = string.Join(" | ", source.Select((Line l) => $"{l.Text}@{l.Y}+{l.Height}"));
		(Line, string) tuple = source.Select((Line l) => (Line: l, Phrase: RecognizePhrase(l.Text))).FirstOrDefault(((Line Line, string Phrase) l) => l.Phrase != null);
		if (tuple.Item2 == null)
		{
			bool flag = source.Any((Line l) => Similarity(string.Join("", CharismaText.Tokens(l.Text)), "trysomesmalltalkonsomeonenearby") >= 0.4);
			return new CharismaFrame("", "", !flag);
		}
		Line raw = tuple.Item1;
		Line line = (from l in source
			where l.Y >= raw.Y + raw.Height + 2 && l.Y < raw.Y + Math.Max(30, raw.Height * 5)
			orderby l.Y
			select l).FirstOrDefault();
		int num = pixels.Width / 8;
		int height2 = Math.Max(12, raw.Height * 2);
		HealthRegion inputArea = new HealthRegion(pixels.Width / 2 - num / 2, raw.Y + raw.Height + 2, num, height2);
		return new CharismaFrame(tuple.Item2, line?.Text ?? "", Reliable: true, inputArea);
	}

	public static string? RecognizePhrase(string text)
	{
		string value = string.Join("", CharismaText.Tokens(text));
		(string, double)[] array = (from p in Phrases
			select (Phrase: p, Score: Similarity(value, string.Join("", CharismaText.Tokens(p)))) into p
			orderby p.Score descending
			select p).Take(2).ToArray();
		if (!(array[0].Item2 >= 0.62) || !(array[0].Item2 - array[1].Item2 >= 0.18))
		{
			return null;
		}
		return array[0].Item1;
	}

	private static double Similarity(string a, string b)
	{
		if (a.Length == 0)
		{
			return 0.0;
		}
		int[] array = Enumerable.Range(0, b.Length + 1).ToArray();
		for (int i = 1; i <= a.Length; i++)
		{
			int[] array2 = new int[b.Length + 1];
			array2[0] = i;
			for (int j = 1; j <= b.Length; j++)
			{
				array2[j] = Math.Min(Math.Min(array2[j - 1] + 1, array[j] + 1), array[j - 1] + ((a[i - 1] != b[j - 1]) ? 1 : 0));
			}
			array = array2;
		}
		return 1.0 - (double)array[b.Length] / (double)Math.Max(a.Length, b.Length);
	}

	private List<Line> Read(HealthPixels pixels, int left, int top, int width, int height, PageIteratorLevel level)
	{
		int num = width * 4 + 24;
		int num2 = height * 4 + 24;
		int num3 = (num * 3 + 3) & -4;
		using MemoryStream memoryStream = new MemoryStream();
		using (BinaryWriter binaryWriter = new BinaryWriter(memoryStream, Encoding.UTF8, leaveOpen: true))
		{
			binaryWriter.Write((ushort)19778);
			binaryWriter.Write(54 + num3 * num2);
			binaryWriter.Write(0);
			binaryWriter.Write(54);
			binaryWriter.Write(40);
			binaryWriter.Write(num);
			binaryWriter.Write(num2);
			binaryWriter.Write((ushort)1);
			binaryWriter.Write((ushort)24);
			binaryWriter.Write(0);
			binaryWriter.Write(num3 * num2);
			for (int i = 0; i < 4; i++)
			{
				binaryWriter.Write(0);
			}
			byte[] array = new byte[num3];
			for (int num4 = num2 - 1; num4 >= 0; num4--)
			{
				Array.Fill(array, byte.MaxValue);
				if (num4 >= 12 && num4 < num2 - 12)
				{
					for (int j = 12; j < num - 12; j++)
					{
						int num5 = ((top + (num4 - 12) / 4) * pixels.Width + left + (j - 12) / 4) * 4;
						int val = pixels.Bgra[num5];
						int val2 = pixels.Bgra[num5 + 1];
						int val3 = pixels.Bgra[num5 + 2];
						byte b = (byte)(255 - Math.Clamp((Math.Min(val3, Math.Min(val2, val)) - 125) * 255 / 100, 0, 255));
						array[j * 3] = (array[j * 3 + 1] = (array[j * 3 + 2] = b));
					}
				}
				binaryWriter.Write(array);
			}
		}
		using Pix image = Pix.LoadFromMemory(memoryStream.ToArray());
		using Page page = _engine.Process(image, PageSegMode.SparseText);
		using ResultIterator resultIterator = page.GetIterator();
		resultIterator.Begin();
		List<Line> list = new List<Line>();
		do
		{
			string text = resultIterator.GetText(level)?.Trim();
			if (!string.IsNullOrWhiteSpace(text) && resultIterator.TryGetBoundingBox(level, out var bounds))
			{
				list.Add(new Line(text, left + (bounds.X1 - 12) / 4, top + (bounds.Y1 - 12) / 4, Math.Max(1, (bounds.Width + 4 - 1) / 4), Math.Max(1, (bounds.Height + 4 - 1) / 4), resultIterator.GetConfidence(level)));
			}
		}
		while (resultIterator.Next(level));
		return list;
	}

	private void EnsureEngine()
	{
		if (_engine == null)
		{
			string path = (TesseractEnviornment.CustomSearchPath = HealthOcrResources.EnsureAvailable());
			_engine = new TesseractEngine(Path.Combine(path, "tessdata"), "eng", EngineMode.LstmOnly);
			_engine.SetVariable("debug_file", "NUL");
		}
	}

	public void Dispose()
	{
		_engine?.Dispose();
		_engine = null;
	}
}
