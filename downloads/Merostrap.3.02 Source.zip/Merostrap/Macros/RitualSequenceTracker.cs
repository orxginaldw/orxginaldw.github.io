using System;
using System.Linq;

namespace Merostrap.Macros;

public sealed class RitualSequenceTracker
{
	private RitualGlyph? _pending;

	private RitualGlyph? _candidate;

	private long _candidateSince;

	private RitualGlyph[] _sentSequence = Array.Empty<RitualGlyph>();

	private RitualGlyph[] _latest = Array.Empty<RitualGlyph>();

	private bool _ready;

	private long? _absentSince;

	private long _lastObservedAt;

	private long _lastSentAt;

	public string Status { get; private set; } = "reading prompts";

	public void ResetConfirmation()
	{
		_candidate = null;
		_ready = false;
		Status = "confirming prompt";
		_absentSince = null;
	}

	public char? Observe(RitualFrame frame, long timestamp)
	{
		_lastObservedAt = timestamp;
		_ready = false;
		Status = "confirming prompt";
		if (!frame.Reliable || frame.Glyphs == null || frame.Glyphs.Count > 12 || frame.Glyphs.Any((RitualGlyph g) =>
		{
			int width = g.Width;
			bool flag3 = ((width < 1 || width > 128) ? true : false);
			bool flag4 = flag3;
			if (!flag4)
			{
				int height = g.Height;
				bool flag5 = ((height < 1 || height > 128) ? true : false);
				flag4 = flag5;
			}
			return flag4;
		}))
		{
			_candidate = null;
			_absentSince = null;
			Status = "waiting for a clear ritual frame";
			return null;
		}
		if (frame.Glyphs.Count == 0)
		{
			_candidate = null;
			Status = (frame.PromptAbsent ? "waiting for a ritual frame" : "waiting for prompts");
			if (frame.PromptAbsent)
			{
				long valueOrDefault = _absentSince.GetValueOrDefault();
				if (!_absentSince.HasValue)
				{
					valueOrDefault = timestamp;
					_absentSince = valueOrDefault;
				}
				if (timestamp - _absentSince >= 1000)
				{
					_pending = null;
					_sentSequence = Array.Empty<RitualGlyph>();
				}
			}
			else
			{
				_absentSince = null;
			}
			return null;
		}
		_absentSince = null;
		_latest = (from g in frame.Glyphs
			orderby g.X, g.Y
			select g).ToArray();
		RitualGlyph value = _latest[0];
		if (!IsCharacter(value.Character) || !(value.Confidence >= 65f) || !(value.Confidence <= 100f))
		{
			_candidate = null;
			Status = "unreadable leading character";
			return null;
		}
		RitualGlyph? pending = _pending;
		if (pending.HasValue)
		{
			RitualGlyph sent = pending.GetValueOrDefault();
			bool flag = _sentSequence.Length > 1 && _latest.Length == _sentSequence.Length - 1 && (double)(_sentSequence[1].X - sent.X) > Math.Max(12.0, (double)sent.Width * 1.5) && _latest.Zip(_sentSequence.Skip(1)).All(((RitualGlyph First, RitualGlyph Second) pair) =>
			{
				if (IsCharacter(pair.Second.Character))
				{
					float confidence2 = pair.Second.Confidence;
					if (confidence2 >= 65f && confidence2 <= 100f && pair.First.Character == pair.Second.Character)
					{
						confidence2 = pair.First.Confidence;
						if (confidence2 >= 65f && confidence2 <= 100f && Math.Abs(pair.First.X - pair.Second.X) <= 3 && Math.Abs(pair.First.Y - pair.Second.Y) <= 3 && Math.Abs(pair.First.Width - pair.Second.Width) <= 2)
						{
							return Math.Abs(pair.First.Height - pair.Second.Height) <= 2;
						}
					}
				}
				return false;
			});
			bool flag2 = _sentSequence.Length == 1 && _latest.Length >= 3 && sent.X - value.X > Math.Max(24, sent.Width * 2) && _latest.All((RitualGlyph g) =>
			{
				if (IsCharacter(g.Character))
				{
					float confidence2 = g.Confidence;
					if (confidence2 >= 65f)
					{
						return confidence2 <= 100f;
					}
					return false;
				}
				return false;
			}) && _latest.Zip(_latest.Skip(1)).All(((RitualGlyph First, RitualGlyph Second) pair) => (double)(pair.Second.X - pair.First.X) > Math.Max(12.0, (double)pair.First.Width * 1.5));
			if (!((value.Character != sent.Character) | flag | flag2) && (_sentSequence.Length < 3 || _latest.Length < _sentSequence.Length - 1 || !_sentSequence.Skip(1).All((RitualGlyph g) =>
			{
				if (IsCharacter(g.Character))
				{
					float confidence2 = g.Confidence;
					if (confidence2 >= 65f)
					{
						return confidence2 <= 100f;
					}
					return false;
				}
				return false;
			}) || !_sentSequence.Skip(1).Any((RitualGlyph g) => g.Character != sent.Character) || !_latest.Take(_sentSequence.Length - 1).All((RitualGlyph g) =>
			{
				if (IsCharacter(g.Character))
				{
					float confidence2 = g.Confidence;
					if (confidence2 >= 65f)
					{
						return confidence2 <= 100f;
					}
					return false;
				}
				return false;
			}) || !(from g in _latest.Take(_sentSequence.Length - 1)
				select g.Character).SequenceEqual(from g in _sentSequence.Skip(1)
				select g.Character)))
			{
				if (_sentSequence.Length > 1 && value.Character == _sentSequence[1].Character && IsCharacter(_sentSequence[1].Character))
				{
					float confidence = _sentSequence[1].Confidence;
					if (confidence >= 65f && confidence <= 100f && (double)Math.Abs(_sentSequence[1].Y - sent.Y) > Math.Max(6.0, (double)sent.Height * 0.7) && Math.Abs(value.Y - _sentSequence[1].Y) <= 6)
					{
						goto IL_070d;
					}
				}
				_candidate = null;
				Status = $"waiting for {sent.Character} to advance";
				return null;
			}
		}
		goto IL_070d;
		IL_070d:
		pending = _candidate;
		if (pending.HasValue)
		{
			RitualGlyph valueOrDefault2 = pending.GetValueOrDefault();
			if (valueOrDefault2.Character == value.Character && !((double)Math.Abs(valueOrDefault2.Y - value.Y) > Math.Max(6.0, (double)value.Height * 0.7)) && Math.Abs(valueOrDefault2.X - value.X) <= Math.Max(12, value.Width * 2))
			{
				_candidate = value;
				if (timestamp - _candidateSince < 15)
				{
					return null;
				}
				_ready = true;
				Status = "reading prompts";
				return value.Character;
			}
		}
		_candidate = value;
		_candidateSince = timestamp;
		return null;
	}

	public void ConfirmSent()
	{
		if (_ready)
		{
			RitualGlyph? candidate = _candidate;
			if (candidate.HasValue)
			{
				RitualGlyph valueOrDefault = candidate.GetValueOrDefault();
				_pending = valueOrDefault;
				_lastSentAt = _lastObservedAt;
				_sentSequence = _latest.ToArray();
				_candidate = null;
				_ready = false;
				return;
			}
		}
		throw new InvalidOperationException("No confirmed ritual character is ready.");
	}

	private static bool IsCharacter(char? c)
	{
		switch (c)
		{
		case '0':
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		case '8':
		case '9':
		case 'A':
		case 'B':
		case 'C':
		case 'D':
		case 'E':
		case 'F':
		case 'G':
		case 'H':
		case 'I':
		case 'J':
		case 'K':
		case 'L':
		case 'M':
		case 'N':
		case 'O':
		case 'P':
		case 'Q':
		case 'R':
		case 'S':
		case 'T':
		case 'U':
		case 'V':
		case 'W':
		case 'X':
		case 'Y':
		case 'Z':
			return true;
		default:
			return false;
		}
	}

	public char? RetryPending(long timestamp, int interval)
	{
		RitualGlyph? pending = _pending;
		if (pending.HasValue)
		{
			RitualGlyph valueOrDefault = pending.GetValueOrDefault();
			if (!(Status != $"waiting for {valueOrDefault.Character} to advance") && timestamp - _lastSentAt >= interval && _latest.Length != 0)
			{
				RitualGlyph value = _latest[0];
				bool flag = value.Character != valueOrDefault.Character;
				if (!flag)
				{
					float confidence = value.Confidence;
					bool flag2 = ((confidence < 65f || confidence > 100f) ? true : false);
					flag = flag2;
				}
				if (flag || Math.Abs(value.X - valueOrDefault.X) > 2 || Math.Abs(value.Y - valueOrDefault.Y) > 2 || Math.Abs(value.Width - valueOrDefault.Width) > 2 || Math.Abs(value.Height - valueOrDefault.Height) > 2)
				{
					return null;
				}
				_candidate = value;
				_ready = true;
				return value.Character;
			}
		}
		return null;
	}
}
