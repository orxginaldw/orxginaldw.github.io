using System;
using System.Runtime.InteropServices;
using System.Threading;
using Merostrap.Macros.Health;

namespace Merostrap.Macros;

public sealed class WindowsRitualPromptSource : IRitualPromptSource, IDisposable
{
	private readonly WindowsHealthCapture _capture = new WindowsHealthCapture();

	private readonly RitualPromptReader _reader = new RitualPromptReader();

	private bool _disposed;

	public HealthRegion? DetectRegion(CancellationToken token)
	{
		token.ThrowIfCancellationRequested();
		if (_disposed || !OperatingSystem.IsWindows())
		{
			return null;
		}
		nint num = WindowsHealthCapture.ForegroundRobloxWindow();
		HealthRegion healthRegion = default;
		int num2;
		if (num != IntPtr.Zero)
		{
			healthRegion = WindowsHealthCapture.ForegroundRobloxArea(top: true);
			num2 = (((object)healthRegion == null) ? 1 : 0);
		}
		else
		{
			num2 = 1;
		}
		bool flag = (byte)num2 != 0;
		if (!flag)
		{
			int width = healthRegion.Width;
			bool flag2 = ((width < 160 || width > 4096) ? true : false);
			flag = flag2;
		}
		bool flag3 = flag;
		if (!flag3)
		{
			int width = healthRegion.Height;
			bool flag2 = ((width < 40 || width > 2160) ? true : false);
			flag3 = flag2;
		}
		if (flag3)
		{
			return null;
		}
		HealthPixels healthPixels = new HealthPixels(healthRegion.Width, healthRegion.Height, new byte[checked(healthRegion.Width * healthRegion.Height * 4)]);
		for (int i = 0; i < healthRegion.Height; i += 300)
		{
			token.ThrowIfCancellationRequested();
			if (WindowsHealthCapture.ForegroundRobloxWindow() != num || WindowsHealthCapture.ForegroundRobloxArea(top: true) != healthRegion)
			{
				return null;
			}
			HealthPixels healthPixels2 = _capture.Capture(new HealthRegion(healthRegion.X, healthRegion.Y + i, healthRegion.Width, Math.Min(300, healthRegion.Height - i)));
			Array.Copy(healthPixels2.Bgra, 0, healthPixels.Bgra, i * healthRegion.Width * 4, healthPixels2.Bgra.Length);
		}
		token.ThrowIfCancellationRequested();
		HealthRegion healthRegion2 = RitualPromptDetector.Detect(healthPixels);
		token.ThrowIfCancellationRequested();
		if (WindowsHealthCapture.ForegroundRobloxWindow() != num || WindowsHealthCapture.ForegroundRobloxArea(top: true) != healthRegion)
		{
			return null;
		}
		if ((object)healthRegion2 != null)
		{
			return healthRegion2 with
			{
				X = healthRegion2.X + healthRegion.X,
				Y = healthRegion2.Y + healthRegion.Y
			};
		}
		return null;
	}

	public RitualFrame Read(HealthRegion region)
	{
		if (_disposed || !OperatingSystem.IsWindows() || !WindowsHealthCapture.IsForegroundRoblox())
		{
			return new RitualFrame(Array.Empty<RitualGlyph>(), Reliable: false);
		}
		nint foregroundWindow = GetForegroundWindow();
		try
		{
			HealthPixels healthPixels = null;
			HealthPixels pixels;
			if (region.Width <= 4084 && region.Height <= 288)
			{
				try
				{
					healthPixels = _capture.Capture(new HealthRegion(region.X - 6, region.Y - 6, region.Width + 12, region.Height + 12));
					pixels = RitualPromptDetector.HudCrop(healthPixels, new HealthRegion(6, 6, region.Width, region.Height));
				}
				catch
				{
					healthPixels = null;
					pixels = _capture.Capture(region);
				}
			}
			else
			{
				pixels = _capture.Capture(region);
			}
			if (!WindowsHealthCapture.IsForegroundRoblox() || GetForegroundWindow() != foregroundWindow)
			{
				return new RitualFrame(Array.Empty<RitualGlyph>(), Reliable: false);
			}
			RitualFrame frame = _reader.Analyze(pixels);
			RitualPromptDetector.OutlineState outline = RitualPromptDetector.OutlineState.Uncertain;
			if ((object)healthPixels != null)
			{
				try
				{
					outline = RitualPromptDetector.ReadOutline(healthPixels);
				}
				catch
				{
					outline = RitualPromptDetector.OutlineState.Uncertain;
				}
			}
			frame = RitualPromptDetector.GateRecognition(frame, outline);
			return (WindowsHealthCapture.IsForegroundRoblox() && GetForegroundWindow() == foregroundWindow) ? frame : new RitualFrame(Array.Empty<RitualGlyph>(), Reliable: false);
		}
		catch
		{
			return new RitualFrame(Array.Empty<RitualGlyph>(), Reliable: false);
		}
	}

	[DllImport("user32.dll")]
	private static extern nint GetForegroundWindow();

	public void Dispose()
	{
		_disposed = true;
		_reader.Dispose();
	}
}
