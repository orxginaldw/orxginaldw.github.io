using System.Net.Http;
using System.Threading;

namespace Merostrap;

internal class HttpClientLoggingHandler : MessageProcessingHandler
{
	public HttpClientLoggingHandler(HttpMessageHandler innerHandler)
		: base(innerHandler)
	{
	}

	protected override HttpRequestMessage ProcessRequest(HttpRequestMessage request, CancellationToken cancellationToken)
	{
		App.Logger.Info($"{request.Method} {request.RequestUri}");
		return request;
	}

	protected override HttpResponseMessage ProcessResponse(HttpResponseMessage response, CancellationToken cancellationToken)
	{
		App.Logger.Info($"{(int)response.StatusCode} {response.ReasonPhrase} {response.RequestMessage.RequestUri}");
		return response;
	}
}
