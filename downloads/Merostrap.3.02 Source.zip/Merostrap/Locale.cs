using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Media;
using Avalonia.Styling;
using Merostrap.Resources;

namespace Merostrap;

internal static class Locale
{
	private static readonly List<string> _rtlLocales;

	public static readonly Dictionary<string, string> SupportedLocales;

	public static CultureInfo CurrentCulture { get; private set; } = CultureInfo.InvariantCulture;

	public static bool RightToLeft { get; private set; }

	public static string GetIdentifierFromName(string language)
	{
		return SupportedLocales.FirstOrDefault((KeyValuePair<string, string> x) => x.Value == language).Key ?? "nil";
	}

	public static List<string> GetLanguages()
	{
		List<string> languages = new List<string>();
		languages.AddRange(SupportedLocales.Values.Take(3));
		languages.AddRange(from x in SupportedLocales.Values
			where !languages.Contains(x)
			orderby x
			select x);
		languages[0] = Strings.Common_SystemDefault;
		return languages;
	}

	public static void Set(string identifier)
	{
		if (!SupportedLocales.ContainsKey(identifier))
		{
			identifier = "nil";
		}
		if (identifier == "nil")
		{
			CurrentCulture = CultureInfo.CurrentUICulture;
		}
		else
		{
			CurrentCulture = new CultureInfo(identifier);
		}
		Thread.CurrentThread.CurrentCulture = CurrentCulture;
		Thread.CurrentThread.CurrentUICulture = CurrentCulture;
		CultureInfo.DefaultThreadCurrentCulture = CurrentCulture;
		CultureInfo.DefaultThreadCurrentUICulture = CurrentCulture;
		Strings.Culture = CurrentCulture;
		RightToLeft = _rtlLocales.Any((string l) => CurrentCulture.Name.StartsWith(l, StringComparison.OrdinalIgnoreCase));
	}

	public static void Initialize()
	{
		Set("nil");
		ApplyLocaleToApplication();
	}

	public static void ApplyLocaleToWindow(Window window)
	{
		if (RightToLeft)
		{
			window.FlowDirection = FlowDirection.RightToLeft;
		}
		else if (CurrentCulture.Name.StartsWith("th", StringComparison.Ordinal))
		{
			Application? current = Application.Current;
			if (current != null)
			{
				current.Resources["ContentFontFamily"] = new FontFamily("Noto Sans Thai");
			}
		}
	}

	private static void ApplyLocaleToApplication()
	{
		if (RightToLeft)
		{
			Style item = new Style((Selector? x) => x.OfType<Control>())
			{
				Setters = { (SetterBase)new Setter(Visual.FlowDirectionProperty, FlowDirection.RightToLeft) }
			};
			Application.Current?.Styles.Add(item);
		}
	}

	static Locale()
	{
		int num = 2;
		List<string> list = new List<string>(num);
		CollectionsMarshal.SetCount(list, num);
		Span<string> span = CollectionsMarshal.AsSpan(list);
		span[0] = "ar";
		span[1] = "he";
		_rtlLocales = list;
		SupportedLocales = new Dictionary<string, string>
		{
			{
				"nil",
				Strings.Common_SystemDefault
			},
			{ "en", "English" },
			{ "en-US", "English (United States)" },
			{ "ar", "العربية" },
			{ "bg", "Български" },
			{ "cs", "Čeština" },
			{ "da", "Dansk" },
			{ "de", "Deutsch" },
			{ "el", "Ελληνικά" },
			{ "es-ES", "Español" },
			{ "et", "Eesti" },
			{ "fi", "Suomi" },
			{ "fr", "Français" },
			{ "hu", "Magyar" },
			{ "id", "Bahasa Indonesia" },
			{ "it", "Italiano" },
			{ "ja", "日本語" },
			{ "ko", "한국어" },
			{ "lt", "Lietuvių" },
			{ "lv", "Latviešu" },
			{ "nl", "Nederlands" },
			{ "pl", "Polski" },
			{ "pt-BR", "Português (Brasil)" },
			{ "pt-PT", "Português (Portugal)" },
			{ "ro", "Română" },
			{ "ru", "Русский" },
			{ "sk", "Slovenčina" },
			{ "sl", "Slovenščina" },
			{ "sv-SE", "Svenska" },
			{ "tr", "Türkçe" },
			{ "uk", "Українська" },
			{ "vi", "Tiếng Việt" },
			{ "zh-CN", "中文 (简体)" },
			{ "zh-TW", "中文 (繁體)" }
		};
	}
}
