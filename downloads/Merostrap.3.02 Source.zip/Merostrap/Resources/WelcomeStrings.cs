using System.Resources;

namespace Merostrap.Resources;

internal static class WelcomeStrings
{
	private static readonly ResourceManager Manager = new ResourceManager("Merostrap.Resources.Welcome", typeof(WelcomeStrings).Assembly);

	public static string Play => Manager.GetString("Play", Locale.CurrentCulture);

	public static string WelcomeTitle => Manager.GetString("WelcomeTitle", Locale.CurrentCulture);

	public static string WelcomeSubtitle => Manager.GetString("WelcomeSubtitle", Locale.CurrentCulture);

	public static string LanguageTitle => Manager.GetString("LanguageTitle", Locale.CurrentCulture);

	public static string LanguageHelp => Manager.GetString("LanguageHelp", Locale.CurrentCulture);

	public static string AppearanceTitle => Manager.GetString("AppearanceTitle", Locale.CurrentCulture);

	public static string AppearanceHelp => Manager.GetString("AppearanceHelp", Locale.CurrentCulture);

	public static string ShortcutsTitle => Manager.GetString("ShortcutsTitle", Locale.CurrentCulture);

	public static string ShortcutsHelp => Manager.GetString("ShortcutsHelp", Locale.CurrentCulture);

	public static string ReadyTitle => Manager.GetString("ReadyTitle", Locale.CurrentCulture);

	public static string ReadyHelp => Manager.GetString("ReadyHelp", Locale.CurrentCulture);

	public static string OpenLauncher => Manager.GetString("OpenLauncher", Locale.CurrentCulture);

	public static string Continue => Manager.GetString("Continue", Locale.CurrentCulture);

	public static string StepFormat => Manager.GetString("StepFormat", Locale.CurrentCulture);

	public static string SetupHint => Manager.GetString("SetupHint", Locale.CurrentCulture);

	public static string LauncherTitle => Manager.GetString("LauncherTitle", Locale.CurrentCulture);

	public static string LauncherHelp => Manager.GetString("LauncherHelp", Locale.CurrentCulture);

	public static string PlayerDescription => Manager.GetString("PlayerDescription", Locale.CurrentCulture);

	public static string StudioDescription => Manager.GetString("StudioDescription", Locale.CurrentCulture);

	public static string LaunchHelp => Manager.GetString("LaunchHelp", Locale.CurrentCulture);

	public static string Username => Manager.GetString("Username", Locale.CurrentCulture);

	public static string Password => Manager.GetString("Password", Locale.CurrentCulture);

	public static string SignIn => Manager.GetString("SignIn", Locale.CurrentCulture);

	public static string Working => Manager.GetString("Working", Locale.CurrentCulture);

	public static string MissingFields => Manager.GetString("MissingFields", Locale.CurrentCulture);

	public static string NotConfigured => Manager.GetString("NotConfigured", Locale.CurrentCulture);

	public static string Unavailable => Manager.GetString("Unavailable", Locale.CurrentCulture);

	public static string DeviceMismatch => Manager.GetString("DeviceMismatch", Locale.CurrentCulture);

	public static string InvalidCredentials => Manager.GetString("InvalidCredentials", Locale.CurrentCulture);

	public static string AccountUnavailable => Manager.GetString("AccountUnavailable", Locale.CurrentCulture);

	public static string RateLimited => Manager.GetString("RateLimited", Locale.CurrentCulture);

	public static string SignOut => Manager.GetString("SignOut", Locale.CurrentCulture);

	public static string AccessVerified => Manager.GetString("AccessVerified", Locale.CurrentCulture);

	public static string ServerSetup => Manager.GetString("ServerSetup", Locale.CurrentCulture);

	public static string DeviceUnavailable => Manager.GetString("DeviceUnavailable", Locale.CurrentCulture);
}
