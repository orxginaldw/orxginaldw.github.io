using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Merostrap.Resources;

[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "18.0.0.0")]
[DebuggerNonUserCode]
[CompilerGenerated]
public class Strings
{
	private static ResourceManager resourceMan;

	private static CultureInfo resourceCulture;

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	public static ResourceManager ResourceManager
	{
		get
		{
			if (resourceMan == null)
			{
				resourceMan = new ResourceManager("Merostrap.Resources.Strings", typeof(Strings).Assembly);
			}
			return resourceMan;
		}
	}

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	public static CultureInfo Culture
	{
		get
		{
			return resourceCulture;
		}
		set
		{
			resourceCulture = value;
		}
	}

	public static string About_Licenses_Title => ResourceManager.GetString("About.Licenses.Title", resourceCulture);

	public static string About_Onboarding_Title => ResourceManager.GetString("About.Onboarding.Title", resourceCulture);

	public static string About_Title => ResourceManager.GetString("About.Title", resourceCulture);

	public static string AccountManager_Replace_Failed => ResourceManager.GetString("AccountManager.Replace.Failed", resourceCulture);

	public static string AccountManager_Replace_Success => ResourceManager.GetString("AccountManager.Replace.Success", resourceCulture);

	public static string ActivityWatcher_LocationQueryFailed => ResourceManager.GetString("ActivityWatcher.LocationQueryFailed", resourceCulture);

	public static string AddCustomTheme_Title => ResourceManager.GetString("AddCustomTheme.Title", resourceCulture);

	public static string App_OSDeprecation_Win7_81 => ResourceManager.GetString("App.OSDeprecation.Win7_81", resourceCulture);

	public static string Boostrapper_Dialog_UnauthorizedChannel => ResourceManager.GetString("Boostrapper.Dialog.UnauthorizedChannel", resourceCulture);

	public static string Bootstrapper_AutoUpdateFailed => ResourceManager.GetString("Bootstrapper.AutoUpdateFailed", resourceCulture);

	public static string Bootstrapper_Bootstrapper_Dialog_PromptChannelChange => ResourceManager.GetString("Bootstrapper.Bootstrapper.Dialog.PromptChannelChange", resourceCulture);

	public static string Bootstrapper_CancelButton_Skip => ResourceManager.GetString("Bootstrapper.CancelButton.Skip", resourceCulture);

	public static string Bootstrapper_ConfirmLaunch => ResourceManager.GetString("Bootstrapper.ConfirmLaunch", resourceCulture);

	public static string Bootstrapper_Dialog_ChannelOutOfDate => ResourceManager.GetString("Bootstrapper.Dialog.ChannelOutOfDate", resourceCulture);

	public static string Bootstrapper_Dialog_NoUpgradeWithoutClient => ResourceManager.GetString("Bootstrapper.Dialog.NoUpgradeWithoutClient", resourceCulture);

	public static string Bootstrapper_ExtractionFailed_Message => ResourceManager.GetString("Bootstrapper.ExtractionFailed.Message", resourceCulture);

	public static string Bootstrapper_ExtractionFailed_Title => ResourceManager.GetString("Bootstrapper.ExtractionFailed.Title", resourceCulture);

	public static string Bootstrapper_JsonManagerSaveFailed => ResourceManager.GetString("Bootstrapper.JsonManagerSaveFailed", resourceCulture);

	public static string Bootstrapper_ModificationsFailed_Message => ResourceManager.GetString("Bootstrapper.ModificationsFailed.Message", resourceCulture);

	public static string Bootstrapper_ModificationsFailed_Title => ResourceManager.GetString("Bootstrapper.ModificationsFailed.Title", resourceCulture);

	public static string Bootstrapper_NotEnoughSpace => ResourceManager.GetString("Bootstrapper.NotEnoughSpace", resourceCulture);

	public static string Bootstrapper_Status_ApplyingModifications => ResourceManager.GetString("Bootstrapper.Status.ApplyingModifications", resourceCulture);

	public static string Bootstrapper_Status_CancelUpgrade => ResourceManager.GetString("Bootstrapper.Status.CancelUpgrade", resourceCulture);

	public static string Bootstrapper_Status_CheckingFlatpak => ResourceManager.GetString("Bootstrapper.Status.CheckingFlatpak", resourceCulture);

	public static string Bootstrapper_Status_CheckingUpdates => ResourceManager.GetString("Bootstrapper.Status.CheckingUpdates", resourceCulture);

	public static string Bootstrapper_Status_Configuring => ResourceManager.GetString("Bootstrapper.Status.Configuring", resourceCulture);

	public static string Bootstrapper_Status_Connecting => ResourceManager.GetString("Bootstrapper.Status.Connecting", resourceCulture);

	public static string Bootstrapper_Status_Downloading => ResourceManager.GetString("Bootstrapper.Status.Downloading", resourceCulture);

	public static string Bootstrapper_Status_DownloadingDXVK => ResourceManager.GetString("Bootstrapper.Status.DownloadingDXVK", resourceCulture);

	public static string Bootstrapper_Status_DownloadingPackages => ResourceManager.GetString("Bootstrapper.Status.DownloadingPackages", resourceCulture);

	public static string Bootstrapper_Status_DownloadingUpdate => ResourceManager.GetString("Bootstrapper.Status.DownloadingUpdate", resourceCulture);

	public static string Bootstrapper_Status_DownloadingWebView2 => ResourceManager.GetString("Bootstrapper.Status.DownloadingWebView2", resourceCulture);

	public static string Bootstrapper_Status_DownloadingWine => ResourceManager.GetString("Bootstrapper.Status.DownloadingWine", resourceCulture);

	public static string Bootstrapper_Status_Extracting => ResourceManager.GetString("Bootstrapper.Status.Extracting", resourceCulture);

	public static string Bootstrapper_Status_ExtractingDXVK => ResourceManager.GetString("Bootstrapper.Status.ExtractingDXVK", resourceCulture);

	public static string Bootstrapper_Status_ExtractingWine => ResourceManager.GetString("Bootstrapper.Status.ExtractingWine", resourceCulture);

	public static string Bootstrapper_Status_FindingTopRegions => ResourceManager.GetString("Bootstrapper.Status.FindingTopRegions", resourceCulture);

	public static string Bootstrapper_Status_InitializingWinePrefix => ResourceManager.GetString("Bootstrapper.Status.InitializingWinePrefix", resourceCulture);

	public static string Bootstrapper_Status_Installing => ResourceManager.GetString("Bootstrapper.Status.Installing", resourceCulture);

	public static string Bootstrapper_Status_InstallingSober => ResourceManager.GetString("Bootstrapper.Status.InstallingSober", resourceCulture);

	public static string Bootstrapper_Status_InstallingUpdate => ResourceManager.GetString("Bootstrapper.Status.InstallingUpdate", resourceCulture);

	public static string Bootstrapper_Status_InstallingWebView2 => ResourceManager.GetString("Bootstrapper.Status.InstallingWebView2", resourceCulture);

	public static string Bootstrapper_Status_InvalidOverride => ResourceManager.GetString("Bootstrapper.Status.InvalidOverride", resourceCulture);

	public static string Bootstrapper_Status_PackagesLeft => ResourceManager.GetString("Bootstrapper.Status.PackagesLeft", resourceCulture);

	public static string Bootstrapper_Status_RetryingPackage => ResourceManager.GetString("Bootstrapper.Status.RetryingPackage", resourceCulture);

	public static string Bootstrapper_Status_SearchingNearbyServers => ResourceManager.GetString("Bootstrapper.Status.SearchingNearbyServers", resourceCulture);

	public static string Bootstrapper_Status_SearchingServers => ResourceManager.GetString("Bootstrapper.Status.SearchingServers", resourceCulture);

	public static string Bootstrapper_Status_SkippingMatchmaking => ResourceManager.GetString("Bootstrapper.Status.SkippingMatchmaking", resourceCulture);

	public static string Bootstrapper_Status_SoberUpdateComplete => ResourceManager.GetString("Bootstrapper.Status.SoberUpdateComplete", resourceCulture);

	public static string Bootstrapper_Status_Starting => ResourceManager.GetString("Bootstrapper.Status.Starting", resourceCulture);

	public static string Bootstrapper_Status_StartingSober => ResourceManager.GetString("Bootstrapper.Status.StartingSober", resourceCulture);

	public static string Bootstrapper_Status_UninstallingWebView2 => ResourceManager.GetString("Bootstrapper.Status.UninstallingWebView2", resourceCulture);

	public static string Bootstrapper_Status_UpdatingSober => ResourceManager.GetString("Bootstrapper.Status.UpdatingSober", resourceCulture);

	public static string Bootstrapper_Status_UpdatingSoberBasic => ResourceManager.GetString("Bootstrapper.Status.UpdatingSoberBasic", resourceCulture);

	public static string Bootstrapper_Status_UpdatingSoberProgress => ResourceManager.GetString("Bootstrapper.Status.UpdatingSoberProgress", resourceCulture);

	public static string Bootstrapper_Status_Upgrading => ResourceManager.GetString("Bootstrapper.Status.Upgrading", resourceCulture);

	public static string Bootstrapper_Status_WaitingForData => ResourceManager.GetString("Bootstrapper.Status.WaitingForData", resourceCulture);

	public static string Bootstrapper_Status_WaitingOtherInstances => ResourceManager.GetString("Bootstrapper.Status.WaitingOtherInstances", resourceCulture);

	public static string Bootstrapper_StylePreview_ImageCancel => ResourceManager.GetString("Bootstrapper.StylePreview.ImageCancel", resourceCulture);

	public static string Bootstrapper_StylePreview_TextCancel => ResourceManager.GetString("Bootstrapper.StylePreview.TextCancel", resourceCulture);

	public static string Bootstrapper_SuccessfullyUninstalled => ResourceManager.GetString("Bootstrapper.SuccessfullyUninstalled", resourceCulture);

	public static string Bootstrapper_Uninstall_RobloxRunning => ResourceManager.GetString("Bootstrapper.Uninstall.RobloxRunning", resourceCulture);

	public static string Bootstrapper_WebView2NotFound => ResourceManager.GetString("Bootstrapper.WebView2NotFound", resourceCulture);

	public static string Bootstrapper_WMFNotFound => ResourceManager.GetString("Bootstrapper.WMFNotFound", resourceCulture);

	public static string Common_AccountManager => ResourceManager.GetString("Common.AccountManager", resourceCulture);

	public static string Common_Add => ResourceManager.GetString("Common.Add", resourceCulture);

	public static string Common_AddSingle => ResourceManager.GetString("Common.AddSingle", resourceCulture);

	public static string Common_All => ResourceManager.GetString("Common.All", resourceCulture);

	public static string Common_Angle => ResourceManager.GetString("Common.Angle", resourceCulture);

	public static string Common_Apply => ResourceManager.GetString("Common.Apply", resourceCulture);

	public static string Common_Auto => ResourceManager.GetString("Common.Auto", resourceCulture);

	public static string Common_Back => ResourceManager.GetString("Common.Back", resourceCulture);

	public static string Common_Bands => ResourceManager.GetString("Common.Bands", resourceCulture);

	public static string Common_Browse => ResourceManager.GetString("Common.Browse", resourceCulture);

	public static string Common_Browser => ResourceManager.GetString("Common.Browser", resourceCulture);

	public static string Common_Cancel => ResourceManager.GetString("Common.Cancel", resourceCulture);

	public static string Common_Clear => ResourceManager.GetString("Common.Clear", resourceCulture);

	public static string Common_Close => ResourceManager.GetString("Common.Close", resourceCulture);

	public static string Common_ColorPicker => ResourceManager.GetString("Common.ColorPicker", resourceCulture);

	public static string Common_Confirm => ResourceManager.GetString("Common.Confirm", resourceCulture);

	public static string Common_Copy => ResourceManager.GetString("Common.Copy", resourceCulture);

	public static string Common_CopyAll => ResourceManager.GetString("Common.CopyAll", resourceCulture);

	public static string Common_CreateNew => ResourceManager.GetString("Common.CreateNew", resourceCulture);

	public static string Common_Custom => ResourceManager.GetString("Common.Custom", resourceCulture);

	public static string Common_Deeplink => ResourceManager.GetString("Common.Deeplink", resourceCulture);

	public static string Common_Default => ResourceManager.GetString("Common.Default", resourceCulture);

	public static string Common_Delete => ResourceManager.GetString("Common.Delete", resourceCulture);

	public static string Common_DeleteAll => ResourceManager.GetString("Common.DeleteAll", resourceCulture);

	public static string Common_Deployment => ResourceManager.GetString("Common.Deployment", resourceCulture);

	public static string Common_Description => ResourceManager.GetString("Common.Description", resourceCulture);

	public static string Common_Disabled => ResourceManager.GetString("Common.Disabled", resourceCulture);

	public static string Common_DiscordRichPresence => ResourceManager.GetString("Common.DiscordRichPresence", resourceCulture);

	public static string Common_Download => ResourceManager.GetString("Common.Download", resourceCulture);

	public static string Common_Edit => ResourceManager.GetString("Common.Edit", resourceCulture);

	public static string Common_Editor => ResourceManager.GetString("Common.Editor", resourceCulture);

	public static string Common_Error => ResourceManager.GetString("Common.Error", resourceCulture);

	public static string Common_Export => ResourceManager.GetString("Common.Export", resourceCulture);

	public static string Common_Files => ResourceManager.GetString("Common.Files", resourceCulture);

	public static string Common_Finish => ResourceManager.GetString("Common.Finish", resourceCulture);

	public static string Common_Finished => ResourceManager.GetString("Common.Finished", resourceCulture);

	public static string Common_Game => ResourceManager.GetString("Common.Game", resourceCulture);

	public static string Common_Generate => ResourceManager.GetString("Common.Generate", resourceCulture);

	public static string Common_GlyphPreview => ResourceManager.GetString("Common.GlyphPreview", resourceCulture);

	public static string Common_HexCode => ResourceManager.GetString("Common.HexCode", resourceCulture);

	public static string Common_Import => ResourceManager.GetString("Common.Import", resourceCulture);

	public static string Common_ImportFromFile => ResourceManager.GetString("Common.ImportFromFile", resourceCulture);

	public static string Common_ImportJson => ResourceManager.GetString("Common.ImportJson", resourceCulture);

	public static string Common_Install => ResourceManager.GetString("Common.Install", resourceCulture);

	public static string Common_JustStarted => ResourceManager.GetString("Common.JustStarted", resourceCulture);

	public static string Common_Launch => ResourceManager.GetString("Common.Launch", resourceCulture);

	public static string Common_Loading => ResourceManager.GetString("Common.Loading", resourceCulture);

	public static string Common_Manual => ResourceManager.GetString("Common.Manual", resourceCulture);

	public static string Common_Miscellaneous => ResourceManager.GetString("Common.Miscellaneous", resourceCulture);

	public static string Common_Name => ResourceManager.GetString("Common.Name", resourceCulture);

	public static string Common_New => ResourceManager.GetString("Common.New", resourceCulture);

	public static string Common_Next => ResourceManager.GetString("Common.Next", resourceCulture);

	public static string Common_No => ResourceManager.GetString("Common.No", resourceCulture);

	public static string Common_NoResult => ResourceManager.GetString("Common.NoResult", resourceCulture);

	public static string Common_NotAvailable => ResourceManager.GetString("Common.NotAvailable", resourceCulture);

	public static string Common_NotFound => ResourceManager.GetString("Common.NotFound", resourceCulture);

	public static string Common_Offset => ResourceManager.GetString("Common.Offset", resourceCulture);

	public static string Common_OK => ResourceManager.GetString("Common.OK", resourceCulture);

	public static string Common_OpenFolder => ResourceManager.GetString("Common.OpenFolder", resourceCulture);

	public static string Common_OpenLogFile => ResourceManager.GetString("Common.OpenLogFile", resourceCulture);

	public static string Common_Performance => ResourceManager.GetString("Common.Performance", resourceCulture);

	public static string Common_Player => ResourceManager.GetString("Common.Player", resourceCulture);

	public static string Common_PresetFlagLists => ResourceManager.GetString("Common.PresetFlagLists", resourceCulture);

	public static string Common_Presets => ResourceManager.GetString("Common.Presets", resourceCulture);

	public static string Common_Priority => ResourceManager.GetString("Common.Priority", resourceCulture);

	public static string Common_Profiles => ResourceManager.GetString("Common.Profiles", resourceCulture);

	public static string Common_Quality => ResourceManager.GetString("Common.Quality", resourceCulture);

	public static string Common_Remove => ResourceManager.GetString("Common.Remove", resourceCulture);

	public static string Common_Rename => ResourceManager.GetString("Common.Rename", resourceCulture);

	public static string Common_RobloxNotInstalled => ResourceManager.GetString("Common.RobloxNotInstalled", resourceCulture);

	public static string Common_SaveAndInstall => ResourceManager.GetString("Common.SaveAndInstall", resourceCulture);

	public static string Common_SaveAndLaunch => ResourceManager.GetString("Common.SaveAndLaunch", resourceCulture);

	public static string Common_Search => ResourceManager.GetString("Common.Search", resourceCulture);

	public static string Common_Select => ResourceManager.GetString("Common.Select", resourceCulture);

	public static string Common_ServerID => ResourceManager.GetString("Common.ServerID", resourceCulture);

	public static string Common_Settings => ResourceManager.GetString("Common.Settings", resourceCulture);

	public static string Common_Shortcuts => ResourceManager.GetString("Common.Shortcuts", resourceCulture);

	public static string Common_Shortcuts_Desktop => ResourceManager.GetString("Common.Shortcuts.Desktop", resourceCulture);

	public static string Common_Shortcuts_StartMenu => ResourceManager.GetString("Common.Shortcuts.StartMenu", resourceCulture);

	public static string Common_Sober => ResourceManager.GetString("Common.Sober", resourceCulture);

	public static string Common_Studio => ResourceManager.GetString("Common.Studio", resourceCulture);

	public static string Common_SystemDefault => ResourceManager.GetString("Common.SystemDefault", resourceCulture);

	public static string Common_Template => ResourceManager.GetString("Common.Template", resourceCulture);

	public static string Common_Timestamp => ResourceManager.GetString("Common.Timestamp", resourceCulture);

	public static string Common_Total => ResourceManager.GetString("Common.Total", resourceCulture);

	public static string Common_Unknown => ResourceManager.GetString("Common.Unknown", resourceCulture);

	public static string Common_Update => ResourceManager.GetString("Common.Update", resourceCulture);

	public static string Common_Value => ResourceManager.GetString("Common.Value", resourceCulture);

	public static string Common_Version => ResourceManager.GetString("Common.Version", resourceCulture);

	public static string Common_VersionGuid => ResourceManager.GetString("Common.VersionGuid", resourceCulture);

	public static string Common_Yes => ResourceManager.GetString("Common.Yes", resourceCulture);

	public static string ContextMenu_CloseRoblox => ResourceManager.GetString("ContextMenu.CloseRoblox", resourceCulture);

	public static string ContextMenu_CopyDeeplinkInvite => ResourceManager.GetString("ContextMenu.CopyDeeplinkInvite", resourceCulture);

	public static string ContextMenu_GameHistory_Description => ResourceManager.GetString("ContextMenu.GameHistory.Description", resourceCulture);

	public static string ContextMenu_GameHistory_Rejoin => ResourceManager.GetString("ContextMenu.GameHistory.Rejoin", resourceCulture);

	public static string ContextMenu_GameHistory_Title => ResourceManager.GetString("ContextMenu.GameHistory.Title", resourceCulture);

	public static string ContextMenu_ServerDetails_Notification_Text => ResourceManager.GetString("ContextMenu.ServerDetails.Notification.Text", resourceCulture);

	public static string ContextMenu_ServerDetails_Notification_Text_ServerID => ResourceManager.GetString("ContextMenu.ServerDetails.Notification.Text.ServerID", resourceCulture);

	public static string ContextMenu_ServerInformation_AccessCode => ResourceManager.GetString("ContextMenu.ServerInformation.AccessCode", resourceCulture);

	public static string ContextMenu_ServerInformation_CopyAccessCode => ResourceManager.GetString("ContextMenu.ServerInformation.CopyAccessCode", resourceCulture);

	public static string ContextMenu_ServerInformation_CopyInstanceId => ResourceManager.GetString("ContextMenu.ServerInformation.CopyInstanceId", resourceCulture);

	public static string ContextMenu_ServerInformation_InstanceId => ResourceManager.GetString("ContextMenu.ServerInformation.InstanceId", resourceCulture);

	public static string ContextMenu_ServerInformation_Location => ResourceManager.GetString("ContextMenu.ServerInformation.Location", resourceCulture);

	public static string ContextMenu_ServerInformation_Notification_Title_Private => ResourceManager.GetString("ContextMenu.ServerInformation.Notification.Title.Private", resourceCulture);

	public static string ContextMenu_ServerInformation_Notification_Title_Public => ResourceManager.GetString("ContextMenu.ServerInformation.Notification.Title.Public", resourceCulture);

	public static string ContextMenu_ServerInformation_Notification_Title_Reserved => ResourceManager.GetString("ContextMenu.ServerInformation.Notification.Title.Reserved", resourceCulture);

	public static string ContextMenu_ServerInformation_NotInAServer => ResourceManager.GetString("ContextMenu.ServerInformation.NotInAServer", resourceCulture);

	public static string ContextMenu_ServerInformation_Title => ResourceManager.GetString("ContextMenu.ServerInformation.Title", resourceCulture);

	public static string ContextMenu_ServerInformation_Type => ResourceManager.GetString("ContextMenu.ServerInformation.Type", resourceCulture);

	public static string ContextMenu_ServerInformation_Uptime => ResourceManager.GetString("ContextMenu.ServerInformation.Uptime", resourceCulture);

	public static string CustomTheme_Add_Errors_FileNotZip => ResourceManager.GetString("CustomTheme.Add.Errors.FileNotZip", resourceCulture);

	public static string CustomTheme_Add_Errors_NameEmpty => ResourceManager.GetString("CustomTheme.Add.Errors.NameEmpty", resourceCulture);

	public static string CustomTheme_Add_Errors_NameIllegalCharacters => ResourceManager.GetString("CustomTheme.Add.Errors.NameIllegalCharacters", resourceCulture);

	public static string CustomTheme_Add_Errors_NameReserved => ResourceManager.GetString("CustomTheme.Add.Errors.NameReserved", resourceCulture);

	public static string CustomTheme_Add_Errors_NameTaken => ResourceManager.GetString("CustomTheme.Add.Errors.NameTaken", resourceCulture);

	public static string CustomTheme_Add_Errors_Unknown => ResourceManager.GetString("CustomTheme.Add.Errors.Unknown", resourceCulture);

	public static string CustomTheme_Add_Errors_ZipInvalidData => ResourceManager.GetString("CustomTheme.Add.Errors.ZipInvalidData", resourceCulture);

	public static string CustomTheme_Add_Errors_ZipMissingThemeFile => ResourceManager.GetString("CustomTheme.Add.Errors.ZipMissingThemeFile", resourceCulture);

	public static string CustomTheme_DefaultName => ResourceManager.GetString("CustomTheme.DefaultName", resourceCulture);

	public static string CustomTheme_Editor_ConfirmSave => ResourceManager.GetString("CustomTheme.Editor.ConfirmSave", resourceCulture);

	public static string CustomTheme_Editor_Errors_PreviewFailed => ResourceManager.GetString("CustomTheme.Editor.Errors.PreviewFailed", resourceCulture);

	public static string CustomTheme_Editor_OpenThemeDirectory => ResourceManager.GetString("CustomTheme.Editor.OpenThemeDirectory", resourceCulture);

	public static string CustomTheme_Editor_Save_Success_Description => ResourceManager.GetString("CustomTheme.Editor.Save.Success.Description", resourceCulture);

	public static string CustomTheme_Editor_Title => ResourceManager.GetString("CustomTheme.Editor.Title", resourceCulture);

	public static string CustomTheme_Errors_DialogAlreadyInitialised => ResourceManager.GetString("CustomTheme.Errors.DialogAlreadyInitialised", resourceCulture);

	public static string CustomTheme_Errors_ElementAttributeBlacklistedUriScheme => ResourceManager.GetString("CustomTheme.Errors.ElementAttributeBlacklistedUriScheme", resourceCulture);

	public static string CustomTheme_Errors_ElementAttributeConversionError => ResourceManager.GetString("CustomTheme.Errors.ElementAttributeConversionError", resourceCulture);

	public static string CustomTheme_Errors_ElementAttributeInvalidType => ResourceManager.GetString("CustomTheme.Errors.ElementAttributeInvalidType", resourceCulture);

	public static string CustomTheme_Errors_ElementAttributeMissing => ResourceManager.GetString("CustomTheme.Errors.ElementAttributeMissing", resourceCulture);

	public static string CustomTheme_Errors_ElementAttributeMissingChild => ResourceManager.GetString("CustomTheme.Errors.ElementAttributeMissingChild", resourceCulture);

	public static string CustomTheme_Errors_ElementAttributeMultipleChildren => ResourceManager.GetString("CustomTheme.Errors.ElementAttributeMultipleChildren", resourceCulture);

	public static string CustomTheme_Errors_ElementAttributeMultipleDefinitions => ResourceManager.GetString("CustomTheme.Errors.ElementAttributeMultipleDefinitions", resourceCulture);

	public static string CustomTheme_Errors_ElementAttributeMustBeLargerThanMin => ResourceManager.GetString("CustomTheme.Errors.ElementAttributeMustBeLargerThanMin", resourceCulture);

	public static string CustomTheme_Errors_ElementAttributeMustBeSmallerThanMax => ResourceManager.GetString("CustomTheme.Errors.ElementAttributeMustBeSmallerThanMax", resourceCulture);

	public static string CustomTheme_Errors_ElementAttributeParseError => ResourceManager.GetString("CustomTheme.Errors.ElementAttributeParseError", resourceCulture);

	public static string CustomTheme_Errors_ElementAttributeParseErrorNull => ResourceManager.GetString("CustomTheme.Errors.ElementAttributeParseErrorNull", resourceCulture);

	public static string CustomTheme_Errors_ElementInvalidChild => ResourceManager.GetString("CustomTheme.Errors.ElementInvalidChild", resourceCulture);

	public static string CustomTheme_Errors_ElementMultipleChildren => ResourceManager.GetString("CustomTheme.Errors.ElementMultipleChildren", resourceCulture);

	public static string CustomTheme_Errors_ElementTypeCreationFailed => ResourceManager.GetString("CustomTheme.Errors.ElementTypeCreationFailed", resourceCulture);

	public static string CustomTheme_Errors_FileNotFound => ResourceManager.GetString("CustomTheme.Errors.FileNotFound", resourceCulture);

	public static string CustomTheme_Errors_InvalidRoot => ResourceManager.GetString("CustomTheme.Errors.InvalidRoot", resourceCulture);

	public static string CustomTheme_Errors_NoThemeSelected => ResourceManager.GetString("CustomTheme.Errors.NoThemeSelected", resourceCulture);

	public static string CustomTheme_Errors_SetupFailed => ResourceManager.GetString("CustomTheme.Errors.SetupFailed", resourceCulture);

	public static string CustomTheme_Errors_TooManyElements => ResourceManager.GetString("CustomTheme.Errors.TooManyElements", resourceCulture);

	public static string CustomTheme_Errors_UnknownElement => ResourceManager.GetString("CustomTheme.Errors.UnknownElement", resourceCulture);

	public static string CustomTheme_Errors_UnknownEnumValue => ResourceManager.GetString("CustomTheme.Errors.UnknownEnumValue", resourceCulture);

	public static string CustomTheme_Errors_VersionNotNumber => ResourceManager.GetString("CustomTheme.Errors.VersionNotNumber", resourceCulture);

	public static string CustomTheme_Errors_VersionNotRecognised => ResourceManager.GetString("CustomTheme.Errors.VersionNotRecognised", resourceCulture);

	public static string CustomTheme_Errors_VersionNotSet => ResourceManager.GetString("CustomTheme.Errors.VersionNotSet", resourceCulture);

	public static string CustomTheme_Errors_VersionNotSupported => ResourceManager.GetString("CustomTheme.Errors.VersionNotSupported", resourceCulture);

	public static string CustomTheme_Errors_XMLParseFailed => ResourceManager.GetString("CustomTheme.Errors.XMLParseFailed", resourceCulture);

	public static string CustomTheme_Templates_Blank_MoreExamples => ResourceManager.GetString("CustomTheme.Templates.Blank.MoreExamples", resourceCulture);

	public static string CustomTheme_Templates_Blank_UIElements => ResourceManager.GetString("CustomTheme.Templates.Blank.UIElements", resourceCulture);

	public static string CustomTheme_Templates_Simple_MoreExamples => ResourceManager.GetString("CustomTheme.Templates.Simple.MoreExamples", resourceCulture);

	public static string Dialog_AddFastFlag_Title => ResourceManager.GetString("Dialog.AddFastFlag.Title", resourceCulture);

	public static string Dialog_AlreadyRunning_Uninstaller => ResourceManager.GetString("Dialog.AlreadyRunning.Uninstaller", resourceCulture);

	public static string Dialog_Bloxshade_Setting => ResourceManager.GetString("Dialog.Bloxshade.Setting", resourceCulture);

	public static string Dialog_Bloxshade_ThankYou => ResourceManager.GetString("Dialog.Bloxshade.ThankYou", resourceCulture);

	public static string Dialog_CannotCreateShortcuts => ResourceManager.GetString("Dialog.CannotCreateShortcuts", resourceCulture);

	public static string Dialog_Connectivity_BadConnection => ResourceManager.GetString("Dialog.Connectivity.BadConnection", resourceCulture);

	public static string Dialog_Connectivity_MatchmakingFailed => ResourceManager.GetString("Dialog.Connectivity.MatchmakingFailed", resourceCulture);

	public static string Dialog_Connectivity_MoreInfo => ResourceManager.GetString("Dialog.Connectivity.MoreInfo", resourceCulture);

	public static string Dialog_Connectivity_RobloxDown => ResourceManager.GetString("Dialog.Connectivity.RobloxDown", resourceCulture);

	public static string Dialog_Connectivity_RobloxUpgradeNeeded => ResourceManager.GetString("Dialog.Connectivity.RobloxUpgradeNeeded", resourceCulture);

	public static string Dialog_Connectivity_RobloxUpgradeSkip => ResourceManager.GetString("Dialog.Connectivity.RobloxUpgradeSkip", resourceCulture);

	public static string Dialog_Connectivity_Title => ResourceManager.GetString("Dialog.Connectivity.Title", resourceCulture);

	public static string Dialog_Connectivity_TryAgainLater => ResourceManager.GetString("Dialog.Connectivity.TryAgainLater", resourceCulture);

	public static string Dialog_Connectivity_UnableToConnect => ResourceManager.GetString("Dialog.Connectivity.UnableToConnect", resourceCulture);

	public static string Dialog_Connectivity_UnableToDownload => ResourceManager.GetString("Dialog.Connectivity.UnableToDownload", resourceCulture);

	public static string Dialog_Connectivity_UnableToDownloadReason => ResourceManager.GetString("Dialog.Connectivity.UnableToDownloadReason", resourceCulture);

	public static string Dialog_Exception_CopyLog => ResourceManager.GetString("Dialog.Exception.CopyLog", resourceCulture);

	public static string Dialog_Exception_CopyLogContents => ResourceManager.GetString("Dialog.Exception.CopyLogContents", resourceCulture);

	public static string Dialog_Exception_Info_1 => ResourceManager.GetString("Dialog.Exception.Info.1", resourceCulture);

	public static string Dialog_Exception_Info_2 => ResourceManager.GetString("Dialog.Exception.Info.2", resourceCulture);

	public static string Dialog_Exception_Info_2_Alt => ResourceManager.GetString("Dialog.Exception.Info.2.Alt", resourceCulture);

	public static string Dialog_Exception_Report => ResourceManager.GetString("Dialog.Exception.Report", resourceCulture);

	public static string Dialog_Exception_Title => ResourceManager.GetString("Dialog.Exception.Title", resourceCulture);

	public static string Dialog_IconLoadFailed => ResourceManager.GetString("Dialog.IconLoadFailed", resourceCulture);

	public static string Dialog_LanguageSelector_Header => ResourceManager.GetString("Dialog.LanguageSelector.Header", resourceCulture);

	public static string Dialog_LanguageSelector_Subtext => ResourceManager.GetString("Dialog.LanguageSelector.Subtext", resourceCulture);

	public static string Dialog_PlayerError_Crash => ResourceManager.GetString("Dialog.PlayerError.Crash", resourceCulture);

	public static string Dialog_PlayerError_FailedLaunch => ResourceManager.GetString("Dialog.PlayerError.FailedLaunch", resourceCulture);

	public static string Dialog_PlayerError_HelpInformation => ResourceManager.GetString("Dialog.PlayerError.HelpInformation", resourceCulture);

	public static string Dialog_RegistryWriteError => ResourceManager.GetString("Dialog.RegistryWriteError", resourceCulture);

	public static string Enums_AppStoragePresets_RobloxTheme_Dark => ResourceManager.GetString("Enums.AppStoragePresets.RobloxTheme.Dark", resourceCulture);

	public static string Enums_AppStoragePresets_RobloxTheme_Default => ResourceManager.GetString("Enums.AppStoragePresets.RobloxTheme.Default", resourceCulture);

	public static string Enums_AppStoragePresets_RobloxTheme_Light => ResourceManager.GetString("Enums.AppStoragePresets.RobloxTheme.Light", resourceCulture);

	public static string Enums_BackgroundMode_Gradient => ResourceManager.GetString("Enums.BackgroundMode.Gradient", resourceCulture);

	public static string Enums_BackgroundMode_Image => ResourceManager.GetString("Enums.BackgroundMode.Image", resourceCulture);

	public static string Enums_BackgroundStretch_Fill => ResourceManager.GetString("Enums.BackgroundStretch.Fill", resourceCulture);

	public static string Enums_BackgroundStretch_None => ResourceManager.GetString("Enums.BackgroundStretch.None", resourceCulture);

	public static string Enums_BackgroundStretch_Uniform => ResourceManager.GetString("Enums.BackgroundStretch.Uniform", resourceCulture);

	public static string Enums_BackgroundStretch_UniformToFill => ResourceManager.GetString("Enums.BackgroundStretch.UniformToFill", resourceCulture);

	public static string Enums_BootstrapperIcon_IconEarly2015 => ResourceManager.GetString("Enums.BootstrapperIcon.IconEarly2015", resourceCulture);

	public static string Enums_BootstrapperIcon_IconMerostrapClassic => ResourceManager.GetString("Enums.BootstrapperIcon.None", resourceCulture);

	public static string Enums_BootstrapperIcon_IconLate2015 => ResourceManager.GetString("Enums.BootstrapperIcon.IconLate2015", resourceCulture);

	public static string Enums_BootstrapperStyle_ByfronDialog => ResourceManager.GetString("Enums.BootstrapperStyle.ByfronDialog", resourceCulture);

	public static string Enums_BootstrapperStyle_ClassicFluentDialog => ResourceManager.GetString("Enums.BootstrapperStyle.ClassicFluentDialog", resourceCulture);

	public static string Enums_BootstrapperStyle_CustomDialog => ResourceManager.GetString("Enums.BootstrapperStyle.CustomDialog", resourceCulture);

	public static string Enums_BootstrapperStyle_FluentAeroDialog => ResourceManager.GetString("Enums.BootstrapperStyle.FluentAeroDialog", resourceCulture);

	public static string Enums_BootstrapperStyle_FluentDialog => ResourceManager.GetString("Enums.BootstrapperStyle.FluentDialog", resourceCulture);

	public static string Enums_BootstrapperStyle_ModernDialog => ResourceManager.GetString("Enums.BootstrapperStyle.ModernDialog", resourceCulture);

	public static string Enums_BootstrapperStyle_TwentyFiveDialog => ResourceManager.GetString("Enums.BootstrapperStyle.TwentyFiveDialog", resourceCulture);

	public static string Enums_CleanerOptions_Never => ResourceManager.GetString("Enums.CleanerOptions.Never", resourceCulture);

	public static string Enums_CleanerOptions_OneDay => ResourceManager.GetString("Enums.CleanerOptions.OneDay", resourceCulture);

	public static string Enums_CleanerOptions_OneMonth => ResourceManager.GetString("Enums.CleanerOptions.OneMonth", resourceCulture);

	public static string Enums_CleanerOptions_OneWeek => ResourceManager.GetString("Enums.CleanerOptions.OneWeek", resourceCulture);

	public static string Enums_CleanerOptions_TwoMonths => ResourceManager.GetString("Enums.CleanerOptions.TwoMonths", resourceCulture);

	public static string Enums_CopyFormatMode_Format1 => ResourceManager.GetString("Enums.CopyFormatMode.Format1", resourceCulture);

	public static string Enums_CopyFormatMode_Format2 => ResourceManager.GetString("Enums.CopyFormatMode.Format2", resourceCulture);

	public static string Enums_CopyFormatMode_Format3 => ResourceManager.GetString("Enums.CopyFormatMode.Format3", resourceCulture);

	public static string Enums_CopyFormatMode_Format4 => ResourceManager.GetString("Enums.CopyFormatMode.Format4", resourceCulture);

	public static string Enums_CursorType_BlackAndWhiteDot => ResourceManager.GetString("Enums.CursorType.BlackAndWhiteDot", resourceCulture);

	public static string Enums_CursorType_From2006 => ResourceManager.GetString("Enums.CursorType.From2006", resourceCulture);

	public static string Enums_CursorType_From2013 => ResourceManager.GetString("Enums.CursorType.From2013", resourceCulture);

	public static string Enums_CursorType_PurpleCross => ResourceManager.GetString("Enums.CursorType.PurpleCross", resourceCulture);

	public static string Enums_CustomThemeTemplate_Blank => ResourceManager.GetString("Enums.CustomThemeTemplate.Blank", resourceCulture);

	public static string Enums_CustomThemeTemplate_Simple => ResourceManager.GetString("Enums.CustomThemeTemplate.Simple", resourceCulture);

	public static string Enums_CycleFrequency_Days => ResourceManager.GetString("Enums.CycleFrequency.Days", resourceCulture);

	public static string Enums_CycleFrequency_EveryLaunch => ResourceManager.GetString("Enums.CycleFrequency.EveryLaunch", resourceCulture);

	public static string Enums_CycleFrequency_Hours => ResourceManager.GetString("Enums.CycleFrequency.Hours", resourceCulture);

	public static string Enums_CycleFrequency_Minutes => ResourceManager.GetString("Enums.CycleFrequency.Minutes", resourceCulture);

	public static string Enums_EmojiType_Catmoji => ResourceManager.GetString("Enums.EmojiType.Catmoji", resourceCulture);

	public static string Enums_EmojiType_Default => ResourceManager.GetString("Enums.EmojiType.Default", resourceCulture);

	public static string Enums_EmojiType_Windows10 => ResourceManager.GetString("Enums.EmojiType.Windows10", resourceCulture);

	public static string Enums_EmojiType_Windows11 => ResourceManager.GetString("Enums.EmojiType.Windows11", resourceCulture);

	public static string Enums_EmojiType_Windows8 => ResourceManager.GetString("Enums.EmojiType.Windows8", resourceCulture);

	public static string Enums_FlagPresets_RenderingMode_D3D11 => ResourceManager.GetString("Enums.FlagPresets.RenderingMode.D3D11", resourceCulture);

	public static string Enums_FlagPresets_RenderingMode_Direct3D => ResourceManager.GetString("Enums.FlagPresets.RenderingMode.Direct3D", resourceCulture);

	public static string Enums_FlagPresets_RenderingMode_OpenGL => ResourceManager.GetString("Enums.FlagPresets.RenderingMode.OpenGL", resourceCulture);

	public static string Enums_FlagPresets_RenderingMode_Vulkan => ResourceManager.GetString("Enums.FlagPresets.RenderingMode.Vulkan", resourceCulture);

	public static string Enums_FlagPresets_TextureQuality_Level0 => ResourceManager.GetString("Enums.FlagPresets.TextureQuality.Level0", resourceCulture);

	public static string Enums_FlagPresets_TextureQuality_Level1 => ResourceManager.GetString("Enums.FlagPresets.TextureQuality.Level1", resourceCulture);

	public static string Enums_FlagPresets_TextureQuality_Level2 => ResourceManager.GetString("Enums.FlagPresets.TextureQuality.Level2", resourceCulture);

	public static string Enums_FlagPresets_TextureQuality_Level3 => ResourceManager.GetString("Enums.FlagPresets.TextureQuality.Level3", resourceCulture);

	public static string Enums_FontSize_x1 => ResourceManager.GetString("Enums.FontSize.x1", resourceCulture);

	public static string Enums_FontSize_x2 => ResourceManager.GetString("Enums.FontSize.x2", resourceCulture);

	public static string Enums_FontSize_x3 => ResourceManager.GetString("Enums.FontSize.x3", resourceCulture);

	public static string Enums_FontSize_x4 => ResourceManager.GetString("Enums.FontSize.x4", resourceCulture);

	public static string Enums_PlayerListLayOut_x0 => ResourceManager.GetString("Enums.PlayerListLayOut.x0", resourceCulture);

	public static string Enums_PlayerListLayOut_x1 => ResourceManager.GetString("Enums.PlayerListLayOut.x1", resourceCulture);

	public static string Enums_QualityLevel_Level1 => ResourceManager.GetString("Enums.QualityLevel.Level1", resourceCulture);

	public static string Enums_QualityLevel_Level10 => ResourceManager.GetString("Enums.QualityLevel.Level10", resourceCulture);

	public static string Enums_QualityLevel_Level11 => ResourceManager.GetString("Enums.QualityLevel.Level11", resourceCulture);

	public static string Enums_QualityLevel_Level12 => ResourceManager.GetString("Enums.QualityLevel.Level12", resourceCulture);

	public static string Enums_QualityLevel_Level13 => ResourceManager.GetString("Enums.QualityLevel.Level13", resourceCulture);

	public static string Enums_QualityLevel_Level14 => ResourceManager.GetString("Enums.QualityLevel.Level14", resourceCulture);

	public static string Enums_QualityLevel_Level15 => ResourceManager.GetString("Enums.QualityLevel.Level15", resourceCulture);

	public static string Enums_QualityLevel_Level16 => ResourceManager.GetString("Enums.QualityLevel.Level16", resourceCulture);

	public static string Enums_QualityLevel_Level17 => ResourceManager.GetString("Enums.QualityLevel.Level17", resourceCulture);

	public static string Enums_QualityLevel_Level18 => ResourceManager.GetString("Enums.QualityLevel.Level18", resourceCulture);

	public static string Enums_QualityLevel_Level19 => ResourceManager.GetString("Enums.QualityLevel.Level19", resourceCulture);

	public static string Enums_QualityLevel_Level2 => ResourceManager.GetString("Enums.QualityLevel.Level2", resourceCulture);

	public static string Enums_QualityLevel_Level20 => ResourceManager.GetString("Enums.QualityLevel.Level20", resourceCulture);

	public static string Enums_QualityLevel_Level21 => ResourceManager.GetString("Enums.QualityLevel.Level21", resourceCulture);

	public static string Enums_QualityLevel_Level3 => ResourceManager.GetString("Enums.QualityLevel.Level3", resourceCulture);

	public static string Enums_QualityLevel_Level4 => ResourceManager.GetString("Enums.QualityLevel.Level4", resourceCulture);

	public static string Enums_QualityLevel_Level5 => ResourceManager.GetString("Enums.QualityLevel.Level5", resourceCulture);

	public static string Enums_QualityLevel_Level6 => ResourceManager.GetString("Enums.QualityLevel.Level6", resourceCulture);

	public static string Enums_QualityLevel_Level7 => ResourceManager.GetString("Enums.QualityLevel.Level7", resourceCulture);

	public static string Enums_QualityLevel_Level8 => ResourceManager.GetString("Enums.QualityLevel.Level8", resourceCulture);

	public static string Enums_QualityLevel_Level9 => ResourceManager.GetString("Enums.QualityLevel.Level9", resourceCulture);

	public static string Enums_RenderingMode_DefaultDirect => ResourceManager.GetString("Enums.RenderingMode.DefaultDirect", resourceCulture);

	public static string Enums_RenderingMode_DefaultMetal => ResourceManager.GetString("Enums.RenderingMode.DefaultMetal", resourceCulture);

	public static string Enums_ServerType_Private => ResourceManager.GetString("Enums.ServerType.Private", resourceCulture);

	public static string Enums_ServerType_Public => ResourceManager.GetString("Enums.ServerType.Public", resourceCulture);

	public static string Enums_ServerType_Reserved => ResourceManager.GetString("Enums.ServerType.Reserved", resourceCulture);

	public static string Enums_TextureQuality_Default => ResourceManager.GetString("Enums.TextureQuality.Default", resourceCulture);

	public static string Enums_TextureQuality_Low => ResourceManager.GetString("Enums.TextureQuality.Low", resourceCulture);

	public static string Enums_TextureQuality_Lowest => ResourceManager.GetString("Enums.TextureQuality.Lowest", resourceCulture);

	public static string Enums_TextureQuality_Medium => ResourceManager.GetString("Enums.TextureQuality.Medium", resourceCulture);

	public static string Enums_Theme_Blue => ResourceManager.GetString("Enums.Theme.Blue", resourceCulture);

	public static string Enums_Theme_Dark => ResourceManager.GetString("Enums.Theme.Dark", resourceCulture);

	public static string Enums_Theme_Merostrap => ResourceManager.GetString("Enums.Theme.Merostrap", resourceCulture);

	public static string Enums_Theme_Green => ResourceManager.GetString("Enums.Theme.Green", resourceCulture);

	public static string Enums_Theme_Light => ResourceManager.GetString("Enums.Theme.Light", resourceCulture);

	public static string Enums_Theme_Orange => ResourceManager.GetString("Enums.Theme.Orange", resourceCulture);

	public static string Enums_Theme_Pink => ResourceManager.GetString("Enums.Theme.Pink", resourceCulture);

	public static string Enums_Theme_Purple => ResourceManager.GetString("Enums.Theme.Purple", resourceCulture);

	public static string Enums_TrayDoubleClickAction_GameHistory => ResourceManager.GetString("Enums.TrayDoubleClickAction.GameHistory", resourceCulture);

	public static string Enums_TrayDoubleClickAction_None => ResourceManager.GetString("Enums.TrayDoubleClickAction.None", resourceCulture);

	public static string Enums_TrayDoubleClickAction_ServerInfo => ResourceManager.GetString("Enums.TrayDoubleClickAction.ServerInfo", resourceCulture);

	public static string FileTypes_ZipArchive => ResourceManager.GetString("FileTypes.ZipArchive", resourceCulture);

	public static string InstallChecker_Updated => ResourceManager.GetString("InstallChecker.Updated", resourceCulture);

	public static string InstallChecker_VersionDifferentThanInstalled => ResourceManager.GetString("InstallChecker.VersionDifferentThanInstalled", resourceCulture);

	public static string InstallChecker_VersionLessThanInstalled => ResourceManager.GetString("InstallChecker.VersionLessThanInstalled", resourceCulture);

	public static string JsonManager_FastFlagsLoadFailed => ResourceManager.GetString("JsonManager.FastFlagsLoadFailed", resourceCulture);

	public static string JsonManager_SettingsLoadFailed => ResourceManager.GetString("JsonManager.SettingsLoadFailed", resourceCulture);

	public static string LaunchMenu_LaunchRoblox => ResourceManager.GetString("LaunchMenu.LaunchRoblox", resourceCulture);

	public static string LaunchMenu_LaunchRobloxStudio => ResourceManager.GetString("LaunchMenu.LaunchRobloxStudio", resourceCulture);

	public static string Logger_NoWriteMode => ResourceManager.GetString("Logger.NoWriteMode", resourceCulture);

	public static string Menu_About_BuildInfo => ResourceManager.GetString("Menu.About.BuildInfo", resourceCulture);

	public static string Menu_About_CommitHash => ResourceManager.GetString("Menu.About.CommitHash", resourceCulture);

	public static string Menu_About_CommitRef => ResourceManager.GetString("Menu.About.CommitRef", resourceCulture);

	public static string Menu_About_Contributors => ResourceManager.GetString("Menu.About.Contributors", resourceCulture);

	public static string Menu_About_Contributors_Code => ResourceManager.GetString("Menu.About.Contributors.Code", resourceCulture);

	public static string Menu_About_Contributors_Description => ResourceManager.GetString("Menu.About.Contributors.Description", resourceCulture);

	public static string Menu_About_Contributors_Insipirations => ResourceManager.GetString("Menu.About.Contributors.Insipirations", resourceCulture);

	public static string Menu_About_Description => ResourceManager.GetString("Menu.About.Description", resourceCulture);

	public static string Menu_About_DiscordServer => ResourceManager.GetString("Menu.About.DiscordServer", resourceCulture);

	public static string Menu_About_GithubRepository => ResourceManager.GetString("Menu.About.GithubRepository", resourceCulture);

	public static string Menu_About_HelpInformation => ResourceManager.GetString("Menu.About.HelpInformation", resourceCulture);

	public static string Menu_About_Licenses_Apache => ResourceManager.GetString("Menu.About.Licenses.Apache", resourceCulture);

	public static string Menu_About_Licenses_MIT => ResourceManager.GetString("Menu.About.Licenses.MIT", resourceCulture);

	public static string Menu_About_ReportIssue => ResourceManager.GetString("Menu.About.ReportIssue", resourceCulture);

	public static string Menu_About_Title => ResourceManager.GetString("Menu.About.Title", resourceCulture);

	public static string Menu_About_Version => ResourceManager.GetString("Menu.About.Version", resourceCulture);

	public static string Menu_AccountSelector_AccountRemoved => ResourceManager.GetString("Menu.AccountSelector.AccountRemoved", resourceCulture);

	public static string Menu_AccountSelector_AddAccount => ResourceManager.GetString("Menu.AccountSelector.AddAccount", resourceCulture);

	public static string Menu_AccountSelector_AlreadyLoggedIn => ResourceManager.GetString("Menu.AccountSelector.AlreadyLoggedIn", resourceCulture);

	public static string Menu_AccountSelector_AskToAddAccount => ResourceManager.GetString("Menu.AccountSelector.AskToAddAccount", resourceCulture);

	public static string Menu_AccountSelector_Login_LocalCookie => ResourceManager.GetString("Menu.AccountSelector.Login.LocalCookie", resourceCulture);

	public static string Menu_AccountSelector_NotLoggedIn => ResourceManager.GetString("Menu.AccountSelector.NotLoggedIn", resourceCulture);

	public static string Menu_AccountSelector_Presence_InGame => ResourceManager.GetString("Menu.AccountSelector.Presence.InGame", resourceCulture);

	public static string Menu_AccountSelector_Presence_InStudio => ResourceManager.GetString("Menu.AccountSelector.Presence.InStudio", resourceCulture);

	public static string Menu_AccountSelector_Presence_Offline => ResourceManager.GetString("Menu.AccountSelector.Presence.Offline", resourceCulture);

	public static string Menu_AccountSelector_Presence_Online => ResourceManager.GetString("Menu.AccountSelector.Presence.Online", resourceCulture);

	public static string Menu_AlreadyRunning_Caption => ResourceManager.GetString("Menu.AlreadyRunning.Caption", resourceCulture);

	public static string Menu_AlreadyRunning_Title => ResourceManager.GetString("Menu.AlreadyRunning.Title", resourceCulture);

	public static string Menu_Appearance_BackgroundMode => ResourceManager.GetString("Menu.Appearance.BackgroundMode", resourceCulture);

	public static string Menu_Appearance_Bootstrapper_Description => ResourceManager.GetString("Menu.Appearance.Bootstrapper.Description", resourceCulture);

	public static string Menu_Appearance_Custom_Theme_Description => ResourceManager.GetString("Menu.Appearance.Custom.Theme.Description", resourceCulture);

	public static string Menu_Appearance_Custom_Theme_Title => ResourceManager.GetString("Menu.Appearance.Custom.Theme.Title", resourceCulture);

	public static string Menu_Appearance_CustomisationTitle_Description => ResourceManager.GetString("Menu.Appearance.CustomisationTitle.Description", resourceCulture);

	public static string Menu_Appearance_CustomisationTitle_Title => ResourceManager.GetString("Menu.Appearance.CustomisationTitle.Title", resourceCulture);

	public static string Menu_Appearance_CustomThemes_DeleteFailed => ResourceManager.GetString("Menu.Appearance.CustomThemes.DeleteFailed", resourceCulture);

	public static string Menu_Appearance_CustomThemes_NoneSelected => ResourceManager.GetString("Menu.Appearance.CustomThemes.NoneSelected", resourceCulture);

	public static string Menu_Appearance_Description => ResourceManager.GetString("Menu.Appearance.Description", resourceCulture);

	public static string Menu_Appearance_Frequency => ResourceManager.GetString("Menu.Appearance.Frequency", resourceCulture);

	public static string Menu_Appearance_Merostrap_Description => ResourceManager.GetString("Menu.Appearance.Merostrap.Description", resourceCulture);

	public static string Menu_Appearance_Icon_Description => ResourceManager.GetString("Menu.Appearance.Icon.Description", resourceCulture);

	public static string Menu_Appearance_Icon_Title => ResourceManager.GetString("Menu.Appearance.Icon.Title", resourceCulture);

	public static string Menu_Appearance_Interval => ResourceManager.GetString("Menu.Appearance.Interval", resourceCulture);

	public static string Menu_Appearance_Language_Description => ResourceManager.GetString("Menu.Appearance.Language.Description", resourceCulture);

	public static string Menu_Appearance_Language_Title => ResourceManager.GetString("Menu.Appearance.Language.Title", resourceCulture);

	public static string Menu_Appearance_Launcher_Description => ResourceManager.GetString("Menu.Appearance.Launcher.Description", resourceCulture);

	public static string Menu_Appearance_Launcher_Title => ResourceManager.GetString("Menu.Appearance.Launcher.Title", resourceCulture);

	public static string Menu_Appearance_Opacity => ResourceManager.GetString("Menu.Appearance.Opacity", resourceCulture);

	public static string Menu_Appearance_Preview => ResourceManager.GetString("Menu.Appearance.Preview", resourceCulture);

	public static string Menu_Appearance_ResetDefault => ResourceManager.GetString("Menu.Appearance.ResetDefault", resourceCulture);

	public static string Menu_Appearance_RobloxIcon_Description => ResourceManager.GetString("Menu.Appearance.RobloxIcon.Description", resourceCulture);

	public static string Menu_Appearance_RobloxIcon_Title => ResourceManager.GetString("Menu.Appearance.RobloxIcon.Title", resourceCulture);

	public static string Menu_Appearance_RobloxTitle_Description => ResourceManager.GetString("Menu.Appearance.RobloxTitle.Description", resourceCulture);

	public static string Menu_Appearance_RobloxTitle_Title => ResourceManager.GetString("Menu.Appearance.RobloxTitle.Title", resourceCulture);

	public static string Menu_Appearance_StretchMode => ResourceManager.GetString("Menu.Appearance.StretchMode", resourceCulture);

	public static string Menu_Appearance_ThemeCycling_Description => ResourceManager.GetString("Menu.Appearance.ThemeCycling.Description", resourceCulture);

	public static string Menu_Appearance_ThemeCycling_Title => ResourceManager.GetString("Menu.Appearance.ThemeCycling.Title", resourceCulture);

	public static string Menu_Appearance_Title => ResourceManager.GetString("Menu.Appearance.Title", resourceCulture);

	public static string Menu_Appearance_WindowManipulationAlert => ResourceManager.GetString("Menu.Appearance.WindowManipulationAlert", resourceCulture);

	public static string Menu_Appearance_WindowsBackdrop_Description => ResourceManager.GetString("Menu.Appearance.WindowsBackdrop.Description", resourceCulture);

	public static string Menu_Appearance_WindowsBackdrop_Title => ResourceManager.GetString("Menu.Appearance.WindowsBackdrop.Title", resourceCulture);

	public static string Menu_Behaviour_AllowCookieAccess_Description => ResourceManager.GetString("Menu.Behaviour.AllowCookieAccess.Description", resourceCulture);

	public static string Menu_Behaviour_AllowCookieAccess_Title => ResourceManager.GetString("Menu.Behaviour.AllowCookieAccess.Title", resourceCulture);

	public static string Menu_Behaviour_AutoUpdate_Description => ResourceManager.GetString("Menu.Behaviour.AutoUpdate.Description", resourceCulture);

	public static string Menu_Behaviour_AutoUpdate_Title => ResourceManager.GetString("Menu.Behaviour.AutoUpdate.Title", resourceCulture);

	public static string Menu_Behaviour_BackgroundUpdates_Description => ResourceManager.GetString("Menu.Behaviour.BackgroundUpdates.Description", resourceCulture);

	public static string Menu_Behaviour_BackgroundUpdates_Title => ResourceManager.GetString("Menu.Behaviour.BackgroundUpdates.Title", resourceCulture);

	public static string Menu_Behaviour_CloseCrashHandler_Description => ResourceManager.GetString("Menu.Behaviour.CloseCrashHandler.Description", resourceCulture);

	public static string Menu_Behaviour_CloseCrashHandler_Title => ResourceManager.GetString("Menu.Behaviour.CloseCrashHandler.Title", resourceCulture);

	public static string Menu_Behaviour_ConfirmLaunches_Description => ResourceManager.GetString("Menu.Behaviour.ConfirmLaunches.Description", resourceCulture);

	public static string Menu_Behaviour_ConfirmLaunches_Title => ResourceManager.GetString("Menu.Behaviour.ConfirmLaunches.Title", resourceCulture);

	public static string Menu_Behaviour_Description => ResourceManager.GetString("Menu.Behaviour.Description", resourceCulture);

	public static string Menu_Behaviour_EnableVirtualDisplay_Description => ResourceManager.GetString("Menu.Behaviour.EnableVirtualDisplay.Description", resourceCulture);

	public static string Menu_Behaviour_EnableVirtualDisplay_Title => ResourceManager.GetString("Menu.Behaviour.EnableVirtualDisplay.Title", resourceCulture);

	public static string Menu_Behaviour_ForceRobloxReinstall_Description => ResourceManager.GetString("Menu.Behaviour.ForceRobloxReinstall.Description", resourceCulture);

	public static string Menu_Behaviour_ForceRobloxReinstall_Title => ResourceManager.GetString("Menu.Behaviour.ForceRobloxReinstall.Title", resourceCulture);

	public static string Menu_Behaviour_Title => ResourceManager.GetString("Menu.Behaviour.Title", resourceCulture);

	public static string Menu_Bootstrapper_AppStorage_Description => ResourceManager.GetString("Menu.Bootstrapper.AppStorage.Description", resourceCulture);

	public static string Menu_Bootstrapper_AppStorage_Title => ResourceManager.GetString("Menu.Bootstrapper.AppStorage.Title", resourceCulture);

	public static string Menu_Bootstrapper_BestRegionAmount_Description => ResourceManager.GetString("Menu.Bootstrapper.BestRegionAmount.Description", resourceCulture);

	public static string Menu_Bootstrapper_BestRegionAmount_Title => ResourceManager.GetString("Menu.Bootstrapper.BestRegionAmount.Title", resourceCulture);

	public static string Menu_Bootstrapper_Cleaner_Age_Description => ResourceManager.GetString("Menu.Bootstrapper.Cleaner.Age.Description", resourceCulture);

	public static string Menu_Bootstrapper_Cleaner_Age_Title => ResourceManager.GetString("Menu.Bootstrapper.Cleaner.Age.Title", resourceCulture);

	public static string Menu_Bootstrapper_Cleaner_Cache_Description => ResourceManager.GetString("Menu.Bootstrapper.Cleaner.Cache.Description", resourceCulture);

	public static string Menu_Bootstrapper_Cleaner_Cache_Title => ResourceManager.GetString("Menu.Bootstrapper.Cleaner.Cache.Title", resourceCulture);

	public static string Menu_Bootstrapper_Cleaner_IncludeBloxstrap_Description => ResourceManager.GetString("Menu.Bootstrapper.Cleaner.IncludeBloxstrap.Description", resourceCulture);

	public static string Menu_Bootstrapper_Cleaner_IncludeBloxstrap_Title => ResourceManager.GetString("Menu.Bootstrapper.Cleaner.IncludeBloxstrap.Title", resourceCulture);

	public static string Menu_Bootstrapper_Cleaner_Logs_Description => ResourceManager.GetString("Menu.Bootstrapper.Cleaner.Logs.Description", resourceCulture);

	public static string Menu_Bootstrapper_Cleaner_Logs_Title => ResourceManager.GetString("Menu.Bootstrapper.Cleaner.Logs.Title", resourceCulture);

	public static string Menu_Bootstrapper_CleanUp_Description => ResourceManager.GetString("Menu.Bootstrapper.CleanUp.Description", resourceCulture);

	public static string Menu_Bootstrapper_CleanUp_Title => ResourceManager.GetString("Menu.Bootstrapper.CleanUp.Title", resourceCulture);

	public static string Menu_Bootstrapper_EnableRobloxBackgroundApp_Description => ResourceManager.GetString("Menu.Bootstrapper.EnableRobloxBackgroundApp.Description", resourceCulture);

	public static string Menu_Bootstrapper_EnableRobloxBackgroundApp_Title => ResourceManager.GetString("Menu.Bootstrapper.EnableRobloxBackgroundApp.Title", resourceCulture);

	public static string Menu_Bootstrapper_Experimental_BetterMatchmaking_Description => ResourceManager.GetString("Menu.Bootstrapper.Experimental.BetterMatchmaking.Description", resourceCulture);

	public static string Menu_Bootstrapper_Experimental_BetterMatchmaking_FollowUser => ResourceManager.GetString("Menu.Bootstrapper.Experimental.BetterMatchmaking.FollowUser", resourceCulture);

	public static string Menu_Bootstrapper_Experimental_BetterMatchmaking_Title => ResourceManager.GetString("Menu.Bootstrapper.Experimental.BetterMatchmaking.Title", resourceCulture);

	public static string Menu_Bootstrapper_MaxServerCheck_Description => ResourceManager.GetString("Menu.Bootstrapper.MaxServerCheck.Description", resourceCulture);

	public static string Menu_Bootstrapper_MaxServerCheck_Title => ResourceManager.GetString("Menu.Bootstrapper.MaxServerCheck.Title", resourceCulture);

	public static string Menu_Bootstrapper_PreferredRegion_Description => ResourceManager.GetString("Menu.Bootstrapper.PreferredRegion.Description", resourceCulture);

	public static string Menu_Bootstrapper_PreferredRegion_Title => ResourceManager.GetString("Menu.Bootstrapper.PreferredRegion.Title", resourceCulture);

	public static string Menu_Bootstrapper_RobloxTheme_Description => ResourceManager.GetString("Menu.Bootstrapper.RobloxTheme.Description", resourceCulture);

	public static string Menu_Bootstrapper_RobloxTheme_Title => ResourceManager.GetString("Menu.Bootstrapper.RobloxTheme.Title", resourceCulture);

	public static string Menu_Bootstrapper_SmallerServer_Description => ResourceManager.GetString("Menu.Bootstrapper.SmallerServer.Description", resourceCulture);

	public static string Menu_Bootstrapper_SmallerServer_Title => ResourceManager.GetString("Menu.Bootstrapper.SmallerServer.Title", resourceCulture);

	public static string Menu_Bootstrapper_SoftKey_Description => ResourceManager.GetString("Menu.Bootstrapper.SoftKey.Description", resourceCulture);

	public static string Menu_Bootstrapper_SoftKey_Title => ResourceManager.GetString("Menu.Bootstrapper.SoftKey.Title", resourceCulture);

	public static string Menu_Bootstrapper_SoftKeyProfile_Description => ResourceManager.GetString("Menu.Bootstrapper.SoftKeyProfile.Description", resourceCulture);

	public static string Menu_Bootstrapper_SoftKeyProfile_Title => ResourceManager.GetString("Menu.Bootstrapper.SoftKeyProfile.Title", resourceCulture);

	public static string Menu_BottomButtons_ExportSettings => ResourceManager.GetString("Menu.BottomButtons.ExportSettings", resourceCulture);

	public static string Menu_BottomButtons_ImportSettings => ResourceManager.GetString("Menu.BottomButtons.ImportSettings", resourceCulture);

	public static string Menu_BottomButtons_ResetSettingsToDefault => ResourceManager.GetString("Menu.BottomButtons.ResetSettingsToDefault", resourceCulture);

	public static string Menu_Channel_ChangeAction_Automatic => ResourceManager.GetString("Menu.Channel.ChangeAction.Automatic", resourceCulture);

	public static string Menu_Channel_ChangeAction_Description => ResourceManager.GetString("Menu.Channel.ChangeAction.Description", resourceCulture);

	public static string Menu_Channel_ChangeAction_Ignore => ResourceManager.GetString("Menu.Channel.ChangeAction.Ignore", resourceCulture);

	public static string Menu_Channel_ChangeAction_Prompt => ResourceManager.GetString("Menu.Channel.ChangeAction.Prompt", resourceCulture);

	public static string Menu_Channel_ChangeAction_Title => ResourceManager.GetString("Menu.Channel.ChangeAction.Title", resourceCulture);

	public static string Menu_Channel_Description => ResourceManager.GetString("Menu.Channel.Description", resourceCulture);

	public static string Menu_Channel_RobloxUpgrades => ResourceManager.GetString("Menu.Channel.RobloxUpgrades", resourceCulture);

	public static string Menu_Channel_RobloxUpgrades_Description => ResourceManager.GetString("Menu.Channel.RobloxUpgrades.Description", resourceCulture);

	public static string Menu_Channel_StaticDirectory_Description => ResourceManager.GetString("Menu.Channel.StaticDirectory.Description", resourceCulture);

	public static string Menu_Channel_StaticDirectory_Title => ResourceManager.GetString("Menu.Channel.StaticDirectory.Title", resourceCulture);

	public static string Menu_Channel_Switcher_Fetching => ResourceManager.GetString("Menu.Channel.Switcher.Fetching", resourceCulture);

	public static string Menu_Channel_Switcher_Unauthorized => ResourceManager.GetString("Menu.Channel.Switcher.Unauthorized", resourceCulture);

	public static string Menu_ColorPicker_SelectColor => ResourceManager.GetString("Menu.ColorPicker.SelectColor", resourceCulture);

	public static string Menu_CommunityModInfo_Title => ResourceManager.GetString("Menu.CommunityModInfo.Title", resourceCulture);

	public static string Menu_CommunityMods_AvatarEditor => ResourceManager.GetString("Menu.CommunityMods.AvatarEditor", resourceCulture);

	public static string Menu_CommunityMods_ColorMods => ResourceManager.GetString("Menu.CommunityMods.ColorMods", resourceCulture);

	public static string Menu_CommunityMods_Cursor => ResourceManager.GetString("Menu.CommunityMods.Cursor", resourceCulture);

	public static string Menu_CommunityMods_Description => ResourceManager.GetString("Menu.CommunityMods.Description", resourceCulture);

	public static string Menu_CommunityMods_Misc => ResourceManager.GetString("Menu.CommunityMods.Misc", resourceCulture);

	public static string Menu_CommunityMods_ModInstalled => ResourceManager.GetString("Menu.CommunityMods.ModInstalled", resourceCulture);

	public static string Menu_CommunityMods_Overwrite => ResourceManager.GetString("Menu.CommunityMods.Overwrite", resourceCulture);

	public static string Menu_CommunityMods_SearchMods => ResourceManager.GetString("Menu.CommunityMods.SearchMods", resourceCulture);

	public static string Menu_CommunityMods_SkyBox => ResourceManager.GetString("Menu.CommunityMods.SkyBox", resourceCulture);

	public static string Menu_CommunityMods_ThemeInstalled => ResourceManager.GetString("Menu.CommunityMods.ThemeInstalled", resourceCulture);

	public static string Menu_CommunityMods_Themes => ResourceManager.GetString("Menu.CommunityMods.Themes", resourceCulture);

	public static string Menu_CommunityMods_Title => ResourceManager.GetString("Menu.CommunityMods.Title", resourceCulture);

	public static string Menu_ContextMenu_CloseStudio => ResourceManager.GetString("Menu.ContextMenu.CloseStudio", resourceCulture);

	public static string Menu_ContextMenu_CloseWatcher => ResourceManager.GetString("Menu.ContextMenu.CloseWatcher", resourceCulture);

	public static string Menu_ContextMenu_NoData => ResourceManager.GetString("Menu.ContextMenu.NoData", resourceCulture);

	public static string Menu_ContextMenu_RegionJoin => ResourceManager.GetString("Menu.ContextMenu.RegionJoin", resourceCulture);

	public static string Menu_CookieState_CouldNotLoad => ResourceManager.GetString("Menu.CookieState.CouldNotLoad", resourceCulture);

	public static string Menu_CookieState_Failed => ResourceManager.GetString("Menu.CookieState.Failed", resourceCulture);

	public static string Menu_CookieState_Invalid => ResourceManager.GetString("Menu.CookieState.Invalid", resourceCulture);

	public static string Menu_CookieState_NotAllowed => ResourceManager.GetString("Menu.CookieState.NotAllowed", resourceCulture);

	public static string Menu_CookieState_NotFound => ResourceManager.GetString("Menu.CookieState.NotFound", resourceCulture);

	public static string Menu_Deployment_AutoPreReleaseUpdate_Description => ResourceManager.GetString("Menu.Deployment.AutoPreReleaseUpdate.Description", resourceCulture);

	public static string Menu_Deployment_AutoPreReleaseUpdate_Title => ResourceManager.GetString("Menu.Deployment.AutoPreReleaseUpdate.Title", resourceCulture);

	public static string Menu_Deployment_AutoUpdateSober => ResourceManager.GetString("Menu.Deployment.AutoUpdateSober", resourceCulture);

	public static string Menu_Deployment_Channel_Description => ResourceManager.GetString("Menu.Deployment.Channel.Description", resourceCulture);

	public static string Menu_Deployment_Channel_OutOfDate => ResourceManager.GetString("Menu.Deployment.Channel.OutOfDate", resourceCulture);

	public static string Menu_Deployment_DisableAnimations_Description => ResourceManager.GetString("Menu.Deployment.DisableAnimations.Description", resourceCulture);

	public static string Menu_Deployment_DisableAnimations_Title => ResourceManager.GetString("Menu.Deployment.DisableAnimations.Title", resourceCulture);

	public static string Menu_Deployment_DomainValidation => ResourceManager.GetString("Menu.Deployment.DomainValidation", resourceCulture);

	public static string Menu_Deployment_FailedToLoadChannelData => ResourceManager.GetString("Menu.Deployment.FailedToLoadChannelData", resourceCulture);

	public static string Menu_Deployment_Merostrap_Description => ResourceManager.GetString("Menu.Deployment.Merostrap.Description", resourceCulture);

	public static string Menu_Deployment_MoveInstallation => ResourceManager.GetString("Menu.Deployment.MoveInstallation", resourceCulture);

	public static string Menu_Deployment_MoveInstallation_Confirm => ResourceManager.GetString("Menu.Deployment.MoveInstallation.Confirm", resourceCulture);

	public static string Menu_Deployment_MoveInstallation_Description => ResourceManager.GetString("Menu.Deployment.MoveInstallation.Description", resourceCulture);

	public static string Menu_Deployment_MoveInstallation_Failed => ResourceManager.GetString("Menu.Deployment.MoveInstallation.Failed", resourceCulture);

	public static string Menu_Deployment_MoveInstallation_InvalidDirectory => ResourceManager.GetString("Menu.Deployment.MoveInstallation.InvalidDirectory", resourceCulture);

	public static string Menu_Deployment_MoveInstallation_SameDirectory => ResourceManager.GetString("Menu.Deployment.MoveInstallation.SameDirectory", resourceCulture);

	public static string Menu_Deployment_MoveInstallation_Success => ResourceManager.GetString("Menu.Deployment.MoveInstallation.Success", resourceCulture);

	public static string Menu_Deployment_MoveInstallation_Title => ResourceManager.GetString("Menu.Deployment.MoveInstallation.Title", resourceCulture);

	public static string Menu_Deployment_MultiThread_Description => ResourceManager.GetString("Menu.Deployment.MultiThread.Description", resourceCulture);

	public static string Menu_Deployment_MultiThread_Title => ResourceManager.GetString("Menu.Deployment.MultiThread.Title", resourceCulture);

	public static string Menu_Deployment_OverrideHash_Description => ResourceManager.GetString("Menu.Deployment.OverrideHash.Description", resourceCulture);

	public static string Menu_Deployment_OverrideHash_Title => ResourceManager.GetString("Menu.Deployment.OverrideHash.Title", resourceCulture);

	public static string Menu_Deployment_Player_Description => ResourceManager.GetString("Menu.Deployment.Player.Description", resourceCulture);

	public static string Menu_Deployment_PlayerChannel_Title => ResourceManager.GetString("Menu.Deployment.PlayerChannel.Title", resourceCulture);

	public static string Menu_Deployment_PlayerOverrideHash_Description => ResourceManager.GetString("Menu.Deployment.PlayerOverrideHash.Description", resourceCulture);

	public static string Menu_Deployment_PlayerOverrideHash_Title => ResourceManager.GetString("Menu.Deployment.PlayerOverrideHash.Title", resourceCulture);

	public static string Menu_Deployment_Studio_Description => ResourceManager.GetString("Menu.Deployment.Studio.Description", resourceCulture);

	public static string Menu_Deployment_StudioChannel_Title => ResourceManager.GetString("Menu.Deployment.StudioChannel.Title", resourceCulture);

	public static string Menu_Deployment_VersionHash_Description => ResourceManager.GetString("Menu.Deployment.VersionHash.Description", resourceCulture);

	public static string Menu_Deployment_VersionHash_Title => ResourceManager.GetString("Menu.Deployment.VersionHash.Title", resourceCulture);

	public static string Menu_Dialog_QuickSignIn_Title => ResourceManager.GetString("Menu.Dialog.QuickSignIn.Title", resourceCulture);

	public static string Menu_FastFlagEditor_AddNew => ResourceManager.GetString("Menu.FastFlagEditor.AddNew", resourceCulture);

	public static string Menu_FastFlagEditor_AlreadyExists => ResourceManager.GetString("Menu.FastFlagEditor.AlreadyExists", resourceCulture);

	public static string Menu_FastFlagEditor_CleanList => ResourceManager.GetString("Menu.FastFlagEditor.CleanList", resourceCulture);

	public static string Menu_FastFlagEditor_ConfirmDeleteAll => ResourceManager.GetString("Menu.FastFlagEditor.ConfirmDeleteAll", resourceCulture);

	public static string Menu_FastFlagEditor_ConflictingImport => ResourceManager.GetString("Menu.FastFlagEditor.ConflictingImport", resourceCulture);

	public static string Menu_FastFlagEditor_DeleteSelected => ResourceManager.GetString("Menu.FastFlagEditor.DeleteSelected", resourceCulture);

	public static string Menu_FastFlagEditor_Description => ResourceManager.GetString("Menu.FastFlagEditor.Description", resourceCulture);

	public static string Menu_FastFlagEditor_DragOverlay => ResourceManager.GetString("Menu.FastFlagEditor.DragOverlay", resourceCulture);

	public static string Menu_FastFlagEditor_Exported => ResourceManager.GetString("Menu.FastFlagEditor.Exported", resourceCulture);

	public static string Menu_FastFlagEditor_ExportJson => ResourceManager.GetString("Menu.FastFlagEditor.ExportJson", resourceCulture);

	public static string Menu_FastFlagEditor_FileExtensionWarning => ResourceManager.GetString("Menu.FastFlagEditor.FileExtensionWarning", resourceCulture);

	public static string Menu_FastFlagEditor_HaveBeenRemoved => ResourceManager.GetString("Menu.FastFlagEditor.HaveBeenRemoved", resourceCulture);

	public static string Menu_FastFlagEditor_InvalidJSON => ResourceManager.GetString("Menu.FastFlagEditor.InvalidJSON", resourceCulture);

	public static string Menu_FastFlagEditor_NoFlagDelete => ResourceManager.GetString("Menu.FastFlagEditor.NoFlagDelete", resourceCulture);

	public static string Menu_FastFlagEditor_NoFlags => ResourceManager.GetString("Menu.FastFlagEditor.NoFlags", resourceCulture);

	public static string Menu_FastFlagEditor_NoInvalid => ResourceManager.GetString("Menu.FastFlagEditor.NoInvalid", resourceCulture);

	public static string Menu_FastFlagEditor_NotInWhiteList => ResourceManager.GetString("Menu.FastFlagEditor.NotInWhiteList", resourceCulture);

	public static string Menu_FastFlagEditor_ShowPresetFlags => ResourceManager.GetString("Menu.FastFlagEditor.ShowPresetFlags", resourceCulture);

	public static string Menu_FastFlagEditor_Title => ResourceManager.GetString("Menu.FastFlagEditor.Title", resourceCulture);

	public static string Menu_FastFlagEditor_TotalFlags => ResourceManager.GetString("Menu.FastFlagEditor.TotalFlags", resourceCulture);

	public static string Menu_FastFlagEditor_WhiteList => ResourceManager.GetString("Menu.FastFlagEditor.WhiteList", resourceCulture);

	public static string Menu_FastFlags_Description => ResourceManager.GetString("Menu.FastFlags.Description", resourceCulture);

	public static string Menu_FastFlags_Editor_Description => ResourceManager.GetString("Menu.FastFlags.Editor.Description", resourceCulture);

	public static string Menu_FastFlags_ManagerEnabled_Description => ResourceManager.GetString("Menu.FastFlags.ManagerEnabled.Description", resourceCulture);

	public static string Menu_FastFlags_ManagerEnabled_Title => ResourceManager.GetString("Menu.FastFlags.ManagerEnabled.Title", resourceCulture);

	public static string Menu_FastFlags_Presets_FixDisplayScaling_Description => ResourceManager.GetString("Menu.FastFlags.Presets.FixDisplayScaling.Description", resourceCulture);

	public static string Menu_FastFlags_Presets_FixDisplayScaling_Title => ResourceManager.GetString("Menu.FastFlags.Presets.FixDisplayScaling.Title", resourceCulture);

	public static string Menu_FastFlags_Presets_GraySky_Description => ResourceManager.GetString("Menu.FastFlags.Presets.GraySky.Description", resourceCulture);

	public static string Menu_FastFlags_Presets_GraySky_Title => ResourceManager.GetString("Menu.FastFlags.Presets.GraySky.Title", resourceCulture);

	public static string Menu_FastFlags_Presets_LowPolyMeshes_Description => ResourceManager.GetString("Menu.FastFlags.Presets.LowPolyMeshes.Description", resourceCulture);

	public static string Menu_FastFlags_Presets_LowPolyMeshes_Information => ResourceManager.GetString("Menu.FastFlags.Presets.LowPolyMeshes.Information", resourceCulture);

	public static string Menu_FastFlags_Presets_LowPolyMeshes_Title => ResourceManager.GetString("Menu.FastFlags.Presets.LowPolyMeshes.Title", resourceCulture);

	public static string Menu_FastFlags_Presets_MSAA_Description => ResourceManager.GetString("Menu.FastFlags.Presets.MSAA.Description", resourceCulture);

	public static string Menu_FastFlags_Presets_MSAA_Title => ResourceManager.GetString("Menu.FastFlags.Presets.MSAA.Title", resourceCulture);

	public static string Menu_FastFlags_Presets_OverrideGraphicQuality_Description => ResourceManager.GetString("Menu.FastFlags.Presets.OverrideGraphicQuality.Description", resourceCulture);

	public static string Menu_FastFlags_Presets_OverrideGraphicQuality_Title => ResourceManager.GetString("Menu.FastFlags.Presets.OverrideGraphicQuality.Title", resourceCulture);

	public static string Menu_FastFlags_Presets_PauseVoxelizer_Description => ResourceManager.GetString("Menu.FastFlags.Presets.PauseVoxelizer.Description", resourceCulture);

	public static string Menu_FastFlags_Presets_PauseVoxelizer_Title => ResourceManager.GetString("Menu.FastFlags.Presets.PauseVoxelizer.Title", resourceCulture);

	public static string Menu_FastFlags_Presets_RemoveGrass_Description => ResourceManager.GetString("Menu.FastFlags.Presets.RemoveGrass.Description", resourceCulture);

	public static string Menu_FastFlags_Presets_RemoveGrass_Title => ResourceManager.GetString("Menu.FastFlags.Presets.RemoveGrass.Title", resourceCulture);

	public static string Menu_FastFlags_Presets_RenderingMode_Description => ResourceManager.GetString("Menu.FastFlags.Presets.RenderingMode.Description", resourceCulture);

	public static string Menu_FastFlags_Presets_RenderingMode_Title => ResourceManager.GetString("Menu.FastFlags.Presets.RenderingMode.Title", resourceCulture);

	public static string Menu_FastFlags_Presets_TextureQuality_Description => ResourceManager.GetString("Menu.FastFlags.Presets.TextureQuality.Description", resourceCulture);

	public static string Menu_FastFlags_Presets_TextureQuality_Title => ResourceManager.GetString("Menu.FastFlags.Presets.TextureQuality.Title", resourceCulture);

	public static string Menu_FastFlags_Reset_Title => ResourceManager.GetString("Menu.FastFlags.Reset.Title", resourceCulture);

	public static string Menu_FastFlags_Title => ResourceManager.GetString("Menu.FastFlags.Title", resourceCulture);

	public static string Menu_FlagProfiles_AddPlaceId => ResourceManager.GetString("Menu.FlagProfiles.AddPlaceId", resourceCulture);

	public static string Menu_FlagProfiles_ClearFlags => ResourceManager.GetString("Menu.FlagProfiles.ClearFlags", resourceCulture);

	public static string Menu_FlagProfiles_CopyFailed => ResourceManager.GetString("Menu.FlagProfiles.CopyFailed", resourceCulture);

	public static string Menu_FlagProfiles_CurrentPlaceIds => ResourceManager.GetString("Menu.FlagProfiles.CurrentPlaceIds", resourceCulture);

	public static string Menu_FlagProfiles_DeleteSelected => ResourceManager.GetString("Menu.FlagProfiles.DeleteSelected", resourceCulture);

	public static string Menu_FlagProfiles_EnterPlaceId => ResourceManager.GetString("Menu.FlagProfiles.EnterPlaceId", resourceCulture);

	public static string Menu_FlagProfiles_GetFlagsFailed => ResourceManager.GetString("Menu.FlagProfiles.GetFlagsFailed", resourceCulture);

	public static string Menu_FlagProfiles_InvalidCharacter => ResourceManager.GetString("Menu.FlagProfiles.InvalidCharacter", resourceCulture);

	public static string Menu_FlagProfiles_NameCannotBeEmpty => ResourceManager.GetString("Menu.FlagProfiles.NameCannotBeEmpty", resourceCulture);

	public static string Menu_FlagProfiles_NoProfileFound => ResourceManager.GetString("Menu.FlagProfiles.NoProfileFound", resourceCulture);

	public static string Menu_FlagProfiles_NoProfilesFound => ResourceManager.GetString("Menu.FlagProfiles.NoProfilesFound", resourceCulture);

	public static string Menu_FlagProfiles_ParseFailed => ResourceManager.GetString("Menu.FlagProfiles.ParseFailed", resourceCulture);

	public static string Menu_FlagProfiles_PlaceIdExists => ResourceManager.GetString("Menu.FlagProfiles.PlaceIdExists", resourceCulture);

	public static string Menu_FlagProfiles_PlaceIdNumeric => ResourceManager.GetString("Menu.FlagProfiles.PlaceIdNumeric", resourceCulture);

	public static string Menu_FlagProfiles_PlaceIdsTab => ResourceManager.GetString("Menu.FlagProfiles.PlaceIdsTab", resourceCulture);

	public static string Menu_FlagProfiles_PlaceIdWatermark => ResourceManager.GetString("Menu.FlagProfiles.PlaceIdWatermark", resourceCulture);

	public static string Menu_FlagProfiles_ProfileExists => ResourceManager.GetString("Menu.FlagProfiles.ProfileExists", resourceCulture);

	public static string Menu_FlagProfiles_ProfileNotFound => ResourceManager.GetString("Menu.FlagProfiles.ProfileNotFound", resourceCulture);

	public static string Menu_FlagProfiles_RemoveSelected => ResourceManager.GetString("Menu.FlagProfiles.RemoveSelected", resourceCulture);

	public static string Menu_FlagProfiles_RenameFailed => ResourceManager.GetString("Menu.FlagProfiles.RenameFailed", resourceCulture);

	public static string Menu_FlagProfiles_SelectProfile => ResourceManager.GetString("Menu.FlagProfiles.SelectProfile", resourceCulture);

	public static string Menu_FlagProfiles_SelectProfileCopy => ResourceManager.GetString("Menu.FlagProfiles.SelectProfileCopy", resourceCulture);

	public static string Menu_FlagProfiles_SelectProfileFirst => ResourceManager.GetString("Menu.FlagProfiles.SelectProfileFirst", resourceCulture);

	public static string Menu_FlagProfiles_SelectProfileLabel => ResourceManager.GetString("Menu.FlagProfiles.SelectProfileLabel", resourceCulture);

	public static string Menu_FlagProfiles_SelectProfileRename => ResourceManager.GetString("Menu.FlagProfiles.SelectProfileRename", resourceCulture);

	public static string Menu_FlagProfiles_SelectProfileUpdate => ResourceManager.GetString("Menu.FlagProfiles.SelectProfileUpdate", resourceCulture);

	public static string Menu_FlagProfiles_Title => ResourceManager.GetString("Menu.FlagProfiles.Title", resourceCulture);

	public static string Menu_FlagProfiles_UpdateFailed => ResourceManager.GetString("Menu.FlagProfiles.UpdateFailed", resourceCulture);

	public static string Menu_GBSEditor_Description => ResourceManager.GetString("Menu.GBSEditor.Description", resourceCulture);

	public static string Menu_GBSEditor_ReadOnly_Description => ResourceManager.GetString("Menu.GBSEditor.ReadOnly.Description", resourceCulture);

	public static string Menu_GBSEditor_ReadOnly_Title => ResourceManager.GetString("Menu.GBSEditor.ReadOnly.Title", resourceCulture);

	public static string Menu_GBSEditor_Title => ResourceManager.GetString("Menu.GBSEditor.Title", resourceCulture);

	public static string Menu_GBSEditor_VectorX => ResourceManager.GetString("Menu.GBSEditor.VectorX", resourceCulture);

	public static string Menu_GBSEditor_VectorY => ResourceManager.GetString("Menu.GBSEditor.VectorY", resourceCulture);

	public static string Menu_GlobalSettings_Accessibility_Title => ResourceManager.GetString("Menu.GlobalSettings.Accessibility.Title", resourceCulture);

	public static string Menu_GlobalSettings_AudioSettings_Title => ResourceManager.GetString("Menu.GlobalSettings.AudioSettings.Title", resourceCulture);

	public static string Menu_GlobalSettings_Export_Fail => ResourceManager.GetString("Menu.GlobalSettings.Export.Fail", resourceCulture);

	public static string Menu_GlobalSettings_Export_Success => ResourceManager.GetString("Menu.GlobalSettings.Export.Success", resourceCulture);

	public static string Menu_GlobalSettings_FirstPersonSensitivity_Description => ResourceManager.GetString("Menu.GlobalSettings.FirstPersonSensitivity.Description", resourceCulture);

	public static string Menu_GlobalSettings_FirstPersonSensitivity_Title => ResourceManager.GetString("Menu.GlobalSettings.FirstPersonSensitivity.Title", resourceCulture);

	public static string Menu_GlobalSettings_FramerateLimit_Description => ResourceManager.GetString("Menu.GlobalSettings.FramerateLimit.Description", resourceCulture);

	public static string Menu_GlobalSettings_FramerateLimit_Title => ResourceManager.GetString("Menu.GlobalSettings.FramerateLimit.Title", resourceCulture);

	public static string Menu_GlobalSettings_Fullscreen_Description => ResourceManager.GetString("Menu.GlobalSettings.Fullscreen.Description", resourceCulture);

	public static string Menu_GlobalSettings_Fullscreen_Title => ResourceManager.GetString("Menu.GlobalSettings.Fullscreen.Title", resourceCulture);

	public static string Menu_GlobalSettings_GraphicsSettings_Title => ResourceManager.GetString("Menu.GlobalSettings.GraphicsSettings.Title", resourceCulture);

	public static string Menu_GlobalSettings_HapticStrength_Description => ResourceManager.GetString("Menu.GlobalSettings.HapticStrength.Description", resourceCulture);

	public static string Menu_GlobalSettings_HapticStrength_Title => ResourceManager.GetString("Menu.GlobalSettings.HapticStrength.Title", resourceCulture);

	public static string Menu_GlobalSettings_Import_Confirmation => ResourceManager.GetString("Menu.GlobalSettings.Import.Confirmation", resourceCulture);

	public static string Menu_GlobalSettings_Import_Fail => ResourceManager.GetString("Menu.GlobalSettings.Import.Fail", resourceCulture);

	public static string Menu_GlobalSettings_Import_NotGBS => ResourceManager.GetString("Menu.GlobalSettings.Import.NotGBS", resourceCulture);

	public static string Menu_GlobalSettings_Import_NotXML => ResourceManager.GetString("Menu.GlobalSettings.Import.NotXML", resourceCulture);

	public static string Menu_GlobalSettings_Import_Success => ResourceManager.GetString("Menu.GlobalSettings.Import.Success", resourceCulture);

	public static string Menu_GlobalSettings_InputSettings_Title => ResourceManager.GetString("Menu.GlobalSettings.InputSettings.Title", resourceCulture);

	public static string Menu_GlobalSettings_InvertY_Description => ResourceManager.GetString("Menu.GlobalSettings.InvertY.Description", resourceCulture);

	public static string Menu_GlobalSettings_InvertY_Title => ResourceManager.GetString("Menu.GlobalSettings.InvertY.Title", resourceCulture);

	public static string Menu_GlobalSettings_MasterVolume_Description => ResourceManager.GetString("Menu.GlobalSettings.MasterVolume.Description", resourceCulture);

	public static string Menu_GlobalSettings_MasterVolume_Title => ResourceManager.GetString("Menu.GlobalSettings.MasterVolume.Title", resourceCulture);

	public static string Menu_GlobalSettings_MaxQuality_Description => ResourceManager.GetString("Menu.GlobalSettings.MaxQuality.Description", resourceCulture);

	public static string Menu_GlobalSettings_MaxQuality_Title => ResourceManager.GetString("Menu.GlobalSettings.MaxQuality.Title", resourceCulture);

	public static string Menu_GlobalSettings_OpenRobloxFolder => ResourceManager.GetString("Menu.GlobalSettings.OpenRobloxFolder", resourceCulture);

	public static string Menu_GlobalSettings_PartyVolume_Description => ResourceManager.GetString("Menu.GlobalSettings.PartyVolume.Description", resourceCulture);

	public static string Menu_GlobalSettings_PartyVolume_Title => ResourceManager.GetString("Menu.GlobalSettings.PartyVolume.Title", resourceCulture);

	public static string Menu_GlobalSettings_PerfStats_Description => ResourceManager.GetString("Menu.GlobalSettings.PerfStats.Description", resourceCulture);

	public static string Menu_GlobalSettings_PerfStats_Title => ResourceManager.GetString("Menu.GlobalSettings.PerfStats.Title", resourceCulture);

	public static string Menu_GlobalSettings_PlayerListLayout_Description => ResourceManager.GetString("Menu.GlobalSettings.PlayerListLayout.Description", resourceCulture);

	public static string Menu_GlobalSettings_PlayerListLayout_Title => ResourceManager.GetString("Menu.GlobalSettings.PlayerListLayout.Title", resourceCulture);

	public static string Menu_GlobalSettings_ReadonlyMessage => ResourceManager.GetString("Menu.GlobalSettings.ReadonlyMessage", resourceCulture);

	public static string Menu_GlobalSettings_ReducedMotion_Description => ResourceManager.GetString("Menu.GlobalSettings.ReducedMotion.Description", resourceCulture);

	public static string Menu_GlobalSettings_ReducedMotion_Title => ResourceManager.GetString("Menu.GlobalSettings.ReducedMotion.Title", resourceCulture);

	public static string Menu_GlobalSettings_Sensitivity_Description => ResourceManager.GetString("Menu.GlobalSettings.Sensitivity.Description", resourceCulture);

	public static string Menu_GlobalSettings_Sensitivity_Title => ResourceManager.GetString("Menu.GlobalSettings.Sensitivity.Title", resourceCulture);

	public static string Menu_GlobalSettings_ShiftLock_Description => ResourceManager.GetString("Menu.GlobalSettings.ShiftLock.Description", resourceCulture);

	public static string Menu_GlobalSettings_ShiftLock_Title => ResourceManager.GetString("Menu.GlobalSettings.ShiftLock.Title", resourceCulture);

	public static string Menu_GlobalSettings_StartQuality_Description => ResourceManager.GetString("Menu.GlobalSettings.StartQuality.Description", resourceCulture);

	public static string Menu_GlobalSettings_StartQuality_Title => ResourceManager.GetString("Menu.GlobalSettings.StartQuality.Title", resourceCulture);

	public static string Menu_GlobalSettings_StudioVolume_Description => ResourceManager.GetString("Menu.GlobalSettings.StudioVolume.Description", resourceCulture);

	public static string Menu_GlobalSettings_StudioVolume_Title => ResourceManager.GetString("Menu.GlobalSettings.StudioVolume.Title", resourceCulture);

	public static string Menu_GlobalSettings_TextSize_Description => ResourceManager.GetString("Menu.GlobalSettings.TextSize.Description", resourceCulture);

	public static string Menu_GlobalSettings_TextSize_Title => ResourceManager.GetString("Menu.GlobalSettings.TextSize.Title", resourceCulture);

	public static string Menu_GlobalSettings_ThirdPersonSensitivity_Description => ResourceManager.GetString("Menu.GlobalSettings.ThirdPersonSensitivity.Description", resourceCulture);

	public static string Menu_GlobalSettings_ThirdPersonSensitivity_Title => ResourceManager.GetString("Menu.GlobalSettings.ThirdPersonSensitivity.Title", resourceCulture);

	public static string Menu_GlobalSettings_Title => ResourceManager.GetString("Menu.GlobalSettings.Title", resourceCulture);

	public static string Menu_GlobalSettings_UITransparency_Description => ResourceManager.GetString("Menu.GlobalSettings.UITransparency.Description", resourceCulture);

	public static string Menu_GlobalSettings_UITransparency_Title => ResourceManager.GetString("Menu.GlobalSettings.UITransparency.Title", resourceCulture);

	public static string Menu_GlobalSettings_Vignette_Description => ResourceManager.GetString("Menu.GlobalSettings.Vignette.Description", resourceCulture);

	public static string Menu_GlobalSettings_Vignette_Title => ResourceManager.GetString("Menu.GlobalSettings.Vignette.Title", resourceCulture);

	public static string Menu_GlobalSettings_VoiceChatVolume_Description => ResourceManager.GetString("Menu.GlobalSettings.VoiceChatVolume.Description", resourceCulture);

	public static string Menu_GlobalSettings_VoiceChatVolume_Title => ResourceManager.GetString("Menu.GlobalSettings.VoiceChatVolume.Title", resourceCulture);

	public static string Menu_GlobalSettings_VRMode_Description => ResourceManager.GetString("Menu.GlobalSettings.VRMode.Description", resourceCulture);

	public static string Menu_GlobalSettings_VRMode_Title => ResourceManager.GetString("Menu.GlobalSettings.VRMode.Title", resourceCulture);

	public static string Menu_GlobalSettingsEditor_Description => ResourceManager.GetString("Menu.GlobalSettingsEditor.Description", resourceCulture);

	public static string Menu_Integrations_ActivityTracking => ResourceManager.GetString("Menu.Integrations.ActivityTracking", resourceCulture);

	public static string Menu_Integrations_ActivityTracking_Description => ResourceManager.GetString("Menu.Integrations.ActivityTracking.Description", resourceCulture);

	public static string Menu_Integrations_AllowActivityJoining_Description => ResourceManager.GetString("Menu.Integrations.AllowActivityJoining.Description", resourceCulture);

	public static string Menu_Integrations_AllowActivityJoining_Title => ResourceManager.GetString("Menu.Integrations.AllowActivityJoining.Title", resourceCulture);

	public static string Menu_Integrations_AutoRejoin_Description => ResourceManager.GetString("Menu.Integrations.AutoRejoin.Description", resourceCulture);

	public static string Menu_Integrations_AutoRejoin_Title => ResourceManager.GetString("Menu.Integrations.AutoRejoin.Title", resourceCulture);

	public static string Menu_Integrations_BlockCardExpander_Description => ResourceManager.GetString("Menu.Integrations.BlockCardExpander.Description", resourceCulture);

	public static string Menu_Integrations_BlockCardExpander_Title => ResourceManager.GetString("Menu.Integrations.BlockCardExpander.Title", resourceCulture);

	public static string Menu_Integrations_BlockScreenShots_Description => ResourceManager.GetString("Menu.Integrations.BlockScreenShots.Description", resourceCulture);

	public static string Menu_Integrations_BlockScreenShots_Title => ResourceManager.GetString("Menu.Integrations.BlockScreenShots.Title", resourceCulture);

	public static string Menu_Integrations_BlockVideoRecording_Description => ResourceManager.GetString("Menu.Integrations.BlockVideoRecording.Description", resourceCulture);

	public static string Menu_Integrations_BlockVideoRecording_Title => ResourceManager.GetString("Menu.Integrations.BlockVideoRecording.Title", resourceCulture);

	public static string Menu_Integrations_Custom_AppLocation => ResourceManager.GetString("Menu.Integrations.Custom.AppLocation", resourceCulture);

	public static string Menu_Integrations_Custom_AutoClose => ResourceManager.GetString("Menu.Integrations.Custom.AutoClose", resourceCulture);

	public static string Menu_Integrations_Custom_AutoCloseOnGame => ResourceManager.GetString("Menu.Integrations.Custom.AutoCloseOnGame", resourceCulture);

	public static string Menu_Integrations_Custom_Description => ResourceManager.GetString("Menu.Integrations.Custom.Description", resourceCulture);

	public static string Menu_Integrations_Custom_GameID => ResourceManager.GetString("Menu.Integrations.Custom.GameID", resourceCulture);

	public static string Menu_Integrations_Custom_LaunchArgs => ResourceManager.GetString("Menu.Integrations.Custom.LaunchArgs", resourceCulture);

	public static string Menu_Integrations_Custom_LaunchArgs_Placeholder => ResourceManager.GetString("Menu.Integrations.Custom.LaunchArgs.Placeholder", resourceCulture);

	public static string Menu_Integrations_Custom_NewIntegration => ResourceManager.GetString("Menu.Integrations.Custom.NewIntegration", resourceCulture);

	public static string Menu_Integrations_Custom_NoneSelected => ResourceManager.GetString("Menu.Integrations.Custom.NoneSelected", resourceCulture);

	public static string Menu_Integrations_Custom_SpecifyGame => ResourceManager.GetString("Menu.Integrations.Custom.SpecifyGame", resourceCulture);

	public static string Menu_Integrations_Custom_Title => ResourceManager.GetString("Menu.Integrations.Custom.Title", resourceCulture);

	public static string Menu_Integrations_CustomStatusDisplay_Description => ResourceManager.GetString("Menu.Integrations.CustomStatusDisplay.Description", resourceCulture);

	public static string Menu_Integrations_CustomStatusDisplay_Title => ResourceManager.GetString("Menu.Integrations.CustomStatusDisplay.Title", resourceCulture);

	public static string Menu_Integrations_Description => ResourceManager.GetString("Menu.Integrations.Description", resourceCulture);

	public static string Menu_Integrations_DesktopApp_Description => ResourceManager.GetString("Menu.Integrations.DesktopApp.Description", resourceCulture);

	public static string Menu_Integrations_DesktopApp_Title => ResourceManager.GetString("Menu.Integrations.DesktopApp.Title", resourceCulture);

	public static string Menu_Integrations_DoubleClickAction_Description => ResourceManager.GetString("Menu.Integrations.DoubleClickAction.Description", resourceCulture);

	public static string Menu_Integrations_DoubleClickAction_Title => ResourceManager.GetString("Menu.Integrations.DoubleClickAction.Title", resourceCulture);

	public static string Menu_Integrations_DynamicThumbnail_Description => ResourceManager.GetString("Menu.Integrations.DynamicThumbnail.Description", resourceCulture);

	public static string Menu_Integrations_DynamicThumbnail_Title => ResourceManager.GetString("Menu.Integrations.DynamicThumbnail.Title", resourceCulture);

	public static string Menu_Integrations_EditingInfo_Description => ResourceManager.GetString("Menu.Integrations.EditingInfo.Description", resourceCulture);

	public static string Menu_Integrations_EditingInfo_Title => ResourceManager.GetString("Menu.Integrations.EditingInfo.Title", resourceCulture);

	public static string Menu_Integrations_EnableActivityTracking_Description => ResourceManager.GetString("Menu.Integrations.EnableActivityTracking.Description", resourceCulture);

	public static string Menu_Integrations_EnableActivityTracking_Title => ResourceManager.GetString("Menu.Integrations.EnableActivityTracking.Title", resourceCulture);

	public static string Menu_Integrations_EnableWindowManipulation_Description => ResourceManager.GetString("Menu.Integrations.EnableWindowManipulation.Description", resourceCulture);

	public static string Menu_Integrations_EnableWindowManipulation_Title => ResourceManager.GetString("Menu.Integrations.EnableWindowManipulation.Title", resourceCulture);

	public static string Menu_Integrations_MerostrapRPC_Description => ResourceManager.GetString("Menu.Integrations.MerostrapRPC.Description", resourceCulture);

	public static string Menu_Integrations_MerostrapRPC_Title => ResourceManager.GetString("Menu.Integrations.MerostrapRPC.Title", resourceCulture);

	public static string Menu_Integrations_GameHistory_Description => ResourceManager.GetString("Menu.Integrations.GameHistory.Description", resourceCulture);

	public static string Menu_Integrations_GameHistory_View => ResourceManager.GetString("Menu.Integrations.GameHistory.View", resourceCulture);

	public static string Menu_Integrations_GameHistoryMenu_Description => ResourceManager.GetString("Menu.Integrations.GameHistoryMenu.Description", resourceCulture);

	public static string Menu_Integrations_GameHistoryMenu_Title => ResourceManager.GetString("Menu.Integrations.GameHistoryMenu.Title", resourceCulture);

	public static string Menu_Integrations_IconChange_Description => ResourceManager.GetString("Menu.Integrations.IconChange.Description", resourceCulture);

	public static string Menu_Integrations_IconChange_Title => ResourceManager.GetString("Menu.Integrations.IconChange.Title", resourceCulture);

	public static string Menu_Integrations_JoinButton_Description => ResourceManager.GetString("Menu.Integrations.JoinButton.Description", resourceCulture);

	public static string Menu_Integrations_JoinButton_Title => ResourceManager.GetString("Menu.Integrations.JoinButton.Title", resourceCulture);

	public static string Menu_Integrations_PlaytimeCounter_Description => ResourceManager.GetString("Menu.Integrations.PlaytimeCounter.Description", resourceCulture);

	public static string Menu_Integrations_PlaytimeCounter_Title => ResourceManager.GetString("Menu.Integrations.PlaytimeCounter.Title", resourceCulture);

	public static string Menu_Integrations_QueryServerLocation_Description => ResourceManager.GetString("Menu.Integrations.QueryServerLocation.Description", resourceCulture);

	public static string Menu_Integrations_QueryServerLocation_Title => ResourceManager.GetString("Menu.Integrations.QueryServerLocation.Title", resourceCulture);

	public static string Menu_Integrations_RequiresActivityTracking => ResourceManager.GetString("Menu.Integrations.RequiresActivityTracking", resourceCulture);

	public static string Menu_Integrations_RPC_Player_Description => ResourceManager.GetString("Menu.Integrations.RPC.Player.Description", resourceCulture);

	public static string Menu_Integrations_RPC_Studio_Description => ResourceManager.GetString("Menu.Integrations.RPC.Studio.Description", resourceCulture);

	public static string Menu_Integrations_ServerUptime_Description => ResourceManager.GetString("Menu.Integrations.ServerUptime.Description", resourceCulture);

	public static string Menu_Integrations_ServerUptime_Title => ResourceManager.GetString("Menu.Integrations.ServerUptime.Title", resourceCulture);

	public static string Menu_Integrations_ShowAccountOnProfile_Description => ResourceManager.GetString("Menu.Integrations.ShowAccountOnProfile.Description", resourceCulture);

	public static string Menu_Integrations_ShowAccountOnProfile_Title => ResourceManager.GetString("Menu.Integrations.ShowAccountOnProfile.Title", resourceCulture);

	public static string Menu_Integrations_ShowGameActivity_Description => ResourceManager.GetString("Menu.Integrations.ShowGameActivity.Description", resourceCulture);

	public static string Menu_Integrations_ShowGameActivity_Title => ResourceManager.GetString("Menu.Integrations.ShowGameActivity.Title", resourceCulture);

	public static string Menu_Integrations_ShowTesting_Description => ResourceManager.GetString("Menu.Integrations.ShowTesting.Description", resourceCulture);

	public static string Menu_Integrations_ShowTesting_Title => ResourceManager.GetString("Menu.Integrations.ShowTesting.Title", resourceCulture);

	public static string Menu_Integrations_StudioActivity_Description => ResourceManager.GetString("Menu.Integrations.StudioActivity.Description", resourceCulture);

	public static string Menu_Integrations_StudioActivity_Title => ResourceManager.GetString("Menu.Integrations.StudioActivity.Title", resourceCulture);

	public static string Menu_Integrations_StudioRPC_PluginConfirmation => ResourceManager.GetString("Menu.Integrations.StudioRPC.PluginConfirmation", resourceCulture);

	public static string Menu_Integrations_Title => ResourceManager.GetString("Menu.Integrations.Title", resourceCulture);

	public static string Menu_Integrations_TitleChange_Description => ResourceManager.GetString("Menu.Integrations.TitleChange.Description", resourceCulture);

	public static string Menu_Integrations_TitleChange_Title => ResourceManager.GetString("Menu.Integrations.TitleChange.Title", resourceCulture);

	public static string Menu_Integrations_TitleChangePlayer_Description => ResourceManager.GetString("Menu.Integrations.TitleChangePlayer.Description", resourceCulture);

	public static string Menu_Integrations_TitleChangePlayer_Title => ResourceManager.GetString("Menu.Integrations.TitleChangePlayer.Title", resourceCulture);

	public static string Menu_Integrations_WorkspaceInfo_Description => ResourceManager.GetString("Menu.Integrations.WorkspaceInfo.Description", resourceCulture);

	public static string Menu_Integrations_WorkspaceInfo_Title => ResourceManager.GetString("Menu.Integrations.WorkspaceInfo.Title", resourceCulture);

	public static string Menu_LinuxSettings_AddVariable => ResourceManager.GetString("Menu.LinuxSettings.AddVariable", resourceCulture);

	public static string Menu_LinuxSettings_AdvancedWineSettings => ResourceManager.GetString("Menu.LinuxSettings.AdvancedWineSettings", resourceCulture);

	public static string Menu_LinuxSettings_AllowGamepadPermission_Description => ResourceManager.GetString("Menu.LinuxSettings.AllowGamepadPermission.Description", resourceCulture);

	public static string Menu_LinuxSettings_AllowGamepadPermission_Title => ResourceManager.GetString("Menu.LinuxSettings.AllowGamepadPermission.Title", resourceCulture);

	public static string Menu_LinuxSettings_DebugMode_Description => ResourceManager.GetString("Menu.LinuxSettings.DebugMode.Description", resourceCulture);

	public static string Menu_LinuxSettings_DebugMode_Title => ResourceManager.GetString("Menu.LinuxSettings.DebugMode.Title", resourceCulture);

	public static string Menu_LinuxSettings_EnableGameMode_Description => ResourceManager.GetString("Menu.LinuxSettings.EnableGameMode.Description", resourceCulture);

	public static string Menu_LinuxSettings_EnableGameMode_Title => ResourceManager.GetString("Menu.LinuxSettings.EnableGameMode.Title", resourceCulture);

	public static string Menu_LinuxSettings_EnableHiDpi_Description => ResourceManager.GetString("Menu.LinuxSettings.EnableHiDpi.Description", resourceCulture);

	public static string Menu_LinuxSettings_EnableHiDpi_Title => ResourceManager.GetString("Menu.LinuxSettings.EnableHiDpi.Title", resourceCulture);

	public static string Menu_LinuxSettings_EnvironmentVariables_Description => ResourceManager.GetString("Menu.LinuxSettings.EnvironmentVariables.Description", resourceCulture);

	public static string Menu_LinuxSettings_EnvironmentVariables_Title => ResourceManager.GetString("Menu.LinuxSettings.EnvironmentVariables.Title", resourceCulture);

	public static string Menu_LinuxSettings_FailedToStartWineCfg => ResourceManager.GetString("Menu.LinuxSettings.FailedToStartWineCfg", resourceCulture);

	public static string Menu_LinuxSettings_ForceLegacyOpenGL_Description => ResourceManager.GetString("Menu.LinuxSettings.ForceLegacyOpenGL.Description", resourceCulture);

	public static string Menu_LinuxSettings_ForceLegacyOpenGL_Title => ResourceManager.GetString("Menu.LinuxSettings.ForceLegacyOpenGL.Title", resourceCulture);

	public static string Menu_LinuxSettings_GameMode_Description => ResourceManager.GetString("Menu.LinuxSettings.GameMode.Description", resourceCulture);

	public static string Menu_LinuxSettings_GameMode_Title => ResourceManager.GetString("Menu.LinuxSettings.GameMode.Title", resourceCulture);

	public static string Menu_LinuxSettings_GraphicsRenderer_Description => ResourceManager.GetString("Menu.LinuxSettings.GraphicsRenderer.Description", resourceCulture);

	public static string Menu_LinuxSettings_GraphicsRenderer_Title => ResourceManager.GetString("Menu.LinuxSettings.GraphicsRenderer.Title", resourceCulture);

	public static string Menu_LinuxSettings_LauncherCommand_Description => ResourceManager.GetString("Menu.LinuxSettings.LauncherCommand.Description", resourceCulture);

	public static string Menu_LinuxSettings_LauncherCommand_Title => ResourceManager.GetString("Menu.LinuxSettings.LauncherCommand.Title", resourceCulture);

	public static string Menu_LinuxSettings_LauncherPlaceholder => ResourceManager.GetString("Menu.LinuxSettings.LauncherPlaceholder", resourceCulture);

	public static string Menu_LinuxSettings_ResolutionPlaceholder => ResourceManager.GetString("Menu.LinuxSettings.ResolutionPlaceholder", resourceCulture);

	public static string Menu_LinuxSettings_Title => ResourceManager.GetString("Menu.LinuxSettings.Title", resourceCulture);

	public static string Menu_LinuxSettings_TouchInputMode_Description => ResourceManager.GetString("Menu.LinuxSettings.TouchInputMode.Description", resourceCulture);

	public static string Menu_LinuxSettings_TouchInputMode_Title => ResourceManager.GetString("Menu.LinuxSettings.TouchInputMode.Title", resourceCulture);

	public static string Menu_LinuxSettings_UseConsoleExperience_Description => ResourceManager.GetString("Menu.LinuxSettings.UseConsoleExperience.Description", resourceCulture);

	public static string Menu_LinuxSettings_UseConsoleExperience_Title => ResourceManager.GetString("Menu.LinuxSettings.UseConsoleExperience.Title", resourceCulture);

	public static string Menu_LinuxSettings_Variable => ResourceManager.GetString("Menu.LinuxSettings.Variable", resourceCulture);

	public static string Menu_LinuxSettings_VirtualDesktops_Description => ResourceManager.GetString("Menu.LinuxSettings.VirtualDesktops.Description", resourceCulture);

	public static string Menu_LinuxSettings_VirtualDesktops_Title => ResourceManager.GetString("Menu.LinuxSettings.VirtualDesktops.Title", resourceCulture);

	public static string Menu_LinuxSettings_WebPages_Description => ResourceManager.GetString("Menu.LinuxSettings.WebPages.Description", resourceCulture);

	public static string Menu_LinuxSettings_WebPages_Title => ResourceManager.GetString("Menu.LinuxSettings.WebPages.Title", resourceCulture);

	public static string Menu_LinuxSettings_WineBinaryNotFound => ResourceManager.GetString("Menu.LinuxSettings.WineBinaryNotFound", resourceCulture);

	public static string Menu_Load => ResourceManager.GetString("Menu.Load", resourceCulture);

	public static string Menu_ManualLogin_EnterCookie => ResourceManager.GetString("Menu.ManualLogin.EnterCookie", resourceCulture);

	public static string Menu_ManualLogin_Instruction_1 => ResourceManager.GetString("Menu.ManualLogin.Instruction.1", resourceCulture);

	public static string Menu_ManualLogin_Instruction_2 => ResourceManager.GetString("Menu.ManualLogin.Instruction.2", resourceCulture);

	public static string Menu_ManualLogin_Instruction_3 => ResourceManager.GetString("Menu.ManualLogin.Instruction.3", resourceCulture);

	public static string Menu_ManualLogin_Instruction_4 => ResourceManager.GetString("Menu.ManualLogin.Instruction.4", resourceCulture);

	public static string Menu_ManualLogin_Instruction_5 => ResourceManager.GetString("Menu.ManualLogin.Instruction.5", resourceCulture);

	public static string Menu_ManualLogin_Instruction_6 => ResourceManager.GetString("Menu.ManualLogin.Instruction.6", resourceCulture);

	public static string Menu_ManualLogin_Instruction_7 => ResourceManager.GetString("Menu.ManualLogin.Instruction.7", resourceCulture);

	public static string Menu_ManualLogin_InvalidCookie => ResourceManager.GetString("Menu.ManualLogin.InvalidCookie", resourceCulture);

	public static string Menu_ManualLogin_PasteSecurity => ResourceManager.GetString("Menu.ManualLogin.PasteSecurity", resourceCulture);

	public static string Menu_ManualLogin_Title => ResourceManager.GetString("Menu.ManualLogin.Title", resourceCulture);

	public static string Menu_ModGenerator_AddStop => ResourceManager.GetString("Menu.ModGenerator.AddStop", resourceCulture);

	public static string Menu_ModGenerator_AppliedModifications => ResourceManager.GetString("Menu.ModGenerator.AppliedModifications", resourceCulture);

	public static string Menu_ModGenerator_ApplyCursor => ResourceManager.GetString("Menu.ModGenerator.ApplyCursor", resourceCulture);

	public static string Menu_ModGenerator_ApplyEmoteWheel => ResourceManager.GetString("Menu.ModGenerator.ApplyEmoteWheel", resourceCulture);

	public static string Menu_ModGenerator_ApplyShiftlock => ResourceManager.GetString("Menu.ModGenerator.ApplyShiftlock", resourceCulture);

	public static string Menu_ModGenerator_BandInfo => ResourceManager.GetString("Menu.ModGenerator.BandInfo", resourceCulture);

	public static string Menu_ModGenerator_Cancelled => ResourceManager.GetString("Menu.ModGenerator.Cancelled", resourceCulture);

	public static string Menu_ModGenerator_CleaningUp => ResourceManager.GetString("Menu.ModGenerator.CleaningUp", resourceCulture);

	public static string Menu_ModGenerator_CustomModName => ResourceManager.GetString("Menu.ModGenerator.CustomModName", resourceCulture);

	public static string Menu_ModGenerator_CustomSpinner => ResourceManager.GetString("Menu.ModGenerator.CustomSpinner", resourceCulture);

	public static string Menu_ModGenerator_Description => ResourceManager.GetString("Menu.ModGenerator.Description", resourceCulture);

	public static string Menu_ModGenerator_DontColorPlay => ResourceManager.GetString("Menu.ModGenerator.DontColorPlay", resourceCulture);

	public static string Menu_ModGenerator_Downnloading => ResourceManager.GetString("Menu.ModGenerator.Downnloading", resourceCulture);

	public static string Menu_ModGenerator_Extracting => ResourceManager.GetString("Menu.ModGenerator.Extracting", resourceCulture);

	public static string Menu_ModGenerator_FailedPreview => ResourceManager.GetString("Menu.ModGenerator.FailedPreview", resourceCulture);

	public static string Menu_ModGenerator_IconSet => ResourceManager.GetString("Menu.ModGenerator.IconSet", resourceCulture);

	public static string Menu_ModGenerator_IncludeModification => ResourceManager.GetString("Menu.ModGenerator.IncludeModification", resourceCulture);

	public static string Menu_ModGenerator_ModsOptions => ResourceManager.GetString("Menu.ModGenerator.ModsOptions", resourceCulture);

	public static string Menu_ModGenerator_Packaging => ResourceManager.GetString("Menu.ModGenerator.Packaging", resourceCulture);

	public static string Menu_ModGenerator_ReadyToGenerate => ResourceManager.GetString("Menu.ModGenerator.ReadyToGenerate", resourceCulture);

	public static string Menu_ModGenerator_RecoloringFonts => ResourceManager.GetString("Menu.ModGenerator.RecoloringFonts", resourceCulture);

	public static string Menu_ModGenerator_RecoloringPNGS => ResourceManager.GetString("Menu.ModGenerator.RecoloringPNGS", resourceCulture);

	public static string Menu_ModGenerator_RobloxIcon => ResourceManager.GetString("Menu.ModGenerator.RobloxIcon", resourceCulture);

	public static string Menu_ModGenerator_SavedTo => ResourceManager.GetString("Menu.ModGenerator.SavedTo", resourceCulture);

	public static string Menu_ModGenerator_Starting => ResourceManager.GetString("Menu.ModGenerator.Starting", resourceCulture);

	public static string Menu_ModGenerator_StylePreview => ResourceManager.GetString("Menu.ModGenerator.StylePreview", resourceCulture);

	public static string Menu_ModGenerator_Title => ResourceManager.GetString("Menu.ModGenerator.Title", resourceCulture);

	public static string Menu_ModGeneratorName_Exists => ResourceManager.GetString("Menu.ModGeneratorName.Exists", resourceCulture);

	public static string Menu_ModGeneratorName_Invalid => ResourceManager.GetString("Menu.ModGeneratorName.Invalid", resourceCulture);

	public static string Menu_Mods_AddNewMod => ResourceManager.GetString("Menu.Mods.AddNewMod", resourceCulture);

	public static string Menu_Mods_AlreadyExist => ResourceManager.GetString("Menu.Mods.AlreadyExist", resourceCulture);

	public static string Menu_Mods_AlreadyImported => ResourceManager.GetString("Menu.Mods.AlreadyImported", resourceCulture);

	public static string Menu_Mods_CannotImportSubfolder => ResourceManager.GetString("Menu.Mods.CannotImportSubfolder", resourceCulture);

	public static string Menu_Mods_DefaultNewModName => ResourceManager.GetString("Menu.Mods.DefaultNewModName", resourceCulture);

	public static string Menu_Mods_DeleteFailed => ResourceManager.GetString("Menu.Mods.DeleteFailed", resourceCulture);

	public static string Menu_Mods_DeleteMod => ResourceManager.GetString("Menu.Mods.DeleteMod", resourceCulture);

	public static string Menu_Mods_Description => ResourceManager.GetString("Menu.Mods.Description", resourceCulture);

	public static string Menu_Mods_DragOverlay => ResourceManager.GetString("Menu.Mods.DragOverlay", resourceCulture);

	public static string Menu_Mods_ExportFailed => ResourceManager.GetString("Menu.Mods.ExportFailed", resourceCulture);

	public static string Menu_Mods_ExportFolderMissing => ResourceManager.GetString("Menu.Mods.ExportFolderMissing", resourceCulture);

	public static string Menu_Mods_ExportSelectMod => ResourceManager.GetString("Menu.Mods.ExportSelectMod", resourceCulture);

	public static string Menu_Mods_ExportSuccess => ResourceManager.GetString("Menu.Mods.ExportSuccess", resourceCulture);

	public static string Menu_Mods_FolderDosentExist => ResourceManager.GetString("Menu.Mods.FolderDosentExist", resourceCulture);

	public static string Menu_Mods_Imported => ResourceManager.GetString("Menu.Mods.Imported", resourceCulture);

	public static string Menu_Mods_ImportFolder => ResourceManager.GetString("Menu.Mods.ImportFolder", resourceCulture);

	public static string Menu_Mods_ImportZIP => ResourceManager.GetString("Menu.Mods.ImportZIP", resourceCulture);

	public static string Menu_Mods_InfoBar => ResourceManager.GetString("Menu.Mods.InfoBar", resourceCulture);

	public static string Menu_Mods_InvalidFolderName => ResourceManager.GetString("Menu.Mods.InvalidFolderName", resourceCulture);

	public static string Menu_Mods_InvalidModFolderName => ResourceManager.GetString("Menu.Mods.InvalidModFolderName", resourceCulture);

	public static string Menu_Mods_InvalidModFolders => ResourceManager.GetString("Menu.Mods.InvalidModFolders", resourceCulture);

	public static string Menu_Mods_NoneInstalled => ResourceManager.GetString("Menu.Mods.NoneInstalled", resourceCulture);

	public static string Menu_Mods_Preview_Failed => ResourceManager.GetString("Menu.Mods.Preview.Failed", resourceCulture);

	public static string Menu_Mods_Preview_Font_Preview => ResourceManager.GetString("Menu.Mods.Preview.Font.Preview", resourceCulture);

	public static string Menu_Mods_Preview_FontVariant => ResourceManager.GetString("Menu.Mods.Preview.FontVariant", resourceCulture);

	public static string Menu_Mods_Preview_Loaded => ResourceManager.GetString("Menu.Mods.Preview.Loaded", resourceCulture);

	public static string Menu_Mods_Preview_Loading => ResourceManager.GetString("Menu.Mods.Preview.Loading", resourceCulture);

	public static string Menu_Mods_Preview_Loading_Glyphs => ResourceManager.GetString("Menu.Mods.Preview.Loading.Glyphs", resourceCulture);

	public static string Menu_Mods_Preview_LoadingFont => ResourceManager.GetString("Menu.Mods.Preview.LoadingFont", resourceCulture);

	public static string Menu_Mods_Preview_NoColor => ResourceManager.GetString("Menu.Mods.Preview.NoColor", resourceCulture);

	public static string Menu_Mods_PreviewFont => ResourceManager.GetString("Menu.Mods.PreviewFont", resourceCulture);

	public static string Menu_Mods_RenameFailed => ResourceManager.GetString("Menu.Mods.RenameFailed", resourceCulture);

	public static string Menu_Mods_SelectedModAction => ResourceManager.GetString("Menu.Mods.SelectedModAction", resourceCulture);

	public static string Menu_Mods_Title => ResourceManager.GetString("Menu.Mods.Title", resourceCulture);

	public static string Menu_Mods_UnsupportedFile => ResourceManager.GetString("Menu.Mods.UnsupportedFile", resourceCulture);

	public static string Menu_Mods_ZipExtractFailed => ResourceManager.GetString("Menu.Mods.ZipExtractFailed", resourceCulture);

	public static string Menu_Onboarding_Page6_A1 => ResourceManager.GetString("Menu.Onboarding.Page6.A1", resourceCulture);

	public static string Menu_Onboarding_Page6_A2 => ResourceManager.GetString("Menu.Onboarding.Page6.A2", resourceCulture);

	public static string Menu_Onboarding_Page6_A3 => ResourceManager.GetString("Menu.Onboarding.Page6.A3", resourceCulture);

	public static string Menu_Onboarding_Page6_A4 => ResourceManager.GetString("Menu.Onboarding.Page6.A4", resourceCulture);

	public static string Menu_Onboarding_Page6_A5 => ResourceManager.GetString("Menu.Onboarding.Page6.A5", resourceCulture);

	public static string Menu_Onboarding_Page6_A6 => ResourceManager.GetString("Menu.Onboarding.Page6.A6", resourceCulture);

	public static string Menu_Onboarding_Page6_Q1 => ResourceManager.GetString("Menu.Onboarding.Page6.Q1", resourceCulture);

	public static string Menu_Onboarding_Page6_Q2 => ResourceManager.GetString("Menu.Onboarding.Page6.Q2", resourceCulture);

	public static string Menu_Onboarding_Page6_Q3 => ResourceManager.GetString("Menu.Onboarding.Page6.Q3", resourceCulture);

	public static string Menu_Onboarding_Page6_Q4 => ResourceManager.GetString("Menu.Onboarding.Page6.Q4", resourceCulture);

	public static string Menu_Onboarding_Page6_Q5 => ResourceManager.GetString("Menu.Onboarding.Page6.Q5", resourceCulture);

	public static string Menu_Onboarding_Page6_Q6 => ResourceManager.GetString("Menu.Onboarding.Page6.Q6", resourceCulture);

	public static string Menu_PresetMods_CursorSet_Apply => ResourceManager.GetString("Menu.PresetMods.CursorSet.Apply", resourceCulture);

	public static string Menu_PresetMods_CursorSet_Export => ResourceManager.GetString("Menu.PresetMods.CursorSet.Export", resourceCulture);

	public static string Menu_PresetMods_CursorSet_Fetch => ResourceManager.GetString("Menu.PresetMods.CursorSet.Fetch", resourceCulture);

	public static string Menu_PresetMods_CursorSet_Import => ResourceManager.GetString("Menu.PresetMods.CursorSet.Import", resourceCulture);

	public static string Menu_PresetMods_CursorSet_None => ResourceManager.GetString("Menu.PresetMods.CursorSet.None", resourceCulture);

	public static string Menu_PresetMods_Description => ResourceManager.GetString("Menu.PresetMods.Description", resourceCulture);

	public static string Menu_PresetMods_Misc_CardExpander_CustomCursors_Descriptions => ResourceManager.GetString("Menu.PresetMods.Misc.CardExpander.CustomCursors.Descriptions", resourceCulture);

	public static string Menu_PresetMods_Misc_CardExpander_CustomCursors_Title => ResourceManager.GetString("Menu.PresetMods.Misc.CardExpander.CustomCursors.Title", resourceCulture);

	public static string Menu_PresetMods_Misc_CompatibilitySettings_Description => ResourceManager.GetString("Menu.PresetMods.Misc.CompatibilitySettings.Description", resourceCulture);

	public static string Menu_PresetMods_Misc_CompatibilitySettings_Title => ResourceManager.GetString("Menu.PresetMods.Misc.CompatibilitySettings.Title", resourceCulture);

	public static string Menu_PresetMods_Misc_CustomCursor_Choose => ResourceManager.GetString("Menu.PresetMods.Misc.CustomCursor.Choose", resourceCulture);

	public static string Menu_PresetMods_Misc_CustomCursor_Description => ResourceManager.GetString("Menu.PresetMods.Misc.CustomCursor.Description", resourceCulture);

	public static string Menu_PresetMods_Misc_CustomCursor_Remove => ResourceManager.GetString("Menu.PresetMods.Misc.CustomCursor.Remove", resourceCulture);

	public static string Menu_PresetMods_Misc_CustomCursor_Title => ResourceManager.GetString("Menu.PresetMods.Misc.CustomCursor.Title", resourceCulture);

	public static string Menu_PresetMods_Misc_CustomCursorSet_Description => ResourceManager.GetString("Menu.PresetMods.Misc.CustomCursorSet.Description", resourceCulture);

	public static string Menu_PresetMods_Misc_CustomCursorSet_Title => ResourceManager.GetString("Menu.PresetMods.Misc.CustomCursorSet.Title", resourceCulture);

	public static string Menu_PresetMods_Misc_CustomDeathSound_Choose => ResourceManager.GetString("Menu.PresetMods.Misc.CustomDeathSound.Choose", resourceCulture);

	public static string Menu_PresetMods_Misc_CustomDeathSound_Description => ResourceManager.GetString("Menu.PresetMods.Misc.CustomDeathSound.Description", resourceCulture);

	public static string Menu_PresetMods_Misc_CustomDeathSound_Remove => ResourceManager.GetString("Menu.PresetMods.Misc.CustomDeathSound.Remove", resourceCulture);

	public static string Menu_PresetMods_Misc_CustomDeathSound_Title => ResourceManager.GetString("Menu.PresetMods.Misc.CustomDeathSound.Title", resourceCulture);

	public static string Menu_PresetMods_Misc_CustomFont_Choose => ResourceManager.GetString("Menu.PresetMods.Misc.CustomFont.Choose", resourceCulture);

	public static string Menu_PresetMods_Misc_CustomFont_Description => ResourceManager.GetString("Menu.PresetMods.Misc.CustomFont.Description", resourceCulture);

	public static string Menu_PresetMods_Misc_CustomFont_Remove => ResourceManager.GetString("Menu.PresetMods.Misc.CustomFont.Remove", resourceCulture);

	public static string Menu_PresetMods_Misc_CustomFont_Title => ResourceManager.GetString("Menu.PresetMods.Misc.CustomFont.Title", resourceCulture);

	public static string Menu_PresetMods_Misc_CustomShiftLock_Choose => ResourceManager.GetString("Menu.PresetMods.Misc.CustomShiftLock.Choose", resourceCulture);

	public static string Menu_PresetMods_Misc_CustomShiftLock_Description => ResourceManager.GetString("Menu.PresetMods.Misc.CustomShiftLock.Description", resourceCulture);

	public static string Menu_PresetMods_Misc_CustomShiftLock_Remove => ResourceManager.GetString("Menu.PresetMods.Misc.CustomShiftLock.Remove", resourceCulture);

	public static string Menu_PresetMods_Misc_CustomShiftLock_Title => ResourceManager.GetString("Menu.PresetMods.Misc.CustomShiftLock.Title", resourceCulture);

	public static string Menu_PresetMods_Misc_Description => ResourceManager.GetString("Menu.PresetMods.Misc.Description", resourceCulture);

	public static string Menu_PresetMods_OpenModsFolder => ResourceManager.GetString("Menu.PresetMods.OpenModsFolder", resourceCulture);

	public static string Menu_PresetMods_Presets_Description => ResourceManager.GetString("Menu.PresetMods.Presets.Description", resourceCulture);

	public static string Menu_PresetMods_Presets_EmojiType_Description => ResourceManager.GetString("Menu.PresetMods.Presets.EmojiType.Description", resourceCulture);

	public static string Menu_PresetMods_Presets_EmojiType_Error => ResourceManager.GetString("Menu.PresetMods.Presets.EmojiType.Error", resourceCulture);

	public static string Menu_PresetMods_Presets_EmojiType_Title => ResourceManager.GetString("Menu.PresetMods.Presets.EmojiType.Title", resourceCulture);

	public static string Menu_PresetMods_Presets_MouseCursor_Description => ResourceManager.GetString("Menu.PresetMods.Presets.MouseCursor.Description", resourceCulture);

	public static string Menu_PresetMods_Presets_MouseCursor_Title => ResourceManager.GetString("Menu.PresetMods.Presets.MouseCursor.Title", resourceCulture);

	public static string Menu_PresetMods_Presets_OldAvatarEditor_Description => ResourceManager.GetString("Menu.PresetMods.Presets.OldAvatarEditor.Description", resourceCulture);

	public static string Menu_PresetMods_Presets_OldAvatarEditor_Title => ResourceManager.GetString("Menu.PresetMods.Presets.OldAvatarEditor.Title", resourceCulture);

	public static string Menu_PresetMods_Title => ResourceManager.GetString("Menu.PresetMods.Title", resourceCulture);

	public static string Menu_QuickPlay_AccountManagerNotAvailable => ResourceManager.GetString("Menu.QuickPlay.AccountManagerNotAvailable", resourceCulture);

	public static string Menu_QuickPlay_Active => ResourceManager.GetString("Menu.QuickPlay.Active", resourceCulture);

	public static string Menu_QuickPlay_AvailableSubplaces => ResourceManager.GetString("Menu.QuickPlay.AvailableSubplaces", resourceCulture);

	public static string Menu_QuickPlay_BestRegionJoined_Message => ResourceManager.GetString("Menu.QuickPlay.BestRegionJoined.Message", resourceCulture);

	public static string Menu_QuickPlay_BestRegionJoined_Title => ResourceManager.GetString("Menu.QuickPlay.BestRegionJoined.Title", resourceCulture);

	public static string Menu_QuickPlay_CheckingServers => ResourceManager.GetString("Menu.QuickPlay.CheckingServers", resourceCulture);

	public static string Menu_QuickPlay_ContinuePlaying => ResourceManager.GetString("Menu.QuickPlay.ContinuePlaying", resourceCulture);

	public static string Menu_QuickPlay_Description => ResourceManager.GetString("Menu.QuickPlay.Description", resourceCulture);

	public static string Menu_QuickPlay_Favorites => ResourceManager.GetString("Menu.QuickPlay.Favorites", resourceCulture);

	public static string Menu_QuickPlay_FetchingGameInfo => ResourceManager.GetString("Menu.QuickPlay.FetchingGameInfo", resourceCulture);

	public static string Menu_QuickPlay_FindingBestServer => ResourceManager.GetString("Menu.QuickPlay.FindingBestServer", resourceCulture);

	public static string Menu_QuickPlay_JoinBestRegion => ResourceManager.GetString("Menu.QuickPlay.JoinBestRegion", resourceCulture);

	public static string Menu_QuickPlay_JoinGame => ResourceManager.GetString("Menu.QuickPlay.JoinGame", resourceCulture);

	public static string Menu_QuickPlay_Latest => ResourceManager.GetString("Menu.QuickPlay.Latest", resourceCulture);

	public static string Menu_QuickPlay_LoadingFavorites => ResourceManager.GetString("Menu.QuickPlay.LoadingFavorites", resourceCulture);

	public static string Menu_QuickPlay_LoadingPrivateServers => ResourceManager.GetString("Menu.QuickPlay.LoadingPrivateServers", resourceCulture);

	public static string Menu_QuickPlay_LoadingRecentGames => ResourceManager.GetString("Menu.QuickPlay.LoadingRecentGames", resourceCulture);

	public static string Menu_QuickPlay_LoadingRecommended => ResourceManager.GetString("Menu.QuickPlay.LoadingRecommended", resourceCulture);

	public static string Menu_QuickPlay_LoadingServers => ResourceManager.GetString("Menu.QuickPlay.LoadingServers", resourceCulture);

	public static string Menu_QuickPlay_LoadingSubplaces => ResourceManager.GetString("Menu.QuickPlay.LoadingSubplaces", resourceCulture);

	public static string Menu_QuickPlay_LoginToSeeFavorites => ResourceManager.GetString("Menu.QuickPlay.LoginToSeeFavorites", resourceCulture);

	public static string Menu_QuickPlay_LoginToSeeRecommended => ResourceManager.GetString("Menu.QuickPlay.LoginToSeeRecommended", resourceCulture);

	public static string Menu_QuickPlay_NoFavoriteGames => ResourceManager.GetString("Menu.QuickPlay.NoFavoriteGames", resourceCulture);

	public static string Menu_QuickPlay_NoPrivateServersFound => ResourceManager.GetString("Menu.QuickPlay.NoPrivateServersFound", resourceCulture);

	public static string Menu_QuickPlay_NoRecentGames => ResourceManager.GetString("Menu.QuickPlay.NoRecentGames", resourceCulture);

	public static string Menu_QuickPlay_NoRecommendedGames => ResourceManager.GetString("Menu.QuickPlay.NoRecommendedGames", resourceCulture);

	public static string Menu_QuickPlay_NoSubplacesFound => ResourceManager.GetString("Menu.QuickPlay.NoSubplacesFound", resourceCulture);

	public static string Menu_QuickPlay_NoSubplacesSelected => ResourceManager.GetString("Menu.QuickPlay.NoSubplacesSelected", resourceCulture);

	public static string Menu_QuickPlay_NoSuitableServer => ResourceManager.GetString("Menu.QuickPlay.NoSuitableServer", resourceCulture);

	public static string Menu_QuickPlay_Players => ResourceManager.GetString("Menu.QuickPlay.Players", resourceCulture);

	public static string Menu_QuickPlay_PleaseSelectAccount => ResourceManager.GetString("Menu.QuickPlay.PleaseSelectAccount", resourceCulture);

	public static string Menu_QuickPlay_PrivateServers => ResourceManager.GetString("Menu.QuickPlay.PrivateServers", resourceCulture);

	public static string Menu_QuickPlay_Recommended => ResourceManager.GetString("Menu.QuickPlay.Recommended", resourceCulture);

	public static string Menu_QuickPlay_RejoinLastServer => ResourceManager.GetString("Menu.QuickPlay.RejoinLastServer", resourceCulture);

	public static string Menu_QuickPlay_RobloxAPI => ResourceManager.GetString("Menu.QuickPlay.RobloxAPI", resourceCulture);

	public static string Menu_QuickPlay_RobloxServers => ResourceManager.GetString("Menu.QuickPlay.RobloxServers", resourceCulture);

	public static string Menu_QuickPlay_SessionHistory => ResourceManager.GetString("Menu.QuickPlay.SessionHistory", resourceCulture);

	public static string Menu_QuickPlay_Title => ResourceManager.GetString("Menu.QuickPlay.Title", resourceCulture);

	public static string Menu_QuickPlay_Tracked => ResourceManager.GetString("Menu.QuickPlay.Tracked", resourceCulture);

	public static string Menu_QuickPlay_TrackedServers => ResourceManager.GetString("Menu.QuickPlay.TrackedServers", resourceCulture);

	public static string Menu_QuickPlay_UnableToAuthenticate => ResourceManager.GetString("Menu.QuickPlay.UnableToAuthenticate", resourceCulture);

	public static string Menu_QuickPlay_UnknownGame => ResourceManager.GetString("Menu.QuickPlay.UnknownGame", resourceCulture);

	public static string Menu_QuickPlay_ViewSubplaces => ResourceManager.GetString("Menu.QuickPlay.ViewSubplaces", resourceCulture);

	public static string Menu_QuickPlay_VisitPage => ResourceManager.GetString("Menu.QuickPlay.VisitPage", resourceCulture);

	public static string Menu_QuickPlay_Visits => ResourceManager.GetString("Menu.QuickPlay.Visits", resourceCulture);

	public static string Menu_QuickSignIn_Cancelled => ResourceManager.GetString("Menu.QuickSignIn.Cancelled", resourceCulture);

	public static string Menu_QuickSignIn_Complete => ResourceManager.GetString("Menu.QuickSignIn.Complete", resourceCulture);

	public static string Menu_QuickSignIn_Instruction => ResourceManager.GetString("Menu.QuickSignIn.Instruction", resourceCulture);

	public static string Menu_QuickSignIn_Linked => ResourceManager.GetString("Menu.QuickSignIn.Linked", resourceCulture);

	public static string Menu_QuickSignIn_TimedOut => ResourceManager.GetString("Menu.QuickSignIn.TimedOut", resourceCulture);

	public static string Menu_QuickSignIn_Waitting => ResourceManager.GetString("Menu.QuickSignIn.Waitting", resourceCulture);

	public static string Menu_RegionSelector_Description => ResourceManager.GetString("Menu.RegionSelector.Description", resourceCulture);

	public static string Menu_RegionSelector_EnterPlaceId => ResourceManager.GetString("Menu.RegionSelector.EnterPlaceId", resourceCulture);

	public static string Menu_RegionSelector_FailedToLoadDatacenters => ResourceManager.GetString("Menu.RegionSelector.FailedToLoadDatacenters", resourceCulture);

	public static string Menu_RegionSelector_FindGame => ResourceManager.GetString("Menu.RegionSelector.FindGame", resourceCulture);

	public static string Menu_RegionSelector_ID => ResourceManager.GetString("Menu.RegionSelector.ID", resourceCulture);

	public static string Menu_RegionSelector_Join => ResourceManager.GetString("Menu.RegionSelector.Join", resourceCulture);

	public static string Menu_RegionSelector_LargeServers => ResourceManager.GetString("Menu.RegionSelector.LargeServers", resourceCulture);

	public static string Menu_RegionSelector_LoadedRegions => ResourceManager.GetString("Menu.RegionSelector.LoadedRegions", resourceCulture);

	public static string Menu_RegionSelector_LoadingDatacenters => ResourceManager.GetString("Menu.RegionSelector.LoadingDatacenters", resourceCulture);

	public static string Menu_RegionSelector_LoadingMore => ResourceManager.GetString("Menu.RegionSelector.LoadingMore", resourceCulture);

	public static string Menu_RegionSelector_LoadMore => ResourceManager.GetString("Menu.RegionSelector.LoadMore", resourceCulture);

	public static string Menu_RegionSelector_LoginRequired => ResourceManager.GetString("Menu.RegionSelector.LoginRequired", resourceCulture);

	public static string Menu_RegionSelector_NoPublicServers => ResourceManager.GetString("Menu.RegionSelector.NoPublicServers", resourceCulture);

	public static string Menu_RegionSelector_NoServersForRegion => ResourceManager.GetString("Menu.RegionSelector.NoServersForRegion", resourceCulture);

	public static string Menu_RegionSelector_Players => ResourceManager.GetString("Menu.RegionSelector.Players", resourceCulture);

	public static string Menu_RegionSelector_PleaseSelectRegion => ResourceManager.GetString("Menu.RegionSelector.PleaseSelectRegion", resourceCulture);

	public static string Menu_RegionSelector_Region => ResourceManager.GetString("Menu.RegionSelector.Region", resourceCulture);

	public static string Menu_RegionSelector_RegionHeader => ResourceManager.GetString("Menu.RegionSelector.RegionHeader", resourceCulture);

	public static string Menu_RegionSelector_SearchingServers => ResourceManager.GetString("Menu.RegionSelector.SearchingServers", resourceCulture);

	public static string Menu_RegionSelector_ServerSize => ResourceManager.GetString("Menu.RegionSelector.ServerSize", resourceCulture);

	public static string Menu_RegionSelector_SmallServers => ResourceManager.GetString("Menu.RegionSelector.SmallServers", resourceCulture);

	public static string Menu_RegionSelector_Title => ResourceManager.GetString("Menu.RegionSelector.Title", resourceCulture);

	public static string Menu_RegionSelector_UsingCachedData => ResourceManager.GetString("Menu.RegionSelector.UsingCachedData", resourceCulture);

	public static string Menu_Restart => ResourceManager.GetString("Menu.Restart", resourceCulture);

	public static string Menu_Save => ResourceManager.GetString("Menu.Save", resourceCulture);

	public static string Menu_SearchBar_AutoJoin => ResourceManager.GetString("Menu.SearchBar.AutoJoin", resourceCulture);

	public static string Menu_SearchBar_JoinError => ResourceManager.GetString("Menu.SearchBar.JoinError", resourceCulture);

	public static string Menu_SearchBar_JoiningBest => ResourceManager.GetString("Menu.SearchBar.JoiningBest", resourceCulture);

	public static string Menu_SearchBar_JoiningGame => ResourceManager.GetString("Menu.SearchBar.JoiningGame", resourceCulture);

	public static string Menu_SearchBar_JoiningName => ResourceManager.GetString("Menu.SearchBar.JoiningName", resourceCulture);

	public static string Menu_SearchBar_NoSuitableServer => ResourceManager.GetString("Menu.SearchBar.NoSuitableServer", resourceCulture);

	public static string Menu_SearchBar_SearchSomething => ResourceManager.GetString("Menu.SearchBar.SearchSomething", resourceCulture);

	public static string Menu_SearchBar_ServerFound => ResourceManager.GetString("Menu.SearchBar.ServerFound", resourceCulture);

	public static string Menu_SettingsSaved_Message => ResourceManager.GetString("Menu.SettingsSaved.Message", resourceCulture);

	public static string Menu_SettingsSaved_Title => ResourceManager.GetString("Menu.SettingsSaved.Title", resourceCulture);

	public static string Menu_Shortcuts_CreateShortcut => ResourceManager.GetString("Menu.Shortcuts.CreateShortcut", resourceCulture);

	public static string Menu_Shortcuts_Description => ResourceManager.GetString("Menu.Shortcuts.Description", resourceCulture);

	public static string Menu_Shortcuts_ErrorCreatingShortcut => ResourceManager.GetString("Menu.Shortcuts.ErrorCreatingShortcut", resourceCulture);

	public static string Menu_Shortcuts_ExtractIcons_Description => ResourceManager.GetString("Menu.Shortcuts.ExtractIcons.Description", resourceCulture);

	public static string Menu_Shortcuts_ExtractIcons_Title => ResourceManager.GetString("Menu.Shortcuts.ExtractIcons.Title", resourceCulture);

	public static string Menu_Shortcuts_Function_Description => ResourceManager.GetString("Menu.Shortcuts.Function.Description", resourceCulture);

	public static string Menu_Shortcuts_Function_Title => ResourceManager.GetString("Menu.Shortcuts.Function.Title", resourceCulture);

	public static string Menu_Shortcuts_Game => ResourceManager.GetString("Menu.Shortcuts.Game", resourceCulture);

	public static string Menu_Shortcuts_GameShortcut_Title => ResourceManager.GetString("Menu.Shortcuts.GameShortcut.Title", resourceCulture);

	public static string Menu_Shortcuts_General_Description => ResourceManager.GetString("Menu.Shortcuts.General.Description", resourceCulture);

	public static string Menu_Shortcuts_General_Title => ResourceManager.GetString("Menu.Shortcuts.General.Title", resourceCulture);

	public static string Menu_Shortcuts_Misc_Description => ResourceManager.GetString("Menu.Shortcuts.Misc.Description", resourceCulture);

	public static string Menu_Shortcuts_NoGameSelected => ResourceManager.GetString("Menu.Shortcuts.NoGameSelected", resourceCulture);

	public static string Menu_Shortcuts_PrivateAccessCode => ResourceManager.GetString("Menu.Shortcuts.PrivateAccessCode", resourceCulture);

	public static string Menu_Shortcuts_Processing => ResourceManager.GetString("Menu.Shortcuts.Processing", resourceCulture);

	public static string Menu_Shortcuts_Ready => ResourceManager.GetString("Menu.Shortcuts.Ready", resourceCulture);

	public static string Menu_Shortcuts_ReadyToCreate => ResourceManager.GetString("Menu.Shortcuts.ReadyToCreate", resourceCulture);

	public static string Menu_Shortcuts_ReadyWithManualId => ResourceManager.GetString("Menu.Shortcuts.ReadyWithManualId", resourceCulture);

	public static string Menu_Shortcuts_SearchForGame => ResourceManager.GetString("Menu.Shortcuts.SearchForGame", resourceCulture);

	public static string Menu_Shortcuts_SelectGameFirst => ResourceManager.GetString("Menu.Shortcuts.SelectGameFirst", resourceCulture);

	public static string Menu_Shortcuts_ServerInstanceId => ResourceManager.GetString("Menu.Shortcuts.ServerInstanceId", resourceCulture);

	public static string Menu_Shortcuts_ShortcutCreated => ResourceManager.GetString("Menu.Shortcuts.ShortcutCreated", resourceCulture);

	public static string Menu_Shortcuts_UpdatingPreview => ResourceManager.GetString("Menu.Shortcuts.UpdatingPreview", resourceCulture);

	public static string Menu_TestMode => ResourceManager.GetString("Menu.TestMode", resourceCulture);

	public static string Menu_TestMode_Description => ResourceManager.GetString("Menu.TestMode.Description", resourceCulture);

	public static string Menu_TestMode_Prompt => ResourceManager.GetString("Menu.TestMode.Prompt", resourceCulture);

	public static string Menu_Title => ResourceManager.GetString("Menu.Title", resourceCulture);

	public static string Menu_UnsavedChangesPrompt => ResourceManager.GetString("Menu.UnsavedChangesPrompt", resourceCulture);

	public static string Onboarding_Page2 => ResourceManager.GetString("Onboarding.Page2", resourceCulture);

	public static string Onboarding_Page3_Text1 => ResourceManager.GetString("Onboarding.Page3.Text1", resourceCulture);

	public static string Onboarding_Page3_Text2 => ResourceManager.GetString("Onboarding.Page3.Text2", resourceCulture);

	public static string Onboarding_Page4 => ResourceManager.GetString("Onboarding.Page4", resourceCulture);

	public static string Onboarding_Page7_Text1 => ResourceManager.GetString("Onboarding.Page7.Text1", resourceCulture);

	public static string Onboarding_Page7_Text2 => ResourceManager.GetString("Onboarding.Page7.Text2", resourceCulture);

	public static string Onboarding_Page7_Text3 => ResourceManager.GetString("Onboarding.Page7.Text3", resourceCulture);

	public static string Onboarding_Title => ResourceManager.GetString("Onboarding.Title", resourceCulture);

	public static string Paths_Icons => ResourceManager.GetString("Paths.Icons", resourceCulture);

	public static string ProfileNamePlaceholder => ResourceManager.GetString("ProfileNamePlaceholder", resourceCulture);

	public static string Sober_FlatpakInstallFailed => ResourceManager.GetString("Sober.FlatpakInstallFailed", resourceCulture);

	public static string Sober_LaunchFailed => ResourceManager.GetString("Sober.LaunchFailed", resourceCulture);

	public static string Uninstaller_KeepData_Description => ResourceManager.GetString("Uninstaller.KeepData.Description", resourceCulture);

	public static string Uninstaller_KeepData_Label => ResourceManager.GetString("Uninstaller.KeepData.Label", resourceCulture);

	public static string Uninstaller_Text => ResourceManager.GetString("Uninstaller.Text", resourceCulture);

	public static string Uninstaller_Title => ResourceManager.GetString("Uninstaller.Title", resourceCulture);

	public static string Uninstaller_Uninstall => ResourceManager.GetString("Uninstaller.Uninstall", resourceCulture);

	public static string Update_Available => ResourceManager.GetString("Update.Available", resourceCulture);

	public static string Update_Linux_Available => ResourceManager.GetString("Update.Linux.Available", resourceCulture);

	public static string Update_NoPackageAvailable => ResourceManager.GetString("Update.NoPackageAvailable", resourceCulture);

	internal Strings()
	{
	}
}
