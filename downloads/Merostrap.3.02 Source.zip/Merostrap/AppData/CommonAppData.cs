using System.Collections.Generic;
using System.IO;
using Merostrap.Models.Persistable;

namespace Merostrap.AppData;

internal abstract class CommonAppData
{
	public virtual string ExecutableName { get; }

	public virtual string BinaryType { get; }

	public string StaticDirectory => Path.Combine(Paths.Versions, BinaryType);

	public string DynamicDirectory => Path.Combine(Paths.Versions, DistributionState.VersionGuid);

	public string Directory
	{
		get
		{
			if (!App.Settings.Prop.StaticDirectory)
			{
				return DynamicDirectory;
			}
			return StaticDirectory;
		}
	}

	public bool IsInstalled
	{
		get
		{
			if (DistributionStateManager.IsSaved && !string.IsNullOrEmpty(DistributionState.VersionGuid))
			{
				return System.IO.Directory.Exists(Directory);
			}
			return false;
		}
	}

	public string ExecutablePath => Path.Combine(Directory, ExecutableName);

	public virtual JsonManager<DistributionState> DistributionStateManager { get; }

	public DistributionState DistributionState => DistributionStateManager.Prop;

	public IReadOnlyList<string> ModManifest => DistributionState.ModManifest;
}
