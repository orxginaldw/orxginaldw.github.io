using System;
using Merostrap.Models.Persistable;

namespace Merostrap.AppData;

internal class RobloxPlayerData : CommonAppData, IAppData
{
	public string ProductName => "Roblox";

	public override string BinaryType
	{
		get
		{
			if (!OperatingSystem.IsMacOS())
			{
				return "WindowsPlayer";
			}
			return "MacPlayer";
		}
	}

	public string RegistryName => "RobloxPlayer";

	public string ProcessName
	{
		get
		{
			if (!OperatingSystem.IsMacOS())
			{
				return "RobloxPlayerBeta";
			}
			return "RobloxPlayer";
		}
	}

	public override string ExecutableName => App.RobloxPlayerAppName;

	public override JsonManager<DistributionState> DistributionStateManager => App.PlayerState;
}
