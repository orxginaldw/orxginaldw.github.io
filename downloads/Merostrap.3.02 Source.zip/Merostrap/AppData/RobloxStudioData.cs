using System;
using Merostrap.Models.Persistable;

namespace Merostrap.AppData;

internal class RobloxStudioData : CommonAppData, IAppData
{
	public string ProductName => "Roblox Studio";

	public override string BinaryType
	{
		get
		{
			if (!OperatingSystem.IsMacOS())
			{
				return "WindowsStudio64";
			}
			return "MacStudio";
		}
	}

	public string RegistryName => "RobloxStudio";

	public string ProcessName
	{
		get
		{
			if (!OperatingSystem.IsMacOS())
			{
				return "RobloxStudioBeta";
			}
			return "RobloxStudio";
		}
	}

	public override string ExecutableName => App.RobloxStudioAppName;

	public override JsonManager<DistributionState> DistributionStateManager => App.StudioState;
}
