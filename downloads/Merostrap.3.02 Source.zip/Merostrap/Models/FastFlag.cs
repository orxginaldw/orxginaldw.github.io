using LucideAvalonia.Enum;
using Merostrap.UI.ViewModels;

namespace Merostrap.Models;

internal class FastFlag : NotifyPropertyChangedViewModel
{
	private LucideIconNames _preset = LucideIconNames.CircleCheck;

	private string _name = string.Empty;

	private string _value = string.Empty;

	public LucideIconNames Preset
	{
		get
		{
			return _preset;
		}
		set
		{
			SetProperty(ref _preset, value, "Preset");
		}
	}

	public string Name
	{
		get
		{
			return _name;
		}
		set
		{
			SetProperty(ref _name, value, "Name");
		}
	}

	public string Value
	{
		get
		{
			return _value;
		}
		set
		{
			SetProperty(ref _value, value, "Value");
		}
	}
}
