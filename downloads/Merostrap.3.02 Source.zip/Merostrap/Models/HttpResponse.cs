using System.Collections.Generic;

namespace Merostrap.Models;

internal class HttpResponse<T>
{
	public T Data { get; set; }

	public List<string> Cookies { get; set; } = new List<string>();
}
