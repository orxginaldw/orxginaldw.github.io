using System.Linq;
using Merostrap.UI.ViewModels;

namespace Merostrap.Models;

internal class GradientStops : NotifyPropertyChangedViewModel
{
	private double _offset;

	private string _color = "#FFFFFF";

	public double Offset
	{
		get
		{
			return _offset;
		}
		set
		{
			_offset = value;
			OnPropertyChanged("Offset");
		}
	}

	public string Color
	{
		get
		{
			return _color;
		}
		set
		{
			string text = (string.IsNullOrWhiteSpace(value) ? value : string.Concat(value.Where((char c) => !char.IsWhiteSpace(c))));
			if (_color != text)
			{
				_color = text;
				OnPropertyChanged("Color");
			}
		}
	}
}
