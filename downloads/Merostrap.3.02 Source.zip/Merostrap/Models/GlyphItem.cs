using Avalonia.Media;

namespace Merostrap.Models;

internal class GlyphItem
{
	public Geometry? Data { get; set; }

	public IBrush? Brush { get; set; }
}
