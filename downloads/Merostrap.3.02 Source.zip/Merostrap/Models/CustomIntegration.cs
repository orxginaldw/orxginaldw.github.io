using Merostrap.UI.ViewModels;

namespace Merostrap.Models;

internal class CustomIntegration : NotifyPropertyChangedViewModel
{
	private string _name = "";

	private string _location = "";

	private bool _specifyGame;

	public string Name
	{
		get
		{
			return _name;
		}
		set
		{
			_name = value;
			OnPropertyChanged("Name");
		}
	}

	public string Location
	{
		get
		{
			return _location;
		}
		set
		{
			_location = value;
			OnPropertyChanged("Location");
		}
	}

	public bool SpecifyGame
	{
		get
		{
			return _specifyGame;
		}
		set
		{
			_specifyGame = value;
			OnPropertyChanged("SpecifyGame");
		}
	}

	public string LaunchArgs { get; set; } = "";

	public string GameID { get; set; } = "";

	public bool AutoCloseOnGame { get; set; } = true;

	public int Delay { get; set; }

	public bool PreLaunch { get; set; }

	public bool AutoClose { get; set; } = true;
}
