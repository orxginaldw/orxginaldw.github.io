using System.Text.Json;
using System.Text.Json.Serialization;

namespace Merostrap.Models.MerostrapStudioRPC;

internal class StudioMessage
{
	[JsonPropertyName("command")]
	public string StudioCommand { get; set; }

	[JsonPropertyName("data")]
	public JsonElement Data { get; set; }
}
