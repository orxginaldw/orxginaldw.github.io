using System.Text.Json.Serialization;

namespace Merostrap.Models.MerostrapStudioRPC;

internal class StudioRichPresence
{
	[JsonPropertyName("details")]
	public string Details { get; set; } = "";

	[JsonPropertyName("state")]
	public string State { get; set; } = "";

	[JsonPropertyName("testing")]
	public bool Testing { get; set; }

	[JsonPropertyName("scriptType")]
	public string ScriptType { get; set; } = "developing";

	[JsonPropertyName("placeId")]
	public long PlaceId { get; set; }

	[JsonPropertyName("isPublic")]
	public bool IsPublic { get; set; }

	[JsonPropertyName("devCount")]
	public int DevCount { get; set; } = 1;
}
