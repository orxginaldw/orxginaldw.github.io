using Avalonia.Media;
using Merostrap.Enums;
using Merostrap.Extensions;
using Merostrap.UI.ViewModels;

namespace Merostrap.Models;

internal class BootstrapperIconEntry : NotifyPropertyChangedViewModel
{
	public BootstrapperIcon IconType { get; set; }

	public IImage? ImageSource => IconType.GetIcon()?.GetImageSource();

	public void RefreshImage()
	{
		OnPropertyChanged("ImageSource");
	}
}
