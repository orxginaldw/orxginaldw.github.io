using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Merostrap.Access;
using Merostrap.Models.APIs.Roblox;
using Merostrap.RobloxInterfaces;

namespace Merostrap.Models.Entities;

internal static class GameSearching
{
	public static async Task<List<OmniSearchContent>> GetGameSearchResultsAsync(string searchQuery, CancellationToken token = default(CancellationToken), bool throwOnError = false)
	{
		List<OmniSearchContent> results = new List<OmniSearchContent>();
		if (string.IsNullOrWhiteSpace(searchQuery))
		{
			App.Logger.Error("Search query is empty.");
			return results;
		}
		try
		{
			new Uri($"https://apis.{Deployment.RobloxDomain}/search-api/omni-search?searchQuery={Uri.EscapeDataString(searchQuery)}&sessionid=0&pageType=Game");
			OmniSearchResponse omniSearchResponse = JsonSerializer.Deserialize<OmniSearchResponse>(await AccessClient.SearchGamesAsync(searchQuery, token));
			if (omniSearchResponse?.SearchResults == null)
			{
				App.Logger.Error("Search API returned no results.");
				return results;
			}
			HashSet<ulong> hashSet = new HashSet<ulong>();
			foreach (OmniSearchGroup searchResult in omniSearchResponse.SearchResults)
			{
				if (results.Count >= 5)
				{
					break;
				}
				if (searchResult.Contents == null)
				{
					continue;
				}
				foreach (OmniSearchContent content in searchResult.Contents)
				{
					if (results.Count < 5)
					{
						if (content.UniverseId != 0L && hashSet.Add(content.UniverseId))
						{
							results.Add(new OmniSearchContent
							{
								UniverseId = content.UniverseId,
								RootPlaceId = content.RootPlaceId,
								Name = (content.Name ?? $"Game {content.UniverseId}"),
								PlayerCount = content.PlayerCount
							});
						}
						continue;
					}
					break;
				}
			}
		}
		catch (Exception ex) when (!throwOnError)
		{
			App.Logger.Error("Error fetching search results: " + ex.Message);
		}
		return results;
	}

	public static async Task<(List<OmniSearchContent> Results, string NextCursor)> GetDetailedGameSearchResultsAsync(string keyword, string cursor = "")
	{
		List<OmniSearchContent> results = new List<OmniSearchContent>();
		if (string.IsNullOrWhiteSpace(keyword))
		{
			return (Results: results, NextCursor: "");
		}
		try
		{
			string value = (string.IsNullOrEmpty(cursor) ? "" : ("&pageToken=" + Uri.EscapeDataString(cursor)));
			new Uri($"https://apis.{Deployment.RobloxDomain}/search-api/omni-search?searchQuery={Uri.EscapeDataString(keyword)}&sessionId=0&pageType=Game{value}");
			JsonDocument jsonDocument = JsonDocument.Parse(await AccessClient.SearchGamesAsync(keyword, default, cursor));
			if (jsonDocument != null && jsonDocument.RootElement.TryGetProperty("searchResults", out var value2) && value2.ValueKind == JsonValueKind.Array)
			{
				string item = "";
				if (jsonDocument.RootElement.TryGetProperty("nextPageToken", out var value3) && value3.ValueKind == JsonValueKind.String)
				{
					item = value3.GetString() ?? "";
				}
				HashSet<ulong> hashSet = new HashSet<ulong>();
				foreach (JsonElement item2 in value2.EnumerateArray())
				{
					if (!item2.TryGetProperty("contents", out var value4) || value4.ValueKind != JsonValueKind.Array)
					{
						continue;
					}
					foreach (JsonElement item3 in value4.EnumerateArray())
					{
						ulong num = (ulong)(item3.TryGetProperty("universeId", out var value5) ? value5.GetInt64() : 0);
						long rootPlaceId = (item3.TryGetProperty("rootPlaceId", out var value6) ? value6.GetInt64() : 0);
						string name = (item3.TryGetProperty("name", out var value7) ? (value7.GetString() ?? $"Game {num}") : $"Game {num}");
						int value8 = (item3.TryGetProperty("playerCount", out var value9) ? value9.GetInt32() : 0);
						if (num != 0L && hashSet.Add(num))
						{
							results.Add(new OmniSearchContent
							{
								UniverseId = num,
								RootPlaceId = rootPlaceId,
								Name = name,
								PlayerCount = value8
							});
						}
					}
				}
				return (Results: results, NextCursor: item);
			}
		}
		catch (Exception ex)
		{
			App.Logger.Error("Error fetching detailed search results: " + ex.Message);
		}
		return (Results: results, NextCursor: "");
	}
}
