using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Merostrap.Exceptions;
using Merostrap.Models.APIs.Roblox;
using Merostrap.Models.RobloxApi;
using Merostrap.Utility;

namespace Merostrap.Models.Entities;

internal class UserDetails
{
	private static List<UserDetails> Cache { get; set; } = new List<UserDetails>();

	public GetUserResponse Data { get; set; }

	public ThumbnailResponse Thumbnail { get; set; }

	public static async Task<UserDetails> Fetch(long id)
	{
		Uri url = UrlBuilder.BuildApiUrl("users", "v1/users/" + id);
		Uri thumbnailsUrl = UrlBuilder.BuildApiUrl("thumbnails", $"v1/users/avatar-headshot?userIds={id}&size=180x180&format=Png&isCircular=false");
		UserDetails userDetails = Cache.FirstOrDefault((UserDetails x) =>
		{
			GetUserResponse data = x.Data;
			return data != null && data.Id == id;
		});
		if (userDetails != null)
		{
			return userDetails;
		}
		GetUserResponse userResponse = await Http.GetJson<GetUserResponse>(url);
		if (userResponse == null)
		{
			throw new InvalidHTTPResponseException("Roblox API for User Details returned invalid data");
		}
		ApiArrayResponse<ThumbnailResponse> apiArrayResponse = await Http.GetJson<ApiArrayResponse<ThumbnailResponse>>(thumbnailsUrl);
		if (apiArrayResponse == null || !apiArrayResponse.Data.Any())
		{
			throw new InvalidHTTPResponseException("Roblox API for Thumbnails returned invalid data");
		}
		UserDetails userDetails2 = new UserDetails
		{
			Data = userResponse,
			Thumbnail = apiArrayResponse.Data.First()
		};
		Cache.Add(userDetails2);
		return userDetails2;
	}
}
