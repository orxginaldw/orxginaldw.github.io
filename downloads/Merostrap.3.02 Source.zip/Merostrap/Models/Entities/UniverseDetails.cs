using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Merostrap.Models.APIs.Roblox;
using Merostrap.Utility;

namespace Merostrap.Models.Entities;

internal class UniverseDetails
{
	private static List<UniverseDetails> Cache { get; set; } = new List<UniverseDetails>();

	public GameDetailResponse Data { get; set; }

	public ThumbnailResponse Thumbnail { get; set; }

	public static UniverseDetails? LoadFromCache(long id)
	{
		return Cache.FirstOrDefault((UniverseDetails x) =>
		{
			GameDetailResponse data = x.Data;
			return data != null && data.Id == id;
		});
	}

	public static Task FetchSingle(long id)
	{
		return FetchBulk(id.ToString(CultureInfo.InvariantCulture));
	}

	public static async Task FetchBulk(string ids)
	{
		if (string.IsNullOrWhiteSpace(ids))
		{
			return;
		}
		List<long> list = (from id in ids.Split(',')
			where long.TryParse(id, CultureInfo.InvariantCulture, out var _)
			select id).Select(long.Parse).Distinct().ToList();
		if (list.Count == 0)
		{
			return;
		}
		List<string> list2 = (from x in list.Select((long id, int index) => new { id, index })
			group x by x.index / 50 into g
			select string.Join(",", g.Select(x => x.id))).ToList();
		List<GameDetailResponse> gameDetailResults = new List<GameDetailResponse>();
		List<ThumbnailResponse> thumbnailResults = new List<ThumbnailResponse>();
		foreach (string item in list2)
		{
			Uri url = UrlBuilder.BuildApiUrl("games", "v1/games?universeIds=" + item);
			Uri thumbnailsUrl = UrlBuilder.BuildApiUrl("thumbnails", "v1/games/icons?universeIds=" + item + "&returnPolicy=PlaceHolder&size=128x128&format=Png&isCircular=false");
			ApiArrayResponse<GameDetailResponse> apiArrayResponse = ((!App.Cookies.Loaded) ? (await Http.GetJson<ApiArrayResponse<GameDetailResponse>>(url)) : (await Http.AuthGetJson<ApiArrayResponse<GameDetailResponse>>(url)));
			if (apiArrayResponse.Data.Any())
			{
				gameDetailResults.AddRange(apiArrayResponse.Data);
			}
			ApiArrayResponse<ThumbnailResponse> apiArrayResponse2 = await Http.GetJson<ApiArrayResponse<ThumbnailResponse>>(thumbnailsUrl);
			if (apiArrayResponse2.Data.Any())
			{
				thumbnailResults.AddRange(apiArrayResponse2.Data);
			}
		}
		List<UniverseDetails> list3 = new List<UniverseDetails>();
		foreach (GameDetailResponse game in gameDetailResults)
		{
			if (Cache.FirstOrDefault((UniverseDetails x) => x.Data?.Id == game.Id) == null)
			{
				ThumbnailResponse thumbnail = thumbnailResults.FirstOrDefault((ThumbnailResponse t) => t.TargetId == game.Id) ?? new ThumbnailResponse
				{
					TargetId = game.Id,
					ImageUrl = ""
				};
				list3.Add(new UniverseDetails
				{
					Data = game,
					Thumbnail = thumbnail
				});
			}
		}
		if (list3.Count > 0)
		{
			Cache.AddRange(list3);
		}
	}
}
