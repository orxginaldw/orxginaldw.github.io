using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Input;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Input.Platform;
using Avalonia.Media.Imaging;
using CommunityToolkit.Mvvm.Input;
using Merostrap.Enums;
using Merostrap.Enums.Messagebox;
using Merostrap.Exceptions;
using Merostrap.Models.APIs;
using Merostrap.UI;
using Merostrap.Utility;

namespace Merostrap.Models.Entities;

internal sealed class ActivityData : IDisposable
{
	private long _universeId;

	private readonly SemaphoreSlim _serverQuerySemaphore = new SemaphoreSlim(1, 1);

	private bool _disposed;

	public ActivityData? RootActivity { get; set; }

	public long UniverseId
	{
		get
		{
			return _universeId;
		}
		set
		{
			_universeId = value;
		}
	}

	public long PlaceId { get; set; }

	public string JobId { get; set; } = string.Empty;

	public string Region { get; set; } = string.Empty;

	public string AccessCode { get; set; } = string.Empty;

	public long UserId { get; set; }

	public string MachineAddress { get; set; } = string.Empty;

	public bool MachineAddressValid
	{
		get
		{
			if (!string.IsNullOrEmpty(MachineAddress))
			{
				return !MachineAddress.StartsWith("10.", StringComparison.Ordinal);
			}
			return false;
		}
	}

	public bool IsTeleport { get; set; }

	public ServerType ServerType { get; set; }

	public DateTime TimeJoined { get; set; }

	public DateTime? TimeLeft { get; set; }

	public DateTime? StartTime { get; set; }

	public string RPCLaunchData { get; set; } = string.Empty;

	public UniverseDetails? UniverseDetails { get; set; }

	public string? RootJobId { get; set; }

	public Bitmap? ThumbnailBitmap { get; set; }

	public ICommand RejoinServerCommand => new RelayCommand(() =>
	{
		RejoinServer();
	});

	public ICommand CopyDeeplinkCommand => new RelayCommand<Visual>(CopyDeeplink);

	public ICommand CopyServerIdCommand => new RelayCommand<Visual>(CopyServerId);

	public ICommand DeleteHistoryCommand => new RelayCommand(DeleteHistory);

	public event EventHandler<string>? OnDeleteRequested;

	public string GetInviteDeeplink(bool launchData = true, DeeplinkType type = DeeplinkType.RobloxProtocol)
	{
		string value = type switch
		{
			DeeplinkType.Merostrap => "http://merostrap.xyz/invite", 
			DeeplinkType.RobloxWeb => "https://www.roblox.com/games/start", 
			_ => "roblox://experiences/start", 
		};
		string text = $"{value}?placeId={PlaceId}";
		if (ServerType == ServerType.Private)
		{
			if (!string.IsNullOrEmpty(AccessCode))
			{
				text = text + "&accessCode=" + AccessCode;
			}
		}
		else
		{
			text = text + "&gameInstanceId=" + JobId;
		}
		if (launchData && !string.IsNullOrEmpty(RPCLaunchData))
		{
			text = text + "&launchData=" + HttpUtility.UrlEncode(RPCLaunchData);
		}
		return text;
	}

	public async Task<string?> QueryServerLocation()
	{
		if (!MachineAddressValid)
		{
			throw new InvalidOperationException("Machine address is invalid (" + MachineAddress + ")");
		}
		await _serverQuerySemaphore.WaitAsync();
		if (GlobalCache.ServerLocation.TryGetValue(MachineAddress, out string location))
		{
			_serverQuerySemaphore.Release();
			return location;
		}
		try
		{
			IPInfoResponse iPInfoResponse = await Http.GetJson<IPInfoResponse>(new Uri("https://ipinfo.io/" + MachineAddress + "/json"));
			if (string.IsNullOrEmpty(iPInfoResponse.City))
			{
				throw new InvalidHTTPResponseException("Reported city was blank");
			}
			location = ((!(iPInfoResponse.City == iPInfoResponse.Region)) ? $"{iPInfoResponse.City}, {iPInfoResponse.Region}, {iPInfoResponse.Country}" : (iPInfoResponse.Region + ", " + iPInfoResponse.Country));
			GlobalCache.ServerLocation[MachineAddress] = location;
			_serverQuerySemaphore.Release();
		}
		catch (Exception ex)
		{
			App.Logger.Error("Failed to get server location for " + MachineAddress + ": " + ex.Message);
			GlobalCache.ServerLocation[MachineAddress] = location;
			_serverQuerySemaphore.Release();
		}
		return location;
	}

	public void RejoinServer(bool CloseRoblox = true)
	{
		try
		{
			App.Logger.Info($"Rejoining server: {PlaceId}/{JobId}");
			string inviteDeeplink = GetInviteDeeplink();
			Process.Start(new ProcessStartInfo
			{
				FileName = inviteDeeplink,
				UseShellExecute = true
			});
			if (CloseRoblox)
			{
				CloseRobloxProcesses();
			}
		}
		catch (Exception ex)
		{
			App.Logger.Error("Failed to rejoin server: " + ex.Message);
			Frontend.ShowMessageBox("Failed to rejoin server: " + ex.Message, MessageBoxImage.Error);
		}
	}

	public static void CloseRobloxProcesses()
	{
		try
		{
			Process[] processesByName = Process.GetProcessesByName("RobloxPlayerBeta");
			if (processesByName.Length == 0)
			{
				App.Logger.Info("Roblox not found");
				return;
			}
			Process[] array = processesByName;
			foreach (Process process in array)
			{
				if ((DateTime.Now - process.StartTime).TotalSeconds < 3.0)
				{
					App.Logger.Info("Skipping new process");
				}
				else
				{
					process.Kill();
				}
			}
		}
		catch (Exception ex)
		{
			App.Logger.Error("Roblox could not be closed: " + ex.Message);
		}
	}

	private async void CopyDeeplink(Visual? visual)
	{
		TopLevel topLevel = TopLevel.GetTopLevel(visual);
		if (topLevel?.Clipboard != null)
		{
			await topLevel.Clipboard.SetTextAsync(GetInviteDeeplink(launchData: true, DeeplinkType.RobloxWeb));
		}
	}

	private async void CopyServerId(Visual? visual)
	{
		TopLevel topLevel = TopLevel.GetTopLevel(visual);
		if (topLevel?.Clipboard != null)
		{
			await topLevel.Clipboard.SetTextAsync(JobId);
		}
	}

	private void DeleteHistory()
	{
		string text = ((!string.IsNullOrEmpty(RootJobId)) ? RootJobId : JobId);
		if (!string.IsNullOrEmpty(text))
		{
			OnDeleteRequested?.Invoke(this, text);
		}
	}

	public void Dispose()
	{
		Dispose(disposing: true);
		GC.SuppressFinalize(this);
	}

	private void Dispose(bool disposing)
	{
		if (!_disposed)
		{
			if (disposing)
			{
				_serverQuerySemaphore?.Dispose();
			}
			_disposed = true;
		}
	}
}
