using System;
using System.IO;
using Merostrap.Utility;

namespace Merostrap.Models.Entities;

internal class ModPresetFileData
{
	public string FilePath { get; private set; }

	public string FullFilePath => Path.Combine(Paths.Modifications, FilePath);

	public FileStream FileStream => File.OpenRead(FullFilePath);

	public string ResourceIdentifier { get; private set; }

	public Stream ResourceStream => Resource.GetStream(ResourceIdentifier);

	public string ResourceHash { get; private set; }

	public ModPresetFileData(string contentPath, string resource)
	{
		if (OperatingSystem.IsLinux())
		{
			string[] paths = contentPath.Split(new char[2] { '\\', '/' }, StringSplitOptions.RemoveEmptyEntries);
			FilePath = Path.Combine(paths);
		}
		else
		{
			FilePath = contentPath;
		}
		ResourceIdentifier = resource;
		using Stream stream = ResourceStream;
		ResourceHash = FastHash.FromStream(stream);
	}

	public bool HashMatches()
	{
		if (!File.Exists(FullFilePath))
		{
			return false;
		}
		using FileStream stream = FileStream;
		return FastHash.FromStream(stream) == ResourceHash;
	}
}
