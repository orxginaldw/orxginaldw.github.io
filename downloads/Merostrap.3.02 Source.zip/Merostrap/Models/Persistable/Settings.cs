using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Merostrap.Enums;
using Merostrap.Enums.AppStoragePresets;
using Merostrap.Performance;
using Merostrap.Resources;

namespace Merostrap.Models.Persistable;

internal class Settings
{
	public bool EnableActivityTracking { get; set; } = true;

	public bool ShowServerDetails { get; set; } = true;

	public bool ShowServerUptime { get; set; } = true;

	public bool AutoRejoin { get; set; }

	public bool ShowGameHistoryMenu { get; set; } = true;

	public bool PlaytimeCounter { get; set; } = true;

	public TrayDoubleClickAction DoubleClickAction { get; set; }

	public bool UseDisableAppPatch { get; set; }

	public bool AutoChangeTitle { get; set; } = true;

	public bool AutoChangeTitleWithPlayerCount { get; set; } = true;

	public bool AutoChangeIcon { get; set; }

	public bool ShowUsingMerostrapRPC { get; set; }

	public bool UseDiscordRichPresence { get; set; } = true;

	public bool HideRPCButtons { get; set; } = true;

	public bool EnableCustomStatusDisplay { get; set; } = true;

	public bool ShowAccountOnRichPresence { get; set; }

	public bool StudioRPC { get; set; }

	public bool StudioThumbnailChanging { get; set; }

	public bool StudioEditingInfo { get; set; }

	public bool StudioWorkspaceInfo { get; set; }

	public bool StudioShowTesting { get; set; }

	public bool StudioGameButton { get; set; }

	public ObservableCollection<CustomIntegration> CustomIntegrations { get; set; } = new ObservableCollection<CustomIntegration>();

	public PerformanceOptions Performance { get; set; } = new PerformanceOptions();

	public List<UserSettingsPreset> SettingsPresets { get; set; } = new List<UserSettingsPreset>();

	public string? ActiveSettingsPreset { get; set; }

	public bool EnableMacrosOnLaunch { get; set; }

	public bool ConfirmLaunches { get; set; } = true;

	public bool MultiInstanceLaunching { get; set; }

	public bool AllowCookieAccess { get; set; }

	public bool AutoCloseCrashHandler { get; set; }

	public CleanerOptions CleanerOptions { get; set; }

	public List<string> CleanerDirectories { get; set; } = new List<string>();

	public bool BackgroundUpdatesEnabled
	{
		[CompilerGenerated]
		get
		{
			return false;
		}
		[CompilerGenerated]
		set
		{
		}
	}

	public bool LaunchWithVirtualDisplay { get; set; }

	public bool SoftKeyEnabled { get; set; }

	public SoftKeyProfile SoftKeyProfile { get; set; }

	public bool EnableBetterMatchmaking { get; set; }

	public string SelectedRegion { get; set; } = Strings.Common_Auto;

	public string PreferredRegion { get; set; } = "";

	public bool EnableRobloxBackgroundApp { get; set; }

	public RobloxTheme RobloxTheme { get; set; }

	public bool UseFastFlagManager { get; set; } = true;

	public bool AskBeforeUsingFastFlags { get; set; } = true;

	public Dictionary<string, List<string>> ProfilePlaceIds { get; set; } = new Dictionary<string, List<string>>();

	public BootstrapperStyle BootstrapperStyle { get; set; } = BootstrapperStyle.FluentAeroDialog;

	public string? SelectedCustomTheme { get; set; }

	public bool CycleEnabled { get; set; }

	public CycleFrequency CycleFrequency { get; set; }

	public int CycleIntervalValue { get; set; } = 1;

	public List<string> CycleEnabledCustomThemes { get; set; } = new List<string>();

	public int CycleCurrentIndex { get; set; }

	public DateTime CycleLastCycleTime { get; set; } = DateTime.MinValue;

	public BootstrapperIcon BootstrapperIcon { get; set; }

	public WindowsBackdrops SelectedBackdrop { get; set; } = WindowsBackdrops.None;

	public string Locale { get; set; } = "nil";

	public List<GradientStops> CustomGradientStops { get; set; }

	public double? GradientAngle { get; set; }

	public BackgroundMode BackgroundType { get; set; }

	public string? BackgroundImagePath { get; set; }

	public BackgroundStretch BackgroundStretch { get; set; }

	public double BackgroundOpacity { get; set; }

	public string BootstrapperTitle { get; set; }

	public string BootstrapperIconCustomLocation { get; set; }

	public Theme Theme { get; set; }

	public bool EnableWindowManipulation { get; set; }

	public RobloxIcon RobloxIcon { get; set; }

	public string RobloxTitle { get; set; }

	public string RobloxIconCustomLocation { get; set; }

	public UpdateCheck UpdateChecks
	{
		[CompilerGenerated]
		get
		{
			return UpdateCheck.Disabled;
		}
		[CompilerGenerated]
		set
		{
		}
	}

	public bool DisableAnimations { get; set; }

	public bool UpdateRoblox { get; set; }

	public bool AutomaticallyUpdateSober { get; set; }

	public int MaxThreadDownload { get; set; }

	public string RobloxDomain { get; set; }

	public bool StaticDirectory { get; set; }

	public string PlayerChannel { get; set; }

	public string StudioChannel { get; set; }

	public ChannelChangeMode ChannelChangeMode { get; set; }

	public bool StudioVersionOverrideEnabled { get; set; }

	public string StudioVersionOverrideHash { get; set; }

	public bool PlayerVersionOverrideEnabled { get; set; }

	public string PlayerVersionOverrideHash { get; set; }

	public bool EnableWebView2 { get; set; }

	public string? StudioVirtualDesktop { get; set; }

	public string? StudioLauncher { get; set; }

	public StudioRenderer StudioRenderer { get; set; }

	public bool StudioGameMode { get; set; }

	public bool StudioDebug { get; set; }

	public Dictionary<string, string> StudioEnvironmentVariables { get; set; }

	public bool ForceLocalData { get; set; }

	public bool DebugDisableVersionPackageCleanup { get; set; }

	public Settings()
	{
		int num = 3;
		List<GradientStops> list = new List<GradientStops>(num);
		CollectionsMarshal.SetCount(list, num);
		Span<GradientStops> span = CollectionsMarshal.AsSpan(list);
		span[0] = new GradientStops
		{
			Offset = 0.0,
			Color = "#8025304A"
		};
		span[1] = new GradientStops
		{
			Offset = 0.5,
			Color = "#80272F48"
		};
		span[2] = new GradientStops
		{
			Offset = 1.0,
			Color = "#80202C36"
		};
		CustomGradientStops = list;
		GradientAngle = 45.0;
		BackgroundImagePath = "";
		BackgroundStretch = BackgroundStretch.Fill;
		BackgroundOpacity = 1.0;
		BootstrapperTitle = "Merostrap";
		BootstrapperIconCustomLocation = "";
		RobloxTitle = "Roblox";
		RobloxIconCustomLocation = "";
		UpdateRoblox = true;
		AutomaticallyUpdateSober = true;
		MaxThreadDownload = 3;
		RobloxDomain = "roblox.com";
		PlayerChannel = "production";
		StudioChannel = "production";
		ChannelChangeMode = ChannelChangeMode.Prompt;
		StudioVersionOverrideHash = string.Empty;
		PlayerVersionOverrideHash = string.Empty;
		EnableWebView2 = true;
		StudioVirtualDesktop = string.Empty;
		StudioLauncher = string.Empty;
		StudioEnvironmentVariables = new Dictionary<string, string>();
		base._002Ector();
	}
}
