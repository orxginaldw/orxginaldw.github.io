using System.Collections.Generic;

namespace Merostrap.Models.Persistable;

internal class AppState
{
	public string VersionGuid { get; set; } = string.Empty;

	public Dictionary<string, string> PackageHashes { get; set; } = new Dictionary<string, string>();

	public int Size { get; set; }
}
