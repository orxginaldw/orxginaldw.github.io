using System.Collections.Generic;

namespace Merostrap.Models.Persistable;

internal class RobloxState
{
	public AppState Player { get; set; } = new AppState();

	public AppState Studio { get; set; } = new AppState();

	public List<string> ModManifest { get; set; } = new List<string>();
}
