using System.Collections.Generic;

namespace Merostrap.Models.Persistable;

internal class DistributionState
{
	public string VersionGuid { get; set; } = string.Empty;

	public Dictionary<string, string> PackageHashes { get; set; } = new Dictionary<string, string>();

	public List<string> ModManifest { get; set; } = new List<string>();
}
