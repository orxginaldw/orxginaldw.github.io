using System.Collections.Generic;
using Merostrap.Enums;

namespace Merostrap.Models.Persistable;

internal class State
{
	public bool TestModeWarningShown { get; set; }

	public bool PromptWebView2Install { get; set; } = true;

	public string? LastPage { get; set; }

	public bool ForceReinstall { get; set; }

	public bool IsFirstLaunch { get; set; } = true;

	public WindowState SettingsWindow { get; set; } = new WindowState();

	public LaunchMode LastLaunchMode { get; set; } = LaunchMode.Player;

	public string? LastMigratedVersion { get; set; }

	public List<ModConfig> Mods { get; set; } = new List<ModConfig>();
}
