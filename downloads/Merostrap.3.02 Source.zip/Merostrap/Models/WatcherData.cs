using System.Collections.Generic;
using Merostrap.Enums;

namespace Merostrap.Models;

internal class WatcherData
{
	public bool PerformanceMode { get; set; }

	public int ProcessId { get; set; }

	public string? LogFile { get; set; }

	public List<int>? AutoclosePids { get; set; }

	public LaunchMode LaunchMode { get; set; } = LaunchMode.Player;

	public string? AccessCode { get; set; }
}
