using Merostrap.Enums;

namespace Merostrap.Models;

internal class GameJoinData
{
	public GameJoinType JoinType;

	public string? JoinOrigin;

	public long? PlaceId { get; set; }

	public string? JobId { get; set; }

	public long? UserId { get; set; }

	public string? AccessCode { get; set; }

	public string PlaceLauncherUrl { get; set; } = string.Empty;
}
