using System.Text.Json.Serialization;

namespace Merostrap.Models;

internal class RobloxCookies
{
	[JsonPropertyName("CookiesVersion")]
	public string Version { get; set; }

	[JsonPropertyName("CookiesData")]
	public string Cookies { get; set; }
}
