using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Merostrap.Models;

internal class AccountManagerData
{
	[JsonPropertyName("accounts")]
	public List<AccountManagerAccount> Accounts { get; set; } = new List<AccountManagerAccount>();

	[JsonPropertyName("activeAccountId")]
	public long? ActiveAccountId { get; set; }

	[JsonPropertyName("lastUpdated")]
	public DateTime LastUpdated { get; set; } = DateTime.UtcNow;
}
