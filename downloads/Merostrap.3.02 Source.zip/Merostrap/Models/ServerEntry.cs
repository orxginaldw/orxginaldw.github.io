using System.Windows.Input;
using Merostrap.UI.ViewModels;

namespace Merostrap.Models;

internal class ServerEntry : NotifyPropertyChangedViewModel
{
	public int Number { get; set; }

	public string ServerId { get; set; }

	public string Region { get; set; }

	public int? DataCenterId { get; set; }

	public string Uptime { get; set; } = "Loading...";

	public ICommand? JoinCommand { get; set; }
}
