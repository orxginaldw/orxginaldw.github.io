using System;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Text.Json.Serialization;
using Avalonia.Media.Imaging;
using Merostrap.Enums;

namespace Merostrap.Models;

internal class ServerInfo
{
	[JsonPropertyName("jobId")]
	public string JobId { get; set; } = "";

	[JsonPropertyName("region")]
	public string Region { get; set; } = "";

	[JsonPropertyName("joinedAt")]
	public DateTime JoinedAt { get; set; }

	[JsonPropertyName("isLatest")]
	public bool IsLatest { get; set; }

	[JsonPropertyName("playing")]
	public int Playing { get; set; }

	[JsonPropertyName("maxPlayers")]
	public int MaxPlayers { get; set; }

	[JsonIgnore]
	public string PlayerCount => $"{Playing}/{MaxPlayers}";

	[JsonPropertyName("uptime")]
	public string Uptime { get; set; } = "";

	[JsonPropertyName("serverType")]
	public ServerType ServerType { get; set; }

	[JsonPropertyName("timeLeft")]
	public DateTime? TimeLeft { get; set; }

	[JsonIgnore]
	public ObservableCollection<Bitmap> PlayerAvatarThumbnails { get; } = new ObservableCollection<Bitmap>();

	[JsonIgnore]
	public Collection<string> PlayerTokens { get; } = new Collection<string>();

	[JsonIgnore]
	public string ExtraPlayersText { get; set; } = "";

	[JsonIgnore]
	public bool HasExtraPlayers { get; set; }

	public string DurationText
	{
		get
		{
			if (JoinedAt == default(DateTime))
			{
				return "";
			}
			string text = JoinedAt.ToString("HH:mm", CultureInfo.InvariantCulture);
			string text2 = (TimeLeft.HasValue ? TimeLeft.Value.ToString("HH:mm", CultureInfo.InvariantCulture) : "…");
			return "From " + text + " to " + text2;
		}
	}
}
