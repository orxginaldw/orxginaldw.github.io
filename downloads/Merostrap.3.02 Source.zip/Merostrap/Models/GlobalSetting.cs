using Merostrap.UI.ViewModels;

namespace Merostrap.Models;

internal class GlobalSetting : NotifyPropertyChangedViewModel
{
	private string _name = string.Empty;

	private string _value = string.Empty;

	private string? _vectorX;

	private string? _vectorY;

	public string Name
	{
		get
		{
			return _name;
		}
		set
		{
			SetProperty(ref _name, value, "Name");
		}
	}

	public string Value
	{
		get
		{
			return _value;
		}
		set
		{
			SetProperty(ref _value, value, "Value");
		}
	}

	public string? VectorX
	{
		get
		{
			return _vectorX;
		}
		set
		{
			SetProperty(ref _vectorX, value, "VectorX");
		}
	}

	public string? VectorY
	{
		get
		{
			return _vectorY;
		}
		set
		{
			SetProperty(ref _vectorY, value, "VectorY");
		}
	}

	public bool IsVector { get; set; }
}
