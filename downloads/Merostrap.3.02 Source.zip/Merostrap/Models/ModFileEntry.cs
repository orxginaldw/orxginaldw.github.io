using System;

namespace Merostrap.Models;

internal class ModFileEntry
{
	public long Size { get; set; }

	public DateTime LastModified { get; set; }
}
