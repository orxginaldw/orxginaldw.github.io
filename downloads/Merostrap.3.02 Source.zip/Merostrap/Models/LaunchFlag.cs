namespace Merostrap.Models;

internal class LaunchFlag(string identifiers)
{
	public bool Active;

	public string? Data;

	public string Identifiers { get; private set; } = identifiers;
}
