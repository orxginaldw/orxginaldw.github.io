using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs;

internal class IPInfoResponse
{
	[JsonPropertyName("city")]
	public string City { get; set; }

	[JsonPropertyName("country")]
	public string Country { get; set; }

	[JsonPropertyName("region")]
	public string Region { get; set; }

	[JsonPropertyName("loc")]
	public string Loc { get; set; }
}
