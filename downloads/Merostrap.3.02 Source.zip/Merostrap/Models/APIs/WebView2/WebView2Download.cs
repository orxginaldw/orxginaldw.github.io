namespace Merostrap.Models.APIs.WebView2;

internal class WebView2Download
{
	public string? Url { get; set; }

	public string? FileId { get; set; }
}
