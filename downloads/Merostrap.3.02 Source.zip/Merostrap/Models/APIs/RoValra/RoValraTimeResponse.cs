using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.RoValra;

internal class RoValraTimeResponse
{
	[JsonPropertyName("status")]
	public string Status;

	[JsonPropertyName("servers")]
	public List<RoValrasServer>? Servers { get; set; }
}
