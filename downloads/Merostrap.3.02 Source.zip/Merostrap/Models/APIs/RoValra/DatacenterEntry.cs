using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.RoValra;

internal class DatacenterEntry
{
	[JsonPropertyName("location")]
	public DatacenterLocation Location { get; set; } = new DatacenterLocation();

	[JsonPropertyName("dataCenterIds")]
	public List<int> DataCenterIds { get; set; } = new List<int>();
}
