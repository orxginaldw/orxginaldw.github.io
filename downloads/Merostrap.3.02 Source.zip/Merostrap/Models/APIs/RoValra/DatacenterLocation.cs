using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.RoValra;

internal class DatacenterLocation
{
	[JsonPropertyName("city")]
	public string City { get; set; } = "";

	[JsonPropertyName("country")]
	public string Country { get; set; } = string.Empty;

	[JsonPropertyName("latLong")]
	public string[] LatLong { get; set; }
}
