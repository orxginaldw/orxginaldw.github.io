using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.Roblox;

internal class OmniSearchResponse
{
	[JsonPropertyName("searchResults")]
	public List<OmniSearchGroup>? SearchResults { get; set; }
}
