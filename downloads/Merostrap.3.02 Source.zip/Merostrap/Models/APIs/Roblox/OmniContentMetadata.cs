using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.Roblox;

internal class OmniContentMetadata
{
	[JsonPropertyName("Game")]
	public Dictionary<string, OmniGameDetails>? Game { get; set; }
}
