using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.Roblox;

internal class ApiArrayResponse<T>
{
	[JsonPropertyName("data")]
	public IEnumerable<T> Data { get; set; }
}
