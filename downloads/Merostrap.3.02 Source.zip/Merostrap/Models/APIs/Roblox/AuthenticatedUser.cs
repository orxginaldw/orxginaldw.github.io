using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.Roblox;

internal class AuthenticatedUser
{
	[JsonPropertyName("id")]
	public long Id { get; set; }

	[JsonPropertyName("name")]
	public string Username { get; set; } = string.Empty;

	[JsonPropertyName("displayName")]
	public string DisplayName { get; set; } = string.Empty;
}
