using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.Roblox;

internal class OmniSearchGroup
{
	[JsonPropertyName("contents")]
	public List<OmniSearchContent>? Contents { get; set; }
}
