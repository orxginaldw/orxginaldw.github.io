using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.Roblox;

internal class OmniGameDetails
{
	[JsonPropertyName("name")]
	public string? Name { get; set; }

	[JsonPropertyName("universeId")]
	public long UniverseId { get; set; }

	[JsonPropertyName("rootPlaceId")]
	public long RootPlaceId { get; set; }

	[JsonPropertyName("playerCount")]
	public int PlayerCount { get; set; }

	[JsonPropertyName("totalUpVotes")]
	public int TotalUpVotes { get; set; }

	[JsonPropertyName("totalDownVotes")]
	public int TotalDownVotes { get; set; }
}
