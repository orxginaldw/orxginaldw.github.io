using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.Roblox;

internal class FetchResult
{
	[JsonPropertyName("data")]
	public List<ServerInstance> Servers { get; set; } = new List<ServerInstance>();

	[JsonPropertyName("nextPageCursor")]
	public string NextCursor { get; set; } = string.Empty;

	[JsonIgnore]
	public int NewlyFetchedCount { get; set; }
}
