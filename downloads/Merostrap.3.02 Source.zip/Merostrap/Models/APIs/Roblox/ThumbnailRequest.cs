using System.Text.Json.Serialization;
using Merostrap.Enums;

namespace Merostrap.Models.APIs.Roblox;

internal class ThumbnailRequest
{
	[JsonPropertyName("requestId")]
	public string? RequestId { get; set; }

	[JsonPropertyName("targetId")]
	public ulong? TargetId { get; set; }

	[JsonPropertyName("token")]
	[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
	public string? Token { get; set; }

	[JsonPropertyName("type")]
	[JsonConverter(typeof(JsonStringEnumConverter))]
	public ThumbnailType Type { get; set; }

	[JsonPropertyName("size")]
	public ThumbnailSize Size { get; set; }

	[JsonPropertyName("format")]
	[JsonConverter(typeof(JsonStringEnumConverter))]
	public ThumbnailFormat Format { get; set; }

	[JsonPropertyName("isCircular")]
	public bool IsCircular { get; set; }
}
