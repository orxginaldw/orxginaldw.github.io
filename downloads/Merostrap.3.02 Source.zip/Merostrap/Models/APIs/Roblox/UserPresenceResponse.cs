using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.Roblox;

internal class UserPresenceResponse
{
	[JsonPropertyName("userPresences")]
	public List<UserPresence> UserPresences { get; set; } = new List<UserPresence>();
}
