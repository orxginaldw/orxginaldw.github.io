using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.Roblox;

internal class CreatorData
{
	[JsonPropertyName("id")]
	public long Id { get; set; }

	[JsonPropertyName("type")]
	public string? Type { get; set; }

	[JsonPropertyName("name")]
	public string? Name { get; set; }
}
