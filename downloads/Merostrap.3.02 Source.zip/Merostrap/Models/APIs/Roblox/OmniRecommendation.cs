using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.Roblox;

internal class OmniRecommendation
{
	[JsonPropertyName("contentType")]
	public string? ContentType { get; set; }

	[JsonPropertyName("contentId")]
	public long ContentId { get; set; }

	[JsonPropertyName("contentStringId")]
	public string? ContentStringId { get; set; }
}
