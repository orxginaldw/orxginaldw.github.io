using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.Roblox;

internal class PrivateServersResponse
{
	[JsonPropertyName("data")]
	public List<PrivateServerData> Data { get; set; } = new List<PrivateServerData>();
}
