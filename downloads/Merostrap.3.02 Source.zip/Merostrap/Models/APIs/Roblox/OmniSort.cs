using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.Roblox;

internal class OmniSort
{
	[JsonPropertyName("topic")]
	public string? Topic { get; set; }

	[JsonPropertyName("topicId")]
	public long TopicId { get; set; }

	[JsonPropertyName("treatmentType")]
	public string? TreatmentType { get; set; }

	[JsonPropertyName("recommendationList")]
	public List<OmniRecommendation>? RecommendationList { get; set; }
}
