using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.Roblox;

internal class SearchLandingSort
{
	[JsonPropertyName("sortId")]
	public string? SortId { get; set; }

	[JsonPropertyName("games")]
	public List<SearchLandingGame>? Games { get; set; }
}
