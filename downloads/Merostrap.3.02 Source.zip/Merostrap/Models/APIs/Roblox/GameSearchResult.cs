using System.Globalization;
using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.Roblox;

internal class GameSearchResult
{
	[JsonPropertyName("rootPlaceId")]
	public long RootPlaceId { get; set; }

	[JsonPropertyName("name")]
	public string Name { get; set; } = string.Empty;

	[JsonPropertyName("playerCount")]
	public int? PlayerCount { get; set; }

	public override string ToString()
	{
		if (!string.IsNullOrWhiteSpace(Name))
		{
			return $"{Name} ({RootPlaceId})";
		}
		return RootPlaceId.ToString(CultureInfo.InvariantCulture);
	}
}
