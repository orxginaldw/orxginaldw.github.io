using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.Roblox;

internal class ServerInstance
{
	[JsonPropertyName("id")]
	public string Id { get; set; } = string.Empty;

	[JsonPropertyName("playing")]
	public int Playing { get; set; }

	[JsonPropertyName("maxPlayers")]
	public int MaxPlayers { get; set; }

	[JsonPropertyName("region")]
	public string Region { get; set; } = "Unknown";

	[JsonIgnore]
	public string? ProbeAddress { get; set; }

	[JsonPropertyName("dataCenterId")]
	public int? DataCenterId { get; set; }

	[JsonPropertyName("firstSeen")]
	public DateTime? FirstSeen { get; set; }

	[JsonPropertyName("playerTokens")]
	public List<string> PlayerTokens { get; set; } = new List<string>();

	[JsonIgnore]
	public string UptimeDisplay
	{
		get
		{
			if (!FirstSeen.HasValue)
			{
				return "Not Tracked";
			}
			TimeSpan timeSpan = DateTime.UtcNow - FirstSeen.Value;
			if (timeSpan.TotalSeconds < 60.0)
			{
				return "Just started";
			}
			return $"{timeSpan.Days}d {timeSpan.Hours}h {timeSpan.Minutes}m";
		}
	}
}
