using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.Roblox;

internal class OmniRecommendationResponse
{
	[JsonPropertyName("sorts")]
	public List<OmniSort>? Sorts { get; set; }

	[JsonPropertyName("contentMetadata")]
	public OmniContentMetadata? ContentMetadata { get; set; }
}
