using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.Roblox;

internal class SearchLandingResponse
{
	[JsonPropertyName("sorts")]
	public List<SearchLandingSort>? Sorts { get; set; }
}
