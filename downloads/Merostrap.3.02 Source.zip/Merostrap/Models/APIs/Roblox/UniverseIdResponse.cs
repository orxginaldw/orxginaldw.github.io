using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.Roblox;

internal class UniverseIdResponse
{
	[JsonPropertyName("universeId")]
	public long UniverseId { get; set; }
}
