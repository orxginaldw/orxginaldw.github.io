using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.Roblox;

internal class RecentlyVisitedResponse
{
	[JsonPropertyName("sorts")]
	public List<SortGroup> Sorts { get; set; } = new List<SortGroup>();
}
