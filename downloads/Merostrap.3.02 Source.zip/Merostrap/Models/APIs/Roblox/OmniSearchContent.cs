using System.Text.Json.Serialization;
using Avalonia.Media.Imaging;
using Merostrap.UI.ViewModels;

namespace Merostrap.Models.APIs.Roblox;

internal class OmniSearchContent : NotifyPropertyChangedViewModel
{
	private string? _thumbnailUrl;

	private Bitmap? _thumbnailBitmap;

	[JsonPropertyName("universeId")]
	public ulong UniverseId { get; set; }

	[JsonPropertyName("rootPlaceId")]
	public long RootPlaceId { get; set; }

	[JsonPropertyName("name")]
	public string? Name { get; set; }

	[JsonPropertyName("playerCount")]
	public int? PlayerCount { get; set; }

	public string? ThumbnailUrl
	{
		get
		{
			return _thumbnailUrl;
		}
		set
		{
			_thumbnailUrl = value;
		}
	}

	public Bitmap? ThumbnailBitmap
	{
		get
		{
			return _thumbnailBitmap;
		}
		set
		{
			SetProperty(ref _thumbnailBitmap, value, "ThumbnailBitmap");
		}
	}
}
