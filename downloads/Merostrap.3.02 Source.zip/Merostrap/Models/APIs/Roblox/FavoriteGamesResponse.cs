using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.Roblox;

internal class FavoriteGamesResponse
{
	[JsonPropertyName("previousPageCursor")]
	public string? PreviousPageCursor { get; set; }

	[JsonPropertyName("nextPageCursor")]
	public string? NextPageCursor { get; set; }

	[JsonPropertyName("data")]
	public List<FavoriteGameData>? Data { get; set; }
}
