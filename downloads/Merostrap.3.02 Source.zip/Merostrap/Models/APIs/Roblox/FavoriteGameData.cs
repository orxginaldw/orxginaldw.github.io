using System;
using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.Roblox;

internal class FavoriteGameData
{
	[JsonPropertyName("id")]
	public long Id { get; set; }

	[JsonPropertyName("name")]
	public string? Name { get; set; }

	[JsonPropertyName("description")]
	public string? Description { get; set; }

	[JsonPropertyName("creator")]
	public CreatorData? Creator { get; set; }

	[JsonPropertyName("rootPlace")]
	public RootPlaceData? RootPlace { get; set; }

	[JsonPropertyName("created")]
	public DateTime Created { get; set; }

	[JsonPropertyName("updated")]
	public DateTime Updated { get; set; }

	[JsonPropertyName("placeVisits")]
	public long PlaceVisits { get; set; }
}
