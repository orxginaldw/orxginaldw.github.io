using System;
using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.Roblox;

internal class ClientVersion
{
	[JsonPropertyName("version")]
	public string Version { get; set; }

	[JsonPropertyName("clientVersionUpload")]
	public string VersionGuid { get; set; }

	[JsonPropertyName("bootstrapperVersion")]
	public string BootstrapperVersion { get; set; }

	public DateTime? Timestamp { get; set; }

	[JsonIgnore]
	public bool IsInstalledFallback { get; set; }

	public bool IsBehindDefaultChannel { get; set; }
}
