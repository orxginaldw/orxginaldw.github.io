using System.Text.Json.Serialization;

namespace Merostrap.Models.APIs.GitHub;

internal class GithubReleaseAsset
{
	[JsonPropertyName("browser_download_url")]
	public string BrowserDownloadUrl { get; set; }

	[JsonPropertyName("name")]
	public string Name { get; set; }
}
