using System.Collections.Generic;
using System.Text.Json.Serialization;
using FluentAvalonia.UI.Controls;

namespace Merostrap.Models.APIs.Config;

internal class RemoteDataBase
{
	[JsonPropertyName("alertEnabled")]
	public bool AlertEnabled { get; set; }

	[JsonPropertyName("alertContent")]
	public string AlertContent { get; set; }

	[JsonPropertyName("alertSeverity")]
	public FAInfoBarSeverity AlertSeverity { get; set; }

	[JsonPropertyName("bannedVersionHashes")]
	public List<string> BannedVersionHashes { get; set; } = new List<string>();

	[JsonPropertyName("packageMaps")]
	public PackageMaps PackageMaps { get; set; } = new PackageMaps();

	[JsonPropertyName("allowedFastFlags")]
	public string AllowedFastFlags { get; set; }

	[JsonPropertyName("mappings")]
	public Dictionary<string, string[]> Mappings { get; set; } = new Dictionary<string, string[]>();

	[JsonPropertyName("communityMods")]
	public List<CommunityMod> CommunityMods { get; set; } = new List<CommunityMod>();
}
