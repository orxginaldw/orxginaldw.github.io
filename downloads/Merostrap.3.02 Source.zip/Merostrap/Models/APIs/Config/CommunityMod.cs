using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using Avalonia.Media.Imaging;
using Avalonia.Threading;
using Merostrap.Enums;
using Merostrap.UI.ViewModels;

namespace Merostrap.Models.APIs.Config;

internal class CommunityMod : NotifyPropertyChangedViewModel
{
	private bool _isDownloading;

	private double _downloadProgress;

	private object? _downloadCommand;

	private Bitmap? _thumbnail;

	[JsonPropertyName("id")]
	public string Id { get; set; }

	[JsonPropertyName("name")]
	public string Name { get; set; }

	[JsonPropertyName("download")]
	public string DownloadUrl { get; set; }

	[JsonPropertyName("gradient")]
	public List<GradientStop>? GradientStops { get; set; }

	[JsonPropertyName("angle")]
	public double? GradientAngle { get; set; }

	[JsonPropertyName("author")]
	public string Author { get; set; }

	[JsonPropertyName("description")]
	public string Description { get; set; }

	[JsonPropertyName("thumbnail")]
	public string ThumbnailUrl { get; set; }

	[JsonPropertyName("modtype")]
	public ModType ModType { get; set; } = ModType.ColorMod;

	[JsonIgnore]
	public bool IsDownloading
	{
		get
		{
			return _isDownloading;
		}
		set
		{
			SetProperty(ref _isDownloading, value, "IsDownloading");
		}
	}

	[JsonIgnore]
	public double DownloadProgress
	{
		get
		{
			return _downloadProgress;
		}
		set
		{
			SetProperty(ref _downloadProgress, value, "DownloadProgress");
		}
	}

	[JsonIgnore]
	public object? DownloadCommand
	{
		get
		{
			return _downloadCommand;
		}
		set
		{
			SetProperty(ref _downloadCommand, value, "DownloadCommand");
		}
	}

	[JsonIgnore]
	public bool IsCustomTheme => ModType == ModType.CustomTheme;

	[JsonIgnore]
	public bool IsColorMod => ModType == ModType.ColorMod;

	[JsonIgnore]
	public string ModTypeDisplay => ModType switch
	{
		ModType.MiscMod => "Misc Mod", 
		ModType.ColorMod => "Color Mod", 
		ModType.SkyBox => "SkyBox", 
		ModType.Cursor => "Cursor", 
		ModType.AvatarEditor => "Avatar Editor", 
		ModType.CustomTheme => "Custom Theme", 
		_ => "Unknown", 
	};

	[JsonIgnore]
	public Bitmap? Thumbnail
	{
		get
		{
			return _thumbnail;
		}
		set
		{
			SetProperty(ref _thumbnail, value, "Thumbnail");
		}
	}

	private string GetCacheFilePath()
	{
		string text = Path.Combine(Paths.Cache, "CommunityMods");
		Directory.CreateDirectory(text);
		return Path.Combine(text, Id + ".png");
	}

	public async Task LoadThumbnailAsync()
	{
		if (Thumbnail != null || string.IsNullOrEmpty(ThumbnailUrl))
		{
			return;
		}
		string cachePath = GetCacheFilePath();
		if (File.Exists(cachePath))
		{
			try
			{
				Bitmap bitmap = await Task.Run(() =>
				{
					using FileStream stream2 = File.OpenRead(cachePath);
					return Bitmap.DecodeToWidth(stream2, 600);
				});
				await Dispatcher.UIThread.InvokeAsync(() => Thumbnail = bitmap);
				return;
			}
			catch (Exception ex)
			{
				App.Logger.Error("Failed to load cached thumbnail: " + ex.Message);
				try
				{
					File.Delete(cachePath);
				}
				catch
				{
				}
			}
		}
		try
		{
			using HttpResponseMessage response = await App.HttpClient.GetAsync(new Uri(ThumbnailUrl));
			if (!response.IsSuccessStatusCode)
			{
				return;
			}
			Stream stream = await response.Content.ReadAsStreamAsync();
			try
			{
				Bitmap bitmap2 = await Task.Run(() => Bitmap.DecodeToWidth(stream, 600));
				await Task.Run(() =>
				{
					using FileStream stream2 = File.Create(cachePath);
					bitmap2.Save(stream2, PngBitmapEncoderOptions.Default);
				});
				await Dispatcher.UIThread.InvokeAsync(() => Thumbnail = bitmap2);
			}
			finally
			{
				if (stream != null)
				{
					await stream.DisposeAsync();
				}
			}
		}
		catch (Exception ex2)
		{
			App.Logger.Error<string>("Unhandled exception: ", ex2.Message);
		}
	}
}
