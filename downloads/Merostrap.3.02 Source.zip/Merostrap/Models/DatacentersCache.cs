using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Merostrap.Models;

internal class DatacentersCache
{
	[JsonPropertyName("regions")]
	public Dictionary<string, List<int>> Regions { get; set; } = new Dictionary<string, List<int>>();

	[JsonPropertyName("lastUpdated")]
	public DateTime LastUpdated { get; set; }
}
