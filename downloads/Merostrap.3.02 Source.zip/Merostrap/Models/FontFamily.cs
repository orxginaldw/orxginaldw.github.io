using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Merostrap.Models;

internal class FontFamily
{
	[JsonPropertyName("name")]
	public string Name { get; set; }

	[JsonPropertyName("faces")]
	public IEnumerable<FontFace> Faces { get; set; }
}
