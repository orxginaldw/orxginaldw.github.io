namespace Merostrap.Models;

internal class CustomCursorSet
{
	public string Name { get; set; } = "";

	public string FolderPath { get; set; } = "";
}
