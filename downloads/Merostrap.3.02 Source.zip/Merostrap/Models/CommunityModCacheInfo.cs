using System;

namespace Merostrap.Models;

internal class CommunityModCacheInfo
{
	public string Url { get; set; }

	public DateTime LastUpdated { get; set; }
}
