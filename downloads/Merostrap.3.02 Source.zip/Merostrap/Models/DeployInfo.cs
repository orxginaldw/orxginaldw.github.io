namespace Merostrap.Models;

internal class DeployInfo
{
	public string Timestamp { get; set; }

	public string Version { get; set; }

	public string VersionGuid { get; set; }
}
