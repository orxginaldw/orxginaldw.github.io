using System.IO;
using System.Text.Json.Serialization;
using Merostrap.Enums;
using Merostrap.Resources;
using Merostrap.UI.ViewModels;

namespace Merostrap.Models;

internal class ModConfig : NotifyPropertyChangedViewModel
{
	private string _folderName = "";

	private int _priority;

	private ModTarget _target;

	private bool _enabled = true;

	public string FolderName
	{
		get
		{
			return _folderName;
		}
		set
		{
			if (SetProperty(ref _folderName, value, "FolderName"))
			{
				OnPropertyChanged("FileCount");
			}
		}
	}

	public int Priority
	{
		get
		{
			return _priority;
		}
		set
		{
			SetProperty(ref _priority, value, "Priority");
		}
	}

	public ModTarget Target
	{
		get
		{
			return _target;
		}
		set
		{
			SetProperty(ref _target, value, "Target");
		}
	}

	public bool Enabled
	{
		get
		{
			return _enabled;
		}
		set
		{
			SetProperty(ref _enabled, value, "Enabled");
		}
	}

	public int FileCount => GetFileCount();

	[JsonIgnore]
	public string FileCountDisplay => $"{FileCount} {Strings.Common_Files}";

	[JsonIgnore]
	public string PriorityDisplay => $"{Strings.Common_Priority} {Priority}";

	private int GetFileCount()
	{
		if (string.IsNullOrEmpty(FolderName))
		{
			return 0;
		}
		string path = Path.Combine(Paths.Modifications, FolderName);
		if (!Directory.Exists(path))
		{
			return 0;
		}
		try
		{
			return Directory.GetFiles(path, "*", SearchOption.AllDirectories).Length;
		}
		catch
		{
			return 0;
		}
	}
}
