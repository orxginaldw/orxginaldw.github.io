using System;
using System.IO;
using System.Reflection;
using Merostrap.Models.SettingTasks.Base;
using Merostrap.Resources;
using Merostrap.Utility;

namespace Merostrap.Models.SettingTasks;

internal class ExtractIconsTask : BoolBaseTask
{
	private static readonly string[] AllowedIconNames = new string[8] { "Icon2008.ico", "Icon2011.ico", "Icon2017.ico", "Icon2019.ico", "Icon2022.ico", "Icon2025.ico", "IconEarly2015.ico", "IconLate2015.ico" };

	private static string IconPath => Path.Combine(Paths.Base, Strings.Paths_Icons);

	public ExtractIconsTask()
		: base("ExtractIcons")
	{
		OriginalState = Directory.Exists(IconPath);
	}

	public override void Execute()
	{
		if (NewState)
		{
			Directory.CreateDirectory(IconPath);
			Assembly executingAssembly = Assembly.GetExecutingAssembly();
			string[] manifestResourceNames = executingAssembly.GetManifestResourceNames();
			string[] allowedIconNames = AllowedIconNames;
			foreach (string text in allowedIconNames)
			{
				string text2 = "Merostrap.Resources." + text;
				if (!manifestResourceNames.Contains(text2))
				{
					continue;
				}
				using Stream stream = executingAssembly.GetManifestResourceStream(text2);
				using MemoryStream memoryStream = new MemoryStream();
				stream.CopyTo(memoryStream);
				string text3 = Path.Combine(IconPath, text);
				Filesystem.AssertReadOnly(text3);
				File.WriteAllBytes(text3, memoryStream.ToArray());
			}
		}
		else if (Directory.Exists(IconPath))
		{
			Directory.Delete(IconPath, recursive: true);
		}
		OriginalState = NewState;
	}
}
