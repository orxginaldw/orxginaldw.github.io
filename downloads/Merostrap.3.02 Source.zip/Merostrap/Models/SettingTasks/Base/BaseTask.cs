namespace Merostrap.Models.SettingTasks.Base;

internal abstract class BaseTask
{
	public string Name { get; private set; }

	public abstract bool Changed { get; }

	public BaseTask(string prefix, string name)
		: this(prefix + "." + name)
	{
	}

	public BaseTask(string name)
	{
		Name = name;
	}

	public override string ToString()
	{
		return Name;
	}

	public abstract void Execute();
}
