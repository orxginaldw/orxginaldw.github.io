namespace Merostrap.Models.SettingTasks.Base;

internal abstract class StringBaseTask : BaseTask
{
	private string _originalState = "";

	private string _newState = "";

	public virtual string OriginalState
	{
		get
		{
			return _originalState;
		}
		set
		{
			_originalState = value;
			_newState = value;
		}
	}

	public virtual string NewState
	{
		get
		{
			return _newState;
		}
		set
		{
			_newState = value;
			if (Changed)
			{
				App.PendingSettingTasks[Name] = this;
			}
			else
			{
				App.PendingSettingTasks.Remove(Name);
			}
		}
	}

	public override bool Changed => _newState != OriginalState;

	public StringBaseTask(string prefix, string name)
		: base(prefix, name)
	{
	}
}
