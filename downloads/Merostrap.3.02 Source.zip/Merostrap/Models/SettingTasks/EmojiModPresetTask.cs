using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using Merostrap.Enums;
using Merostrap.Enums.Messagebox;
using Merostrap.Extensions;
using Merostrap.Models.SettingTasks.Base;
using Merostrap.Resources;
using Merostrap.UI;
using Merostrap.Utility;

namespace Merostrap.Models.SettingTasks;

internal class EmojiModPresetTask : EnumBaseTask<EmojiType>
{
	private static string FilePath => Path.Combine(Paths.Modifications, "content", "fonts", "TwemojiMozilla.ttf");

	private static IEnumerable<KeyValuePair<EmojiType, string>>? QueryCurrentValue()
	{
		if (!File.Exists(FilePath))
		{
			return null;
		}
		using FileStream stream = File.OpenRead(FilePath);
		string hash = FastHash.FromStream(stream);
		return EmojiTypeEx.Hashes.Where((KeyValuePair<EmojiType, string> x) => x.Value == hash);
	}

	public EmojiModPresetTask()
		: base("ModPreset", "EmojiFont")
	{
		IEnumerable<KeyValuePair<EmojiType, string>> enumerable = QueryCurrentValue();
		if (enumerable != null)
		{
			OriginalState = enumerable.FirstOrDefault().Key;
		}
	}

	public override async void Execute()
	{
		IEnumerable<KeyValuePair<EmojiType, string>> enumerable = QueryCurrentValue();
		if (NewState != EmojiType.Default)
		{
			if ((enumerable?.FirstOrDefault())?.Key == NewState)
			{
				return;
			}
			try
			{
				HttpResponseMessage httpResponseMessage = await App.HttpClient.GetAsync(new Uri(NewState.GetUrl()));
				httpResponseMessage.EnsureSuccessStatusCode();
				Directory.CreateDirectory(Path.GetDirectoryName(FilePath));
				await using FileStream fileStream = new FileStream(FilePath, FileMode.Create);
				await httpResponseMessage.Content.CopyToAsync(fileStream);
				OriginalState = NewState;
			}
			catch (Exception ex)
			{
				App.Logger.Error("Unhandled exception: ", ex);
				await Frontend.ShowConnectivityDialog(string.Format(CultureInfo.CurrentCulture, Strings.Dialog_Connectivity_UnableToConnect, "GitHub"), Strings.Menu_PresetMods_Presets_EmojiType_Error + "\n\n" + Strings.Dialog_Connectivity_TryAgainLater, MessageBoxImage.Warning, ex);
			}
		}
		else if (enumerable != null && enumerable.Any())
		{
			Filesystem.AssertReadOnly(FilePath);
			File.Delete(FilePath);
			OriginalState = NewState;
		}
	}
}
