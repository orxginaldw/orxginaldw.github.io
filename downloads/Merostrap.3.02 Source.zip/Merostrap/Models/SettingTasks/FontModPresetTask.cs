using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.RegularExpressions;
using Merostrap.Models.SettingTasks.Base;
using Merostrap.Utility;

namespace Merostrap.Models.SettingTasks;

internal class FontModPresetTask : StringBaseTask
{
	private const string CustomFontAssetId = "rbxasset://fonts/CustomFont.ttf";

	private static readonly JsonSerializerOptions SerializerOptions = new JsonSerializerOptions
	{
		WriteIndented = true
	};

	private static readonly string[] CustomFontFamilyFiles = new string[42]
	{
		"AccanthisADFStd.json", "AmaticSC.json", "Arimo.json", "Balthazar.json", "Bangers.json", "BuilderExtended.json", "BuilderMono.json", "BuilderSans.json", "ComicNeueAngular.json", "Creepster.json",
		"DenkOne.json", "Fondamento.json", "FredokaOne.json", "GrenzeGotisch.json", "Guru.json", "HighwayGothic.json", "Inconsolata.json", "IndieFlower.json", "JosefinSans.json", "Jura.json",
		"Kalam.json", "LegacyArial.json", "LegacyArimo.json", "LuckiestGuy.json", "Merriweather.json", "Michroma.json", "Montserrat.json", "Nunito.json", "Oswald.json", "PatrickHand.json",
		"PermanentMarker.json", "PressStart2P.json", "Roboto.json", "RobotoCondensed.json", "RobotoMono.json", "RomanAntique.json", "Sarpanch.json", "SourceSansPro.json", "SpecialElite.json", "TitilliumWeb.json",
		"Ubuntu.json", "Zekton.json"
	};

	private static readonly FontFace[] CustomFontFaces = new FontFace[7]
	{
		new FontFace
		{
			Name = "Thin",
			Weight = 100,
			Style = "normal",
			AssetId = "rbxasset://fonts/CustomFont.ttf"
		},
		new FontFace
		{
			Name = "Light",
			Weight = 300,
			Style = "normal",
			AssetId = "rbxasset://fonts/CustomFont.ttf"
		},
		new FontFace
		{
			Name = "Regular",
			Weight = 400,
			Style = "normal",
			AssetId = "rbxasset://fonts/CustomFont.ttf"
		},
		new FontFace
		{
			Name = "Medium",
			Weight = 500,
			Style = "normal",
			AssetId = "rbxasset://fonts/CustomFont.ttf"
		},
		new FontFace
		{
			Name = "Semi Bold",
			Weight = 600,
			Style = "normal",
			AssetId = "rbxasset://fonts/CustomFont.ttf"
		},
		new FontFace
		{
			Name = "Bold",
			Weight = 700,
			Style = "normal",
			AssetId = "rbxasset://fonts/CustomFont.ttf"
		},
		new FontFace
		{
			Name = "Extra Bold",
			Weight = 800,
			Style = "normal",
			AssetId = "rbxasset://fonts/CustomFont.ttf"
		}
	};

	private static string CustomFontFamiliesDirectory => Path.Combine(Paths.Modifications, "content", "fonts", "families");

	public static string? GetFileHash()
	{
		if (!File.Exists(Paths.CustomFont))
		{
			return null;
		}
		using FileStream stream = File.OpenRead(Paths.CustomFont);
		return FastHash.FromStream(stream);
	}

	public FontModPresetTask()
		: base("ModPreset", "TextFont")
	{
		if (File.Exists(Paths.CustomFont))
		{
			OriginalState = Paths.CustomFont;
		}
	}

	public override void Execute()
	{
		if (!string.IsNullOrEmpty(NewState))
		{
			if (!string.Equals(NewState, Paths.CustomFont, StringComparison.OrdinalIgnoreCase) && File.Exists(NewState))
			{
				Directory.CreateDirectory(Path.GetDirectoryName(Paths.CustomFont));
				Filesystem.AssertReadOnly(Paths.CustomFont);
				File.Copy(NewState, Paths.CustomFont, overwrite: true);
			}
			EnsureCustomFontFamilies();
		}
		else if (File.Exists(Paths.CustomFont))
		{
			Filesystem.AssertReadOnly(Paths.CustomFont);
			File.Delete(Paths.CustomFont);
		}
		if (string.IsNullOrEmpty(NewState))
		{
			CleanupCustomFontFamilies();
		}
		OriginalState = NewState;
	}

	private static void EnsureCustomFontFamilies()
	{
		Directory.CreateDirectory(CustomFontFamiliesDirectory);
		string[] customFontFamilyFiles = CustomFontFamilyFiles;
		foreach (string text in customFontFamilyFiles)
		{
			string text2 = Path.Combine(CustomFontFamiliesDirectory, text);
			FontFamily value = new FontFamily
			{
				Name = GetFontFamilyNameFromFilename(text),
				Faces = CustomFontFaces
			};
			Filesystem.AssertReadOnly(text2);
			File.WriteAllText(text2, JsonSerializer.Serialize(value, SerializerOptions));
		}
	}

	private static void CleanupCustomFontFamilies()
	{
		if (!Directory.Exists(CustomFontFamiliesDirectory))
		{
			return;
		}
		string[] files = Directory.GetFiles(CustomFontFamiliesDirectory, "*.json");
		foreach (string text in files)
		{
			if (IsCustomFontFamilyOverride(text))
			{
				Filesystem.AssertReadOnly(text);
				File.Delete(text);
			}
		}
		if (!Directory.EnumerateFileSystemEntries(CustomFontFamiliesDirectory).Any())
		{
			Directory.Delete(CustomFontFamiliesDirectory);
		}
	}

	private static bool IsCustomFontFamilyOverride(string filePath)
	{
		return File.ReadAllText(filePath).Contains("rbxasset://fonts/CustomFont.ttf", StringComparison.OrdinalIgnoreCase);
	}

	private static string GetFontFamilyNameFromFilename(string familyFile)
	{
		return Regex.Replace(Regex.Replace(Path.GetFileNameWithoutExtension(familyFile), "(?<=[A-Z])([A-Z][a-z])", " $1"), "(?<=[a-z0-9])([A-Z])", " $1");
	}
}
