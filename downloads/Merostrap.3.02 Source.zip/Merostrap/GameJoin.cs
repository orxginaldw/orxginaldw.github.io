using System;
using System.Text.RegularExpressions;
using System.Web;
using Merostrap.Enums;
using Merostrap.Models;

namespace Merostrap;

internal class GameJoin
{
	private static long RegexMatchLong(string url, string query, string pattern)
	{
		Match match = Regex.Match(url, query + pattern);
		if (!match.Success)
		{
			return 0L;
		}
		long.TryParse(match.Groups[1].Value, out var result);
		return result;
	}

	private static string RegexMatchString(string url, string query, string pattern)
	{
		Match match = Regex.Match(url, query + pattern);
		if (!match.Success)
		{
			return string.Empty;
		}
		return match.Groups[1].Value;
	}

	public static GameJoinData GetJoinDataByLaunchCommand(string launchCommandLine)
	{
		GameJoinData gameJoinData = new GameJoinData();
		if (!launchCommandLine.StartsWith("roblox-player:", StringComparison.Ordinal) && !launchCommandLine.StartsWith("roblox://", StringComparison.Ordinal))
		{
			return gameJoinData;
		}
		if (launchCommandLine.StartsWith("roblox://", StringComparison.Ordinal))
		{
			App.Logger.Info("Processing roblox:// URI: " + launchCommandLine);
			Match match = Regex.Match(launchCommandLine, "placeId=([0-9]+)");
			if (match.Success)
			{
				long.TryParse(match.Groups[1].Value, out var result);
				if (result > 0)
				{
					gameJoinData.JoinType = GameJoinType.RequestGame;
					gameJoinData.PlaceId = result;
					gameJoinData.PlaceLauncherUrl = launchCommandLine;
					App.Logger.Info($"Extracted place ID from roblox:// URI: {result}");
				}
			}
			Match match2 = Regex.Match(launchCommandLine, "gameInstanceId=([a-zA-Z0-9-]+)");
			if (match2.Success)
			{
				gameJoinData.JobId = match2.Groups[1].Value;
				App.Logger.Info("Extracted job ID from roblox:// URI: " + gameJoinData.JobId);
			}
			Match match3 = Regex.Match(launchCommandLine, "accessCode=([a-zA-Z0-9-]+)");
			if (match3.Success)
			{
				gameJoinData.AccessCode = match3.Groups[1].Value;
				App.Logger.Info("Extracted access code from roblox:// URI: " + gameJoinData.AccessCode);
			}
			Match match4 = Regex.Match(launchCommandLine, "joinAttemptOrigin=([a-zA-Z0-9-]+)");
			if (match4.Success)
			{
				gameJoinData.JoinOrigin = match4.Groups[1].Value;
				App.Logger.Info("Extracted join origin from roblox:// URI: " + gameJoinData.JoinOrigin);
			}
			return gameJoinData;
		}
		Match match5 = Regex.Match(launchCommandLine, "placelauncherurl:(.+?)(\\+|$)");
		if (!match5.Success || match5.Groups.Count != 3)
		{
			return gameJoinData;
		}
		string str = (gameJoinData.PlaceLauncherUrl = match5.Groups[1].Value);
		string text = HttpUtility.UrlDecode(str);
		if (string.IsNullOrEmpty(text))
		{
			return gameJoinData;
		}
		Match match6 = Regex.Match(text, "request=(.+?)&");
		if (!match6.Success || match6.Groups.Count != 2)
		{
			return gameJoinData;
		}
		App.Logger.Debug("Detecting join type");
		switch (match6.Groups[1].Value)
		{
		case "RequestGame":
		{
			gameJoinData.JoinType = GameJoinType.RequestGame;
			string joinOrigin = RegexMatchString(text, "joinAttemptOrigin=", "([a-zA-Z0-9-]+?)(&|\\+|$)");
			long num2 = RegexMatchLong(text, "placeId=", "([0-9]+)");
			if (num2 == 0L)
			{
				return gameJoinData;
			}
			gameJoinData.PlaceId = num2;
			gameJoinData.JoinOrigin = joinOrigin;
			break;
		}
		case "RequestGameJob":
		{
			gameJoinData.JoinType = GameJoinType.RequestGameJob;
			string joinOrigin2 = RegexMatchString(text, "joinAttemptOrigin=", "([a-zA-Z0-9-]+?)(&|\\+|$)");
			string text4 = RegexMatchString(text, "gameId=", "([a-zA-Z0-9-]+?)(&|\\+|$)");
			long num4 = RegexMatchLong(text, "placeId=", "([0-9]+)");
			if (string.IsNullOrEmpty(text4) || num4 == 0L)
			{
				return gameJoinData;
			}
			gameJoinData.PlaceId = num4;
			gameJoinData.JobId = text4;
			gameJoinData.JoinOrigin = joinOrigin2;
			break;
		}
		case "RequestPrivateGame":
		{
			gameJoinData.JoinType = GameJoinType.RequestPrivateGame;
			string text3 = RegexMatchString(text, "accessCode=", "([a-zA-Z0-9-]+?)(&|\\+|$)");
			long num3 = RegexMatchLong(text, "placeId=", "([0-9]+)");
			if (string.IsNullOrEmpty(text3) || num3 == 0L)
			{
				return gameJoinData;
			}
			gameJoinData.PlaceId = num3;
			gameJoinData.AccessCode = text3;
			break;
		}
		case "RequestFollowUser":
		{
			gameJoinData.JoinType = GameJoinType.RequestFollowUser;
			long num5 = RegexMatchLong(text, "userId=", "([0-9]+)");
			if (num5 == 0L)
			{
				return gameJoinData;
			}
			gameJoinData.UserId = num5;
			break;
		}
		case "RequestPlayTogetherGame":
		{
			gameJoinData.JoinType = GameJoinType.RequestPlayTogetherGame;
			long num = RegexMatchLong(text, "placeId=", "([0-9]+)");
			string text2 = RegexMatchString(text, "conversationId=", "([a-zA-Z0-9-]+?)(&|\\+|$)");
			if (string.IsNullOrEmpty(text2) || num == 0L)
			{
				return gameJoinData;
			}
			gameJoinData.PlaceId = num;
			gameJoinData.JobId = text2;
			break;
		}
		}
		App.Logger.Info($"Join type: {gameJoinData.JoinType}");
		return gameJoinData;
	}
}
