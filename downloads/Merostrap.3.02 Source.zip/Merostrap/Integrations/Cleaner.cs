using System;
using System.Collections.Generic;
using System.IO;
using Merostrap.Enums;
using Merostrap.Performance;

namespace Merostrap.Integrations;

internal class Cleaner
{
	public static readonly IReadOnlyDictionary<string, string?> Directories = new Dictionary<string, string>
	{
		{
			"MerostrapLogs",
			Paths.Logs
		},
		{
			"MerostrapCache",
			Paths.Downloads
		},
		{
			"RobloxLogs",
			Paths.RobloxLogs
		},
		{
			"RobloxCache",
			Paths.RobloxCache
		}
	};

	public static void DoCleaning()
	{
		int? ageDays = App.Settings.Prop.CleanerOptions switch
		{
			CleanerOptions.OneDay => (int?)1, 
			CleanerOptions.OneWeek => 7, 
			CleanerOptions.OneMonth => 30, 
			CleanerOptions.TwoMonths => 60, 
			_ => null, 
		};
		if (!ageDays.HasValue)
		{
			return;
		}
		foreach (KeyValuePair<string, string> directory in Directories)
		{
			if (App.Settings.Prop.CleanerDirectories.Contains(directory.Key) && !string.IsNullOrEmpty(directory.Value))
			{
				try
				{
					CacheCleanupResult cacheCleanupResult = CacheCleanup.Clean(directory.Value, ageDays, DateTime.UtcNow);
					App.Logger.Info($"Cleaner {directory.Key}: scanned {cacheCleanupResult.Scanned}, deleted {cacheCleanupResult.Deleted}, skipped {cacheCleanupResult.Skipped}");
				}
				catch (Exception ex) when ((ex is IOException || ex is UnauthorizedAccessException || ex is ArgumentException) ? true : false)
				{
					App.Logger.Error("Cleaner skipped " + directory.Key + ": " + ex.GetType().Name);
				}
			}
		}
	}
}
