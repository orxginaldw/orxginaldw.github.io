using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Merostrap.Models;
using Merostrap.Models.APIs.Roblox;
using Merostrap.Utility;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Merostrap.Integrations.AccountManager;

internal static class RobloxApiService
{
	public static async Task<AccountManagerAccount?> GetAccountInfoFromCookieAsync(string securityCookie)
	{
		_ = 1;
		try
		{
			using HttpClientHandler handler = new HttpClientHandler
			{
				CookieContainer = new CookieContainer(),
				CheckCertificateRevocationList = true
			};
			handler.CookieContainer.Add(new Cookie(".ROBLOSECURITY", securityCookie, "/", ".roblox.com"));
			using HttpClient client = new HttpClient(handler);
			HttpResponseMessage httpResponseMessage = await client.GetAsync(UrlBuilder.BuildApiUrl("users", "v1/users/authenticated"));
			httpResponseMessage.EnsureSuccessStatusCode();
			JObject jObject = JsonConvert.DeserializeObject<JObject>(await httpResponseMessage.Content.ReadAsStringAsync());
			if (jObject == null)
			{
				return null;
			}
			return new AccountManagerAccount(securityCookie, jObject["id"]?.Value<long>() ?? 0, jObject["name"]?.Value<string>() ?? "", jObject["displayName"]?.Value<string>() ?? "");
		}
		catch (Exception value)
		{
			App.Logger.Error(value);
			return null;
		}
	}

	public static async Task<UserPresence?> GetUserPresenceAsync(long userId)
	{
		try
		{
			string content = System.Text.Json.JsonSerializer.Serialize(new
			{
				userIds = new long[1] { userId }
			});
			using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, UrlBuilder.BuildApiUrl("presence", "v1/presence/users"))
			{
				Content = new StringContent(content, Encoding.UTF8, "application/json")
			};
			return (await Http.SendJson<UserPresenceResponse>(request).ConfigureAwait(continueOnCapturedContext: false))?.UserPresences?.FirstOrDefault((UserPresence x) => x.UserId == userId);
		}
		catch (Exception value)
		{
			App.Logger.Error(value);
			return null;
		}
	}

	public static async Task<bool?> ValidateAccountAsync(AccountManagerAccount account)
	{
		try
		{
			string securityToken = account.SecurityToken;
			if (string.IsNullOrEmpty(securityToken))
			{
				return false;
			}
			using HttpClientHandler handler = new HttpClientHandler
			{
				CookieContainer = new CookieContainer(),
				CheckCertificateRevocationList = true
			};
			handler.CookieContainer.Add(new Cookie(".ROBLOSECURITY", securityToken, "/", ".roblox.com"));
			using HttpClient client = new HttpClient(handler);
			HttpResponseMessage httpResponseMessage = await client.GetAsync(UrlBuilder.BuildApiUrl("users", "v1/users/authenticated"));
			if (httpResponseMessage.StatusCode == HttpStatusCode.OK)
			{
				return true;
			}
			if (httpResponseMessage.StatusCode == HttpStatusCode.Unauthorized || httpResponseMessage.StatusCode == HttpStatusCode.Forbidden)
			{
				return false;
			}
			return null;
		}
		catch (Exception value)
		{
			App.Logger.Error(value);
			return null;
		}
	}
}
