using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Merostrap.Models.APIs.Roblox;
using Merostrap.Utility;

namespace Merostrap.Integrations.AccountManager;

internal class AvatarService
{
	private readonly Dictionary<long, string?> _avatarUrlCache = new Dictionary<long, string>();

	public async Task<Dictionary<long, string?>> GetAvatarUrlsBulkAsync(List<long> userIds)
	{
		Dictionary<long, string?> result = new Dictionary<long, string>();
		if (userIds == null || userIds.Count == 0)
		{
			return result;
		}
		for (int i = 0; i < userIds.Count; i += 100)
		{
			List<long> values = userIds.Skip(i).Take(100).ToList();
			string text = string.Join(',', values);
			UriBuilder uriBuilder = new UriBuilder(UrlBuilder.BuildApiUrl("thumbnails", "v1/users/avatar-headshot"))
			{
				Query = "userIds=" + text + "&size=75x75&format=Png&isCircular=true"
			};
			try
			{
				ApiArrayResponse<ThumbnailResponse> apiArrayResponse = await Http.GetJson<ApiArrayResponse<ThumbnailResponse>>(uriBuilder.Uri);
				if (apiArrayResponse?.Data == null)
				{
					continue;
				}
				foreach (ThumbnailResponse datum in apiArrayResponse.Data)
				{
					if (datum.TargetId > 0 && !string.IsNullOrEmpty(datum.ImageUrl))
					{
						result[datum.TargetId] = datum.ImageUrl;
						_avatarUrlCache[datum.TargetId] = datum.ImageUrl;
					}
				}
			}
			catch (Exception ex)
			{
				App.Logger.Error("Batch failed: " + ex.Message);
			}
		}
		return result;
	}

	public string? GetCachedAvatarUrl(long userId)
	{
		if (!_avatarUrlCache.TryGetValue(userId, out string value))
		{
			return null;
		}
		return value;
	}
}
