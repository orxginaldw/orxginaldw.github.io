using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Merostrap.Models;
using Merostrap.Models.APIs.Roblox;
using Merostrap.UI.Elements.Dialogs;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Merostrap.Integrations.AccountManager;

internal class AccountManager
{
	private const string AccountsFile = "AccountManager.json";

	private readonly string _accountsLocation;

	private List<AccountManagerAccount> _accounts = new List<AccountManagerAccount>();

	private readonly LoginService _loginService = new LoginService();

	private readonly AvatarService _avatarService = new AvatarService();

	public AccountManagerAccount? ActiveAccount { get; private set; }

	public long CurrentPlaceId { get; set; }

	public string CurrentServerInstanceId { get; set; } = "";

	public static AccountManager Shared { get; } = new AccountManager();

	public IReadOnlyList<AccountManagerAccount> Accounts => _accounts;

	public event Action<AccountManagerAccount?>? ActiveAccountChanged;

	public AccountManager()
	{
		_accountsLocation = Path.Combine(Paths.Cache, "AccountManager.json");
		LoadAccounts();
	}

	public void LoadAccounts()
	{
		if (!File.Exists(_accountsLocation))
		{
			return;
		}
		try
		{
			string json = File.ReadAllText(_accountsLocation);
			json = MigrateCredentials(json);
			AccountManagerData data = JsonConvert.DeserializeObject<AccountManagerData>(json);
			if (data?.Accounts == null)
			{
				return;
			}
			_accounts = data.Accounts.Select((AccountManagerAccount account) => account with
			{
				SecurityToken = (AccountSecurity.GetCredential(account.UserId.ToString(CultureInfo.InvariantCulture)) ?? string.Empty)
			}).ToList();
			if (data.ActiveAccountId.HasValue)
			{
				ActiveAccount = _accounts.Find((AccountManagerAccount account) => account.UserId == data.ActiveAccountId);
			}
		}
		catch (Exception argument)
		{
			App.Logger.Error("Unhandled exception: ", argument);
		}
	}

	private string MigrateCredentials(string json)
	{
		try
		{
			JObject jObject = JObject.Parse(json);
			if (!(jObject["Accounts"] is JArray source))
			{
				return json;
			}
			bool flag = false;
			foreach (JObject item in source.OfType<JObject>())
			{
				JToken jToken = item["UserId"];
				string text = item["SecurityToken"]?.Value<string>();
				if (jToken != null && !string.IsNullOrEmpty(text))
				{
					flag = true;
					long value = jToken.Value<long>();
					if (!AccountSecurity.TryUnprotect(text, out string unprotected))
					{
						throw new InvalidOperationException($"Failed to decrypt credential for account {value}.");
					}
					if (!AccountSecurity.SetCredential(value.ToString(CultureInfo.InvariantCulture), unprotected))
					{
						throw new InvalidOperationException($"Failed to store credential for account {value}.");
					}
					item.Remove("SecurityToken");
				}
			}
			if (!flag)
			{
				return json;
			}
			string text2 = jObject.ToString(Formatting.Indented);
			File.WriteAllText(_accountsLocation, text2);
			App.Logger.Info("Successfully migrated account credentials to the OS credential store.");
			return text2;
		}
		catch (Exception value2)
		{
			App.Logger.Error($"Failed to migrate account credentials: {value2}");
			return json;
		}
	}

	public void SaveAccounts()
	{
		try
		{
			foreach (AccountManagerAccount account in _accounts)
			{
				if (!string.IsNullOrEmpty(account.SecurityToken) && !AccountSecurity.SetCredential(account.UserId.ToString(CultureInfo.InvariantCulture), account.SecurityToken))
				{
					App.Logger.Warn($"Failed to save credential for account {account.UserId}.");
				}
			}
			AccountManagerData value = new AccountManagerData
			{
				Accounts = _accounts.ToList(),
				ActiveAccountId = ActiveAccount?.UserId,
				LastUpdated = DateTime.UtcNow
			};
			File.WriteAllText(_accountsLocation, JsonConvert.SerializeObject(value, Formatting.Indented));
		}
		catch (Exception argument)
		{
			App.Logger.Error("Unhandled exception: ", argument);
		}
	}

	public void SetActiveAccount(long? userId)
	{
		AccountManagerAccount accountManagerAccount = _accounts.Find((AccountManagerAccount a) => a.UserId == userId);
		if (accountManagerAccount != null)
		{
			ActiveAccount = accountManagerAccount;
			ActiveAccountChanged?.Invoke(accountManagerAccount);
			SaveAccounts();
		}
	}

	public void AddAccount(AccountManagerAccount account)
	{
		if (!_accounts.Any((AccountManagerAccount a) => a.UserId == account.UserId))
		{
			_accounts.Add(account);
			SaveAccounts();
		}
	}

	public bool RemoveAccount(AccountManagerAccount account)
	{
		try
		{
			bool flag = ActiveAccount?.UserId == account.UserId;
			if (_accounts.RemoveAll((AccountManagerAccount a) => a.UserId == account.UserId) > 0)
			{
				AccountSecurity.DeleteCredential(account.UserId.ToString(CultureInfo.InvariantCulture));
				if (flag)
				{
					ActiveAccount = _accounts.FirstOrDefault();
					ActiveAccountChanged?.Invoke(ActiveAccount);
				}
				SaveAccounts();
				App.Logger.Info($"Removed account {account.Username} ({account.UserId}).");
				return true;
			}
			return false;
		}
		catch (Exception value)
		{
			App.Logger.Error(value);
			return false;
		}
	}

	public string? GetRoblosecurityForUser(long userId)
	{
		return AccountSecurity.GetCredential(userId.ToString(CultureInfo.InvariantCulture));
	}

	public static Task<AccountManagerAccount?> AddAccountByQuickSignInAsync(QuickSignCodeDialog dialog, CancellationToken token)
	{
		return LoginService.AddAccountByQuickSignInAsync(dialog, token);
	}

	public async Task<AccountManagerAccount?> AddAccountByBrowserAsync()
	{
		return await _loginService.AddAccountByBrowserAsync(async (string cookie) =>
		{
			AccountManagerAccount accountInfo = await RobloxApiService.GetAccountInfoFromCookieAsync(cookie);
			if (accountInfo == null)
			{
				return (AccountManagerAccount?)null;
			}
			AccountManagerAccount accountManagerAccount = _accounts.FirstOrDefault((AccountManagerAccount acc) => acc.UserId == accountInfo.UserId);
			if (accountManagerAccount == null)
			{
				AddAccount(accountInfo);
				return accountInfo;
			}
			return accountManagerAccount;
		});
	}

	public static Task<UserPresence?> GetUserPresenceAsync(long userId)
	{
		return RobloxApiService.GetUserPresenceAsync(userId);
	}

	public static Task<bool?> ValidateAccountAsync(AccountManagerAccount account)
	{
		return RobloxApiService.ValidateAccountAsync(account);
	}

	public static bool WriteCookieFileForAccount(AccountManagerAccount account)
	{
		return AccountCookieWriter.WriteCookieFileForAccount(account);
	}

	public Task<Dictionary<long, string?>> GetAvatarUrlsBulkAsync(List<long> userIds)
	{
		return _avatarService.GetAvatarUrlsBulkAsync(userIds);
	}

	public string? GetCachedAvatarUrl(long userId)
	{
		return _avatarService.GetCachedAvatarUrl(userId);
	}
}
