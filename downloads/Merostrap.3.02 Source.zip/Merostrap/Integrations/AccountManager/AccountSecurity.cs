using System;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using ktsu.CredentialCache;
using ktsu.Semantics.Strings;

namespace Merostrap.Integrations.AccountManager;

internal static class AccountSecurity
{
	private const string ServiceName = "Merostrap";

	public static string? GetCredential(string accountId)
	{
		if (string.IsNullOrWhiteSpace(accountId))
		{
			return null;
		}
		try
		{
			PersonaGUID persona = CreatePersona(accountId);
			if (CredentialCache.Instance.TryGet(persona, out Credential credential) && credential is CredentialWithToken credentialWithToken)
			{
				return credentialWithToken.Token.ToString(CultureInfo.InvariantCulture);
			}
		}
		catch
		{
		}
		return null;
	}

	public static bool SetCredential(string accountId, string credential)
	{
		if (string.IsNullOrWhiteSpace(accountId) || string.IsNullOrEmpty(credential))
		{
			return false;
		}
		try
		{
			PersonaGUID persona = CreatePersona(accountId);
			CredentialCache.Instance.AddOrReplace(persona, new CredentialWithToken
			{
				Token = SemanticString<CredentialToken>.Create(credential)
			});
			return true;
		}
		catch (Exception value)
		{
			App.Logger.Error($"Failed to store credential for account {accountId}: {value}");
			return false;
		}
	}

	public static bool DeleteCredential(string accountId)
	{
		if (string.IsNullOrWhiteSpace(accountId))
		{
			return false;
		}
		try
		{
			PersonaGUID persona = CreatePersona(accountId);
			return CredentialCache.Instance.Remove(persona);
		}
		catch
		{
			return false;
		}
	}

	private static PersonaGUID CreatePersona(string accountId)
	{
		return SemanticString<PersonaGUID>.Create("Merostrap:" + accountId);
	}

	public static string Protect(string text)
	{
		if (string.IsNullOrEmpty(text))
		{
			return string.Empty;
		}
		if (!RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
		{
			return text;
		}
		try
		{
			return Convert.ToBase64String(ProtectedData.Protect(Encoding.UTF8.GetBytes(text), null, DataProtectionScope.CurrentUser));
		}
		catch
		{
			return text;
		}
	}

	public static bool TryUnprotect(string text, out string unprotected)
	{
		unprotected = string.Empty;
		if (string.IsNullOrEmpty(text))
		{
			return false;
		}
		if (!RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
		{
			unprotected = text;
			return true;
		}
		try
		{
			byte[] bytes = ProtectedData.Unprotect(Convert.FromBase64String(text), null, DataProtectionScope.CurrentUser);
			unprotected = Encoding.UTF8.GetString(bytes);
			return !string.IsNullOrEmpty(unprotected);
		}
		catch
		{
			return false;
		}
	}
}
