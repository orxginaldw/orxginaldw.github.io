using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Merostrap.Models;

namespace Merostrap.Integrations.AccountManager;

internal static class AccountCookieWriter
{
	private struct BinaryCookie(string name, string value, bool isSecure = false)
	{
		public string Name { get; set; } = name;

		public string Value { get; set; } = value;

		public string Domain { get; set; } = ".roblox.com";

		public string Path { get; set; } = "/";

		public int Flags { get; set; } = isSecure ? 1 : 0;

		public double? Expiry { get; set; } = null;

		public double? Creation { get; set; } = null;
	}

	private static readonly JsonSerializerOptions _jsonOptions = new JsonSerializerOptions
	{
		WriteIndented = true
	};

	public static bool WriteCookieFileForAccount(AccountManagerAccount account)
	{
		string securityToken = account.SecurityToken;
		if (string.IsNullOrEmpty(securityToken))
		{
			App.Logger.Info("Account has no valid cookie.");
			return false;
		}
		string cookiesPath = CookiesManager.CookiesPath;
		try
		{
			if (OperatingSystem.IsWindows())
			{
				return WriteWindowsCookieFile(securityToken, cookiesPath);
			}
			if (OperatingSystem.IsMacOS())
			{
				return WriteMacCookieFile(securityToken, cookiesPath);
			}
			if (OperatingSystem.IsLinux())
			{
				return WriteLinuxCookieFile(securityToken, cookiesPath);
			}
			App.Logger.Info("Unsupported OS.");
			return false;
		}
		catch (Exception value)
		{
			App.Logger.Error(value);
			return false;
		}
	}

	private static bool WriteWindowsCookieFile(string plainCookie, string filePath)
	{
		string value = GenerateGuestData();
		string value2 = GenerateTrackerData();
		string s = $"#HttpOnly_.roblox.com\tTRUE\t/\tFALSE\t0\tGuestData\t{value}\n#HttpOnly_.roblox.com\tTRUE\t/\tFALSE\t0\tRBXEventTrackerV2\t{value2}\n#HttpOnly_.roblox.com\tTRUE\t/\tTRUE\t1817995500\t.ROBLOSECURITY\t{plainCookie}";
		byte[] inArray = ProtectedData.Protect(Encoding.UTF8.GetBytes(s), null, DataProtectionScope.CurrentUser);
		string contents = JsonSerializer.Serialize(new RobloxCookies
		{
			Version = "1",
			Cookies = Convert.ToBase64String(inArray)
		}, _jsonOptions);
		BackupFile(filePath);
		File.WriteAllText(filePath, contents);
		return true;
	}

	private static bool WriteMacCookieFile(string plainCookie, string filePath)
	{
		BinaryCookie[] collection = new BinaryCookie[4]
		{
			new BinaryCookie("rbx-ip2", "rbx-ip2"),
			new BinaryCookie("RBXPaymentsFlowContext", "98619ec1-af61-4739-a12b-c8fc4abbab79,"),
			new BinaryCookie("rbxas", "40ac424f7d0844b99d92179bdb9e22341d7e2c49cc7ae6c5101cca1c9a67b365"),
			new BinaryCookie("ARID", "fc r502pFLAl14bk47SYcQoDVdTFrOeqwK6AxopmW+t1Ke66bZfJX7J3KniMv+tn8NuVRLyJkFkO5z3XXzJm1ANOvLfHLkBv9q1aIoq/MT4rKYzZ6KXnZb+xnOMsu43OExsFnQhxZy2LCOzbYJMnuidqjZSIH6qQSU=**uKVnWDwQcFDl0aet")
		};
		BinaryCookie item = new BinaryCookie("GuestData", GenerateGuestData());
		BinaryCookie item2 = new BinaryCookie("RBXEventTrackerV2", GenerateTrackerData());
		BinaryCookie item3 = new BinaryCookie(".ROBLOSECURITY", plainCookie, isSecure: true)
		{
			Expiry = MacTimeFromDateTime(DateTime.UtcNow.AddDays(365.0))
		};
		List<BinaryCookie> list = new List<BinaryCookie>(collection) { item, item2, item3 };
		for (int i = 0; i < list.Count; i++)
		{
			BinaryCookie value = list[i];
			value.Domain = ".roblox.com";
			value.Path = "/";
			if (!value.Expiry.HasValue)
			{
				value.Expiry = 0.0;
			}
			if (!value.Creation.HasValue)
			{
				value.Creation = MacTimeFromDateTime(DateTime.UtcNow);
			}
			list[i] = value;
		}
		byte[] bytes = SerializeBinaryCookies(list);
		BackupFile(filePath);
		File.WriteAllBytes(filePath, bytes);
		return true;
	}

	private static bool WriteLinuxCookieFile(string plainCookie, string filePath)
	{
		string contents = ".ROBLOSECURITY=" + plainCookie + ";";
		BackupFile(filePath);
		File.WriteAllText(filePath, contents);
		return true;
	}

	private static byte[] SerializeBinaryCookies(List<BinaryCookie> cookies)
	{
		List<byte[]> list = cookies.Select(BuildCookieRecord).ToList();
		int count = list.Count;
		int num = 8 + count * 4;
		int host = num + list.Sum((byte[] b) => b.Length);
		using MemoryStream memoryStream = new MemoryStream();
		using BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write(256);
		binaryWriter.Write(count);
		int num2 = num;
		foreach (byte[] item in list)
		{
			binaryWriter.Write(num2);
			num2 += item.Length;
		}
		foreach (byte[] item2 in list)
		{
			binaryWriter.Write(item2);
		}
		byte[] buffer = memoryStream.ToArray();
		using MemoryStream memoryStream2 = new MemoryStream();
		using BinaryWriter binaryWriter2 = new BinaryWriter(memoryStream2);
		binaryWriter2.Write("cook"u8);
		binaryWriter2.Write(IPAddress.HostToNetworkOrder(1));
		binaryWriter2.Write(IPAddress.HostToNetworkOrder(host));
		binaryWriter2.Write(buffer);
		return memoryStream2.ToArray();
	}

	private static byte[] BuildCookieRecord(BinaryCookie cookie)
	{
		byte[] bytes = Encoding.UTF8.GetBytes(cookie.Domain + "\0");
		byte[] bytes2 = Encoding.UTF8.GetBytes(cookie.Name + "\0");
		byte[] bytes3 = Encoding.UTF8.GetBytes(cookie.Path + "\0");
		byte[] bytes4 = Encoding.UTF8.GetBytes(cookie.Value + "\0");
		int num = 52;
		byte[] array = new byte[num + bytes.Length + bytes2.Length + bytes3.Length + bytes4.Length];
		using MemoryStream output = new MemoryStream(array);
		using BinaryWriter binaryWriter = new BinaryWriter(output);
		binaryWriter.Write(0);
		binaryWriter.Write(cookie.Flags);
		binaryWriter.Write(new byte[12]);
		int num2 = num;
		int num3 = num2 + bytes.Length;
		int num4 = num3 + bytes2.Length;
		int value = num4 + bytes3.Length;
		binaryWriter.Write(num2);
		binaryWriter.Write(num3);
		binaryWriter.Write(num4);
		binaryWriter.Write(value);
		binaryWriter.Write(cookie.Expiry.GetValueOrDefault());
		binaryWriter.Write(cookie.Creation.GetValueOrDefault());
		binaryWriter.Write(bytes);
		binaryWriter.Write(bytes2);
		binaryWriter.Write(bytes3);
		binaryWriter.Write(bytes4);
		return array;
	}

	private static double MacTimeFromDateTime(DateTime dt)
	{
		return (dt.ToUniversalTime() - new DateTime(2001, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalSeconds;
	}

	private static string GenerateGuestData()
	{
		using RandomNumberGenerator randomNumberGenerator = RandomNumberGenerator.Create();
		byte[] array = new byte[4];
		randomNumberGenerator.GetBytes(array);
		int value = -((BitConverter.ToInt32(array, 0) & 0x7FFFFFFF) % 999999999) - 1;
		return $"UserID={value};";
	}

	private static string GenerateTrackerData()
	{
		string value = DateTime.UtcNow.ToString("MM/dd/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
		long value2 = GenerateRandomBrowserId();
		return $"CreateDate={value}&rbxid=&rbxuid=&browserid={value2};";
	}

	private static long GenerateRandomBrowserId()
	{
		using RandomNumberGenerator randomNumberGenerator = RandomNumberGenerator.Create();
		byte[] array = new byte[8];
		randomNumberGenerator.GetBytes(array);
		long num = BitConverter.ToInt64(array, 0) & 0x7FFFFFFFFFFFFFFFL;
		return (num < 1000000000000000L) ? (num + 1000000000000000L) : num;
	}

	private static void BackupFile(string filePath)
	{
		if (File.Exists(filePath))
		{
			try
			{
				File.Copy(filePath, filePath + ".bak", overwrite: true);
			}
			catch
			{
			}
		}
	}
}
