using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Avalonia.Threading;
using FluentAvalonia.UI.Controls;
using Merostrap.Models;
using Merostrap.UI.Elements.Dialogs;
using Merostrap.UI.Elements.Settings;
using Merostrap.Utility;
using Microsoft.Win32;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PuppeteerSharp;
using PuppeteerSharp.BrowserData;

namespace Merostrap.Integrations.AccountManager;

internal class LoginService
{
	private Browser? _browser;

	private static readonly string[] CompatibleBrowsers = new string[15]
	{
		"chrome", "google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "brave", "brave-browser", "edge", "msedge", "microsoft-edge",
		"vivaldi", "opera", "opera-stable", "helium", "thorium"
	};

	public static async Task<AccountManagerAccount?> AddAccountByQuickSignInAsync(QuickSignCodeDialog dialog, CancellationToken cancellationToken)
	{
		try
		{
			using HttpClient client = new HttpClient();
			Uri requestUri = UrlBuilder.BuildApiUrl("apis", "auth-token-service/v1/login/create");
			using StringContent createContent = new StringContent("{}", Encoding.UTF8, "application/json");
			using HttpResponseMessage createResponse = await client.PostAsync(requestUri, createContent, cancellationToken);
			createResponse.EnsureSuccessStatusCode();
			JObject jObject = JObject.Parse(await createResponse.Content.ReadAsStringAsync(cancellationToken));
			string code = jObject["code"].Value<string>();
			string privateKey = jObject["privateKey"].Value<string>();
			DateTime expirationTime = jObject["expirationTime"].Value<DateTime>();
			await Dispatcher.UIThread.InvokeAsync(() =>
			{
				dialog.StartNewSignIn(code);
			});
			Uri statusUrl = UrlBuilder.BuildApiUrl("apis", "auth-token-service/v1/login/status");
			string text = null;
			while (!cancellationToken.IsCancellationRequested)
			{
				await Task.Delay(4000, cancellationToken);
				var value = new { code, privateKey };
				using StringContent statusContent = new StringContent(JsonConvert.SerializeObject(value), Encoding.UTF8, "application/json");
				using HttpResponseMessage statusResponse = await client.PostAsync(statusUrl, statusContent, cancellationToken);
				if ((statusResponse.StatusCode == HttpStatusCode.Forbidden || statusResponse.StatusCode == HttpStatusCode.BadRequest) && statusResponse.Headers.TryGetValues("x-csrf-token", out IEnumerable<string> values))
				{
					string value2 = values.First();
					using HttpRequestMessage retryRequest = new HttpRequestMessage(HttpMethod.Post, statusUrl)
					{
						Content = statusContent
					};
					retryRequest.Headers.Add("x-csrf-token", value2);
					using HttpResponseMessage retryResponse = await client.SendAsync(retryRequest, cancellationToken);
					text = await ProcessStatusBody(retryResponse, dialog);
				}
				else
				{
					text = await ProcessStatusBody(statusResponse, dialog);
				}
				if (text == "Validated" || text == "Cancelled")
				{
					break;
				}
				if (DateTime.UtcNow > expirationTime)
				{
					await Dispatcher.UIThread.InvokeAsync(() =>
					{
						dialog.UpdateStatus("TimedOut");
					});
					return null;
				}
				continue;
			}
			if (cancellationToken.IsCancellationRequested || text == "Cancelled")
			{
				return null;
			}
			return await PerformFinalLoginAsync(code, privateKey, dialog, cancellationToken);
		}
		catch (OperationCanceledException)
		{
			return null;
		}
		catch (Exception ex2)
		{
			Exception ex3 = ex2;
			App.Logger.Error(ex3);
			await Dispatcher.UIThread.InvokeAsync(() =>
			{
				dialog.UpdateStatus("Error: " + ex3.Message);
			});
			return null;
		}
	}

	private static async Task<string?> ProcessStatusBody(HttpResponseMessage response, QuickSignCodeDialog dialog)
	{
		string json = await response.Content.ReadAsStringAsync();
		if (response.StatusCode == HttpStatusCode.BadRequest)
		{
			await Dispatcher.UIThread.InvokeAsync(() =>
			{
				dialog.UpdateStatus("Cancelled");
			});
			return "Cancelled";
		}
		JObject jObject = JObject.Parse(json);
		string status = (string?)jObject["status"];
		string accountName = (string?)jObject["accountName"];
		await Dispatcher.UIThread.InvokeAsync(() =>
		{
			dialog.UpdateStatus(status ?? "Error", accountName);
		});
		return status;
	}

	private static async Task<AccountManagerAccount?> PerformFinalLoginAsync(string code, string privateKey, QuickSignCodeDialog dialog, CancellationToken token)
	{
		Uri loginUrl = UrlBuilder.BuildApiUrl("auth", "v2/login");
		var loginData = new
		{
			ctype = "AuthToken",
			cvalue = code,
			password = privateKey
		};
		using StringContent loginContent = new StringContent(JsonConvert.SerializeObject(loginData), Encoding.UTF8, "application/json");
		using HttpClientHandler handler = new HttpClientHandler
		{
			CookieContainer = new CookieContainer(),
			UseCookies = true,
			CheckCertificateRevocationList = true
		};
		using HttpClient client = new HttpClient(handler);
		HttpResponseMessage loginResponse = null;
		try
		{
			loginResponse = await client.PostAsync(loginUrl, loginContent, token);
			if ((loginResponse.StatusCode == HttpStatusCode.Forbidden || loginResponse.StatusCode == HttpStatusCode.BadRequest) && loginResponse.Headers.TryGetValues("x-csrf-token", out IEnumerable<string> values))
			{
				string value = values.First();
				using StringContent retryContent = new StringContent(JsonConvert.SerializeObject(loginData), Encoding.UTF8, "application/json");
				using HttpRequestMessage retryRequest = new HttpRequestMessage(HttpMethod.Post, loginUrl)
				{
					Content = retryContent
				};
				retryRequest.Headers.Add("x-csrf-token", value);
				loginResponse.Dispose();
				loginResponse = await client.SendAsync(retryRequest, token);
			}
			loginResponse.EnsureSuccessStatusCode();
			string text = handler.CookieContainer.GetCookies(new Uri("https://roblox.com"))[".ROBLOSECURITY"]?.Value;
			if (string.IsNullOrEmpty(text))
			{
				return null;
			}
			AccountManagerAccount account = await RobloxApiService.GetAccountInfoFromCookieAsync(text);
			if (account != null)
			{
				await Dispatcher.UIThread.InvokeAsync(() =>
				{
					dialog.CompleteSignIn();
				});
			}
			return account;
		}
		finally
		{
			loginResponse?.Dispose();
		}
	}

	public async Task<AccountManagerAccount?> AddAccountByBrowserAsync(Func<string, Task<AccountManagerAccount?>> accountResolver)
	{
		TaskCompletionSource<string?> completionSource = new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);
		AccountManagerAccount result;
		try
		{
			_ = 10;
			try
			{
				App.Logger.Info("Launching browser for account login...");
				string text = GetSystemBrowserPath();
				if (text != null)
				{
					MainWindow.ShowGlobalNotification("Compatible browser found!", "Launching browser for login.", FAInfoBarSeverity.Success);
				}
				if (text == null)
				{
					BrowserFetcher browserFetcher = new BrowserFetcher();
					InstalledBrowser installedBrowser = browserFetcher.GetInstalledBrowsers().FirstOrDefault((InstalledBrowser b) => b.Browser == SupportedBrowser.Chromium);
					if (installedBrowser != null)
					{
						text = installedBrowser.GetExecutablePath();
					}
					if (text == null)
					{
						App.Logger.Info("No browser found, downloading Chromium...");
						MainWindow.ShowGlobalNotification("No compatible browser found", "Please wait while we download Chromium for login.", FAInfoBarSeverity.Warning);
						text = (await browserFetcher.DownloadAsync()).GetExecutablePath();
					}
				}
				LaunchOptions launchOptions = new LaunchOptions();
				launchOptions.Headless = false;
				launchOptions.DefaultViewport = null;
				launchOptions.ExecutablePath = text;
				launchOptions.Args = new string[4] { "--disable-notifications", "--no-sandbox", "--disable-setuid-sandbox", "--disable-blink-features=AutomationControlled" };
				launchOptions.IgnoredDefaultArgs = new string[1] { "--enable-automation" };
				_browser = (Browser)(await Puppeteer.LaunchAsync(launchOptions));
				if (_browser == null)
				{
					result = null;
				}
				else
				{
					IPage mainPage = await _browser.NewPageAsync();
					await mainPage.SetUserAgentAsync("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36");
					IPage[] array = await _browser.PagesAsync();
					foreach (IPage page in array)
					{
						if (page != mainPage)
						{
							await page.CloseAsync();
						}
					}
					_browser.Disconnected += (object? s, EventArgs e) =>
					{
						completionSource.TrySetResult(null);
					};
					mainPage.Close += (object? s, EventArgs e) =>
					{
						completionSource.TrySetResult(null);
					};
					mainPage.Response += (object? _, ResponseCreatedEventArgs e) =>
					{
						ObserveRedirectBody(e.Response);
					};
					Task.Run(async () =>
					{
						_ = 1;
						try
						{
							while (!completionSource.Task.IsCompleted && mainPage != null && !mainPage.IsClosed)
							{
								CookieParam cookieParam = (await mainPage.GetCookiesAsync("https://www.roblox.com/")).FirstOrDefault((CookieParam c) => c.Name == ".ROBLOSECURITY");
								if (cookieParam != null)
								{
									App.Logger.Info("Successfully captured cookie.");
									completionSource.TrySetResult(cookieParam.Value);
									break;
								}
								await Task.Delay(1000);
							}
						}
						catch
						{
						}
					});
					try
					{
						await mainPage.GoToAsync("https://www.roblox.com/login", new NavigationOptions
						{
							WaitUntil = new WaitUntilNavigation[1] { WaitUntilNavigation.Networkidle2 }
						});
					}
					catch (Exception ex)
					{
						App.Logger.Error("Initial nav failed (" + ex.Message + "), trying JS fallback...");
						try
						{
							if (!mainPage.IsClosed)
							{
								await mainPage.EvaluateExpressionAsync("window.location.href = 'https://www.roblox.com/login'");
							}
						}
						catch
						{
						}
					}
					string text2 = ((await Task.WhenAny(completionSource.Task, Task.Delay(TimeSpan.FromMinutes(10L))) != completionSource.Task) ? null : (await completionSource.Task));
					string text3 = text2;
					result = ((!string.IsNullOrEmpty(text3)) ? (await accountResolver(text3)) : null);
				}
			}
			catch (Exception value)
			{
				App.Logger.Error(value);
				result = null;
			}
		}
		finally
		{
			if (_browser != null && !_browser.IsClosed)
			{
				await _browser.CloseAsync();
				_browser = null;
			}
		}
		return result;
	}

	private static void ObserveRedirectBody(IResponse response)
	{
		int status = (int)response.Status;
		if ((status < 300 || status >= 400) ? true : false)
		{
			return;
		}
		Task.Run(async () =>
		{
			try
			{
				await response.BufferAsync();
			}
			catch
			{
			}
		});
	}

	private static bool IsCompatibleBrowser(string? executablePath)
	{
		if (string.IsNullOrWhiteSpace(executablePath) || !File.Exists(executablePath))
		{
			return false;
		}
		string executableName = Path.GetFileNameWithoutExtension(executablePath);
		return CompatibleBrowsers.Any((string browser) => executableName.Equals(browser, StringComparison.OrdinalIgnoreCase));
	}

	private static string? GetSystemBrowserPath()
	{
		string text = null;
		if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
		{
			text = GetWindowsBrowserPath();
		}
		else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
		{
			text = GetLinuxBrowserPath();
		}
		else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
		{
			text = GetMacOsBrowserPath();
		}
		if (!IsCompatibleBrowser(text))
		{
			return null;
		}
		return text;
	}

	private static string? GetWindowsBrowserPath()
	{
		try
		{
			using RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\Shell\\Associations\\UrlAssociations\\http\\UserChoice");
			string text = registryKey?.GetValue("ProgId")?.ToString();
			if (string.IsNullOrWhiteSpace(text))
			{
				return null;
			}
			using RegistryKey registryKey2 = Registry.ClassesRoot.OpenSubKey(text + "\\shell\\open\\command");
			return GetExecutableFromCommand(registryKey2?.GetValue(null)?.ToString());
		}
		catch
		{
			return null;
		}
	}

	private static string? GetLinuxBrowserPath()
	{
		try
		{
			using Process process = Process.Start(new ProcessStartInfo
			{
				FileName = "xdg-mime",
				Arguments = "query default x-scheme-handler/http",
				RedirectStandardOutput = true,
				UseShellExecute = false,
				CreateNoWindow = true
			});
			if (process == null)
			{
				return null;
			}
			string text = process.StandardOutput.ReadToEnd().Trim();
			process.WaitForExit();
			if (string.IsNullOrWhiteSpace(text))
			{
				return null;
			}
			string text2 = Environment.GetEnvironmentVariable("XDG_DATA_HOME") ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), ".local", "share");
			string[] array = (Environment.GetEnvironmentVariable("XDG_DATA_DIRS") ?? "/usr/local/share:/usr/share").Split(':', StringSplitOptions.RemoveEmptyEntries);
			int num = 0;
			string[] array2 = new string[1 + array.Length];
			array2[num] = text2;
			num++;
			ReadOnlySpan<string> readOnlySpan = new ReadOnlySpan<string>(array);
			readOnlySpan.CopyTo(new Span<string>(array2).Slice(num, readOnlySpan.Length));
			num += readOnlySpan.Length;
			array2 = array2;
			for (num = 0; num < array2.Length; num++)
			{
				string path = Path.Combine(array2[num], "applications", text);
				if (File.Exists(path))
				{
					string executableFromCommand = GetExecutableFromCommand((from line in File.ReadLines(path)
						select line.Trim()).FirstOrDefault((string line) => line.StartsWith("Exec=", StringComparison.OrdinalIgnoreCase))?.Substring("Exec=".Length));
					if (executableFromCommand != null)
					{
						return executableFromCommand;
					}
				}
			}
		}
		catch
		{
		}
		return null;
	}

	private static string? GetMacOsBrowserPath()
	{
		try
		{
			using Process process = Process.Start(new ProcessStartInfo
			{
				FileName = "defaults",
				Arguments = "read com.apple.LaunchServices/com.apple.launchservices.secure LSHandlers",
				RedirectStandardOutput = true,
				UseShellExecute = false,
				CreateNoWindow = true
			});
			if (process == null)
			{
				return null;
			}
			string text = process.StandardOutput.ReadToEnd();
			process.WaitForExit();
			string text2 = null;
			bool flag = false;
			string[] array = text.Split('\n');
			for (int i = 0; i < array.Length; i++)
			{
				string text3 = array[i].Trim();
				if (text3.Contains("\"LSHandlerURLScheme\" = http", StringComparison.Ordinal))
				{
					flag = true;
				}
				else if (flag && text3.StartsWith("LSHandlerRoleAll = ", StringComparison.Ordinal))
				{
					text2 = text3.Replace("LSHandlerRoleAll = ", "", StringComparison.Ordinal).Trim().TrimEnd(';')
						.Trim('"');
					break;
				}
			}
			if (string.IsNullOrWhiteSpace(text2))
			{
				return null;
			}
			using Process process2 = Process.Start(new ProcessStartInfo
			{
				FileName = "mdfind",
				Arguments = "kMDItemCFBundleIdentifier == '" + text2 + "'",
				RedirectStandardOutput = true,
				UseShellExecute = false,
				CreateNoWindow = true
			});
			if (process2 == null)
			{
				return null;
			}
			string text4 = process2.StandardOutput.ReadToEnd().Split('\n', StringSplitOptions.RemoveEmptyEntries).FirstOrDefault() ?? "";
			process2.WaitForExit();
			if (string.IsNullOrWhiteSpace(text4))
			{
				return null;
			}
			string plistValue = GetPlistValue(Path.Combine(text4, "Contents", "Info.plist"), "CFBundleExecutable");
			if (string.IsNullOrWhiteSpace(plistValue))
			{
				return null;
			}
			string text5 = Path.Combine(text4, "Contents", "MacOS", plistValue);
			return File.Exists(text5) ? text5 : null;
		}
		catch
		{
			return null;
		}
	}

	private static string? GetExecutableFromCommand(string? command)
	{
		if (string.IsNullOrWhiteSpace(command))
		{
			return null;
		}
		command = command.Trim();
		string text;
		if (command.StartsWith('"'))
		{
			int num = command.IndexOf('"', 1);
			if (num <= 1)
			{
				return null;
			}
			text = command.Substring(1, num - 1);
		}
		else
		{
			text = command.Split(' ', StringSplitOptions.RemoveEmptyEntries).FirstOrDefault() ?? "";
		}
		if (string.IsNullOrWhiteSpace(text))
		{
			return null;
		}
		if (text.Equals("flatpak", StringComparison.OrdinalIgnoreCase) || text.Equals("snap", StringComparison.OrdinalIgnoreCase))
		{
			return null;
		}
		if (Path.IsPathFullyQualified(text))
		{
			if (!File.Exists(text))
			{
				return null;
			}
			return text;
		}
		string environmentVariable = Environment.GetEnvironmentVariable("PATH");
		if (string.IsNullOrWhiteSpace(environmentVariable))
		{
			return null;
		}
		string[] array = environmentVariable.Split(Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries);
		for (int i = 0; i < array.Length; i++)
		{
			string text2 = Path.Combine(array[i], text);
			if (File.Exists(text2))
			{
				return text2;
			}
		}
		return null;
	}

	private static string? GetPlistValue(string plistPath, string key)
	{
		if (!File.Exists(plistPath))
		{
			return null;
		}
		using Process process = Process.Start(new ProcessStartInfo
		{
			FileName = "defaults",
			Arguments = "read \"" + plistPath + "\" " + key,
			RedirectStandardOutput = true,
			UseShellExecute = false,
			CreateNoWindow = true
		});
		if (process == null)
		{
			return null;
		}
		string text = process.StandardOutput.ReadToEnd().Trim();
		process.WaitForExit();
		return string.IsNullOrWhiteSpace(text) ? null : text;
	}
}
