using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Merostrap.Enums;
using Merostrap.Models;
using Merostrap.Models.BloxstrapRPC;
using Merostrap.Models.Entities;
using Merostrap.Models.MerostrapStudioRPC;

namespace Merostrap.Integrations;

internal class ActivityWatcher : IDisposable
{
	private const string GameMessageEntry = "[FLog::CreatorOutput] [BloxstrapRPC]";

	private const string GameJoiningEntry = "[FLog::Output] ! Joining game";

	private const string GameTeleportingEntry = "[FLog::UgcExperienceController] UgcExperienceController: doTeleport: joinScriptUrl";

	private const string GameLaunchEventEntry = "[FLog::NewWebView2Browser] Webview handles hybrid javascript event";

	private const string GameJoiningUniverseEntry = "[FLog::GameJoinLoadTime] Report game_join_loadtime:";

	private const string GameJoiningUDMUXEntry = "[FLog::Network] UDMUX Address = ";

	private const string GameJoinedEntry = "[FLog::Network] serverId:";

	private const string GameDisconnectedEntry = "[FLog::Network] Time to disconnect replication data:";

	private const string GameLeavingEntry = "[FLog::SingleSurfaceApp] leaveUGCGameInternal";

	private const string GameLeavingEntrySober = "app_interface$json: {\"type\":\"game_left\"}";

	private const string AppCloseEntrySober = "app: lifecycle: will_do_clean_exit";

	private const string GameDisconnectReasonEntry = "[FLog::Network] Sending disconnect with reason:";

	private const string GameServerUptimeEntry = "[FLog::Output] Server Prefix: ";

	private const string StudioPlaceOpenEntry = "[FLog::PlaceManager] Start to open place";

	private const string StudioPlaceCloseEntry = "[FLog::PlaceManager] PlaceManager::closeCurrentPlayDoc";

	private const string GameJoiningEntryPattern = "! Joining game '([0-9a-f\\-]{36})' place ([0-9]+) at ([0-9\\.]+)";

	private const string GameJoiningUniversePattern = "universeid:([0-9]+)";

	private const string GameJoiningUniverseUserIDPattern = "userid:([0-9]+)";

	private const string GameJoinReferralPattern = "referral_page:([^,]+)";

	private const string GameTeleportJoinTypePattern = "JoinTypeId\"%3a(\\d+)%2c";

	private const string GameJoiningUDMUXPattern = "UDMUX Address\\s*=\\s*([0-9\\.]+),\\s*Port\\s*=\\s*[0-9]+\\s*\\|\\s*RCC Server Address\\s*=\\s*([0-9\\.]+),\\s*Port\\s*=\\s*[0-9]+";

	private const string GameJoinedEntryPattern = "serverId: ([0-9\\.]+)\\|[0-9]+";

	private const string GameMessageEntryPattern = "\\[BloxstrapRPC\\] (.*)";

	private const string GameDisconnectReasonPattern = "Sending disconnect with reason: (\\d+)";

	private const string GameServerUptimePattern = "Server Prefix:.+_(\\d{8}T\\d{6}Z)_RCC_[0-9a-z]+";

	private int _logEntriesRead;

	private bool _teleportMarker;

	private bool _reservedTeleportMarker;

	private bool _shouldAutoRejoin;

	private static readonly string GameHistoryCachePath = Path.Combine(Paths.Cache, "GameHistory.json");

	private static readonly JsonSerializerOptions _loadOptions = new JsonSerializerOptions
	{
		PropertyNameCaseInsensitive = true
	};

	private static readonly JsonSerializerOptions _saveOptions = new JsonSerializerOptions
	{
		WriteIndented = true,
		PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
		DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
	};

	private DateTime LastRPCRequest;

	private readonly LaunchMode _launchMode;

	private readonly int _robloxPID;

	public string LogLocation;

	public bool InGame;

	public bool InStudioPlace;

	public bool InRobloxStudio;

	private const int HttpPort = 4875;

	private HttpListener? _httpListener;

	private readonly CancellationTokenSource _httpCancellationTokenSource = new CancellationTokenSource();

	public List<ActivityData> History = new List<ActivityData>();

	public bool IsDisposed;

	public ActivityData Data { get; private set; } = new ActivityData();

	public event EventHandler? OnHistoryUpdated;

	public event EventHandler<string>? OnLogEntry;

	public event EventHandler? ShowNotif;

	public event EventHandler? OnGameJoin;

	public event EventHandler? OnGameLeave;

	public event EventHandler? OnStudioPlaceOpened;

	public event EventHandler? OnStudioPlaceClosed;

	public event EventHandler? OnLogOpen;

	public event EventHandler? OnAppClose;

	public event EventHandler<Message>? OnRPCMessage;

	public event EventHandler<StudioMessage>? OnStudioRPCMessage;

	public static void CloseProcess(int pid)
	{
		try
		{
			using Process process = Process.GetProcessById(pid);
			if (process.HasExited)
			{
				App.Logger.Info($"PID {pid} has already exited");
			}
			else
			{
				process.Kill();
			}
		}
		catch (Exception value)
		{
			App.Logger.Error($"PID {pid} could not be closed {value}");
		}
	}

	public ActivityWatcher(string? logFile = null, LaunchMode launchMode = LaunchMode.Player, int RobloxPID = 0)
	{
		if (!string.IsNullOrEmpty(logFile))
		{
			LogLocation = logFile;
		}
		_launchMode = launchMode;
		_robloxPID = RobloxPID;
		if (_launchMode == LaunchMode.Studio || _launchMode == LaunchMode.StudioAuth)
		{
			InRobloxStudio = true;
			StartHTTPServer();
		}
		LoadGameHistory();
	}

	public async void Start()
	{
		FileInfo fileInfo;
		if (string.IsNullOrEmpty(LogLocation))
		{
			string logDirectory = Paths.RobloxLogs;
			if (!Directory.Exists(logDirectory))
			{
				return;
			}
			App.Logger.Info("Opening Roblox log file...");
			string logNameFilter = ((InRobloxStudio || _launchMode == LaunchMode.Studio || _launchMode == LaunchMode.StudioAuth) ? "Studio" : "Player");
			while (true)
			{
				List<FileInfo> list = (from x in new DirectoryInfo(logDirectory).GetFiles()
					where x.Name.Contains(logNameFilter, StringComparison.OrdinalIgnoreCase) && x.CreationTime <= DateTime.Now
					orderby x.CreationTime descending
					select x).ToList();
				if (list.Count == 0)
				{
					App.Logger.Info("No '" + logNameFilter + "' log files found, waiting...");
					await Task.Delay(1000);
					continue;
				}
				fileInfo = list.First();
				if (fileInfo.CreationTime.AddSeconds(15.0) > DateTime.Now)
				{
					break;
				}
				App.Logger.Info("Could not find recent enough log file, waiting... (newest is " + fileInfo.Name + ")");
				await Task.Delay(1000);
			}
			LogLocation = fileInfo.FullName;
		}
		else
		{
			fileInfo = new FileInfo(LogLocation);
		}
		OnLogOpen?.Invoke(this, EventArgs.Empty);
		FileStream stream = fileInfo.Open(FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
		App.Logger.Info("Opened " + LogLocation);
		using StreamReader streamReader = new StreamReader(stream);
		while (!IsDisposed)
		{
			string text = await streamReader.ReadLineAsync();
			if (text == null)
			{
				await Task.Delay(1000);
			}
			else
			{
				ReadLogEntry(text);
			}
		}
	}

	private void ReadLogEntry(string entry)
	{
		OnLogEntry?.Invoke(this, entry);
		_logEntriesRead++;
		if (_logEntriesRead <= 1000 && _logEntriesRead % 50 == 0)
		{
			App.Logger.Info($"Read {_logEntriesRead} log entries");
		}
		else if (_logEntriesRead % 100 == 0)
		{
			App.Logger.Info($"Read {_logEntriesRead} log entries");
		}
		string text = ExtractLogMessage(entry);
		if (!string.IsNullOrEmpty(text))
		{
			if (InRobloxStudio || _launchMode == LaunchMode.Studio || _launchMode == LaunchMode.StudioAuth)
			{
				ProcessStudioLogEntry(text);
			}
			else
			{
				ProcessPlayerLogEntry(text);
			}
		}
	}

	private static string? ExtractLogMessage(string entry)
	{
		int num = entry.IndexOf("[FLog::", StringComparison.Ordinal);
		int num2 = entry.IndexOf("[DFLog::", StringComparison.Ordinal);
		int num3 = -1;
		if (num >= 0 && num2 >= 0)
		{
			num3 = Math.Min(num, num2);
		}
		else if (num >= 0)
		{
			num3 = num;
		}
		else if (num2 >= 0)
		{
			num3 = num2;
		}
		if (num3 >= 0)
		{
			return entry.Substring(num3);
		}
		int num4 = entry.IndexOf(' ', StringComparison.Ordinal);
		if (num4 == -1)
		{
			return null;
		}
		return entry.Substring(num4 + 1);
	}

	private void ProcessStudioLogEntry(string logMessage)
	{
		if (!InRobloxStudio)
		{
			InRobloxStudio = true;
		}
		if (!InStudioPlace)
		{
			if (logMessage.StartsWith("[FLog::PlaceManager] Start to open place", StringComparison.Ordinal))
			{
				App.Logger.Info("Studio place opened");
				InStudioPlace = true;
				OnStudioPlaceOpened?.Invoke(this, EventArgs.Empty);
			}
		}
		else if (InStudioPlace && logMessage.StartsWith("[FLog::PlaceManager] PlaceManager::closeCurrentPlayDoc", StringComparison.Ordinal))
		{
			App.Logger.Info("Studio place closed");
			InStudioPlace = false;
			OnStudioPlaceClosed?.Invoke(this, EventArgs.Empty);
		}
	}

	private async void ProcessPlayerLogEntry(string logMessage)
	{
		if (logMessage.StartsWith("[FLog::SingleSurfaceApp] leaveUGCGameInternal", StringComparison.Ordinal) || logMessage.StartsWith("app_interface$json: {\"type\":\"game_left\"}", StringComparison.Ordinal) || logMessage.StartsWith("app: lifecycle: will_do_clean_exit", StringComparison.Ordinal))
		{
			App.Logger.Debug("User is back into the desktop app");
			OnAppClose?.Invoke(this, EventArgs.Empty);
			if (Data.PlaceId != 0L && !InGame)
			{
				App.Logger.Debug("User appears to be leaving from a cancelled/errored join");
				Data = new ActivityData();
			}
			return;
		}
		if (logMessage.StartsWith("[FLog::Network] Sending disconnect with reason:", StringComparison.Ordinal))
		{
			Match match = Regex.Match(logMessage, "Sending disconnect with reason: (\\d+)");
			if (match.Success && match.Groups.Count == 2)
			{
				int num = int.Parse(match.Groups[1].Value, CultureInfo.InvariantCulture);
				if (num == 1 || num == 277)
				{
					_shouldAutoRejoin = true;
					App.Logger.Info($"Inactivity/Internet disconnect detected (reason: {num})");
				}
				else
				{
					App.Logger.Info($"Disconnect reason code: {num}");
				}
			}
		}
		if (!InGame && Data.PlaceId == 0L)
		{
			if (logMessage.StartsWith("[FLog::Output] ! Joining game", StringComparison.Ordinal))
			{
				Match match2 = Regex.Match(logMessage, "! Joining game '([0-9a-f\\-]{36})' place ([0-9]+) at ([0-9\\.]+)");
				if (match2.Groups.Count != 4)
				{
					App.Logger.Error("Failed to assert format for game join entry " + logMessage);
					return;
				}
				InGame = false;
				Data.PlaceId = long.Parse(match2.Groups[2].Value, CultureInfo.InvariantCulture);
				Data.JobId = match2.Groups[1].Value;
				Data.MachineAddress = match2.Groups[3].Value;
				if (_teleportMarker)
				{
					Data.IsTeleport = true;
					_teleportMarker = false;
				}
				if (_reservedTeleportMarker)
				{
					Data.ServerType = ServerType.Reserved;
					_reservedTeleportMarker = false;
				}
				App.Logger.Info($"Joining Game ({Data})");
			}
			else
			{
				if (!logMessage.StartsWith("[FLog::NewWebView2Browser] Webview handles hybrid javascript event", StringComparison.Ordinal))
				{
					return;
				}
				int startIndex = logMessage.IndexOf('{', StringComparison.Ordinal);
				using JsonDocument jsonDocument = JsonDocument.Parse(logMessage.Substring(startIndex));
				if (jsonDocument.RootElement.TryGetProperty("params", out var value) && value.TryGetProperty("request", out var value2) && value2.TryGetProperty("requestType", out var value3) && value3.GetString() == "RequestPrivateGame" && value2.TryGetProperty("accessCode", out var value4))
				{
					string text = value4.GetString();
					if (!string.IsNullOrEmpty(text))
					{
						Data.AccessCode = text;
						Data.ServerType = ServerType.Private;
						App.Logger.Info("Captured private server access code: " + text);
					}
				}
			}
		}
		else if (!InGame && Data.PlaceId != 0L)
		{
			if (logMessage.Contains("[FLog::GameJoinLoadTime] Report game_join_loadtime:", StringComparison.Ordinal))
			{
				Match match3 = Regex.Match(logMessage, "universeid:([0-9]+)", RegexOptions.IgnoreCase);
				if (match3.Success)
				{
					Data.UniverseId = long.Parse(match3.Groups[1].Value, CultureInfo.InvariantCulture);
				}
				Match match4 = Regex.Match(logMessage, "userid:([0-9]+)", RegexOptions.IgnoreCase);
				if (match4.Success)
				{
					Data.UserId = long.Parse(match4.Groups[1].Value, CultureInfo.InvariantCulture);
				}
				if (Data.UniverseId == 0L)
				{
					App.Logger.Error("Failed to extract UniverseId from game join entry. " + logMessage);
					return;
				}
				Match match5 = Regex.Match(logMessage, "referral_page:([^,]+)", RegexOptions.IgnoreCase);
				if (match5.Groups.Count == 2)
				{
					string value5 = match5.Groups[1].Value;
					if (value5.Contains("RequestPrivateGame", StringComparison.OrdinalIgnoreCase) || value5.Contains("GameDetailPageJSHybridEvent", StringComparison.OrdinalIgnoreCase))
					{
						Data.ServerType = ServerType.Private;
					}
				}
				if (History.Count > 0)
				{
					ActivityData activityData = History.First();
					if (Data.UniverseId == activityData.UniverseId && Data.IsTeleport)
					{
						Data.RootActivity = activityData.RootActivity ?? activityData;
					}
				}
			}
			else if (logMessage.StartsWith("[FLog::Network] UDMUX Address = ", StringComparison.Ordinal))
			{
				Match match6 = Regex.Match(logMessage, "UDMUX Address\\s*=\\s*([0-9\\.]+),\\s*Port\\s*=\\s*[0-9]+\\s*\\|\\s*RCC Server Address\\s*=\\s*([0-9\\.]+),\\s*Port\\s*=\\s*[0-9]+");
				if (!match6.Success || match6.Groups.Count != 3)
				{
					App.Logger.Error("Failed to parse UDMUX entry (regex mismatch). " + logMessage);
					return;
				}
				string value6 = match6.Groups[2].Value;
				if (string.IsNullOrEmpty(Data.MachineAddress) || Data.MachineAddress != value6)
				{
					App.Logger.Info("Updating MachineAddress from " + Data.MachineAddress + " to " + value6);
					Data.MachineAddress = value6;
				}
				App.Logger.Info($"Server is UDMUX protected ({Data})");
			}
			else
			{
				if (!logMessage.StartsWith("[FLog::Network] serverId:", StringComparison.Ordinal) || logMessage.Contains("UNASSIGNED_SYSTEM_ADDRESS", StringComparison.Ordinal))
				{
					return;
				}
				Match match7 = Regex.Match(logMessage, "serverId: ([0-9\\.]+)\\|[0-9]+");
				if (match7.Success && match7.Groups.Count == 2)
				{
					string value7 = match7.Groups[1].Value;
					if (!string.IsNullOrEmpty(value7) && value7 != Data.MachineAddress)
					{
						App.Logger.Info("Updating MachineAddress from " + Data.MachineAddress + " to " + value7);
						Data.MachineAddress = value7;
					}
					App.Logger.Info($"Joined Game ({Data})");
					InGame = true;
					Data.TimeJoined = DateTime.Now;
					OnGameJoin?.Invoke(this, EventArgs.Empty);
				}
				else
				{
					App.Logger.Error("Failed to assert format for game joined entry " + logMessage);
				}
			}
		}
		else
		{
			if (!InGame || Data.PlaceId == 0L)
			{
				return;
			}
			if (logMessage.StartsWith("[FLog::Network] Time to disconnect replication data:", StringComparison.Ordinal))
			{
				App.Logger.Info($"Disconnected from Game ({Data})");
				InGame = false;
				Data.TimeLeft = DateTime.Now;
				AddToHistory(Data);
				OnGameLeave?.Invoke(this, EventArgs.Empty);
				ActivityData autoRejoinData = Data;
				Data = new ActivityData();
				if (App.Settings.Prop.AutoRejoin && _shouldAutoRejoin)
				{
					await Task.Delay(3000);
					autoRejoinData.RejoinServer(CloseRoblox: false);
					CloseProcess(_robloxPID);
				}
				_shouldAutoRejoin = false;
			}
			else if (logMessage.StartsWith("[FLog::UgcExperienceController] UgcExperienceController: doTeleport: joinScriptUrl", StringComparison.Ordinal))
			{
				App.Logger.Info($"Initiating teleport to server ({Data})");
				_teleportMarker = true;
				Match match8 = Regex.Match(logMessage, "JoinTypeId\"%3a(\\d+)%2c");
				if (match8.Success && int.TryParse(match8.Groups[1].Value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var result))
				{
					ServerSessionJoinType serverSessionJoinType = (ServerSessionJoinType)result;
					App.Logger.Info($"Teleport JoinTypeId: {result}");
					if ((serverSessionJoinType == ServerSessionJoinType.NewGamePrivateGame || serverSessionJoinType == ServerSessionJoinType.SpecificPrivateGame) ? true : false)
					{
						_reservedTeleportMarker = true;
						App.Logger.Info("Detected reserved server teleport");
					}
				}
				else
				{
					App.Logger.Error("Failed to detect teleport type");
				}
			}
			else if (logMessage.StartsWith("[FLog::CreatorOutput] [BloxstrapRPC]", StringComparison.Ordinal))
			{
				Match match9 = Regex.Match(logMessage, "\\[BloxstrapRPC\\] (.*)");
				if (match9.Groups.Count != 2)
				{
					App.Logger.Error("Failed to assert format for RPC message entry. " + logMessage);
					return;
				}
				string value8 = match9.Groups[1].Value;
				App.Logger.Info("Received message: '" + value8 + "'");
				if ((DateTime.Now - LastRPCRequest).TotalSeconds <= 1.0)
				{
					App.Logger.Info("Dropping message as ratelimit has been hit");
					return;
				}
				Message message;
				try
				{
					message = JsonSerializer.Deserialize<Message>(value8);
				}
				catch (Exception ex)
				{
					App.Logger.Error("Failed to parse message! (JSON deserialization threw an exception) " + ex.Message);
					return;
				}
				if (message == null)
				{
					App.Logger.Error("Failed to parse message! (JSON deserialization returned null)");
					return;
				}
				if (string.IsNullOrEmpty(message.Command))
				{
					App.Logger.Error("Failed to parse message! (Command is empty)");
					return;
				}
				if (message.Command == "SetLaunchData")
				{
					string text2;
					try
					{
						text2 = message.Data.Deserialize<string>();
					}
					catch (Exception ex2)
					{
						App.Logger.Error("Failed to parse message! (JSON deserialization threw an exception) " + ex2.Message);
						return;
					}
					if (text2 == null)
					{
						App.Logger.Error("Failed to parse message! (JSON deserialization returned null)");
						return;
					}
					if (text2.Length > 200)
					{
						App.Logger.Error("Data cannot be longer than 200 characters");
						return;
					}
					Data.RPCLaunchData = text2;
				}
				OnRPCMessage?.Invoke(this, message);
				LastRPCRequest = DateTime.Now;
			}
			else
			{
				if (!logMessage.StartsWith("[FLog::Output] Server Prefix: ", StringComparison.Ordinal))
				{
					return;
				}
				Match match10 = Regex.Match(logMessage, "Server Prefix:.+_(\\d{8}T\\d{6}Z)_RCC_[0-9a-z]+");
				if (!match10.Success && match10.Groups.Count == 2)
				{
					App.Logger.Error("Failed to assert format for server uptime entry. " + logMessage);
					return;
				}
				string value9 = match10.Groups[1].Value;
				App.Logger.Info("Server started at " + value9);
				Data.StartTime = DateTime.ParseExact(value9, "yyyyMMdd'T'HHmmss'Z'", CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal);
				if (!App.Settings.Prop.Performance.NetworkMode && App.Settings.Prop.ShowServerDetails && Data.MachineAddressValid)
				{
					Data.QueryServerLocation();
				}
				ShowNotif?.Invoke(this, null);
			}
		}
	}

	private void StartHTTPServer()
	{
		try
		{
			_httpListener = new HttpListener();
			_httpListener.Prefixes.Add($"http://localhost:{4875}/");
			_httpListener.Start();
			ListenForHTTPRequests(_httpCancellationTokenSource.Token);
			App.Logger.Info($"Studio RPC server active on port {4875}");
		}
		catch (Exception argument)
		{
			App.Logger.Error("Unhandled exception: ", argument);
		}
	}

	public void StopHTTPServer()
	{
		_httpCancellationTokenSource.Cancel();
		if (_httpListener != null)
		{
			try
			{
				_httpListener.Close();
			}
			catch
			{
			}
			_httpListener = null;
		}
	}

	private async Task ListenForHTTPRequests(CancellationToken token)
	{
		while ((_httpListener?.IsListening ?? false) && !token.IsCancellationRequested)
		{
			try
			{
				HttpListenerContext context = await _httpListener.GetContextAsync().WaitAsync(token);
				Task.Run(() =>
				{
					ProcessHTTPRequest(context);
				}, token);
			}
			catch (OperationCanceledException)
			{
				break;
			}
			catch (Exception value)
			{
				App.Logger.Error(value);
				await Task.Delay(1000, token);
			}
		}
	}

	private void ProcessHTTPRequest(HttpListenerContext context)
	{
		using HttpListenerResponse httpListenerResponse = context.Response;
		try
		{
			if (context.Request.HttpMethod != "POST" || context.Request.Url?.AbsolutePath != "/rpc")
			{
				httpListenerResponse.StatusCode = 404;
				return;
			}
			using StreamReader streamReader = new StreamReader(context.Request.InputStream, Encoding.UTF8);
			StudioMessage studioMessage = JsonSerializer.Deserialize<StudioMessage>(streamReader.ReadToEnd());
			if (studioMessage == null)
			{
				return;
			}
			if (studioMessage.StudioCommand == "SetRichPresence")
			{
				StudioRichPresence studioRichPresence = studioMessage.Data.Deserialize<StudioRichPresence>();
				if (studioRichPresence != null)
				{
					studioMessage.Data = JsonSerializer.SerializeToElement(studioRichPresence);
				}
			}
			OnStudioRPCMessage?.Invoke(this, studioMessage);
			httpListenerResponse.StatusCode = 200;
		}
		catch (Exception ex)
		{
			App.Logger.Error("Unhandled exception: " + ex.Message);
			httpListenerResponse.StatusCode = 500;
		}
	}

	public void LoadGameHistory()
	{
		try
		{
			if (!File.Exists(GameHistoryCachePath))
			{
				App.Logger.Info("No existing game history cache found");
				History = new List<ActivityData>();
				return;
			}
			List<GameHistoryEntry> list = JsonSerializer.Deserialize<List<GameHistoryEntry>>(File.ReadAllText(GameHistoryCachePath), _loadOptions);
			if (list != null)
			{
				List<ActivityData> list2 = new List<ActivityData>();
				foreach (GameHistoryEntry item in list)
				{
					if (item.UniverseId == 0L || item.PlaceId == 0L)
					{
						continue;
					}
					foreach (ServerInfo server in item.Servers)
					{
						if (!(server.JoinedAt == default(DateTime)))
						{
							ActivityData activityData = new ActivityData
							{
								UniverseId = item.UniverseId,
								PlaceId = item.PlaceId,
								JobId = server.JobId,
								ServerType = server.ServerType,
								TimeJoined = server.JoinedAt,
								TimeLeft = server.TimeLeft,
								Region = server.Region
							};
							activityData.UniverseDetails = UniverseDetails.LoadFromCache(activityData.UniverseId);
							list2.Add(activityData);
						}
					}
				}
				History = list2.OrderByDescending((ActivityData x) => x.TimeJoined).Take(300).ToList();
				App.Logger.Info($"Loaded {History.Count} sessions from cache");
			}
			else
			{
				History = new List<ActivityData>();
			}
		}
		catch (Exception value)
		{
			App.Logger.Error(value);
			History = new List<ActivityData>();
		}
	}

	private async void AddToHistory(ActivityData activity)
	{
		ServerType serverType = activity.ServerType;
		bool flag = (uint)(serverType - 1) <= 1u;
		if (flag || activity.UniverseId == 0L || activity.PlaceId == 0L || activity.TimeJoined == default(DateTime))
		{
			return;
		}
		if (!App.Settings.Prop.Performance.NetworkMode && activity.MachineAddressValid && string.IsNullOrEmpty(activity.Region))
		{
			ActivityData activityData = activity;
			activityData.Region = (await activity.QueryServerLocation()) ?? "Unknown";
		}
		if (!string.IsNullOrEmpty(activity.JobId))
		{
			History.RemoveAll((ActivityData x) => x.JobId == activity.JobId);
		}
		History.Insert(0, activity);
		if (History.Count > 300)
		{
			History = History.OrderByDescending((ActivityData x) => x.TimeJoined).Take(300).ToList();
		}
		SaveGameHistory();
		OnHistoryUpdated?.Invoke(this, EventArgs.Empty);
	}

	public void SaveGameHistory()
	{
		try
		{
			Directory.CreateDirectory(Paths.Cache);
			List<GameHistoryEntry> list = (from g in (from a in History
					where a.UniverseId != 0L && a.PlaceId != 0
					group a by a.UniverseId into g
					orderby g.Max((ActivityData s) => s.TimeJoined) descending
					select g).Take(30)
				select new GameHistoryEntry
				{
					UniverseId = g.Key,
					PlaceId = g.OrderByDescending((ActivityData s) => s.TimeJoined).First().PlaceId,
					Servers = (from s in g.OrderByDescending((ActivityData s) => s.TimeJoined).Take(10)
						select new ServerInfo
						{
							JobId = s.JobId,
							JoinedAt = s.TimeJoined,
							TimeLeft = s.TimeLeft,
							ServerType = s.ServerType,
							Region = s.Region
						}).ToList()
				}).ToList();
			string contents = JsonSerializer.Serialize(list, _saveOptions);
			File.WriteAllText(GameHistoryCachePath, contents);
			App.Logger.Info($"Saved {list.Count} games (max 10 servers each) to cache");
		}
		catch (Exception value)
		{
			App.Logger.Error(value);
		}
	}

	public void Dispose()
	{
		IsDisposed = true;
		if (InRobloxStudio)
		{
			StopHTTPServer();
		}
		_httpCancellationTokenSource?.Dispose();
		GC.SuppressFinalize(this);
	}
}
