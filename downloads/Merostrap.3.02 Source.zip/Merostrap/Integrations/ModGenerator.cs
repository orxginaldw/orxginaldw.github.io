using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Avalonia.Media;
using Merostrap.Enums;
using Merostrap.Models.APIs.Config;
using Merostrap.Models.APIs.GitHub;
using Merostrap.Models.APIs.Roblox;
using Merostrap.Utility;
using SkiaSharp;

namespace Merostrap.Integrations;

internal static class ModGenerator
{
	internal record GradientStop(float Stop, Color Color);

	internal record SpriteDef(string Name, int X, int Y, int W, int H);

	private class SpriteBlacklist
	{
		public List<string> Prefixes { get; set; } = new List<string>();

		public List<string> Suffixes { get; set; } = new List<string>();

		public List<string> Keywords { get; set; } = new List<string>();

		public List<string> Strict { get; set; } = new List<string>();

		public bool IsBlacklisted(string name)
		{
			if (name.StartsWith("icons/graphic/lock", StringComparison.OrdinalIgnoreCase))
			{
				return false;
			}
			foreach (string prefix in Prefixes)
			{
				if (name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
				{
					return true;
				}
			}
			foreach (string suffix in Suffixes)
			{
				if (name.EndsWith(suffix, StringComparison.OrdinalIgnoreCase))
				{
					return true;
				}
			}
			foreach (string keyword in Keywords)
			{
				if (name.Contains(keyword, StringComparison.OrdinalIgnoreCase))
				{
					return true;
				}
			}
			foreach (string item in Strict)
			{
				if (string.Equals(name, item, StringComparison.OrdinalIgnoreCase))
				{
					return true;
				}
			}
			return false;
		}
	}

	private static class LuaImageSetParser
	{
		public static Dictionary<string, List<SpriteDef>> Parse(string luaPath)
		{
			App.Logger.Info("Parsing Lua file: " + luaPath);
			string text = File.ReadAllText(luaPath);
			Dictionary<string, List<SpriteDef>> dictionary = new Dictionary<string, List<SpriteDef>>();
			Regex regex = new Regex("\\['([^']+)'\\]\\s*=\\s*{\\s*ImageRectOffset\\s*=\\s*Vector2\\.new\\((\\d+),\\s*(\\d+)\\)\\s*,\\s*ImageRectSize\\s*=\\s*Vector2\\.new\\((\\d+),\\s*(\\d+)\\)\\s*,\\s*ImageSet\\s*=\\s*'([^']+)'", RegexOptions.Compiled);
			string[] array = new string[3] { "assets_1x", "assets_2x", "assets_3x" };
			int num = 0;
			string[] array2 = array;
			foreach (string value in array2)
			{
				string value2 = $"function make_{value}() {value} = {{";
				int num2 = text.IndexOf(value2, StringComparison.Ordinal);
				if (num2 == -1)
				{
					continue;
				}
				int num3 = text.IndexOf('{', num2);
				if (num3 == -1)
				{
					continue;
				}
				int num4 = FindMatchingBrace(text, num3);
				string input = text.Substring(num3 + 1, num4 - num3 - 1);
				MatchCollection matchCollection = regex.Matches(input);
				App.Logger.Info($"Found {matchCollection.Count} entries in {value}");
				num += matchCollection.Count;
				foreach (Match item in matchCollection)
				{
					string value3 = item.Groups[1].Value;
					int x = int.Parse(item.Groups[2].Value, CultureInfo.InvariantCulture);
					int y = int.Parse(item.Groups[3].Value, CultureInfo.InvariantCulture);
					int w = int.Parse(item.Groups[4].Value, CultureInfo.InvariantCulture);
					int h = int.Parse(item.Groups[5].Value, CultureInfo.InvariantCulture);
					string path = item.Groups[6].Value + ".png";
					string fullPath = Path.GetFullPath(Path.Combine(Path.Combine(Path.GetDirectoryName(luaPath), "..", "SpriteSheets"), path));
					if (!dictionary.ContainsKey(fullPath))
					{
						dictionary[fullPath] = new List<SpriteDef>();
					}
					dictionary[fullPath].Add(new SpriteDef(value3, x, y, w, h));
				}
			}
			App.Logger.Info($"Total sprite definitions: {num}, across {dictionary.Count} sheets");
			if (num == 0)
			{
				App.Logger.Warn("No sprites matched. Check the Lua file format.");
			}
			return dictionary;
		}

		private static int FindMatchingBrace(string text, int openBraceIndex)
		{
			int num = 1;
			for (int i = openBraceIndex + 1; i < text.Length; i++)
			{
				if (text[i] == '{')
				{
					num++;
				}
				else if (text[i] == '}')
				{
					num--;
				}
				if (num == 0)
				{
					return i;
				}
			}
			return -1;
		}
	}

	private const string ModGeneratorVersionApiUrl = "https://api.github.com/repos/Merostrap/mod-generator/releases/latest";

	private static readonly string[] CursorFiles = new string[3] { "IBeamCursor.png", "ArrowCursor.png", "ArrowFarCursor.png" };

	private static readonly string[] ShiftlockFiles = new string[1] { "MouseLockedCursor.png" };

	private static readonly string[] EmoteWheelFiles = new string[6] { "SelectedGradient.png", "SelectedGradient@2x.png", "SelectedGradient@3x.png", "SelectedLine.png", "SelectedLine@2x.png", "SelectedLine@3x.png" };

	private static readonly HttpClient DownloadClient = new HttpClient(new HttpClientHandler
	{
		AutomaticDecompression = DecompressionMethods.All,
		CheckCertificateRevocationList = true
	})
	{
		Timeout = TimeSpan.FromMinutes(5L)
	};

	private static readonly SpriteBlacklist SpriteBlacklistInstance;

	private static string ModGeneratorVersionCacheFile => Path.Combine(Paths.Cache, "ModGeneratorVersion.json");

	private static async Task<GithubRelease?> GetLatestModGeneratorRelease()
	{
		try
		{
			return await Http.GetJson<GithubRelease>(new Uri("https://api.github.com/repos/Merostrap/mod-generator/releases/latest"));
		}
		catch (Exception ex)
		{
			App.Logger.Warn("GetLatestModGeneratorRelease failed: " + ex.Message);
			return null;
		}
	}

	private static string GetCachedModGeneratorVersion()
	{
		try
		{
			using JsonDocument jsonDocument = JsonDocument.Parse(File.ReadAllText(ModGeneratorVersionCacheFile));
			return jsonDocument.RootElement.GetProperty("Version").GetString() ?? "0.0.0";
		}
		catch
		{
			return "0.0.0";
		}
	}

	private static void CacheModGeneratorVersion(string version)
	{
		var value = new
		{
			Version = version,
			UpdatedAt = DateTime.Now
		};
		File.WriteAllText(ModGeneratorVersionCacheFile, JsonSerializer.Serialize(value));
	}

	public static async Task<string> EnsureModGeneratorAsync()
	{
		string exePath = GetModGeneratorExePath();
		string cachedVersion = GetCachedModGeneratorVersion();
		if (File.Exists(exePath))
		{
			GithubRelease githubRelease = await GetLatestModGeneratorRelease();
			if (githubRelease != null && Versioning.CompareVersions(githubRelease.TagName, cachedVersion) != VersionComparison.GreaterThan)
			{
				return exePath;
			}
		}
		App.Logger.Info("Downloading mod-generator (cached: " + cachedVersion + ")...");
		await DownloadModGeneratorInternalAsync();
		return exePath;
	}

	private static string GetModGeneratorExePath()
	{
		string modGeneratorAssetName = GetModGeneratorAssetName();
		string text = Path.Combine(Path.GetTempPath(), "Merostrap", "mod-generator");
		Directory.CreateDirectory(text);
		return Path.Combine(text, modGeneratorAssetName);
	}

	private static async Task DownloadModGeneratorInternalAsync()
	{
		GithubRelease release = await GetLatestModGeneratorRelease();
		if (release == null)
		{
			throw new InvalidOperationException("Failed to fetch latest mod-generator release.");
		}
		string assetName = GetModGeneratorAssetName();
		string text = (release.Assets?.FirstOrDefault((GithubReleaseAsset a) => a.Name.Equals(assetName, StringComparison.OrdinalIgnoreCase)))?.BrowserDownloadUrl;
		if (string.IsNullOrEmpty(text))
		{
			text = "https://github.com/Froststrap/mod-generator/releases/latest/download/" + assetName;
		}
		byte[] bytes = await DownloadClient.GetByteArrayAsync(new Uri(text));
		string exePath = GetModGeneratorExePath();
		await File.WriteAllBytesAsync(exePath, bytes);
		if (!OperatingSystem.IsWindows())
		{
			using Process chmod = Process.Start(new ProcessStartInfo
			{
				FileName = "chmod",
				Arguments = "+x \"" + exePath + "\"",
				UseShellExecute = false,
				CreateNoWindow = true
			});
			if (chmod != null)
			{
				await chmod.WaitForExitAsync();
			}
		}
		CacheModGeneratorVersion(release.TagName);
		App.Logger.Info("mod-generator updated to version " + release.TagName);
	}

	public static void RecolorAllPngs(string rootDir, Color solidColor, Dictionary<string, string[]> mappings, bool recolorCursors = false, bool recolorShiftlock = false, bool recolorEmoteWheel = false, List<GradientStop>? gradient = null, float gradientAngleDeg = 0f, string? getImageSetDataPath = null, string? customLogoPath = null, string? customSpinnerPath = null)
	{
		if (string.IsNullOrWhiteSpace(rootDir) || !Directory.Exists(rootDir))
		{
			return;
		}
		Parallel.ForEach(mappings, (KeyValuePair<string, string[]> kv) =>
		{
			string path4 = Path.Combine(kv.Value);
			string path5 = Path.Combine(rootDir, path4);
			if (File.Exists(path5))
			{
				SafeRecolorImage(path5, solidColor, gradient, gradientAngleDeg);
			}
		});
		int num = 3;
		List<(bool, string[], string)> list = new List<(bool, string[], string)>(num);
		CollectionsMarshal.SetCount(list, num);
		Span<(bool, string[], string)> span = CollectionsMarshal.AsSpan(list);
		span[0] = (recolorCursors, CursorFiles, Path.Combine("content", "textures", "Cursors", "KeyboardMouse"));
		span[1] = (recolorShiftlock, ShiftlockFiles, Path.Combine("content", "textures"));
		ref(bool, string[], string) reference = ref span[2];
		bool item = recolorEmoteWheel;
		string[] emoteWheelFiles = EmoteWheelFiles;
		InlineArray5<string> buffer = default;
		buffer[0] = "content";
		buffer[1] = "textures";
		buffer[2] = "ui";
		buffer[3] = "Emotes";
		buffer[4] = "Large";
		reference = (item, emoteWheelFiles, Path.Combine(buffer));
		foreach (var (flag, array, path) in list)
		{
			if (!flag)
			{
				continue;
			}
			string[] array2 = array;
			foreach (string path2 in array2)
			{
				string path3 = Path.Combine(rootDir, path, path2);
				if (File.Exists(path3))
				{
					SafeRecolorImage(path3, solidColor, gradient, gradientAngleDeg);
				}
			}
		}
		if (!string.IsNullOrWhiteSpace(getImageSetDataPath) && File.Exists(getImageSetDataPath))
		{
			RecolorSpriteSheets(solidColor, gradient, gradientAngleDeg, getImageSetDataPath, customLogoPath, customSpinnerPath);
		}
	}

	private static void RecolorSpriteSheets(Color solidColor, List<GradientStop>? gradient, float gradientAngleDeg, string getImageSetDataPath, string? customLogoPath, string? customSpinnerPath)
	{
		App.Logger.Info("Parsing image set data: " + getImageSetDataPath);
		Dictionary<string, List<SpriteDef>> dictionary = LuaImageSetParser.Parse(getImageSetDataPath);
		if (dictionary.Count == 0)
		{
			App.Logger.Warn("No sprite sheets found from Lua file.");
			return;
		}
		App.Logger.Info($"Found {dictionary.Count} sprite sheets.");
		foreach (var (text2, list2) in dictionary)
		{
			App.Logger.Info($"Processing sheet: {text2} with {list2.Count} sprites");
			if (!File.Exists(text2))
			{
				continue;
			}
			using SKBitmap sKBitmap = LoadAsRgba8888(text2);
			bool flag = false;
			if (!string.IsNullOrEmpty(customLogoPath) && File.Exists(customLogoPath))
			{
				flag |= ReplaceCustomSprite(sKBitmap, list2, "icons/logo/block", customLogoPath);
			}
			if (!string.IsNullOrEmpty(customSpinnerPath) && File.Exists(customSpinnerPath))
			{
				flag |= ReplaceCustomSprite(sKBitmap, list2, "icons/graphic/loadingspinner", customSpinnerPath);
			}
			foreach (SpriteDef item in list2)
			{
				if (item.W <= 0 || item.H <= 0 || SpriteBlacklistInstance.IsBlacklisted(item.Name) || (string.Equals(item.Name, "icons/logo/block", StringComparison.OrdinalIgnoreCase) && !string.IsNullOrEmpty(customLogoPath)) || (string.Equals(item.Name, "icons/graphic/loadingspinner", StringComparison.OrdinalIgnoreCase) && !string.IsNullOrEmpty(customSpinnerPath)))
				{
					continue;
				}
				using SKBitmap original = ExtractSprite(sKBitmap, item.X, item.Y, item.W, item.H);
				using SKBitmap sKBitmap2 = ApplyMaskToBitmap(original, solidColor, gradient, gradientAngleDeg);
				for (int i = 0; i < item.H; i++)
				{
					for (int j = 0; j < item.W; j++)
					{
						sKBitmap.SetPixel(item.X + j, item.Y + i, sKBitmap2.GetPixel(j, i));
					}
				}
				flag = true;
			}
			if (flag)
			{
				string text3 = text2 + ".tmp";
				SaveBitmapAsPng(sKBitmap, text3);
				ReplaceFileWithRetry(text2, text3);
				App.Logger.Info("Recolored sprite sheet: " + text2);
			}
		}
	}

	private static bool ReplaceCustomSprite(SKBitmap sheet, List<SpriteDef> sprites, string targetSpriteName, string customImagePath)
	{
		SpriteDef spriteDef = sprites.FirstOrDefault((SpriteDef s) => string.Equals(s.Name, targetSpriteName, StringComparison.OrdinalIgnoreCase));
		if (spriteDef == null || spriteDef.W <= 0 || spriteDef.H <= 0)
		{
			return false;
		}
		using SKBitmap sKBitmap = LoadAsRgba8888(customImagePath);
		float num = Math.Min((float)spriteDef.W / (float)sKBitmap.Width, (float)spriteDef.H / (float)sKBitmap.Height);
		int num2 = Math.Max(1, (int)Math.Round((float)sKBitmap.Width * num));
		int num3 = Math.Max(1, (int)Math.Round((float)sKBitmap.Height * num));
		using SKBitmap sKBitmap2 = new SKBitmap(new SKImageInfo(spriteDef.W, spriteDef.H, SKColorType.Rgba8888, SKAlphaType.Unpremul));
		using (SKCanvas sKCanvas = new SKCanvas(sKBitmap2))
		{
			sKCanvas.Clear(SKColors.Transparent);
			SKRect dest = SKRect.Create((float)(spriteDef.W - num2) / 2f, (float)(spriteDef.H - num3) / 2f, num2, num3);
			sKCanvas.DrawBitmap(sKBitmap, dest);
		}
		for (int num4 = 0; num4 < spriteDef.H; num4++)
		{
			for (int num5 = 0; num5 < spriteDef.W; num5++)
			{
				SKColor pixel = sKBitmap2.GetPixel(num5, num4);
				if (pixel.Alpha > 0)
				{
					sheet.SetPixel(spriteDef.X + num5, spriteDef.Y + num4, pixel);
				}
			}
		}
		return true;
	}

	private static void SafeRecolorImage(string path, Color solidColor, List<GradientStop>? gradient, float gradientAngleDeg)
	{
		using SKBitmap original = LoadAsRgba8888(path);
		using SKBitmap bitmap = ApplyMaskToBitmap(original, solidColor, gradient, gradientAngleDeg);
		string text = path + ".tmp";
		SaveBitmapAsPng(bitmap, text);
		ReplaceFileWithRetry(path, text);
	}

	private static SKBitmap ApplyMaskToBitmap(SKBitmap original, Color solidColor, List<GradientStop>? gradient, float gradientAngleDeg)
	{
		int width = original.Width;
		int height = original.Height;
		SKBitmap sKBitmap = original.Copy();
		double num2;
		double num3;
		double num7;
		double num8;
		if (gradient != null && gradient.Count > 0)
		{
			double num = (double)(gradientAngleDeg - 90f) * Math.PI / 180.0;
			num2 = Math.Cos(num);
			num3 = Math.Sin(num);
			double num4 = width - 1;
			double num5 = height - 1;
			double val = 0.0 * num2 + 0.0 * num3;
			double val2 = num4 * num2 + 0.0 * num3;
			double val3 = 0.0 * num2 + num5 * num3;
			double val4 = num4 * num2 + num5 * num3;
			double num6 = Math.Min(Math.Min(val, val2), Math.Min(val3, val4));
			num7 = Math.Max(Math.Max(val, val2), Math.Max(val3, val4)) - num6;
			if (Math.Abs(num7) < 1E-06)
			{
				num7 = 1.0;
			}
			num8 = num6;
		}
		else
		{
			num2 = (num3 = (num8 = 0.0));
			num7 = 1.0;
		}
		for (int i = 0; i < height; i++)
		{
			for (int j = 0; j < width; j++)
			{
				SKColor pixel = original.GetPixel(j, i);
				if (pixel.Alpha != 0)
				{
					Color color;
					if (gradient != null && gradient.Count > 0)
					{
						float value = (float)(((double)j * num2 + (double)i * num3 - num8) / num7);
						value = Math.Clamp(value, 0f, 1f);
						color = InterpolateGradient(gradient, value);
					}
					else
					{
						color = solidColor;
					}
					sKBitmap.SetPixel(j, i, new SKColor(color.R, color.G, color.B, pixel.Alpha));
				}
			}
		}
		return sKBitmap;
	}

	private static Color InterpolateGradient(List<GradientStop> stops, float t)
	{
		if (stops == null || stops.Count == 0)
		{
			return Color.FromRgb(byte.MaxValue, byte.MaxValue, byte.MaxValue);
		}
		List<GradientStop> list = stops.OrderBy((GradientStop s) => s.Stop).ToList();
		if (t <= list[0].Stop)
		{
			return list[0].Color;
		}
		if (t >= list[list.Count - 1].Stop)
		{
			return list[list.Count - 1].Color;
		}
		GradientStop gradientStop = list[0];
		GradientStop gradientStop2 = list[list.Count - 1];
		for (int num = 0; num < list.Count - 1; num++)
		{
			if (t >= list[num].Stop && t <= list[num + 1].Stop)
			{
				gradientStop = list[num];
				gradientStop2 = list[num + 1];
				break;
			}
		}
		float num2 = gradientStop2.Stop - gradientStop.Stop;
		float value = ((num2 > 0f) ? ((t - gradientStop.Stop) / num2) : 0f);
		value = Math.Clamp(value, 0f, 1f);
		byte r = (byte)((float)(int)gradientStop.Color.R + (float)(gradientStop2.Color.R - gradientStop.Color.R) * value);
		byte g = (byte)((float)(int)gradientStop.Color.G + (float)(gradientStop2.Color.G - gradientStop.Color.G) * value);
		byte b = (byte)((float)(int)gradientStop.Color.B + (float)(gradientStop2.Color.B - gradientStop.Color.B) * value);
		return Color.FromRgb(r, g, b);
	}

	private static SKBitmap LoadAsRgba8888(string path)
	{
		using SKBitmap sKBitmap = SKBitmap.Decode(path) ?? throw new IOException("Failed to decode image: " + path);
		if (sKBitmap.ColorType == SKColorType.Rgba8888 && sKBitmap.AlphaType == SKAlphaType.Unpremul)
		{
			return sKBitmap.Copy();
		}
		SKBitmap sKBitmap2 = new SKBitmap(new SKImageInfo(sKBitmap.Width, sKBitmap.Height, SKColorType.Rgba8888, SKAlphaType.Unpremul));
		using (SKCanvas sKCanvas = new SKCanvas(sKBitmap2))
		{
			sKCanvas.Clear(SKColors.Transparent);
			using SKPaint paint = new SKPaint
			{
				BlendMode = SKBlendMode.Src
			};
			sKCanvas.DrawBitmap(sKBitmap, 0f, 0f, paint);
		}
		return sKBitmap2;
	}

	private static SKBitmap ExtractSprite(SKBitmap source, int x, int y, int w, int h)
	{
		SKBitmap sKBitmap = new SKBitmap(new SKImageInfo(w, h, SKColorType.Rgba8888, SKAlphaType.Unpremul));
		for (int i = 0; i < h; i++)
		{
			for (int j = 0; j < w; j++)
			{
				sKBitmap.SetPixel(j, i, source.GetPixel(x + j, y + i));
			}
		}
		return sKBitmap;
	}

	private static void SaveBitmapAsPng(SKBitmap bitmap, string path)
	{
		using SKImage sKImage = SKImage.FromBitmap(bitmap);
		using SKData sKData = sKImage.Encode(SKEncodedImageFormat.Png, 100);
		using FileStream target = File.Create(path);
		sKData.SaveTo(target);
	}

	private static void ReplaceFileWithRetry(string originalPath, string tempPath)
	{
		int num = 0;
		while (true)
		{
			try
			{
				File.Delete(originalPath);
				File.Move(tempPath, originalPath);
				break;
			}
			catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
			{
				num++;
				if (num > 5)
				{
					throw;
				}
				Thread.Sleep(50);
			}
		}
	}

	public static async Task RecolorFontsAsync(string merostrapTemp, Color solidColor, string? gradientStops = null, double? angle = null, string? imageMap = null, int? bands = null, string? skipGlyphs = null)
	{
		InlineArray8<string> buffer = default;
		buffer[0] = merostrapTemp;
		buffer[1] = "ExtraContent";
		buffer[2] = "LuaPackages";
		buffer[3] = "Packages";
		buffer[4] = "_Index";
		buffer[5] = "BuilderIcons";
		buffer[6] = "BuilderIcons";
		buffer[7] = "Font";
		string fontDir = Path.Combine(buffer);
		if (Directory.Exists(fontDir))
		{
			string text = await EnsureModGeneratorAsync();
			string text2 = gradientStops ?? $"{solidColor.R:X2}{solidColor.G:X2}{solidColor.B:X2}";
			string text3 = "--path \"" + fontDir + "\" --color " + text2;
			if (angle.HasValue)
			{
				text3 += $" --angle {angle.Value}";
			}
			if (!string.IsNullOrEmpty(imageMap))
			{
				text3 = text3 + " --image-map \"" + imageMap + "\"";
			}
			if (bands.HasValue && bands.Value > 0)
			{
				text3 += $" --bands {bands.Value}";
			}
			if (!string.IsNullOrEmpty(skipGlyphs))
			{
				text3 = text3 + " --skip-glyphs \"" + skipGlyphs + "\"";
			}
			App.Logger.Info<string>("RecolorFontsAsync", "Recolor Args: " + text3);
			await ExecuteExeAsync(text, text3, Path.GetDirectoryName(text));
		}
	}

	private static string GetModGeneratorAssetName()
	{
		if (OperatingSystem.IsWindows())
		{
			return "mod-generator.exe";
		}
		if (OperatingSystem.IsMacOS())
		{
			return "mod-generator-macos";
		}
		return "mod-generator-linux";
	}

	public static async Task<(string luaZip, string extraZip, string contentZip, string hash, string version)> DownloadForModGenerator(bool overwrite = false)
	{
		ClientVersion clientInfo = await Http.GetJson<ClientVersion>(UrlBuilder.BuildApiUrl("clientsettingscdn", "v2/client-version/WindowsStudio64"));
		string hash = clientInfo.VersionGuid.Replace("version-", "", StringComparison.Ordinal);
		string tempPath = Path.Combine(Path.GetTempPath(), "Merostrap");
		Directory.CreateDirectory(tempPath);
		InlineArray3<Task<string>> buffer = default;
		buffer[0] = DownloadOne("extracontent-luapackages");
		buffer[1] = DownloadOne("extracontent-textures");
		buffer[2] = DownloadOne("content-textures2");
		string[] array = await Task.WhenAll<string>(buffer);
		foreach (string item in from f in Directory.GetFiles(tempPath, "*.zip")
			where !f.Contains(hash, StringComparison.OrdinalIgnoreCase)
			select f)
		{
			try
			{
				File.Delete(item);
			}
			catch
			{
			}
		}
		return (luaZip: array[0], extraZip: array[1], contentZip: array[2], hash: hash, version: clientInfo.Version);
		async Task<string> DownloadOne(string type)
		{
			string uriString = $"https://setup.rbxcdn.com/version-{hash}-{type}.zip";
			string path = Path.Combine(tempPath, type + "-" + hash + ".zip");
			if (!overwrite && File.Exists(path) && new FileInfo(path).Length > 0)
			{
				return path;
			}
			await File.WriteAllBytesAsync(path, await DownloadClient.GetByteArrayAsync(new Uri(uriString)));
			return path;
		}
	}

	public static async Task<Dictionary<string, string[]>> LoadMappingsAsync()
	{
		try
		{
			RemoteDataBase prop = App.RemoteData.Prop;
			if (prop != null && prop.Mappings?.Count > 0)
			{
				return prop.Mappings;
			}
		}
		catch
		{
		}
		return await LoadEmbeddedMappingsAsync();
	}

	private static async Task<Dictionary<string, string[]>> LoadEmbeddedMappingsAsync()
	{
		Assembly executingAssembly = Assembly.GetExecutingAssembly();
		using Stream stream = executingAssembly.GetManifestResourceStream("Merostrap.Resources.mappings.json");
		if (stream == null)
		{
			return new Dictionary<string, string[]>();
		}
		return (await JsonSerializer.DeserializeAsync<Dictionary<string, string[]>>(stream)) ?? new Dictionary<string, string[]>();
	}

	private static async Task<(int ExitCode, string Output, string Errors)> ExecuteExeAsync(string exe, string args, string workingDir)
	{
		using Process process = new Process
		{
			StartInfo = new ProcessStartInfo
			{
				FileName = exe,
				Arguments = args,
				WorkingDirectory = workingDir,
				UseShellExecute = false,
				RedirectStandardOutput = true,
				RedirectStandardError = true,
				CreateNoWindow = true
			}
		};
		process.Start();
		Task<string> outTask = process.StandardOutput.ReadToEndAsync();
		Task<string> errTask = process.StandardError.ReadToEndAsync();
		await process.WaitForExitAsync();
		int exitCode = process.ExitCode;
		return (ExitCode: exitCode, Output: await outTask, Errors: await errTask);
	}

	public static void ZipResult(string sourceDir, string outputZip)
	{
		if (File.Exists(outputZip))
		{
			File.Delete(outputZip);
		}
		ZipFile.CreateFromDirectory(sourceDir, outputZip, CompressionLevel.Optimal, includeBaseDirectory: false);
	}

	static ModGenerator()
	{
		SpriteBlacklist spriteBlacklist = new SpriteBlacklist();
		int num = 5;
		List<string> list = new List<string>(num);
		CollectionsMarshal.SetCount(list, num);
		Span<string> span = CollectionsMarshal.AsSpan(list);
		span[0] = "chat_bubble/";
		span[1] = "component_assets/";
		span[2] = "icons/controls/voice/";
		span[3] = "icons/graphic/";
		span[4] = "squircles/";
		spriteBlacklist.Prefixes = list;
		spriteBlacklist.Suffixes = new List<string>();
		num = 2;
		List<string> list2 = new List<string>(num);
		CollectionsMarshal.SetCount(list2, num);
		Span<string> span2 = CollectionsMarshal.AsSpan(list2);
		span2[0] = "goldrobux";
		span2[1] = "icons/common/play";
		spriteBlacklist.Keywords = list2;
		num = 1;
		List<string> list3 = new List<string>(num);
		CollectionsMarshal.SetCount(list3, num);
		CollectionsMarshal.AsSpan(list3)[0] = "gradient/gradient_0_100";
		spriteBlacklist.Strict = list3;
		SpriteBlacklistInstance = spriteBlacklist;
	}
}
