using System;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Threading;
using Merostrap.Enums;

namespace Merostrap.Integrations;

internal sealed class Softkey : IDisposable
{
	private enum ActiveHorizontal
	{
		None,
		Left,
		Right
	}

	private enum ActiveVertical
	{
		None,
		Up,
		Down
	}

	private delegate nint LowLevelKeyboardProc(int nCode, nint wParam, nint lParam);

	private struct KBDLLHOOKSTRUCT
	{
		public uint vkCode;

		public uint scanCode;

		public uint flags;

		public uint time;

		public nuint dwExtraInfo;
	}

	private struct INPUT
	{
		public uint type;

		public InputUnion u;
	}

	[StructLayout(LayoutKind.Explicit)]
	private struct InputUnion
	{
		[FieldOffset(0)]
		public MOUSEINPUT mi;

		[FieldOffset(0)]
		public KEYBDINPUT ki;

		[FieldOffset(0)]
		public HARDWAREINPUT hi;
	}

	private struct MOUSEINPUT
	{
		public int dx;

		public int dy;

		public uint mouseData;

		public uint dwFlags;

		public uint time;

		public nuint dwExtraInfo;
	}

	private struct KEYBDINPUT
	{
		public ushort wVk;

		public ushort wScan;

		public uint dwFlags;

		public uint time;

		public nuint dwExtraInfo;
	}

	private struct HARDWAREINPUT
	{
		public uint uMsg;

		public ushort wParamL;

		public ushort wParamH;
	}

	private struct MSG
	{
		public nint hwnd;

		public uint message;

		public nint wParam;

		public nint lParam;

		public uint time;

		public int pt_x;

		public int pt_y;
	}

	private uint _keyUp;

	private uint _keyLeft;

	private uint _keyDown;

	private uint _keyRight;

	private const int WH_KEYBOARD_LL = 13;

	private const int WM_KEYDOWN = 256;

	private const int WM_KEYUP = 257;

	private const int WM_SYSKEYDOWN = 260;

	private const int WM_SYSKEYUP = 261;

	private const int LLKHF_INJECTED = 16;

	private const nuint InjectedMarker = 1179865940u;

	private readonly int _robloxPid;

	private Thread? _hookThread;

	private uint _hookThreadId;

	private nint _hookHandle = IntPtr.Zero;

	private LowLevelKeyboardProc? _hookProc;

	private bool _physLeft;

	private bool _physRight;

	private ActiveHorizontal _activeHorizontal;

	private bool _physUp;

	private bool _physDown;

	private ActiveVertical _activeVertical;

	private bool _isEnabled = true;

	private bool _isDisposed;

	private const uint INPUT_KEYBOARD = 1u;

	private const uint KEYEVENTF_KEYUP = 2u;

	private const uint KEYEVENTF_SCANCODE = 8u;

	private const uint MAPVK_VK_TO_VSC = 0u;

	private const uint WM_QUIT = 18u;

	public Softkey(int robloxPid)
	{
		_robloxPid = robloxPid;
		AssignKeys(App.Settings.Prop.SoftKeyProfile);
		if (!OperatingSystem.IsWindows())
		{
			App.Logger.Warn("Softkey is only supported on Windows, skipping");
		}
		else
		{
			Start();
		}
	}

	public void SetEnabled(bool enabled)
	{
		_isEnabled = enabled;
		if (!enabled)
		{
			ClearState();
		}
	}

	private void AssignKeys(SoftKeyProfile profile)
	{
		switch (profile)
		{
		case SoftKeyProfile.AZERTY:
			_keyUp = 90u;
			_keyLeft = 81u;
			_keyDown = 83u;
			_keyRight = 68u;
			break;
		case SoftKeyProfile.ESDF:
			_keyUp = 69u;
			_keyLeft = 83u;
			_keyDown = 68u;
			_keyRight = 70u;
			break;
		case SoftKeyProfile.ArrowKeys:
			_keyUp = 38u;
			_keyLeft = 37u;
			_keyDown = 40u;
			_keyRight = 39u;
			break;
		default:
			_keyUp = 87u;
			_keyLeft = 65u;
			_keyDown = 83u;
			_keyRight = 68u;
			break;
		}
	}

	[SupportedOSPlatform("windows")]
	private void Start()
	{
		_hookThread = new Thread(HookThreadProc)
		{
			IsBackground = true,
			Name = "Softkey Hook"
		};
		_hookThread.Start();
	}

	[SupportedOSPlatform("windows")]
	private void HookThreadProc()
	{
		_hookThreadId = GetCurrentThreadId();
		_hookProc = HookCallback;
		_hookHandle = SetWindowsHookEx(13, _hookProc, IntPtr.Zero, 0u);
		if (_hookHandle == IntPtr.Zero)
		{
			App.Logger.Error($"Failed to install keyboard hook, error {Marshal.GetLastWin32Error()}");
			return;
		}
		App.Logger.Info("Keyboard hook installed");
		MSG lpMsg;
		while (GetMessage(out lpMsg, IntPtr.Zero, 0u, 0u) > 0)
		{
			TranslateMessage(ref lpMsg);
			DispatchMessage(ref lpMsg);
		}
	}

	[SupportedOSPlatform("windows")]
	private nint HookCallback(int nCode, nint wParam, nint lParam)
	{
		try
		{
			if (nCode < 0 || !_isEnabled)
			{
				return CallNextHookEx(_hookHandle, nCode, wParam, lParam);
			}
			KBDLLHOOKSTRUCT kBDLLHOOKSTRUCT = Marshal.PtrToStructure<KBDLLHOOKSTRUCT>(lParam);
			if (kBDLLHOOKSTRUCT.dwExtraInfo == 1179865940 || (kBDLLHOOKSTRUCT.flags & 0x10) != 0)
			{
				return CallNextHookEx(_hookHandle, nCode, wParam, lParam);
			}
			GetWindowThreadProcessId(GetForegroundWindow(), out var lpdwProcessId);
			if (lpdwProcessId != _robloxPid)
			{
				ClearState();
				return CallNextHookEx(_hookHandle, nCode, wParam, lParam);
			}
			if (kBDLLHOOKSTRUCT.vkCode != _keyUp && kBDLLHOOKSTRUCT.vkCode != _keyDown && kBDLLHOOKSTRUCT.vkCode != _keyLeft && kBDLLHOOKSTRUCT.vkCode != _keyRight)
			{
				return CallNextHookEx(_hookHandle, nCode, wParam, lParam);
			}
			int num = ((IntPtr)wParam).ToInt32();
			bool flag = num == 256 || num == 260;
			bool flag2 = num == 257 || num == 261;
			if (!flag && !flag2)
			{
				return CallNextHookEx(_hookHandle, nCode, wParam, lParam);
			}
			if (kBDLLHOOKSTRUCT.vkCode == _keyLeft || kBDLLHOOKSTRUCT.vkCode == _keyRight)
			{
				if (flag)
				{
					HandleKeyDownHorizontal(kBDLLHOOKSTRUCT.vkCode == _keyLeft);
				}
				else
				{
					HandleKeyUpHorizontal(kBDLLHOOKSTRUCT.vkCode == _keyLeft);
				}
			}
			else if (kBDLLHOOKSTRUCT.vkCode == _keyUp || kBDLLHOOKSTRUCT.vkCode == _keyDown)
			{
				if (flag)
				{
					HandleKeyDownVertical(kBDLLHOOKSTRUCT.vkCode == _keyUp);
				}
				else
				{
					HandleKeyUpVertical(kBDLLHOOKSTRUCT.vkCode == _keyUp);
				}
			}
			return 1;
		}
		catch (Exception exception)
		{
			App.Logger.Error(exception, "Hook callback crashed");
			return CallNextHookEx(_hookHandle, nCode, wParam, lParam);
		}
	}

	private void HandleKeyDownHorizontal(bool isLeft)
	{
		if (isLeft)
		{
			if (_physLeft)
			{
				return;
			}
			_physLeft = true;
			if (_activeHorizontal != ActiveHorizontal.Left)
			{
				if (_activeHorizontal == ActiveHorizontal.Right)
				{
					SendKey((int)_keyRight, keyDown: false);
				}
				SendKey((int)_keyLeft, keyDown: true);
				_activeHorizontal = ActiveHorizontal.Left;
			}
		}
		else
		{
			if (_physRight)
			{
				return;
			}
			_physRight = true;
			if (_activeHorizontal != ActiveHorizontal.Right)
			{
				if (_activeHorizontal == ActiveHorizontal.Left)
				{
					SendKey((int)_keyLeft, keyDown: false);
				}
				SendKey((int)_keyRight, keyDown: true);
				_activeHorizontal = ActiveHorizontal.Right;
			}
		}
	}

	private void HandleKeyUpHorizontal(bool isLeft)
	{
		if (isLeft)
		{
			_physLeft = false;
			if (_activeHorizontal == ActiveHorizontal.Left)
			{
				SendKey((int)_keyLeft, keyDown: false);
				_activeHorizontal = ActiveHorizontal.None;
				if (_physRight)
				{
					SendKey((int)_keyRight, keyDown: true);
					_activeHorizontal = ActiveHorizontal.Right;
				}
			}
			return;
		}
		_physRight = false;
		if (_activeHorizontal == ActiveHorizontal.Right)
		{
			SendKey((int)_keyRight, keyDown: false);
			_activeHorizontal = ActiveHorizontal.None;
			if (_physLeft)
			{
				SendKey((int)_keyLeft, keyDown: true);
				_activeHorizontal = ActiveHorizontal.Left;
			}
		}
	}

	private void HandleKeyDownVertical(bool isUp)
	{
		if (isUp)
		{
			if (_physUp)
			{
				return;
			}
			_physUp = true;
			if (_activeVertical != ActiveVertical.Up)
			{
				if (_activeVertical == ActiveVertical.Down)
				{
					SendKey((int)_keyDown, keyDown: false);
				}
				SendKey((int)_keyUp, keyDown: true);
				_activeVertical = ActiveVertical.Up;
			}
		}
		else
		{
			if (_physDown)
			{
				return;
			}
			_physDown = true;
			if (_activeVertical != ActiveVertical.Down)
			{
				if (_activeVertical == ActiveVertical.Up)
				{
					SendKey((int)_keyUp, keyDown: false);
				}
				SendKey((int)_keyDown, keyDown: true);
				_activeVertical = ActiveVertical.Down;
			}
		}
	}

	private void HandleKeyUpVertical(bool isUp)
	{
		if (isUp)
		{
			_physUp = false;
			if (_activeVertical == ActiveVertical.Up)
			{
				SendKey((int)_keyUp, keyDown: false);
				_activeVertical = ActiveVertical.None;
				if (_physDown)
				{
					SendKey((int)_keyDown, keyDown: true);
					_activeVertical = ActiveVertical.Down;
				}
			}
			return;
		}
		_physDown = false;
		if (_activeVertical == ActiveVertical.Down)
		{
			SendKey((int)_keyDown, keyDown: false);
			_activeVertical = ActiveVertical.None;
			if (_physUp)
			{
				SendKey((int)_keyUp, keyDown: true);
				_activeVertical = ActiveVertical.Up;
			}
		}
	}

	private void ClearState()
	{
		if (_activeHorizontal == ActiveHorizontal.Left)
		{
			SendKey((int)_keyLeft, keyDown: false);
		}
		else if (_activeHorizontal == ActiveHorizontal.Right)
		{
			SendKey((int)_keyRight, keyDown: false);
		}
		if (_activeVertical == ActiveVertical.Up)
		{
			SendKey((int)_keyUp, keyDown: false);
		}
		else if (_activeVertical == ActiveVertical.Down)
		{
			SendKey((int)_keyDown, keyDown: false);
		}
		_physLeft = false;
		_physRight = false;
		_physUp = false;
		_physDown = false;
		_activeHorizontal = ActiveHorizontal.None;
		_activeVertical = ActiveVertical.None;
	}

	[SupportedOSPlatform("windows")]
	private static void SendKey(int vkCode, bool keyDown)
	{
		ushort num = (ushort)MapVirtualKey((uint)vkCode, 0u);
		INPUT iNPUT = new INPUT
		{
			type = 1u,
			u = new InputUnion
			{
				ki = new KEYBDINPUT
				{
					wVk = (ushort)vkCode,
					wScan = num,
					dwFlags = (keyDown ? 8u : 10u),
					time = 0u,
					dwExtraInfo = 1179865940u
				}
			}
		};
		if (SendInput(1u, new INPUT[1] { iNPUT }, Marshal.SizeOf<INPUT>()) == 0)
		{
			App.Logger.Warn($"SendInput failed (error {Marshal.GetLastWin32Error()}) – falling back to keybd_event.");
			byte bVk = (byte)vkCode;
			uint dwFlags = ((!keyDown) ? 2u : 0u);
			keybd_event(bVk, (byte)num, dwFlags, UIntPtr.Zero);
		}
	}

	public void Dispose()
	{
		if (_isDisposed)
		{
			return;
		}
		_isDisposed = true;
		if (OperatingSystem.IsWindows())
		{
			ClearState();
			if (_hookThreadId != 0)
			{
				PostThreadMessage(_hookThreadId, 18u, IntPtr.Zero, IntPtr.Zero);
				_hookThread?.Join(TimeSpan.FromSeconds(2L));
			}
			if (_hookHandle != IntPtr.Zero)
			{
				UnhookWindowsHookEx(_hookHandle);
				_hookHandle = IntPtr.Zero;
			}
			App.Logger.Info("Keyboard hook removed");
		}
		GC.SuppressFinalize(this);
	}

	[DllImport("user32.dll")]
	private static extern nint GetForegroundWindow();

	[DllImport("user32.dll", SetLastError = true)]
	private static extern uint GetWindowThreadProcessId(nint hWnd, out uint lpdwProcessId);

	[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
	private static extern nint SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, nint hMod, uint dwThreadId);

	[DllImport("user32.dll", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool UnhookWindowsHookEx(nint hhk);

	[DllImport("user32.dll")]
	private static extern nint CallNextHookEx(nint hhk, int nCode, nint wParam, nint lParam);

	[DllImport("user32.dll", SetLastError = true)]
	private static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

	[DllImport("user32.dll", CharSet = CharSet.Auto)]
	private static extern uint MapVirtualKey(uint uCode, uint uMapType);

	[DllImport("kernel32.dll")]
	private static extern uint GetCurrentThreadId();

	[DllImport("user32.dll", CharSet = CharSet.Auto)]
	private static extern int GetMessage(out MSG lpMsg, nint hWnd, uint wMsgFilterMin, uint wMsgFilterMax);

	[DllImport("user32.dll", CharSet = CharSet.Auto)]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool TranslateMessage(ref MSG lpMsg);

	[DllImport("user32.dll", CharSet = CharSet.Auto)]
	private static extern nint DispatchMessage(ref MSG lpMsg);

	[DllImport("user32.dll", CharSet = CharSet.Auto)]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool PostThreadMessage(uint idThread, uint Msg, nint wParam, nint lParam);

	[DllImport("user32.dll")]
	private static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, nuint dwExtraInfo);
}
