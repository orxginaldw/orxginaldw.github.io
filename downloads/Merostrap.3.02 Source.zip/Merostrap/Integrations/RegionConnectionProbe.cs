using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;

namespace Merostrap.Integrations;

internal static class RegionConnectionProbe
{
	public static bool IsPublicAddress(string? value)
	{
		if (!IPAddress.TryParse(value, out IPAddress address) || address.AddressFamily != AddressFamily.InterNetwork)
		{
			return false;
		}
		byte[] addressBytes = address.GetAddressBytes();
		byte b = addressBytes[0];
		bool flag = ((b == 0 || b == 10 || b == 127) ? true : false);
		if (!flag && addressBytes[0] < 224 && (addressBytes[0] != 169 || addressBytes[1] != 254))
		{
			if (addressBytes[0] == 172)
			{
				byte b2 = addressBytes[1];
				if (b2 >= 16 && b2 <= 31)
				{
					goto IL_00a7;
				}
			}
			if (addressBytes[0] != 192 || addressBytes[1] != 168)
			{
				if (addressBytes[0] == 100)
				{
					byte b2 = addressBytes[1];
					return b2 < 64 || b2 > 127;
				}
				return true;
			}
		}
		goto IL_00a7;
		IL_00a7:
		return false;
	}

	public static async Task<long?> MeasureAsync(string address, CancellationToken token)
	{
		if (!IsPublicAddress(address))
		{
			return null;
		}
		List<long> samples = new List<long>();
		for (int i = 0; i < 3; i++)
		{
			token.ThrowIfCancellationRequested();
			using Ping ping = new Ping();
			try
			{
				PingReply pingReply = await ping.SendPingAsync(IPAddress.Parse(address), 900).WaitAsync(token);
				if (pingReply.Status == IPStatus.Success)
				{
					samples.Add(pingReply.RoundtripTime);
				}
			}
			catch (PingException)
			{
			}
		}
		return (samples.Count == 0) ? ((long?)null) : new long?(samples.Order().ElementAt(samples.Count / 2));
	}
}
