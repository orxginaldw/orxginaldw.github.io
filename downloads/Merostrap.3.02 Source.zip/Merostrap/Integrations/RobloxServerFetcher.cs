using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Merostrap.Enums.Messagebox;
using Merostrap.Integrations.AccountManager;
using Merostrap.Models;
using Merostrap.Models.APIs;
using Merostrap.Models.APIs.RoValra;
using Merostrap.Models.APIs.Roblox;
using Merostrap.Resources;
using Merostrap.UI;
using Merostrap.Utility;

namespace Merostrap.Integrations;

internal class RobloxServerFetcher : IDisposable
{
	internal class ServerSelectionResult
	{
		public string? ServerId { get; set; }

		public string? Region { get; set; }

		public int Rank { get; set; }

		public DateTime? FirstSeen { get; set; }

		public bool Found => !string.IsNullOrEmpty(ServerId);
	}

	private readonly HttpClient _client;

	private Dictionary<int, string>? _datacenterIdToRegion;

	private List<string>? _regionList;

	private List<DatacenterEntry>? _datacenterEntries;

	private IPInfoResponse? _ipinfoCache;

	private DateTime _ipinfoCachedAtUtc;

	private const string DatacenterUrl = "https://apis.rovalra.com/v1/datacenters/list";

	private const string RegionServersUrl = "https://apis.rovalra.com/v1/servers/region";

	private const string IpInfoUrl = "https://ipinfo.io/json";

	private static readonly TimeSpan IpInfoCacheDuration = TimeSpan.FromHours(6);

	private static readonly TimeSpan MatchmakingTimeout = TimeSpan.FromSeconds(20L);

	private bool _disposed;

	private static readonly char[] _regionSeparators = new char[1] { ',' };

	public RobloxServerFetcher()
		: this(new SocketsHttpHandler
		{
			PooledConnectionLifetime = TimeSpan.FromMinutes(5L),
			MaxConnectionsPerServer = 20
		})
	{
	}

	internal RobloxServerFetcher(HttpMessageHandler handler)
	{
		_client = new HttpClient(handler);
		_client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
	}

	private static string BuildRegionKey(string? city, string? country)
	{
		if (string.IsNullOrWhiteSpace(city) && string.IsNullOrWhiteSpace(country))
		{
			return "Unknown";
		}
		return (city + ", " + country).Trim().Trim(new char[2] { ',', ' ' });
	}

	public async Task<(List<string> regions, Dictionary<int, string> datacenterMap)?> GetDatacentersAsync(CancellationToken cancellationToken = default(CancellationToken))
	{
		if (_datacenterIdToRegion != null && _regionList != null)
		{
			return (_regionList, _datacenterIdToRegion);
		}
		try
		{
			cancellationToken.ThrowIfCancellationRequested();
			List<DatacenterEntry> list = JsonSerializer.Deserialize<List<DatacenterEntry>>(await _client.GetStringAsync(new Uri("https://apis.rovalra.com/v1/datacenters/list"), cancellationToken));
			if (list == null)
			{
				return null;
			}
			Dictionary<int, string> dictionary = new Dictionary<int, string>();
			HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
			foreach (DatacenterEntry item in list)
			{
				string text = BuildRegionKey(item.Location?.City, item.Location?.Country);
				hashSet.Add(text);
				foreach (int dataCenterId in item.DataCenterIds)
				{
					dictionary[dataCenterId] = text;
				}
			}
			_regionList = hashSet.OrderBy((string r) => r, StringComparer.OrdinalIgnoreCase).ToList();
			_datacenterIdToRegion = dictionary;
			_datacenterEntries = list;
			return (_regionList, _datacenterIdToRegion);
		}
		catch (OperationCanceledException)
		{
			throw;
		}
		catch (Exception argument)
		{
			App.Logger.Error("Unhandled exception:", argument);
			return null;
		}
	}

	private static (string? city, string? country) ParseRegionString(string region)
	{
		if (string.IsNullOrEmpty(region))
		{
			return (city: null, country: null);
		}
		string[] array = region.Split(_regionSeparators, StringSplitOptions.RemoveEmptyEntries);
		if (array.Length == 2)
		{
			string item = array[0].Trim();
			string item2 = array[1].Trim();
			return (city: item, country: item2);
		}
		if (region.Length == 2 && region.All(char.IsLetter))
		{
			return (city: null, country: region.ToUpperInvariant());
		}
		return (city: null, country: null);
	}

	public async Task<(List<ServerInstance> Servers, int? NextCursor)> FetchServersByRegionAsync(long placeId, string region, int? cursor = null, int limit = 100, CancellationToken cancellationToken = default(CancellationToken))
	{
		List<ServerInstance> results = new List<ServerInstance>();
		try
		{
			(string? city, string? country) tuple = ParseRegionString(region);
			string item = tuple.city;
			string item2 = tuple.country;
			string text = $"place_id={placeId}&limit={limit}";
			if (!string.IsNullOrEmpty(item2))
			{
				text = text + "&country=" + item2;
			}
			if (!string.IsNullOrEmpty(item))
			{
				text = text + "&city=" + Uri.EscapeDataString(item);
			}
			if (string.IsNullOrEmpty(item2) && string.IsNullOrEmpty(item) && !string.IsNullOrEmpty(region))
			{
				text = text + "&region=" + Uri.EscapeDataString(region);
			}
			if (cursor.HasValue)
			{
				text += $"&cursor={cursor.Value}";
			}
			Uri uri = new UriBuilder("https://apis.rovalra.com/v1/servers/region")
			{
				Query = text
			}.Uri;
			using HttpResponseMessage response = await _client.GetAsync(uri, cancellationToken);
			if (!response.IsSuccessStatusCode)
			{
				return (Servers: results, NextCursor: null);
			}
			RoValraRegionResponse roValraRegionResponse = JsonSerializer.Deserialize<RoValraRegionResponse>(await response.Content.ReadAsStringAsync(cancellationToken));
			if (roValraRegionResponse?.Servers == null)
			{
				return (Servers: results, NextCursor: null);
			}
			foreach (RoValraRegionServer server in roValraRegionResponse.Servers)
			{
				string region2 = ResolveRegionDisplay(server.DatacenterId, server.City, server.RegionCode, server.Country);
				ServerInstance item3 = new ServerInstance
				{
					Id = server.ServerId,
					Region = region2,
					ProbeAddress = server.IpAddress,
					DataCenterId = server.DatacenterId,
					FirstSeen = server.FirstSeen,
					Playing = 0,
					MaxPlayers = 0,
					PlayerTokens = new List<string>()
				};
				results.Add(item3);
			}
			return (Servers: results, NextCursor: roValraRegionResponse.NextCursor);
		}
		catch (OperationCanceledException)
		{
			throw;
		}
		catch (Exception value)
		{
			App.Logger.Error($"Error fetching servers for region {region}: {value}");
			return (Servers: results, NextCursor: null);
		}
	}

	private string ResolveRegionDisplay(int datacenterId, string? city, string? regionCode, string? country)
	{
		if (_datacenterIdToRegion != null && _datacenterIdToRegion.TryGetValue(datacenterId, out string value))
		{
			return value;
		}
		if (!string.IsNullOrEmpty(city) && !string.IsNullOrEmpty(regionCode))
		{
			return city + ", " + regionCode;
		}
		if (!string.IsNullOrEmpty(country))
		{
			return country;
		}
		return "Unknown";
	}

	public async Task<List<ServerInstance>> FetchServersForRegionsAsync(long placeId, List<string> regions, CancellationToken cancellationToken = default(CancellationToken))
	{
		List<ServerInstance> allServers = new List<ServerInstance>();
		HashSet<string> seenIds = new HashSet<string>();
		foreach (string region in regions)
		{
			cancellationToken.ThrowIfCancellationRequested();
			foreach (ServerInstance item in (await FetchServersByRegionAsync(placeId, region, null, 100, cancellationToken)).Item1)
			{
				if (seenIds.Add(item.Id))
				{
					allServers.Add(item);
				}
			}
		}
		return allServers;
	}

	public async Task<FetchResult> FetchServerInstancesAsync(long placeId, string cursor = "", string? optionalCookie = null, int? maxServers = null, CancellationToken cancellationToken = default(CancellationToken))
	{
		string text = (string.IsNullOrWhiteSpace(optionalCookie) ? (await ResolveCookieAsync(cancellationToken)) : optionalCookie);
		string roblosecurity = text;
		if (string.IsNullOrWhiteSpace(roblosecurity))
		{
			return new FetchResult();
		}
		if (_datacenterIdToRegion == null)
		{
			await GetDatacentersAsync(cancellationToken);
		}
		Uri uri = new UriBuilder(UrlBuilder.BuildApiUrl("games", $"v2/games/{placeId}/servers/Public"))
		{
			Query = "sortOrder=Desc&excludeFullGames=true&limit=100&orderBy=BestLatency&cursor=" + cursor
		}.Uri;
		using HttpRequestMessage req = new HttpRequestMessage(HttpMethod.Get, uri);
		req.Headers.Add("Cookie", ".ROBLOSECURITY=" + roblosecurity);
		HttpResponseMessage httpResponseMessage = await _client.SendAsync(req, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
		if (!httpResponseMessage.IsSuccessStatusCode)
		{
			return new FetchResult();
		}
		using JsonDocument jsonDoc = JsonDocument.Parse(await httpResponseMessage.Content.ReadAsStringAsync(cancellationToken));
		if (!jsonDoc.RootElement.TryGetProperty("data", out var value))
		{
			return new FetchResult();
		}
		string nextCursor = (jsonDoc.RootElement.TryGetProperty("nextPageCursor", out var value2) ? (value2.GetString() ?? "") : "");
		ConcurrentBag<ServerInstance> instances = new ConcurrentBag<ServerInstance>();
		List<(string jobId, int playing, int maxPlayers, List<string> playerTokens)> serverInfos = new List<(string, int, int, List<string>)>();
		foreach (JsonElement item11 in value.EnumerateArray())
		{
			if (!maxServers.HasValue || serverInfos.Count < maxServers.Value)
			{
				string item = item11.GetProperty("id").GetString() ?? "";
				int @int = item11.GetProperty("playing").GetInt32();
				int int2 = item11.GetProperty("maxPlayers").GetInt32();
				List<string> item2 = (from x in item11.GetProperty("playerTokens").EnumerateArray()
					select x.GetString() ?? "" into s
					where !string.IsNullOrEmpty(s)
					select s).ToList();
				if (@int < int2)
				{
					serverInfos.Add((item, @int, int2, item2));
				}
				continue;
			}
			break;
		}
		List<Task<(string, int?)>> list = new List<Task<(string, int?)>>();
		foreach (var item12 in serverInfos)
		{
			string item3 = item12.jobId;
			cancellationToken.ThrowIfCancellationRequested();
			Task<(string, int?)> item4 = FetchServerRegionAsync(placeId, item3, roblosecurity, cancellationToken);
			list.Add(item4);
		}
		(string, int?)[] array = await Task.WhenAll(list);
		for (int num = 0; num < serverInfos.Count; num++)
		{
			(string jobId, int playing, int maxPlayers, List<string> playerTokens) tuple = serverInfos[num];
			string item5 = tuple.jobId;
			int item6 = tuple.playing;
			int item7 = tuple.maxPlayers;
			List<string> item8 = tuple.playerTokens;
			int? item9 = array[num].Item2;
			string region = ((item9.HasValue && _datacenterIdToRegion != null && _datacenterIdToRegion.TryGetValue(item9.Value, out string value3)) ? value3 : "Unknown");
			ServerInstance item10 = new ServerInstance
			{
				Id = item5,
				Playing = item6,
				MaxPlayers = item7,
				Region = region,
				DataCenterId = item9,
				FirstSeen = null,
				PlayerTokens = item8
			};
			instances.Add(item10);
		}
		return new FetchResult
		{
			Servers = instances.ToList(),
			NextCursor = nextCursor
		};
	}

	private async Task<(string jobId, int? dcId)> FetchServerRegionAsync(long placeId, string jobId, string roblosecurity, CancellationToken cancellationToken)
	{
		_ = 1;
		try
		{
			using JsonDocument jsonDocument = JsonDocument.Parse(await (await SendJoinRequestWithRetriesAsync(placeId, jobId, roblosecurity, cancellationToken)).Content.ReadAsStringAsync(cancellationToken));
			int? item = null;
			if (TryExtractDataCenterId(jsonDocument.RootElement, out var dcId))
			{
				item = dcId;
			}
			return (jobId: jobId, dcId: item);
		}
		catch
		{
			return (jobId: jobId, dcId: null);
		}
	}

	private async Task<HttpResponseMessage> SendJoinRequestWithRetriesAsync(long placeId, string jobId, string roblosecurity, CancellationToken cancellationToken = default(CancellationToken))
	{
		int attempt = 0;
		while (true)
		{
			attempt++;
			using HttpRequestMessage joinReq = new HttpRequestMessage(HttpMethod.Post, UrlBuilder.BuildApiUrl("gamejoin", "v1/join-game-instance"));
			joinReq.Headers.Add("Referer", $"https://roblox.com/games/{placeId}");
			joinReq.Headers.Add("Origin", "https://roblox.com");
			joinReq.Headers.Add("Cookie", ".ROBLOSECURITY=" + roblosecurity);
			joinReq.Content = new StringContent(JsonSerializer.Serialize(new
			{
				placeId = placeId,
				isTeleport = false,
				gameId = jobId,
				gameJoinAttemptId = jobId
			}), Encoding.UTF8, "application/json");
			try
			{
				HttpResponseMessage httpResponseMessage = await _client.SendAsync(joinReq, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
				if (httpResponseMessage.StatusCode == HttpStatusCode.Unauthorized || httpResponseMessage.StatusCode == HttpStatusCode.Forbidden)
				{
					return httpResponseMessage;
				}
				if ((httpResponseMessage.StatusCode == HttpStatusCode.TooManyRequests || httpResponseMessage.StatusCode >= HttpStatusCode.InternalServerError) && attempt < 3)
				{
					httpResponseMessage.Dispose();
					await Task.Delay(500 * attempt, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
					continue;
				}
				return httpResponseMessage;
			}
			catch (HttpRequestException) when (attempt < 3)
			{
				await Task.Delay(250 * attempt, cancellationToken).ConfigureAwait(continueOnCapturedContext: false);
				goto end_IL_0058;
			}
			end_IL_0058:;
		}
	}

	private static bool TryExtractDataCenterId(JsonElement elem, out int dcId)
	{
		dcId = 0;
		if (elem.ValueKind != JsonValueKind.Object)
		{
			return false;
		}
		if (elem.TryGetProperty("DataCenterId", out var value) && value.TryGetInt32(out dcId))
		{
			return true;
		}
		foreach (JsonProperty item in elem.EnumerateObject())
		{
			if (item.Value.ValueKind == JsonValueKind.Number && (item.Name.Contains("DataCenterId", StringComparison.Ordinal) || item.Name.Equals("dc", StringComparison.Ordinal)))
			{
				if (item.Value.TryGetInt32(out dcId))
				{
					return true;
				}
			}
			else if (item.Value.ValueKind == JsonValueKind.Object && TryExtractDataCenterId(item.Value, out dcId))
			{
				return true;
			}
		}
		return false;
	}

	public async Task<bool> ValidateCookieAsync(string roblosecurityCookie, CancellationToken cancellationToken = default(CancellationToken))
	{
		try
		{
			if (string.IsNullOrWhiteSpace(roblosecurityCookie))
			{
				return false;
			}
			using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, UrlBuilder.BuildApiUrl("users", "v1/users/authenticated"));
			request.Headers.Add("Cookie", ".ROBLOSECURITY=" + roblosecurityCookie);
			using HttpResponseMessage httpResponseMessage = await _client.SendAsync(request, cancellationToken);
			return httpResponseMessage.StatusCode == HttpStatusCode.OK;
		}
		catch (OperationCanceledException)
		{
			throw;
		}
		catch
		{
			return false;
		}
	}

	private static Task<string?> GetCookieFromAccountManagerAsync()
	{
		try
		{
			AccountManagerAccount accountManagerAccount = Merostrap.Integrations.AccountManager.AccountManager.Shared?.ActiveAccount;
			if (accountManagerAccount != null && !string.IsNullOrWhiteSpace(accountManagerAccount.SecurityToken))
			{
				return Task.FromResult(accountManagerAccount.SecurityToken);
			}
		}
		catch (Exception argument)
		{
			App.Logger.Error("Unhandled exception:", argument);
		}
		return Task.FromResult<string>(null);
	}

	private static Task<string?> GetCookieFromCookiesManagerAsync()
	{
		try
		{
			if (App.Cookies != null)
			{
				FieldInfo field = typeof(CookiesManager).GetField("AuthCookie", BindingFlags.Instance | BindingFlags.NonPublic);
				if (field != null)
				{
					return Task.FromResult(field.GetValue(App.Cookies) as string);
				}
			}
		}
		catch (Exception argument)
		{
			App.Logger.Error("Unhandled exception:", argument);
		}
		return Task.FromResult<string>(null);
	}

	public async Task<string?> ResolveCookieAsync(CancellationToken cancellationToken = default(CancellationToken))
	{
		string accountManagerCookie = await GetCookieFromAccountManagerAsync();
		bool flag = !string.IsNullOrWhiteSpace(accountManagerCookie);
		if (flag)
		{
			flag = await ValidateCookieAsync(accountManagerCookie, cancellationToken);
		}
		if (flag)
		{
			App.Logger.Info("Using valid cookie from Account Manager.");
			return accountManagerCookie;
		}
		string cookiesManagerCookie = await GetCookieFromCookiesManagerAsync();
		flag = !string.IsNullOrWhiteSpace(cookiesManagerCookie);
		if (flag)
		{
			flag = await ValidateCookieAsync(cookiesManagerCookie, cancellationToken);
		}
		if (flag)
		{
			App.Logger.Info("Using valid cookie from Cookies Manager.");
			return cookiesManagerCookie;
		}
		App.Logger.Warn("No valid .ROBLOSECURITY cookie could be resolved.");
		return null;
	}

	public async Task<bool> IsServerAliveAsync(long placeId, string jobId, string roblosecurity, CancellationToken cancellationToken)
	{
		_ = 1;
		try
		{
			using CancellationTokenSource cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
			cts.CancelAfter(TimeSpan.FromMilliseconds(1500L));
			using HttpResponseMessage response = await SendJoinRequestWithRetriesAsync(placeId, jobId, roblosecurity, cts.Token);
			if (response.StatusCode == HttpStatusCode.Unauthorized || response.StatusCode == HttpStatusCode.Forbidden)
			{
				return false;
			}
			if (response.StatusCode == HttpStatusCode.TooManyRequests)
			{
				return false;
			}
			if (!response.IsSuccessStatusCode)
			{
				return false;
			}
			string json;
			try
			{
				json = await response.Content.ReadAsStringAsync(cts.Token);
			}
			catch
			{
				return false;
			}
			using JsonDocument jsonDocument = JsonDocument.Parse(json);
			if (!jsonDocument.RootElement.TryGetProperty("status", out var value) || value.ValueKind != JsonValueKind.Number || !value.TryGetInt32(out var value2))
			{
				return false;
			}
			return value2 == 2;
		}
		catch (OperationCanceledException)
		{
			return false;
		}
		catch
		{
			return false;
		}
	}

	private static double Deg2Rad(double deg)
	{
		return deg * (Math.PI / 180.0);
	}

	private static double GetDistance(double lat1, double lon1, double lat2, double lon2)
	{
		double num = Deg2Rad(lat2 - lat1);
		double num2 = Deg2Rad(lon2 - lon1);
		double num3 = Math.Sin(num / 2.0) * Math.Sin(num / 2.0) + Math.Cos(Deg2Rad(lat1)) * Math.Cos(Deg2Rad(lat2)) * Math.Sin(num2 / 2.0) * Math.Sin(num2 / 2.0);
		double num4 = 2.0 * Math.Atan2(Math.Sqrt(num3), Math.Sqrt(1.0 - num3));
		return 6371.0 * num4;
	}

	private async Task<IPInfoResponse?> GetIpInfoCachedAsync(CancellationToken cancellationToken)
	{
		if (_ipinfoCache != null && DateTime.UtcNow - _ipinfoCachedAtUtc < IpInfoCacheDuration)
		{
			return _ipinfoCache;
		}
		try
		{
			_ipinfoCache = JsonSerializer.Deserialize<IPInfoResponse>(await _client.GetStringAsync(new Uri("https://ipinfo.io/json"), cancellationToken));
			_ipinfoCachedAtUtc = DateTime.UtcNow;
			return _ipinfoCache;
		}
		catch (OperationCanceledException)
		{
			throw;
		}
		catch (Exception argument)
		{
			App.Logger.Error("Failed to resolve IP info:", argument);
			return _ipinfoCache;
		}
	}

	public async Task<List<string>> GetClosestRegionsForAutoModeAsync(CancellationToken cancellationToken = default(CancellationToken))
	{
		_ = 1;
		try
		{
			if (!(await GetDatacentersAsync(cancellationToken)).HasValue || _datacenterEntries == null || _datacenterEntries.Count == 0)
			{
				return new List<string>();
			}
			IPInfoResponse iPInfoResponse = await GetIpInfoCachedAsync(cancellationToken);
			if (string.IsNullOrEmpty(iPInfoResponse?.Loc))
			{
				return new List<string>();
			}
			string[] array = iPInfoResponse.Loc.Split(',');
			if (array.Length < 2)
			{
				return new List<string>();
			}
			if (!double.TryParse(array[0], NumberStyles.Float, CultureInfo.InvariantCulture, out var result) || !double.TryParse(array[1], NumberStyles.Float, CultureInfo.InvariantCulture, out var result2))
			{
				return new List<string>();
			}
			Dictionary<string, double> dictionary = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
			foreach (DatacenterEntry datacenterEntry in _datacenterEntries)
			{
				if (datacenterEntry.Location != null && datacenterEntry.Location.LatLong != null && datacenterEntry.Location.LatLong.Length >= 2 && double.TryParse(datacenterEntry.Location.LatLong[0], NumberStyles.Float, CultureInfo.InvariantCulture, out var result3) && double.TryParse(datacenterEntry.Location.LatLong[1], NumberStyles.Float, CultureInfo.InvariantCulture, out var result4))
				{
					double distance = GetDistance(result, result2, result3, result4);
					string text = BuildRegionKey(datacenterEntry.Location.City, datacenterEntry.Location.Country);
					if (!string.IsNullOrEmpty(text) && !text.Equals("Unknown", StringComparison.OrdinalIgnoreCase) && (!dictionary.TryGetValue(text, out var value) || distance < value))
					{
						dictionary[text] = distance;
					}
				}
			}
			List<string> list = (from kvp in dictionary
				orderby kvp.Value
				select kvp.Key).ToList();
			App.Logger.Info($"Sorted {list.Count} regions by distance: {string.Join(", ", list.Take(5))}...");
			return list;
		}
		catch (OperationCanceledException)
		{
			throw;
		}
		catch (Exception argument)
		{
			App.Logger.Error("Unhandled exception:", argument);
			return new List<string>();
		}
	}

	public async Task<ServerSelectionResult> FindBestServerInRegionAsync(long placeId, List<string> regions, CancellationToken cancellationToken = default(CancellationToken))
	{
		using CancellationTokenSource searchDeadline = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
		searchDeadline.CancelAfter(MatchmakingTimeout);
		cancellationToken = searchDeadline.Token;
		DateTime startedAtUtc = DateTime.UtcNow;
		try
		{
			App.Logger.Info($"Searching for alive server across {regions.Count} regions (timeout {MatchmakingTimeout.TotalSeconds}s)");
			string cookie = await ResolveCookieAsync(cancellationToken);
			if (string.IsNullOrEmpty(cookie))
			{
				App.Logger.Warn("No valid cookie for server liveliness checks.");
			}
			Dictionary<string, int> regionRank = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
			for (int i = 0; i < regions.Count; i++)
			{
				regionRank[regions[i]] = i + 1;
			}
			int probesDone = 0;
			foreach (string region in regions)
			{
				cancellationToken.ThrowIfCancellationRequested();
				if (DateTime.UtcNow - startedAtUtc >= MatchmakingTimeout || probesDone >= 8)
				{
					App.Logger.Warn($"Matchmaking timeout reached after {probesDone} probe(s).");
					return new ServerSelectionResult();
				}
				List<ServerInstance> item = (await FetchServersByRegionAsync(placeId, region, null, 100, cancellationToken)).Item1;
				if (item.Count == 0)
				{
					continue;
				}
				List<ServerInstance> list = item.OrderBy((ServerInstance s) => s.FirstSeen).ToList();
				if (string.IsNullOrEmpty(cookie))
				{
					ServerInstance serverInstance = list[0];
					int value;
					return new ServerSelectionResult
					{
						ServerId = serverInstance.Id,
						Region = serverInstance.Region,
						Rank = (regionRank.TryGetValue(serverInstance.Region, out value) ? value : int.MaxValue),
						FirstSeen = serverInstance.FirstSeen
					};
				}
				foreach (ServerInstance server in list)
				{
					cancellationToken.ThrowIfCancellationRequested();
					if (DateTime.UtcNow - startedAtUtc >= MatchmakingTimeout || probesDone >= 8)
					{
						App.Logger.Warn($"Matchmaking timeout reached after {probesDone} probe(s).");
						return new ServerSelectionResult();
					}
					probesDone++;
					if (await IsServerAliveAsync(placeId, server.Id, cookie, cancellationToken))
					{
						App.Logger.Info($"Found alive server after {probesDone} probe(s) in {(DateTime.UtcNow - startedAtUtc).TotalSeconds:F1}s.");
						int value2;
						return new ServerSelectionResult
						{
							ServerId = server.Id,
							Region = server.Region,
							Rank = (regionRank.TryGetValue(server.Region, out value2) ? value2 : int.MaxValue),
							FirstSeen = server.FirstSeen
						};
					}
				}
			}
			App.Logger.Warn($"No alive server found after {probesDone} probe(s) across {regions.Count} regions.");
			return new ServerSelectionResult();
		}
		catch (OperationCanceledException)
		{
			throw;
		}
		catch (Exception argument)
		{
			App.Logger.Error("Unhandled exception:", argument);
			return new ServerSelectionResult();
		}
	}

	public async Task<ServerSelectionResult> FindBestServerInSelectedRegionAsync(long placeId, string selectedRegion, CancellationToken cancellationToken = default(CancellationToken))
	{
		using CancellationTokenSource searchDeadline = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
		searchDeadline.CancelAfter(MatchmakingTimeout);
		cancellationToken = searchDeadline.Token;
		DateTime startedAtUtc = DateTime.UtcNow;
		try
		{
			if (string.IsNullOrEmpty(selectedRegion))
			{
				return new ServerSelectionResult();
			}
			App.Logger.Info($"Searching for alive server in {selectedRegion} (timeout {MatchmakingTimeout.TotalSeconds}s)");
			string cookie = await ResolveCookieAsync(cancellationToken);
			if (string.IsNullOrEmpty(cookie))
			{
				App.Logger.Warn("No valid cookie for server liveliness checks.");
			}
			List<ServerInstance> item = (await FetchServersByRegionAsync(placeId, selectedRegion, null, 100, cancellationToken)).Item1;
			if (item.Count == 0)
			{
				return new ServerSelectionResult();
			}
			List<ServerInstance> list = item.OrderBy((ServerInstance s) => s.FirstSeen).ToList();
			if (string.IsNullOrEmpty(cookie))
			{
				ServerInstance serverInstance = list[0];
				return new ServerSelectionResult
				{
					ServerId = serverInstance.Id,
					Region = serverInstance.Region,
					Rank = 1,
					FirstSeen = serverInstance.FirstSeen
				};
			}
			int probesDone = 0;
			foreach (ServerInstance server in list)
			{
				cancellationToken.ThrowIfCancellationRequested();
				if (DateTime.UtcNow - startedAtUtc >= MatchmakingTimeout || probesDone >= 8)
				{
					App.Logger.Warn($"Matchmaking timeout reached in {selectedRegion} after {probesDone} probe(s).");
					return new ServerSelectionResult();
				}
				probesDone++;
				if (await IsServerAliveAsync(placeId, server.Id, cookie, cancellationToken))
				{
					App.Logger.Info($"Found alive server in {selectedRegion} after {probesDone} probe(s) in {(DateTime.UtcNow - startedAtUtc).TotalSeconds:F1}s.");
					return new ServerSelectionResult
					{
						ServerId = server.Id,
						Region = server.Region,
						Rank = 1,
						FirstSeen = server.FirstSeen
					};
				}
			}
			App.Logger.Warn($"No alive server found in {selectedRegion} after {probesDone} probe(s).");
			return new ServerSelectionResult();
		}
		catch (OperationCanceledException)
		{
			throw;
		}
		catch (Exception argument)
		{
			App.Logger.Error("Unhandled exception:", argument);
			return new ServerSelectionResult();
		}
	}

	public async Task<bool> JoinBestServerAsync(long placeId, bool showConfirmation = true, CancellationToken cancellationToken = default(CancellationToken))
	{
		_ = 6;
		try
		{
			string text = (PreferredRegionRouting.HasPreference ? PreferredRegionRouting.Region : (App.Settings.Prop.SelectedRegion ?? ""));
			if (!string.IsNullOrEmpty(text) && !text.Equals(Strings.Common_Auto, StringComparison.OrdinalIgnoreCase))
			{
				ServerSelectionResult result = await FindBestServerInSelectedRegionAsync(placeId, text, cancellationToken);
				if (result.Found)
				{
					if (showConfirmation && await Frontend.ShowMessageBox("Found server in " + result.Region + ".\nDo you want to join?", MessageBoxImage.Question, MessageBoxButton.YesNo) != MessageBoxResult.Yes)
					{
						return false;
					}
					string fileName = $"roblox://experiences/start?placeId={placeId}&gameInstanceId={result.ServerId}";
					Process.Start(new ProcessStartInfo
					{
						FileName = fileName,
						UseShellExecute = true
					});
					return true;
				}
			}
			List<string> list = await GetClosestRegionsForAutoModeAsync(cancellationToken);
			if (list.Count == 0)
			{
				await Frontend.ShowMessageBox("Could not determine your location for Auto mode. Please try again later.", MessageBoxImage.Warning);
				return false;
			}
			ServerSelectionResult autoResult = await FindBestServerInRegionAsync(placeId, list, cancellationToken);
			if (!autoResult.Found)
			{
				await Frontend.ShowMessageBox($"Could not find a suitable server within {MatchmakingTimeout.TotalSeconds} seconds.");
				return false;
			}
			if (showConfirmation && await Frontend.ShowMessageBox("Found server in " + autoResult.Region + ".\nDo you want to join?", MessageBoxImage.Question, MessageBoxButton.YesNo) != MessageBoxResult.Yes)
			{
				return false;
			}
			string fileName2 = $"roblox://experiences/start?placeId={placeId}&gameInstanceId={autoResult.ServerId}";
			Process.Start(new ProcessStartInfo
			{
				FileName = fileName2,
				UseShellExecute = true
			});
			return true;
		}
		catch (Exception argument)
		{
			App.Logger.Error("Unhandled exception:", argument);
			return false;
		}
	}

	public void Dispose()
	{
		Dispose(disposing: true);
		GC.SuppressFinalize(this);
	}

	protected virtual void Dispose(bool disposing)
	{
		if (!_disposed)
		{
			if (disposing)
			{
				_client?.Dispose();
			}
			_disposed = true;
		}
	}
}
