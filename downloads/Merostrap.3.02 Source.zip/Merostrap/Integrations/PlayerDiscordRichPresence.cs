using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using DiscordRPC;
using DiscordRPC.Message;
using Merostrap.Enums;
using Merostrap.Models.APIs;
using Merostrap.Models.APIs.Roblox;
using Merostrap.Models.BloxstrapRPC;
using Merostrap.Models.Entities;
using Merostrap.Utility;

namespace Merostrap.Integrations;

internal class PlayerDiscordRichPresence : IDisposable
{
	private readonly DiscordRpcClient? _rpcClient;

	private readonly ActivityWatcher _activityWatcher;

	private readonly Queue<Message> _messageQueue = new Queue<Message>();

	private DiscordRPC.RichPresence? _currentPresence;

	private DiscordRPC.RichPresence? _originalPresence;

	private readonly FixedSizeList<ThumbnailCacheEntry> _thumbnailCache = new FixedSizeList<ThumbnailCacheEntry>(20);

	private ulong? _smallImgBeingFetched;

	private ulong? _largeImgBeingFetched;

	private CancellationTokenSource? _fetchThumbnailsToken;

	private bool _visible = true;

	private bool _disposed;

	public PlayerDiscordRichPresence(ActivityWatcher activityWatcher)
	{
		_rpcClient = new DiscordRpcClient("363445589247131668", -1, null, autoEvents: true, DiscordIpcPipeClient.Create());
		_activityWatcher = activityWatcher;
		_activityWatcher.OnGameJoin += (object? _, EventArgs _) =>
		{
			Task.Run(() => SetCurrentGame());
		};
		_activityWatcher.OnGameLeave += (object? _, EventArgs _) =>
		{
			Task.Run(() => SetCurrentGame());
		};
		_activityWatcher.OnRPCMessage += (object? _, Message message) =>
		{
			ProcessRPCMessage(message);
		};
		_rpcClient.OnReady += (object _, ReadyMessage e) =>
		{
			App.Logger.Info($"Received ready from user {e.User} ({e.User.ID})");
		};
		_rpcClient.OnPresenceUpdate += (object _, PresenceMessage e) =>
		{
			App.Logger.Info("Presence updated");
		};
		_rpcClient.OnError += (object _, ErrorMessage e) =>
		{
			App.Logger.Error("An RPC error occurred - " + e.Message);
		};
		_rpcClient.OnConnectionEstablished += (object _, ConnectionEstablishedMessage e) =>
		{
			App.Logger.Info("Established connection with Discord RPC");
		};
		_rpcClient.OnClose += (object _, CloseMessage e) =>
		{
			App.Logger.Error($"Lost connection to Discord RPC - {e.Reason} ({e.Code})");
		};
		try
		{
			_rpcClient.Initialize();
		}
		catch (Exception ex)
		{
			App.Logger.Error("Failed to init RPC: " + ex.Message);
		}
	}

	public void ProcessRPCMessage(Message message, bool implicitUpdate = true)
	{
		if (_disposed || (message.Command != "SetRichPresence" && message.Command != "SetLaunchData"))
		{
			return;
		}
		if (_currentPresence == null || _originalPresence == null)
		{
			App.Logger.Info("Presence is not set, enqueuing message");
			_messageQueue.Enqueue(message);
			return;
		}
		if (message.Command == "SetLaunchData")
		{
			_currentPresence.Buttons = GetButtons();
		}
		else if (message.Command == "SetRichPresence")
		{
			ProcessSetRichPresence(message, implicitUpdate);
		}
		if (implicitUpdate)
		{
			UpdatePresence();
		}
	}

	private void AddToThumbnailCache(ulong id, string? url)
	{
		if (url != null)
		{
			_thumbnailCache.Add(new ThumbnailCacheEntry
			{
				Id = id,
				Url = url
			});
		}
	}

	private async Task UpdatePresenceIconsAsync(ulong? smallImg, ulong? largeImg, bool implicitUpdate, CancellationToken token)
	{
		if (_disposed)
		{
			return;
		}
		if (smallImg.HasValue && largeImg.HasValue)
		{
			string[] array = await Thumbnails.GetThumbnailUrlsAsync(new List<ThumbnailRequest>(2)
			{
				new ThumbnailRequest
				{
					TargetId = smallImg.Value,
					Type = ThumbnailType.Asset,
					Size = ThumbnailSize.Cyberpunk,
					IsCircular = false
				},
				new ThumbnailRequest
				{
					TargetId = largeImg.Value,
					Type = ThumbnailType.Asset,
					Size = ThumbnailSize.Cyberpunk,
					IsCircular = false
				}
			}, token);
			string text = array[0];
			string text2 = array[1];
			AddToThumbnailCache(smallImg.Value, text);
			AddToThumbnailCache(largeImg.Value, text2);
			if (_currentPresence != null)
			{
				_currentPresence.Assets.SmallImageKey = text ?? string.Empty;
				_currentPresence.Assets.LargeImageKey = text2 ?? string.Empty;
			}
		}
		else if (smallImg.HasValue)
		{
			string text3 = await Thumbnails.GetThumbnailUrlAsync(new ThumbnailRequest
			{
				TargetId = smallImg.Value,
				Type = ThumbnailType.Asset,
				Size = ThumbnailSize.Cyberpunk,
				IsCircular = false
			}, token);
			AddToThumbnailCache(smallImg.Value, text3);
			DiscordRPC.RichPresence? currentPresence = _currentPresence;
			if (currentPresence != null)
			{
				currentPresence.Assets.SmallImageKey = text3 ?? string.Empty;
			}
		}
		else if (largeImg.HasValue)
		{
			string text4 = await Thumbnails.GetThumbnailUrlAsync(new ThumbnailRequest
			{
				TargetId = largeImg.Value,
				Type = ThumbnailType.Asset,
				Size = ThumbnailSize.Cyberpunk,
				IsCircular = false
			}, token);
			AddToThumbnailCache(largeImg.Value, text4);
			DiscordRPC.RichPresence? currentPresence2 = _currentPresence;
			if (currentPresence2 != null)
			{
				currentPresence2.Assets.LargeImageKey = text4 ?? string.Empty;
			}
		}
		_smallImgBeingFetched = null;
		_largeImgBeingFetched = null;
		if (implicitUpdate)
		{
			UpdatePresence();
		}
	}

	private void ProcessSetRichPresence(Message message, bool implicitUpdate)
	{
		if (_disposed)
		{
			return;
		}
		_fetchThumbnailsToken?.Cancel();
		_fetchThumbnailsToken = null;
		Merostrap.Models.BloxstrapRPC.RichPresence presenceData;
		try
		{
			presenceData = message.Data.Deserialize<Merostrap.Models.BloxstrapRPC.RichPresence>();
		}
		catch (Exception)
		{
			App.Logger.Error("Failed to parse message! (JSON deserialization threw an exception)");
			return;
		}
		if (presenceData == null)
		{
			App.Logger.Error("Failed to parse message! (JSON deserialization returned null)");
			return;
		}
		if (presenceData.Details != null)
		{
			if (presenceData.Details.Length > 128)
			{
				App.Logger.Error("Details cannot be longer than 128 characters");
			}
			else if (presenceData.Details == "<reset>")
			{
				_currentPresence.Details = _originalPresence.Details;
			}
			else
			{
				_currentPresence.Details = presenceData.Details;
			}
		}
		if (presenceData.State != null)
		{
			if (presenceData.State.Length > 128)
			{
				App.Logger.Error("State cannot be longer than 128 characters");
			}
			else if (presenceData.State == "<reset>")
			{
				_currentPresence.State = _originalPresence.State;
			}
			else
			{
				_currentPresence.State = presenceData.State;
			}
		}
		if (presenceData.TimestampStart == 0)
		{
			_currentPresence.Timestamps.Start = null;
		}
		else if (presenceData.TimestampStart.HasValue)
		{
			_currentPresence.Timestamps.StartUnixMilliseconds = presenceData.TimestampStart * 1000;
		}
		if (presenceData.TimestampEnd == 0)
		{
			_currentPresence.Timestamps.End = null;
		}
		else if (presenceData.TimestampEnd.HasValue)
		{
			_currentPresence.Timestamps.EndUnixMilliseconds = presenceData.TimestampEnd * 1000;
		}
		ulong? smallImgBeingFetched = null;
		ulong? largeImgBeingFetched = null;
		if (presenceData.SmallImage != null && !App.Settings.Prop.ShowAccountOnRichPresence)
		{
			if (presenceData.SmallImage.Clear)
			{
				_currentPresence.Assets.SmallImageKey = _originalPresence.Assets.SmallImageKey;
				_currentPresence.Assets.SmallImageText = _originalPresence.Assets.SmallImageText;
				_smallImgBeingFetched = null;
			}
			else if (presenceData.SmallImage.Reset)
			{
				_currentPresence.Assets.SmallImageText = _originalPresence.Assets.SmallImageText;
				_currentPresence.Assets.SmallImageKey = _originalPresence.Assets.SmallImageKey;
				_smallImgBeingFetched = null;
			}
			else
			{
				if (presenceData.SmallImage.AssetId.HasValue)
				{
					ThumbnailCacheEntry thumbnailCacheEntry = _thumbnailCache.FirstOrDefault((ThumbnailCacheEntry x) => x.Id == presenceData.SmallImage.AssetId);
					if (thumbnailCacheEntry == null)
					{
						smallImgBeingFetched = presenceData.SmallImage.AssetId;
					}
					else
					{
						_currentPresence.Assets.SmallImageKey = thumbnailCacheEntry.Url ?? string.Empty;
						_smallImgBeingFetched = null;
					}
				}
				if (presenceData.SmallImage.HoverText != null)
				{
					_currentPresence.Assets.SmallImageText = presenceData.SmallImage.HoverText;
				}
			}
		}
		if (presenceData.LargeImage != null)
		{
			if (presenceData.LargeImage.Clear)
			{
				_currentPresence.Assets.LargeImageKey = _originalPresence.Assets.LargeImageKey;
				_currentPresence.Assets.LargeImageText = _originalPresence.Assets.LargeImageText;
				_largeImgBeingFetched = null;
			}
			else if (presenceData.LargeImage.Reset)
			{
				_currentPresence.Assets.LargeImageText = _originalPresence.Assets.LargeImageText;
				_currentPresence.Assets.LargeImageKey = _originalPresence.Assets.LargeImageKey;
				_largeImgBeingFetched = null;
			}
			else
			{
				if (presenceData.LargeImage.AssetId.HasValue)
				{
					ThumbnailCacheEntry thumbnailCacheEntry2 = _thumbnailCache.FirstOrDefault((ThumbnailCacheEntry x) => x.Id == presenceData.LargeImage.AssetId);
					if (thumbnailCacheEntry2 == null)
					{
						largeImgBeingFetched = presenceData.LargeImage.AssetId;
					}
					else
					{
						_currentPresence.Assets.LargeImageKey = thumbnailCacheEntry2.Url ?? string.Empty;
						_largeImgBeingFetched = null;
					}
				}
				if (presenceData.LargeImage.HoverText != null)
				{
					_currentPresence.Assets.LargeImageText = presenceData.LargeImage.HoverText;
				}
			}
		}
		_smallImgBeingFetched = smallImgBeingFetched;
		_largeImgBeingFetched = largeImgBeingFetched;
		if (_smallImgBeingFetched.HasValue || _largeImgBeingFetched.HasValue)
		{
			_fetchThumbnailsToken = new CancellationTokenSource();
			Task.Run(() => UpdatePresenceIconsAsync(_smallImgBeingFetched, _largeImgBeingFetched, implicitUpdate, _fetchThumbnailsToken.Token));
		}
	}

	public void SetVisibility(bool visible)
	{
		if (!_disposed)
		{
			App.Logger.Info($"Setting presence visibility ({visible})");
			_visible = visible;
			if (_visible)
			{
				UpdatePresence();
			}
			else
			{
				_rpcClient?.ClearPresence();
			}
		}
	}

	public async Task<bool> SetCurrentGame()
	{
		if (_disposed)
		{
			return false;
		}
		if (!_activityWatcher.InGame)
		{
			App.Logger.Info("Not in game, clearing presence");
			_currentPresence = (_originalPresence = null);
			_messageQueue.Clear();
			UpdatePresence();
			return true;
		}
		ActivityData activity = _activityWatcher.Data;
		if (activity == null)
		{
			App.Logger.Warn("Activity data is null; skipping presence update.");
			return false;
		}
		App.Logger.Info($"Setting presence for Place ID {activity.PlaceId}");
		DateTime timeStarted = activity.RootActivity?.TimeJoined ?? activity.TimeJoined;
		if (activity.UniverseDetails == null)
		{
			try
			{
				await UniverseDetails.FetchSingle(activity.UniverseId);
				activity.UniverseDetails = UniverseDetails.LoadFromCache(activity.UniverseId);
			}
			catch (Exception value)
			{
				App.Logger.Error($"Failed to fetch universe details: {value}");
				return false;
			}
		}
		UniverseDetails universeDetails = activity.UniverseDetails;
		if (universeDetails == null)
		{
			App.Logger.Error($"Universe details not available for UniverseId {activity.UniverseId}");
			return false;
		}
		if (!_activityWatcher.InGame || activity.PlaceId != _activityWatcher.Data.PlaceId)
		{
			return false;
		}
		string icon = universeDetails.Thumbnail.ImageUrl ?? "roblox";
		string smallImageKey = "roblox";
		string smallImageText = "Roblox";
		if (App.Settings.Prop.ShowAccountOnRichPresence)
		{
			UserDetails userDetails = await UserDetails.Fetch(activity.UserId);
			smallImageKey = userDetails.Thumbnail.ImageUrl ?? "roblox";
			smallImageText = $"Playing on {userDetails.Data.DisplayName} (@{userDetails.Data.Name})";
		}
		string state = activity.ServerType switch
		{
			ServerType.Private => "In a Private server", 
			ServerType.Reserved => "In a Reserved server", 
			_ => "by " + universeDetails.Data.Creator.Name + (universeDetails.Data.Creator.HasVerifiedBadge ? " ☑\ufe0f" : ""), 
		};
		string text = universeDetails.Data.Name;
		if (text.Length < 2)
		{
			text += "⠀⠀⠀";
		}
		_currentPresence = new DiscordRPC.RichPresence
		{
			Details = text,
			StatusDisplay = (App.Settings.Prop.EnableCustomStatusDisplay ? StatusDisplayType.Details : StatusDisplayType.Name),
			State = state,
			Timestamps = new Timestamps
			{
				Start = timeStarted.ToUniversalTime()
			},
			Buttons = GetButtons(),
			Assets = new Assets
			{
				LargeImageKey = icon,
				LargeImageText = universeDetails.Data.Name,
				SmallImageKey = smallImageKey,
				SmallImageText = smallImageText
			}
		};
		_originalPresence = _currentPresence.Clone();
		if (_messageQueue.TryDequeue(out Message result))
		{
			App.Logger.Info("Processing queued messages");
			ProcessRPCMessage(result, implicitUpdate: false);
		}
		UpdatePresence();
		return true;
	}

	public Button[] GetButtons()
	{
		List<Button> list = new List<Button>();
		ActivityData data = _activityWatcher.Data;
		if (!App.Settings.Prop.HideRPCButtons)
		{
			bool flag = false;
			if (data.ServerType == ServerType.Public)
			{
				flag = true;
			}
			else if (data.ServerType == ServerType.Reserved && !string.IsNullOrEmpty(data.RPCLaunchData))
			{
				flag = true;
			}
			if (flag)
			{
				list.Add(new Button
				{
					Label = "Join server",
					Url = data.GetInviteDeeplink()
				});
			}
		}
		list.Add(new Button
		{
			Label = "See game page",
			Url = $"https://www.roblox.com/games/{data.PlaceId}"
		});
		return list.ToArray();
	}

	public void UpdatePresence()
	{
		if (_disposed || _rpcClient == null || !_rpcClient.IsInitialized)
		{
			return;
		}
		try
		{
			if (_visible)
			{
				if (_currentPresence != null)
				{
					DiscordRPC.RichPresence currentPresence = _currentPresence;
					if (currentPresence.Assets == null)
					{
						Assets assets = (currentPresence.Assets = new Assets());
					}
					App.Logger.Info("Updating presence");
					_rpcClient.SetPresence(_currentPresence);
				}
				else
				{
					App.Logger.Info("Clearing presence (no current presence)");
					_rpcClient.ClearPresence();
				}
			}
			else
			{
				_rpcClient.ClearPresence();
			}
		}
		catch (IOException ex) when (ex.InnerException is SocketException)
		{
			App.Logger.Error("Socket interrupted (Operation Canceled).");
		}
		catch (Exception value)
		{
			App.Logger.Error(value);
		}
	}

	public void Dispose()
	{
		if (_disposed)
		{
			return;
		}
		_disposed = true;
		App.Logger.Info("Cleaning up Discord RPC and Presence");
		if (_rpcClient != null)
		{
			try
			{
				_fetchThumbnailsToken?.Cancel();
				_fetchThumbnailsToken?.Dispose();
				if (_rpcClient.IsInitialized)
				{
					try
					{
						_rpcClient.ClearPresence();
					}
					catch (IOException)
					{
					}
				}
				_rpcClient.Dispose();
			}
			catch (IOException ex2) when (ex2.InnerException is SocketException)
			{
			}
			catch (Exception value)
			{
				App.Logger.Error(value);
			}
		}
		GC.SuppressFinalize(this);
	}
}
