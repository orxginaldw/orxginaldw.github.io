using System;
using System.Diagnostics;
using System.IO;
using System.Net.Sockets;
using DiscordRPC;
using DiscordRPC.Message;

namespace Merostrap.Integrations;

internal class MerostrapRichPresence : IDisposable
{
	private readonly DiscordRpcClient? _rpcClient;

	private readonly Timestamps _startTimestamps;

	private readonly Stopwatch _uptimeStopwatch;

	private bool _disposed;

	private string _currentPage = "Idle";

	private string? _currentDialog;

	private string _lastState = "";

	public bool IsConnected => _rpcClient?.IsInitialized ?? false;

	public MerostrapRichPresence()
	{
		_rpcClient = new DiscordRpcClient("", -1, null, autoEvents: true, DiscordIpcPipeClient.Create())
		{
			SkipIdenticalPresence = true,
			ShutdownOnly = true
		};
		_rpcClient.OnReady += OnReady;
		_startTimestamps = new Timestamps
		{
			Start = DateTime.UtcNow
		};
		_uptimeStopwatch = Stopwatch.StartNew();
		try
		{
			_rpcClient.Initialize();
		}
		catch (Exception ex)
		{
			App.Logger.Error("Failed to init RPC: " + ex.Message);
		}
	}

	private void OnReady(object sender, ReadyMessage args)
	{
		if (!_disposed)
		{
			App.Logger.Info("Connected as " + args.User.Username);
			if (!_disposed)
			{
				UpdatePresence();
			}
		}
	}

	public void SetPage(string pageName)
	{
		if (!_disposed)
		{
			_currentPage = pageName;
			_currentDialog = null;
			UpdatePresence();
		}
	}

	public void SetDialog(string dialogName)
	{
		if (!_disposed)
		{
			_currentDialog = dialogName;
			UpdatePresence();
		}
	}

	public void ClearDialog()
	{
		if (!_disposed)
		{
			_currentDialog = null;
			UpdatePresence();
		}
	}

	public void UpdatePresence()
	{
		if (_disposed || _rpcClient == null || !_rpcClient.IsInitialized)
		{
			return;
		}
		string text = ((!string.IsNullOrEmpty(_currentDialog)) ? ("Page: " + _currentPage + " | Dialog: " + _currentDialog) : ("Page: " + _currentPage));
		if (text == _lastState)
		{
			return;
		}
		_lastState = text;
		RichPresence presence = new RichPresence
		{
			Details = "Customize Roblox to your liking!",
			State = text,
			Timestamps = _startTimestamps,
			Buttons = Array.Empty<Button>()
		};
		try
		{
			_rpcClient.SetPresence(presence);
		}
		catch (IOException ex) when (ex.InnerException is SocketException)
		{
			App.Logger.Error("Socket interrupted (Operation Canceled).");
		}
		catch (Exception argument)
		{
			App.Logger.Error("Unhandled exception: ", argument);
		}
	}

	public void Dispose()
	{
		if (_disposed)
		{
			return;
		}
		_disposed = true;
		App.Logger.Info("Cleaning up Discord RPC");
		if (_rpcClient != null)
		{
			try
			{
				_rpcClient.OnReady -= OnReady;
				_rpcClient.Dispose();
			}
			catch (IOException ex) when (ex.InnerException is SocketException)
			{
			}
			catch (Exception ex2)
			{
				App.Logger.Error("Cleanup error: " + ex2.Message);
			}
		}
		_uptimeStopwatch.Stop();
		GC.SuppressFinalize(this);
	}
}
