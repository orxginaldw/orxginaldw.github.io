using System;
using System.Diagnostics;
using System.Threading.Tasks;
using Avalonia.Threading;
using Merostrap.Enums;
using Merostrap.Extensions;
using Windows.Win32;
using Windows.Win32.Foundation;
using Windows.Win32.UI.Accessibility;
using Windows.Win32.UI.WindowsAndMessaging;

namespace Merostrap.Integrations;

internal class WindowManipulation : IDisposable
{
	private const string LOG_IDENT = "WindowManipulation";

	private const uint WINEVENT_OUTOFCONTEXT = 0u;

	private const uint EVENT_OBJECT_NAMECHANGE = 32780u;

	private const uint WM_SETICON = 128u;

	private const int ICON_SMALL = 0;

	private const int ICON_BIG = 1;

	private const int OBJID_WINDOW = 0;

	private const int ResolveTimeoutMs = 30000;

	private const int ResolvePollMs = 750;

	private const int PostResolveDelayMs = 2000;

	private readonly WINEVENTPROC _setTitleHook;

	private bool _titleHookInstalled;

	private UnhookWinEventSafeHandle? _titleHook;

	private HWND _hWnd;

	private readonly uint _robloxPID;

	private bool _disposed;

	private string _currentTitle = "Roblox";

	private string _gameTitle = "";

	private string _configuredTitle = "Roblox";

	private bool _inGame;

	public bool HasWindow => _hWnd != HWND.Null;

	public WindowManipulation(long robloxProcessId)
	{
		App.Logger.Info<string>("WindowManipulation", $"Got Roblox PID {robloxProcessId}");
		_robloxPID = (uint)robloxProcessId;
		_setTitleHook = SetWindowTitleHook;
	}

	public void Start()
	{
		Task.Run(async () =>
		{
			if (!(await WaitForWindowAsync()))
			{
				App.Logger.Warn<string>("WindowManipulation", $"Timed out waiting for window handle for PID {_robloxPID}");
			}
			else
			{
				await Task.Delay(2000);
				if (!_disposed)
				{
					ApplyConfiguredIcon();
					ApplyConfiguredTitle();
				}
			}
		});
	}

	public void ApplyWindowModifications()
	{
		App.Logger.Info<string>("WindowManipulation", "Applying window modifications");
		ApplyConfiguredIcon();
		ApplyConfiguredTitle();
	}

	public unsafe void ApplyConfiguredIcon()
	{
		if (!HasWindow)
		{
			return;
		}
		App.Logger.Info<string>("WindowManipulation", "Applying configured Roblox icon");
		RobloxIcon robloxIcon = App.Settings.Prop.RobloxIcon;
		if (robloxIcon == RobloxIcon.IconDefault)
		{
			PInvoke.SendMessage(_hWnd, 128u, new WPARAM(0u), new LPARAM(0));
			PInvoke.SendMessage(_hWnd, 128u, new WPARAM(1u), new LPARAM(0));
			return;
		}
		nint hIcon = robloxIcon.GetHIcon();
		if (hIcon != IntPtr.Zero)
		{
			HICON hICON = PInvoke.CopyIcon(new HICON(hIcon));
			PInvoke.SendMessage(_hWnd, 128u, new WPARAM(0u), new LPARAM((nint)hICON.Value));
			PInvoke.SendMessage(_hWnd, 128u, new WPARAM(1u), new LPARAM((nint)hICON.Value));
		}
	}

	public void ApplyConfiguredTitle()
	{
		if (!HasWindow)
		{
			return;
		}
		_configuredTitle = App.Settings.Prop.RobloxTitle;
		if (_inGame)
		{
			App.Logger.Info<string>("WindowManipulation", "In-game, keeping current title instead of applying configured title.");
			return;
		}
		_currentTitle = _configuredTitle;
		App.Logger.Info<string>("WindowManipulation", "Applying configured Roblox title: " + _configuredTitle);
		PInvoke.SetWindowText(_hWnd, _configuredTitle);
		if (_configuredTitle != "Roblox")
		{
			EnsureTitleHook();
		}
	}

	public unsafe void ApplyGameIcon(byte[] iconBytes)
	{
		if (!HasWindow)
		{
			return;
		}
		try
		{
			int systemMetrics = PInvoke.GetSystemMetrics(SYSTEM_METRICS_INDEX.SM_CXSMICON);
			int systemMetrics2 = PInvoke.GetSystemMetrics(SYSTEM_METRICS_INDEX.SM_CYSMICON);
			int systemMetrics3 = PInvoke.GetSystemMetrics(SYSTEM_METRICS_INDEX.SM_CXICON);
			int systemMetrics4 = PInvoke.GetSystemMetrics(SYSTEM_METRICS_INDEX.SM_CYICON);
			using DestroyIconSafeHandle destroyIconSafeHandle = PInvoke.CreateIconFromResourceEx(iconBytes, true, 196608u, systemMetrics, systemMetrics2, IMAGE_FLAGS.LR_DEFAULTCOLOR);
			using DestroyIconSafeHandle destroyIconSafeHandle2 = PInvoke.CreateIconFromResourceEx(iconBytes, true, 196608u, systemMetrics3, systemMetrics4, IMAGE_FLAGS.LR_DEFAULTCOLOR);
			if (!destroyIconSafeHandle.IsInvalid && !destroyIconSafeHandle2.IsInvalid)
			{
				HICON hICON = PInvoke.CopyIcon(new HICON(destroyIconSafeHandle.DangerousGetHandle()));
				HICON hICON2 = PInvoke.CopyIcon(new HICON(destroyIconSafeHandle2.DangerousGetHandle()));
				PInvoke.SendMessage(_hWnd, 128u, new WPARAM(0u), new LPARAM((nint)hICON.Value));
				PInvoke.SendMessage(_hWnd, 128u, new WPARAM(1u), new LPARAM((nint)hICON2.Value));
				App.Logger.Info<string>("WindowManipulation", "Applied game icon to Roblox window");
			}
		}
		catch (Exception ex)
		{
			App.Logger.Error<string>("WindowManipulation", "Failed to apply game icon: " + ex.Message);
		}
	}

	public void ApplyGameTitle(string title)
	{
		if (HasWindow)
		{
			_inGame = true;
			_gameTitle = title;
			_currentTitle = title;
			EnsureTitleHook();
			App.Logger.Info<string>("WindowManipulation", "Applying game title to Roblox window: " + title);
			PInvoke.SetWindowText(_hWnd, title);
		}
	}

	public void ResetToConfigured()
	{
		App.Logger.Info<string>("WindowManipulation", "Resetting Roblox window back to configured state");
		_inGame = false;
		_gameTitle = "";
		if (App.Settings.Prop.AutoChangeIcon)
		{
			ApplyConfiguredIcon();
		}
		if (App.Settings.Prop.AutoChangeTitle)
		{
			ApplyConfiguredTitle();
		}
	}

	private async Task<bool> WaitForWindowAsync()
	{
		int elapsed = 0;
		while (!_disposed && elapsed < 30000)
		{
			if (TryGetWindowForPid((int)_robloxPID, out var handle))
			{
				_hWnd = new HWND(handle);
				App.Logger.Info<string>("WindowManipulation", $"Resolved window handle for PID {_robloxPID}: 0x{((IntPtr)handle).ToInt64():X}");
				return true;
			}
			await Task.Delay(750);
			elapsed += 750;
		}
		return HasWindow;
	}

	private static bool TryGetWindowForPid(int pid, out nint handle)
	{
		handle = IntPtr.Zero;
		if (pid <= 0)
		{
			return false;
		}
		try
		{
			using Process process = Process.GetProcessById(pid);
			process.Refresh();
			if (process.MainWindowHandle != IntPtr.Zero)
			{
				handle = process.MainWindowHandle;
				return true;
			}
		}
		catch
		{
		}
		return false;
	}

	private void EnsureTitleHook()
	{
		if (_titleHookInstalled)
		{
			return;
		}
		Dispatcher.UIThread.Post(() =>
		{
			if (!_titleHookInstalled && !_disposed)
			{
				_titleHookInstalled = true;
				_titleHook = PInvoke.SetWinEventHook(32780u, 32780u, null, _setTitleHook, 0u, 0u, 0u);
				App.Logger.Info<string>("WindowManipulation", "Title change hook installed.");
			}
		});
	}

	private void UnhookTitleHook()
	{
		if (_titleHookInstalled)
		{
			try
			{
				_titleHook?.Dispose();
			}
			catch
			{
			}
			_titleHook = null;
			_titleHookInstalled = false;
			App.Logger.Info<string>("WindowManipulation", "Title change hook removed.");
		}
	}

	private void SetWindowTitleHook(HWINEVENTHOOK hWinEventHook, uint iEvent, HWND hWnd, int idObject, int idChild, uint dwEventThread, uint dwmsEventTime)
	{
		if (idObject == 0 && idChild == 0 && HasWindow && !(hWnd != _hWnd))
		{
			Span<char> span = new char[256];
			PInvoke.GetWindowText(_hWnd, span);
			if (span.TrimEnd('\0').ToString() != _currentTitle)
			{
				App.Logger.Info<string>("WindowManipulation", "Reverting Roblox title back to: " + _currentTitle);
				PInvoke.SetWindowText(_hWnd, _currentTitle);
			}
		}
	}

	public void Dispose()
	{
		if (!_disposed)
		{
			_disposed = true;
			if (_inGame)
			{
				ApplyConfiguredIcon();
			}
			UnhookTitleHook();
			GC.SuppressFinalize(this);
		}
	}
}
