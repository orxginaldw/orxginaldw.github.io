using System;
using System.Collections.Specialized;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace Merostrap.Integrations;

internal static class PreferredRegionRouting
{
	public static string Region => App.Settings.Prop.PreferredRegion?.Trim() ?? "";

	public static bool HasPreference => Region.Length > 0;

	public static bool UseMatchmaking
	{
		get
		{
			if (!HasPreference)
			{
				return App.Settings.Prop.EnableBetterMatchmaking;
			}
			return true;
		}
	}

	public static bool IsFriendJoin(string? origin)
	{
		if (origin == "friendServerListJoin" || origin == "placesListInHomePage")
		{
			return true;
		}
		return false;
	}

	public static async Task<string> RewriteAsync(string launchUri, Func<long, CancellationToken, Task<string?>> resolve, CancellationToken token)
	{
		if (!Uri.TryCreate(launchUri, UriKind.Absolute, out Uri result) || result.Scheme != "roblox" || !result.Host.Equals("experiences", StringComparison.OrdinalIgnoreCase) || result.AbsolutePath != "/start")
		{
			return launchUri;
		}
		NameValueCollection nameValueCollection = HttpUtility.ParseQueryString(result.Query);
		if (!long.TryParse(nameValueCollection["placeId"], out var result2) || result2 <= 0)
		{
			return launchUri;
		}
		string[] array = new string[8] { "gameInstanceId", "gameId", "jobId", "accessCode", "privateServerLinkCode", "linkCode", "userId", "reservedServerAccessCode" };
		foreach (string key in array)
		{
			if (nameValueCollection.AllKeys.Any((string existing) => string.Equals(existing, key, StringComparison.OrdinalIgnoreCase)))
			{
				return launchUri;
			}
		}
		if (IsFriendJoin(nameValueCollection["joinAttemptOrigin"]))
		{
			return launchUri;
		}
		string text = await resolve(result2, token);
		if (string.IsNullOrWhiteSpace(text))
		{
			return launchUri;
		}
		int num = launchUri.IndexOf('#');
		string text2 = ((num < 0) ? "" : launchUri.Substring(num));
		return ((num < 0) ? launchUri : launchUri.Substring(0, num)) + "&gameInstanceId=" + Uri.EscapeDataString(text) + text2;
	}

	public static async Task<string> ApplyAsync(string launchUri, CancellationToken token = default(CancellationToken))
	{
		if (!HasPreference)
		{
			return launchUri;
		}
		string region = Region;
		using CancellationTokenSource deadline = CancellationTokenSource.CreateLinkedTokenSource(token);
		deadline.CancelAfter(TimeSpan.FromSeconds(8L));
		try
		{
			return await RewriteAsync(launchUri, async (long place, CancellationToken cancellation) =>
			{
				using RobloxServerFetcher fetcher = new RobloxServerFetcher();
				return (await fetcher.FindBestServerInSelectedRegionAsync(place, region, cancellation)).ServerId;
			}, deadline.Token);
		}
		catch (OperationCanceledException) when (!token.IsCancellationRequested)
		{
			return launchUri;
		}
		catch (HttpRequestException)
		{
			return launchUri;
		}
	}
}
