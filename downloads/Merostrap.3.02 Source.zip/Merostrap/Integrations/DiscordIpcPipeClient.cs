using System;
using System.Buffers.Binary;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Threading;
using DiscordRPC.IO;
using DiscordRPC.Logging;

namespace Merostrap.Integrations;

internal sealed class DiscordIpcPipeClient : INamedPipeClient, IDisposable
{
	public const string PipePrefix = "discord-ipc-";

	public const int MaxPipes = 10;

	public const int MaxFrameSize = 1048576;

	private readonly ConcurrentQueue<PipeFrame> _frames = new ConcurrentQueue<PipeFrame>();

	private readonly object _writeLock = new object();

	private Socket? _socket;

	private volatile bool _closed = true;

	private volatile bool _disposed;

	public ILogger Logger { get; set; } = new NullLogger();

	public bool IsConnected
	{
		get
		{
			if (_socket != null && !_closed)
			{
				return !_disposed;
			}
			return false;
		}
	}

	public int ConnectedPipe { get; private set; } = -1;

	public static INamedPipeClient? Create()
	{
		if (!OperatingSystem.IsMacOS())
		{
			return null;
		}
		return new DiscordIpcPipeClient();
	}

	public bool Connect(int pipe)
	{
		ObjectDisposedException.ThrowIf(_disposed, this);
		Close();
		foreach (string item in ResolvePipePaths(pipe))
		{
			if (TryConnect(item, out Socket socket))
			{
				_socket = socket;
				_closed = false;
				ConnectedPipe = ParsePipeIndex(item);
				StartReading();
				return true;
			}
		}
		return false;
	}

	public bool ReadFrame(out PipeFrame frame)
	{
		if (_frames.TryDequeue(out var result))
		{
			frame = result;
			return true;
		}
		frame = default;
		return false;
	}

	public bool WriteFrame(PipeFrame frame)
	{
		if (!IsConnected)
		{
			return false;
		}
		try
		{
			Span<byte> span = stackalloc byte[8];
			BinaryPrimitives.WriteUInt32LittleEndian(span, (uint)frame.Opcode);
			BinaryPrimitives.WriteUInt32LittleEndian(span.Slice(4, 4), frame.Length);
			lock (_writeLock)
			{
				_socket.Send(span);
				byte[] data = frame.Data;
				if (data != null && data.Length > 0)
				{
					_socket.Send(frame.Data);
				}
			}
			return true;
		}
		catch (Exception ex)
		{
			Logger.Error("Failed to write frame: {0}", ex.Message);
			return false;
		}
	}

	public void Close()
	{
		if (_closed)
		{
			return;
		}
		_closed = true;
		Socket socket = _socket;
		_socket = null;
		if (socket == null)
		{
			return;
		}
		try
		{
			socket.Shutdown(SocketShutdown.Both);
		}
		catch
		{
		}
		try
		{
			socket.Dispose();
		}
		catch
		{
		}
	}

	public void Dispose()
	{
		if (!_disposed)
		{
			_disposed = true;
			Close();
		}
	}

	private void StartReading()
	{
		Socket socket = _socket;
		Thread thread = new Thread(() =>
		{
			ReadLoop(socket);
		});
		thread.IsBackground = true;
		thread.Name = "Discord IPC Socket Read";
		thread.Start();
	}

	private void ReadLoop(Socket? socket)
	{
		byte[] array = new byte[8];
		try
		{
			while (!_closed && !_disposed && socket != null && socket.Connected && ReadExactly(socket, array, 0, array.Length))
			{
				uint opcode = BinaryPrimitives.ReadUInt32LittleEndian(array.AsSpan(0, 4));
				uint num = BinaryPrimitives.ReadUInt32LittleEndian(array.AsSpan(4, 4));
				if (num <= 1048576)
				{
					byte[] array2 = new byte[num];
					if (num == 0 || ReadExactly(socket, array2, 0, array2.Length))
					{
						_frames.Enqueue(new PipeFrame
						{
							Opcode = (Opcode)opcode,
							Data = array2
						});
						continue;
					}
					break;
				}
				break;
			}
		}
		catch
		{
		}
		finally
		{
			if (!_closed)
			{
				Close();
			}
		}
	}

	private static bool ReadExactly(Socket socket, byte[] buffer, int offset, int count)
	{
		while (offset < count)
		{
			int num = socket.Receive(buffer, offset, count - offset, SocketFlags.None);
			if (num <= 0)
			{
				return false;
			}
			offset += num;
		}
		return true;
	}

	private bool TryConnect(string path, out Socket? socket)
	{
		Socket socket2 = new Socket(AddressFamily.Unix, SocketType.Stream, ProtocolType.IP);
		try
		{
			socket2.Connect(new UnixDomainSocketEndPoint(path));
			socket = socket2;
			return true;
		}
		catch (SocketException) when (!File.Exists(path))
		{
			socket = null;
			return false;
		}
		catch (Exception ex2)
		{
			Logger.Trace("Discord pipe {0} could not be connected: {1}", path, ex2.Message);
			try
			{
				socket2.Dispose();
			}
			catch
			{
			}
			socket = null;
			return false;
		}
	}

	private static IEnumerable<string> ResolvePipePaths(int pipe)
	{
		int start = ((pipe >= 0) ? Math.Min(pipe, 9) : 0);
		int end = ((pipe < 0) ? 10 : (start + 1));
		foreach (string dir in ResolveDirectories())
		{
			for (int i = start; i < end; i++)
			{
				yield return Path.Combine(dir, $"{"discord-ipc-"}{i}");
			}
		}
	}

	private static IEnumerable<string> ResolveDirectories()
	{
		string[] array = new string[4] { "XDG_RUNTIME_DIR", "TMPDIR", "TMP", "TEMP" };
		for (int i = 0; i < array.Length; i++)
		{
			string environmentVariable = Environment.GetEnvironmentVariable(array[i]);
			if (!string.IsNullOrWhiteSpace(environmentVariable) && Directory.Exists(environmentVariable))
			{
				yield return environmentVariable;
			}
		}
		if (!OperatingSystem.IsMacOS())
		{
			yield break;
		}
		foreach (string item in MacGuiTempDirectories())
		{
			yield return item;
		}
	}

	private static IEnumerable<string> MacGuiTempDirectories()
	{
		string[] array = new string[2] { "/private/var/folders", "/var/folders" };
		foreach (string path in array)
		{
			if (!Directory.Exists(path))
			{
				continue;
			}
			foreach (string item in SafeEnumerateDirectories(path))
			{
				foreach (string item2 in SafeEnumerateDirectories(item))
				{
					string text = Path.Combine(item2, "T");
					if (Directory.Exists(text))
					{
						bool flag;
						try
						{
							flag = Directory.EnumerateFileSystemEntries(text, "discord-ipc-*").Any();
						}
						catch
						{
							flag = false;
						}
						if (flag)
						{
							yield return text;
						}
					}
				}
			}
		}
	}

	private static IEnumerable<string> SafeEnumerateDirectories(string path)
	{
		string[] array;
		try
		{
			array = Directory.EnumerateDirectories(path).ToArray();
		}
		catch
		{
			yield break;
		}
		string[] array2 = array;
		for (int i = 0; i < array2.Length; i++)
		{
			yield return array2[i];
		}
	}

	private static int ParsePipeIndex(string path)
	{
		string text = Path.GetFileName(path) ?? string.Empty;
		int num = text.LastIndexOf('-');
		if (num < 0 || !int.TryParse(text.AsSpan(num + 1), out var result))
		{
			return 0;
		}
		return result;
	}
}
