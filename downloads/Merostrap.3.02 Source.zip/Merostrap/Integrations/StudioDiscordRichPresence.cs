using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Text.Json;
using DiscordRPC;
using DiscordRPC.Message;
using Merostrap.Models.MerostrapStudioRPC;

namespace Merostrap.Integrations;

internal class StudioDiscordRichPresence : IDisposable
{
	private readonly DiscordRpcClient? _rpcClient;

	private readonly ActivityWatcher _activityWatcher;

	private readonly Queue<StudioMessage> _messageQueue = new Queue<StudioMessage>();

	private RichPresence? _currentPresence;

	private RichPresence? _originalPresence;

	private bool _visible = true;

	private bool _rpcEnabled = true;

	private bool _disposed;

	public StudioDiscordRichPresence(ActivityWatcher activityWatcher)
	{
		_rpcClient = new DiscordRpcClient("1454451301130960896", -1, null, autoEvents: true, DiscordIpcPipeClient.Create());
		_activityWatcher = activityWatcher;
		_activityWatcher.OnStudioRPCMessage += (object? _, StudioMessage message) =>
		{
			ProcessRPCMessage(message);
		};
		_activityWatcher.OnStudioPlaceOpened += (object? _, EventArgs _) =>
		{
			HandleStudioPlaceOpened();
		};
		_activityWatcher.OnStudioPlaceClosed += (object? _, EventArgs _) =>
		{
			HandleStudioPlaceClosed();
		};
		_rpcClient.OnReady += (object _, ReadyMessage e) =>
		{
			App.Logger.Info($"Received ready from user {e.User} ({e.User.ID})");
			if (!_disposed)
			{
				InitializeStudioPresence();
			}
		};
		_rpcClient.OnConnectionEstablished += (object _, ConnectionEstablishedMessage e) =>
		{
			App.Logger.Info("Established connection with Discord RPC");
		};
		_rpcClient.OnClose += (object _, CloseMessage e) =>
		{
			App.Logger.Info($"Lost connection to Discord RPC - {e.Reason} ({e.Code})");
		};
		_rpcClient.OnError += (object _, ErrorMessage e) =>
		{
			App.Logger.Info("An RPC error occurred - " + e.Message);
		};
		try
		{
			_rpcClient.Initialize();
		}
		catch (Exception ex)
		{
			App.Logger.Error("Failed to init RPC: " + ex.Message);
		}
	}

	private static void HandleStudioPlaceOpened()
	{
		App.Logger.Info("Studio place opened");
	}

	private void HandleStudioPlaceClosed()
	{
		if (!_disposed)
		{
			App.Logger.Info("Studio place closed");
			ResetStudioPresence();
			_rpcEnabled = true;
		}
	}

	public void ProcessRPCMessage(StudioMessage message, bool implicitUpdate = true)
	{
		if (!_disposed && message.StudioCommand == "SetRichPresence" && _rpcEnabled)
		{
			if (_currentPresence == null || _originalPresence == null)
			{
				InitializeStudioPresence();
			}
			ProcessStudioRichPresence(message, implicitUpdate);
		}
	}

	private void InitializeStudioPresence()
	{
		if (!_disposed && _rpcClient != null)
		{
			App.Logger.Info("Initializing Studio presence");
			_currentPresence = new RichPresence
			{
				Timestamps = new Timestamps
				{
					Start = DateTime.UtcNow
				},
				Assets = new Assets
				{
					LargeImageKey = "roblox_studio",
					LargeImageText = "Roblox Studio",
					SmallImageKey = null,
					SmallImageText = null
				}
			};
			_originalPresence = _currentPresence.Clone();
			while (_messageQueue.Count > 0)
			{
				ProcessRPCMessage(_messageQueue.Dequeue(), implicitUpdate: false);
			}
			UpdatePresence();
		}
	}

	private void ResetStudioPresence()
	{
		if (!_disposed && _rpcClient != null)
		{
			App.Logger.Info("Resetting Studio presence");
			DateTime? dateTime = _currentPresence?.Timestamps?.Start;
			_currentPresence = new RichPresence
			{
				Timestamps = (dateTime.HasValue ? new Timestamps
				{
					Start = dateTime.Value
				} : new Timestamps
				{
					Start = DateTime.UtcNow
				}),
				Assets = new Assets
				{
					LargeImageKey = "roblox_studio",
					LargeImageText = "Roblox Studio",
					SmallImageKey = null,
					SmallImageText = null
				}
			};
			UpdatePresence();
		}
	}

	private void ProcessStudioRichPresence(StudioMessage message, bool implicitUpdate)
	{
		if (_disposed || _rpcClient == null)
		{
			return;
		}
		StudioRichPresence studioRichPresence;
		try
		{
			studioRichPresence = message.Data.Deserialize<StudioRichPresence>();
		}
		catch (Exception)
		{
			App.Logger.Error("Failed to parse studio message!");
			return;
		}
		if (studioRichPresence == null)
		{
			return;
		}
		if (!string.IsNullOrEmpty(studioRichPresence.Details) && App.Settings.Prop.StudioWorkspaceInfo)
		{
			_currentPresence.Details = ((studioRichPresence.DevCount > 1) ? $"{studioRichPresence.Details} ({studioRichPresence.DevCount} Developers)" : studioRichPresence.Details);
		}
		if (!string.IsNullOrEmpty(studioRichPresence.State) && App.Settings.Prop.StudioEditingInfo)
		{
			_currentPresence.State = studioRichPresence.State;
		}
		string largeImageKey = "roblox_studio";
		string largeImageText = "Roblox Studio";
		if (!string.IsNullOrEmpty(studioRichPresence.ScriptType) && App.Settings.Prop.StudioThumbnailChanging)
		{
			string text;
			switch (studioRichPresence.ScriptType.ToUpperInvariant())
			{
			case "SERVER SCRIPT":
				text = "studio_server";
				break;
			case "LOCAL SCRIPT":
				text = "studio_client";
				break;
			case "MODULE":
			case "SERVER MODULE":
			case "CLIENT MODULE":
				text = "studio_module";
				break;
			default:
				text = "roblox_studio";
				break;
			}
			largeImageKey = text;
			largeImageText = "Editing " + studioRichPresence.ScriptType;
		}
		string text2 = null;
		if (studioRichPresence.Testing && App.Settings.Prop.StudioShowTesting)
		{
			text2 = "play_icon";
		}
		_currentPresence.Assets = new Assets
		{
			LargeImageKey = largeImageKey,
			LargeImageText = largeImageText,
			SmallImageKey = (text2 ?? string.Empty),
			SmallImageText = ((studioRichPresence.Testing && App.Settings.Prop.StudioShowTesting) ? "Currently Testing" : null)
		};
		if (App.Settings.Prop.StudioGameButton && studioRichPresence.PlaceId > 0 && studioRichPresence.IsPublic)
		{
			_currentPresence.Buttons = new Button[1]
			{
				new Button
				{
					Label = "Open Roblox Game",
					Url = $"https://www.roblox.com/games/{studioRichPresence.PlaceId}"
				}
			};
		}
		else
		{
			_currentPresence.Buttons = null;
		}
		if (_rpcEnabled)
		{
			_originalPresence = _currentPresence.Clone();
		}
		if (implicitUpdate)
		{
			UpdatePresence();
		}
	}

	public void SetVisibility(bool visible)
	{
		if (!_disposed && _rpcClient != null)
		{
			App.Logger.Info($"Setting presence visibility ({visible})");
			_visible = visible;
			if (_visible)
			{
				UpdatePresence();
			}
			else
			{
				_rpcClient.ClearPresence();
			}
		}
	}

	public void UpdatePresence()
	{
		if (_disposed || _rpcClient == null || _currentPresence == null || !_rpcClient.IsInitialized)
		{
			return;
		}
		try
		{
			if (_visible)
			{
				_rpcClient.SetPresence(_currentPresence);
			}
		}
		catch (IOException ex) when (ex.InnerException is SocketException)
		{
			App.Logger.Error("Socket interrupted (Operation Canceled).");
		}
		catch (Exception value)
		{
			App.Logger.Error(value);
		}
	}

	public void Dispose()
	{
		if (_disposed)
		{
			return;
		}
		_disposed = true;
		App.Logger.Info("Cleaning up Discord RPC");
		if (_rpcClient != null)
		{
			try
			{
				if (_rpcClient.IsInitialized)
				{
					try
					{
						_rpcClient.ClearPresence();
					}
					catch (IOException)
					{
					}
				}
				_rpcClient.Dispose();
			}
			catch (IOException ex2) when (ex2.InnerException is SocketException)
			{
			}
			catch (Exception value)
			{
				App.Logger.Error(value);
			}
		}
		GC.SuppressFinalize(this);
	}
}
