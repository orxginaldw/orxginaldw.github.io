using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.Versioning;
using System.Threading;
using System.Threading.Tasks;
using Merostrap.Enums;
using Merostrap.Models;
using Merostrap.Models.APIs.Roblox;
using Merostrap.Models.Entities;
using Merostrap.UI.Converters;
using Merostrap.Utility;

namespace Merostrap.Integrations;

[SupportedOSPlatform("windows")]
internal class IntegrationWatcher : IDisposable
{
	private readonly ActivityWatcher _activityWatcher;

	private readonly WindowManipulation? _windowManipulation;

	private readonly Dictionary<int, CustomIntegration> _activeIntegrations = new Dictionary<int, CustomIntegration>();

	private static bool WindowManipulationEnabled
	{
		get
		{
			if (App.Settings.Prop.EnableWindowManipulation)
			{
				return App.Settings.Prop.EnableActivityTracking;
			}
			return false;
		}
	}

	public IntegrationWatcher(ActivityWatcher activityWatcher, WindowManipulation? windowManipulation = null)
	{
		_activityWatcher = activityWatcher;
		_windowManipulation = windowManipulation;
		_activityWatcher.OnGameJoin += OnGameJoin;
		_activityWatcher.OnGameLeave += OnGameLeave;
	}

	private void OnGameJoin(object? sender, EventArgs e)
	{
		if (!_activityWatcher.InGame)
		{
			return;
		}
		if (!App.Settings.Prop.Performance.NetworkMode && _windowManipulation != null && WindowManipulationEnabled && OperatingSystem.IsWindows())
		{
			Task.Run(async () =>
			{
				if (App.Settings.Prop.AutoChangeIcon)
				{
					byte[] array = await FetchGameIconAsync();
					if (array != null)
					{
						_windowManipulation.ApplyGameIcon(array);
					}
				}
				if (App.Settings.Prop.AutoChangeTitle)
				{
					string text = await FetchGameTitleAsync();
					if (text != null)
					{
						_windowManipulation.ApplyGameTitle(text);
					}
				}
			});
		}
		long placeId = _activityWatcher.Data.PlaceId;
		foreach (CustomIntegration customIntegration in App.Settings.Prop.CustomIntegrations)
		{
			if (customIntegration.SpecifyGame && !(customIntegration.GameID != placeId.ToString(CultureInfo.InvariantCulture)))
			{
				LaunchIntegration(customIntegration);
			}
		}
	}

	private void OnGameLeave(object? sender, EventArgs e)
	{
		if (_windowManipulation != null && WindowManipulationEnabled)
		{
			_windowManipulation.ResetToConfigured();
		}
		foreach (int item in _activeIntegrations.Keys.ToList())
		{
			if (_activeIntegrations[item].AutoCloseOnGame)
			{
				TerminateProcess(item);
				_activeIntegrations.Remove(item);
			}
		}
	}

	private async Task<byte[]?> FetchGameIconAsync()
	{
		_ = 3;
		try
		{
			ActivityData data = _activityWatcher.Data;
			if (data == null || data.UniverseId == 0L)
			{
				return null;
			}
			App.Logger.Info($"Fetching icon for Universe ID: {data.UniverseId}");
			string text = await Thumbnails.GetThumbnailUrlAsync(new ThumbnailRequest
			{
				TargetId = (ulong)data.UniverseId,
				Size = ThumbnailSize.Detailed,
				Type = ThumbnailType.GameIcon,
				Format = ThumbnailFormat.Png
			}, CancellationToken.None);
			if (string.IsNullOrEmpty(text))
			{
				App.Logger.Info("Failed to resolve game thumbnail URL");
				return null;
			}
			using HttpResponseMessage response = await App.HttpClient.GetAsync(new Uri(text));
			response.EnsureSuccessStatusCode();
			using Stream stream = await response.Content.ReadAsStreamAsync();
			using MemoryStream ms = new MemoryStream();
			await stream.CopyToAsync(ms);
			return ms.ToArray();
		}
		catch (Exception ex)
		{
			App.Logger.Error("Failed to fetch game icon: " + ex.Message);
			return null;
		}
	}

	private async Task<string?> FetchGameTitleAsync()
	{
		try
		{
			ActivityData activity = _activityWatcher.Data;
			if (activity == null)
			{
				return null;
			}
			if (activity.UniverseDetails == null)
			{
				try
				{
					await UniverseDetails.FetchSingle(activity.UniverseId);
				}
				catch (Exception argument)
				{
					App.Logger.Error("Unhandled exception: ", argument);
				}
				activity.UniverseDetails = UniverseDetails.LoadFromCache(activity.UniverseId);
			}
			if (activity.UniverseDetails?.Data == null)
			{
				return null;
			}
			string name = activity.UniverseDetails.Data.Name;
			if (string.IsNullOrEmpty(name))
			{
				return null;
			}
			if (App.Settings.Prop.AutoChangeTitleWithPlayerCount)
			{
				long playing = activity.UniverseDetails.Data.Playing;
				string text = (new NumberAbbreviationConverter().Convert(playing, typeof(string), null, CultureInfo.CurrentCulture) as string) ?? playing.ToString(CultureInfo.InvariantCulture);
				return name + " (" + text + " playing)";
			}
			return name;
		}
		catch (Exception ex)
		{
			App.Logger.Error("Failed to fetch game title: " + ex.Message);
			return null;
		}
	}

	private void LaunchIntegration(CustomIntegration integration)
	{
		try
		{
			Process process = Process.Start(new ProcessStartInfo
			{
				FileName = integration.Location,
				Arguments = integration.LaunchArgs.Replace("\r\n", " ", StringComparison.Ordinal),
				WorkingDirectory = Path.GetDirectoryName(integration.Location),
				UseShellExecute = true
			});
			if (process != null)
			{
				App.Logger.Info($"Integration '{integration.Name}' launched for game ID '{integration.GameID}' (PID {process.Id}).");
				_activeIntegrations[process.Id] = integration;
			}
		}
		catch (Exception ex)
		{
			App.Logger.Error("Failed to launch integration '" + integration.Name + "': " + ex.Message);
		}
	}

	private static void TerminateProcess(int pid)
	{
		try
		{
			Process.GetProcessById(pid).Kill();
			App.Logger.Info($"Terminated integration process (PID {pid}).");
		}
		catch (Exception)
		{
			App.Logger.Error($"Failed to terminate process (PID {pid}), likely already exited.");
		}
	}

	public void Dispose()
	{
		foreach (int key in _activeIntegrations.Keys)
		{
			TerminateProcess(key);
		}
		_activeIntegrations.Clear();
		GC.SuppressFinalize(this);
	}
}
