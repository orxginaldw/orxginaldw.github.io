using System;
using System.IO;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Nodes;
using Merostrap.Enums.AppStoragePresets;
using Merostrap.Utility;

namespace Merostrap;

internal static class AppStorageManager
{
	private static readonly JsonSerializerOptions SerializerOptions = new JsonSerializerOptions
	{
		Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
	};

	public static string FileLocation
	{
		get
		{
			if (!OperatingSystem.IsLinux())
			{
				return Path.Combine(Paths.Roblox, "LocalStorage", "appStorage.json");
			}
			return Path.Combine(Paths.SoberData, "appData", "LocalStorage", "appStorage.json");
		}
	}

	public static void Apply()
	{
		bool background = App.Settings.Prop.EnableRobloxBackgroundApp;
		Mutate((JsonObject storage) =>
		{
			ApplyBackgroundApp(storage, background);
			ApplyTheme(storage);
		});
		if (!background && OperatingSystem.IsWindows())
		{
			WindowsRegistry.RemoveRobloxStartupEntry();
		}
	}

	private static void ApplyBackgroundApp(JsonObject storage, bool enabled)
	{
		string text = (enabled ? "true" : "false");
		storage["LaunchAtStartup"] = text;
		storage["MinimizeToTray"] = text;
		storage["SystemTrayModalShown"] = "true";
	}

	private static void ApplyTheme(JsonObject storage)
	{
		string text;
		switch (App.Settings.Prop.RobloxTheme)
		{
		case RobloxTheme.Default:
			return;
		default:
			text = "light";
			break;
		case RobloxTheme.Dark:
			text = "dark";
			break;
		}
		string text2 = text;
		storage["AuthenticatedTheme"] = text2;
		try
		{
			if (storage["UserId"] is JsonValue jsonValue && jsonValue.TryGetValue<string>(out string value) && !string.IsNullOrEmpty(value))
			{
				JsonObject jsonObject = new JsonObject();
				if (storage["DeviceLevelTheme"] is JsonValue jsonValue2 && jsonValue2.TryGetValue<string>(out string value2) && !string.IsNullOrWhiteSpace(value2) && JsonNode.Parse(value2) is JsonObject jsonObject2)
				{
					jsonObject = jsonObject2;
				}
				jsonObject[value] = text2;
				storage["DeviceLevelTheme"] = jsonObject.ToJsonString(SerializerOptions);
			}
		}
		catch (Exception value3)
		{
			App.Logger.Error("AppStorageManager::ApplyTheme: Failed to update the per-account theme cache");
			App.Logger.Error(value3);
		}
	}

	private static void Mutate(Action<JsonObject> mutate)
	{
		string text = FileLocation;
		if (!File.Exists(text))
		{
			Create(text, mutate);
			return;
		}
		string text2 = null;
		try
		{
			text = new FileInfo(text).ResolveLinkTarget(returnFinalTarget: true)?.FullName ?? text;
			string text3 = File.ReadAllText(text);
			if (string.IsNullOrWhiteSpace(text3))
			{
				App.Logger.Info("AppStorageManager::Mutate: File is empty, leaving it alone");
				return;
			}
			if (!(JsonNode.Parse(text3) is JsonObject jsonObject))
			{
				App.Logger.Info("AppStorageManager::Mutate: File is not a JSON object, leaving it alone");
				return;
			}
			string text4 = jsonObject.ToJsonString(SerializerOptions);
			mutate(jsonObject);
			string text5 = jsonObject.ToJsonString(SerializerOptions);
			if (text5 == text4)
			{
				App.Logger.Info("AppStorageManager::Mutate: Already up to date");
				return;
			}
			text2 = text + ".merostrap-tmp";
			File.WriteAllText(text2, text5, new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
			Filesystem.AssertReadOnly(text);
			File.Replace(text2, text, null);
			text2 = null;
			App.Logger.Info("AppStorageManager::Mutate: Saved successfully");
		}
		catch (Exception value)
		{
			App.Logger.Error("AppStorageManager::Mutate: Failed to patch " + text);
			App.Logger.Error(value);
		}
		finally
		{
			if (text2 != null)
			{
				try
				{
					File.Delete(text2);
				}
				catch (Exception value2)
				{
					App.Logger.Error(value2);
				}
			}
		}
	}

	private static void Create(string path, Action<JsonObject> mutate)
	{
		try
		{
			JsonObject jsonObject = new JsonObject();
			mutate(jsonObject);
			Directory.CreateDirectory(Path.GetDirectoryName(path));
			File.WriteAllText(path, jsonObject.ToJsonString(SerializerOptions), new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
			App.Logger.Info("AppStorageManager::Create: Seeded " + path);
		}
		catch (Exception value)
		{
			App.Logger.Error("AppStorageManager::Create: Failed to seed " + path);
			App.Logger.Error(value);
		}
	}
}
