using System;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using Avalonia;
using Avalonia.Logging;
using Merostrap.Backend;
using Merostrap.Updates;
using NLog;

namespace Merostrap;

internal sealed class Program
{
	private static readonly NLog.Logger Logger = LogManager.GetCurrentClassLogger();

	[DllImport("kernel32.dll")]
	private static extern bool AllocConsole();

	[STAThread]
	public static void Main(string[] args)
	{
		if (SelfUpdateRunner.TryRun(args))
		{
			return;
		}
		ThreadPool.SetMinThreads(Environment.ProcessorCount * 2, Environment.ProcessorCount * 2);
		if (args.Any((string a) => (a == "-c" || a == "--console") ? true : false))
		{
			AllocConsole();
		}
		Assembly assembly = typeof(App).Assembly;
		LogManager.Setup().LoadConfigurationFromAssemblyResource(assembly);
		GlobalDiagnosticsContext.Set("logRoot", Paths.Logs);
		GlobalDiagnosticsContext.Set("startTime", DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss", CultureInfo.InvariantCulture));
		Logger.Debug("Log file: " + Logging.FileLocation);
		AppInitializer.InitializeNativeResolvers();
		App.LaunchSettings = new LaunchSettings(args);
		if (App.LaunchSettings.MultiInstanceWatcherFlag.Active)
		{
			try
			{
				Paths.Initialize();
				MultiInstanceWatcher.Run();
				return;
			}
			catch (Exception exception)
			{
				Logger.Error(exception, "Multi-instance helper failed");
				return;
			}
			finally
			{
				LogManager.Shutdown();
			}
		}
		try
		{
			NativeNotify.InitRing();
			BuildAvaloniaApp().StartWithClassicDesktopLifetime(args);
		}
		catch (Exception exception2)
		{
			Logger.Fatal(exception2, "Unhandled exception during startup");
			throw;
		}
		finally
		{
			LogManager.Shutdown();
		}
	}

	public static AppBuilder BuildAvaloniaApp()
	{
		AppBuilder appBuilder = AppBuilder.Configure<App>().UsePlatformDetect().LogToTrace(LogEventLevel.Warning);
		if (OperatingSystem.IsWindows())
		{
			LaunchSettings launchSettings = App.LaunchSettings;
			if (launchSettings != null && launchSettings.NoGpuFlag.Active)
			{
				appBuilder = appBuilder.With(new Win32PlatformOptions
				{
					RenderingMode = new _003C_003Ez__ReadOnlySingleElementList<Win32RenderingMode>(Win32RenderingMode.Software)
				});
			}
		}
		if (OperatingSystem.IsLinux() && !string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("MEROSTRAP_FORCE_WAYLAND")))
		{
			App.Logger.Debug("Using Wayland backend (MEROSTRAP_FORCE_WAYLAND)");
			appBuilder = appBuilder.UseWayland().With(new WaylandPlatformOptions
			{
				UseDmabufSwapchain = true
			});
		}
		return appBuilder;
	}
}
