using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Merostrap;

internal static class Resource
{
	private static readonly Assembly assembly = Assembly.GetExecutingAssembly();

	private static readonly string[] resourceNames = assembly.GetManifestResourceNames();

	public static Stream GetStream(string name)
	{
		string name2 = resourceNames.Single((string str) => str.EndsWith(name, StringComparison.Ordinal));
		return assembly.GetManifestResourceStream(name2);
	}

	public static async Task<byte[]> Get(string name)
	{
		using Stream stream = GetStream(name);
		using MemoryStream memoryStream = new MemoryStream();
		await stream.CopyToAsync(memoryStream);
		return memoryStream.ToArray();
	}

	public static async Task<string> GetString(string name)
	{
		Encoding uTF = Encoding.UTF8;
		return uTF.GetString(await Get(name));
	}
}
