using System;
using System.Collections.Generic;
using System.IO;
using NLog;
using NLog.Config;
using NLog.Targets;
using NLog.Targets.Wrappers;

namespace Merostrap;

internal static class Logging
{
	public static bool Initialized => LogManager.Configuration != null;

	public static string? FileLocation
	{
		get
		{
			FileTarget fileTarget = FindFileTarget();
			if (fileTarget == null)
			{
				return null;
			}
			try
			{
				return fileTarget.FileName.Render(LogEventInfo.CreateNullEvent());
			}
			catch
			{
				return null;
			}
		}
	}

	public static string AsDocument
	{
		get
		{
			string fileLocation = FileLocation;
			if (string.IsNullOrEmpty(fileLocation) || !File.Exists(fileLocation))
			{
				return string.Empty;
			}
			try
			{
				using FileStream stream = new FileStream(fileLocation, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
				using StreamReader streamReader = new StreamReader(stream);
				return streamReader.ReadToEnd();
			}
			catch (Exception ex)
			{
				return "[Failed to read log file: " + ex.Message + "]";
			}
		}
	}

	private static FileTarget? FindFileTarget()
	{
		LoggingConfiguration configuration = LogManager.Configuration;
		if (configuration == null)
		{
			return null;
		}
		return FindFileTarget(configuration.AllTargets);
	}

	private static FileTarget? FindFileTarget(IEnumerable<Target> targets)
	{
		foreach (Target target in targets)
		{
			if (target is FileTarget result)
			{
				return result;
			}
			if (target is WrapperTargetBase { WrappedTarget: not null } wrapperTargetBase)
			{
				FileTarget fileTarget = FindFileTarget(new Target[1] { wrapperTargetBase.WrappedTarget });
				if (fileTarget != null)
				{
					return fileTarget;
				}
			}
		}
		return null;
	}
}
