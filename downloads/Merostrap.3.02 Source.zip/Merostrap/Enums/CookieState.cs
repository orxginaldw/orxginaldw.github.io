namespace Merostrap.Enums;

internal enum CookieState
{
	Success,
	NotAllowed,
	NotFound,
	Invalid,
	Failed,
	Unknown
}
