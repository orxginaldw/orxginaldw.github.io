namespace Merostrap.Enums;

internal enum LaunchMode
{
	None,
	Unknown,
	Player,
	Studio,
	StudioAuth
}
