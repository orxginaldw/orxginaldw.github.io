using Merostrap.Models.Attributes;

namespace Merostrap.Enums;

internal enum CycleFrequency
{
	[EnumName(FromTranslation = "Enums.CycleFrequency.EveryLaunch")]
	EveryLaunch,
	[EnumName(FromTranslation = "Enums.CycleFrequency.Minutes")]
	Minutes,
	[EnumName(FromTranslation = "Enums.CycleFrequency.Hours")]
	Hours,
	[EnumName(FromTranslation = "Enums.CycleFrequency.Days")]
	Days
}
