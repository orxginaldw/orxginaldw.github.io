using Merostrap.Models.Attributes;

namespace Merostrap.Enums;

internal enum Theme
{
	[EnumName(FromTranslation = "Common.SystemDefault")]
	Default,
	Dark,
	Light,
	[EnumName(FromTranslation = "Common.Custom")]
	Custom
}
