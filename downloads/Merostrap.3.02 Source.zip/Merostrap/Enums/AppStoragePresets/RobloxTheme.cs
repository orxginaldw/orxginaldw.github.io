namespace Merostrap.Enums.AppStoragePresets;

internal enum RobloxTheme
{
	Default,
	Light,
	Dark
}
