using Merostrap.Models.Attributes;

namespace Merostrap.Enums;

internal enum BackgroundMode
{
	[EnumName(FromTranslation = "Enums.BackgroundMode.Gradient")]
	Gradient,
	[EnumName(FromTranslation = "Enums.BackgroundMode.Image")]
	Image
}
