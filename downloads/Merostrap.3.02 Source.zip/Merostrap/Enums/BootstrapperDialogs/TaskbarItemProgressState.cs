namespace Merostrap.Enums.BootstrapperDialogs;

internal enum TaskbarItemProgressState
{
	None,
	Indeterminate,
	Normal,
	Error,
	Paused
}
