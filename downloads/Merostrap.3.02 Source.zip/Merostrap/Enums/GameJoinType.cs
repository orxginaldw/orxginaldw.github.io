namespace Merostrap.Enums;

internal enum GameJoinType
{
	Unknown,
	RequestGame,
	RequestGameJob,
	RequestPrivateGame,
	RequestFollowUser,
	RequestPlayTogetherGame
}
