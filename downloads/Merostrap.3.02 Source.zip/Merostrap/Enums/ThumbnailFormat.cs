namespace Merostrap.Enums;

internal enum ThumbnailFormat
{
	Png,
	Jpeg
}
