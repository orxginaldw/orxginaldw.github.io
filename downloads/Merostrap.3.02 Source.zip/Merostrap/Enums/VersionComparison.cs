namespace Merostrap.Enums;

internal enum VersionComparison
{
	LessThan = -1,
	Equal,
	GreaterThan
}
