namespace Merostrap.Enums.Messagebox;

internal enum MessageBoxImage
{
	None,
	Error,
	Information,
	Question,
	Warning
}
