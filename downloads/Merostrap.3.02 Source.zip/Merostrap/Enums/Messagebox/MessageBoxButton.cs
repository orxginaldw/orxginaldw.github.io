namespace Merostrap.Enums.Messagebox;

internal enum MessageBoxButton
{
	OK,
	OKCancel,
	YesNo,
	YesNoCancel
}
