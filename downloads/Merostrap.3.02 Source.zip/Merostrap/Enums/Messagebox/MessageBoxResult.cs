namespace Merostrap.Enums.Messagebox;

internal enum MessageBoxResult
{
	None,
	OK,
	Cancel,
	Yes,
	No
}
