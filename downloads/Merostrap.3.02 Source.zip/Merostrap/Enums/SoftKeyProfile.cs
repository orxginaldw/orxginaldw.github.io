using Merostrap.Models.Attributes;

namespace Merostrap.Enums;

internal enum SoftKeyProfile
{
	WASD,
	AZERTY,
	ESDF,
	[EnumName(StaticName = "Arrow Keys")]
	ArrowKeys
}
