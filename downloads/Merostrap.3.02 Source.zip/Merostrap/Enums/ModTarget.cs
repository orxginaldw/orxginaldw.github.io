namespace Merostrap.Enums;

internal enum ModTarget
{
	Both,
	Player,
	Studio
}
