using Merostrap.Models.Attributes;

namespace Merostrap.Enums;

internal enum TrayDoubleClickAction
{
	[EnumName(FromTranslation = "Enums.TrayDoubleClickAction.ServerInfo")]
	ServerInfo,
	[EnumName(FromTranslation = "Enums.TrayDoubleClickAction.GameHistory")]
	GameHistory,
	[EnumName(FromTranslation = "Enums.TrayDoubleClickAction.None")]
	None
}
