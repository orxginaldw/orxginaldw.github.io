namespace Merostrap.Enums;

internal enum ServerType
{
	Public,
	Private,
	Reserved
}
