namespace Merostrap.Enums;

internal enum ModType
{
	MiscMod,
	ColorMod,
	SkyBox,
	Cursor,
	AvatarEditor,
	CustomTheme
}
