using Merostrap.Models.Attributes;

namespace Merostrap.Enums.FlagPresets;

internal enum MSAAMode
{
	[EnumName(StaticName = "0x (Default)")]
	Default,
	[EnumName(StaticName = "1x")]
	x1,
	[EnumName(StaticName = "2x")]
	x2,
	[EnumName(StaticName = "4x")]
	x4
}
