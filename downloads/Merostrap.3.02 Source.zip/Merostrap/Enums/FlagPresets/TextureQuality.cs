using Merostrap.Models.Attributes;

namespace Merostrap.Enums.FlagPresets;

internal enum TextureQuality
{
	[EnumName(FromTranslation = "Enums.TextureQuality.Default")]
	Default,
	[EnumName(FromTranslation = "Enums.TextureQuality.Medium")]
	Medium,
	[EnumName(FromTranslation = "Enums.TextureQuality.Low")]
	Low,
	[EnumName(FromTranslation = "Enums.TextureQuality.Lowest")]
	Lowest
}
