namespace Merostrap.Enums.FlagPresets;

internal enum RenderingMode
{
	Default,
	Direct3D,
	Vulkan,
	OpenGL
}
