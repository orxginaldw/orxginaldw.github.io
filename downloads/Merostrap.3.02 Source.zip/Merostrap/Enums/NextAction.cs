namespace Merostrap.Enums;

internal enum NextAction
{
	Terminate,
	LaunchSettings,
	LaunchRoblox,
	LaunchMenu,
	SignIn,
	LaunchRobloxStudio
}
