namespace Merostrap.Enums;

internal enum DeeplinkType
{
	Merostrap,
	RobloxProtocol,
	RobloxWeb
}
