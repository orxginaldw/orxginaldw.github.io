namespace Merostrap.Enums;

internal enum GameSource
{
	None,
	Tracked,
	RobloxApi
}
