namespace Merostrap.Enums;

internal enum CleanerOptions
{
	Never,
	OneDay,
	OneWeek,
	OneMonth,
	TwoMonths
}
