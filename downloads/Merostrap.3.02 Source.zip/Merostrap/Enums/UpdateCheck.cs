namespace Merostrap.Enums;

internal enum UpdateCheck
{
	Disabled,
	Stable,
	Test,
	Both
}
