namespace Merostrap.Enums;

internal enum WindowsBackdrops
{
	Mica,
	Acrylic,
	None
}
