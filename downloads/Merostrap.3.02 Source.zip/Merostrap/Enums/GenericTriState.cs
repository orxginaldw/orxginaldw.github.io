namespace Merostrap.Enums;

internal enum GenericTriState
{
	Successful,
	Failed,
	Unknown
}
