namespace Merostrap.Enums;

internal enum CustomThemeTemplate
{
	Blank,
	Simple
}
