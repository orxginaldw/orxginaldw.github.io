namespace Merostrap.Enums;

internal enum ChannelChangeMode
{
	Automatic,
	Prompt,
	Ignore
}
