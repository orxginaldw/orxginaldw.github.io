namespace Merostrap.Enums;

internal enum BootstrapperStyle
{
	ClassicFluentDialog,
	TwentyFiveDialog,
	ByfronDialog,
	ModernDialog,
	FluentDialog,
	FluentAeroDialog,
	CustomDialog
}
