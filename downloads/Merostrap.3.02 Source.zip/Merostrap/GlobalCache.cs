using System.Collections.Generic;

namespace Merostrap;

internal static class GlobalCache
{
	public static readonly Dictionary<string, string?> ServerLocation = new Dictionary<string, string>();
}
