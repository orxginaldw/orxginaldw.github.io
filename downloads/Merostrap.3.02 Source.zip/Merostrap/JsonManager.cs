using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using System.Text.Json.Nodes;
using Merostrap.Enums.Messagebox;
using Merostrap.Models.Persistable;
using Merostrap.Resources;
using Merostrap.UI;
using Merostrap.Utility;

namespace Merostrap;

internal class JsonManager<T>(string? className = null) where T : class, new()
{
	private static readonly JsonSerializerOptions _jsonOptions = new JsonSerializerOptions
	{
		WriteIndented = true,
		ReadCommentHandling = JsonCommentHandling.Skip
	};

	protected T _prop = new T();

	protected string? _savedHash;

	private JsonObject? _savedSettingsSnapshot;

	public virtual T Prop
	{
		get
		{
			return _prop;
		}
		set
		{
			_prop = value;
		}
	}

	public string? LastFileHash { get; private set; }

	public bool Loaded { get; protected set; }

	public virtual string ClassName { get; } = string.IsNullOrEmpty(className) ? typeof(T).Name : className;

	public virtual string ProfilesLocation => Path.Combine(Paths.Base, "Profiles.json");

	public virtual string FileName => ClassName + ".json";

	public virtual string FileLocation => Path.Combine(Paths.Base, FileName);

	public bool IsSaved => File.Exists(FileLocation);

	public bool HasUnsavedChanges
	{
		get
		{
			if (_savedHash == null)
			{
				return true;
			}
			return ComputeHash(Prop) != _savedHash;
		}
	}

	private void RememberImmediateSettings(string contents)
	{
		if (Prop is Settings)
		{
			_savedSettingsSnapshot = JsonNode.Parse(contents)?.AsObject();
		}
	}

	private void PreserveImmediateSettings()
	{
		if (!(Prop is Settings obj) || _savedSettingsSnapshot == null || !File.Exists(FileLocation))
		{
			return;
		}
		JsonObject jsonObject = JsonNode.Parse(File.ReadAllText(FileLocation))?.AsObject();
		if (jsonObject == null)
		{
			return;
		}
		string[] array = new string[2] { "EnableMacrosOnLaunch", "MultiInstanceLaunching" };
		foreach (string text in array)
		{
			PropertyInfo property = typeof(Settings).GetProperty(text);
			bool flag = (bool)property.GetValue(obj);
			if (_savedSettingsSnapshot[text] is JsonValue jsonValue && jsonValue.TryGetValue<bool>(out var value) && value == flag && jsonObject[text] is JsonValue jsonValue2 && jsonValue2.TryGetValue<bool>(out var value2))
			{
				property.SetValue(obj, value2);
			}
		}
	}

	protected virtual string ComputeHash(T obj)
	{
		return FastHash.FromString(JsonSerializer.Serialize(obj, _jsonOptions));
	}

	public virtual bool Load(bool alertFailure = true)
	{
		App.Logger.Info("Loading from " + FileLocation + "...");
		try
		{
			if (File.Exists(FileLocation))
			{
				string text = File.ReadAllText(FileLocation);
				T prop = JsonSerializer.Deserialize<T>(text, _jsonOptions) ?? throw new InvalidOperationException(ClassName + " deserialization returned null.");
				_prop = prop;
				Loaded = true;
				LastFileHash = FastHash.FromString(text);
				_savedHash = ComputeHash(_prop);
				RememberImmediateSettings(text);
				App.Logger.Info("Loaded successfully!");
				return true;
			}
			App.Logger.Error("Could not find " + FileLocation + ".");
			Loaded = true;
			_savedHash = ComputeHash(_prop);
			return false;
		}
		catch (Exception ex)
		{
			App.Logger.Error("Failed to load!");
			App.Logger.Error(ex);
			if (alertFailure)
			{
				string className = ClassName;
				string text2;
				if (className == "Settings")
				{
					text2 = Strings.JsonManager_SettingsLoadFailed;
				}
				else
				{
					text2 = ((!(className == "FastFlagManager")) ? string.Empty : Strings.JsonManager_FastFlagsLoadFailed);
				}
				string text3 = text2;
				if (!string.IsNullOrEmpty(text3))
				{
					Frontend.ShowMessageBox(text3 + "\n\n" + ex.Message, MessageBoxImage.Warning);
				}
				try
				{
					if (File.Exists(FileLocation))
					{
						File.Copy(FileLocation, FileLocation + ".bak", overwrite: true);
					}
				}
				catch (Exception value)
				{
					App.Logger.Error("Failed to create backup file: " + FileLocation + ".bak");
					App.Logger.Error(value);
				}
			}
			Loaded = true;
			Save();
			return false;
		}
	}

	public virtual bool Save()
	{
		if (!HasUnsavedChanges)
		{
			App.Logger.Info("No changes, skipping save.");
			return false;
		}
		App.Logger.Info("Saving to " + FileLocation + "...");
		Directory.CreateDirectory(Path.GetDirectoryName(FileLocation));
		try
		{
			PreserveImmediateSettings();
			string text = JsonSerializer.Serialize(Prop, _jsonOptions);
			File.WriteAllText(FileLocation, text);
			LastFileHash = FastHash.FromString(text);
			_savedHash = ComputeHash(Prop);
			RememberImmediateSettings(text);
			App.Logger.Info("Save complete!");
			return true;
		}
		catch (Exception ex) when ((ex is IOException || ex is UnauthorizedAccessException) ? true : false)
		{
			App.Logger.Error("Failed to save");
			App.Logger.Error(ex);
			Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.Bootstrapper_JsonManagerSaveFailed, ClassName, ex.Message), MessageBoxImage.Warning);
			return false;
		}
	}

	public virtual void SaveSetting(string SettingName)
	{
		if (string.IsNullOrEmpty(SettingName))
		{
			Save();
			return;
		}
		App.Logger.Info("Saving setting '" + SettingName + "' to " + FileLocation);
		Directory.CreateDirectory(Path.GetDirectoryName(FileLocation));
		try
		{
			JsonObject jsonObject = new JsonObject();
			if (File.Exists(FileLocation))
			{
				string text = File.ReadAllText(FileLocation);
				if (!string.IsNullOrWhiteSpace(text))
				{
					using JsonDocument jsonDocument = JsonDocument.Parse(text);
					jsonObject = JsonSerializer.SerializeToNode(jsonDocument.RootElement)?.AsObject() ?? new JsonObject();
				}
			}
			if ((JsonSerializer.SerializeToNode(Prop, _jsonOptions)?.AsObject() ?? throw new InvalidOperationException("Failed to serialize current object.")).TryGetPropertyValue(SettingName, out JsonNode jsonNode))
			{
				jsonObject[SettingName] = jsonNode?.DeepClone();
				App.Logger.Info("Updated Setting '" + SettingName + "'");
				string text2 = jsonObject.ToJsonString(_jsonOptions);
				File.WriteAllText(FileLocation, text2);
				LastFileHash = FastHash.FromString(text2);
				_savedHash = ComputeHash(JsonSerializer.Deserialize<T>(text2, _jsonOptions));
				RememberImmediateSettings(text2);
				App.Logger.Info("SaveSetting complete!");
			}
			else
			{
				App.Logger.Error("Setting '" + SettingName + "' not found – aborting save.");
			}
		}
		catch (Exception ex) when ((ex is IOException || ex is UnauthorizedAccessException || ex is JsonException) ? true : false)
		{
			App.Logger.Error("Failed to save Setting");
			App.Logger.Error(ex);
		}
	}

	public void UpdateSavedSetting(string name, Func<JsonNode?, JsonNode?> update)
	{
		if (!File.Exists(FileLocation))
		{
			return;
		}
		try
		{
			JsonObject jsonObject = JsonNode.Parse(File.ReadAllText(FileLocation))?.AsObject();
			if (jsonObject != null)
			{
				jsonObject[name] = update(jsonObject[name])?.DeepClone();
				string text = jsonObject.ToJsonString(_jsonOptions);
				File.WriteAllText(FileLocation, text);
				LastFileHash = FastHash.FromString(text);
				_savedHash = ComputeHash(JsonSerializer.Deserialize<T>(text, _jsonOptions));
			}
		}
		catch (Exception ex) when ((ex is IOException || ex is UnauthorizedAccessException || ex is JsonException) ? true : false)
		{
			App.Logger.Error("Failed to update saved setting '" + name + "'");
			App.Logger.Error(ex);
		}
	}

	public virtual void Delete()
	{
		try
		{
			if (File.Exists(FileLocation))
			{
				File.Delete(FileLocation);
				Loaded = false;
				App.Logger.Info("Delete complete!");
			}
			else
			{
				App.Logger.Error("File does not exist on disk");
			}
		}
		catch (Exception ex) when ((ex is IOException || ex is UnauthorizedAccessException) ? true : false)
		{
			App.Logger.Error("Failed to delete");
			App.Logger.Error(ex);
		}
	}

	public async void SaveProfile(string name)
	{
		string savedFlagProfiles = Paths.SavedFlagProfiles;
		try
		{
			if (!string.IsNullOrEmpty(name))
			{
				string path = Path.Combine(savedFlagProfiles, name);
				if (!Directory.Exists(savedFlagProfiles))
				{
					Directory.CreateDirectory(savedFlagProfiles);
				}
				App.Logger.Info("Writing flag profile " + name);
				if (!File.Exists(path))
				{
					File.Create(path).Dispose();
				}
				string contents = JsonSerializer.Serialize(Prop, _jsonOptions);
				File.WriteAllText(path, contents);
			}
		}
		catch (Exception ex)
		{
			await Frontend.ShowMessageBox(ex.Message, MessageBoxImage.Error);
		}
	}

	public async void LoadProfile(string? name, bool? clearFlags)
	{
		string savedFlagProfiles = Paths.SavedFlagProfiles;
		if (string.IsNullOrEmpty(name))
		{
			return;
		}
		try
		{
			if (!Directory.Exists(savedFlagProfiles))
			{
				Directory.CreateDirectory(savedFlagProfiles);
			}
			string text = Directory.GetFiles(savedFlagProfiles).FirstOrDefault((string f) => Path.GetFileName(f) == name) ?? string.Empty;
			if (string.IsNullOrEmpty(text))
			{
				return;
			}
			string text2 = File.ReadAllText(text);
			App.Logger.Info("Loading " + text2);
			T? val = JsonSerializer.Deserialize<T>(text2);
			if (val == null)
			{
				throw new JsonException("Failed to deserialize profile: " + name);
			}
			T val2 = val;
			App.FastFlags.suspendUndoSnapshot = true;
			App.FastFlags.SaveUndoSnapshot();
			if (clearFlags == true)
			{
				Prop = val2;
			}
			else if (val2 is IDictionary<string, object> dictionary && Prop is IDictionary<string, object> dictionary2)
			{
				foreach (KeyValuePair<string, object> item in dictionary)
				{
					if (item.Value != null)
					{
						dictionary2[item.Key] = item.Value;
					}
				}
			}
			App.FastFlags.suspendUndoSnapshot = false;
			App.FastFlags.Save();
		}
		catch (Exception ex)
		{
			await Frontend.ShowMessageBox(ex.Message, MessageBoxImage.Error);
		}
	}

	public async void LoadPresetProfile(string? name, bool? clearFlags)
	{
		if (string.IsNullOrEmpty(name))
		{
			return;
		}
		try
		{
			Assembly executingAssembly = Assembly.GetExecutingAssembly();
			string text = "Merostrap.Resources.PresetFlags.";
			string resourceFullName = text + name;
			string text2 = executingAssembly.GetManifestResourceNames().FirstOrDefault((string r) => r.Equals(resourceFullName, StringComparison.OrdinalIgnoreCase));
			string json;
			if (text2 != null)
			{
				using Stream stream = executingAssembly.GetManifestResourceStream(text2);
				using StreamReader streamReader = new StreamReader(stream);
				json = streamReader.ReadToEnd();
				App.Logger.Info("Loading embedded preset profile " + name);
			}
			else
			{
				string savedFlagProfiles = Paths.SavedFlagProfiles;
				if (!Directory.Exists(savedFlagProfiles))
				{
					Directory.CreateDirectory(savedFlagProfiles);
				}
				string? obj = Directory.GetFiles(savedFlagProfiles).FirstOrDefault((string f) => Path.GetFileName(f) == name) ?? string.Empty;
				if (string.IsNullOrEmpty(obj))
				{
					throw new FileNotFoundException("Profile file '" + name + "' not found.");
				}
				json = File.ReadAllText(obj);
				App.Logger.Info("Loading user profile from file " + name);
			}
			T? val = JsonSerializer.Deserialize<T>(json);
			if (val == null)
			{
				throw new ArgumentNullException("name", "Deserialization returned null");
			}
			T val2 = val;
			App.FastFlags.suspendUndoSnapshot = true;
			App.FastFlags.SaveUndoSnapshot();
			if (clearFlags == true)
			{
				Prop = val2;
			}
			else if (val2 is IDictionary<string, object> dictionary && Prop is IDictionary<string, object> dictionary2)
			{
				foreach (KeyValuePair<string, object> item in dictionary)
				{
					if (item.Value != null)
					{
						dictionary2[item.Key] = item.Value;
					}
				}
			}
			App.FastFlags.suspendUndoSnapshot = false;
			App.FastFlags.Save();
		}
		catch (Exception ex)
		{
			await Frontend.ShowMessageBox(ex.Message, MessageBoxImage.Error);
		}
	}

	public bool HasFileOnDiskChanged()
	{
		if (!File.Exists(FileLocation))
		{
			return !string.IsNullOrEmpty(LastFileHash);
		}
		if (string.IsNullOrEmpty(LastFileHash) && File.Exists(FileLocation))
		{
			return true;
		}
		return LastFileHash != FastHash.FromFile(FileLocation);
	}
}
