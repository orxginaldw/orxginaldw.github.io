using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Interactivity;
using Avalonia.Threading;
using Merostrap.Access;
using Merostrap.Enums;
using Merostrap.Enums.Messagebox;
using Merostrap.Extensions;
using Merostrap.Integrations;
using Merostrap.Resources;
using Merostrap.UI;
using Merostrap.UI.Elements.Dialogs;
using Merostrap.UI.Elements.Onboarding;
using Merostrap.UI.Elements.Settings;
using Merostrap.Updates;
using Merostrap.Utility;

namespace Merostrap;

internal static class LaunchHandler
{
	private static int _activationInFlight;

	public static async void ProcessNextAction(NextAction action)
	{
		NextAction nextAction = action;
		bool flag = ((nextAction == NextAction.Terminate || nextAction == NextAction.LaunchRoblox || nextAction == NextAction.LaunchRobloxStudio) ? true : false);
		bool flag2 = !flag;
		if (flag2)
		{
			flag2 = !(await AccessGate.EnsureAsync(silent: false, action == NextAction.SignIn));
		}
		if (flag2)
		{
			App.Terminate();
			return;
		}
		nextAction = action;
		flag2 = ((nextAction == NextAction.LaunchSettings || (uint)(nextAction - 3) <= 1u) ? true : false);
		flag = flag2;
		if (flag)
		{
			flag = await AutomaticUpdater.TryUpdateAsync();
		}
		if (!flag)
		{
			switch (action)
			{
			case NextAction.LaunchMenu:
			case NextAction.SignIn:
				LaunchMenu();
				break;
			case NextAction.LaunchSettings:
				App.Logger.Info("Opening settings");
				LaunchSettings();
				break;
			case NextAction.LaunchRoblox:
				App.Logger.Info("Opening Roblox");
				LaunchRoblox(LaunchMode.Player);
				break;
			case NextAction.LaunchRobloxStudio:
				App.Logger.Info("Opening Roblox Studio");
				LaunchRoblox(LaunchMode.Studio);
				break;
			default:
				App.Logger.Info("Closing");
				App.Terminate();
				break;
			}
		}
	}

	public static async Task ProcessLaunchArgs()
	{
		if (App.LaunchSettings.OnboardingFlag.Active)
		{
			LaunchOnboarding();
			return;
		}
		bool directGameLaunch = App.LaunchSettings.RobloxLaunchMode != LaunchMode.None && !App.LaunchSettings.OnboardingFlag.Active && !App.LaunchSettings.MenuFlag.Active && !App.LaunchSettings.WatcherFlag.Active && !App.LaunchSettings.BackgroundUpdaterFlag.Active;
		bool flag = !directGameLaunch;
		if (flag)
		{
			flag = !(await AccessGate.EnsureAsync(App.LaunchSettings.QuietFlag.Active || App.LaunchSettings.WatcherFlag.Active || App.LaunchSettings.BackgroundUpdaterFlag.Active));
		}
		if (flag)
		{
			App.Terminate();
			return;
		}
		flag = !directGameLaunch;
		if (flag)
		{
			flag = await AutomaticUpdater.TryUpdateAsync();
		}
		if (!flag)
		{
			if (App.LaunchSettings.OnboardingFlag.Active)
			{
				App.Logger.Info("Opening onboarding");
				LaunchOnboarding();
			}
			else if (App.LaunchSettings.MenuFlag.Active)
			{
				App.Logger.Info("Opening settings");
				LaunchSettings();
			}
			else if (App.LaunchSettings.WatcherFlag.Active)
			{
				App.Logger.Info("Opening watcher");
				LaunchWatcher();
			}
			else if (App.LaunchSettings.BackgroundUpdaterFlag.Active)
			{
				App.Logger.Info("Opening background updater");
				await LaunchBackgroundUpdater();
			}
			else if (App.LaunchSettings.RobloxLaunchMode != LaunchMode.None)
			{
				App.Logger.Info($"Opening bootstrapper ({App.LaunchSettings.RobloxLaunchMode})");
				LaunchRoblox(App.LaunchSettings.RobloxLaunchMode);
			}
			else if (!App.LaunchSettings.QuietFlag.Active)
			{
				App.Logger.Info("Opening menu");
				LaunchMenu();
			}
			else
			{
				App.Logger.Info("Closing - quiet flag active");
				App.Terminate();
			}
		}
	}

	public static void LaunchSettings()
	{
		InterProcessLock interlock = new InterProcessLock("Settings");
		try
		{
			if (!interlock.IsAcquired)
			{
				interlock.Dispose();
				App.Logger.Info("Found an already existing menu window");
				using EventWaitHandle eventWaitHandle = new EventWaitHandle(initialState: false, EventResetMode.AutoReset, "Merostrap-ActivateSettingsEvent");
				eventWaitHandle.Set();
				App.Terminate();
				return;
			}
			Merostrap.UI.Elements.Settings.MainWindow window = new Merostrap.UI.Elements.Settings.MainWindow(showAlreadyRunningWarning: false);
			window.Loaded += (object? s, RoutedEventArgs e) =>
			{
				Task.Run(() => App.PlayerState.Load());
				Task.Run(() => App.StudioState.Load());
				if (!string.IsNullOrEmpty("") && App.Settings.Prop.ShowUsingMerostrapRPC && App.FrostRPC == null)
				{
					App.FrostRPC = new MerostrapRichPresence();
				}
			};
			window.Closed += (object? s, EventArgs e) =>
			{
				interlock.Dispose();
				App.FrostRPC = null;
				ProcessNextAction(window.CloseAction);
			};
			window.Show();
		}
		finally
		{
			if (interlock != null)
			{
				((IDisposable)interlock).Dispose();
			}
		}
	}

	public static void LaunchMenu()
	{
		LaunchMenuDialog dialog = new LaunchMenuDialog();
		dialog.Loaded += (object? s, RoutedEventArgs e) =>
		{
			if (!string.IsNullOrEmpty("") && App.Settings.Prop.ShowUsingMerostrapRPC && App.FrostRPC == null)
			{
				App.FrostRPC = new MerostrapRichPresence();
				App.FrostRPC.SetPage("Launch Menu");
			}
		};
		dialog.Closed += (object? sender, EventArgs e) =>
		{
			App.FrostRPC = null;
			ProcessNextAction(dialog.CloseAction);
		};
		dialog.Show();
	}

	public static void LaunchOnboarding()
	{
		Merostrap.UI.Elements.Onboarding.MainWindow mainWindow = new Merostrap.UI.Elements.Onboarding.MainWindow();
		if (Application.Current?.ApplicationLifetime is IClassicDesktopStyleApplicationLifetime classicDesktopStyleApplicationLifetime)
		{
			classicDesktopStyleApplicationLifetime.MainWindow = mainWindow;
		}
		mainWindow.Loaded += (object? s, RoutedEventArgs e) =>
		{
			if (!string.IsNullOrEmpty("") && App.Settings.Prop.ShowUsingMerostrapRPC && App.FrostRPC == null)
			{
				App.FrostRPC = new MerostrapRichPresence();
				App.FrostRPC.SetPage("Onboarding");
			}
		};
		mainWindow.Show();
		mainWindow.Closed += (object? s, EventArgs ev) =>
		{
			if (mainWindow.Completed)
			{
				App.State.Prop.IsFirstLaunch = false;
			}
			App.State.Save();
			App.Settings.Save();
			ProcessNextAction(mainWindow.CloseAction);
		};
	}

	public static async Task LaunchRoblox(LaunchMode launchMode)
	{
		if (!(await AccessGate.EnsureAsync(App.LaunchSettings.QuietFlag.Active)))
		{
			App.Terminate();
		}
		else
		{
			if (await AutomaticUpdater.TryUpdateAsync())
			{
				return;
			}
			if (launchMode == LaunchMode.None)
			{
				throw new InvalidOperationException("No Roblox launch mode set");
			}
			if (OperatingSystem.IsWindows() && !File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "mfplat.dll")))
			{
				await Frontend.ShowMessageBox(Strings.Bootstrapper_WMFNotFound, MessageBoxImage.Error);
				if (!App.LaunchSettings.QuietFlag.Active)
				{
					Threading.ShellExecute("https://support.microsoft.com/en-us/topic/media-feature-pack-list-for-windows-n-editions-c1c6fffa-d052-8338-7a79-a4bb980a700a");
				}
				App.Terminate(ErrorCode.ERROR_FILE_NOT_FOUND);
			}
			if (App.Settings.Prop.ConfirmLaunches && Processes.IsRobloxRunning() && launchMode == LaunchMode.Player && (!OperatingSystem.IsWindows() || !App.Settings.Prop.MultiInstanceLaunching) && await Frontend.ShowMessageBox(Strings.Bootstrapper_ConfirmLaunch, MessageBoxImage.Warning, MessageBoxButton.YesNo) != MessageBoxResult.Yes)
			{
				App.Terminate();
				return;
			}
			bool useFastFlagsForLaunch = true;
			if (FastFlagLaunchChoice.ShouldAsk(App.Settings.Prop.AskBeforeUsingFastFlags, launchMode == LaunchMode.Player, App.LaunchSettings.QuietFlag.Active, App.LaunchSettings.RobloxLaunchArgs) && !OperatingSystem.IsLinux())
			{
				MessageBoxResult messageBoxResult = await Frontend.ShowMessageBox("Would you like to open the game with FastFlags?", MessageBoxImage.Question, MessageBoxButton.YesNo);
				if (messageBoxResult != MessageBoxResult.Yes && messageBoxResult != MessageBoxResult.No)
				{
					App.Terminate();
					return;
				}
				useFastFlagsForLaunch = messageBoxResult == MessageBoxResult.Yes;
			}
			App.Logger.Info("Initializing bootstrapper");
			App.Bootstrapper = new Bootstrapper(launchMode)
			{
				UseFastFlagsForLaunch = useFastFlagsForLaunch
			};
			IBootstrapperDialog bootstrapperDialog = null;
			if (!App.LaunchSettings.QuietFlag.Active)
			{
				try
				{
					App.Logger.Info("Initializing bootstrapper dialog");
					ThemeCycler.HandleLaunchCycle();
					bootstrapperDialog = await App.Settings.Prop.BootstrapperStyle.GetNew();
					App.Bootstrapper.Dialog = bootstrapperDialog;
					bootstrapperDialog.Bootstrapper = App.Bootstrapper;
				}
				catch (Exception exception)
				{
					App.Logger.Error(exception, "Failed to create the bootstrapper dialog, launching without one");
					App.Bootstrapper.Dialog = null;
					bootstrapperDialog = null;
				}
			}
			Task.Run((Func<Task?>)App.Bootstrapper.Run).ContinueWith((Func<Task, Task>)(async (Task t) =>
			{
				App.Logger.Info("Bootstrapper task has finished");
				if (t.IsFaulted)
				{
					App.Logger.Error("An exception occurred when running the bootstrapper");
					if (t.Exception != null)
					{
						await App.FinalizeExceptionHandling(t.Exception);
					}
				}
				App.Terminate();
			}), TaskScheduler.Default);
			try
			{
				bootstrapperDialog?.ShowBootstrapper();
			}
			catch (Exception exception2)
			{
				App.Logger.Error(exception2, "Failed to show the bootstrapper dialog, continuing without it");
				App.Bootstrapper.Dialog = null;
			}
			App.Logger.Info("Exiting");
		}
	}

	public static void LaunchWatcher()
	{
		Watcher watcher = new Watcher();
		Task.Run((Func<Task?>)watcher.Run).ContinueWith((Func<Task, Task>)(async (Task t) =>
		{
			App.Logger.Info("Watcher task has finished");
			watcher.Dispose();
			if (t.IsFaulted)
			{
				App.Logger.Error("An exception occurred when running the watcher");
				if (t.Exception != null)
				{
					await App.FinalizeExceptionHandling(t.Exception);
				}
			}
			if (App.Settings.Prop.CleanerOptions != CleanerOptions.Never)
			{
				Cleaner.DoCleaning();
			}
			App.Terminate();
		}), TaskScheduler.Default);
	}

	public static async Task LaunchBackgroundUpdater()
	{
		if (App.Settings.Prop.Performance.UseQuietDownloads)
		{
			App.Logger.Info("Background updates are disabled by the current performance/network settings.");
			App.Terminate();
			return;
		}
		App.LaunchSettings.QuietFlag.Active = true;
		App.LaunchSettings.NoLaunchFlag.Active = true;
		App.Logger.Info("Initializing bootstrapper");
		App.Bootstrapper = new Bootstrapper(LaunchMode.Player)
		{
			LockName = "BackgroundUpdater",
			QuitIfLockExists = true
		};
		CancellationTokenSource cts = new CancellationTokenSource();
		try
		{
			await Task.Run(() =>
			{
				App.Logger.Info("Started event waiter");
				using (EventWaitHandle eventWaitHandle = new EventWaitHandle(initialState: false, EventResetMode.AutoReset, "Merostrap-BackgroundUpdaterKillEvent"))
				{
					eventWaitHandle.WaitOne();
				}
				App.Logger.Info("Received close event, killing it all!");
				App.Bootstrapper.Cancel();
			}, cts.Token);
			await Task.Run((Func<Task?>)App.Bootstrapper.Run).ContinueWith((Func<Task, Task>)(async (Task t) =>
			{
				App.Logger.Info("Bootstrapper task has finished");
				await cts.CancelAsync();
				if (t.IsFaulted)
				{
					App.Logger.Error("An exception occurred when running the bootstrapper");
					if (t.Exception != null)
					{
						await App.FinalizeExceptionHandling(t.Exception);
					}
				}
				App.Terminate();
			}), TaskScheduler.Default);
			App.Logger.Info("Exiting");
		}
		finally
		{
			if (cts != null)
			{
				((IDisposable)cts).Dispose();
			}
		}
	}

	public static void HandleActivationUri(string uri)
	{
		if (!App.LaunchSettings.TryResolveRobloxUri(new _003C_003Ez__ReadOnlySingleElementList<string>(uri)))
		{
			App.Logger.Info("Ignoring unrecognized activation URI: " + uri);
			return;
		}
		if (Interlocked.CompareExchange(ref _activationInFlight, 1, 0) != 0)
		{
			App.Logger.Info("A launch is already being handled, ignoring activation");
			return;
		}
		LaunchMode mode = App.LaunchSettings.RobloxLaunchMode;
		App.Logger.Info($"Handling activation URI as a Roblox launch ({mode})");
		Dispatcher.UIThread.Post(() =>
		{
			LaunchRoblox(mode);
		});
	}
}
