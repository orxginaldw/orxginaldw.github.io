using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.Versioning;
using System.Threading.Tasks;
using LucideAvalonia.Enum;
using Merostrap.Enums.FlagPresets;
using Merostrap.Enums.Messagebox;
using Merostrap.Models;
using Merostrap.UI;

namespace Merostrap;

internal class FastFlagManager : JsonManager<Dictionary<string, object>>
{
	private Dictionary<string, object> OriginalProp = new Dictionary<string, object>();

	public static readonly IReadOnlyDictionary<string, string> PresetFlags = new Dictionary<string, string>
	{
		{ "Rendering.ManualFullscreen", "FFlagHandleAltEnterFullscreenManually" },
		{ "Rendering.PauseVoxerlizer", "DFFlagDebugPauseVoxelizer" },
		{ "Rendering.DisableScaling", "DFFlagDisableDPIScale" },
		{ "Rendering.TextureQuality.OverrideEnabled", "DFFlagTextureQualityOverrideEnabled" },
		{ "Rendering.TextureQuality.Level", "DFIntTextureQualityOverride" },
		{ "Rendering.FrmQuality", "DFIntDebugFRMQualityLevelOverride" },
		{ "Rendering.LowPolyMeshes1", "DFIntCSGLevelOfDetailSwitchingDistance" },
		{ "Rendering.LowPolyMeshes2", "DFIntCSGLevelOfDetailSwitchingDistanceL12" },
		{ "Rendering.LowPolyMeshes3", "DFIntCSGLevelOfDetailSwitchingDistanceL23" },
		{ "Rendering.LowPolyMeshes4", "DFIntCSGLevelOfDetailSwitchingDistanceL34" },
		{ "Rendering.Mode.D3D11", "FFlagDebugGraphicsPreferD3D11" },
		{ "Rendering.Mode.Vulkan", "FFlagDebugGraphicsPreferVulkan" },
		{ "Rendering.Mode.OpenGL", "FFlagDebugGraphicsPreferOpenGL" },
		{ "Graphic.GraySky", "FFlagDebugSkyGray" },
		{ "Rendering.MSAA1", "FIntDebugForceMSAASamples" },
		{ "Rendering.RemoveGrass1", "FIntFRMMinGrassDistance" },
		{ "Rendering.RemoveGrass2", "FIntFRMMaxGrassDistance" },
		{ "Rendering.RemoveGrass3", "FIntGrassMovementReducedMotionFactor" }
	};

	public bool suspendUndoSnapshot;

	private readonly Stack<Dictionary<string, object>> undoStack = new Stack<Dictionary<string, object>>();

	private readonly Stack<Dictionary<string, object>> redoStack = new Stack<Dictionary<string, object>>();

	public override string ClassName => "FastFlagManager";

	public override string ProfilesLocation => Paths.SavedFlagProfiles;

	public override string FileName => "ClientAppSettings.json";

	public override string FileLocation => Path.Combine(Paths.Modifications, "ClientSettings", FileName);

	public bool Changed => !OriginalProp.SequenceEqual(Prop);

	public static IReadOnlyDictionary<RenderingMode, string> RenderingModes => new Dictionary<RenderingMode, string>
	{
		{
			RenderingMode.Default,
			"None"
		},
		{
			RenderingMode.Direct3D,
			"D3D11"
		},
		{
			RenderingMode.Vulkan,
			"Vulkan"
		},
		{
			RenderingMode.OpenGL,
			"OpenGL"
		}
	};

	public static IReadOnlyDictionary<TextureQuality, string?> TextureQualityLevels => new Dictionary<TextureQuality, string>
	{
		{
			TextureQuality.Default,
			null
		},
		{
			TextureQuality.Medium,
			"2"
		},
		{
			TextureQuality.Low,
			"1"
		},
		{
			TextureQuality.Lowest,
			"0"
		}
	};

	public static IReadOnlyDictionary<MSAAMode, string?> MSAAModes => new Dictionary<MSAAMode, string>
	{
		{
			MSAAMode.Default,
			null
		},
		{
			MSAAMode.x1,
			"1"
		},
		{
			MSAAMode.x2,
			"2"
		},
		{
			MSAAMode.x4,
			"4"
		}
	};

	public static IReadOnlyDictionary<QualityLevel, string?> QualityLevels => new Dictionary<QualityLevel, string>
	{
		{
			QualityLevel.Disabled,
			null
		},
		{
			QualityLevel.Level1,
			"1"
		},
		{
			QualityLevel.Level2,
			"2"
		},
		{
			QualityLevel.Level3,
			"3"
		},
		{
			QualityLevel.Level4,
			"4"
		},
		{
			QualityLevel.Level5,
			"5"
		},
		{
			QualityLevel.Level6,
			"6"
		},
		{
			QualityLevel.Level7,
			"7"
		},
		{
			QualityLevel.Level8,
			"8"
		},
		{
			QualityLevel.Level9,
			"9"
		},
		{
			QualityLevel.Level10,
			"10"
		},
		{
			QualityLevel.Level11,
			"11"
		},
		{
			QualityLevel.Level12,
			"12"
		},
		{
			QualityLevel.Level13,
			"13"
		},
		{
			QualityLevel.Level14,
			"14"
		},
		{
			QualityLevel.Level15,
			"15"
		},
		{
			QualityLevel.Level16,
			"16"
		},
		{
			QualityLevel.Level17,
			"17"
		},
		{
			QualityLevel.Level18,
			"18"
		},
		{
			QualityLevel.Level19,
			"19"
		},
		{
			QualityLevel.Level20,
			"20"
		},
		{
			QualityLevel.Level21,
			"21"
		}
	};

	public void SetValue(string key, object? value)
	{
		if (!suspendUndoSnapshot)
		{
			SaveUndoSnapshot();
		}
		if (value == null)
		{
			if (Prop.ContainsKey(key))
			{
				App.Logger.Info("Deletion of '" + key + "' is pending");
			}
			Prop.Remove(key);
			return;
		}
		if (Prop.TryGetValue(key, out object value2))
		{
			if (string.Equals(value.ToString(), value2?.ToString(), StringComparison.Ordinal))
			{
				return;
			}
			App.Logger.Info($"Changing of '{key}' from '{value2}' to '{value}' is pending");
		}
		else
		{
			App.Logger.Info($"Setting of '{key}' to '{value}' is pending");
		}
		Prop[key] = value.ToString();
	}

	public string? GetValue(string key)
	{
		if (Prop.TryGetValue(key, out object value) && value != null)
		{
			return value.ToString();
		}
		return null;
	}

	public void SetPreset(string prefix, object? value)
	{
		foreach (KeyValuePair<string, string> item in PresetFlags.Where((KeyValuePair<string, string> x) => x.Key.StartsWith(prefix, StringComparison.Ordinal)))
		{
			SetValue(item.Value, value);
		}
	}

	public void SetPresetEnum(string prefix, string target, object? value)
	{
		foreach (KeyValuePair<string, string> item in PresetFlags.Where((KeyValuePair<string, string> x) => x.Key.StartsWith(prefix, StringComparison.Ordinal)))
		{
			if (item.Key.StartsWith(prefix + "." + target, StringComparison.Ordinal))
			{
				SetValue(item.Value, value);
			}
			else
			{
				SetValue(item.Value, null);
			}
		}
	}

	public string? GetPreset(string name)
	{
		if (!PresetFlags.TryGetValue(name, out string value))
		{
			App.Logger.Error("Could not find preset " + name);
			return null;
		}
		return GetValue(value);
	}

	public T GetPresetEnum<T>(IReadOnlyDictionary<T, string> mapping, string prefix, string value) where T : Enum
	{
		foreach (KeyValuePair<T, string> item in mapping)
		{
			if (!(item.Value == "None") && GetPreset(prefix + "." + item.Value) == value)
			{
				return item.Key;
			}
		}
		return mapping.First().Key;
	}

	public static bool IsPreset(string flag)
	{
		return PresetFlags.Values.Any((string v) => string.Equals(v, flag, StringComparison.OrdinalIgnoreCase));
	}

	public override bool Save()
	{
		foreach (string item in Prop.Keys.ToList())
		{
			Prop[item] = Prop[item].ToString();
		}
		bool flag = base.Save();
		if (flag)
		{
			OriginalProp = new Dictionary<string, object>(Prop);
			if (OperatingSystem.IsLinux())
			{
				SyncToSoberConfig();
			}
		}
		return flag;
	}

	[SupportedOSPlatform("linux")]
	private void SyncToSoberConfig()
	{
		try
		{
			if (!App.SoberSettings.Loaded)
			{
				App.SoberSettings.Load(alertFailure: false);
			}
			Dictionary<string, object> orCreateFFlagsContainer = App.SoberSettings.GetOrCreateFFlagsContainer();
			foreach (KeyValuePair<string, object> item in Prop)
			{
				string text = item.Value?.ToString() ?? "";
				long result2;
				double result3;
				if (bool.TryParse(text, out var result))
				{
					orCreateFFlagsContainer[item.Key] = result;
				}
				else if (long.TryParse(text, out result2))
				{
					orCreateFFlagsContainer[item.Key] = result2;
				}
				else if (double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out result3))
				{
					orCreateFFlagsContainer[item.Key] = result3;
				}
				else
				{
					orCreateFFlagsContainer[item.Key] = text;
				}
			}
			App.SoberSettings.Save();
			App.Logger.Info($"Successfully synced {orCreateFFlagsContainer.Count} flags.");
		}
		catch (Exception value)
		{
			App.Logger.Error($"Failed to sync flags: {value}");
		}
	}

	public override bool Load(bool alertFailure = true)
	{
		bool result = base.Load(alertFailure);
		OriginalProp = new Dictionary<string, object>(Prop);
		if (GetPreset("Rendering.ManualFullscreen") != "False")
		{
			SetPreset("Rendering.ManualFullscreen", "False");
		}
		return result;
	}

	public static async Task DeleteProfile(string profile)
	{
		try
		{
			string savedFlagProfiles = Paths.SavedFlagProfiles;
			if (!Directory.Exists(savedFlagProfiles))
			{
				Directory.CreateDirectory(savedFlagProfiles);
			}
			if (!string.IsNullOrEmpty(profile))
			{
				File.Delete(Path.Combine(savedFlagProfiles, profile));
			}
		}
		catch (Exception ex)
		{
			await Frontend.ShowMessageBox(ex.Message, MessageBoxImage.Error);
		}
	}

	public IEnumerable<FastFlag> GetAllFlags()
	{
		foreach (KeyValuePair<string, object> item in Prop)
		{
			yield return new FastFlag
			{
				Name = item.Key,
				Value = (item.Value?.ToString() ?? ""),
				Preset = LucideIconNames.Minus
			};
		}
	}

	public void SaveUndoSnapshot()
	{
		if (undoStack.Count <= 0 || !DictionaryEquals(undoStack.Peek(), Prop))
		{
			undoStack.Push(new Dictionary<string, object>(Prop));
			redoStack.Clear();
		}
	}

	private static bool DictionaryEquals(Dictionary<string, object> a, Dictionary<string, object> b)
	{
		if (a.Count != b.Count)
		{
			return false;
		}
		foreach (KeyValuePair<string, object> item in a)
		{
			if (!b.TryGetValue(item.Key, out object value))
			{
				return false;
			}
			if (!object.Equals(item.Value, value))
			{
				return false;
			}
		}
		return true;
	}

	public void Undo()
	{
		if (undoStack.Count == 0)
		{
			return;
		}
		redoStack.Push(new Dictionary<string, object>(Prop));
		Dictionary<string, object> dictionary = undoStack.Pop();
		Prop.Clear();
		foreach (KeyValuePair<string, object> item in dictionary)
		{
			Prop[item.Key] = item.Value;
		}
	}

	public void Redo()
	{
		if (redoStack.Count == 0)
		{
			return;
		}
		undoStack.Push(new Dictionary<string, object>(Prop));
		Dictionary<string, object> dictionary = redoStack.Pop();
		Prop.Clear();
		foreach (KeyValuePair<string, object> item in dictionary)
		{
			Prop[item.Key] = item.Value;
		}
	}

	public FastFlagManager()
		: base((string?)null)
	{
	}
}
