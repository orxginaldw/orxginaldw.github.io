using System;
using System.Runtime.Versioning;
using Merostrap.Enums;
using Merostrap.Enums.Messagebox;
using Merostrap.Resources;
using Merostrap.UI;
using Microsoft.Win32;

namespace Merostrap.Extensions;

[SupportedOSPlatform("windows")]
internal static class RegistryKeyHelpers
{
	[SupportedOSPlatform("windows")]
	public static async void SetValueSafe(this RegistryKey registryKey, string? name, object value)
	{
		ArgumentNullException.ThrowIfNull(registryKey, "registryKey");
		ArgumentNullException.ThrowIfNull(value, "value");
		try
		{
			App.Logger.Info($"Writing '{value}' to {registryKey}\\{name}");
			registryKey.SetValue(name, value);
		}
		catch (UnauthorizedAccessException)
		{
			await Frontend.ShowMessageBox(Strings.Dialog_RegistryWriteError, MessageBoxImage.Error);
			App.Terminate(ErrorCode.ERROR_INSTALL_FAILURE);
		}
		catch (ArgumentNullException) when (name == null)
		{
			App.Logger.Error("Cannot set registry value with null name");
			await Frontend.ShowMessageBox(Strings.Dialog_RegistryWriteError, MessageBoxImage.Error);
			App.Terminate(ErrorCode.ERROR_INSTALL_FAILURE);
		}
	}

	[SupportedOSPlatform("windows")]
	public static async void DeleteValueSafe(this RegistryKey registryKey, string name)
	{
		ArgumentNullException.ThrowIfNull(registryKey, "registryKey");
		ArgumentNullException.ThrowIfNull(name, "name");
		try
		{
			App.Logger.Info($"Deleting {registryKey}\\{name}");
			registryKey.DeleteValue(name);
		}
		catch (UnauthorizedAccessException)
		{
			await Frontend.ShowMessageBox(Strings.Dialog_RegistryWriteError, MessageBoxImage.Error);
			App.Terminate(ErrorCode.ERROR_INSTALL_FAILURE);
		}
		catch (ArgumentException)
		{
			App.Logger.Error($"Registry value '{name}' does not exist in {registryKey}");
		}
	}
}
