using System.Collections.Generic;
using Merostrap.Enums;

namespace Merostrap.Extensions;

internal static class CleanerOptionsEx
{
	public static IReadOnlyCollection<CleanerOptions> Selections => new _003C_003Ez__ReadOnlyArray<CleanerOptions>(new CleanerOptions[5]
	{
		CleanerOptions.Never,
		CleanerOptions.OneDay,
		CleanerOptions.OneWeek,
		CleanerOptions.OneMonth,
		CleanerOptions.TwoMonths
	});
}
