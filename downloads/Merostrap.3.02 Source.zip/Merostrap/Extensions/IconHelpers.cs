using System;
using System.Globalization;
using System.IO;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Merostrap.Enums;
using Merostrap.Resources;
using Merostrap.UI;

namespace Merostrap.Extensions;

internal static class IconHelpers
{
	public static Bitmap GetSized(this Bitmap bitmap, int width, int height)
	{
		ArgumentNullException.ThrowIfNull(bitmap, "bitmap");
		return bitmap.CreateScaledBitmap(new PixelSize(width, height));
	}

	public static IImage GetImageSource(this Bitmap bitmap)
	{
		ArgumentNullException.ThrowIfNull(bitmap, "bitmap");
		return bitmap;
	}

	public static async Task<Bitmap> GetBitmapFromStream(Stream stream, bool handleException = true)
	{
		ArgumentNullException.ThrowIfNull(stream, "stream");
		if (handleException)
		{
			try
			{
				stream.Seek(0L, SeekOrigin.Begin);
				return new Bitmap(stream);
			}
			catch (Exception ex)
			{
				App.Logger.Error("Unhandled exception: ", ex);
				await Frontend.ShowMessageBox(string.Format(CultureInfo.CurrentCulture, Strings.Dialog_IconLoadFailed, ex.Message));
				return RobloxIcon.IconDefault.GetIcon();
			}
		}
		stream.Seek(0L, SeekOrigin.Begin);
		return new Bitmap(stream);
	}
}
