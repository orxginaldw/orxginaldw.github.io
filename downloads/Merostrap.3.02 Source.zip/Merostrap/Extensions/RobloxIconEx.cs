using System;
using System.Collections.Generic;
using System.IO;
using Avalonia.Media.Imaging;
using Avalonia.Platform;
using Merostrap.Enums;
using Windows.Win32;
using Windows.Win32.UI.WindowsAndMessaging;

namespace Merostrap.Extensions;

internal static class RobloxIconEx
{
	private static readonly Dictionary<RobloxIcon, Bitmap> _cache = new Dictionary<RobloxIcon, Bitmap>();

	private static readonly Dictionary<RobloxIcon, nint> _hIconCache = new Dictionary<RobloxIcon, nint>();

	public static IReadOnlyCollection<RobloxIcon> Selections => new _003C_003Ez__ReadOnlyArray<RobloxIcon>(new RobloxIcon[9]
	{
		RobloxIcon.IconDefault,
		RobloxIcon.Icon2022,
		RobloxIcon.Icon2019,
		RobloxIcon.Icon2017,
		RobloxIcon.IconLate2015,
		RobloxIcon.IconEarly2015,
		RobloxIcon.Icon2011,
		RobloxIcon.Icon2008,
		RobloxIcon.IconCustom
	});

	public static Bitmap GetIcon(this RobloxIcon icon)
	{
		if (_cache.TryGetValue(icon, out Bitmap value))
		{
			return value;
		}
		Bitmap bitmap;
		switch (icon)
		{
		case RobloxIcon.IconCustom:
		{
			Bitmap bitmap2 = null;
			string robloxIconCustomLocation = App.Settings.Prop.RobloxIconCustomLocation;
			if (string.IsNullOrEmpty(robloxIconCustomLocation))
			{
				App.Logger.Warn("Custom icon is not set.");
			}
			else
			{
				try
				{
					bitmap2 = LoadIconFromFile(robloxIconCustomLocation);
				}
				catch (Exception value2)
				{
					App.Logger.Error($"Failed to load custom icon! {value2}");
				}
			}
			Bitmap bitmap3 = bitmap2 ?? LoadFromResource("Icon2025");
			_cache[icon] = bitmap3;
			return bitmap3;
		}
		case RobloxIcon.Icon2008:
			bitmap = LoadFromResource("Icon2008");
			break;
		case RobloxIcon.Icon2011:
			bitmap = LoadFromResource("Icon2011");
			break;
		case RobloxIcon.IconEarly2015:
			bitmap = LoadFromResource("IconEarly2015");
			break;
		case RobloxIcon.IconLate2015:
			bitmap = LoadFromResource("IconLate2015");
			break;
		case RobloxIcon.Icon2017:
			bitmap = LoadFromResource("Icon2017");
			break;
		case RobloxIcon.Icon2019:
			bitmap = LoadFromResource("Icon2019");
			break;
		case RobloxIcon.Icon2022:
			bitmap = LoadFromResource("Icon2022");
			break;
		default:
			bitmap = LoadFromResource("Icon2025");
			break;
		}
		Bitmap bitmap4 = bitmap;
		_cache[icon] = bitmap4;
		return bitmap4;
	}

	public unsafe static nint GetHIcon(this RobloxIcon icon)
	{
		if (_hIconCache.TryGetValue(icon, out var value))
		{
			return value;
		}
		HICON hICON = IcoBytesToHIcon(LoadIconBytes(icon));
		if (hICON != HICON.Null)
		{
			_hIconCache[icon] = (nint)hICON.Value;
		}
		return (nint)hICON.Value;
	}

	private static Bitmap LoadFromResource(string name)
	{
		using Stream stream = AssetLoader.Open(new Uri("avares://Merostrap/Resources/" + name + ".ico"));
		return new Bitmap(stream);
	}

	private static Bitmap LoadIconFromFile(string path)
	{
		using FileStream stream = File.OpenRead(path);
		return new Bitmap(stream);
	}

	private static byte[] LoadIconBytes(RobloxIcon icon)
	{
		string name;
		switch (icon)
		{
		case RobloxIcon.IconCustom:
		{
			string robloxIconCustomLocation = App.Settings.Prop.RobloxIconCustomLocation;
			if (!string.IsNullOrEmpty(robloxIconCustomLocation) && File.Exists(robloxIconCustomLocation))
			{
				try
				{
					return File.ReadAllBytes(robloxIconCustomLocation);
				}
				catch (Exception value)
				{
					App.Logger.Error($"Failed to read custom icon! {value}");
				}
			}
			return LoadResourceBytes("Icon2025");
		}
		case RobloxIcon.Icon2008:
			name = "Icon2008";
			break;
		case RobloxIcon.Icon2011:
			name = "Icon2011";
			break;
		case RobloxIcon.IconEarly2015:
			name = "IconEarly2015";
			break;
		case RobloxIcon.IconLate2015:
			name = "IconLate2015";
			break;
		case RobloxIcon.Icon2017:
			name = "Icon2017";
			break;
		case RobloxIcon.Icon2019:
			name = "Icon2019";
			break;
		case RobloxIcon.Icon2022:
			name = "Icon2022";
			break;
		default:
			name = "Icon2025";
			break;
		}
		return LoadResourceBytes(name);
	}

	private static byte[] LoadResourceBytes(string name)
	{
		using Stream stream = AssetLoader.Open(new Uri("avares://Merostrap/Resources/" + name + ".ico"));
		using MemoryStream memoryStream = new MemoryStream();
		stream.CopyTo(memoryStream);
		return memoryStream.ToArray();
	}

	private unsafe static HICON IcoBytesToHIcon(byte[] icoBytes, int desiredSize = 32)
	{
		if (icoBytes.Length < 6)
		{
			return HICON.Null;
		}
		ushort num = BitConverter.ToUInt16(icoBytes, 2);
		ushort num2 = BitConverter.ToUInt16(icoBytes, 4);
		if (num != 1 || num2 == 0)
		{
			return HICON.Null;
		}
		int num3 = -1;
		int num4 = int.MaxValue;
		for (int i = 0; i < num2; i++)
		{
			int num5 = 6 + i * 16;
			if (num5 + 16 > icoBytes.Length)
			{
				break;
			}
			int num6 = icoBytes[num5];
			int num7 = icoBytes[num5 + 1];
			if (num6 == 0)
			{
				num6 = 256;
			}
			if (num7 == 0)
			{
				num7 = 256;
			}
			int num8 = Math.Abs(num6 - desiredSize) + Math.Abs(num7 - desiredSize);
			if (num8 < num4)
			{
				num4 = num8;
				num3 = i;
			}
		}
		if (num3 < 0)
		{
			return HICON.Null;
		}
		int num9 = 6 + num3 * 16;
		uint num10 = BitConverter.ToUInt32(icoBytes, num9 + 8);
		uint num11 = BitConverter.ToUInt32(icoBytes, num9 + 12);
		if (num11 + num10 > icoBytes.Length || num10 == 0)
		{
			return HICON.Null;
		}
		byte[] array = new byte[num10];
		Buffer.BlockCopy(icoBytes, (int)num11, array, 0, (int)num10);
		fixed (byte* presbits = array)
		{
			return PInvoke.CreateIconFromResourceEx(presbits, num10, true, 196608u, 0, 0, IMAGE_FLAGS.LR_DEFAULTCOLOR);
		}
	}

	public unsafe static void InvalidateCustomIcon()
	{
		_cache.Remove(RobloxIcon.IconCustom);
		if (_hIconCache.Remove(RobloxIcon.IconCustom, out var value) && value != IntPtr.Zero)
		{
			PInvoke.DestroyIcon(new HICON((void*)value));
		}
	}
}
