using System;
using System.Globalization;
using System.Text;
using System.Threading.Tasks;
using Merostrap.Enums;
using Merostrap.Resources;

namespace Merostrap.Extensions;

internal static class CustomThemeTemplateEx
{
	private const string EXAMPLES_URL = "https://github.com/Bloxstraplabs/custom-bootstrapper-examples";

	public static string GetFileName(this CustomThemeTemplate template)
	{
		return $"CustomBootstrapperTemplate_{template}.xml";
	}

	public static async Task<string> GetFileContents(this CustomThemeTemplate template)
	{
		byte[] bytes = await Resource.Get(template.GetFileName());
		string text = Encoding.UTF8.GetString(bytes);
		switch (template)
		{
		case CustomThemeTemplate.Blank:
		{
			string newValue2 = string.Format(CultureInfo.InvariantCulture, Strings.CustomTheme_Templates_Blank_MoreExamples, "https://github.com/Bloxstraplabs/custom-bootstrapper-examples");
			return text.Replace("{0}", Strings.CustomTheme_Templates_Blank_UIElements, StringComparison.Ordinal).Replace("{1}", newValue2, StringComparison.Ordinal);
		}
		case CustomThemeTemplate.Simple:
		{
			string newValue = string.Format(CultureInfo.InvariantCulture, Strings.CustomTheme_Templates_Simple_MoreExamples, "https://github.com/Bloxstraplabs/custom-bootstrapper-examples");
			return text.Replace("{0}", newValue, StringComparison.Ordinal);
		}
		default:
			return text;
		}
	}
}
