using Avalonia;
using Avalonia.Platform;
using Merostrap.Enums;

namespace Merostrap.Extensions;

internal static class ThemeEx
{
	public static Theme GetFinal(this Theme dialogTheme)
	{
		if (dialogTheme != Theme.Default)
		{
			return dialogTheme;
		}
		if (Application.Current?.PlatformSettings?.GetColorValues().ThemeVariant != PlatformThemeVariant.Dark)
		{
			return Theme.Light;
		}
		return Theme.Dark;
	}
}
