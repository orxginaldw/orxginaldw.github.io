using System.Collections.Generic;
using Merostrap.Enums.AppStoragePresets;

namespace Merostrap.Extensions;

internal class RobloxThemeEx
{
	public static IReadOnlyCollection<RobloxTheme> Selections => new _003C_003Ez__ReadOnlyArray<RobloxTheme>(new RobloxTheme[3]
	{
		RobloxTheme.Default,
		RobloxTheme.Light,
		RobloxTheme.Dark
	});
}
