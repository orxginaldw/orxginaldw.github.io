using System;
using System.Collections.Generic;
using System.IO;
using Avalonia.Media.Imaging;
using Avalonia.Platform;
using Merostrap.Enums;

namespace Merostrap.Extensions;

internal static class BootstrapperIconEx
{
	private static readonly Dictionary<BootstrapperIcon, Bitmap> _cache = new Dictionary<BootstrapperIcon, Bitmap>();

	public static IReadOnlyCollection<BootstrapperIcon> Selections => new _003C_003Ez__ReadOnlyArray<BootstrapperIcon>(new BootstrapperIcon[10]
	{
		BootstrapperIcon.None,
		BootstrapperIcon.Icon2025,
		BootstrapperIcon.Icon2022,
		BootstrapperIcon.Icon2019,
		BootstrapperIcon.Icon2017,
		BootstrapperIcon.IconLate2015,
		BootstrapperIcon.IconEarly2015,
		BootstrapperIcon.Icon2011,
		BootstrapperIcon.Icon2008,
		BootstrapperIcon.IconCustom
	});

	public static Bitmap? GetIcon(this BootstrapperIcon icon)
	{
		if (icon == BootstrapperIcon.None)
		{
			return null;
		}
		if (_cache.TryGetValue(icon, out Bitmap value))
		{
			return value;
		}
		Bitmap bitmap;
		switch (icon)
		{
		case BootstrapperIcon.IconCustom:
		{
			Bitmap bitmap2 = null;
			string bootstrapperIconCustomLocation = App.Settings.Prop.BootstrapperIconCustomLocation;
			if (string.IsNullOrEmpty(bootstrapperIconCustomLocation))
			{
				App.Logger.Warn("Custom icon is not set.");
			}
			else
			{
				try
				{
					bitmap2 = LoadIconFromFile(bootstrapperIconCustomLocation);
				}
				catch (Exception value2)
				{
					App.Logger.Error($"Failed to load custom icon! {value2}");
				}
			}
			Bitmap bitmap3 = bitmap2;
			if (bitmap3 != null)
			{
				_cache[icon] = bitmap3;
			}
			return bitmap3;
		}
		case BootstrapperIcon.Icon2008:
			bitmap = LoadFromResource("Icon2008");
			break;
		case BootstrapperIcon.Icon2011:
			bitmap = LoadFromResource("Icon2011");
			break;
		case BootstrapperIcon.IconEarly2015:
			bitmap = LoadFromResource("IconEarly2015");
			break;
		case BootstrapperIcon.IconLate2015:
			bitmap = LoadFromResource("IconLate2015");
			break;
		case BootstrapperIcon.Icon2017:
			bitmap = LoadFromResource("Icon2017");
			break;
		case BootstrapperIcon.Icon2019:
			bitmap = LoadFromResource("Icon2019");
			break;
		case BootstrapperIcon.Icon2022:
			bitmap = LoadFromResource("Icon2022");
			break;
		case BootstrapperIcon.Icon2025:
			bitmap = LoadFromResource("Icon2025");
			break;
		default:
			bitmap = null;
			break;
		}
		Bitmap bitmap4 = bitmap;
		if (bitmap4 != null)
		{
			_cache[icon] = bitmap4;
		}
		return bitmap4;
	}

	private static Bitmap LoadFromResource(string name)
	{
		using Stream stream = AssetLoader.Open(new Uri("avares://Merostrap/Resources/" + name + ".ico"));
		return LoadBestIconFromIcoStream(stream);
	}

	private static Bitmap LoadIconFromFile(string path)
	{
		using FileStream stream = File.OpenRead(path);
		return LoadBestIconFromIcoStream(stream);
	}

	private static Bitmap LoadBestIconFromIcoStream(Stream stream)
	{
		stream.Position = 0L;
		return new Bitmap(stream);
	}

	public static void InvalidateCustomIcon()
	{
		_cache.Remove(BootstrapperIcon.IconCustom);
	}
}
