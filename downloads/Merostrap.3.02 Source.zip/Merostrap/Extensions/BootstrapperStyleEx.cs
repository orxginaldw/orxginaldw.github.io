using System.Collections.Generic;
using System.Threading.Tasks;
using Merostrap.Enums;
using Merostrap.UI;

namespace Merostrap.Extensions;

internal static class BootstrapperStyleEx
{
	public static IReadOnlyCollection<BootstrapperStyle> Selections => new _003C_003Ez__ReadOnlyArray<BootstrapperStyle>(new BootstrapperStyle[7]
	{
		BootstrapperStyle.FluentAeroDialog,
		BootstrapperStyle.FluentDialog,
		BootstrapperStyle.ClassicFluentDialog,
		BootstrapperStyle.TwentyFiveDialog,
		BootstrapperStyle.ByfronDialog,
		BootstrapperStyle.ModernDialog,
		BootstrapperStyle.CustomDialog
	});

	public static async Task<IBootstrapperDialog> GetNew(this BootstrapperStyle bootstrapperStyle)
	{
		return await Frontend.GetBootstrapperDialog(bootstrapperStyle);
	}
}
