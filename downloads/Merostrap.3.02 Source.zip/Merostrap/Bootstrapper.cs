using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Net.Security;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using ICSharpCode.SharpZipLib.Core;
using ICSharpCode.SharpZipLib.GZip;
using ICSharpCode.SharpZipLib.Tar;
using ICSharpCode.SharpZipLib.Zip;
using Merostrap.AppData;
using Merostrap.Backend;
using Merostrap.Enums;
using Merostrap.Enums.BootstrapperDialogs;
using Merostrap.Enums.Messagebox;
using Merostrap.Exceptions;
using Merostrap.Extensions;
using Merostrap.Integrations;
using Merostrap.Models;
using Merostrap.Models.APIs.GitHub;
using Merostrap.Models.APIs.Roblox;
using Merostrap.Models.APIs.WebView2;
using Merostrap.Models.Manifest;
using Merostrap.Performance;
using Merostrap.Resources;
using Merostrap.RobloxInterfaces;
using Merostrap.UI;
using Merostrap.UI.ViewModels.Settings;
using Merostrap.Utility;
using Microsoft.Win32;

namespace Merostrap;

internal class Bootstrapper : IDisposable
{
	private const int ProgressBarMaximum = 10000;

	private const double TaskbarProgressMaximum = 1.0;

	private const int DownloadBufferSize = 4096;

	private const int MaxDownloadAttempts = 5;

	private const string SoberFlatpakId = "org.vinegarhq.Sober";

	public const string BackgroundUpdaterLockName = "BackgroundUpdater";

	private static readonly string[] DxvkDlls = new string[4] { "d3d9.dll", "d3d10core.dll", "d3d11.dll", "dxgi.dll" };

	private const string WebView2MicrosoftRootPem = "-----BEGIN CERTIFICATE-----\r\nMIIF7TCCA9WgAwIBAgIQP4vItfyfspZDtWnWbELhRDANBgkqhkiG9w0BAQsFADCB\r\niDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl\r\nZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMp\r\nTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEw\r\nMzIyMjIwNTI4WhcNMzYwMzIyMjIxMzA0WjCBiDELMAkGA1UEBhMCVVMxEzARBgNV\r\nBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv\r\nc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm\r\naWNhdGUgQXV0aG9yaXR5IDIwMTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIK\r\nAoICAQCygEGqNThNE3IyaCJNuLLx/9VSvGzH9dJKjDbu0cJcfoyKrq8TKG/Ac+M6\r\nztAlqFo6be+ouFmrEyNozQwph9FvgFyPRH9dkAFSWKxRxV8qh9zc2AodwQO5e7BW\r\n6KPeZGHCnvjzfLnsDbVU/ky2ZU+I8JxImQxCCwl8MVkXeQZ4KI2JOkwDJb5xalwL\r\n54RgpJki49KvhKSn+9GY7Qyp3pSJ4Q6g3MDOmT3qCFK7VnnkH4S6Hri0xElcTzFL\r\nh93dBWcmmYDgcRGjuKVB4qRTufcyKYMME782XgSzS0NHL2vikR7TmE/dQgfI6B0S\r\n/Jmpaz6SfsjWaTr8ZL22CZ3K/QwLopt3YEsDlKQwaRLWQi3BQUzK3Kr9j1uDRprZ\r\n/LHR47PJf0h6zSTwQY9cdNCssBAgBkm3xy0hyFfj0IbzA2j70M5xwYmZSmQBbP3s\r\nMJHPQTySx+W6hh1hhMdfgzlirrSSL0fzC/hV66AfWdC7dJse0Hbm8ukG1xDo+mTe\r\nacY1logC8Ea4PyeZb8txiSk190gWAjWP1Xl8TQLPX+uKg09FcYj5qQ1OcunCnAfP\r\nSRtOBA5jUYxe2ADBVSy2xuDCZU7JNDn1nLPEfuhhbhNfFcRf2X7tHc7uROzLLoax\r\n7Dj2cO2rXBPB2Q8Nx4CyVe0096yb5MPa50c8prWPMd/FS6/r8QIDAQABo1EwTzAL\r\nBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQUci06AjGQQ7kU\r\nBU7h6qfHMdEjiTQwEAYJKwYBBAGCNxUBBAMCAQAwDQYJKoZIhvcNAQELBQADggIB\r\nAH9yzw+3xRXbm8BJyiZb/p4T5tPw0tuXX/JLP02zrhmu7deXoKzvqTqjwkGw5biR\r\nnhOBJAPmCf0/V0A5ISRW0RAvS0CpNoZLtFNXmvvxfomPEf4YbFGq6O0JlbXlccmh\r\n6Yd1phV/yX43VF50k8XDZ8wNT2uoFwxtCJJ+i92Bqi1wIcM9BhS7vyRep4TXPw8h\r\nIr1LAAbblxzYXtTFC1yHblCk6MM4pPvLLMWSZpuFXst6bJN8gClYW1e1QGm6CHmm\r\nZGIVnYeWRbVmIyADixxzoNOieTPgUFmG2y/lAiXqcyqfABTINseSO+lOAOzYVgm5\r\nM0kS0lQLAausR7aRKX1MtHWAUgHoyoL2n8ysnI8X6i8msKtyrAv+nlEex0NVZ09R\r\ns1fWtuzuUrc66U7h14GIvE+OdbtLqPA1qibUZ2dJsnBMO5PcHd94kIZysjik0dyS\r\nTclY6ysSXNQ7roxrsIPlAT/4CTL2kzU0Iq/dNw13CYArzUgA8YyZGUcFAenRv9FO\r\n0OYoQzeZpApKCNmacXPSqs0xE2N2oTdvkjgefRI8ZjLny23h/FKJ3crWZgWalmG+\r\noijHHKOnNlA8OqTfSm7mhzvO6/DggTedEzxSjr25HTTGHdUKaj2YKXCMiSrRq4IQ\r\nSB/c9O+lxbtVGjhjhE63bK2VVOxlIhBJF7jAHscPrFRH\r\n-----END CERTIFICATE-----";

	private const string AppSettings = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<Settings>\r\n\t<ContentFolder>content</ContentFolder>\r\n\t<BaseUrl>http://www.roblox.com</BaseUrl>\r\n</Settings>\r\n";

	private readonly FastZipEvents _fastZipEvents = new FastZipEvents();

	private static readonly JsonSerializerOptions _indentedJsonOptions = new JsonSerializerOptions
	{
		WriteIndented = true
	};

	private static readonly Regex FlatpakProgressRegex = new Regex("Updating\\s+(?<current>\\d+)/(?<total>\\d+)…", RegexOptions.IgnoreCase | RegexOptions.Compiled);

	private static readonly Regex FlatpakPercentRegex = new Regex("(?<percent>\\d+)%", RegexOptions.Compiled);

	private readonly CancellationTokenSource _cancelTokenSource = new CancellationTokenSource();

	private IAppData AppData;

	private Dictionary<string, string> PackageDirectoryMap;

	private LaunchMode _launchMode;

	private string _launchCommandLine = App.LaunchSettings.RobloxLaunchArgs;

	private Version? _latestVersion;

	private string _latestVersionGuid;

	private string _latestVersionDirectory;

	private PackageManifest _versionPackageManifest;

	private readonly ConcurrentDictionary<string, byte> _sizedFromResponse = new ConcurrentDictionary<string, byte>();

	private readonly GameJoinData _joinData;

	private bool _isInstalling;

	private bool _packageExtractionSuccess = true;

	private bool _matchmakingInProgress;

	private volatile bool _skipMatchmaking;

	private CancellationTokenSource? _matchmakingCts;

	private bool _noConnection;

	private InterProcessLock? _appLock;

	private int _appPid;

	private readonly Stopwatch _startupTimer = new Stopwatch();

	private bool _disposed;

	private static readonly Lazy<HttpClient> _webView2HttpClient = new Lazy<HttpClient>(CreateWebView2HttpClient);

	private static readonly X509Certificate2 _webView2RootCert = X509Certificate2.CreateFromPem("-----BEGIN CERTIFICATE-----\r\nMIIF7TCCA9WgAwIBAgIQP4vItfyfspZDtWnWbELhRDANBgkqhkiG9w0BAQsFADCB\r\niDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl\r\nZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMp\r\nTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEw\r\nMzIyMjIwNTI4WhcNMzYwMzIyMjIxMzA0WjCBiDELMAkGA1UEBhMCVVMxEzARBgNV\r\nBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv\r\nc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm\r\naWNhdGUgQXV0aG9yaXR5IDIwMTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIK\r\nAoICAQCygEGqNThNE3IyaCJNuLLx/9VSvGzH9dJKjDbu0cJcfoyKrq8TKG/Ac+M6\r\nztAlqFo6be+ouFmrEyNozQwph9FvgFyPRH9dkAFSWKxRxV8qh9zc2AodwQO5e7BW\r\n6KPeZGHCnvjzfLnsDbVU/ky2ZU+I8JxImQxCCwl8MVkXeQZ4KI2JOkwDJb5xalwL\r\n54RgpJki49KvhKSn+9GY7Qyp3pSJ4Q6g3MDOmT3qCFK7VnnkH4S6Hri0xElcTzFL\r\nh93dBWcmmYDgcRGjuKVB4qRTufcyKYMME782XgSzS0NHL2vikR7TmE/dQgfI6B0S\r\n/Jmpaz6SfsjWaTr8ZL22CZ3K/QwLopt3YEsDlKQwaRLWQi3BQUzK3Kr9j1uDRprZ\r\n/LHR47PJf0h6zSTwQY9cdNCssBAgBkm3xy0hyFfj0IbzA2j70M5xwYmZSmQBbP3s\r\nMJHPQTySx+W6hh1hhMdfgzlirrSSL0fzC/hV66AfWdC7dJse0Hbm8ukG1xDo+mTe\r\nacY1logC8Ea4PyeZb8txiSk190gWAjWP1Xl8TQLPX+uKg09FcYj5qQ1OcunCnAfP\r\nSRtOBA5jUYxe2ADBVSy2xuDCZU7JNDn1nLPEfuhhbhNfFcRf2X7tHc7uROzLLoax\r\n7Dj2cO2rXBPB2Q8Nx4CyVe0096yb5MPa50c8prWPMd/FS6/r8QIDAQABo1EwTzAL\r\nBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQUci06AjGQQ7kU\r\nBU7h6qfHMdEjiTQwEAYJKwYBBAGCNxUBBAMCAQAwDQYJKoZIhvcNAQELBQADggIB\r\nAH9yzw+3xRXbm8BJyiZb/p4T5tPw0tuXX/JLP02zrhmu7deXoKzvqTqjwkGw5biR\r\nnhOBJAPmCf0/V0A5ISRW0RAvS0CpNoZLtFNXmvvxfomPEf4YbFGq6O0JlbXlccmh\r\n6Yd1phV/yX43VF50k8XDZ8wNT2uoFwxtCJJ+i92Bqi1wIcM9BhS7vyRep4TXPw8h\r\nIr1LAAbblxzYXtTFC1yHblCk6MM4pPvLLMWSZpuFXst6bJN8gClYW1e1QGm6CHmm\r\nZGIVnYeWRbVmIyADixxzoNOieTPgUFmG2y/lAiXqcyqfABTINseSO+lOAOzYVgm5\r\nM0kS0lQLAausR7aRKX1MtHWAUgHoyoL2n8ysnI8X6i8msKtyrAv+nlEex0NVZ09R\r\ns1fWtuzuUrc66U7h14GIvE+OdbtLqPA1qibUZ2dJsnBMO5PcHd94kIZysjik0dyS\r\nTclY6ysSXNQ7roxrsIPlAT/4CTL2kzU0Iq/dNw13CYArzUgA8YyZGUcFAenRv9FO\r\n0OYoQzeZpApKCNmacXPSqs0xE2N2oTdvkjgefRI8ZjLny23h/FKJ3crWZgWalmG+\r\noijHHKOnNlA8OqTfSm7mhzvO6/DggTedEzxSjr25HTTGHdUKaj2YKXCMiSrRq4IQ\r\nSB/c9O+lxbtVGjhjhE63bK2VVOxlIhBJF7jAHscPrFRH\r\n-----END CERTIFICATE-----");

	private double _progressIncrement;

	private double _taskbarProgressIncrement;

	private double _taskbarProgressMaximum;

	private long _totalDownloadedBytes;

	private long _totalPackagedBytes;

	public bool UseFastFlagsForLaunch { get; init; } = true;

	private static bool AutomaticallyUpdateSober
	{
		get
		{
			if (OperatingSystem.IsLinux())
			{
				return App.Settings.Prop.AutomaticallyUpdateSober;
			}
			return false;
		}
	}

	private string CurrentDirectory => _latestVersionDirectory ?? AppData.Directory;

	private bool MustUpgrade
	{
		get
		{
			if (!App.LaunchSettings.ForceFlag.Active && !App.State.Prop.ForceReinstall && ((OperatingSystem.IsLinux() && !IsStudioLaunch) || (!string.IsNullOrEmpty(AppData.DistributionState.VersionGuid) && !(OperatingSystem.IsMacOS() ? (!Directory.Exists(AppData.ExecutablePath)) : (!File.Exists(AppData.ExecutablePath))))) && (!OperatingSystem.IsWindows() || IsStudioLaunch || File.Exists(Path.Combine(CurrentDirectory, "WebView2Loader.dll"))))
			{
				if (OperatingSystem.IsWindows() && !IsStudioLaunch)
				{
					return !File.Exists(Path.Combine(CurrentDirectory, "RobloxPlayerBeta.dll"));
				}
				return false;
			}
			return true;
		}
	}

	public bool IsStudioLaunch => _launchMode != LaunchMode.Player;

	public string LockName { get; set; } = "Bootstrapper";

	public bool QuitIfLockExists { get; set; }

	public IBootstrapperDialog? Dialog { get; set; }

	public Bootstrapper(LaunchMode launchMode)
	{
		_launchMode = launchMode;
		FastZipEvents fastZipEvents = _fastZipEvents;
		fastZipEvents.FileFailure = (FileFailureHandler)Delegate.Combine(fastZipEvents.FileFailure, (FileFailureHandler)((object _, ScanFailureEventArgs e) =>
		{
			if (!e.Name.EndsWith(".ttf", StringComparison.OrdinalIgnoreCase))
			{
				throw e.Exception;
			}
			App.Logger.Error("Failed to extract " + e.Name);
			_packageExtractionSuccess = false;
		}));
		FastZipEvents fastZipEvents2 = _fastZipEvents;
		fastZipEvents2.DirectoryFailure = (DirectoryFailureHandler)Delegate.Combine(fastZipEvents2.DirectoryFailure, (DirectoryFailureHandler)((object _, ScanFailureEventArgs e) =>
		{
			throw e.Exception;
		}));
		FastZipEvents fastZipEvents3 = _fastZipEvents;
		fastZipEvents3.ProcessFile = (ProcessFileHandler)Delegate.Combine(fastZipEvents3.ProcessFile, (ProcessFileHandler)((object _, ScanEventArgs e) =>
		{
			e.ContinueRunning = !_cancelTokenSource.IsCancellationRequested;
		}));
		SetupAppData();
		Deployment.Channel = (IsStudioLaunch ? App.Settings.Prop.StudioChannel : App.Settings.Prop.PlayerChannel);
		App.Logger.Info("Using " + (IsStudioLaunch ? "Studio" : "Player") + " channel: " + Deployment.Channel);
		_joinData = GameJoin.GetJoinDataByLaunchCommand(_launchCommandLine);
	}

	private void SetupAppData()
	{
		IAppData appData2;
		if (!IsStudioLaunch)
		{
			IAppData appData = new RobloxPlayerData();
			appData2 = appData;
		}
		else
		{
			IAppData appData = new RobloxStudioData();
			appData2 = appData;
		}
		AppData = appData2;
	}

	private async Task SetupPackageDictionaries()
	{
		if (OperatingSystem.IsMacOS())
		{
			PackageDirectoryMap = new Dictionary<string, string>
			{
				{ "RobloxPlayer.zip", "" },
				{ "RobloxStudioApp.zip", "" }
			};
			return;
		}
		if (OperatingSystem.IsLinux() && !IsStudioLaunch)
		{
			PackageDirectoryMap = new Dictionary<string, string>();
			return;
		}
		await App.RemoteData.WaitUntilDataFetched();
		Dictionary<string, string> dictionary = App.RemoteData.Prop.PackageMaps[IsStudioLaunch ? "studio" : "player"];
		Dictionary<string, string> commonPackageMap = App.RemoteData.Prop.PackageMaps.CommonPackageMap;
		PackageDirectoryMap = new Dictionary<string, string>(commonPackageMap);
		foreach (KeyValuePair<string, string> item in dictionary)
		{
			PackageDirectoryMap[item.Key] = item.Value;
		}
		if (!OperatingSystem.IsLinux())
		{
			return;
		}
		foreach (string item2 in PackageDirectoryMap.Keys.ToList())
		{
			if (PackageDirectoryMap[item2] != null)
			{
				PackageDirectoryMap[item2] = PackageDirectoryMap[item2].Replace('\\', '/');
			}
		}
	}

	private async Task HandleConnectionError(Exception ex)
	{
		_noConnection = true;
		if (App.Settings.Prop.StaticDirectory || !string.IsNullOrEmpty(AppData.DistributionState.VersionGuid))
		{
			_latestVersionDirectory = AppData.Directory;
		}
		App.Logger.Warn($"Connectivity check failed: {ex}");
		string text = Strings.Dialog_Connectivity_BadConnection;
		if (ex is AggregateException)
		{
			ex = ex.InnerException;
		}
		if (ex is HttpRequestException && ex.InnerException == null)
		{
			text = string.Format(CultureInfo.InvariantCulture, Strings.Dialog_Connectivity_RobloxDown, "[status.roblox.com](https://status.roblox.com)");
		}
		await Frontend.ShowConnectivityDialog(description: (!MustUpgrade) ? (text + "\n\n" + Strings.Dialog_Connectivity_RobloxUpgradeSkip) : (text + "\n\n" + Strings.Dialog_Connectivity_RobloxUpgradeNeeded + "\n\n" + Strings.Dialog_Connectivity_TryAgainLater), title: string.Format(CultureInfo.InvariantCulture, Strings.Dialog_Connectivity_UnableToConnect, "Roblox"), image: MustUpgrade ? MessageBoxImage.Error : MessageBoxImage.Warning, exception: ex);
		if (MustUpgrade)
		{
			App.Terminate(ErrorCode.ERROR_CANCELLED);
		}
	}

	public async Task Run()
	{
		_startupTimer.Restart();
		App.Logger.Info("Running bootstrapper");
		IBootstrapperDialog? dialog = Dialog;
		if (dialog != null)
		{
			dialog.CancelEnabled = true;
		}
		if (AutomaticallyUpdateSober && _launchMode == LaunchMode.Player)
		{
			await UpdateSoberFlatpakAsync();
		}
		SetStatus(Strings.Bootstrapper_Status_Connecting);
		if (OperatingSystem.IsLinux() && !IsStudioLaunch)
		{
			_noConnection = true;
			_latestVersionDirectory = Paths.SoberAssetOverlay;
			App.Logger.Info("Linux (Player): skipping connectivity check — Sober manages Roblox.");
		}
		else
		{
			Exception ex = await Deployment.InitializeConnectivity();
			App.Logger.Info("Connectivity check finished");
			if (ex != null)
			{
				await HandleConnectionError(ex);
			}
		}
		if (!App.LaunchSettings.BypassUpdateCheck && !App.LaunchSettings.UpgradeFlag.Active && App.Settings.Prop.UpdateChecks != UpdateCheck.Disabled && await Updater.CheckForUpdates())
		{
			return;
		}
		bool lockWasAlreadyHeld = false;
		_appLock = new InterProcessLock(LockName, TimeSpan.Zero);
		if (!_appLock.IsAcquired)
		{
			lockWasAlreadyHeld = true;
			if (QuitIfLockExists)
			{
				App.Logger.Info(LockName + " instance exists, exiting!");
				return;
			}
			App.Logger.Warn(LockName + " instance exists, waiting...");
			SetStatus(Strings.Bootstrapper_Status_WaitingOtherInstances);
			while (!_cancelTokenSource.Token.IsCancellationRequested)
			{
				_appLock.Dispose();
				_appLock = new InterProcessLock(LockName, TimeSpan.Zero);
				if (_appLock.IsAcquired)
				{
					break;
				}
				await Task.Delay(500, _cancelTokenSource.Token);
			}
			if (_cancelTokenSource.Token.IsCancellationRequested)
			{
				return;
			}
		}
		App.Logger.Info("Lock acquired.");
		try
		{
			if (lockWasAlreadyHeld)
			{
				App.Settings.Load();
				App.State.Load();
				AppData.DistributionStateManager.Load();
			}
			if (!_noConnection)
			{
				try
				{
					await GetLatestVersionInfo();
				}
				catch (Exception ex2)
				{
					await HandleConnectionError(ex2);
				}
			}
			CleanupVersionsFolder();
			bool flag = true;
			if (!_noConnection)
			{
				if (App.RemoteData.LoadedState == GenericTriState.Unknown)
				{
					SetStatus(Strings.Bootstrapper_Status_WaitingForData);
				}
				await SetupPackageDictionaries();
				if (AppData.DistributionState.VersionGuid != _latestVersionGuid || MustUpgrade)
				{
					bool flag2;
					using (InterProcessLock interProcessLock = new InterProcessLock("BackgroundUpdater", TimeSpan.Zero))
					{
						flag2 = !interProcessLock.IsAcquired;
					}
					if (App.LaunchSettings.BackgroundUpdaterFlag.Active)
					{
						flag2 = false;
					}
					App.Logger.Debug($"Background updater running: {flag2}");
					if (flag2 && MustUpgrade)
					{
						Processes.KillBackgroundUpdater();
						flag2 = false;
					}
					if (!flag2)
					{
						if (!IsEligibleForBackgroundUpdate())
						{
							await UpgradeRoblox();
						}
						else
						{
							StartBackgroundUpdater();
						}
					}
				}
				if (_cancelTokenSource.IsCancellationRequested)
				{
					return;
				}
				flag = await ApplyModifications();
			}
			else if (OperatingSystem.IsLinux())
			{
				if (MustUpgrade)
				{
					App.Logger.Debug("Linux: Force reinstall enabled.");
					InlineArray7<string> buffer = default;
					buffer[0] = Paths.Versions;
					buffer[1] = "Sober";
					buffer[2] = "data";
					buffer[3] = "sober";
					buffer[4] = "packages";
					buffer[5] = "x86_64";
					buffer[6] = "com.roblox.client";
					string text = Path.Combine(buffer);
					try
					{
						if (Directory.Exists(text))
						{
							DirectoryInfo directoryInfo = new DirectoryInfo(text);
							FileInfo[] files = directoryInfo.GetFiles();
							for (int i = 0; i < files.Length; i++)
							{
								files[i].Delete();
							}
							DirectoryInfo[] directories = directoryInfo.GetDirectories();
							for (int i = 0; i < directories.Length; i++)
							{
								directories[i].Delete(recursive: true);
							}
							App.State.Prop.ForceReinstall = false;
							App.Logger.Debug("Successfully cleared contents of " + text);
						}
					}
					catch (Exception ex3)
					{
						App.Logger.Error("Failed to purge packages: " + ex3.Message);
					}
				}
				if (PackageDirectoryMap == null)
				{
					PackageDirectoryMap = new Dictionary<string, string>();
				}
				if (!_cancelTokenSource.IsCancellationRequested)
				{
					flag = await ApplyModifications();
				}
			}
			if (OperatingSystem.IsWindows())
			{
				if (IsStudioLaunch)
				{
					WindowsRegistry.RegisterStudio();
					App.Logger.Debug("Studio launch detected, syncing RPC plugin...");
					StudioPluginManager.Sync();
				}
				else
				{
					WindowsRegistry.RegisterPlayer();
				}
				WindowsRegistry.RegisterClientLocation(IsStudioLaunch, _latestVersionDirectory);
			}
			else if (IsStudioLaunch)
			{
				App.Logger.Debug("Studio launch detected, syncing RPC plugin...");
				StudioPluginManager.Sync();
			}
			if (App.LaunchSettings.NoLaunchFlag.Active || _cancelTokenSource.IsCancellationRequested)
			{
				return;
			}
			if (!App.LaunchSettings.QuietFlag.Active)
			{
				if (!_packageExtractionSuccess)
				{
					NativeNotify.SendMessage(Strings.Bootstrapper_ExtractionFailed_Title, Strings.Bootstrapper_ExtractionFailed_Message);
				}
				else if (!flag)
				{
					NativeNotify.SendMessage(Strings.Bootstrapper_ModificationsFailed_Title, Strings.Bootstrapper_ModificationsFailed_Message);
				}
			}
			if (!OperatingSystem.IsLinux())
			{
				bool flag3 = OperatingSystem.IsWindows() && !IsStudioLaunch && App.Settings.Prop.MultiInstanceLaunching;
				if (flag3)
				{
					flag3 = !(await MultiInstanceWatcher.EnsureStartedAsync(_cancelTokenSource.Token));
				}
				if (flag3)
				{
					await Frontend.ShowMessageBox("Multi-instance could not start. Close all Roblox clients and try again, or disable multi-instance launching.", MessageBoxImage.Warning);
					return;
				}
				await StartRoblox();
			}
			else if (IsStudioLaunch)
			{
				await LaunchStudioViaWineAsync();
			}
			else
			{
				if (!(await EnsureSoberInstalledAsync()))
				{
					return;
				}
				await LaunchViaSober(new List<int>());
			}
			Dialog?.CloseBootstrapper();
		}
		finally
		{
			_appLock?.Dispose();
		}
	}

	private async Task GetLatestVersionInfo()
	{
		Match match = Regex.Match(App.LaunchSettings.RobloxLaunchArgs, "channel:([a-zA-Z0-9-_]+)", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
		string enrolledChannel = ((match.Groups.Count == 2) ? match.Groups[1].Value.ToLowerInvariant() : "production");
		bool behindProductionCheck = App.Settings.Prop.ChannelChangeMode == ChannelChangeMode.Prompt;
		string tokenChannel = null;
		if (App.Cookies.Loaded)
		{
			UserChannel userChannel = await Deployment.GetUserChannel(AppData.BinaryType);
			if (userChannel?.Token != null && userChannel.AssignmentType != 1)
			{
				if (!string.IsNullOrEmpty(enrolledChannel))
				{
					_launchCommandLine = _launchCommandLine.Replace("channel:" + enrolledChannel, "channel:" + userChannel.Channel, StringComparison.OrdinalIgnoreCase);
				}
				Deployment.ChannelToken = userChannel.Token;
				tokenChannel = userChannel.Channel;
				enrolledChannel = userChannel.Channel;
			}
		}
		if (!App.LaunchSettings.ChannelFlag.Active || string.IsNullOrEmpty(App.LaunchSettings.ChannelFlag.Data))
		{
			switch (App.Settings.Prop.ChannelChangeMode)
			{
			case ChannelChangeMode.Automatic:
				App.Logger.Info("Enrolling into channel");
				EnrollChannel(enrolledChannel);
				break;
			case ChannelChangeMode.Prompt:
			{
				App.Logger.Debug("Prompting channel enrollment");
				if (!match.Success || match.Groups.Count != 2 || string.Equals(match.Groups[1].Value, Deployment.Channel, StringComparison.OrdinalIgnoreCase))
				{
					App.Logger.Warn("Channel is either equal or incorrectly formatted");
					break;
				}
				string arg = ((!string.IsNullOrEmpty(match.Groups[1].Value)) ? match.Groups[1].Value : "production");
				if (await Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.Bootstrapper_Bootstrapper_Dialog_PromptChannelChange, arg, Deployment.Channel), MessageBoxImage.Question, MessageBoxButton.YesNo) == MessageBoxResult.Yes)
				{
					EnrollChannel(enrolledChannel);
				}
				break;
			}
			case ChannelChangeMode.Ignore:
				App.Logger.Debug("Ignoring channel enrollment");
				break;
			}
		}
		else
		{
			string data = App.LaunchSettings.ChannelFlag.Data;
			if (!string.IsNullOrEmpty(data))
			{
				App.Logger.Debug("Forcing channel " + data);
				EnrollChannel(data);
			}
		}
		if (!string.IsNullOrEmpty(Deployment.ChannelToken) && !string.Equals(Deployment.Channel, tokenChannel, StringComparison.OrdinalIgnoreCase))
		{
			App.Logger.Info($"Dropping channel token for '{tokenChannel}' because the active channel is '{Deployment.Channel}'");
			Deployment.ChannelToken = string.Empty;
		}
		bool overrideUsed = false;
		if (IsStudioLaunch && App.Settings.Prop.StudioVersionOverrideEnabled && !string.IsNullOrEmpty(App.Settings.Prop.StudioVersionOverrideHash))
		{
			_latestVersionGuid = App.Settings.Prop.StudioVersionOverrideHash.Trim();
			App.Logger.Debug("Studio version override active: pinned to " + _latestVersionGuid);
			overrideUsed = true;
		}
		else if (!IsStudioLaunch && App.Settings.Prop.PlayerVersionOverrideEnabled && !string.IsNullOrEmpty(App.Settings.Prop.PlayerVersionOverrideHash))
		{
			string overrideHash = App.Settings.Prop.PlayerVersionOverrideHash.Trim();
			var (flag, text) = await ChannelViewModel.ValidateHashCore(overrideHash, enforceAgeAndBan: true, AppData.BinaryType);
			if (flag)
			{
				_latestVersionGuid = overrideHash;
				App.Logger.Debug("Player version override active: pinned to " + _latestVersionGuid);
				overrideUsed = true;
			}
			else
			{
				App.Logger.Warn("Player version override invalid: " + text + ". Falling back to channel.");
				if (!App.LaunchSettings.QuietFlag.Active)
				{
					await Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.Bootstrapper_Status_InvalidOverride, overrideHash, text), MessageBoxImage.Warning);
				}
				App.Settings.Prop.PlayerVersionOverrideEnabled = false;
				App.Settings.Prop.PlayerVersionOverrideHash = string.Empty;
				App.Settings.Save();
			}
		}
		if (!overrideUsed && (!App.LaunchSettings.VersionFlag.Active || string.IsNullOrEmpty(App.LaunchSettings.VersionFlag.Data)))
		{
			ClientVersion clientVersion;
			try
			{
				clientVersion = await Deployment.GetInfo(Deployment.Channel, behindProductionCheck, includeTimestamp: false, AppData.BinaryType);
			}
			catch (InvalidChannelException ex)
			{
				if (ex.StatusCode == HttpStatusCode.NotFound)
				{
					App.Logger.Warn("Reverting enrolled channel to production because a WindowsPlayer build does not exist for " + Deployment.Channel);
				}
				else
				{
					if (ex.StatusCode != HttpStatusCode.Unauthorized)
					{
						throw;
					}
					App.Logger.Warn($"Reverting enrolled channel to {"production"} because {Deployment.Channel} is restricted for public use.");
					if (App.Settings.Prop.ChannelChangeMode != ChannelChangeMode.Automatic)
					{
						await Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.Boostrapper_Dialog_UnauthorizedChannel, Deployment.Channel, "production"));
					}
				}
				RevertChannel();
				clientVersion = await Deployment.GetInfo("production", behindProductionCheck, includeTimestamp: false, AppData.BinaryType);
			}
			if (clientVersion.IsBehindDefaultChannel && App.Settings.Prop.ChannelChangeMode == ChannelChangeMode.Prompt && await Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.Bootstrapper_Dialog_ChannelOutOfDate, Deployment.Channel, "production"), MessageBoxImage.Warning, MessageBoxButton.YesNo) == MessageBoxResult.Yes)
			{
				App.Logger.Debug("Changed Roblox channel from " + Deployment.Channel + " to production");
				RevertChannel();
				clientVersion = await Deployment.GetInfo("production", behindProductionCheck: false, includeTimestamp: false, AppData.BinaryType);
			}
			if (clientVersion.IsInstalledFallback)
			{
				SetStatus("Using installed Roblox build ? update check unavailable...");
			}
			_latestVersionGuid = clientVersion.VersionGuid;
			_latestVersion = Versioning.ParseVersionSafe(clientVersion.Version);
		}
		else if (!overrideUsed)
		{
			string data2 = App.LaunchSettings.VersionFlag.Data;
			if (string.IsNullOrEmpty(data2))
			{
				App.Logger.Error("VersionFlag.Data was unexpectedly null or empty. Falling back to default channel.");
				ClientVersion clientVersion2 = await Deployment.GetInfo("production", behindProductionCheck: false, includeTimestamp: false, AppData.BinaryType);
				_latestVersionGuid = clientVersion2.VersionGuid;
				_latestVersion = Versioning.ParseVersionSafe(clientVersion2.Version);
			}
			else
			{
				App.Logger.Debug("Version set to " + data2 + " from arguments");
				_latestVersionGuid = data2;
			}
		}
		SyncLaunchChannel();
		if (App.Settings.Prop.StaticDirectory)
		{
			_latestVersionDirectory = AppData.StaticDirectory;
		}
		else
		{
			_latestVersionDirectory = Path.Combine(Paths.Versions, _latestVersionGuid);
		}
		if (OperatingSystem.IsLinux() && !IsStudioLaunch)
		{
			_latestVersionDirectory = Paths.SoberAssetOverlay;
		}
		if (OperatingSystem.IsMacOS())
		{
			string value = (IsStudioLaunch ? "RobloxStudioApp.zip" : "RobloxPlayer.zip");
			string data3 = $"v0\n{value}\n{_latestVersionGuid}\n0\n0";
			_versionPackageManifest = new PackageManifest(data3);
		}
		else
		{
			string location = Deployment.GetLocation("/" + _latestVersionGuid + "-rbxPkgManifest.txt");
			_versionPackageManifest = new PackageManifest(await App.HttpClient.GetStringAsync(new Uri(location)));
		}
		if (_launchMode == LaunchMode.Unknown)
		{
			App.Logger.Info("Identifying launch mode from package manifest");
			bool flag2 = _versionPackageManifest.Exists((Package x) => x.Name == "RobloxApp.zip" || x.Name == "RobloxPlayer.zip");
			App.Logger.Info($"isPlayer={flag2}");
			_launchMode = (flag2 ? LaunchMode.Player : LaunchMode.Studio);
			SetupAppData();
		}
		void EnrollChannel(string channel = "production")
		{
			Deployment.Channel = channel;
			if (IsStudioLaunch)
			{
				App.Settings.Prop.StudioChannel = channel;
			}
			else
			{
				App.Settings.Prop.PlayerChannel = channel;
			}
			App.Settings.Save();
		}
		void RevertChannel()
		{
			Deployment.Channel = "production";
			Deployment.ChannelToken = string.Empty;
			if (IsStudioLaunch)
			{
				App.Settings.Prop.StudioChannel = "production";
			}
			else
			{
				App.Settings.Prop.PlayerChannel = "production";
			}
			App.Settings.Save();
		}
	}

	private void SyncLaunchChannel()
	{
		string text = (Deployment.IsDefaultChannel ? "production" : Deployment.Channel);
		if (!string.IsNullOrEmpty(_launchCommandLine))
		{
			string text2 = Regex.Replace(_launchCommandLine, "channel:[a-zA-Z0-9-_]+", "channel:" + text, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
			if (!string.Equals(text2, _launchCommandLine, StringComparison.Ordinal))
			{
				App.Logger.Info("Launch arguments carried a different channel than the one installed, using '" + text + "'");
				_launchCommandLine = text2;
			}
		}
		if (OperatingSystem.IsWindows())
		{
			using RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("SOFTWARE\\ROBLOX Corporation\\Environments\\" + AppData.RegistryName + "\\Channel");
			registryKey.SetValueSafe("www." + Deployment.RobloxDomain, Deployment.IsDefaultChannel ? "" : Deployment.Channel);
		}
		if (OperatingSystem.IsMacOS())
		{
			MacChannelStore.Apply(AppData.RegistryName, Deployment.RobloxDomain, Deployment.IsDefaultChannel ? null : Deployment.Channel);
		}
	}

	private bool IsEligibleForBackgroundUpdate()
	{
		if (App.LaunchSettings.BackgroundUpdaterFlag.Active)
		{
			App.Logger.Debug("Not eligible: Is the background updater process");
			return false;
		}
		if (!App.Settings.Prop.BackgroundUpdatesEnabled || App.Settings.Prop.Performance.UseQuietDownloads)
		{
			App.Logger.Debug("Not eligible: Background updates disabled");
			return false;
		}
		if (IsStudioLaunch)
		{
			App.Logger.Debug("Not eligible: Studio launch");
			return false;
		}
		if (MustUpgrade)
		{
			App.Logger.Debug("Not eligible: Must upgrade is true");
			return false;
		}
		if (!string.IsNullOrEmpty(Deployment.ChannelToken))
		{
			App.Logger.Debug("Not eligible: Private channel enrollment");
			return false;
		}
		long freeDiskSpace = Filesystem.GetFreeDiskSpace(Paths.Base);
		if (freeDiskSpace < 3000000000u)
		{
			App.Logger.Info($"Not eligible: User has {freeDiskSpace} free space, at least {3000000000L} is required");
			return false;
		}
		if (_latestVersion == null)
		{
			App.Logger.Info("Not eligible: Latest version is undefined");
			return false;
		}
		Version robloxVersion = Versioning.GetRobloxVersion(AppData);
		if (robloxVersion == null)
		{
			App.Logger.Info("Not eligible: Current version is undefined");
			return false;
		}
		if (robloxVersion.Minor > _latestVersion.Minor)
		{
			App.Logger.Info("Not eligible: Downgrade");
			return false;
		}
		int num = _latestVersion.Minor - robloxVersion.Minor;
		if (num == 0 || num == 1)
		{
			App.Logger.Info("Eligible");
			return true;
		}
		App.Logger.Info($"Not eligible: Major version diff is {num}");
		return false;
	}

	private async Task<string> GetBetterMatchmakingServerID(CancellationToken cancellationToken = default(CancellationToken))
	{
		using CancellationTokenSource launchDeadline = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
		launchDeadline.CancelAfter(TimeSpan.FromSeconds(8L));
		cancellationToken = launchDeadline.Token;
		string selectedRegion = (PreferredRegionRouting.HasPreference ? PreferredRegionRouting.Region : (App.Settings.Prop.SelectedRegion ?? ""));
		using RobloxServerFetcher fetcher = new RobloxServerFetcher();
		if (!string.IsNullOrEmpty(selectedRegion) && !selectedRegion.Equals(Strings.Common_Auto, StringComparison.OrdinalIgnoreCase))
		{
			App.Logger.Debug("User selected specific region: " + selectedRegion);
			SetStatus(string.Format(CultureInfo.InvariantCulture, Strings.Bootstrapper_Status_SearchingServers, selectedRegion));
			RobloxServerFetcher.ServerSelectionResult serverSelectionResult = await fetcher.FindBestServerInSelectedRegionAsync(_joinData.PlaceId.Value, selectedRegion, cancellationToken);
			if (serverSelectionResult.Found)
			{
				App.Logger.Info("Found server in selected region " + selectedRegion + ": " + serverSelectionResult.ServerId);
				return serverSelectionResult.ServerId;
			}
			if (PreferredRegionRouting.HasPreference)
			{
				return "";
			}
			App.Logger.Info("No servers found in selected region " + selectedRegion + ". Falling back to Auto mode.");
		}
		if (cancellationToken.IsCancellationRequested)
		{
			App.Logger.Debug("Matchmaking was cancelled before auto mode could start.");
			return "";
		}
		cancellationToken.ThrowIfCancellationRequested();
		SetStatus(Strings.Bootstrapper_Status_SearchingNearbyServers);
		List<string> list = await fetcher.GetClosestRegionsForAutoModeAsync(cancellationToken);
		if (cancellationToken.IsCancellationRequested)
		{
			return "";
		}
		if (list.Count == 0)
		{
			throw new HttpRequestException("No regions found from datacenter list");
		}
		RobloxServerFetcher.ServerSelectionResult serverSelectionResult2 = await fetcher.FindBestServerInRegionAsync(_joinData.PlaceId.Value, list, cancellationToken);
		if (serverSelectionResult2.Found)
		{
			App.Logger.Info($"Selected best server in {serverSelectionResult2.Region} (rank {serverSelectionResult2.Rank})");
			return serverSelectionResult2.ServerId;
		}
		App.Logger.Warn("No server found in any region within timeout.");
		return "";
	}

	private async Task StartRoblox()
	{
		if (_launchMode == LaunchMode.Player)
		{
			ProfileGraphicsLaunch.Prepare();
		}
		if (!UseFastFlagsForLaunch && !OperatingSystem.IsLinux())
		{
			FastFlagLaunchChoice.RemoveOverrides(OperatingSystem.IsMacOS() ? Path.Combine(CurrentDirectory, AppData.ExecutableName, "Contents", "MacOS") : CurrentDirectory);
			App.Logger.Info("Launching without local FastFlag overrides for this session.");
		}
		App.Logger.Info($"Starting Roblox after {_startupTimer.ElapsedMilliseconds} ms of launcher preparation (performance mode: {App.Settings.Prop.Performance.UseLeanRuntime}).");
		if (_launchMode == LaunchMode.Player)
		{
			AppStorageManager.Apply();
			if (_joinData.JoinType == GameJoinType.Unknown)
			{
				App.Logger.Warn("Unable to get join data");
			}
			App.Logger.Info($"Join Type: {_joinData.JoinType}");
			App.Logger.Info("Join Origin: " + (_joinData.JoinOrigin ?? "null"));
			App.Logger.Info("Place ID: " + (_joinData.PlaceId?.ToString(CultureInfo.InvariantCulture) ?? "null"));
			App.Logger.Info("Job ID: " + (_joinData.JobId ?? "null"));
			App.Logger.Info("Access Code: " + (_joinData.AccessCode ?? "null"));
			_launchCommandLine = await PreferredRegionRouting.ApplyAsync(_launchCommandLine, _cancelTokenSource.Token);
			if (_launchCommandLine.StartsWith("roblox://", StringComparison.Ordinal))
			{
				App.Logger.Info("Joining through roblox:// URI, skipping Better Matchmaking");
			}
			else
			{
				bool isFollowUser = PreferredRegionRouting.HasPreference && PreferredRegionRouting.IsFriendJoin(_joinData.JoinOrigin);
				if (!isFollowUser && App.Settings.Prop.EnableBetterMatchmaking && (_joinData.JoinOrigin == "friendServerListJoin" || _joinData.JoinOrigin == "placesListInHomePage"))
				{
					App.Logger.Debug("User is trying to join a friend, showing dialog");
					if (await Frontend.ShowMessageBox(string.Format((IFormatProvider?)CultureInfo.InvariantCulture, Strings.Menu_Bootstrapper_Experimental_BetterMatchmaking_FollowUser, default(ReadOnlySpan<object>)), MessageBoxImage.Question, MessageBoxButton.YesNo) == MessageBoxResult.Yes)
					{
						isFollowUser = true;
					}
				}
				string serverid = null;
				bool matchmakingCancelled = false;
				_matchmakingInProgress = true;
				_skipMatchmaking = false;
				_matchmakingCts = new CancellationTokenSource();
				IBootstrapperDialog? dialog = Dialog;
				if (dialog != null)
				{
					dialog.CancelButtonText = Strings.Bootstrapper_CancelButton_Skip;
				}
				try
				{
					if (PreferredRegionRouting.UseMatchmaking && _joinData.JoinType == GameJoinType.RequestGame && _joinData.PlaceId.HasValue && !isFollowUser)
					{
						if (_skipMatchmaking)
						{
							App.Logger.Info("Matchmaking was skipped due to user cancellation.");
							matchmakingCancelled = true;
						}
						else
						{
							serverid = await GetBetterMatchmakingServerID(_matchmakingCts.Token);
						}
					}
				}
				catch (OperationCanceledException)
				{
					App.Logger.Debug("Nearby server search cancelled or timed out; joining the original server.");
					matchmakingCancelled = true;
				}
				catch (HttpRequestException exception)
				{
					Frontend.ShowConnectivityDialog(string.Format(CultureInfo.InvariantCulture, Strings.Dialog_Connectivity_UnableToConnect, "rovalra.com"), Strings.Dialog_Connectivity_MatchmakingFailed, MessageBoxImage.Warning, exception);
				}
				finally
				{
					IBootstrapperDialog? dialog2 = Dialog;
					if (dialog2 != null)
					{
						dialog2.CancelButtonText = Strings.Common_Cancel;
					}
					_matchmakingInProgress = false;
					_matchmakingCts?.Dispose();
					_matchmakingCts = null;
				}
				if (!matchmakingCancelled && !string.IsNullOrEmpty(serverid) && _joinData.PlaceId.HasValue)
				{
					string str = UrlBuilder.BuildPlacelauncherUrl(_joinData.PlaceId.Value, serverid);
					_launchCommandLine = _launchCommandLine.Replace(_joinData.PlaceLauncherUrl, HttpUtility.UrlEncode(str), StringComparison.Ordinal);
				}
			}
			if (!Deployment.IsDefaultRobloxDomain && string.IsNullOrEmpty(_launchCommandLine))
			{
				_launchCommandLine = "roblox://navigation/home";
			}
		}
		SetStatus(Strings.Bootstrapper_Status_Starting);
		string expectedName = (IsStudioLaunch ? App.RobloxStudioAppName : App.RobloxPlayerAppName);
		string expectedPath = Path.Combine(AppData.Directory, expectedName);
		if (!Directory.Exists(expectedPath) && !File.Exists(expectedPath))
		{
			App.Logger.Warn(expectedName + " not found at " + expectedPath + ", triggering upgrade...");
			await UpgradeRoblox();
		}
		if (!Directory.Exists(expectedPath) && !File.Exists(expectedPath))
		{
			throw new FileNotFoundException("Roblox application not found at expected path after upgrade: " + expectedPath);
		}
		App.Logger.Info("Resolved Roblox path: " + expectedPath);
		string arguments = _launchCommandLine;
		if (OperatingSystem.IsMacOS())
		{
			string text = _launchCommandLine.Trim();
			if (text.Length == 0 && !IsStudioLaunch)
			{
				text = "roblox-player:";
			}
			if (text.Length == 0)
			{
				arguments = "-n \"" + expectedPath + "\"";
			}
			else if (text.StartsWith('-'))
			{
				arguments = "-n \"" + expectedPath + "\" --args " + text;
			}
			else
			{
				App.Logger.Info("Delivering the launch url to Roblox through Launch Services");
				string value = text.Replace("\"", "%22", StringComparison.Ordinal);
				arguments = $"-n -a \"{expectedPath}\" \"{value}\"";
			}
		}
		ProcessStartInfo startInfo = new ProcessStartInfo
		{
			FileName = (OperatingSystem.IsMacOS() ? "open" : expectedPath),
			Arguments = arguments,
			WorkingDirectory = AppData.Directory,
			UseShellExecute = OperatingSystem.IsMacOS()
		};
		if (_launchMode == LaunchMode.Player && ShouldRunAsAdmin())
		{
			startInfo.Verb = "runas";
			startInfo.UseShellExecute = true;
		}
		else if (_launchMode == LaunchMode.StudioAuth)
		{
			Process.Start(startInfo);
			return;
		}
		List<int> autoclosePids = new List<int>();
		foreach (CustomIntegration customIntegration in App.Settings.Prop.CustomIntegrations)
		{
			if (customIntegration != null && customIntegration.PreLaunch)
			{
				await LaunchIntegrationAsync(customIntegration, autoclosePids);
			}
		}
		try
		{
			using Process process = Process.Start(startInfo);
			if (OperatingSystem.IsMacOS() && startInfo.FileName == "open")
			{
				_appPid = await GetRobloxProcessIdAsync(expectedName, TimeSpan.FromSeconds(5L));
				if (_appPid == 0)
				{
					_appPid = process.Id;
					App.Logger.Warn("Could not locate Roblox process, falling back to open PID.");
				}
				else
				{
					App.Logger.Info($"Detected Roblox process PID: {_appPid}");
				}
			}
			else
			{
				_appPid = process.Id;
			}
		}
		catch (Win32Exception ex2) when (ex2.NativeErrorCode == 1223)
		{
			return;
		}
		catch (Exception)
		{
			try
			{
				if (OperatingSystem.IsMacOS())
				{
					Directory.Delete(AppData.ExecutablePath, recursive: true);
				}
				else
				{
					File.Delete(AppData.ExecutablePath);
				}
			}
			catch (Exception ex4)
			{
				App.Logger.Warn("Failed to remove client to force a reinstall: " + ex4.Message);
			}
			throw;
		}
		if (_launchMode == LaunchMode.Player && App.Settings.Prop.Performance.UseGameCpuPriority)
		{
			App.Logger.Info("Game CPU priority: " + GameProcessPriority.Apply(_appPid, enabled: true));
		}
		App.Logger.Debug($"Started Roblox (PID {_appPid}). Launching Watcher...");
		if (!IsStudioLaunch)
		{
			foreach (CustomIntegration customIntegration2 in App.Settings.Prop.CustomIntegrations)
			{
				if (customIntegration2 != null && !customIntegration2.PreLaunch && !customIntegration2.SpecifyGame)
				{
					await LaunchIntegrationAsync(customIntegration2, autoclosePids);
				}
			}
		}
		await LaunchWatcherIfNeededAsync(autoclosePids);
		if (!App.Settings.Prop.Performance.UseLeanRuntime)
		{
			await Task.Delay(1000, _cancelTokenSource.Token);
		}
	}

	private async Task LaunchViaSober(List<int> autoclosePids)
	{
		if (App.Settings.Prop.ShowServerDetails)
		{
			App.SoberSettings.SetPreset("ServerLocationIndicatorEnabled", "false");
		}
		if (App.Settings.Prop.UseDiscordRichPresence)
		{
			App.SoberSettings.SetPreset("DiscordRpcEnabled", "false");
			App.SoberSettings.SetPreset("DiscordRpcShowJoinButton", "false");
		}
		if (App.Settings.Prop.UseDisableAppPatch)
		{
			App.SoberSettings.SetPreset("CloseOnLeave", "false");
		}
		App.SoberSettings.Save();
		AppStorageManager.Apply();
		if (_joinData.JoinType == GameJoinType.Unknown)
		{
			App.Logger.Warn("Unable to get join data");
		}
		App.Logger.Info($"Join Type: {_joinData.JoinType}");
		App.Logger.Info("Join Origin: " + (_joinData.JoinOrigin ?? "null"));
		App.Logger.Info("Place ID: " + (_joinData.PlaceId?.ToString(CultureInfo.InvariantCulture) ?? "null"));
		App.Logger.Info("Job ID: " + (_joinData.JobId ?? "null"));
		App.Logger.Info("Access Code: " + (_joinData.AccessCode ?? "null"));
		_launchCommandLine = await PreferredRegionRouting.ApplyAsync(_launchCommandLine, _cancelTokenSource.Token);
		if (_launchCommandLine.StartsWith("roblox://", StringComparison.Ordinal))
		{
			App.Logger.Info("Joining through roblox:// URI, skipping Better Matchmaking");
		}
		else
		{
			bool isFollowUser = PreferredRegionRouting.HasPreference && PreferredRegionRouting.IsFriendJoin(_joinData.JoinOrigin);
			if (!isFollowUser && App.Settings.Prop.EnableBetterMatchmaking && (_joinData.JoinOrigin == "friendServerListJoin" || _joinData.JoinOrigin == "placesListInHomePage"))
			{
				App.Logger.Debug("User is trying to join a friend, showing dialog");
				if (await Frontend.ShowMessageBox(string.Format((IFormatProvider?)CultureInfo.InvariantCulture, Strings.Menu_Bootstrapper_Experimental_BetterMatchmaking_FollowUser, default(ReadOnlySpan<object>)), MessageBoxImage.Question, MessageBoxButton.YesNo) == MessageBoxResult.Yes)
				{
					isFollowUser = true;
				}
			}
			string serverid = null;
			bool matchmakingCancelled = false;
			_matchmakingInProgress = true;
			_skipMatchmaking = false;
			_matchmakingCts = new CancellationTokenSource();
			IBootstrapperDialog? dialog = Dialog;
			if (dialog != null)
			{
				dialog.CancelButtonText = Strings.Bootstrapper_CancelButton_Skip;
			}
			try
			{
				if (PreferredRegionRouting.UseMatchmaking && _joinData.JoinType == GameJoinType.RequestGame && _joinData.PlaceId.HasValue && !isFollowUser)
				{
					if (_skipMatchmaking)
					{
						App.Logger.Info("Matchmaking was skipped due to user cancellation.");
						matchmakingCancelled = true;
					}
					else
					{
						serverid = await GetBetterMatchmakingServerID(_matchmakingCts.Token);
					}
				}
			}
			catch (OperationCanceledException)
			{
				App.Logger.Info("Better Matchmaking was Skipped, joining original server.");
				matchmakingCancelled = true;
			}
			catch (HttpRequestException exception)
			{
				Frontend.ShowConnectivityDialog(string.Format(CultureInfo.InvariantCulture, Strings.Dialog_Connectivity_UnableToConnect, "rovalra.com"), Strings.Dialog_Connectivity_MatchmakingFailed, MessageBoxImage.Warning, exception);
			}
			finally
			{
				IBootstrapperDialog? dialog2 = Dialog;
				if (dialog2 != null)
				{
					dialog2.CancelButtonText = Strings.Common_Cancel;
				}
				_matchmakingInProgress = false;
				_matchmakingCts?.Dispose();
				_matchmakingCts = null;
			}
			if (!matchmakingCancelled && !string.IsNullOrEmpty(serverid) && _joinData.PlaceId.HasValue)
			{
				string str = UrlBuilder.BuildPlacelauncherUrl(_joinData.PlaceId.Value, serverid);
				_launchCommandLine = _launchCommandLine.Replace(_joinData.PlaceLauncherUrl, HttpUtility.UrlEncode(str), StringComparison.Ordinal);
			}
		}
		SetStatus(Strings.Bootstrapper_Status_StartingSober);
		Processes.KillSober();
		App.Logger.Debug("Launching Sober via flatpak with args: " + _launchCommandLine);
		ProcessStartInfo startInfo = new ProcessStartInfo
		{
			FileName = "flatpak",
			Arguments = "run org.vinegarhq.Sober " + _launchCommandLine,
			UseShellExecute = false
		};
		try
		{
			DateTime launchTime = DateTime.UtcNow;
			using Process process = Process.Start(startInfo);
			_appPid = process.Id;
			App.Logger.Info($"Sober launched with PID {_appPid}");
			App.Logger.Debug("Launching Watcher...");
			await LaunchWatcherIfNeededAsync(autoclosePids);
			Task.Run(async () =>
			{
				string[] soberReadySignals = new string[2] { "will_handle_app_startup", "will_handle_start_game" };
				DateTime deadline = DateTime.UtcNow.AddMilliseconds(30000.0);
				try
				{
					string latestLog = Path.Combine(Paths.RobloxLogs, "latest.log");
					while (DateTime.UtcNow < deadline && (!File.Exists(latestLog) || !(File.GetLastWriteTimeUtc(latestLog) >= launchTime)))
					{
						await Task.Delay(50);
					}
					if (!File.Exists(latestLog))
					{
						App.Logger.Info("latest.log not found at " + latestLog + ", closing dialog.");
					}
					else
					{
						App.Logger.Info("Tailing " + latestLog + " for ready signal...");
						using FileStream fs = new FileStream(latestLog, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
						using StreamReader reader = new StreamReader(fs);
						while (DateTime.UtcNow < deadline)
						{
							string line = await reader.ReadLineAsync();
							if (line == null)
							{
								await Task.Delay(50);
							}
							else if (soberReadySignals.Any((string signal) => line.Contains(signal, StringComparison.Ordinal)))
							{
								App.Logger.Debug("Sober window ready, closing bootstrapper dialog.");
								Dialog?.CloseBootstrapper();
								return;
							}
						}
						App.Logger.Warn("Timed out waiting for Sober ready signal, closing dialog.");
					}
				}
				catch (Exception ex4)
				{
					App.Logger.Error("Log watcher error: " + ex4.Message + " — closing dialog.");
				}
				finally
				{
					Dialog?.CloseBootstrapper();
				}
			});
			while (!_cancelTokenSource.IsCancellationRequested)
			{
				await Task.Delay(2500, _cancelTokenSource.Token);
				Process[] processesByName = Process.GetProcessesByName("sober");
				bool flag = processesByName.Length != 0;
				Process[] array = processesByName;
				for (int num = 0; num < array.Length; num++)
				{
					array[num].Dispose();
				}
				if (!flag)
				{
					break;
				}
			}
			App.Logger.Info("Sober process exited");
		}
		catch (OperationCanceledException)
		{
			App.Logger.Info("Sober launch cancelled by user.");
		}
		catch (Exception ex3)
		{
			App.Logger.Error($"Failed to launch Sober via flatpak! {ex3}");
			string arg = (string.IsNullOrWhiteSpace(ex3.Message) ? "" : ("\n\n" + ex3.Message));
			await Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.Sober_LaunchFailed, "org.vinegarhq.Sober", arg), MessageBoxImage.Error);
			App.Terminate(ErrorCode.ERROR_CANCELLED);
		}
	}

	private async Task LaunchWatcherIfNeededAsync(List<int> autoclosePids, string? logFileName = null, string? logDirectory = null)
	{
		PerformanceRuntimePolicy performanceRuntimePolicy = PerformanceRuntimePolicy.Create(App.Settings.Prop.Performance.UseLeanRuntime, App.Settings.Prop.EnableActivityTracking, App.LaunchSettings.TestModeFlag.Active, autoclosePids.Count);
		bool flag = OperatingSystem.IsWindows() && _launchMode == LaunchMode.Player && App.Settings.Prop.EnableMacrosOnLaunch;
		if (!performanceRuntimePolicy.StartWatcher && !flag)
		{
			App.Logger.Info("No background watcher required for this session.");
			return;
		}
		try
		{
			Process.GetProcessById(_appPid);
		}
		catch
		{
			return;
		}
		if (performanceRuntimePolicy.WaitForLog && string.IsNullOrEmpty(logFileName))
		{
			string rbxLogDir = logDirectory ?? Paths.RobloxLogs;
			for (int i = 0; i < 60; i++)
			{
				if (Directory.Exists(rbxLogDir))
				{
					logFileName = (from f in Directory.GetFiles(rbxLogDir, "*.log")
						select new FileInfo(f) into f
						where f.CreationTimeUtc > DateTime.UtcNow.AddSeconds(-5.0)
						orderby f.CreationTimeUtc descending
						select f).FirstOrDefault()?.FullName;
				}
				if (logFileName != null)
				{
					break;
				}
				await Task.Delay(500, _cancelTokenSource.Token);
			}
		}
		using InterProcessLock interProcessLock = new InterProcessLock("WatcherLaunch", TimeSpan.FromSeconds(5L));
		if (interProcessLock.IsAcquired)
		{
			WatcherData value = new WatcherData
			{
				PerformanceMode = App.Settings.Prop.Performance.UseLeanRuntime,
				ProcessId = _appPid,
				LogFile = logFileName,
				AutoclosePids = autoclosePids,
				LaunchMode = _launchMode,
				AccessCode = _joinData.AccessCode
			};
			string text = Convert.ToBase64String(Encoding.UTF8.GetBytes(JsonSerializer.Serialize(value)));
			string text2 = "-watcher \"" + text + "\"";
			if (App.LaunchSettings.TestModeFlag.Active)
			{
				text2 += " -testmode";
			}
			Process.Start(Paths.Process, text2);
		}
	}

	private static async Task LaunchIntegrationAsync(CustomIntegration integration, List<int> autoclosePids)
	{
		if (App.Settings.Prop.Performance.UseLeanRuntime)
		{
			App.Logger.Info("Performance session: skipped integration '" + integration.Name + "'.");
			return;
		}
		App.Logger.Info($"Launching custom integration '{integration.Name}' ({integration.Location} {integration.LaunchArgs} - autoclose is {integration.AutoClose})");
		int num = 0;
		try
		{
			num = Process.Start(new ProcessStartInfo
			{
				FileName = integration.Location,
				Arguments = integration.LaunchArgs.Replace("\r\n", " ", StringComparison.Ordinal),
				WorkingDirectory = Path.GetDirectoryName(integration.Location),
				UseShellExecute = true
			}).Id;
		}
		catch (Exception ex)
		{
			App.Logger.Error("Failed to launch integration '" + integration.Name + "'! " + ex.Message);
		}
		if (integration.AutoClose && num != 0)
		{
			autoclosePids.Add(num);
		}
		if (integration.Delay != 0)
		{
			await Task.Delay(integration.Delay);
		}
	}

	private static async Task<int> GetRobloxProcessIdAsync(string expectedName, TimeSpan timeout)
	{
		string processName = expectedName.Replace(".app", "", StringComparison.Ordinal);
		DateTime startTime = DateTime.Now;
		while (DateTime.Now - startTime < timeout)
		{
			Process[] processesByName = Process.GetProcessesByName(processName);
			Process process = null;
			DateTime dateTime = DateTime.MinValue;
			Process[] array = processesByName;
			foreach (Process process2 in array)
			{
				try
				{
					if (process2.StartTime > dateTime)
					{
						dateTime = process2.StartTime;
						process = process2;
					}
				}
				catch (Exception)
				{
				}
			}
			if (process != null)
			{
				return process.Id;
			}
			await Task.Delay(100);
		}
		return 0;
	}

	private bool ShouldRunAsAdmin()
	{
		if (!OperatingSystem.IsWindows())
		{
			return false;
		}
		foreach (RegistryKey root in WindowsRegistry.Roots)
		{
			using RegistryKey registryKey = root.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatFlags\\Layers");
			if (registryKey != null)
			{
				string text = (string)registryKey.GetValue(AppData.ExecutablePath);
				if (text != null && text.Contains("RUNASADMIN", StringComparison.OrdinalIgnoreCase))
				{
					return true;
				}
			}
		}
		return false;
	}

	public bool Cancel()
	{
		if (_matchmakingInProgress)
		{
			App.Logger.Info("Skipping Better MatchMaking.");
			_skipMatchmaking = true;
			_matchmakingCts?.Cancel();
			SetStatus(Strings.Bootstrapper_Status_SkippingMatchmaking);
			return true;
		}
		if (_cancelTokenSource.IsCancellationRequested)
		{
			return false;
		}
		App.Logger.Info("Cancelling launch...");
		_cancelTokenSource.Cancel();
		IBootstrapperDialog? dialog = Dialog;
		if (dialog != null)
		{
			dialog.CancelEnabled = false;
		}
		if (_isInstalling)
		{
			try
			{
				if (OperatingSystem.IsWindows())
				{
					WindowsRegistry.RegisterClientLocation(IsStudioLaunch, null);
				}
				if (Directory.Exists(_latestVersionDirectory))
				{
					Directory.Delete(_latestVersionDirectory, recursive: true);
				}
			}
			catch (Exception value)
			{
				App.Logger.Error($"Could not fully clean up installation! {value}");
			}
		}
		else if (_appPid != 0)
		{
			try
			{
				using Process process = Process.GetProcessById(_appPid);
				process.Kill();
			}
			catch (Exception ex)
			{
				App.Logger.Warn($"Failed to kill process {_appPid}: {ex.Message}");
			}
		}
		if (OperatingSystem.IsLinux())
		{
			try
			{
				Process[] processesByName = Process.GetProcessesByName("sober");
				foreach (Process process2 in processesByName)
				{
					try
					{
						App.Logger.Info($"Killing sober process (PID {process2.Id})");
						process2.Kill(entireProcessTree: true);
					}
					catch (Exception value2)
					{
						App.Logger.Error($"Failed to kill sober process (PID {process2.Id}) {value2}");
					}
				}
			}
			catch (Exception value3)
			{
				App.Logger.Error($"Failed to enumerate sober processes. {value3}");
			}
		}
		_appLock?.Dispose();
		Dialog?.CloseBootstrapper();
		App.SoftTerminate(ErrorCode.ERROR_CANCELLED);
		return false;
	}

	private static bool TryDeleteRobloxInDirectory(string dir)
	{
		string[] array = new string[2]
		{
			App.RobloxPlayerAppName,
			App.RobloxStudioAppName
		};
		foreach (string path in array)
		{
			string path2 = Path.Combine(dir, path);
			if (!(OperatingSystem.IsMacOS() ? Directory.Exists(path2) : File.Exists(path2)))
			{
				continue;
			}
			try
			{
				if (OperatingSystem.IsMacOS())
				{
					Directory.Delete(path2, recursive: true);
					continue;
				}
				File.SetAttributes(path2, FileAttributes.Normal);
				File.Delete(path2);
			}
			catch (Exception)
			{
				return false;
			}
		}
		return true;
	}

	public static void CleanupVersionsFolder()
	{
		if (OperatingSystem.IsLinux())
		{
			Bootstrapper? bootstrapper = App.Bootstrapper;
			if (bootstrapper == null || !bootstrapper.IsStudioLaunch)
			{
				App.Logger.Info("Skipping cleanup on Linux (Player) to protect Sober's data directory.");
				return;
			}
		}
		if (App.LaunchSettings.BackgroundUpdaterFlag.Active)
		{
			App.Logger.Info("Background updater tried to cleanup, stopping!");
			return;
		}
		if (!Directory.Exists(Paths.Versions))
		{
			App.Logger.Info("Versions directory does not exist, skipping cleanup.");
			return;
		}
		string[] directories = Directory.GetDirectories(Paths.Versions);
		foreach (string text in directories)
		{
			string fileName = Path.GetFileName(text);
			if (OperatingSystem.IsLinux() && fileName == "Sober")
			{
				continue;
			}
			bool num;
			if (!App.Settings.Prop.StaticDirectory)
			{
				if (!(fileName != App.PlayerState.Prop.VersionGuid))
				{
					continue;
				}
				num = fileName != App.StudioState.Prop.VersionGuid;
			}
			else
			{
				if (!(fileName != "WindowsPlayer") || !(fileName != "WindowsStudio64") || !(fileName != "MacPlayer"))
				{
					continue;
				}
				num = fileName != "MacStudio";
			}
			if (!num || !TryDeleteRobloxInDirectory(text))
			{
				continue;
			}
			try
			{
				Directory.Delete(text, recursive: true);
			}
			catch (UnauthorizedAccessException)
			{
				try
				{
					Filesystem.AssertReadOnlyDirectory(text);
					Directory.Delete(text, recursive: true);
				}
				catch (Exception exception)
				{
					App.Logger.Error(exception, "Failed to delete " + text);
				}
			}
			catch (IOException exception2)
			{
				App.Logger.Error(exception2, "Failed to delete " + text);
			}
		}
	}

	private void MigrateCompatibilityFlags()
	{
		if (!OperatingSystem.IsWindows())
		{
			return;
		}
		string text = Path.Combine(Paths.Versions, AppData.DistributionState.VersionGuid, AppData.ExecutableName);
		string text2 = Path.Combine(_latestVersionDirectory, AppData.ExecutableName);
		using RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatFlags\\Layers");
		if (registryKey.GetValue(text) is string value)
		{
			App.Logger.Info($"Migrating app compatibility flags from {text} to {text2}...");
			registryKey.SetValueSafe(text2, value);
			registryKey.DeleteValueSafe(text);
		}
	}

	private static void KillRobloxPlayers()
	{
		List<Process> list = new List<Process>();
		string processName = (OperatingSystem.IsMacOS() ? "RobloxPlayer" : "RobloxPlayerBeta");
		list.AddRange(Process.GetProcessesByName(processName));
		list.AddRange(Process.GetProcessesByName("RobloxCrashHandler"));
		foreach (Process item in list)
		{
			try
			{
				item.Kill();
				item.WaitForExit();
			}
			catch (Exception exception)
			{
				App.Logger.Error(exception, $"Failed to close process {item.Id}");
			}
		}
	}

	private async Task UpgradeRoblox()
	{
		if (!App.Settings.Prop.UpdateRoblox)
		{
			SetStatus(Strings.Bootstrapper_Status_CancelUpgrade);
			App.Logger.Info("Upgrading disabled, cancelling the upgrade.");
			if (Directory.Exists(_latestVersionDirectory))
			{
				await Task.Delay(2000);
				return;
			}
			Frontend.ShowMessageBox(Strings.Bootstrapper_Dialog_NoUpgradeWithoutClient, MessageBoxImage.Warning);
		}
		SetStatus(string.IsNullOrEmpty(AppData.DistributionState.VersionGuid) ? Strings.Bootstrapper_Status_Installing : Strings.Bootstrapper_Status_Upgrading);
		Directory.CreateDirectory(Paths.Base);
		Directory.CreateDirectory(Paths.Downloads);
		Directory.CreateDirectory(Paths.Versions);
		_isInstalling = true;
		if (!App.LaunchSettings.BackgroundUpdaterFlag.Active && !IsStudioLaunch)
		{
			KillRobloxPlayers();
		}
		if (!App.LaunchSettings.BackgroundUpdaterFlag.Active && Directory.Exists(_latestVersionDirectory))
		{
			try
			{
				Directory.Delete(_latestVersionDirectory, recursive: true);
			}
			catch (Exception exception)
			{
				App.Logger.Error(exception, "Failed to delete the latest version directory");
			}
		}
		Directory.CreateDirectory(_latestVersionDirectory);
		if (OperatingSystem.IsMacOS())
		{
			string resourcesBackupPath = GetResourcesBackupPath(_latestVersionGuid);
			if (Directory.Exists(resourcesBackupPath))
			{
				try
				{
					Directory.Delete(resourcesBackupPath, recursive: true);
					App.Logger.Info("Deleted existing mod backup for " + _latestVersionGuid);
				}
				catch (Exception ex)
				{
					App.Logger.Warn("Failed to delete mod backup: " + ex.Message);
				}
			}
		}
		List<string> cachedPackageHashes = (from x in Directory.GetFiles(Paths.Downloads)
			select Path.GetFileName(x)).ToList();
		long num = 0L;
		List<Package> source = _versionPackageManifest.Where((Package p) => p.Name != "RobloxPlayerInstaller.exe").ToList();
		num += source.Where((Package x) => !cachedPackageHashes.Contains(x.Signature)).Sum((Func<Package, long>)((Package x) => x.PackedSize));
		num += ((IEnumerable<Package>)source).Sum((Func<Package, long>)((Package x) => x.Size));
		if (Filesystem.GetFreeDiskSpace(Paths.Base) < num)
		{
			await Frontend.ShowMessageBox(Strings.Bootstrapper_NotEnoughSpace, MessageBoxImage.Error);
			App.Terminate(ErrorCode.ERROR_INSTALL_FAILURE);
			return;
		}
		if (Dialog != null)
		{
			Dialog.ProgressIndeterminate = false;
			Dialog.TaskbarProgressState = TaskbarItemProgressState.Normal;
			Dialog.ProgressMaximum = 10000;
			_totalPackagedBytes = _versionPackageManifest.Where((Package p) => p.Name != "RobloxPlayerInstaller.exe").Sum((Package package3) => package3.PackedSize);
			_progressIncrement = 10000.0 / (double)_totalPackagedBytes;
			_taskbarProgressMaximum = 1.0;
			_taskbarProgressIncrement = _taskbarProgressMaximum / (double)_totalPackagedBytes;
		}
		List<Task> packageTasks = new List<Task>();
		IOrderedEnumerable<Package> orderedEnumerable = from p in _versionPackageManifest
			where p.Name != "RobloxPlayerInstaller.exe"
			orderby p.PackedSize descending
			select p;
		SemaphoreSlim downloadSemaphore = new SemaphoreSlim((App.Settings.Prop.MaxThreadDownload <= 0) ? 1 : App.Settings.Prop.MaxThreadDownload);
		try
		{
			foreach (Package package in orderedEnumerable)
			{
				await downloadSemaphore.WaitAsync(_cancelTokenSource.Token);
				Task item = Task.Run(async () =>
				{
					_ = 1;
					try
					{
						await DownloadPackage(package);
						if (package.Name != "WebView2RuntimeInstaller.zip")
						{
							await ExtractPackage(package);
						}
					}
					finally
					{
						downloadSemaphore.Release();
					}
				}, _cancelTokenSource.Token);
				packageTasks.Add(item);
			}
			await Task.WhenAll(packageTasks);
			if (_cancelTokenSource.IsCancellationRequested)
			{
				return;
			}
			if (Dialog != null)
			{
				Dialog.ProgressIndeterminate = true;
				Dialog.TaskbarProgressState = TaskbarItemProgressState.Indeterminate;
				SetStatus(Strings.Bootstrapper_Status_Configuring);
			}
			if (OperatingSystem.IsWindows() && App.State.Prop.PromptWebView2Install)
			{
				using RegistryKey hklmKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\WOW6432Node\\Microsoft\\EdgeUpdate\\Clients\\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}");
				using RegistryKey hkcuKey = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\EdgeUpdate\\Clients\\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}");
				if (hklmKey != null || hkcuKey != null)
				{
					App.State.Prop.PromptWebView2Install = true;
				}
				else if (await Frontend.ShowMessageBox(Strings.Bootstrapper_WebView2NotFound, MessageBoxImage.Warning, MessageBoxButton.YesNo, MessageBoxResult.Yes) != MessageBoxResult.Yes)
				{
					App.State.Prop.PromptWebView2Install = false;
				}
				else
				{
					App.Logger.Info("Installing WebView2 runtime...");
					Package package2 = _versionPackageManifest.Find((Package x) => x.Name == "WebView2RuntimeInstaller.zip");
					if (package2 == null)
					{
						App.Logger.Info("Aborted runtime install because package does not exist, has WebView2 been added in this Roblox version yet?");
						return;
					}
					string baseDirectory = Path.Combine(_latestVersionDirectory, PackageDirectoryMap[package2.Name]);
					await ExtractPackage(package2);
					SetStatus(Strings.Bootstrapper_Status_InstallingWebView2);
					await Process.Start(new ProcessStartInfo
					{
						WorkingDirectory = baseDirectory,
						FileName = Path.Combine(baseDirectory, "MicrosoftEdgeWebview2Setup.exe"),
						Arguments = "/silent /install"
					}).WaitForExitAsync();
					App.Logger.Info("Finished installing runtime");
					Directory.Delete(baseDirectory, recursive: true);
				}
			}
			if (OperatingSystem.IsMacOS())
			{
				string[] array = new string[2] { "RobloxPlayer.app", "RobloxStudio.app" };
				string[] array2 = array;
				foreach (string path in array2)
				{
					string text = Path.Combine(_latestVersionDirectory, path);
					if (!Directory.Exists(text))
					{
						continue;
					}
					string path2 = Path.Combine(text, "Contents", "MacOS");
					if (Directory.Exists(path2))
					{
						string[] files = Directory.GetFiles(path2);
						for (int num3 = 0; num3 < files.Length; num3++)
						{
							new FileInfo(files[num3]).UnixFileMode |= UnixFileMode.OtherExecute | UnixFileMode.GroupExecute | UnixFileMode.UserExecute;
						}
					}
					using Process process = Process.Start("xattr", "-dr com.apple.quarantine \"" + text + "\"");
					await process.WaitForExitAsync();
				}
			}
			MigrateCompatibilityFlags();
			AppData.DistributionState.VersionGuid = _latestVersionGuid;
			AppData.DistributionState.PackageHashes.Clear();
			foreach (Package item2 in _versionPackageManifest)
			{
				AppData.DistributionState.PackageHashes.Add(item2.Name, item2.Signature);
			}
			CleanupVersionsFolder();
			List<string> list = new List<string>();
			list.AddRange(App.PlayerState.Prop.PackageHashes.Values);
			list.AddRange(App.StudioState.Prop.PackageHashes.Values);
			if (!App.Settings.Prop.DebugDisableVersionPackageCleanup)
			{
				foreach (string item3 in cachedPackageHashes)
				{
					if (!list.Contains(item3))
					{
						App.Logger.Info("Deleting unused package " + item3);
						try
						{
							File.Delete(Path.Combine(Paths.Downloads, item3));
						}
						catch (Exception exception2)
						{
							App.Logger.Error(exception2, "Failed to delete " + item3 + "!");
						}
					}
				}
			}
			App.State.Prop.ForceReinstall = false;
			App.State.Save();
			AppData.DistributionStateManager.Save();
			if (OperatingSystem.IsWindows())
			{
				WindowsRegistry.UpdateEstimatedSize();
			}
			if (!IsStudioLaunch)
			{
				InitializeModFolders();
			}
			_isInstalling = false;
		}
		finally
		{
			if (downloadSemaphore != null)
			{
				((IDisposable)downloadSemaphore).Dispose();
			}
		}
	}

	private static string? ParseFlatpakInstallStep(string line)
	{
		if (string.IsNullOrWhiteSpace(line))
		{
			return null;
		}
		line = Regex.Replace(line, "\\x1B\\[[0-9;?]*[ -/]*[@-~]", string.Empty).Replace('\r', ' ').Trim();
		int num = line.IndexOf("Installing", StringComparison.OrdinalIgnoreCase);
		if (num < 0)
		{
			return null;
		}
		return line.Substring(num).Trim();
	}

	private async Task<bool> EnsureSoberInstalledAsync()
	{
		SetStatus(Strings.Bootstrapper_Status_CheckingFlatpak);
		ProcessStartInfo startInfo = new ProcessStartInfo
		{
			FileName = "flatpak",
			Arguments = "--version",
			UseShellExecute = false,
			CreateNoWindow = true
		};
		try
		{
			using Process checkProcess = Process.Start(startInfo);
			if (checkProcess == null)
			{
				throw new InvalidOperationException("Failed to start flatpak process.");
			}
			await checkProcess.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30L));
			if (checkProcess.ExitCode != 0)
			{
				throw new InvalidOperationException("Flatpak returned a non-zero exit code.");
			}
		}
		catch (TimeoutException exception)
		{
			App.Logger.Error(exception, "Timed out while checking Flatpak installation.");
			await Frontend.ShowMessageBox("Timed out while checking Flatpak installation. Please make sure Flatpak is working and try again.", MessageBoxImage.Error);
			App.Terminate(ErrorCode.ERROR_CANCELLED);
			return false;
		}
		catch (Exception exception2)
		{
			App.Logger.Error(exception2, "Flatpak not found.");
			await Frontend.ShowMessageBox("Flatpak is required on Linux.\n\nPlease install Flatpak first, then launch Merostrap again.", MessageBoxImage.Error);
			App.Terminate(ErrorCode.ERROR_CANCELLED);
			return false;
		}
		ProcessStartInfo startInfo2 = new ProcessStartInfo
		{
			FileName = "flatpak",
			Arguments = "info org.vinegarhq.Sober",
			UseShellExecute = false,
			CreateNoWindow = true
		};
		try
		{
			using Process checkProcess = Process.Start(startInfo2);
			if (checkProcess != null)
			{
				await checkProcess.WaitForExitAsync();
				if (checkProcess.ExitCode == 0)
				{
					App.Logger.Info("Sober is already installed.");
					return true;
				}
			}
		}
		catch (Exception exception3)
		{
			App.Logger.Error(exception3, "Failed to check Sober installation status.");
		}
		App.Logger.Info("Installing Sober...");
		if (Dialog != null)
		{
			Dialog.ProgressIndeterminate = true;
			Dialog.TaskbarProgressState = TaskbarItemProgressState.Indeterminate;
		}
		SetStatus(Strings.Bootstrapper_Status_InstallingSober);
		ProcessStartInfo startInfo3 = new ProcessStartInfo
		{
			FileName = "flatpak",
			Arguments = "install --noninteractive flathub org.vinegarhq.Sober",
			UseShellExecute = false,
			RedirectStandardOutput = true,
			RedirectStandardError = true,
			CreateNoWindow = true
		};
		List<string> errorLines;
		using (Process installProcess = Process.Start(startInfo3))
		{
			if (installProcess == null)
			{
				await Frontend.ShowMessageBox("Failed to start Sober installation via Flatpak.", MessageBoxImage.Error);
				App.Terminate(ErrorCode.ERROR_CANCELLED);
				return false;
			}
			errorLines = new List<string>();
			InlineArray3<Task> buffer = default;
			buffer[0] = ReadInstallStream(installProcess.StandardOutput);
			buffer[1] = ReadInstallStream(installProcess.StandardError);
			buffer[2] = installProcess.WaitForExitAsync();
			await Task.WhenAll(buffer);
			if (installProcess.ExitCode != 0)
			{
				string text = string.Join('\n', errorLines.TakeLast(8));
				string arg = (string.IsNullOrWhiteSpace(text) ? "" : ("\n\n" + text));
				await Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.Sober_FlatpakInstallFailed, "org.vinegarhq.Sober", arg), MessageBoxImage.Error);
				App.Terminate(ErrorCode.ERROR_CANCELLED);
				return false;
			}
			App.Logger.Info("Sober installation complete.");
			SetStatus(Strings.Bootstrapper_Status_StartingSober);
			return true;
		}
		async Task ReadInstallStream(StreamReader reader)
		{
			while (true)
			{
				string text2 = await reader.ReadLineAsync();
				if (text2 == null)
				{
					break;
				}
				App.Logger.Info("[flatpak] " + text2);
				string text3 = ParseFlatpakInstallStep(text2);
				if (!string.IsNullOrEmpty(text3))
				{
					SetStatus(text3);
				}
				else if (!string.IsNullOrWhiteSpace(text2))
				{
					errorLines.Add(text2.Trim());
				}
			}
		}
	}

	private async Task UpdateSoberFlatpakAsync()
	{
		App.Logger.Info("Running 'flatpak update org.vinegarhq.Sober'.");
		SetStatus(Strings.Bootstrapper_Status_UpdatingSober);
		if (Dialog != null)
		{
			Dialog.ProgressIndeterminate = false;
			Dialog.ProgressMaximum = 100;
			Dialog.ProgressValue = 0;
			Dialog.TaskbarProgressState = TaskbarItemProgressState.Normal;
			Dialog.TaskbarProgressValue = 0.0;
		}
		ProcessStartInfo startInfo = new ProcessStartInfo
		{
			FileName = "flatpak",
			Arguments = "update --user org.vinegarhq.Sober --assumeyes",
			UseShellExecute = false,
			RedirectStandardOutput = true,
			RedirectStandardError = true,
			CreateNoWindow = true
		};
		TimeSpan delay = TimeSpan.FromMinutes(20L);
		using CancellationTokenSource cts = new CancellationTokenSource(delay);
		CancellationTokenSource linkedCts = CancellationTokenSource.CreateLinkedTokenSource(cts.Token, _cancelTokenSource.Token);
		try
		{
			_ = 1;
			try
			{
				Process process = Process.Start(startInfo) ?? throw new InvalidOperationException("Failed to start flatpak update process.");
				try
				{
					Task.Run(async () =>
					{
						try
						{
							while (!linkedCts.Token.IsCancellationRequested)
							{
								string text = await process.StandardOutput.ReadLineAsync();
								if (text == null)
								{
									break;
								}
								if (!string.IsNullOrWhiteSpace(text))
								{
									App.Logger.Info("[flatpak] " + text);
									Match match = FlatpakProgressRegex.Match(text);
									int num = 0;
									int num2 = 0;
									if (match.Success)
									{
										num = int.Parse(match.Groups["current"].Value, CultureInfo.InvariantCulture);
										num2 = int.Parse(match.Groups["total"].Value, CultureInfo.InvariantCulture);
									}
									Match match2 = FlatpakPercentRegex.Match(text);
									int num3 = -1;
									if (match2.Success)
									{
										num3 = int.Parse(match2.Groups["percent"].Value, CultureInfo.InvariantCulture);
									}
									if (match.Success && match2.Success)
									{
										double num4 = 100.0 / (double)num2;
										int value = (int)Math.Round((double)(num - 1) * num4 + (double)num3 / 100.0 * num4);
										value = Math.Clamp(value, 0, 100);
										if (Dialog != null)
										{
											Dialog.ProgressValue = value;
											Dialog.TaskbarProgressValue = (double)value / 100.0;
											SetStatus(string.Format(CultureInfo.InvariantCulture, Strings.Bootstrapper_Status_UpdatingSoberProgress, num, num2, num3));
										}
									}
									else if (match.Success)
									{
										int value2 = (int)Math.Round((double)(num - 1) * (100.0 / (double)num2));
										value2 = Math.Clamp(value2, 0, 100);
										if (Dialog != null)
										{
											Dialog.ProgressValue = value2;
											Dialog.TaskbarProgressValue = (double)value2 / 100.0;
											SetStatus(string.Format(CultureInfo.InvariantCulture, Strings.Bootstrapper_Status_UpdatingSoberBasic, num, num2));
										}
									}
									else
									{
										string text2 = text.Trim();
										if (!string.IsNullOrEmpty(text2) && text2.Length < 80)
										{
											SetStatus(text2);
										}
									}
								}
							}
						}
						catch (OperationCanceledException)
						{
							App.Logger.Info("Output reading cancelled.");
						}
						catch (Exception ex3)
						{
							App.Logger.Warn("Error reading flatpak output: " + ex3.Message);
						}
					}, linkedCts.Token);
					Task.Run(async () =>
					{
						try
						{
							while (!linkedCts.Token.IsCancellationRequested)
							{
								string text = await process.StandardError.ReadLineAsync();
								if (text == null)
								{
									break;
								}
								if (!string.IsNullOrWhiteSpace(text))
								{
									App.Logger.Warn("[flatpak-err] " + text);
								}
							}
						}
						catch (OperationCanceledException)
						{
						}
						catch (Exception ex3)
						{
							App.Logger.Warn("Error reading flatpak stderr: " + ex3.Message);
						}
					}, linkedCts.Token);
					await Task.WhenAny(process.WaitForExitAsync(linkedCts.Token), Task.Delay(-1, linkedCts.Token));
					if (!process.HasExited && linkedCts.IsCancellationRequested)
					{
						App.Logger.Warn("Update cancelled by user or timeout. Killing process.");
						try
						{
							process.Kill(entireProcessTree: true);
						}
						catch
						{
						}
					}
					if (!process.HasExited)
					{
						await process.WaitForExitAsync();
					}
					if (process.ExitCode != 0 && process.ExitCode != -1)
					{
						App.Logger.Warn($"flatpak update exited with code {process.ExitCode}.");
					}
					else if (process.ExitCode == 0)
					{
						App.Logger.Info("Sober update finished successfully.");
						if (Dialog != null)
						{
							Dialog.ProgressValue = 100;
							Dialog.TaskbarProgressValue = 1.0;
							SetStatus(Strings.Bootstrapper_Status_SoberUpdateComplete);
						}
					}
				}
				finally
				{
					if (process != null)
					{
						((IDisposable)process).Dispose();
					}
				}
			}
			catch (OperationCanceledException) when (cts.IsCancellationRequested)
			{
				App.Logger.Warn("Update timed out after 20 minutes.");
			}
			catch (Exception exception)
			{
				App.Logger.Error(exception, "Failed to update Sober.");
			}
			finally
			{
				if (Dialog != null)
				{
					Dialog.ProgressIndeterminate = true;
					Dialog.ProgressValue = 0;
					Dialog.TaskbarProgressValue = 0.0;
					Dialog.TaskbarProgressState = TaskbarItemProgressState.None;
				}
			}
		}
		finally
		{
			if (linkedCts != null)
			{
				((IDisposable)linkedCts).Dispose();
			}
		}
	}

	private static async Task ExtractTarXzAsync(string archivePath, string outputDir, CancellationToken cancellationToken)
	{
		ProcessStartInfo startInfo = new ProcessStartInfo("tar", $"-xJf \"{archivePath}\" -C \"{outputDir}\"")
		{
			UseShellExecute = false,
			RedirectStandardError = true,
			RedirectStandardOutput = true
		};
		using Process process = Process.Start(startInfo);
		if (process == null)
		{
			throw new InvalidOperationException("Failed to start tar");
		}
		await process.WaitForExitAsync(cancellationToken);
		if (process.ExitCode != 0)
		{
			throw new InvalidOperationException("tar extraction failed: " + await process.StandardError.ReadToEndAsync(cancellationToken));
		}
	}

	private async Task SetupDxvkAndRendererAsync()
	{
		StudioRenderer studioRenderer = App.Settings.Prop.StudioRenderer;
		SetRendererFastFlags(studioRenderer switch
		{
			StudioRenderer.D3D11 => "D3D11", 
			StudioRenderer.D3D11FL10 => "D3D11FL10", 
			StudioRenderer.DXVK => "D3D11", 
			StudioRenderer.Vulkan => "Vulkan", 
			StudioRenderer.OpenGL => "OpenGL", 
			_ => "D3D11", 
		});
		if (studioRenderer == StudioRenderer.DXVK)
		{
			string url = "https://github.com/doitsujin/dxvk/releases/download/v2.7.1/dxvk-2.7.1.tar.gz";
			await InstallDxvkAsync(url);
		}
		else
		{
			CleanupDxvkDlls();
		}
		ApplyRendererFlagsToVersionDirectory();
	}

	private static void SetRendererFastFlags(string prefer)
	{
		string[] array = new string[4] { "D3D11", "D3D11FL10", "Vulkan", "OpenGL" };
		foreach (string text in array)
		{
			bool flag = text == prefer;
			App.FastFlags.SetValue("FFlagDebugGraphicsPrefer" + text, flag ? "True" : "False");
			App.FastFlags.SetValue("FFlagDebugGraphicsDisable" + text, flag ? "False" : "True");
		}
	}

	private async Task InstallDxvkAsync(string url)
	{
		string cacheFile = Path.Combine(Paths.Downloads, "dxvk-2.7.1.tar.gz");
		Directory.CreateDirectory(Paths.Downloads);
		if (DxvkDlls.Any((string dll) => File.Exists(Path.Combine(_latestVersionDirectory, dll))))
		{
			return;
		}
		if (!File.Exists(cacheFile))
		{
			SetStatus(Strings.Bootstrapper_Status_DownloadingDXVK);
			await DownloadFileWithProgressAsync(url, cacheFile);
			IBootstrapperDialog? dialog = Dialog;
			if (dialog != null)
			{
				dialog.ProgressIndeterminate = true;
			}
		}
		SetStatus(Strings.Bootstrapper_Status_ExtractingDXVK);
		await ExtractDxvkArchive(cacheFile, _latestVersionDirectory);
	}

	private static async Task ExtractDxvkArchive(string archivePath, string outputDir)
	{
		await Task.Run(() =>
		{
			using FileStream baseInputStream = File.OpenRead(archivePath);
			using GZipInputStream inputStream = new GZipInputStream(baseInputStream);
			using TarInputStream tarInputStream = new TarInputStream(inputStream, Encoding.UTF8);
			TarEntry nextEntry;
			while ((nextEntry = tarInputStream.GetNextEntry()) != null)
			{
				if (!nextEntry.IsDirectory)
				{
					string text = nextEntry.Name.Replace('\\', '/');
					if (text.Contains("/x64/", StringComparison.OrdinalIgnoreCase) && text.EndsWith(".dll", StringComparison.OrdinalIgnoreCase))
					{
						string fileName = Path.GetFileName(text);
						if (DxvkDlls.Contains(fileName))
						{
							using FileStream outputStream = File.Create(Path.Combine(outputDir, fileName));
							tarInputStream.CopyEntryContents(outputStream);
						}
					}
				}
			}
		});
	}

	private void CleanupDxvkDlls()
	{
		string[] dxvkDlls = DxvkDlls;
		foreach (string text in dxvkDlls)
		{
			string path = Path.Combine(_latestVersionDirectory, text);
			if (File.Exists(path))
			{
				try
				{
					File.Delete(path);
				}
				catch (Exception ex)
				{
					App.Logger.Error("Failed to delete " + text + " in CleanupDxvkDlls: " + ex.Message);
				}
			}
		}
	}

	private void ApplyRendererFlagsToVersionDirectory()
	{
		if (!UseFastFlagsForLaunch || string.IsNullOrEmpty(_latestVersionDirectory))
		{
			return;
		}
		string text = Path.Combine(OperatingSystem.IsMacOS() ? Path.Combine(_latestVersionDirectory, AppData.ExecutableName, "Contents", "MacOS") : _latestVersionDirectory, "ClientSettings");
		Directory.CreateDirectory(text);
		string path = Path.Combine(text, "ClientAppSettings.json");
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		if (File.Exists(path))
		{
			try
			{
				dictionary = JsonSerializer.Deserialize<Dictionary<string, object>>(File.ReadAllText(path)) ?? new Dictionary<string, object>();
			}
			catch
			{
			}
		}
		foreach (KeyValuePair<string, object> item in App.FastFlags.Prop.Where((KeyValuePair<string, object> kv) => kv.Key.StartsWith("FFlagDebugGraphicsPrefer", StringComparison.Ordinal) || kv.Key.StartsWith("FFlagDebugGraphicsDisable", StringComparison.Ordinal)).ToDictionary((KeyValuePair<string, object> kv) => kv.Key, (KeyValuePair<string, object> kv) => kv.Value))
		{
			dictionary[item.Key] = item.Value;
		}
		string contents = JsonSerializer.Serialize(dictionary, _indentedJsonOptions);
		File.WriteAllText(path, contents);
	}

	private async Task SetupWebView2Async(WineManager wineMgr)
	{
		if (!OperatingSystem.IsLinux() || !IsStudioLaunch)
		{
			return;
		}
		string text = await wineMgr.QueryRegistryValueAsync("HKLM\\Software\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Microsoft EdgeWebView", "DisplayVersion", _cancelTokenSource.Token);
		bool flag = !string.IsNullOrEmpty(text);
		if (App.Settings.Prop.EnableWebView2 == flag)
		{
			App.Logger.Info(App.Settings.Prop.EnableWebView2 ? "WebView2 already installed, skipping." : "WebView2 already not installed, skipping.");
			return;
		}
		if (App.Settings.Prop.EnableWebView2)
		{
			App.Logger.Info("Downloading WebView2 Runtime via Wine...");
			SetStatus(Strings.Bootstrapper_Status_DownloadingWebView2);
			try
			{
				if (!(await wineMgr.RegistryKeyExistsAsync("HKCU\\Software\\Wine\\AppDefaults\\msedgewebview2.exe", _cancelTokenSource.Token)))
				{
					await wineMgr.AddRegistryValueAsync("HKCU\\Software\\Wine\\AppDefaults\\msedgewebview2.exe", "Version", "win7", "REG_SZ", _cancelTokenSource.Token);
				}
			}
			catch (Exception ex)
			{
				App.Logger.Error("Failed to set WebView2 AppDefaults override: " + ex.Message);
			}
			string version = await GetWebView2LatestVersionAsync();
			if (version == null)
			{
				App.Logger.Warn("Could not resolve the latest WebView2 Runtime version, skipping install.");
				return;
			}
			(string, string)? tuple = await GetWebView2RuntimeDownloadAsync(version);
			if (!tuple.HasValue)
			{
				App.Logger.Warn("Could not resolve a WebView2 Runtime download, skipping install.");
				return;
			}
			string tempFile = Path.Combine(Path.GetTempPath(), tuple.Value.Item2);
			try
			{
				await DownloadFileWithProgressAsync(tuple.Value.Item1, tempFile);
				IBootstrapperDialog? dialog = Dialog;
				if (dialog != null)
				{
					dialog.ProgressIndeterminate = true;
				}
				SetStatus(Strings.Bootstrapper_Status_InstallingWebView2);
				int num = await wineMgr.RunAsync(tempFile, new string[3] { "--msedgewebview", "--do-not-launch-msedge", "--system-level" }, null, _cancelTokenSource.Token);
				App.Logger.Info((num == 0) ? ("WebView2 Runtime " + version + " installed successfully.") : $"WebView2 installer exited with code {num}.");
			}
			catch (Exception ex2)
			{
				App.Logger.Error("Failed to install WebView2: " + ex2.Message);
			}
			finally
			{
				if (File.Exists(tempFile))
				{
					File.Delete(tempFile);
				}
			}
			return;
		}
		App.Logger.Info("Uninstalling WebView2 Runtime via Wine...");
		SetStatus(Strings.Bootstrapper_Status_UninstallingWebView2);
		InlineArray9<string> buffer = default;
		buffer[0] = wineMgr.PrefixDir;
		buffer[1] = "drive_c";
		buffer[2] = "Program Files (x86)";
		buffer[3] = "Microsoft";
		buffer[4] = "EdgeWebView";
		buffer[5] = "Application";
		buffer[6] = text;
		buffer[7] = "Installer";
		buffer[8] = "setup.exe";
		string text2 = Path.Combine(buffer);
		if (!File.Exists(text2))
		{
			App.Logger.Warn("WebView2 uninstaller not found at " + text2 + ", skipping uninstall.");
			return;
		}
		try
		{
			int exitCode = await wineMgr.RunAsync(text2, new string[4] { "--msedgewebview", "--uninstall", "--system-level", "--force-uninstall" }, null, _cancelTokenSource.Token);
			string value = await wineMgr.QueryRegistryValueAsync("HKLM\\Software\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Microsoft EdgeWebView", "DisplayVersion", _cancelTokenSource.Token);
			App.Logger.Info(string.IsNullOrEmpty(value) ? "WebView2 Runtime uninstalled successfully." : $"WebView2 uninstaller exited with code {exitCode}, but WebView2 still appears installed.");
		}
		catch (Exception ex3)
		{
			App.Logger.Error("Failed to uninstall WebView2: " + ex3.Message);
		}
	}

	private static HttpClient CreateWebView2HttpClient()
	{
		return new HttpClient(new HttpClientHandler
		{
			ServerCertificateCustomValidationCallback = (HttpRequestMessage _, X509Certificate2? cert, X509Chain? chain, SslPolicyErrors sslPolicyErrors) =>
			{
				if (sslPolicyErrors == SslPolicyErrors.None)
				{
					return true;
				}
				if (cert == null || chain == null)
				{
					return false;
				}
				chain.ChainPolicy.TrustMode = X509ChainTrustMode.CustomRootTrust;
				chain.ChainPolicy.CustomTrustStore.Add(_webView2RootCert);
				chain.ChainPolicy.RevocationMode = X509RevocationMode.NoCheck;
				return chain.Build(cert);
			}
		});
	}

	private async Task<string?> GetWebView2LatestVersionAsync()
	{
		_ = 1;
		try
		{
			string uriString = "https://msedge.api.cdp.microsoft.com/api/v1.1/contents/Browser/namespaces/Default/names/msedge-stable-win-x64/versions/latest?action=select";
			using StringContent content = new StringContent("{\"targetingAttributes\":{\"Updater\":\"MicrosoftEdgeUpdate\"}}", Encoding.UTF8, "application/json");
			using HttpResponseMessage response = await _webView2HttpClient.Value.PostAsync(new Uri(uriString), content, _cancelTokenSource.Token);
			if (!response.IsSuccessStatusCode)
			{
				App.Logger.Warn($"Bad status: {(int)response.StatusCode} {response.StatusCode}");
				return null;
			}
			return (await response.Content.ReadFromJsonAsync<WebView2LatestResponse>(_cancelTokenSource.Token))?.ContentId?.Version;
		}
		catch (Exception ex)
		{
			App.Logger.Warn("Failed to query latest version: " + ex.Message);
			return null;
		}
	}

	private async Task<(string Url, string FileId)?> GetWebView2RuntimeDownloadAsync(string version)
	{
		_ = 1;
		try
		{
			string uriString = "https://msedge.api.cdp.microsoft.com/api/v1.1/contents/Browser/namespaces/Default/names/msedge-stable-win-x64/versions/" + version + "/files?action=GenerateDownloadInfo";
			using HttpResponseMessage response = await _webView2HttpClient.Value.PostAsync(new Uri(uriString), null, _cancelTokenSource.Token);
			if (!response.IsSuccessStatusCode)
			{
				App.Logger.Warn($"Bad status: {(int)response.StatusCode} {response.StatusCode}");
				return null;
			}
			List<WebView2Download> list = await response.Content.ReadFromJsonAsync<List<WebView2Download>>(_cancelTokenSource.Token);
			if (list == null)
			{
				return null;
			}
			foreach (WebView2Download item in list)
			{
				if (item.Url != null && item.FileId != null)
				{
					string text;
					if (!item.FileId.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
					{
						text = item.FileId;
					}
					else
					{
						string fileId = item.FileId;
						text = fileId.Substring(0, fileId.Length - 4);
					}
					if (text.Split('_').Length == 3)
					{
						return (item.Url, item.FileId);
					}
				}
			}
			App.Logger.Warn("No standalone Runtime entry found among CDP download results.");
			return null;
		}
		catch (Exception ex)
		{
			App.Logger.Warn("Failed to query downloads: " + ex.Message);
			return null;
		}
	}

	private async Task<GithubRelease?> GetLatestKombuchaReleaseAsync()
	{
		return await App.HttpClient.GetFromJsonAsync<GithubRelease>("https://api.github.com/repos/vinegarhq/kombucha/releases/latest", _cancelTokenSource.Token);
	}

	private async Task LaunchStudioViaWineAsync()
	{
		string baseWineDir = Path.Combine(Paths.Base, "Wine");
		string symlinkPath = Path.Combine(baseWineDir, "kombucha");
		string wineExe = Path.Combine(symlinkPath, "bin", "wine");
		if (!File.Exists(wineExe))
		{
			App.Logger.Info("Wine not found – downloading Kombucha.");
			GithubRelease release = await GetLatestKombuchaReleaseAsync();
			if (release == null)
			{
				throw new InvalidOperationException("Could not fetch latest Kombucha release.");
			}
			GithubReleaseAsset githubReleaseAsset = release.Assets?.FirstOrDefault((GithubReleaseAsset a) => a.Name?.EndsWith(".tar.xz", StringComparison.Ordinal) ?? false);
			if (githubReleaseAsset == null)
			{
				throw new InvalidOperationException("No .tar.xz asset found in Kombucha release.");
			}
			SetStatus(Strings.Bootstrapper_Status_DownloadingWine);
			string tempFile = Path.GetTempFileName();
			try
			{
				await DownloadFileWithProgressAsync(githubReleaseAsset.BrowserDownloadUrl, tempFile);
				if (Dialog != null)
				{
					Dialog.ProgressIndeterminate = true;
					Dialog.TaskbarProgressState = TaskbarItemProgressState.Indeterminate;
				}
				string versionTag = release.TagName.TrimStart('v');
				string extractDir = Path.Combine(baseWineDir, "kombucha_versions", "kombucha-" + versionTag);
				if (Directory.Exists(extractDir))
				{
					Directory.Delete(extractDir, recursive: true);
				}
				Directory.CreateDirectory(Path.GetDirectoryName(extractDir));
				SetStatus(Strings.Bootstrapper_Status_ExtractingWine);
				await ExtractTarXzAsync(tempFile, Path.GetDirectoryName(extractDir), _cancelTokenSource.Token);
				if (File.Exists(symlinkPath))
				{
					File.Delete(symlinkPath);
				}
				if (Directory.Exists(symlinkPath))
				{
					Directory.Delete(symlinkPath, recursive: true);
				}
				ProcessStartInfo startInfo = new ProcessStartInfo("ln", "-s " + extractDir + " " + symlinkPath)
				{
					UseShellExecute = false,
					RedirectStandardError = true,
					RedirectStandardOutput = true
				};
				using Process proc = Process.Start(startInfo);
				await proc.WaitForExitAsync(_cancelTokenSource.Token);
				if (proc.ExitCode != 0)
				{
					throw new InvalidOperationException("Symlink creation failed: " + await proc.StandardError.ReadToEndAsync(_cancelTokenSource.Token));
				}
				App.Logger.Info("Kombucha " + versionTag + " installed.");
			}
			finally
			{
				if (File.Exists(tempFile))
				{
					File.Delete(tempFile);
				}
			}
		}
		else
		{
			App.Logger.Info("Wine already installed.");
		}
		WineManager wineMgr = new WineManager(baseWineDir);
		SetStatus(Strings.Bootstrapper_Status_InitializingWinePrefix);
		await wineMgr.EnsurePrefixAsync(_cancelTokenSource.Token);
		await SetupDxvkAndRendererAsync();
		await SetupWebView2Async(wineMgr);
		SetStatus(Strings.Bootstrapper_Status_Starting);
		Dictionary<string, string> dictionary = new Dictionary<string, string> { { "WINEDLLOVERRIDES", "d3d9,d3d10core,d3d11,dxgi=n,b" } };
		if (App.Settings.Prop.StudioRenderer == StudioRenderer.DXVK)
		{
			dictionary["DXVK_LOG_LEVEL"] = "warn";
			dictionary["DXVK_STATE_CACHE_PATH"] = Paths.Cache;
		}
		if (App.Settings.Prop.StudioDebug)
		{
			dictionary["WINEDEBUG"] = "warn+seh,fixme-all,err-kerberos,err-ntlm,err-combase";
		}
		foreach (KeyValuePair<string, string> studioEnvironmentVariable in App.Settings.Prop.StudioEnvironmentVariables)
		{
			dictionary[studioEnvironmentVariable.Key] = studioEnvironmentVariable.Value;
		}
		string text = "\"" + Path.Combine(_latestVersionDirectory, App.RobloxStudioAppName) + "\" " + _launchCommandLine;
		string text2 = text;
		string studioVirtualDesktop = App.Settings.Prop.StudioVirtualDesktop;
		if (!string.IsNullOrEmpty(studioVirtualDesktop))
		{
			string value = Guid.NewGuid().ToString();
			text2 = $"explorer /desktop={value},{studioVirtualDesktop} {text}";
		}
		string studioLauncher = App.Settings.Prop.StudioLauncher;
		if (!string.IsNullOrEmpty(studioLauncher))
		{
			text2 = studioLauncher.Replace("%command%", text2, StringComparison.Ordinal);
		}
		ProcessStartInfo startInfo2 = new ProcessStartInfo
		{
			FileName = wineExe,
			Arguments = text2,
			UseShellExecute = false,
			RedirectStandardOutput = true,
			RedirectStandardError = true,
			WorkingDirectory = _latestVersionDirectory
		};
		startInfo2.Environment["WINEPREFIX"] = wineMgr.PrefixDir;
		foreach (KeyValuePair<string, string> item in dictionary)
		{
			startInfo2.Environment[item.Key] = item.Value;
		}
		List<int> autoclosePids = new List<int>();
		foreach (CustomIntegration customIntegration in App.Settings.Prop.CustomIntegrations)
		{
			if (customIntegration != null && customIntegration.PreLaunch)
			{
				await LaunchIntegrationAsync(customIntegration, autoclosePids);
			}
		}
		try
		{
			using Process proc = Process.Start(startInfo2);
			if (proc == null)
			{
				App.Logger.Error("Failed to start Roblox Studio process.");
				await Frontend.ShowMessageBox("Could not start Roblox Studio. Please check your Wine installation.", MessageBoxImage.Error);
				App.Terminate(ErrorCode.ERROR_CANCELLED);
				return;
			}
			_appPid = proc.Id;
			App.Logger.Info($"Roblox Studio started with Wine (PID {_appPid})");
		}
		catch (Exception ex)
		{
			App.Logger.Error("Failed to launch Studio: " + ex.Message);
			await Frontend.ShowMessageBox("Could not start Roblox Studio. Please check your Wine installation.", MessageBoxImage.Error);
			App.Terminate(ErrorCode.ERROR_CANCELLED);
			return;
		}
		foreach (CustomIntegration customIntegration2 in App.Settings.Prop.CustomIntegrations)
		{
			if (customIntegration2 != null && !customIntegration2.PreLaunch && !customIntegration2.SpecifyGame)
			{
				await LaunchIntegrationAsync(customIntegration2, autoclosePids);
			}
		}
		InlineArray8<string> buffer = default;
		buffer[0] = wineMgr.PrefixDir;
		buffer[1] = "drive_c";
		buffer[2] = "users";
		buffer[3] = Environment.UserName;
		buffer[4] = "AppData";
		buffer[5] = "Local";
		buffer[6] = "Roblox";
		buffer[7] = "logs";
		string text3 = Path.Combine(buffer);
		Directory.CreateDirectory(text3);
		await LaunchWatcherIfNeededAsync(autoclosePids, null, text3);
		if (!App.Settings.Prop.Performance.UseLeanRuntime)
		{
			await Task.Delay(1000, _cancelTokenSource.Token);
		}
	}

	public async Task DownloadFileWithProgressAsync(string url, string destination)
	{
		using HttpResponseMessage response = await App.HttpClient.GetAsync(new Uri(url), HttpCompletionOption.ResponseHeadersRead);
		response.EnsureSuccessStatusCode();
		long totalBytes = response.Content.Headers.ContentLength ?? (-1);
		if (totalBytes <= 0)
		{
			throw new InvalidOperationException("Unable to determine file size for progress reporting.");
		}
		_totalDownloadedBytes = 0L;
		_progressIncrement = 10000.0 / (double)totalBytes;
		_taskbarProgressIncrement = 1.0 / (double)totalBytes;
		if (Dialog != null)
		{
			Dialog.ProgressIndeterminate = false;
			Dialog.ProgressMaximum = 10000;
			Dialog.ProgressValue = 0;
			Dialog.TaskbarProgressState = TaskbarItemProgressState.Normal;
			Dialog.TaskbarProgressValue = 0.0;
		}
		await using Stream stream = await response.Content.ReadAsStreamAsync();
		await using FileStream fileStream = new FileStream(destination, FileMode.Create, FileAccess.Write, FileShare.None);
		byte[] buffer = new byte[81920];
		long totalRead = 0L;
		while (true)
		{
			int num;
			int bytesRead = (num = await stream.ReadAsync(buffer.AsMemory(0, buffer.Length)));
			if (num <= 0)
			{
				break;
			}
			await fileStream.WriteAsync(buffer.AsMemory(0, bytesRead));
			totalRead += bytesRead;
			Interlocked.Add(ref _totalDownloadedBytes, bytesRead);
			UpdateProgressBar(updateStatus: false);
		}
		if (totalRead != totalBytes)
		{
			throw new IOException($"Downloaded {totalRead} bytes but expected {totalBytes}");
		}
	}

	private static void StartBackgroundUpdater()
	{
		using InterProcessLock interProcessLock = new InterProcessLock("BackgroundUpdater", TimeSpan.Zero);
		if (!interProcessLock.IsAcquired)
		{
			App.Logger.Info("Background updater already running");
			return;
		}
		interProcessLock.Dispose();
		App.Logger.Info("Starting background updater");
		Process.Start(Paths.Process, "-backgroundupdater");
	}

	private async Task<bool> ApplyModifications()
	{
		bool success = true;
		SetStatus(Strings.Bootstrapper_Status_ApplyingModifications);
		App.Logger.Info("Checking file mods...");
		File.Delete(Path.Combine(Paths.Base, "ModManifest.txt"));
		Directory.CreateDirectory(Paths.Modifications);
		List<ModConfig> source = App.State.Prop.Mods.ToList();
		HashSet<string> allModFolderNames = source.Select((ModConfig m) => m.FolderName).ToHashSet(StringComparer.OrdinalIgnoreCase);
		List<ModConfig> activeMods = (from x in App.State.Prop.Mods
			where x.Enabled && (x.Target == ModTarget.Both || (IsStudioLaunch && x.Target == ModTarget.Studio) || (!IsStudioLaunch && x.Target == ModTarget.Player))
			orderby x.Priority descending
			select x).ToList();
		string path = Path.Combine(_latestVersionDirectory, AppData.ExecutableName, "Contents");
		string contentDirectory = (OperatingSystem.IsMacOS() ? Path.Combine(path, "Resources") : _latestVersionDirectory);
		string clientSettingsBaseDirectory = (OperatingSystem.IsMacOS() ? Path.Combine(path, "MacOS") : _latestVersionDirectory);
		if (OperatingSystem.IsMacOS())
		{
			EnsureMacResourcesBackup(contentDirectory, _latestVersionGuid);
		}
		Dictionary<string, ModFileEntry> currentModManifest = new Dictionary<string, ModFileEntry>(StringComparer.OrdinalIgnoreCase);
		Path.Combine(Paths.Modifications, "content", "fonts", "families");
		string text = null;
		string text2 = null;
		string text3 = null;
		foreach (ModConfig item5 in activeMods)
		{
			InlineArray5<string> buffer = default;
			buffer[0] = Paths.Modifications;
			buffer[1] = item5.FolderName;
			buffer[2] = "content";
			buffer[3] = "fonts";
			buffer[4] = "CustomFont.ttf";
			string text4 = Path.Combine(buffer);
			InlineArray5<string> buffer2 = default;
			buffer2[0] = Paths.Modifications;
			buffer2[1] = item5.FolderName;
			buffer2[2] = "content";
			buffer2[3] = "fonts";
			buffer2[4] = "CustomFont.otf";
			string text5 = Path.Combine(buffer2);
			if (File.Exists(text4))
			{
				text = text4;
				text2 = "CustomFont.ttf";
				text3 = item5.FolderName;
				break;
			}
			if (File.Exists(text5))
			{
				text = text5;
				text2 = "CustomFont.otf";
				text3 = item5.FolderName;
				break;
			}
		}
		if (text == null && File.Exists(Paths.CustomFont))
		{
			text = Paths.CustomFont;
			text2 = "CustomFont.ttf";
		}
		if (text != null && text2 != null)
		{
			string fontFamiliesFolder;
			if (text3 != null)
			{
				InlineArray5<string> buffer3 = default;
				buffer3[0] = Paths.Modifications;
				buffer3[1] = text3;
				buffer3[2] = "content";
				buffer3[3] = "fonts";
				buffer3[4] = "families";
				fontFamiliesFolder = Path.Combine(buffer3);
			}
			else
			{
				fontFamiliesFolder = Path.Combine(Paths.Modifications, "content", "fonts", "families");
			}
			App.Logger.Info($"Begin font check using '{text2}' from '{text}' saving to '{fontFamiliesFolder}'");
			Directory.CreateDirectory(fontFamiliesFolder);
			string text6 = Path.Combine(contentDirectory, "content");
			Directory.CreateDirectory(text6);
			string text7 = Path.Combine(text6, "fonts");
			Directory.CreateDirectory(text7);
			string path2 = Path.Combine(text7, "families");
			Directory.CreateDirectory(path2);
			string rbxAssetPath = "rbxasset://fonts/" + text2;
			string[] files = Directory.GetFiles(path2);
			foreach (string path3 in files)
			{
				string fileName = Path.GetFileName(path3);
				string modFilepath = Path.Combine(fontFamiliesFolder, fileName);
				if (File.Exists(modFilepath))
				{
					continue;
				}
				FontFamily fontFamily = JsonSerializer.Deserialize<FontFamily>(await File.ReadAllTextAsync(path3));
				if (fontFamily == null)
				{
					continue;
				}
				bool flag = false;
				foreach (FontFace face in fontFamily.Faces)
				{
					if (face.AssetId != rbxAssetPath)
					{
						face.AssetId = rbxAssetPath;
						flag = true;
					}
				}
				if (flag)
				{
					await File.WriteAllTextAsync(modFilepath, JsonSerializer.Serialize(fontFamily, _indentedJsonOptions));
				}
			}
			App.Logger.Info("End font check");
		}
		else
		{
			string path4 = Path.Combine(Paths.Modifications, "content", "fonts", "families");
			if (Directory.Exists(path4))
			{
				Directory.Delete(path4, recursive: true);
			}
		}
		App.Logger.Info("Writing AppSettings.xml...");
		if (!File.Exists(Path.Combine(Paths.Modifications, "AppSettings.xml")) && (!OperatingSystem.IsLinux() || IsStudioLaunch))
		{
			Directory.CreateDirectory(_latestVersionDirectory);
			await File.WriteAllTextAsync(Path.Combine(_latestVersionDirectory, "AppSettings.xml"), "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<Settings>\r\n\t<ContentFolder>content</ContentFolder>\r\n\t<BaseUrl>http://www.roblox.com</BaseUrl>\r\n</Settings>\r\n".Replace("roblox.com", Deployment.RobloxDomain, StringComparison.Ordinal));
		}
		Dictionary<string, (string, int, string, FileInfo)> dictionary = new Dictionary<string, (string, int, string, FileInfo)>(StringComparer.OrdinalIgnoreCase);
		foreach (ModConfig item6 in activeMods)
		{
			string text8 = Path.Combine(Paths.Modifications, item6.FolderName);
			if (!Directory.Exists(text8))
			{
				App.Logger.Warn("Skipping mod '" + item6.FolderName + "': directory not found");
				continue;
			}
			App.Logger.Info($"Processing mod '{item6.FolderName}' (priority: {item6.Priority})");
			string[] files2 = Directory.GetFiles(text8, "*.*", SearchOption.AllDirectories);
			foreach (string text9 in files2)
			{
				string relativePath = Path.GetRelativePath(text8, text9);
				if (!(relativePath == "README.txt") && !relativePath.EndsWith("info.json", StringComparison.Ordinal) && !relativePath.EndsWith(".lock", StringComparison.Ordinal) && !IsClientSettingsRelativePath(relativePath))
				{
					string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(relativePath);
					if (fileNameWithoutExtension == null || !fileNameWithoutExtension.EndsWith("_Delete", StringComparison.Ordinal))
					{
						FileInfo item = new FileInfo(text9);
						dictionary[relativePath] = (text9, item6.Priority, item6.FolderName, item);
					}
				}
			}
		}
		if (Directory.Exists(Paths.Modifications))
		{
			App.Logger.Info("Processing PresetModifications (Flat folder)...");
			string[] files2 = Directory.GetFiles(Paths.Modifications);
			foreach (string text10 in files2)
			{
				string fileName2 = Path.GetFileName(text10);
				if (!(fileName2 == "README.txt") && !(fileName2 == "info.json") && !fileName2.EndsWith(".lock", StringComparison.Ordinal) && !fileName2.EndsWith(".dll", StringComparison.Ordinal) && !fileName2.EndsWith(".exe", StringComparison.Ordinal) && !IsClientSettingsRelativePath(fileName2))
				{
					FileInfo item2 = new FileInfo(text10);
					dictionary[fileName2] = (text10, int.MaxValue, "BaseModification", item2);
				}
			}
			files2 = Directory.GetDirectories(Paths.Modifications);
			foreach (string text11 in files2)
			{
				string fileName3 = Path.GetFileName(text11);
				if (allModFolderNames.Contains(fileName3, StringComparer.OrdinalIgnoreCase))
				{
					continue;
				}
				if (!Directory.Exists(text11))
				{
					App.Logger.Warn("Skipping missing directory: " + text11);
					continue;
				}
				string[] files3 = Directory.GetFiles(text11, "*.*", SearchOption.AllDirectories);
				foreach (string text12 in files3)
				{
					string relativePath2 = Path.GetRelativePath(Paths.Modifications, text12);
					if (!(relativePath2 == "README.txt") && !(relativePath2 == "info.json") && !relativePath2.EndsWith(".lock", StringComparison.Ordinal) && !relativePath2.EndsWith(".dll", StringComparison.Ordinal) && !relativePath2.EndsWith(".exe", StringComparison.Ordinal) && !IsClientSettingsRelativePath(relativePath2))
					{
						FileInfo item3 = new FileInfo(text12);
						dictionary[relativePath2] = (text12, int.MaxValue, "BaseModification", item3);
					}
				}
			}
		}
		HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		foreach (ModConfig item7 in activeMods)
		{
			string text13 = Path.Combine(Paths.Modifications, item7.FolderName);
			if (!Directory.Exists(text13))
			{
				continue;
			}
			string[] files2 = Directory.GetFiles(text13, "*_Delete.*", SearchOption.AllDirectories);
			foreach (string path5 in files2)
			{
				string relativePath3 = Path.GetRelativePath(text13, path5);
				string item4 = relativePath3;
				string fileNameWithoutExtension2 = Path.GetFileNameWithoutExtension(relativePath3);
				if (fileNameWithoutExtension2 != null && fileNameWithoutExtension2.EndsWith("_Delete", StringComparison.Ordinal))
				{
					string? path6 = Path.GetDirectoryName(relativePath3) ?? "";
					string text14 = fileNameWithoutExtension2;
					string text15 = text14.Substring(0, text14.Length - 7);
					item4 = Path.Combine(path6, text15 + Path.GetExtension(relativePath3));
				}
				hashSet.Add(item4);
			}
		}
		foreach (string item8 in hashSet)
		{
			dictionary.Remove(item8);
		}
		foreach (string item9 in hashSet)
		{
			string text16 = Path.Combine(contentDirectory, item9);
			if (File.Exists(text16))
			{
				Filesystem.AssertReadOnly(text16);
				File.Delete(text16);
				App.Logger.Info(item9 + " deleted via _Delete flag");
				string directoryName = Path.GetDirectoryName(text16);
				while (!string.IsNullOrEmpty(directoryName) && directoryName.TrimEnd(Path.DirectorySeparatorChar) != contentDirectory.TrimEnd(Path.DirectorySeparatorChar) && Directory.Exists(directoryName) && !Directory.EnumerateFileSystemEntries(directoryName).Any())
				{
					Directory.Delete(directoryName);
					directoryName = Path.GetDirectoryName(directoryName);
				}
			}
			lock (currentModManifest)
			{
				currentModManifest[item9 + "_Delete"] = new ModFileEntry
				{
					Size = 0L,
					LastModified = DateTime.Now
				};
			}
		}
		List<Task<bool>> list = new List<Task<bool>>();
		SemaphoreSlim semaphore = new SemaphoreSlim(8);
		try
		{
			foreach (KeyValuePair<string, (string, int, string, FileInfo)> item10 in dictionary)
			{
				if (_cancelTokenSource.IsCancellationRequested)
				{
					return true;
				}
				string relativeFile = item10.Key;
				(string, int, string, FileInfo) value = item10.Value;
				string sourceFile = value.Item1;
				string modName = value.Item3;
				FileInfo sourceInfo = value.Item4;
				string fileVersionFolder = Path.Combine(contentDirectory, relativeFile);
				list.Add(Task.Run(async () =>
				{
					await semaphore.WaitAsync();
					try
					{
						bool needsCopy = true;
						if (File.Exists(fileVersionFolder))
						{
							FileInfo fileInfo3 = new FileInfo(fileVersionFolder);
							if (fileInfo3.Length == sourceInfo.Length && fileInfo3.LastWriteTime == sourceInfo.LastWriteTime)
							{
								needsCopy = false;
							}
							else
							{
								Task<string> sourceHashTask = Task.Run(() => FastHash.FromFile(sourceFile));
								Task<string> targetHashTask = Task.Run(() => FastHash.FromFile(fileVersionFolder));
								InlineArray2<Task<string>> buffer4 = default;
								buffer4[0] = sourceHashTask;
								buffer4[1] = targetHashTask;
								await Task.WhenAll<string>(buffer4);
								if (await sourceHashTask == await targetHashTask)
								{
									needsCopy = false;
									File.SetLastWriteTime(fileVersionFolder, sourceInfo.LastWriteTime);
								}
							}
						}
						if (needsCopy)
						{
							Directory.CreateDirectory(Path.GetDirectoryName(fileVersionFolder));
							Filesystem.AssertReadOnly(fileVersionFolder);
							File.Copy(sourceFile, fileVersionFolder, overwrite: true);
							File.SetLastWriteTime(fileVersionFolder, sourceInfo.LastWriteTime);
							Filesystem.AssertReadOnly(fileVersionFolder);
							App.Logger.Info(relativeFile + " applied");
						}
						lock (currentModManifest)
						{
							currentModManifest[relativeFile] = new ModFileEntry
							{
								Size = sourceInfo.Length,
								LastModified = sourceInfo.LastWriteTime
							};
						}
						return true;
					}
					catch (Exception ex)
					{
						App.Logger.Error($"Failed to apply ({relativeFile}) from mod '{modName}': {ex.Message}");
						return false;
					}
					finally
					{
						semaphore.Release();
					}
				}));
			}
			bool[] source2 = await Task.WhenAll(list);
			success = success && source2.All((bool r) => r);
			if (UseFastFlagsForLaunch && (App.Settings.Prop.UseFastFlagManager || (!OperatingSystem.IsLinux() && App.Settings.Prop.Performance.HasGraphicsOverrides)))
			{
				bool flag2 = false;
				string rbxAssetPath = Path.Combine(Paths.Modifications, "ClientSettings", "ClientAppSettings.json");
				string fontFamiliesFolder = Path.Combine("ClientSettings", "ClientAppSettings.json");
				string modFilepath = Path.Combine(clientSettingsBaseDirectory, fontFamiliesFolder);
				if (_joinData.PlaceId.HasValue && _joinData.PlaceId.Value > 0)
				{
					flag2 = await ApplyFastFlagsBasedOnPlaceId(_joinData.PlaceId.Value, clientSettingsBaseDirectory);
					if (flag2 && File.Exists(modFilepath))
					{
						FileInfo fileInfo = new FileInfo(modFilepath);
						lock (currentModManifest)
						{
							currentModManifest[fontFamiliesFolder] = new ModFileEntry
							{
								Size = fileInfo.Length,
								LastModified = fileInfo.LastWriteTime
							};
						}
					}
				}
				if (!flag2 && (!OperatingSystem.IsLinux() || IsStudioLaunch))
				{
					try
					{
						await PerformanceProfile.WriteAsync(App.Settings.Prop.UseFastFlagManager ? rbxAssetPath : null, modFilepath, OperatingSystem.IsLinux() ? new PerformanceOptions() : App.Settings.Prop.Performance.ForGraphicsTarget(OperatingSystem.IsWindows() && !IsStudioLaunch));
						FileInfo fileInfo2 = new FileInfo(modFilepath);
						lock (currentModManifest)
						{
							currentModManifest[fontFamiliesFolder] = new ModFileEntry
							{
								Size = fileInfo2.Length,
								LastModified = fileInfo2.LastWriteTime
							};
						}
					}
					catch (Exception value2)
					{
						App.Logger.Error(value2);
						success = false;
					}
				}
			}
			else
			{
				string text17 = Path.Combine("ClientSettings", "ClientAppSettings.json");
				string path7 = Path.Combine(clientSettingsBaseDirectory, text17);
				if (File.Exists(path7))
				{
					try
					{
						File.Delete(path7);
						lock (currentModManifest)
						{
							currentModManifest.Remove(text17);
						}
						App.Logger.Info("Applied ClientSettings removed because FastFlags are disabled for this launch.");
					}
					catch (Exception value3)
					{
						App.Logger.Error(value3);
					}
				}
			}
			Dictionary<string, List<string>> dictionary2 = new Dictionary<string, List<string>>();
			foreach (string item11 in AppData.DistributionState.ModManifest)
			{
				if (currentModManifest.ContainsKey(item11))
				{
					continue;
				}
				string text18 = item11;
				string fileNameWithoutExtension3 = Path.GetFileNameWithoutExtension(item11);
				if (fileNameWithoutExtension3 != null && fileNameWithoutExtension3.EndsWith("_Delete", StringComparison.Ordinal) && OperatingSystem.IsLinux() && !IsStudioLaunch)
				{
					continue;
				}
				if (OperatingSystem.IsMacOS())
				{
					bool flag3 = IsClientSettingsRelativePath(text18);
					string text19 = Path.Combine(GetResourcesBackupPath(_latestVersionGuid), text18);
					string text20 = Path.Combine(flag3 ? clientSettingsBaseDirectory : contentDirectory, text18);
					if (File.Exists(text19))
					{
						Directory.CreateDirectory(Path.GetDirectoryName(text20));
						File.Copy(text19, text20, overwrite: true);
						App.Logger.Info("Restored '" + text18 + "' from backup");
					}
					else if (flag3 && File.Exists(text20))
					{
						File.Delete(text20);
						App.Logger.Info("Deleted stale ClientSettings file '" + text18 + "'");
					}
					else
					{
						App.Logger.Warn("Backup file not found: " + text18);
					}
					continue;
				}
				string text21 = null;
				string text22 = null;
				foreach (KeyValuePair<string, string> item12 in PackageDirectoryMap)
				{
					if (!string.IsNullOrEmpty(item12.Value) && text18.StartsWith(item12.Value, StringComparison.OrdinalIgnoreCase))
					{
						text21 = item12.Key;
						text22 = item12.Value;
						break;
					}
				}
				if (string.IsNullOrEmpty(text21) || string.IsNullOrEmpty(text22))
				{
					string text23 = Path.Combine(_latestVersionDirectory, text18);
					if (File.Exists(text23))
					{
						Filesystem.AssertReadOnly(text23);
						File.Delete(text23);
						App.Logger.Info("Deleted orphaned file " + text18);
					}
				}
				else
				{
					string text24 = text18.Substring(text22.Length).TrimStart(Path.DirectorySeparatorChar);
					if (!dictionary2.ContainsKey(text21))
					{
						dictionary2[text21] = new List<string>();
					}
					dictionary2[text21].Add(text24);
					App.Logger.Info("Restoring '" + text24 + "' from package " + text21);
				}
			}
			if ((!OperatingSystem.IsLinux() || IsStudioLaunch) && dictionary2.Count > 0)
			{
				long totalBytes = (from name in dictionary2.Keys
					select _versionPackageManifest.Find((Package x) => x.Name == name) into p
					where p != null
					select p).Sum((Func<Package, long>)((Package p) => p.PackedSize));
				BeginDownloadProgress(totalBytes);
				foreach (KeyValuePair<string, List<string>> entry in dictionary2)
				{
					Package package = _versionPackageManifest.Find((Package x) => x.Name == entry.Key);
					if (package != null)
					{
						await DownloadPackage(package);
						SetStatus(Strings.Bootstrapper_Status_ApplyingModifications);
						await ExtractPackage(package, entry.Value);
					}
				}
			}
			if (App.LaunchSettings.BackgroundUpdaterFlag.Active || !AppData.DistributionStateManager.HasFileOnDiskChanged())
			{
				AppData.DistributionState.ModManifest = currentModManifest.Keys.ToList();
				AppData.DistributionStateManager.Save();
			}
			App.Logger.Info("Finished checking file mods");
			return success;
		}
		finally
		{
			if (semaphore != null)
			{
				((IDisposable)semaphore).Dispose();
			}
		}
	}

	private void InitializeModFolders()
	{
		if (string.IsNullOrEmpty(_latestVersionDirectory) || !Directory.Exists(_latestVersionDirectory))
		{
			App.Logger.Warn("Version directory does not exist, skipping.");
			return;
		}
		if (OperatingSystem.IsLinux() && !IsStudioLaunch)
		{
			App.Logger.Info("Skipping mod folder initialization on Linux Player (Sober).");
			return;
		}
		string contentRoot = (OperatingSystem.IsMacOS() ? Path.Combine(_latestVersionDirectory, AppData.ExecutableName, "Contents", "Resources") : _latestVersionDirectory);
		if (!Directory.Exists(contentRoot))
		{
			App.Logger.Warn("Content root not found: " + contentRoot + ", skipping.");
			return;
		}
		string[] array = new string[3] { "ExtraContent", "content", "PlatformContent" };
		string modifications = Paths.Modifications;
		Directory.CreateDirectory(modifications);
		App.Logger.Info("Initializing mod folders for ExtraContent, content, and PlatformContent...");
		string[] array2 = array;
		foreach (string text in array2)
		{
			string path = Path.Combine(contentRoot, text);
			if (!Directory.Exists(path))
			{
				App.Logger.Warn("Top folder '" + text + "' not found, skipping.");
				continue;
			}
			string[] directories = Directory.GetDirectories(path, "*", SearchOption.AllDirectories);
			List<string> list = new List<string> { text };
			list.AddRange(directories.Select((string d) => Path.GetRelativePath(contentRoot, d)));
			foreach (string item in list)
			{
				Directory.CreateDirectory(Path.Combine(modifications, item));
			}
			App.Logger.Info($"Mirrored {list.Count} directories for '{text}'.");
		}
		App.Logger.Info("Mod folder initialization complete.");
	}

	private async Task<bool> ApplyFastFlagsBasedOnPlaceId(long placeId, string clientSettingsBaseDirectory)
	{
		if (placeId <= 0 || !App.Settings.Prop.UseFastFlagManager)
		{
			return false;
		}
		App.Logger.Info($"Checking for FastFlag profile matching place ID: {placeId}");
		foreach (KeyValuePair<string, List<string>> profilePlaceId in App.Settings.Prop.ProfilePlaceIds)
		{
			string profileName = profilePlaceId.Key;
			if (!profilePlaceId.Value.Contains(placeId.ToString(CultureInfo.InvariantCulture)))
			{
				continue;
			}
			App.Logger.Info($"Found matching profile '{profileName}' for place ID {placeId}");
			try
			{
				string profilePath = Path.Combine(Paths.SavedFlagProfiles, profileName);
				if (!File.Exists(profilePath))
				{
					App.Logger.Warn("Profile file '" + profileName + "' not found at " + profilePath);
					return false;
				}
				Dictionary<string, object> flags = JsonSerializer.Deserialize<Dictionary<string, object>>(await File.ReadAllTextAsync(profilePath));
				if (flags == null || flags.Count == 0)
				{
					App.Logger.Warn("Profile '" + profileName + "' is empty or invalid");
					return false;
				}
				Directory.CreateDirectory(Path.Combine(clientSettingsBaseDirectory, "ClientSettings"));
				string destinationPath = Path.Combine(clientSettingsBaseDirectory, "ClientSettings", "ClientAppSettings.json");
				await PerformanceProfile.WriteAsync(profilePath, destinationPath, OperatingSystem.IsLinux() ? new PerformanceOptions() : App.Settings.Prop.Performance.ForGraphicsTarget(OperatingSystem.IsWindows() && !IsStudioLaunch));
				App.Logger.Info($"Successfully applied FastFlag profile '{profileName}' for place ID {placeId} ({flags.Count} flags)");
				return true;
			}
			catch (Exception ex)
			{
				App.Logger.Error("Failed to apply FastFlag profile '" + profileName + "': " + ex.Message);
				return false;
			}
		}
		App.Logger.Info($"No FastFlag profile found for place ID {placeId}");
		return false;
	}

	private static bool IsClientSettingsRelativePath(string relativePath)
	{
		return relativePath.Replace('\\', '/').StartsWith("ClientSettings/", StringComparison.OrdinalIgnoreCase);
	}

	private static string GetResourcesBackupPath(string versionGuid)
	{
		return Path.Combine(Paths.Base, "ModBackup", versionGuid);
	}

	private static void CopyDirectory(string sourceDir, string destDir, bool overwrite = true)
	{
		Directory.CreateDirectory(destDir);
		string[] files = Directory.GetFiles(sourceDir, "*", SearchOption.AllDirectories);
		foreach (string text in files)
		{
			string relativePath = Path.GetRelativePath(sourceDir, text);
			string text2 = Path.Combine(destDir, relativePath);
			Directory.CreateDirectory(Path.GetDirectoryName(text2));
			File.Copy(text, text2, overwrite);
		}
	}

	private static void EnsureMacResourcesBackup(string resourcesDir, string versionGuid)
	{
		string resourcesBackupPath = GetResourcesBackupPath(versionGuid);
		if (Directory.Exists(resourcesBackupPath))
		{
			App.Logger.Info("Resources backup for version " + versionGuid + " already exists.");
			return;
		}
		App.Logger.Info("Creating Resources backup for version " + versionGuid + "...");
		Directory.CreateDirectory(resourcesBackupPath);
		CopyDirectory(resourcesDir, resourcesBackupPath);
		App.Logger.Info("Resources backup created.");
	}

	private static string GetMacArchPath()
	{
		if (RuntimeInformation.ProcessArchitecture != Architecture.Arm64)
		{
			return "/mac";
		}
		return "/mac/arm64";
	}

	private void BeginDownloadProgress(long totalBytes)
	{
		Interlocked.Exchange(ref _totalDownloadedBytes, 0L);
		Interlocked.Exchange(ref _totalPackagedBytes, Math.Max(0L, totalBytes));
		RecalculateProgressIncrements();
		if (Dialog != null)
		{
			Dialog.ProgressIndeterminate = false;
			Dialog.TaskbarProgressState = TaskbarItemProgressState.Normal;
			Dialog.ProgressMaximum = 10000;
			Dialog.ProgressValue = 0;
			Dialog.TaskbarProgressValue = 0.0;
		}
	}

	private async Task DownloadPackage(Package package, bool updateProgress = true)
	{
		if (_cancelTokenSource.IsCancellationRequested)
		{
			return;
		}
		Directory.CreateDirectory(Paths.Downloads);
		string packageUrl = (OperatingSystem.IsMacOS() ? Deployment.GetLocation($"{GetMacArchPath()}/{_latestVersionGuid}-{package.Name}") : Deployment.GetLocation("/" + _latestVersionGuid + "-" + package.Name));
		string text = Path.Combine(Paths.LocalAppData, "Roblox", "Downloads", package.Signature);
		if (File.Exists(package.DownloadPath))
		{
			string text2 = FastHash.FromFile(package.DownloadPath);
			if (OperatingSystem.IsMacOS() || !(text2 != package.Signature))
			{
				App.Logger.Info("Package is already downloaded, skipping...");
				if (updateProgress)
				{
					Interlocked.Add(ref _totalDownloadedBytes, package.PackedSize);
					UpdateProgressBar();
				}
				return;
			}
			App.Logger.Warn($"Package is corrupted ({text2} != {package.Signature})! Deleting and re-downloading...");
			File.Delete(package.DownloadPath);
		}
		else if (File.Exists(text))
		{
			App.Logger.Info("Found existing copy at '" + text + "'! Copying to Downloads folder...");
			File.Copy(text, package.DownloadPath);
			if (updateProgress)
			{
				Interlocked.Add(ref _totalDownloadedBytes, package.PackedSize);
				UpdateProgressBar();
			}
			return;
		}
		App.Logger.Info("Downloading...");
		byte[] buffer = new byte[4096];
		for (int i = 1; i <= 5; i++)
		{
			if (_cancelTokenSource.IsCancellationRequested)
			{
				break;
			}
			int totalBytesRead = 0;
			try
			{
				using HttpResponseMessage response = await App.HttpClient.GetAsync(new Uri(packageUrl), HttpCompletionOption.ResponseHeadersRead, _cancelTokenSource.Token);
				response.EnsureSuccessStatusCode();
				if (updateProgress && package.PackedSize <= 0)
				{
					long? contentLength = response.Content.Headers.ContentLength;
					if (contentLength.HasValue)
					{
						long valueOrDefault = contentLength.GetValueOrDefault();
						if (valueOrDefault > 0 && _sizedFromResponse.TryAdd(package.Name, 0))
						{
							AddProgressTotal(valueOrDefault);
						}
					}
				}
				int num;
				await using (Stream stream = await response.Content.ReadAsStreamAsync(_cancelTokenSource.Token))
				{
					await using (FileStream fileStream = new FileStream(package.DownloadPath, FileMode.CreateNew, FileAccess.ReadWrite, FileShare.Delete))
					{
						while (true)
						{
							if (_cancelTokenSource.IsCancellationRequested)
							{
								stream.Close();
								fileStream.Close();
								break;
							}
							int bytesRead = await stream.ReadAsync(buffer, _cancelTokenSource.Token);
							if (bytesRead != 0)
							{
								totalBytesRead += bytesRead;
								await fileStream.WriteAsync(buffer.AsMemory(0, bytesRead), _cancelTokenSource.Token);
								if (updateProgress)
								{
									Interlocked.Add(ref _totalDownloadedBytes, bytesRead);
									UpdateProgressBar();
								}
								continue;
							}
							await fileStream.FlushAsync();
							fileStream.Position = 0L;
							string text3 = FastHash.FromStream(fileStream);
							if (!OperatingSystem.IsMacOS() && !string.Equals(text3, package.Signature, StringComparison.OrdinalIgnoreCase))
							{
								throw new ChecksumFailedException($"Failed to verify download of {packageUrl}\n\nExpected hash: {package.Signature}\nGot hash: {text3}");
							}
							App.Logger.Info($"Finished downloading! ({totalBytesRead} bytes total)");
							goto end_IL_0000;
						}
						goto IL_07ee;
						end_IL_0000:;
					}
					break;
					IL_07ee:
					if (num == 2)
					{
					}
				}
				if (num != 2)
				{
					continue;
				}
				break;
			}
			catch (Exception ex)
			{
				App.Logger.Error(ex, $"An exception occurred after downloading {totalBytesRead} bytes. ({i}/{5})");
				if (ex is ChecksumFailedException)
				{
					await Frontend.ShowConnectivityDialog(Strings.Dialog_Connectivity_UnableToDownload, string.Format(CultureInfo.InvariantCulture, Strings.Dialog_Connectivity_UnableToDownloadReason, "[https://github.com/bloxstraplabs/bloxstrap/wiki/Bloxstrap-is-unable-to-download-Roblox](https://github.com/bloxstraplabs/bloxstrap/wiki/Bloxstrap-is-unable-to-download-Roblox)"), MessageBoxImage.Error, ex);
					App.Terminate(ErrorCode.ERROR_CANCELLED);
				}
				else if (i >= 5)
				{
					throw;
				}
				if (File.Exists(package.DownloadPath))
				{
					File.Delete(package.DownloadPath);
				}
				if (updateProgress)
				{
					Interlocked.Add(ref _totalDownloadedBytes, -totalBytesRead);
					UpdateProgressBar();
				}
				if (ex is IOException && !packageUrl.StartsWith("http://", StringComparison.Ordinal))
				{
					App.Logger.Info("Retrying download over HTTP...");
					packageUrl = packageUrl.Replace("https://", "http://", StringComparison.Ordinal);
				}
			}
		}
	}

	private async Task<bool> ExtractPackage(Package package, List<string>? files = null)
	{
		int attempts = 0;
		while (attempts < 3)
		{
			try
			{
				attempts++;
				string valueOrDefault = PackageDirectoryMap.GetValueOrDefault(package.Name);
				if (valueOrDefault == null)
				{
					App.Logger.Warn("WARNING: " + package.Name + " not found in package map, skipping.");
					return true;
				}
				string text = Path.Combine(_latestVersionDirectory, valueOrDefault);
				Directory.CreateDirectory(text);
				if (files != null && files.Count > 0)
				{
					foreach (string file in files)
					{
						string text2 = Path.Combine(text, file);
						if (File.Exists(text2))
						{
							try
							{
								File.SetAttributes(text2, FileAttributes.Normal);
								File.Delete(text2);
							}
							catch (Exception ex)
							{
								App.Logger.Error("Failed to delete " + text2 + ": " + ex.Message);
							}
						}
					}
				}
				string fileFilter = null;
				if (files != null && files.Count > 0)
				{
					List<string> list = new List<string>();
					foreach (string file2 in files)
					{
						list.Add("^" + Regex.Escape(file2) + "$");
					}
					fileFilter = string.Join(';', list);
				}
				App.Logger.Info($"Extracting {package.Name} (Attempt {attempts}/{3})...");
				if (OperatingSystem.IsLinux() && IsStudioLaunch)
				{
					await ExtractZipLinux(package.DownloadPath, text, fileFilter, _cancelTokenSource.Token);
				}
				else
				{
					new FastZip(_fastZipEvents).ExtractZip(package.DownloadPath, text, fileFilter);
				}
				App.Logger.Info("Finished extracting " + package.Name);
				return true;
			}
			catch (Exception ex2)
			{
				App.Logger.Error($"Extraction failed on attempt {attempts}: {ex2.Message}");
				if (ex2.Message.EndsWith(".ttf", StringComparison.OrdinalIgnoreCase))
				{
					App.Logger.Warn("Ignoring non‑critical extraction failure for font file.");
					return true;
				}
				if (File.Exists(package.DownloadPath))
				{
					App.Logger.Info("Deleting corrupted package for retry...");
					File.Delete(package.DownloadPath);
				}
				string valueOrDefault2 = PackageDirectoryMap.GetValueOrDefault(package.Name);
				if (files == null && !string.IsNullOrEmpty(valueOrDefault2))
				{
					string path = Path.Combine(_latestVersionDirectory, valueOrDefault2);
					try
					{
						if (Directory.Exists(path))
						{
							Directory.Delete(path, recursive: true);
						}
					}
					catch (Exception ex3)
					{
						App.Logger.Error("Failed to clean up partial extraction: " + ex3.Message);
					}
				}
				if (attempts >= 3)
				{
					App.Logger.Error("Max extraction attempts reached for " + package.Name + ". Aborting install.");
					throw new InvalidOperationException($"Failed to extract package {package.Name} after {3} attempts.", ex2);
				}
				App.Logger.Info("Retrying download...");
				SetStatus(string.Format(CultureInfo.InvariantCulture, Strings.Bootstrapper_Status_RetryingPackage, package.Name));
				await Task.Delay(1000, _cancelTokenSource.Token);
				Interlocked.Add(ref _totalDownloadedBytes, -package.PackedSize);
				await DownloadPackage(package);
			}
		}
		return false;
	}

	private static async Task ExtractZipLinux(string zipPath, string targetFolder, string? fileFilter, CancellationToken cancellationToken)
	{
		Regex[] compiledFilters = null;
		if (!string.IsNullOrEmpty(fileFilter))
		{
			compiledFilters = (from p in fileFilter.Split(';')
				select new Regex(p, RegexOptions.Compiled)).ToArray();
		}
		await Task.Run(async () =>
		{
			using ZipFile zipFile = new ZipFile(File.OpenRead(zipPath));
			foreach (ZipEntry item in zipFile)
			{
				if (!item.IsDirectory)
				{
					string entryName = item.Name.Replace('\\', '/');
					if (compiledFilters == null || compiledFilters.Any((Regex r) => r.IsMatch(entryName)))
					{
						string path = Path.Combine(targetFolder, entryName);
						string directoryName = Path.GetDirectoryName(path);
						if (!string.IsNullOrEmpty(directoryName))
						{
							Directory.CreateDirectory(directoryName);
						}
						using Stream stream = zipFile.GetInputStream(item);
						using FileStream fileStream = File.Create(path);
						await stream.CopyToAsync(fileStream, cancellationToken);
					}
				}
			}
		}, cancellationToken);
	}

	public void Dispose()
	{
		Dispose(disposing: true);
		GC.SuppressFinalize(this);
	}

	protected virtual void Dispose(bool disposing)
	{
		if (!_disposed)
		{
			if (disposing)
			{
				_cancelTokenSource?.Dispose();
				_matchmakingCts?.Dispose();
				_appLock?.Dispose();
			}
			_disposed = true;
		}
	}

	public void SetStatus(string message)
	{
		message = message.Replace("{product}", AppData.ProductName, StringComparison.Ordinal);
		IBootstrapperDialog? dialog = Dialog;
		if (dialog != null)
		{
			dialog.Message = message;
		}
	}

	private void UpdateProgressBar(bool updateStatus = true)
	{
		if (Dialog != null)
		{
			long num = Math.Max(0L, Interlocked.Read(in _totalDownloadedBytes));
			long num2 = Interlocked.Read(in _totalPackagedBytes);
			if (updateStatus && num2 > 0)
			{
				SetStatus(string.Format(CultureInfo.InvariantCulture, Strings.Bootstrapper_Status_DownloadingPackages, FormatBytes(Math.Min(num, num2)), FormatBytes(num2)));
			}
			if (double.IsFinite(_progressIncrement))
			{
				int value = (int)Math.Floor(_progressIncrement * (double)num);
				value = Math.Clamp(value, 0, 10000);
				Dialog.ProgressValue = value;
			}
			if (double.IsFinite(_taskbarProgressIncrement))
			{
				double value2 = _taskbarProgressIncrement * (double)num;
				value2 = Math.Clamp(value2, 0.0, _taskbarProgressMaximum);
				Dialog.TaskbarProgressValue = value2;
			}
		}
	}

	private void RecalculateProgressIncrements()
	{
		long num = Interlocked.Read(in _totalPackagedBytes);
		_taskbarProgressMaximum = 1.0;
		if (num <= 0)
		{
			_progressIncrement = 0.0;
			_taskbarProgressIncrement = 0.0;
		}
		else
		{
			_progressIncrement = 10000.0 / (double)num;
			_taskbarProgressIncrement = _taskbarProgressMaximum / (double)num;
		}
	}

	private void AddProgressTotal(long bytes)
	{
		if (bytes > 0)
		{
			Interlocked.Add(ref _totalPackagedBytes, bytes);
			RecalculateProgressIncrements();
		}
	}

	private static string FormatBytes(long bytes)
	{
		string[] array = new string[4] { "B", "KB", "MB", "GB" };
		double num = bytes;
		int num2 = 0;
		while (num >= 1024.0 && num2 < array.Length - 1)
		{
			num2++;
			num /= 1024.0;
		}
		return $"{num:0.##} {array[num2]}";
	}
}
