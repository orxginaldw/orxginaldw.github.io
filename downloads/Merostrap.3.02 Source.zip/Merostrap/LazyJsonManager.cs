namespace Merostrap;

internal class LazyJsonManager<T> : JsonManager<T> where T : class, new()
{
	public override T Prop
	{
		get
		{
			if (!Loaded)
			{
				Load();
			}
			return _prop;
		}
		set
		{
			_prop = value;
			Loaded = true;
		}
	}

	public LazyJsonManager(string? className)
		: base(className)
	{
	}
}
