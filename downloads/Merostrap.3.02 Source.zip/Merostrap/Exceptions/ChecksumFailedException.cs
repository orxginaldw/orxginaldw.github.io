using System;

namespace Merostrap.Exceptions;

internal class ChecksumFailedException : Exception
{
	public ChecksumFailedException()
	{
	}

	public ChecksumFailedException(string message)
		: base(message)
	{
	}

	public ChecksumFailedException(string message, Exception innerException)
		: base(message, innerException)
	{
	}
}
