using System;

namespace Merostrap.Exceptions;

internal class AssertionException : Exception
{
	public AssertionException()
		: base("This is very likely just an off-chance error. Please report this first, and then start Merostrap again.")
	{
	}

	public AssertionException(string message)
		: base(message + "\n\nThis is very likely just an off-chance error. Please report this first, and then start Merostrap again.")
	{
	}

	public AssertionException(string message, Exception innerException)
		: base(message + "\n\nThis is very likely just an off-chance error. Please report this first, and then start Merostrap again.", innerException)
	{
	}
}
