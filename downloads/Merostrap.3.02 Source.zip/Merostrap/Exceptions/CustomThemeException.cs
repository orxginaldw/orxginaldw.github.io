using System;
using System.Globalization;
using System.Text;
using Merostrap.Resources;

namespace Merostrap.Exceptions;

internal class CustomThemeException : Exception
{
	public string EnglishMessage { get; }

	public CustomThemeException()
	{
	}

	public CustomThemeException(string message)
		: base(message)
	{
	}

	public CustomThemeException(string message, Exception innerException)
		: base(message, innerException)
	{
	}

	public CustomThemeException(string translationString, params object?[] args)
		: base(string.Format(CultureInfo.InvariantCulture, Strings.ResourceManager.GetString(translationString, CultureInfo.CurrentCulture) ?? translationString, args))
	{
		EnglishMessage = string.Format(CultureInfo.InvariantCulture, Strings.ResourceManager.GetString(translationString, CultureInfo.InvariantCulture) ?? translationString, args);
	}

	public CustomThemeException(Exception innerException, string translationString)
		: base(Strings.ResourceManager.GetString(translationString, CultureInfo.CurrentCulture) ?? translationString, innerException)
	{
		EnglishMessage = Strings.ResourceManager.GetString(translationString, CultureInfo.InvariantCulture) ?? translationString;
	}

	public CustomThemeException(Exception innerException, string translationString, params object?[] args)
		: base(string.Format(CultureInfo.InvariantCulture, Strings.ResourceManager.GetString(translationString, CultureInfo.CurrentCulture) ?? translationString, args), innerException)
	{
		EnglishMessage = string.Format(CultureInfo.InvariantCulture, Strings.ResourceManager.GetString(translationString, CultureInfo.InvariantCulture) ?? translationString, args);
	}

	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder(GetType().ToString());
		if (!string.IsNullOrEmpty(Message))
		{
			StringBuilder stringBuilder2 = stringBuilder;
			StringBuilder stringBuilder3 = stringBuilder2;
			IFormatProvider invariantCulture = CultureInfo.InvariantCulture;
			IFormatProvider provider = invariantCulture;
			StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(2, 1, stringBuilder2, invariantCulture);
			handler.AppendLiteral(": ");
			handler.AppendFormatted(Message);
			stringBuilder3.Append(provider, ref handler);
		}
		if (!string.IsNullOrEmpty(EnglishMessage) && Message != EnglishMessage)
		{
			StringBuilder stringBuilder2 = stringBuilder;
			StringBuilder stringBuilder4 = stringBuilder2;
			IFormatProvider invariantCulture = CultureInfo.InvariantCulture;
			IFormatProvider provider2 = invariantCulture;
			StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(3, 1, stringBuilder2, invariantCulture);
			handler.AppendLiteral(" (");
			handler.AppendFormatted(EnglishMessage);
			handler.AppendLiteral(")");
			stringBuilder4.Append(provider2, ref handler);
		}
		if (InnerException != null)
		{
			stringBuilder.AppendFormat(CultureInfo.InvariantCulture, "\r\n ---> {0}\r\n   ", InnerException);
		}
		if (StackTrace != null)
		{
			stringBuilder.AppendFormat(CultureInfo.InvariantCulture, "\r\n{0}", StackTrace);
		}
		return stringBuilder.ToString();
	}
}
