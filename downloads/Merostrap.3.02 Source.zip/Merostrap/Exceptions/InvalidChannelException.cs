using System;
using System.Net;

namespace Merostrap.Exceptions;

internal class InvalidChannelException : Exception
{
	public HttpStatusCode? StatusCode { get; }

	public InvalidChannelException()
	{
	}

	public InvalidChannelException(string message)
		: base(message)
	{
	}

	public InvalidChannelException(string message, Exception innerException)
		: base(message, innerException)
	{
	}

	public InvalidChannelException(HttpStatusCode? statusCode)
	{
		StatusCode = statusCode;
	}
}
