using System;

namespace Merostrap.Exceptions;

internal class InvalidHTTPResponseException : Exception
{
	public InvalidHTTPResponseException()
	{
	}

	public InvalidHTTPResponseException(string message)
		: base(message)
	{
	}

	public InvalidHTTPResponseException(string message, Exception innerException)
		: base(message, innerException)
	{
	}
}
