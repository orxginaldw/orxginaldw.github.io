using System;
using System.IO;

namespace Merostrap;

internal static class Paths
{
	public static string Temp => Path.Combine(Path.GetTempPath(), "Merostrap");

	public static string UserProfile => Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);

	public static string LocalAppData => Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);

	public static string Desktop => Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);

	public static string WindowsStartMenu => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Programs");

	public static string Process => Environment.ProcessPath;

	public static string TempUpdates => Path.Combine(Temp, "Updates");

	public static string TempLogs => Path.Combine(Temp, "Logs");

	public static string ConfigRoot { get; private set; } = "";

	public static string DataRoot { get; private set; } = "";

	public static string Downloads { get; private set; } = "";

	public static string Cache { get; private set; } = "";

	public static string SavedFlagProfiles { get; private set; } = "";

	public static string Versions { get; private set; } = "";

	public static string Modifications { get; private set; } = "";

	public static string Roblox { get; private set; } = "";

	public static string CustomThemes { get; private set; } = "";

	public static string RobloxLogs { get; private set; } = "";

	public static string RobloxCache { get; private set; } = "";

	public static string CustomCursors { get; private set; } = "";

	public static string SoberAssetOverlay { get; private set; } = "";

	public static string SoberData { get; private set; } = "";

	public static string SoberConfig { get; private set; } = "";

	public static string CustomFont => Path.Combine(Modifications, "content", "fonts", "CustomFont.ttf");

	public static string Logs
	{
		get
		{
			if (OperatingSystem.IsMacOS())
			{
				return Path.Combine(UserProfile, "Library", "Logs", "Merostrap");
			}
			if (OperatingSystem.IsLinux())
			{
				string environmentVariable = Environment.GetEnvironmentVariable("XDG_STATE_HOME");
				return Path.Combine(string.IsNullOrEmpty(environmentVariable) ? Path.Combine(UserProfile, ".local", "state") : environmentVariable, "Merostrap");
			}
			return Path.Combine(LocalAppData, "Merostrap", "Logs");
		}
	}

	public static string Base => DataRoot;

	public static bool Initialized => !string.IsNullOrEmpty(DataRoot);

	public static void Initialize()
	{
		if (OperatingSystem.IsWindows())
		{
			DataRoot = (ConfigRoot = Path.Combine(LocalAppData, "Merostrap"));
			Roblox = Path.Combine(LocalAppData, "Roblox");
		}
		else if (OperatingSystem.IsMacOS())
		{
			string path = Path.Combine(UserProfile, "Library");
			DataRoot = (ConfigRoot = Path.Combine(path, "Application Support", "Merostrap"));
			Roblox = Path.Combine(path, "Application Support", "Roblox");
		}
		else if (OperatingSystem.IsLinux())
		{
			string path2 = Environment.GetEnvironmentVariable("XDG_CONFIG_HOME") ?? Path.Combine(UserProfile, ".config");
			string? path3 = Environment.GetEnvironmentVariable("XDG_DATA_HOME") ?? Path.Combine(UserProfile, ".local", "share");
			string path4 = Environment.GetEnvironmentVariable("XDG_CACHE_HOME") ?? Path.Combine(UserProfile, ".cache");
			if (Environment.GetEnvironmentVariable("XDG_BIN_HOME") == null)
			{
				Path.Combine(UserProfile, ".local", "bin");
			}
			ConfigRoot = Path.Combine(path2, "Merostrap");
			DataRoot = Path.Combine(path3, "Merostrap");
			Roblox = Path.Combine(DataRoot, "Versions", "Sober");
			SoberData = Path.Combine(Roblox, "data", "sober");
			SoberAssetOverlay = Path.Combine(Roblox, "data", "sober", "asset_overlay");
			SoberConfig = Path.Combine(Roblox, "config", "sober");
			Cache = Path.Combine(path4, "Merostrap");
		}
		SavedFlagProfiles = Path.Combine(ConfigRoot, "SavedFlagProfiles");
		CustomCursors = Path.Combine(ConfigRoot, "CustomCursorsSets");
		CustomThemes = Path.Combine(ConfigRoot, "CustomThemes");
		Downloads = Path.Combine(DataRoot, "Downloads");
		Versions = Path.Combine(DataRoot, "Versions");
		Modifications = Path.Combine(ConfigRoot, "Modifications");
		if (string.IsNullOrEmpty(Cache))
		{
			Cache = Path.Combine(DataRoot, "Cache");
		}
		if (OperatingSystem.IsMacOS())
		{
			RobloxLogs = Path.Combine(UserProfile, "Library", "Logs", "Roblox");
			RobloxCache = Path.Combine(UserProfile, "Library", "Caches", "com.roblox.RobloxPlayer");
		}
		else if (OperatingSystem.IsLinux())
		{
			RobloxLogs = Path.Combine(Roblox, "data", "sober", "sober_logs");
			RobloxCache = Path.Combine(Roblox, "cache");
		}
		else
		{
			RobloxLogs = Path.Combine(Roblox, "logs");
			RobloxCache = Path.Combine(Path.GetTempPath(), "Roblox");
		}
		OperatingSystem.IsWindows();
		Directory.CreateDirectory(ConfigRoot);
		Directory.CreateDirectory(DataRoot);
		Directory.CreateDirectory(Path.GetDirectoryName(SavedFlagProfiles) ?? SavedFlagProfiles);
		Directory.CreateDirectory(CustomCursors);
		Directory.CreateDirectory(CustomThemes);
		Directory.CreateDirectory(Modifications);
		Directory.CreateDirectory(Downloads);
		Directory.CreateDirectory(Versions);
		Directory.CreateDirectory(Cache);
		Directory.CreateDirectory(Logs);
		if (!OperatingSystem.IsLinux())
		{
			return;
		}
		try
		{
			string text3 = Path.Combine(DataRoot, "Roblox");
			if (Directory.Exists(text3) && !Directory.Exists(Roblox))
			{
				Directory.CreateDirectory(Path.GetDirectoryName(Roblox));
				Directory.Move(text3, Roblox);
			}
			TryMove(Path.Combine(DataRoot, "Modifications"), Modifications);
			string text4 = Path.Combine(UserProfile, ".config", "Merostrap");
			string path5 = Path.Combine(ConfigRoot, ".migrated_to_xdg");
			if (Directory.Exists(text4) && !File.Exists(path5) && !string.Equals(Path.GetFullPath(text4), Path.GetFullPath(ConfigRoot), StringComparison.OrdinalIgnoreCase))
			{
				TryMove(Path.Combine(text4, "Modifications"), Modifications);
				TryMove(Path.Combine(text4, "SavedFlagProfiles"), SavedFlagProfiles);
				TryMove(Path.Combine(text4, "CustomCursorsSets"), CustomCursors);
				TryMove(Path.Combine(text4, "CustomThemes"), CustomThemes);
				TryMove(Path.Combine(text4, "PlayerState.json"), Path.Combine(DataRoot, "PlayerState.json"));
				TryMove(Path.Combine(text4, "StudioState.json"), Path.Combine(DataRoot, "StudioState.json"));
				TryMove(Path.Combine(text4, "Downloads"), Downloads);
				TryMove(Path.Combine(text4, "Versions"), Versions);
				TryMove(Path.Combine(text4, "Cache"), Cache);
				TryMove(Path.Combine(text4, "Logs"), Logs);
				try
				{
					File.WriteAllText(path5, DateTime.UtcNow.ToString("o"));
					return;
				}
				catch
				{
					return;
				}
			}
		}
		catch
		{
		}
		static void TryMove(string src, string dst)
		{
			try
			{
				if (File.Exists(src) && !File.Exists(dst))
				{
					File.Move(src, dst);
				}
				else if (Directory.Exists(src))
				{
					if (Directory.Exists(dst))
					{
						string[] directories = Directory.GetDirectories(src, "*", SearchOption.AllDirectories);
						foreach (string path6 in directories)
						{
							string relativePath = Path.GetRelativePath(src, path6);
							Directory.CreateDirectory(Path.Combine(dst, relativePath));
						}
						directories = Directory.GetFiles(src, "*", SearchOption.AllDirectories);
						foreach (string text5 in directories)
						{
							string relativePath2 = Path.GetRelativePath(src, text5);
							string text6 = Path.Combine(dst, relativePath2);
							Directory.CreateDirectory(Path.GetDirectoryName(text6) ?? Path.GetDirectoryName(dst));
							if (!File.Exists(text6))
							{
								File.Move(text5, text6);
							}
						}
						try
						{
							Directory.Delete(src, recursive: true);
							return;
						}
						catch
						{
							return;
						}
					}
					Directory.Move(src, dst);
				}
			}
			catch
			{
			}
		}
	}
}
