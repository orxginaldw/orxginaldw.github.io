using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text.Json;
using Merostrap.Enums.Messagebox;
using Merostrap.Resources;
using Merostrap.UI;

namespace Merostrap;

internal class SoberSettingsManager : JsonManager<Dictionary<string, object>>
{
	private static readonly JsonSerializerOptions _writeOptions = new JsonSerializerOptions
	{
		WriteIndented = true
	};

	private static readonly JsonSerializerOptions _readOptions = new JsonSerializerOptions
	{
		ReadCommentHandling = JsonCommentHandling.Skip,
		AllowTrailingCommas = true
	};

	public static readonly IReadOnlyDictionary<string, string> PresetKeys = new Dictionary<string, string>
	{
		["AllowGamepadPermission"] = "allow_gamepad_permission",
		["EnableGamemode"] = "enable_gamemode",
		["EnableHiDpi"] = "enable_hidpi",
		["TouchMode"] = "touch_mode",
		["UseConsoleExperience"] = "use_console_experience",
		["UseLibsecret"] = "use_libsecret",
		["UseOpengl"] = "use_opengl",
		["ServerLocationIndicatorEnabled"] = "server_location_indicator_enabled",
		["DiscordRpcEnabled"] = "discord_rpc_enabled",
		["DiscordRpcShowJoinButton"] = "discord_rpc_show_join_button",
		["CloseOnLeave"] = "close_on_leave",
		["FFlagsContainer"] = "fflags"
	};

	public override string ClassName => "SoberSettingsManager";

	public override string FileName => "config.json";

	public override string FileLocation => Path.Combine(Paths.SoberConfig, FileName);

	public void SetPreset(string presetName, object? value)
	{
		if (!PresetKeys.TryGetValue(presetName, out string value2))
		{
			App.Logger.Warn("Unknown preset '" + presetName + "'");
			return;
		}
		if (!(value is string text))
		{
			goto IL_009c;
		}
		object obj;
		long result;
		if (text.Equals("true", StringComparison.OrdinalIgnoreCase))
		{
			obj = true;
		}
		else if (text.Equals("false", StringComparison.OrdinalIgnoreCase))
		{
			obj = false;
		}
		else if (long.TryParse(text, out result))
		{
			obj = result;
		}
		else
		{
			if (!double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out var result2))
			{
				goto IL_009c;
			}
			obj = result2;
		}
		goto IL_009f;
		IL_009c:
		obj = value;
		goto IL_009f;
		IL_009f:
		object value3 = obj;
		SetValue(value2, value3);
	}

	public string? GetPreset(string name)
	{
		if (PresetKeys.TryGetValue(name, out string value))
		{
			return GetValue(value);
		}
		App.Logger.Warn("Unknown preset '" + name + "'");
		return null;
	}

	public void SetValue(string key, object? value)
	{
		if (value == null)
		{
			Prop.Remove(key);
		}
		else
		{
			Prop[key] = value;
		}
	}

	public string? GetValue(string key)
	{
		if (Prop.TryGetValue(key, out object value) && value != null)
		{
			if (!(value is bool))
			{
				if (!(value is int num))
				{
					if (!(value is long num2))
					{
						if (!(value is double num3))
						{
							if (value is string result)
							{
								return result;
							}
							return value.ToString();
						}
						return num3.ToString(CultureInfo.InvariantCulture);
					}
					return num2.ToString(CultureInfo.InvariantCulture);
				}
				return num.ToString(CultureInfo.InvariantCulture);
			}
			return ((bool)value) ? "true" : "false";
		}
		return null;
	}

	public override bool Load(bool alertFailure = true)
	{
		if (!OperatingSystem.IsLinux())
		{
			App.Logger.Warn("Not on Linux, Sober settings not applicable.");
			Loaded = false;
			Prop = new Dictionary<string, object>();
			return false;
		}
		App.Logger.Info("Loading from " + FileLocation + "...");
		if (!File.Exists(FileLocation))
		{
			App.Logger.Warn("Config file does not exist. Sober is not configured.");
			Loaded = false;
			Prop = new Dictionary<string, object>();
			return false;
		}
		try
		{
			Dictionary<string, object> prop = JsonSerializer.Deserialize<Dictionary<string, object>>(File.ReadAllText(FileLocation), _readOptions) ?? new Dictionary<string, object>();
			Prop = prop;
			Loaded = true;
			_savedHash = ComputeHash(Prop);
			App.Logger.Info("Loaded successfully!");
			return true;
		}
		catch (Exception ex)
		{
			App.Logger.Error($"Failed to load! {ex}");
			Loaded = false;
			Prop = new Dictionary<string, object>();
			if (alertFailure)
			{
				Frontend.ShowMessageBox(Strings.JsonManager_SettingsLoadFailed + "\n\n" + ex.Message, MessageBoxImage.Warning);
			}
			return false;
		}
	}

	public override bool Save()
	{
		if (!HasUnsavedChanges)
		{
			App.Logger.Info("No changes, skipping save.");
			return false;
		}
		if (!Loaded)
		{
			App.Logger.Warn("Save skipped – settings not loaded (non‑Linux or file missing/invalid).");
			return true;
		}
		App.Logger.Info("Saving to " + FileLocation + "...");
		try
		{
			string directoryName = Path.GetDirectoryName(FileLocation);
			if (!string.IsNullOrEmpty(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			string contents = JsonSerializer.Serialize(Prop, _writeOptions);
			File.WriteAllText(FileLocation, contents);
			_savedHash = ComputeHash(Prop);
			App.Logger.Info("Save Complete!");
			return true;
		}
		catch (Exception value)
		{
			App.Logger.Error("Failed to save appStorage.json");
			App.Logger.Error(value);
			return false;
		}
	}

	public Dictionary<string, object> GetOrCreateFFlagsContainer()
	{
		string key = PresetKeys["FFlagsContainer"];
		Dictionary<string, object> dictionary;
		if (Prop.TryGetValue(key, out object value))
		{
			dictionary = value as Dictionary<string, object>;
			if (dictionary != null)
			{
				goto IL_003d;
			}
		}
		dictionary = new Dictionary<string, object>();
		Prop[key] = dictionary;
		goto IL_003d;
		IL_003d:
		return dictionary;
	}

	public SoberSettingsManager()
		: base((string?)null)
	{
	}
}
