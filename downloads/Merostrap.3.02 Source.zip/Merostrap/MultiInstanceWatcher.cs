using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Merostrap.Utility;

namespace Merostrap;

internal static class MultiInstanceWatcher
{
	private const string OwnerName = "Local\\Merostrap.MultiInstance.Owner";

	private const string ReadyName = "Local\\Merostrap.MultiInstance.Ready";

	private const string PendingName = "Local\\Merostrap.MultiInstance.Pending";

	public static async Task<bool> EnsureStartedAsync(CancellationToken cancellationToken)
	{
		if (!OperatingSystem.IsWindows())
		{
			return false;
		}
		using EventWaitHandle ready = new EventWaitHandle(initialState: false, EventResetMode.ManualReset, "Local\\Merostrap.MultiInstance.Ready");
		using EventWaitHandle pending = new EventWaitHandle(initialState: false, EventResetMode.AutoReset, "Local\\Merostrap.MultiInstance.Pending");
		using InterProcessLock launchLock = new InterProcessLock("MultiInstanceLaunch", TimeSpan.FromSeconds(5L));
		if (!launchLock.IsAcquired)
		{
			return false;
		}
		pending.Set();
		if (ready.WaitOne(0))
		{
			return true;
		}
		using Process helper = Process.Start(new ProcessStartInfo(Paths.Process)
		{
			Arguments = "-multiinstancewatcher -quiet",
			UseShellExecute = false,
			CreateNoWindow = true
		});
		for (int i = 0; i < 100; i++)
		{
			cancellationToken.ThrowIfCancellationRequested();
			if (ready.WaitOne(0))
			{
				return true;
			}
			if (helper == null || helper.HasExited)
			{
				return false;
			}
			await Task.Delay(50, cancellationToken);
		}
		App.Logger.Warn("Multi-instance helper did not become ready in time");
		return false;
	}

	public static void Run()
	{
		if (OperatingSystem.IsWindows())
		{
			RunSession("Local\\Merostrap.MultiInstance.Owner", "Local\\Merostrap.MultiInstance.Ready", "Local\\Merostrap.MultiInstance.Pending", "ROBLOX_singletonMutex", "ROBLOX_singletonEvent", HasPlayers, TimeSpan.FromSeconds(60L), TimeSpan.FromSeconds(5L));
		}
	}

	internal static void RunSession(string ownerName, string readyName, string pendingName, string singletonName, string singletonEventName, Func<bool> hasPlayers, TimeSpan startupGrace, TimeSpan exitGrace)
	{
		using Mutex mutex = new Mutex(initiallyOwned: false, ownerName);
		if (!Acquire(mutex))
		{
			return;
		}
		InterProcessLock interProcessLock = null;
		try
		{
			using EventWaitHandle eventWaitHandle = new EventWaitHandle(initialState: false, EventResetMode.ManualReset, readyName);
			using EventWaitHandle eventWaitHandle2 = new EventWaitHandle(initialState: false, EventResetMode.AutoReset, pendingName);
			eventWaitHandle.Reset();
			using Mutex mutex2 = new Mutex(initiallyOwned: false, singletonName);
			if (!Acquire(mutex2))
			{
				App.Logger.Warn("Roblox already owns its singleton. Close all clients before enabling multi-instance.");
				return;
			}
			try
			{
				using (new Mutex(initiallyOwned: false, singletonEventName))
				{
					eventWaitHandle.Set();
					App.Logger.Info("Multi-instance helper ready");
					DateTime dateTime = DateTime.UtcNow + startupGrace;
					try
					{
						while (true)
						{
							if (eventWaitHandle2.WaitOne(500))
							{
								dateTime = DateTime.UtcNow + startupGrace;
							}
							bool flag = hasPlayers();
							if (flag && DateTime.UtcNow + exitGrace > dateTime)
							{
								dateTime = DateTime.UtcNow + exitGrace;
							}
							if (flag || !(DateTime.UtcNow >= dateTime))
							{
								continue;
							}
							interProcessLock = new InterProcessLock("MultiInstanceLaunch");
							if (!interProcessLock.IsAcquired)
							{
								interProcessLock.Dispose();
								interProcessLock = null;
								continue;
							}
							if (!eventWaitHandle2.WaitOne(0))
							{
								break;
							}
							dateTime = DateTime.UtcNow + startupGrace;
							interProcessLock.Dispose();
							interProcessLock = null;
						}
						eventWaitHandle.Reset();
					}
					finally
					{
						eventWaitHandle.Reset();
					}
				}
			}
			finally
			{
				mutex2.ReleaseMutex();
			}
		}
		finally
		{
			mutex.ReleaseMutex();
			interProcessLock?.Dispose();
		}
	}

	private static bool Acquire(Mutex mutex)
	{
		try
		{
			return mutex.WaitOne(0);
		}
		catch (AbandonedMutexException)
		{
			return true;
		}
	}

	private static bool HasPlayers()
	{
		try
		{
			Process[] processesByName = Process.GetProcessesByName("RobloxPlayerBeta");
			try
			{
				return processesByName.Length != 0;
			}
			finally
			{
				Process[] array = processesByName;
				for (int i = 0; i < array.Length; i++)
				{
					array[i].Dispose();
				}
			}
		}
		catch (Exception exception)
		{
			App.Logger.Warn(exception, "Unable to inspect Roblox clients");
			return true;
		}
	}
}
