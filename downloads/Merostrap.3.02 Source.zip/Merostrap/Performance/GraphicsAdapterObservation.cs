namespace Merostrap.Performance;

internal sealed record GraphicsAdapterObservation(string Name, string? DriverVersion, int? RefreshHz, int? Width, int? Height);
