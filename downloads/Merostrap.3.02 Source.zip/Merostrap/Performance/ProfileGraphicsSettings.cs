using System.IO;

namespace Merostrap.Performance;

internal static class ProfileGraphicsSettings
{
	public static string Prepare(PerformanceOptions options, string settingsPath, string recoveryPath)
	{
		int? userFrameCap;
		if (File.Exists(settingsPath) && File.GetAttributes(settingsPath).HasFlag(FileAttributes.ReadOnly))
		{
			userFrameCap = options.UserFrameCap;
			if (userFrameCap.HasValue)
			{
				int valueOrDefault = userFrameCap.GetValueOrDefault();
				if (valueOrDefault >= 0 && valueOrDefault <= 1000)
				{
					goto IL_0071;
				}
			}
			if (options.HasNamedProfile || (options.Profile == OptimizationProfileKind.Custom && File.Exists(recoveryPath)))
			{
				goto IL_0071;
			}
		}
		if (File.Exists(recoveryPath))
		{
			userFrameCap = options.UserFrameCap;
			if (userFrameCap.HasValue)
			{
				int valueOrDefault = userFrameCap.GetValueOrDefault();
				if (valueOrDefault >= 0 && valueOrDefault <= 1000)
				{
					goto IL_00c8;
				}
			}
			if (options.HasNamedProfile || options.Profile == OptimizationProfileKind.Custom)
			{
				goto IL_00c8;
			}
		}
		goto IL_00cf;
		IL_00cf:
		userFrameCap = options.UserFrameCap;
		if (userFrameCap.HasValue)
		{
			int valueOrDefault = userFrameCap.GetValueOrDefault();
			if (valueOrDefault >= 0 && valueOrDefault <= 1000)
			{
				int num = ((options.UserFrameCap == 0) ? (-1) : options.UserFrameCap.Value);
				if (!options.HasNamedProfile)
				{
					return GraphicsSettingsTransaction.ApplyFrameCap(settingsPath, recoveryPath, num);
				}
				return GraphicsSettingsTransaction.Apply(settingsPath, recoveryPath, num, (options.Profile == OptimizationProfileKind.Competitive) ? 1 : ((options.Profile == OptimizationProfileKind.Balanced) ? 5 : 10));
			}
		}
		if (options.HasNamedProfile)
		{
			return GraphicsSettingsTransaction.ApplyWithoutFrameCap(settingsPath, recoveryPath, options.Profile switch
			{
				OptimizationProfileKind.Competitive => 1, 
				OptimizationProfileKind.Balanced => 5, 
				_ => 10, 
			});
		}
		if (options.Profile != OptimizationProfileKind.Custom || !File.Exists(recoveryPath))
		{
			return "Unchanged";
		}
		return GraphicsSettingsTransaction.Restore(settingsPath, recoveryPath);
		IL_00c8:
		GraphicsSettingsTransaction.RebaseChangedSettings(settingsPath, recoveryPath);
		goto IL_00cf;
		IL_0071:
		return "Skipped: Roblox settings are read-only; existing graphics settings and recovery data were preserved.";
	}
}
