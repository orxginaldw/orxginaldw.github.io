namespace Merostrap.Performance;

internal sealed record CustomGraphicsChoices(int? FrameCap, int GraphicsQuality);
