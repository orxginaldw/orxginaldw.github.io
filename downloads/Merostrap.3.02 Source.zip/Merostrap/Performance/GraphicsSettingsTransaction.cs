using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
using System.Xml;
using System.Xml.Linq;

namespace Merostrap.Performance;

internal static class GraphicsSettingsTransaction
{
	private sealed record Recovery(int Version, string Target, byte[] Original, byte[] Applied, byte[] BeforeApply, string OriginalHash, string AppliedHash, string BeforeApplyHash);

	private const int MaximumSettingsBytes = 4194304;

	public static string Apply(string target, string backup, int? frameCap, int quality)
	{
		return ApplyCore(target, backup, frameCap, quality, restoreOriginalCap: false);
	}

	public static string ApplyWithoutFrameCap(string target, string backup, int quality)
	{
		return ApplyCore(target, backup, null, quality, restoreOriginalCap: true);
	}

	public static string ApplyFrameCap(string target, string backup, int frameCap)
	{
		return ApplyCore(target, backup, frameCap, null, restoreOriginalCap: false);
	}

	public static void RebaseChangedSettings(string target, string backup)
	{
		(target, backup) = Paths(target, backup);
		using (Lock(target))
		{
			using (LockRecovery(backup))
			{
				if (File.Exists(backup))
				{
					Recovery recovery = LoadRecovery(target, backup);
					byte[] array = Read(target, 4194304);
					Parse(array);
					if (!KnownState(array, recovery))
					{
						File.Move(backup, backup + ".archived-" + Guid.NewGuid().ToString("N"), overwrite: false);
					}
				}
			}
		}
	}

	private static string ApplyCore(string target, string backup, int? frameCap, int? quality, bool restoreOriginalCap)
	{
		bool flag;
		if (frameCap.HasValue)
		{
			int valueOrDefault = frameCap.GetValueOrDefault();
			if (valueOrDefault < -1 || valueOrDefault == 0)
			{
				flag = true;
				goto IL_0023;
			}
		}
		flag = false;
		goto IL_0023;
		IL_0023:
		bool flag2 = flag;
		if (!flag2)
		{
			bool flag3;
			switch (quality)
			{
			default:
				flag3 = true;
				break;
			case null:
			case 0:
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
			case 7:
			case 8:
			case 9:
			case 10:
				flag3 = false;
				break;
			}
			flag2 = flag3;
		}
		if (flag2)
		{
			throw new ArgumentOutOfRangeException("frameCap");
		}
		(target, backup) = Paths(target, backup);
		using (Lock(target))
		{
			using (LockRecovery(backup))
			{
				byte[] array = Read(target, 4194304);
				Recovery recovery = (File.Exists(backup) ? LoadRecovery(target, backup) : null);
				if ((object)recovery != null && !KnownState(array, recovery))
				{
					throw new InvalidDataException("Roblox settings changed since the profile was applied. Preserve those changes before applying another profile.");
				}
				XDocument xDocument = Parse(array);
				XElement properties = Properties(xDocument);
				if (frameCap.HasValue)
				{
					Set("int", "FramerateCap", frameCap.Value);
				}
				if (restoreOriginalCap && (object)recovery != null)
				{
					XElement[] array2 = (from x in Properties(Parse(recovery.Original)).Elements()
						where (string?)x.Attribute("name") == "FramerateCap"
						select x).ToArray();
					XElement[] array3 = (from x in properties.Elements()
						where (string?)x.Attribute("name") == "FramerateCap"
						select x).ToArray();
					if (array2.Length > 1 || array3.Length > 1 || array2.Any((XElement x) => x.Name != "int") || array3.Any((XElement x) => x.Name != "int"))
					{
						throw new InvalidDataException("Ambiguous FPS setting; profile application stopped.");
					}
					if (array2.Length == 0)
					{
						array3.SingleOrDefault()?.Remove();
					}
					else if (array3.Length == 0)
					{
						properties.Add(new XElement(array2[0]));
					}
					else
					{
						array3[0].ReplaceWith(new XElement(array2[0]));
					}
				}
				if (quality.HasValue)
				{
					Set("token", "SavedQualityLevel", quality.Value);
				}
				else if ((object)recovery != null)
				{
					XElement[] array4 = (from x in Properties(Parse(recovery.Original)).Elements()
						where (string?)x.Attribute("name") == "SavedQualityLevel"
						select x).ToArray();
					XElement[] array5 = (from x in properties.Elements()
						where (string?)x.Attribute("name") == "SavedQualityLevel"
						select x).ToArray();
					if (array4.Length > 1 || array5.Length > 1)
					{
						throw new InvalidDataException("Ambiguous graphics quality.");
					}
					array5.SingleOrDefault()?.Remove();
					if (array4.Length == 1)
					{
						properties.Add(new XElement(array4[0]));
					}
				}
				byte[] array6;
				using (MemoryStream memoryStream = new MemoryStream())
				{
					xDocument.Save(memoryStream, SaveOptions.DisableFormatting);
					array6 = memoryStream.ToArray();
				}
				if (array6.Length > 4194304)
				{
					throw new InvalidDataException("Updated settings exceed the size limit.");
				}
				if (((ReadOnlySpan<byte>)array.AsSpan()).SequenceEqual((ReadOnlySpan<byte>)array6))
				{
					return "Unchanged";
				}
				if (File.GetAttributes(target).HasFlag(FileAttributes.ReadOnly))
				{
					throw new IOException("Roblox settings are read-only; no profile was applied.");
				}
				byte[] array7 = recovery?.Original ?? array;
				Recovery value = new Recovery(1, target, array7, array6, array, Hash(array7), Hash(array6), Hash(array));
				AtomicWrite(backup, JsonSerializer.SerializeToUtf8Bytes(value));
				if (!((ReadOnlySpan<byte>)Read(target, 4194304).AsSpan()).SequenceEqual((ReadOnlySpan<byte>)array))
				{
					throw new InvalidDataException("Roblox settings changed while applying the profile. Recovery data was retained.");
				}
				AtomicWrite(target, array6);
				return "Applied";
				void Set(string type, string name, int num)
				{
					XElement[] array8 = (from x in properties.Elements()
						where (string?)x.Attribute("name") == name
						select x).ToArray();
					if (array8.Length > 1 || (array8.Length == 1 && array8[0].Name != type))
					{
						throw new InvalidDataException("Ambiguous or invalid " + name + " setting.");
					}
					XElement xElement = array8.SingleOrDefault();
					if (xElement == null)
					{
						xElement = new XElement(type, new XAttribute("name", name));
						properties.Add(xElement);
					}
					xElement.Value = num.ToString(CultureInfo.InvariantCulture);
				}
			}
		}
	}

	public static string Restore(string target, string backup)
	{
		(target, backup) = Paths(target, backup);
		using (Lock(target))
		{
			using (LockRecovery(backup))
			{
				if (!File.Exists(backup))
				{
					return "Nothing to restore";
				}
				Recovery recovery = LoadRecovery(target, backup);
				byte[] array = Read(target, 4194304);
				if (!((ReadOnlySpan<byte>)array.AsSpan()).SequenceEqual((ReadOnlySpan<byte>)recovery.Original))
				{
					if (!KnownState(array, recovery))
					{
						throw new InvalidDataException("Roblox settings changed after this profile. Restore was stopped to preserve those changes.");
					}
					if (File.GetAttributes(target).HasFlag(FileAttributes.ReadOnly))
					{
						throw new IOException("Roblox settings are read-only; restore was stopped.");
					}
					AtomicWrite(target, recovery.Original);
				}
				File.Delete(backup);
				return "Restored";
			}
		}
	}

	public static string KeepCurrent(string target, string backup)
	{
		(target, backup) = Paths(target, backup);
		using (Lock(target))
		{
			using (LockRecovery(backup))
			{
				if (!File.Exists(backup))
				{
					return "No active recovery record";
				}
				LoadRecovery(target, backup);
				Parse(Read(target, 4194304));
				string text = backup + ".archived-" + Guid.NewGuid().ToString("N");
				File.Move(backup, text, overwrite: false);
				return "Current graphics kept. Previous recovery archived at " + text;
			}
		}
	}

	private static (string Target, string Backup) Paths(string target, string backup)
	{
		target = Path.GetFullPath(target);
		backup = Path.GetFullPath(backup);
		if (string.Equals(target, backup, StringComparison.OrdinalIgnoreCase) || string.Equals(target + ".merostrap.lock", backup, StringComparison.OrdinalIgnoreCase) || string.Equals(backup + ".merostrap.lock", target, StringComparison.OrdinalIgnoreCase))
		{
			throw new ArgumentException("Recovery data must use a separate file.");
		}
		return (Target: target, Backup: backup);
	}

	private static FileStream Lock(string target)
	{
		return new FileStream(target + ".merostrap.lock", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
	}

	private static FileStream LockRecovery(string backup)
	{
		Directory.CreateDirectory(Path.GetDirectoryName(backup));
		return Lock(backup);
	}

	private static string Hash(byte[] bytes)
	{
		return Convert.ToHexString(SHA256.HashData(bytes));
	}

	private static bool KnownState(byte[] current, Recovery recovery)
	{
		if (!((ReadOnlySpan<byte>)current.AsSpan()).SequenceEqual((ReadOnlySpan<byte>)recovery.Original) && !((ReadOnlySpan<byte>)current.AsSpan()).SequenceEqual((ReadOnlySpan<byte>)recovery.Applied))
		{
			return ((ReadOnlySpan<byte>)current.AsSpan()).SequenceEqual((ReadOnlySpan<byte>)recovery.BeforeApply);
		}
		return true;
	}

	private static byte[] Read(string path, int limit)
	{
		using FileStream fileStream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
		if (fileStream.Length > limit)
		{
			throw new InvalidDataException("Settings or recovery file exceeds the size limit.");
		}
		byte[] array = new byte[checked((int)fileStream.Length)];
		fileStream.ReadExactly(array);
		return array;
	}

	private static Recovery LoadRecovery(string target, string backup)
	{
		try
		{
			Recovery recovery = JsonSerializer.Deserialize<Recovery>(Read(backup, 20971520));
			if ((object)recovery == null || recovery.Version != 1 || !string.Equals(recovery.Target, target, OperatingSystem.IsWindows() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal) || recovery.Original == null || recovery.Applied == null || recovery.BeforeApply == null || recovery.Original.Length > 4194304 || recovery.Applied.Length > 4194304 || recovery.BeforeApply.Length > 4194304 || Hash(recovery.Original) != recovery.OriginalHash || Hash(recovery.Applied) != recovery.AppliedHash || Hash(recovery.BeforeApply) != recovery.BeforeApplyHash)
			{
				throw new InvalidDataException("Recovery record is invalid or belongs to another settings file.");
			}
			Properties(Parse(recovery.Original));
			Properties(Parse(recovery.Applied));
			Properties(Parse(recovery.BeforeApply));
			return recovery;
		}
		catch (JsonException innerException)
		{
			throw new InvalidDataException("Recovery record is corrupt; settings were not changed.", innerException);
		}
	}

	private static XDocument Parse(byte[] bytes)
	{
		try
		{
			using MemoryStream input = new MemoryStream(bytes, writable: false);
			using XmlReader reader = XmlReader.Create(input, new XmlReaderSettings
			{
				DtdProcessing = DtdProcessing.Prohibit,
				XmlResolver = null,
				MaxCharactersInDocument = 4194304L
			});
			XDocument xDocument = XDocument.Load(reader, LoadOptions.PreserveWhitespace);
			Properties(xDocument);
			return xDocument;
		}
		catch (XmlException innerException)
		{
			throw new InvalidDataException("Roblox settings XML is invalid; settings were not changed.", innerException);
		}
	}

	private static XElement Properties(XDocument document)
	{
		XElement[] array = document.Root?.Elements("Item").Where((XElement x) => (string?)x.Attribute("class") == "UserGameSettings").Elements("Properties")
			.ToArray();
		if (document.Root?.Name != "roblox" || array == null || array.Length != 1)
		{
			throw new InvalidDataException("Expected exactly one Roblox UserGameSettings properties block.");
		}
		return array[0];
	}

	private static void AtomicWrite(string path, byte[] bytes)
	{
		Directory.CreateDirectory(Path.GetDirectoryName(path));
		string text = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
		try
		{
			using (FileStream fileStream = new FileStream(text, FileMode.CreateNew, FileAccess.Write, FileShare.None))
			{
				fileStream.Write(bytes);
				fileStream.Flush(flushToDisk: true);
			}
			File.Move(text, path, overwrite: true);
		}
		finally
		{
			if (File.Exists(text))
			{
				File.Delete(text);
			}
		}
	}
}
