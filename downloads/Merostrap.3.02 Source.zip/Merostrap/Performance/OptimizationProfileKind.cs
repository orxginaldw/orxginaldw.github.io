namespace Merostrap.Performance;

internal enum OptimizationProfileKind
{
	Custom,
	Competitive,
	Balanced,
	Quality
}
