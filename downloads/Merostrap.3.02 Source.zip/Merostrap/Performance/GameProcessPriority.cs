using System;
using System.ComponentModel;
using System.Diagnostics;

namespace Merostrap.Performance;

internal static class GameProcessPriority
{
	public static bool ShouldRaise(ProcessPriorityClass priority)
	{
		if (priority == ProcessPriorityClass.Normal || priority == ProcessPriorityClass.Idle || priority == ProcessPriorityClass.BelowNormal)
		{
			return true;
		}
		return false;
	}

	public static string Apply(int processId, bool enabled)
	{
		if (!enabled)
		{
			return "Disabled";
		}
		if (!OperatingSystem.IsWindows())
		{
			return "Unsupported";
		}
		try
		{
			using Process process = Process.GetProcessById(processId);
			if (!ShouldRaise(process.PriorityClass))
			{
				return "Already elevated";
			}
			process.PriorityClass = ProcessPriorityClass.AboveNormal;
			return "Applied";
		}
		catch (Exception ex) when ((ex is Win32Exception || ex is InvalidOperationException || ex is ArgumentException || ex is NotSupportedException) ? true : false)
		{
			return "Unavailable (" + ex.GetType().Name + ")";
		}
	}
}
