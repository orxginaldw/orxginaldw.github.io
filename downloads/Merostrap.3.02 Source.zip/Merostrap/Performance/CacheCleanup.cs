using System;
using System.Collections.Generic;
using System.IO;

namespace Merostrap.Performance;

internal static class CacheCleanup
{
	public static CacheCleanupResult Clean(string directory, int? ageDays, DateTime utcNow)
	{
		if (!ageDays.HasValue)
		{
			return new CacheCleanupResult(0, 0, 0);
		}
		bool flag;
		if (ageDays.HasValue)
		{
			int valueOrDefault = ageDays.GetValueOrDefault();
			if (valueOrDefault < 1 || valueOrDefault > 3650)
			{
				flag = true;
				goto IL_003a;
			}
		}
		flag = false;
		goto IL_003a;
		IL_003a:
		if (flag)
		{
			throw new ArgumentOutOfRangeException("ageDays");
		}
		string text = Path.TrimEndingDirectorySeparator(Path.GetFullPath(directory));
		if (text == Path.GetPathRoot(text) || !Directory.Exists(text) || HasLinkedAncestor(text))
		{
			return new CacheCleanupResult(0, 0, 0);
		}
		DateTime dateTime = utcNow.ToUniversalTime().AddDays(-ageDays.Value);
		int num = 0;
		int num2 = 0;
		int num3 = 0;
		Stack<string> stack = new Stack<string>();
		stack.Push(text);
		while (stack.Count > 0 && num < 4000 && num2 < 200)
		{
			string path = stack.Pop();
			try
			{
				if (HasLinkedAncestor(path))
				{
					num3++;
					continue;
				}
				foreach (FileSystemInfo item in new DirectoryInfo(path).EnumerateFileSystemInfos())
				{
					if (num >= 4000 || num2 >= 200)
					{
						break;
					}
					num++;
					try
					{
						string fullPath = Path.GetFullPath(item.FullName);
						if (!fullPath.StartsWith(text + Path.DirectorySeparatorChar, OperatingSystem.IsWindows() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal) || (item.Attributes & FileAttributes.ReparsePoint) != 0 || HasLinkedAncestor(fullPath))
						{
							num3++;
							continue;
						}
						if ((item.Attributes & FileAttributes.Directory) != 0)
						{
							stack.Push(fullPath);
							continue;
						}
						if ((item.Attributes & FileAttributes.ReadOnly) != 0 || item.LastWriteTimeUtc >= dateTime || fullPath.EndsWith(".tmp", StringComparison.OrdinalIgnoreCase) || fullPath.EndsWith(".partial", StringComparison.OrdinalIgnoreCase))
						{
							num3++;
							continue;
						}
						using (new FileStream(fullPath, FileMode.Open, FileAccess.Read, FileShare.None))
						{
						}
						if (File.GetLastWriteTimeUtc(fullPath) >= dateTime || HasLinkedAncestor(fullPath))
						{
							num3++;
							continue;
						}
						File.Delete(fullPath);
						num2++;
					}
					catch (Exception ex) when ((ex is IOException || ex is UnauthorizedAccessException) ? true : false)
					{
						num3++;
					}
				}
			}
			catch (Exception ex2) when ((ex2 is IOException || ex2 is UnauthorizedAccessException) ? true : false)
			{
				num3++;
			}
		}
		return new CacheCleanupResult(num, num2, num3);
	}

	private static bool HasLinkedAncestor(string path)
	{
		for (string text = path; text != null; text = Path.GetDirectoryName(text))
		{
			if ((File.GetAttributes(text) & FileAttributes.ReparsePoint) != 0)
			{
				return true;
			}
		}
		return false;
	}
}
