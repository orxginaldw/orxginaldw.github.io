using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;

namespace Merostrap.Performance;

internal sealed record OptimizationProfilePreview(OptimizationProfileKind Profile, int? FrameCap, int GraphicsQuality, int? TextureQuality, bool QuietBackground, bool RaiseProcessPriority, IReadOnlyList<string> Explanations)
{
	public static OptimizationProfilePreview Create(OptimizationProfileKind profile, HardwareSnapshot hardware, CustomGraphicsChoices custom)
	{
		ArgumentNullException.ThrowIfNull(hardware, "hardware");
		ArgumentNullException.ThrowIfNull(custom, "custom");
		if (!Enum.IsDefined(profile))
		{
			throw new ArgumentOutOfRangeException("profile");
		}
		int graphicsQuality = custom.GraphicsQuality;
		if ((graphicsQuality < 0 || graphicsQuality > 10) ? true : false)
		{
			throw new ArgumentOutOfRangeException("custom");
		}
		if (profile == OptimizationProfileKind.Custom)
		{
			return new OptimizationProfilePreview(profile, custom.FrameCap, custom.GraphicsQuality, null, QuietBackground: false, RaiseProcessPriority: false, new _003C_003Ez__ReadOnlySingleElementList<string>("Custom settings are preserved; no automatic override is proposed."));
		}
		GraphicsAdapterObservation[] array = hardware.Adapters.Where((GraphicsAdapterObservation x) => x.Width > 0 && x.Height > 0).ToArray();
		int? num = ((array.Length == 1) ? array[0].RefreshHz : ((int?)null));
		graphicsQuality = 1;
		List<string> list = new List<string>(graphicsQuality);
		CollectionsMarshal.SetCount(list, graphicsQuality);
		CollectionsMarshal.AsSpan(list)[0] = "This is a proposed starting point, not a measured sustainable FPS or latency guarantee.";
		List<string> list2 = list;
		if (!num.HasValue)
		{
			list2.Add("No unambiguous active refresh observation; select a target FPS manually.");
		}
		else
		{
			list2.Add($"The adapter reports {num} Hz. Confirm the game's monitor before using this FPS target.");
		}
		int num2 = profile switch
		{
			OptimizationProfileKind.Competitive => 1, 
			OptimizationProfileKind.Balanced => 5, 
			_ => 10, 
		};
		int? textureQuality = profile switch
		{
			OptimizationProfileKind.Competitive => (int?)0, 
			OptimizationProfileKind.Balanced => 1, 
			_ => null, 
		};
		if (profile == OptimizationProfileKind.Balanced)
		{
			long? totalMemoryBytes = hardware.TotalMemoryBytes;
			if (totalMemoryBytes.HasValue)
			{
				long valueOrDefault = totalMemoryBytes.GetValueOrDefault();
				if (valueOrDefault > 0 && valueOrDefault < 8589934592L)
				{
					textureQuality = 0;
					list2.Add("Less than 8 GiB usable RAM: suggest lowest texture detail to reduce asset memory demand; image detail is reduced. This does not measure GPU memory pressure.");
				}
			}
		}
		list2.Add($"Graphics level {num2} trades visual detail against rendering work; test in the same game scene.");
		list2.Add("No forced renderer, CPU affinity, timer, registry, or networking changes. Process priority remains opt-in.");
		bool flag = (uint)(profile - 1) <= 1u;
		bool flag2 = flag;
		if (flag2)
		{
			list2.Add("Avoid optional background downloads; integration feature choices must remain explicit when this preview is applied.");
		}
		return new OptimizationProfilePreview(profile, num, num2, textureQuality, flag2, RaiseProcessPriority: false, list2.AsReadOnly());
	}
}
