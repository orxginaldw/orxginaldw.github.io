using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;

namespace Merostrap.Performance;

internal sealed record HardwareSnapshot(IReadOnlyList<string> CpuNames, int? LogicalProcessors, long? TotalMemoryBytes, long? AvailableMemoryBytes, IReadOnlyList<GraphicsAdapterObservation> Adapters, IReadOnlyList<string> Warnings)
{
	private sealed record RawHardware(string[]? CpuNames, int? LogicalProcessors, long? TotalMemoryKiB, long? AvailableMemoryKiB, RawAdapter?[]? Adapters, string[]? Warnings);

	private sealed record RawAdapter(string? Name, string? DriverVersion, int? RefreshHz, int? Width, int? Height);

	public static HardwareSnapshot Unknown(string reason)
	{
		return new HardwareSnapshot(Array.Empty<string>(), null, null, null, Array.Empty<GraphicsAdapterObservation>(), new _003C_003Ez__ReadOnlySingleElementList<string>(reason));
	}

	public static HardwareSnapshot ParseWindowsJson(string json)
	{
		RawHardware rawHardware = JsonSerializer.Deserialize<RawHardware>(json) ?? throw new JsonException("Missing hardware report.");
		List<string> list = new List<string>(rawHardware.Warnings ?? Array.Empty<string>());
		long? num = Bytes(rawHardware.TotalMemoryKiB);
		long? num2 = ((rawHardware.AvailableMemoryKiB == 0) ? new long?(0L) : Bytes(rawHardware.AvailableMemoryKiB));
		if (num2 > num)
		{
			num2 = null;
			list.Add("Available RAM exceeded total RAM; observation discarded.");
		}
		string[] array = (rawHardware.CpuNames ?? Array.Empty<string>()).Where((string x) => !string.IsNullOrWhiteSpace(x)).ToArray();
		int? logicalProcessors = rawHardware.LogicalProcessors;
		int? logicalProcessors2 = ((logicalProcessors.HasValue && logicalProcessors.GetValueOrDefault() > 0) ? rawHardware.LogicalProcessors : ((int?)null));
		GraphicsAdapterObservation[] array2 = (rawHardware.Adapters ?? Array.Empty<RawAdapter>()).Where((RawAdapter x) => (object)x != null).Select((RawAdapter x) =>
		{
			string? name = (string.IsNullOrWhiteSpace(x.Name) ? "Unknown adapter" : x.Name);
			string? driverVersion = x.DriverVersion;
			int? refreshHz = x.RefreshHz;
			int? refreshHz2;
			if (refreshHz.HasValue)
			{
				int valueOrDefault = refreshHz.GetValueOrDefault();
				if (valueOrDefault > 1 && valueOrDefault <= 2000)
				{
					refreshHz2 = x.RefreshHz;
					goto IL_0055;
				}
			}
			refreshHz2 = null;
			goto IL_0055;
			IL_0055:
			refreshHz = x.Width;
			int? width = ((refreshHz.HasValue && refreshHz.GetValueOrDefault() > 0) ? x.Width : ((int?)null));
			refreshHz = x.Height;
			return new GraphicsAdapterObservation(name, driverVersion, refreshHz2, width, (refreshHz.HasValue && refreshHz.GetValueOrDefault() > 0) ? x.Height : ((int?)null));
		}).ToArray();
		if (array.Length == 0 || !logicalProcessors2.HasValue)
		{
			list.Add("CPU details are incomplete.");
		}
		if (!num.HasValue || !num2.HasValue)
		{
			list.Add("RAM observations are incomplete.");
		}
		if (array2.Length == 0)
		{
			list.Add("Graphics adapters were not detected.");
		}
		list.Add("Adapter modes do not identify Roblox's selected monitor or variable refresh capability. VRAM is not inferred from WMI AdapterRAM.");
		return new HardwareSnapshot(array, logicalProcessors2, num, num2, array2, list.AsReadOnly());
		static long? Bytes(long? kib)
		{
			if (kib.HasValue)
			{
				long valueOrDefault = kib.GetValueOrDefault();
				if (valueOrDefault > 0 && valueOrDefault <= 9007199254740991L)
				{
					return kib * 1024;
				}
			}
			return null;
		}
	}
}
