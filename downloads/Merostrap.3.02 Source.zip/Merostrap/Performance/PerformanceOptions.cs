using System;
using System.Text.Json.Serialization;

namespace Merostrap.Performance;

internal sealed class PerformanceOptions : IJsonOnDeserialized
{
	public bool Enabled { get; set; }

	public OptimizationProfileKind? Profile { get; set; }

	public int? ProfileFrameCap { get; set; }

	public int? UserFrameCap { get; set; }

	public bool? LeanSession { get; set; }

	public bool SmallMemoryTextureProfile { get; set; }

	[JsonIgnore]
	public bool HasNamedProfile
	{
		get
		{
			OptimizationProfileKind? profile = Profile;
			if (profile.HasValue)
			{
				OptimizationProfileKind valueOrDefault = profile.GetValueOrDefault();
				if ((uint)(valueOrDefault - 1) <= 2u)
				{
					return true;
				}
			}
			return false;
		}
	}

	[JsonIgnore]
	public bool UseLegacyPerformance
	{
		get
		{
			if (!Profile.HasValue)
			{
				return Enabled;
			}
			return false;
		}
	}

	[JsonIgnore]
	public bool UseLeanRuntime => LeanSession ?? UseLegacyPerformance;

	[JsonIgnore]
	public OptimizationProfileKind EffectiveProfile
	{
		get
		{
			OptimizationProfileKind? profile = Profile;
			if (profile.HasValue)
			{
				OptimizationProfileKind valueOrDefault = profile.GetValueOrDefault();
				if (!Enum.IsDefined(valueOrDefault))
				{
					return OptimizationProfileKind.Custom;
				}
				return valueOrDefault;
			}
			if (!Enabled)
			{
				return OptimizationProfileKind.Custom;
			}
			return OptimizationProfileKind.Competitive;
		}
	}

	public bool NetworkMode { get; set; }

	public bool LowerRenderQuality { get; set; }

	public bool PrioritizeGameCpu { get; set; } = true;

	[JsonIgnore]
	public bool UseLowRenderQuality
	{
		get
		{
			if (!HasNamedProfile)
			{
				if (!UseLegacyPerformance)
				{
					return LowerRenderQuality;
				}
				return true;
			}
			return false;
		}
	}

	[JsonIgnore]
	public bool UseGameCpuPriority
	{
		get
		{
			if (UseLeanRuntime)
			{
				return PrioritizeGameCpu;
			}
			return false;
		}
	}

	public bool LowTextures { get; set; }

	public bool ReduceGrass { get; set; }

	public bool NoShadows { get; set; }

	public bool ReduceAntiAliasing { get; set; }

	public bool AvoidBackgroundDownloads { get; set; }

	public bool ReduceAnimations { get; set; }

	[JsonIgnore]
	public bool UseLowTextures
	{
		get
		{
			if (!HasNamedProfile)
			{
				if (!UseLegacyPerformance)
				{
					return LowTextures;
				}
				return true;
			}
			return false;
		}
	}

	[JsonIgnore]
	public bool UseReducedGrass
	{
		get
		{
			if (!HasNamedProfile)
			{
				if (!UseLegacyPerformance)
				{
					return ReduceGrass;
				}
				return true;
			}
			return false;
		}
	}

	[JsonIgnore]
	public bool UseReducedAntiAliasing
	{
		get
		{
			if (!HasNamedProfile)
			{
				if (!UseLegacyPerformance)
				{
					return ReduceAntiAliasing;
				}
				return true;
			}
			return false;
		}
	}

	[JsonIgnore]
	public bool UseQuietDownloads
	{
		get
		{
			bool flag = UseLegacyPerformance;
			bool flag2;
			if (!flag)
			{
				OptimizationProfileKind? profile = Profile;
				if (profile.HasValue)
				{
					OptimizationProfileKind valueOrDefault = profile.GetValueOrDefault();
					if ((uint)(valueOrDefault - 1) <= 1u)
					{
						flag2 = true;
						goto IL_002e;
					}
				}
				flag2 = false;
				goto IL_002e;
			}
			goto IL_0030;
			IL_0030:
			if (!flag && !NetworkMode)
			{
				return AvoidBackgroundDownloads;
			}
			return true;
			IL_002e:
			flag = flag2;
			goto IL_0030;
		}
	}

	[JsonIgnore]
	public bool UseReducedAnimations
	{
		get
		{
			if (!UseLegacyPerformance)
			{
				return ReduceAnimations;
			}
			return true;
		}
	}

	[JsonIgnore]
	public bool HasGraphicsOverrides
	{
		get
		{
			if (!HasNamedProfile && !UseLowRenderQuality && !UseLowTextures && !UseReducedGrass && !UseReducedAntiAliasing)
			{
				return NoShadows;
			}
			return true;
		}
	}

	void IJsonOnDeserialized.OnDeserialized()
	{
		ProfileFrameCap = null;
	}

	public PerformanceOptions ForGraphicsTarget(bool supportsNamedProfiles)
	{
		if (!HasNamedProfile || supportsNamedProfiles)
		{
			return this;
		}
		return new PerformanceOptions
		{
			NoShadows = NoShadows
		};
	}
}
