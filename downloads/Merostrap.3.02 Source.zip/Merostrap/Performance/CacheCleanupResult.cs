namespace Merostrap.Performance;

internal sealed record CacheCleanupResult(int Scanned, int Deleted, int Skipped);
