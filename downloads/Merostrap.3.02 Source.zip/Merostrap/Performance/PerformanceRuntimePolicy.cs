namespace Merostrap.Performance;

internal sealed record PerformanceRuntimePolicy(bool TrackActivity, bool StartWatcher, bool WaitForLog)
{
	public static bool ShouldScheduleCrashCleanup(bool performanceMode, bool isPlayer, bool autoCloseEnabled)
	{
		return !performanceMode & isPlayer & autoCloseEnabled;
	}

	public static PerformanceRuntimePolicy Create(bool performanceMode, bool activityTracking, bool testMode, int cleanupProcessCount)
	{
		bool flag = activityTracking && !performanceMode;
		return new PerformanceRuntimePolicy(flag, (flag | testMode) || cleanupProcessCount > 0, flag);
	}
}
