using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;

namespace Merostrap.Performance;

internal static class PerformanceProfile
{
	public static Dictionary<string, object> Merge(IReadOnlyDictionary<string, object> source, PerformanceOptions options)
	{
		Dictionary<string, object> dictionary = new Dictionary<string, object>(source, StringComparer.Ordinal);
		if (options.NoShadows)
		{
			dictionary["DFFlagDebugPauseVoxelizer"] = "True";
			dictionary["FIntRenderShadowIntensity"] = "0";
		}
		bool flag;
		if (options.HasNamedProfile)
		{
			string[] array = new string[10] { "DFIntDebugFRMQualityLevelOverride", "DFFlagTextureQualityOverrideEnabled", "DFIntTextureQualityOverride", "FIntDebugForceMSAASamples", "FIntFRMMinGrassDistance", "FIntFRMMaxGrassDistance", "DFIntCSGLevelOfDetailSwitchingDistance", "DFIntCSGLevelOfDetailSwitchingDistanceL12", "DFIntCSGLevelOfDetailSwitchingDistanceL23", "DFIntCSGLevelOfDetailSwitchingDistanceL34" };
			foreach (string key in array)
			{
				dictionary.Remove(key);
			}
			OptimizationProfileKind? profile = options.Profile;
			if (profile.HasValue)
			{
				OptimizationProfileKind valueOrDefault = profile.GetValueOrDefault();
				if ((uint)(valueOrDefault - 1) <= 1u)
				{
					flag = true;
					goto IL_00db;
				}
			}
			flag = false;
			goto IL_00db;
		}
		if (options.UseLowRenderQuality)
		{
			dictionary["DFIntDebugFRMQualityLevelOverride"] = "1";
		}
		if (options.UseLowTextures)
		{
			dictionary["DFFlagTextureQualityOverrideEnabled"] = "True";
			dictionary["DFIntTextureQualityOverride"] = (options.UseLegacyPerformance ? "0" : "1");
		}
		if (options.UseReducedGrass)
		{
			dictionary["FIntFRMMinGrassDistance"] = "0";
			dictionary["FIntFRMMaxGrassDistance"] = "0";
		}
		if (options.UseReducedAntiAliasing)
		{
			dictionary["FIntDebugForceMSAASamples"] = "1";
		}
		if (options.UseLegacyPerformance)
		{
			dictionary["DFIntCSGLevelOfDetailSwitchingDistance"] = "250";
			dictionary["DFIntCSGLevelOfDetailSwitchingDistanceL12"] = "125";
			dictionary["DFIntCSGLevelOfDetailSwitchingDistanceL23"] = "60";
			dictionary["DFIntCSGLevelOfDetailSwitchingDistanceL34"] = "30";
		}
		return dictionary;
		IL_00db:
		if (flag)
		{
			dictionary["DFFlagTextureQualityOverrideEnabled"] = "True";
			dictionary["DFIntTextureQualityOverride"] = ((options.Profile == OptimizationProfileKind.Competitive || options.SmallMemoryTextureProfile) ? "0" : "1");
		}
		if (options.Profile == OptimizationProfileKind.Competitive)
		{
			dictionary["FIntFRMMinGrassDistance"] = "0";
			dictionary["FIntFRMMaxGrassDistance"] = "0";
			dictionary["FIntDebugForceMSAASamples"] = "1";
		}
		return dictionary;
	}

	public static async Task WriteAsync(string? sourcePath, string destinationPath, PerformanceOptions options)
	{
		Dictionary<string, object> source = new Dictionary<string, object>();
		if (sourcePath != null && File.Exists(sourcePath))
		{
			source = JsonSerializer.Deserialize<Dictionary<string, object>>(await File.ReadAllTextAsync(sourcePath)) ?? throw new InvalidDataException("The graphics profile is invalid.");
		}
		string json = JsonSerializer.Serialize(Merge(source, options));
		bool flag = File.Exists(destinationPath);
		if (flag)
		{
			flag = await File.ReadAllTextAsync(destinationPath) == json;
		}
		if (flag)
		{
			return;
		}
		Directory.CreateDirectory(Path.GetDirectoryName(destinationPath));
		string temporary = destinationPath + "." + Guid.NewGuid().ToString("N") + ".tmp";
		try
		{
			await File.WriteAllTextAsync(temporary, json);
			File.Move(temporary, destinationPath, overwrite: true);
		}
		finally
		{
			if (File.Exists(temporary))
			{
				File.Delete(temporary);
			}
		}
	}
}
