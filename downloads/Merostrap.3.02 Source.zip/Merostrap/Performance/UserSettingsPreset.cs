using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using Merostrap.Models.Persistable;

namespace Merostrap.Performance;

internal sealed class UserSettingsPreset
{
	public string Name { get; set; } = "";

	public ProfileGame? Game { get; set; }

	public PerformanceOptions Performance { get; set; } = new PerformanceOptions();

	public bool PreferNearbyServers { get; set; }

	public int FrameCap { get; set; } = 60;

	public Dictionary<string, string>? FastFlags { get; set; }

	public string? RobloxSettings { get; set; }

	public static UserSettingsPreset Capture(string name)
	{
		int result;
		return new UserSettingsPreset
		{
			Name = name,
			Performance = Copy(App.Settings.Prop.Performance),
			PreferNearbyServers = App.Settings.Prop.EnableBetterMatchmaking,
			FrameCap = (App.Settings.Prop.Performance.UserFrameCap ?? (int.TryParse(App.GlobalSettings.GetPreset("Rendering.FramerateCap"), out result) ? Math.Max(0, result) : 60)),
			FastFlags = App.FastFlags.Prop.ToDictionary((KeyValuePair<string, object> p) => p.Key, (KeyValuePair<string, object> p) => p.Value?.ToString() ?? ""),
			RobloxSettings = ((!App.GlobalSettings.Loaded) ? null : App.GlobalSettings.Document?.ToString())
		};
	}

	public void Apply()
	{
		if (RobloxSettings != null)
		{
			App.GlobalSettings.ApplyProfile(RobloxSettings);
		}
		App.Settings.Prop.Performance = Copy(Performance);
		App.Settings.Prop.Performance.UserFrameCap = FrameCap;
		App.Settings.Prop.EnableBetterMatchmaking = PreferNearbyServers;
		if (FastFlags != null)
		{
			App.FastFlags.SaveUndoSnapshot();
			App.FastFlags.Prop = ((IEnumerable<KeyValuePair<string, string>>)FastFlags).ToDictionary((Func<KeyValuePair<string, string>, string>)((KeyValuePair<string, string> p) => p.Key), (Func<KeyValuePair<string, string>, object>)((KeyValuePair<string, string> p) => p.Value));
		}
	}

	public static void SaveActive()
	{
		Settings settings = App.Settings.Prop;
		int num = settings.SettingsPresets.FindIndex((UserSettingsPreset p) => p.Name == settings.ActiveSettingsPreset);
		if (num >= 0)
		{
			UserSettingsPreset userSettingsPreset = settings.SettingsPresets[num];
			UserSettingsPreset userSettingsPreset2 = Capture(userSettingsPreset.Name);
			userSettingsPreset2.Game = userSettingsPreset.Game;
			settings.SettingsPresets[num] = userSettingsPreset2;
		}
	}

	public static PerformanceOptions Copy(PerformanceOptions options)
	{
		return JsonSerializer.Deserialize<PerformanceOptions>(JsonSerializer.Serialize(options));
	}
}
