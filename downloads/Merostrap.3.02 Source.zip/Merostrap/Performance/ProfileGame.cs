namespace Merostrap.Performance;

internal sealed class ProfileGame
{
	public ulong UniverseId { get; set; }

	public long PlaceId { get; set; }

	public string Name { get; set; } = "";

	public string? IconBase64 { get; set; }
}
