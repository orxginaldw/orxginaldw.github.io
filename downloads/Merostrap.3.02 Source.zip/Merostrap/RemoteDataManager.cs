using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Security;
using System.Text.Json;
using System.Threading.Tasks;
using Merostrap.Enums;
using Merostrap.Models.APIs.Config;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Crypto.Signers;

namespace Merostrap;

internal class RemoteDataManager : JsonManager<RemoteDataBase>
{
	public GenericTriState LoadedState = GenericTriState.Unknown;

	private const int Ed25519PublicKeyLength = 32;

	private const int Ed25519SignatureLength = 64;

	private const string ConfigPublicKeyBase64 = "frqqb5rEBhsU5pMkPQDQYwM3FyEmJWWIQWsVKztwzrI=";

	private static readonly byte[] ConfigPublicKey = Convert.FromBase64String("frqqb5rEBhsU5pMkPQDQYwM3FyEmJWWIQWsVKztwzrI=");

	public override string ClassName => "RemoteDataManager";

	public override string FileLocation => Path.Combine(Paths.Base, "Data.json");

	private string SignatureFileLocation => FileLocation + ".sig";

	public event EventHandler DataLoaded;

	public void Subscribe(EventHandler Handler)
	{
		switch (LoadedState)
		{
		case GenericTriState.Unknown:
			DataLoaded += Handler;
			break;
		case GenericTriState.Successful:
			Handler(this, EventArgs.Empty);
			break;
		default:
			Handler(this, EventArgs.Empty);
			break;
		}
	}

	public async Task WaitUntilDataFetched()
	{
		int tries = 0;
		while (LoadedState == GenericTriState.Unknown)
		{
			await Task.Delay(100);
			tries++;
			if (tries >= 30)
			{
				break;
			}
		}
	}

	public async Task LoadData()
	{
		if (string.IsNullOrWhiteSpace(""))
		{
			LoadedState = GenericTriState.Successful;
			DataLoaded?.Invoke(this, EventArgs.Empty);
			return;
		}
		if (App.Settings.Prop.ForceLocalData || App.LaunchSettings.WatcherFlag.Active)
		{
			App.Logger.Info("Force loading local data");
			LoadLocalVerifiedData();
			LoadedState = GenericTriState.Successful;
		}
		else
		{
			try
			{
				Uri requestUri = new Uri("");
				Uri requestUri2 = new Uri(".sig");
				App.Logger.Info("Fetching remote Data.json and signature...");
				Task<byte[]> dataTask = App.HttpClient.GetByteArrayAsync(requestUri);
				Task<byte[]> sigTask = App.HttpClient.GetByteArrayAsync(requestUri2);
				InlineArray2<Task<byte[]>> buffer = default;
				buffer[0] = dataTask;
				buffer[1] = sigTask;
				await Task.WhenAll<byte[]>(buffer);
				byte[] dataBytes = await dataTask;
				byte[] array = await sigTask;
				if (array.Length != 64 || !VerifyEd25519(dataBytes, array, ConfigPublicKey))
				{
					throw new SecurityException("Remote Data.json signature verification failed!");
				}
				App.Logger.Info("Remote Data.json signature verified successfully.");
				Prop = JsonSerializer.Deserialize<RemoteDataBase>(dataBytes) ?? throw new JsonException("Deserialized remote data was null.");
				LoadedState = GenericTriState.Successful;
				App.Logger.Info("Remote data loaded");
				SaveLocalVerifiedData(dataBytes, array);
			}
			catch (Exception ex)
			{
				App.Logger.Error("Could not load remote data: " + ex.Message);
				App.Logger.Info("Attempting to load verified local cache instead...");
				bool flag = LoadLocalVerifiedData();
				LoadedState = ((!flag) ? GenericTriState.Failed : GenericTriState.Successful);
			}
		}
		DataLoaded?.Invoke(this, EventArgs.Empty);
		App.Logger.Info($"Loading finished with status: {LoadedState}");
	}

	private void SaveLocalVerifiedData(byte[] dataBytes, byte[] sigBytes)
	{
		try
		{
			File.WriteAllBytes(FileLocation, dataBytes);
			File.WriteAllBytes(SignatureFileLocation, sigBytes);
			App.Logger.Info("Saved verified Data.json and Data.json.sig to local cache.");
		}
		catch (Exception ex)
		{
			App.Logger.Warn("Failed to save local cache: " + ex.Message);
		}
	}

	private bool LoadLocalVerifiedData()
	{
		if (!File.Exists(FileLocation) || !File.Exists(SignatureFileLocation))
		{
			App.Logger.Info("No complete local cache found. Loading default local config.");
			Load(alertFailure: false);
			return false;
		}
		try
		{
			byte[] array = File.ReadAllBytes(FileLocation);
			byte[] array2 = File.ReadAllBytes(SignatureFileLocation);
			if (array2.Length != 64 || !VerifyEd25519(array, array2, ConfigPublicKey))
			{
				App.Logger.Error("LOCAL DISK CACHE TAMPERED! Signature check failed for local Data.json.");
				File.Delete(FileLocation);
				File.Delete(SignatureFileLocation);
				Load(alertFailure: false);
				return false;
			}
			Prop = JsonSerializer.Deserialize<RemoteDataBase>(array);
			App.Logger.Info("Successfully verified and loaded local Data.json cache from disk.");
			return true;
		}
		catch (Exception ex)
		{
			App.Logger.Error("Error reading local cache: " + ex.Message);
			Load(alertFailure: false);
			return false;
		}
	}

	private static bool VerifyEd25519(byte[] data, byte[] signature, byte[] publicKey)
	{
		if (data == null || signature == null || publicKey == null)
		{
			return false;
		}
		if (signature.Length != 64 || publicKey.Length != 32)
		{
			return false;
		}
		try
		{
			Ed25519PublicKeyParameters parameters = new Ed25519PublicKeyParameters(publicKey, 0);
			Ed25519Signer ed25519Signer = new Ed25519Signer();
			ed25519Signer.Init(forSigning: false, parameters);
			ed25519Signer.BlockUpdate(data, 0, data.Length);
			return ed25519Signer.VerifySignature(signature);
		}
		catch
		{
			return false;
		}
	}

	public RemoteDataManager()
		: base((string?)null)
	{
	}
}
