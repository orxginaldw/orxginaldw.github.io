using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Merostrap.Enums;
using Merostrap.Models;

namespace Merostrap;

internal class LaunchSettings
{
	private static readonly HashSet<string> StudioFileExtensions = new HashSet<string>(new _003C_003Ez__ReadOnlyArray<string>(new string[4] { ".rbxl", ".rbxlx", ".rbxm", ".rbxmx" }), StringComparer.OrdinalIgnoreCase);

	private readonly Dictionary<string, LaunchFlag> _flagLookup;

	private (LaunchMode Mode, string Args)? _resolvedRoblox;

	public LaunchFlag MenuFlag { get; } = new LaunchFlag("preferences,menu,settings");

	public LaunchFlag WatcherFlag { get; } = new LaunchFlag("watcher");

	public LaunchFlag MultiInstanceWatcherFlag { get; } = new LaunchFlag("multiinstancewatcher");

	public LaunchFlag BackgroundUpdaterFlag { get; } = new LaunchFlag("backgroundupdater");

	public LaunchFlag OnboardingFlag { get; } = new LaunchFlag("onboarding");

	public LaunchFlag QuietFlag { get; } = new LaunchFlag("quiet");

	public LaunchFlag NoLaunchFlag { get; } = new LaunchFlag("nolaunch");

	public LaunchFlag TestModeFlag { get; } = new LaunchFlag("testmode");

	public LaunchFlag UpgradeFlag { get; } = new LaunchFlag("upgrade");

	public LaunchFlag PlayerFlag { get; } = new LaunchFlag("p,player");

	public LaunchFlag StudioFlag { get; } = new LaunchFlag("s,studio");

	public LaunchFlag VersionFlag { get; } = new LaunchFlag("version");

	public LaunchFlag ChannelFlag { get; } = new LaunchFlag("channel");

	public LaunchFlag ForceFlag { get; } = new LaunchFlag("force");

	public LaunchFlag GameShortcutFlag { get; } = new LaunchFlag("gameshortcut");

	public LaunchFlag ConsoleFlag { get; } = new LaunchFlag("c,console");

	public LaunchFlag NoGpuFlag { get; } = new LaunchFlag("g,nogpu");

	public bool BypassUpdateCheck
	{
		get
		{
			if (!WatcherFlag.Active)
			{
				return BackgroundUpdaterFlag.Active;
			}
			return true;
		}
	}

	public LaunchMode RobloxLaunchMode { get; set; }

	public string RobloxLaunchArgs { get; set; } = "";

	public string[] Args { get; private set; }

	private static bool IsRobloxStudioFile(string path)
	{
		if (string.IsNullOrEmpty(path))
		{
			return false;
		}
		try
		{
			string extension = Path.GetExtension(path);
			return StudioFileExtensions.Contains(extension);
		}
		catch
		{
			return false;
		}
	}

	private Dictionary<string, LaunchFlag> BuildFlagLookup()
	{
		LaunchFlag[] array = new LaunchFlag[17]
		{
			MenuFlag, WatcherFlag, MultiInstanceWatcherFlag, BackgroundUpdaterFlag, OnboardingFlag, QuietFlag, NoLaunchFlag, TestModeFlag, UpgradeFlag, PlayerFlag,
			StudioFlag, VersionFlag, ChannelFlag, ForceFlag, GameShortcutFlag, ConsoleFlag, NoGpuFlag
		};
		Dictionary<string, LaunchFlag> dictionary = new Dictionary<string, LaunchFlag>(StringComparer.OrdinalIgnoreCase);
		LaunchFlag[] array2 = array;
		foreach (LaunchFlag launchFlag in array2)
		{
			string[] array3 = launchFlag.Identifiers.Split(',');
			foreach (string key in array3)
			{
				dictionary[key] = launchFlag;
			}
		}
		return dictionary;
	}

	private LaunchFlag? GetFlag(string identifier)
	{
		if (!_flagLookup.TryGetValue(identifier, out LaunchFlag value))
		{
			return null;
		}
		return value;
	}

	public LaunchSettings(string[] args)
	{
		_flagLookup = BuildFlagLookup();
		Args = args;
		int num = 0;
		if (Args.Length >= 1 && ShouldSkipHostArgument(Args[0]))
		{
			num = 1;
		}
		if (Args.Length > num)
		{
			string text = Args[num];
			if (text.StartsWith("roblox:", StringComparison.OrdinalIgnoreCase) || text.StartsWith("roblox-player:", StringComparison.OrdinalIgnoreCase))
			{
				App.Logger.Info("Got Roblox player argument");
				RobloxLaunchMode = LaunchMode.Player;
				RobloxLaunchArgs = text;
				num++;
			}
			else if (text.StartsWith("roblox-studio-auth:", StringComparison.OrdinalIgnoreCase))
			{
				App.Logger.Info("Got Roblox Studio Auth argument");
				RobloxLaunchMode = LaunchMode.StudioAuth;
				RobloxLaunchArgs = text;
				num++;
			}
			else if (text.StartsWith("roblox-studio:", StringComparison.OrdinalIgnoreCase))
			{
				App.Logger.Info("Got Roblox Studio argument");
				RobloxLaunchMode = LaunchMode.Studio;
				RobloxLaunchArgs = text;
				num++;
			}
			else if (text.StartsWith("version-", StringComparison.Ordinal))
			{
				App.Logger.Info("Got version argument");
				VersionFlag.Active = true;
				VersionFlag.Data = text;
				num++;
			}
			else if (IsRobloxStudioFile(text))
			{
				App.Logger.Info("Got Roblox Studio file argument");
				RobloxLaunchMode = LaunchMode.Studio;
				RobloxLaunchArgs = "-task EditFile -localPlaceFile \"" + text + "\"";
				num++;
			}
		}
		for (int i = num; i < Args.Length; i++)
		{
			string text2 = Args[i];
			if (!text2.StartsWith('-'))
			{
				App.Logger.Error("Invalid argument: " + text2);
				continue;
			}
			string text3 = text2.TrimStart('-');
			LaunchFlag flag = GetFlag(text3);
			if (flag == null)
			{
				App.Logger.Warn("Unknown argument: " + text3);
				continue;
			}
			if (flag.Active)
			{
				App.Logger.Error("Tried to set " + text3 + " flag twice");
				continue;
			}
			flag.Active = true;
			if (i < Args.Length - 1)
			{
				string text4 = Args[i + 1];
				if (text4 != null && !text4.StartsWith('-'))
				{
					flag.Data = text4;
					i++;
					App.Logger.Info("Identifier '" + text3 + "' is active with data");
					continue;
				}
			}
			App.Logger.Info("Identifier '" + text3 + "' is active");
		}
		if (VersionFlag.Active)
		{
			RobloxLaunchMode = LaunchMode.Unknown;
		}
		if (PlayerFlag.Active)
		{
			ParsePlayer(PlayerFlag.Data);
		}
		else if (StudioFlag.Active)
		{
			ParseStudio(StudioFlag.Data);
		}
		if (GameShortcutFlag.Active && !string.IsNullOrEmpty(GameShortcutFlag.Data))
		{
			ParseGameShortcut(GameShortcutFlag.Data);
		}
		if (RobloxLaunchMode == LaunchMode.None)
		{
			TryResolveRobloxUri();
		}
	}

	public bool TryResolveRobloxUri(IEnumerable<string>? args = null)
	{
		if (args == null && _resolvedRoblox.HasValue)
		{
			RobloxLaunchMode = _resolvedRoblox.Value.Mode;
			RobloxLaunchArgs = _resolvedRoblox.Value.Args;
			return true;
		}
		foreach (string item in args ?? Args)
		{
			if (item.StartsWith("roblox:", StringComparison.OrdinalIgnoreCase) || item.StartsWith("roblox-player:", StringComparison.OrdinalIgnoreCase))
			{
				App.Logger.Info("Found Roblox player URI outside first argument");
				RobloxLaunchMode = LaunchMode.Player;
				RobloxLaunchArgs = item;
				_resolvedRoblox = (RobloxLaunchMode, RobloxLaunchArgs);
				return true;
			}
			if (item.StartsWith("roblox-studio-auth:", StringComparison.OrdinalIgnoreCase))
			{
				App.Logger.Info("Found Roblox Studio Auth URI outside first argument");
				RobloxLaunchMode = LaunchMode.StudioAuth;
				RobloxLaunchArgs = item;
				_resolvedRoblox = (RobloxLaunchMode, RobloxLaunchArgs);
				return true;
			}
			if (item.StartsWith("roblox-studio:", StringComparison.OrdinalIgnoreCase))
			{
				App.Logger.Info("Found Roblox Studio URI outside first argument");
				RobloxLaunchMode = LaunchMode.Studio;
				RobloxLaunchArgs = item;
				_resolvedRoblox = (RobloxLaunchMode, RobloxLaunchArgs);
				return true;
			}
		}
		return false;
	}

	private static bool ShouldSkipHostArgument(string arg)
	{
		if (string.IsNullOrWhiteSpace(arg))
		{
			return false;
		}
		if (arg.EndsWith(".dll", StringComparison.OrdinalIgnoreCase))
		{
			return true;
		}
		string processPath = Environment.ProcessPath;
		if (!string.IsNullOrEmpty(processPath) && string.Equals(arg, processPath, StringComparison.OrdinalIgnoreCase))
		{
			return true;
		}
		string text = Environment.GetCommandLineArgs().FirstOrDefault();
		if (!string.IsNullOrEmpty(text) && string.Equals(arg, text, StringComparison.OrdinalIgnoreCase))
		{
			return true;
		}
		return false;
	}

	private void ParsePlayer(string? data)
	{
		RobloxLaunchMode = LaunchMode.Player;
		if (!string.IsNullOrEmpty(data))
		{
			App.Logger.Info("Got Roblox launch arguments");
			RobloxLaunchArgs = data;
		}
		else
		{
			App.Logger.Error("No Roblox launch arguments were provided");
		}
	}

	private void ParseStudio(string? data)
	{
		RobloxLaunchMode = LaunchMode.Studio;
		if (string.IsNullOrEmpty(data))
		{
			App.Logger.Error("No Roblox launch arguments were provided");
		}
		else if (data.StartsWith("roblox-studio:", StringComparison.Ordinal))
		{
			App.Logger.Info("Got Roblox Studio launch arguments");
			RobloxLaunchArgs = data;
		}
		else if (data.StartsWith("roblox-studio-auth:", StringComparison.Ordinal))
		{
			App.Logger.Info("Got Roblox Studio Auth launch arguments");
			RobloxLaunchMode = LaunchMode.StudioAuth;
			RobloxLaunchArgs = data;
		}
		else
		{
			App.Logger.Info("Got Roblox Studio local place file");
			RobloxLaunchArgs = "-task EditFile -localPlaceFile \"" + data + "\"";
		}
	}

	private void ParseGameShortcut(string data)
	{
		string[] array = data.Split(';');
		if (array.Length < 1)
		{
			App.Logger.Error("Insufficient data for game shortcut");
			return;
		}
		string text = array[0];
		string text2 = ((array.Length > 1) ? array[1] : "");
		string text3 = ((array.Length > 2) ? array[2] : "");
		string text4 = "roblox://experiences/start?placeId=" + text;
		if (!string.IsNullOrEmpty(text3))
		{
			text4 = text4 + "&accessCode=" + text3;
		}
		else if (!string.IsNullOrEmpty(text2))
		{
			text4 = text4 + "&gameInstanceId=" + text2;
		}
		App.Logger.Info("Generated shortcut deeplink: " + text4);
		RobloxLaunchMode = LaunchMode.Player;
		RobloxLaunchArgs = text4;
	}
}
