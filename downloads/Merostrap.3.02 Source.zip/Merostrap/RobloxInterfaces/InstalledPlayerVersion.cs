using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Merostrap.RobloxInterfaces;

internal sealed record InstalledPlayerVersion(string VersionGuid, Version Version)
{
	public static bool IsUnavailable(Exception error)
	{
		if (!(error is TaskCanceledException))
		{
			if (error is HttpRequestException { StatusCode: var statusCode } ex)
			{
				return !statusCode.HasValue || ex.StatusCode.Value >= HttpStatusCode.InternalServerError;
			}
			return false;
		}
		return true;
	}

	public static InstalledPlayerVersion? FindNewest(IEnumerable<string> roots, Func<string, Version?>? readVersion = null)
	{
		if (readVersion == null)
		{
			readVersion = (string path) =>
			{
				FileVersionInfo versionInfo = FileVersionInfo.GetVersionInfo(path);
				return new Version(versionInfo.FileMajorPart, versionInfo.FileMinorPart, versionInfo.FileBuildPart, versionInfo.FilePrivatePart);
			};
		}
		InstalledPlayerVersion installedPlayerVersion = null;
		foreach (string root in roots)
		{
			if (!Directory.Exists(root))
			{
				continue;
			}
			try
			{
				string[] directories = Directory.GetDirectories(root, "version-*");
				foreach (string text in directories)
				{
					string fileName = Path.GetFileName(text);
					if (!Regex.IsMatch(fileName, "^version-[0-9a-fA-F]{16}$"))
					{
						continue;
					}
					try
					{
						if ((File.GetAttributes(text) & FileAttributes.ReparsePoint) != 0)
						{
							continue;
						}
						string text2 = Path.Combine(text, "RobloxPlayerBeta.exe");
						if (File.Exists(text2))
						{
							Version version = readVersion(text2);
							if ((object)version != null && version.Major == 0 && version.Minor > 0 && ((object)installedPlayerVersion == null || version > installedPlayerVersion.Version))
							{
								installedPlayerVersion = new InstalledPlayerVersion(fileName, version);
							}
						}
					}
					catch (Exception ex) when ((ex is IOException || ex is UnauthorizedAccessException || ex is ArgumentException) ? true : false)
					{
					}
				}
			}
			catch (Exception ex2) when ((ex2 is IOException || ex2 is UnauthorizedAccessException) ? true : false)
			{
			}
		}
		return installedPlayerVersion;
	}
}
