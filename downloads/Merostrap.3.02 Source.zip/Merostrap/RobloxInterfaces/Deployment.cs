using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Merostrap.Enums;
using Merostrap.Exceptions;
using Merostrap.Models.APIs.Roblox;
using Merostrap.Utility;

namespace Merostrap.RobloxInterfaces;

internal static class Deployment
{
	public const string DefaultRobloxDomain = "roblox.com";

	public const string DefaultChannel = "production";

	private static string _channel = "production";

	public static readonly List<HttpStatusCode?> BadChannelCodes;

	private static readonly Dictionary<string, ClientVersion> ClientVersionCache;

	private static readonly List<string> BaseUrls;

	private const int SecondaryMirrorDelayMs = 300;

	public static string Channel
	{
		get
		{
			return _channel;
		}
		set
		{
			if (!(_channel == value))
			{
				_channel = value;
				ChannelChanged?.Invoke(null, value);
			}
		}
	}

	public static string ChannelToken { get; set; } = string.Empty;

	public static string BinaryType
	{
		get
		{
			if (!OperatingSystem.IsMacOS())
			{
				return "WindowsPlayer";
			}
			return "MacPlayer";
		}
	}

	public static string RobloxDomain => App.Settings.Prop.RobloxDomain;

	public static bool IsDefaultChannel
	{
		get
		{
			if (!Channel.Equals("production", StringComparison.OrdinalIgnoreCase))
			{
				return Channel.Equals("live", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}
	}

	public static bool IsDefaultRobloxDomain => RobloxDomain.Equals("roblox.com", StringComparison.OrdinalIgnoreCase);

	public static string BaseUrl { get; private set; } = null;

	public static event EventHandler<string>? ChannelChanged;

	private static async Task<string> ProbeMirror(string url, int delayMs, CancellationToken token)
	{
		if (delayMs > 0)
		{
			await Task.Delay(delayMs, token);
		}
		using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, url + "/versionStudio");
		using HttpResponseMessage httpResponseMessage = await App.HttpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, token);
		httpResponseMessage.EnsureSuccessStatusCode();
		return url;
	}

	public static async Task<Exception?> InitializeConnectivity()
	{
		CancellationTokenSource tokenSource = new CancellationTokenSource(TimeSpan.FromSeconds(10L));
		try
		{
			List<Task<string>> pending = BaseUrls.Select((string url, int index) => ProbeMirror(url, (index != 0) ? 300 : 0, tokenSource.Token)).ToList();
			App.Logger.Info("Testing for best regional download mirror...");
			Exception ex = null;
			while (pending.Count > 0)
			{
				Task<string> task = await Task.WhenAny(pending);
				pending.Remove(task);
				string baseUrl;
				try
				{
					baseUrl = await task;
				}
				catch (Exception ex2)
				{
					ex = ex2;
					continue;
				}
				BaseUrl = baseUrl;
				App.Logger.Info("Optimal BaseUrl: " + BaseUrl);
				await tokenSource.CancelAsync();
				return null;
			}
			BaseUrl = "https://setup.rbxcdn.com";
			App.Logger.Warn("No mirrors responded. Falling back to default: " + BaseUrl);
			return ex ?? new InvalidOperationException("No regional mirrors were responsive.");
		}
		finally
		{
			if (tokenSource != null)
			{
				((IDisposable)tokenSource).Dispose();
			}
		}
	}

	public static string GetLocation(string resource)
	{
		string text = BaseUrl;
		if (!IsDefaultChannel)
		{
			text += "/channel/common";
		}
		return text + resource;
	}

	public static async Task<UserChannel?> GetUserChannel(string binaryType)
	{
		_ = 1;
		try
		{
			Uri uri = UrlBuilder.BuildApiUrl("clientsettings", "v2/user-channel?binaryType=" + binaryType);
			HttpResponseMessage httpResponseMessage = await App.Cookies.AuthGet(uri);
			httpResponseMessage.EnsureSuccessStatusCode();
			return JsonSerializer.Deserialize<UserChannel>(await httpResponseMessage.Content.ReadAsStringAsync());
		}
		catch (HttpRequestException value)
		{
			App.Logger.Error($"Failed to get user channel: {value}");
		}
		return null;
	}

	public static async Task<bool> IsChannelPrivate(string channel)
	{
		if (channel == "production")
		{
			channel = "live";
		}
		if (channel == "live")
		{
			return false;
		}
		try
		{
			Uri requestUri = UrlBuilder.BuildApiUrl("clientsettingscdn", "v2/client-version/" + BinaryType + "/channel/" + channel);
			(await App.HttpClient.GetAsync(requestUri)).EnsureSuccessStatusCode();
		}
		catch (HttpRequestException ex)
		{
			if (BadChannelCodes.Contains(ex.StatusCode))
			{
				return true;
			}
		}
		return false;
	}

	public static async Task<DateTime?> GetVersionTimestamp(string version)
	{
		if (string.IsNullOrEmpty(BaseUrl))
		{
			await InitializeConnectivity();
		}
		try
		{
			if (OperatingSystem.IsMacOS())
			{
				string location = GetLocation("/mac/" + version + "-RobloxPlayer.zip");
				using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Head, location);
				using HttpResponseMessage httpResponseMessage = await App.HttpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead);
				httpResponseMessage.EnsureSuccessStatusCode();
				if (httpResponseMessage.Content.Headers.TryGetValues("last-modified", out IEnumerable<string> values))
				{
					return DateTime.Parse(values.First(), CultureInfo.InvariantCulture);
				}
			}
			else
			{
				string location = GetLocation("/" + version + "-rbxPkgManifest.txt");
				HttpResponseMessage httpResponseMessage2 = await App.HttpClient.GetAsync(new Uri(location));
				httpResponseMessage2.EnsureSuccessStatusCode();
				if (httpResponseMessage2.Content.Headers.TryGetValues("last-modified", out IEnumerable<string> values2))
				{
					return DateTime.Parse(values2.First(), CultureInfo.InvariantCulture);
				}
			}
		}
		catch (HttpRequestException value)
		{
			App.Logger.Error($"Failed to get timestamp for {version}: {value}");
		}
		return null;
	}

	public static async Task<ClientVersion> GetInfo(string? channel = null, bool behindProductionCheck = false, bool includeTimestamp = false, string? binaryTypeOverride = null)
	{
		if (string.IsNullOrEmpty(channel))
		{
			channel = Channel;
		}
		bool isDefaultChannel = string.Equals(channel, "production", StringComparison.OrdinalIgnoreCase);
		App.Logger.Info("Getting deploy info for channel " + channel);
		string activeBinaryType = binaryTypeOverride ?? BinaryType;
		string cacheKey = channel + "-" + activeBinaryType;
		ClientVersion clientVersion;
		if (ClientVersionCache.TryGetValue(cacheKey, out ClientVersion value))
		{
			App.Logger.Info("Deploy information is cached");
			clientVersion = value;
		}
		else
		{
			string path = "v2/client-version/" + activeBinaryType;
			if (!isDefaultChannel)
			{
				path = path + "/channel/" + channel;
			}
			InstalledPlayerVersion installed = ((((OperatingSystem.IsWindows() && activeBinaryType == "WindowsPlayer") & isDefaultChannel) && IsDefaultRobloxDomain) ? InstalledPlayerVersion.FindNewest(new _003C_003Ez__ReadOnlyArray<string>(new string[2]
			{
				Paths.Versions,
				Path.Combine(Paths.Roblox, "Versions")
			})) : null);
			try
			{
				using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, UrlBuilder.BuildApiUrl("clientsettingscdn", path));
				if (!string.IsNullOrEmpty(ChannelToken))
				{
					request.Headers.Add("Roblox-Channel-Token", ChannelToken);
				}
				clientVersion = await DeploymentRequest.ReadJsonAsync<ClientVersion>(App.HttpClient, request, (object)installed != null);
			}
			catch (HttpRequestException ex) when (!isDefaultChannel && BadChannelCodes.Contains(ex.StatusCode))
			{
				throw new InvalidChannelException(ex.StatusCode);
			}
			catch (Exception ex2)
			{
				App.Logger.Error($"Failed to contact clientsettingscdn! {ex2}");
				App.Logger.Warn("Falling back to clientsettings...");
				try
				{
					using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, UrlBuilder.BuildApiUrl("clientsettings", path));
					if (!string.IsNullOrEmpty(ChannelToken))
					{
						request.Headers.Add("Roblox-Channel-Token", ChannelToken);
					}
					clientVersion = await DeploymentRequest.ReadJsonAsync<ClientVersion>(App.HttpClient, request, (object)installed != null);
				}
				catch (HttpRequestException ex3) when (!isDefaultChannel && BadChannelCodes.Contains(ex3.StatusCode))
				{
					throw new InvalidChannelException(ex3.StatusCode);
				}
				catch (Exception error) when (((OperatingSystem.IsWindows() && activeBinaryType == "WindowsPlayer") & isDefaultChannel) && IsDefaultRobloxDomain && InstalledPlayerVersion.IsUnavailable(ex2) && InstalledPlayerVersion.IsUnavailable(error))
				{
					if ((object)installed == null)
					{
						throw;
					}
					if (string.IsNullOrEmpty(BaseUrl))
					{
						await InitializeConnectivity();
					}
					using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Head, BaseUrl + "/" + installed.VersionGuid + "-rbxPkgManifest.txt");
					using CancellationTokenSource manifestDeadline = new CancellationTokenSource(TimeSpan.FromSeconds(5L));
					using HttpResponseMessage httpResponseMessage = await App.HttpClient.SendAsync(request, manifestDeadline.Token);
					httpResponseMessage.EnsureSuccessStatusCode();
					App.Logger.Warn($"Version services unavailable; using installed Player build {installed.VersionGuid} ({installed.Version}). Latest version could not be checked.");
					clientVersion = new ClientVersion
					{
						VersionGuid = installed.VersionGuid,
						Version = installed.Version.ToString(),
						IsInstalledFallback = true
					};
				}
			}
			if (!isDefaultChannel & behindProductionCheck)
			{
				ClientVersion clientVersion2 = await GetInfo("production", behindProductionCheck: false, includeTimestamp: false, activeBinaryType);
				if (Versioning.CompareVersions(clientVersion.Version, clientVersion2.Version) == VersionComparison.LessThan)
				{
					clientVersion.IsBehindDefaultChannel = true;
				}
			}
			else
			{
				clientVersion.IsBehindDefaultChannel = false;
			}
			ClientVersionCache[cacheKey] = clientVersion;
		}
		if (includeTimestamp && !clientVersion.Timestamp.HasValue)
		{
			ClientVersion clientVersion3 = clientVersion;
			clientVersion3.Timestamp = await GetVersionTimestamp(clientVersion.VersionGuid);
		}
		return clientVersion;
	}

	static Deployment()
	{
		int num = 3;
		List<HttpStatusCode?> list = new List<HttpStatusCode?>(num);
		CollectionsMarshal.SetCount(list, num);
		Span<HttpStatusCode?> span = CollectionsMarshal.AsSpan(list);
		span[0] = HttpStatusCode.Unauthorized;
		span[1] = HttpStatusCode.Forbidden;
		span[2] = HttpStatusCode.NotFound;
		BadChannelCodes = list;
		ClientVersionCache = new Dictionary<string, ClientVersion>();
		num = 5;
		List<string> list2 = new List<string>(num);
		CollectionsMarshal.SetCount(list2, num);
		Span<string> span2 = CollectionsMarshal.AsSpan(list2);
		span2[0] = "https://setup.rbxcdn.com";
		span2[1] = "https://setup-ak.rbxcdn.com";
		span2[2] = "https://setup-aws.rbxcdn.com";
		span2[3] = "https://setup-cfly.rbxcdn.com";
		span2[4] = "https://s3.amazonaws.com/setup.roblox.com";
		BaseUrls = list2;
	}
}
