using System;
using System.Net.Http;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace Merostrap.RobloxInterfaces;

internal static class DeploymentRequest
{
	public static TimeSpan TimeoutFor(bool hasInstalledFallback)
	{
		return TimeSpan.FromSeconds(hasInstalledFallback ? 2 : 15);
	}

	public static async Task<T> ReadJsonAsync<T>(HttpClient client, HttpRequestMessage request, bool hasInstalledFallback)
	{
		using CancellationTokenSource deadline = new CancellationTokenSource(TimeoutFor(hasInstalledFallback));
		using HttpResponseMessage response = await client.SendAsync(request, deadline.Token);
		response.EnsureSuccessStatusCode();
		T val = JsonSerializer.Deserialize<T>(await response.Content.ReadAsStringAsync(deadline.Token));
		if (val == null)
		{
			throw new JsonException("Empty deployment response.");
		}
		return val;
	}
}
