using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Merostrap.Enums;
using Merostrap.Models;
using Merostrap.Models.APIs.Roblox;
using Merostrap.RobloxInterfaces;
using Merostrap.Utility;

namespace Merostrap;

internal class CookiesManager
{
	private struct BinaryCookie
	{
		public string Name { get; set; }

		public string Value { get; set; }

		public string Domain { get; set; }

		public string Path { get; set; }

		public int Flags { get; set; }

		public DateTime? Expiry { get; set; }

		public DateTime? Creation { get; set; }
	}

	private CookieState _state = CookieState.Unknown;

	public EventHandler<CookieState>? StateChanged;

	private string AuthCookie = string.Empty;

	private const string AuthCookieName = ".ROBLOSECURITY";

	private const string AuthPattern = "\\t.ROBLOSECURITY\\t(.+?)(;|$)";

	public CookieState State
	{
		get
		{
			return _state;
		}
		set
		{
			_state = value;
			StateChanged?.Invoke(this, value);
		}
	}

	public bool Loaded
	{
		get
		{
			if (Enabled)
			{
				return State == CookieState.Success;
			}
			return false;
		}
	}

	private static bool Enabled => App.Settings.Prop.AllowCookieAccess;

	public static string CookiesPath
	{
		get
		{
			if (!OperatingSystem.IsMacOS())
			{
				if (!OperatingSystem.IsLinux())
				{
					return Path.Combine(Paths.Roblox, "LocalStorage", Deployment.IsDefaultRobloxDomain ? "RobloxCookies.dat" : (Deployment.RobloxDomain + "_RobloxCookies.dat"));
				}
				return Path.Combine(Paths.Roblox, "data", "sober", "cookies");
			}
			return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Library", "HTTPStorages", "com.roblox.RobloxPlayer.binarycookies");
		}
	}

	public string GetAuthCookie()
	{
		return AuthCookie;
	}

	public async Task<HttpResponseMessage> AuthRequest(HttpRequestMessage request)
	{
		string text = request.RequestUri?.Host;
		ArgumentNullException.ThrowIfNull(text, "host");
		if (!text.Equals(Deployment.RobloxDomain, StringComparison.OrdinalIgnoreCase) && !text.EndsWith("." + Deployment.RobloxDomain, StringComparison.OrdinalIgnoreCase))
		{
			throw new HttpRequestException("Host must end with Roblox domain (" + Deployment.RobloxDomain + ")");
		}
		if (!Enabled)
		{
			throw new InvalidOperationException("Cookie access is not enabled");
		}
		request.Headers.Add("Cookie", ".ROBLOSECURITY=" + AuthCookie);
		return await App.HttpClient.SendAsync(request);
	}

	public async Task<HttpResponseMessage> AuthGet(Uri? uri)
	{
		using HttpRequestMessage request = new HttpRequestMessage
		{
			RequestUri = uri,
			Method = HttpMethod.Get
		};
		return await AuthRequest(request);
	}

	public async Task<HttpResponseMessage> AuthPost(Uri? uri, HttpContent? content)
	{
		using HttpRequestMessage request = new HttpRequestMessage
		{
			RequestUri = uri,
			Content = content,
			Method = HttpMethod.Post
		};
		return await AuthRequest(request);
	}

	public async Task<AuthenticatedUser?> GetAuthenticated()
	{
		_ = 1;
		try
		{
			Uri uri = UrlBuilder.BuildApiUrl("users", "v1/users/authenticated");
			HttpResponseMessage httpResponseMessage = await AuthGet(uri);
			httpResponseMessage.EnsureSuccessStatusCode();
			return JsonSerializer.Deserialize<AuthenticatedUser>(await httpResponseMessage.Content.ReadAsStringAsync());
		}
		catch (HttpRequestException ex)
		{
			App.Logger.Error("Failed to get authenticated user: " + ex.Message);
		}
		return null;
	}

	public async Task LoadCookies()
	{
		if (!Enabled)
		{
			State = CookieState.NotAllowed;
			App.Logger.Error("Cookie access not allowed");
			return;
		}
		if (!string.IsNullOrEmpty(AuthCookie))
		{
			App.Logger.Error("Cookie was already loaded!");
			return;
		}
		if (!File.Exists(CookiesPath))
		{
			State = CookieState.NotFound;
			App.Logger.Error("Cookie file not found");
			return;
		}
		try
		{
			string text = string.Empty;
			if (OperatingSystem.IsWindows())
			{
				text = await LoadWindowsCookies();
			}
			else if (OperatingSystem.IsMacOS())
			{
				text = await LoadMacCookies();
			}
			else if (OperatingSystem.IsLinux())
			{
				text = await LoadLinuxCookies();
			}
			if (string.IsNullOrEmpty(text))
			{
				State = CookieState.Invalid;
				return;
			}
			AuthCookie = text;
			AuthenticatedUser authenticatedUser = await GetAuthenticated();
			State = ((authenticatedUser == null || authenticatedUser.Id == 0L) ? CookieState.Invalid : CookieState.Success);
		}
		catch (Exception ex)
		{
			App.Logger.Error("Failed to load cookies: " + ex.Message);
			State = CookieState.Failed;
		}
	}

	private static async Task<string> LoadWindowsCookies()
	{
		byte[] bytes = ProtectedData.Unprotect(Convert.FromBase64String(JsonSerializer.Deserialize<RobloxCookies>(await File.ReadAllTextAsync(CookiesPath)).Cookies), null, DataProtectionScope.CurrentUser);
		Match match = Regex.Match(Encoding.UTF8.GetString(bytes), "\\t.ROBLOSECURITY\\t(.+?)(;|$)");
		return match.Success ? match.Groups[1].Value : string.Empty;
	}

	private static async Task<string> LoadMacCookies()
	{
		return ExtractRoblosecurity(ParseBinaryCookies(await File.ReadAllBytesAsync(CookiesPath))) ?? string.Empty;
	}

	private static async Task<string> LoadLinuxCookies()
	{
		string text = await File.ReadAllTextAsync(CookiesPath);
		if (string.IsNullOrWhiteSpace(text))
		{
			return string.Empty;
		}
		string[] array = text.Split(';', StringSplitOptions.RemoveEmptyEntries);
		for (int i = 0; i < array.Length; i++)
		{
			string text2 = array[i].Trim();
			int num = text2.IndexOf('=', StringComparison.Ordinal);
			if (num > 0)
			{
				string text3 = text2.Substring(0, num).Trim();
				string result = text2.Substring(num + 1).Trim();
				if (text3 == ".ROBLOSECURITY")
				{
					return result;
				}
			}
		}
		return string.Empty;
	}

	private static List<BinaryCookie> ParseBinaryCookies(byte[] data)
	{
		List<BinaryCookie> list = new List<BinaryCookie>();
		int num = 0;
		if (data.Length < 4 || data[0] != 99 || data[1] != 111 || data[2] != 111 || data[3] != 107)
		{
			throw new InvalidOperationException("Not a binarycookies file");
		}
		num += 4;
		int num2 = ReadBigEndianInt32(data, ref num);
		int[] array = new int[num2];
		for (int i = 0; i < num2; i++)
		{
			array[i] = ReadBigEndianInt32(data, ref num);
		}
		for (int j = 0; j < num2; j++)
		{
			int num3 = num;
			int num4 = num3 + array[j];
			int num5 = ReadLittleEndianInt32(data, num3);
			if (num5 != 256 && num5 != 65536)
			{
				App.Logger.Error($"Unexpected page header: 0x{num5:X} at offset {num3}");
			}
			int num6 = ReadLittleEndianInt32(data, num3 + 4);
			int num7 = num3 + 8;
			for (int k = 0; k < num6; k++)
			{
				int offset = num3 + ReadLittleEndianInt32(data, num7 + k * 4);
				try
				{
					BinaryCookie item = ParseSingleCookie(data, offset);
					list.Add(item);
				}
				catch (Exception ex)
				{
					App.Logger.Error($"Failed to parse cookie {k} in page {j}: {ex.Message}");
				}
			}
			num = num4;
		}
		return list;
	}

	private static BinaryCookie ParseSingleCookie(byte[] data, int offset)
	{
		int flags = ReadLittleEndianInt32(data, offset + 4);
		int num = ReadLittleEndianInt32(data, offset + 16);
		int num2 = ReadLittleEndianInt32(data, offset + 20);
		int num3 = ReadLittleEndianInt32(data, offset + 24);
		int num4 = ReadLittleEndianInt32(data, offset + 28);
		double macTime = BitConverter.ToDouble(data, offset + 40);
		double macTime2 = BitConverter.ToDouble(data, offset + 48);
		string domain = ReadNullTerminatedString(data, offset + num);
		string name = ReadNullTerminatedString(data, offset + num2);
		string path = ReadNullTerminatedString(data, offset + num3);
		string value = ReadNullTerminatedString(data, offset + num4);
		return new BinaryCookie
		{
			Name = name,
			Value = value,
			Domain = domain,
			Path = path,
			Flags = flags,
			Expiry = MacTimeToDateTime(macTime),
			Creation = MacTimeToDateTime(macTime2)
		};
	}

	private static string ReadNullTerminatedString(byte[] data, int offset)
	{
		int i;
		for (i = offset; i < data.Length && data[i] != 0; i++)
		{
		}
		return Encoding.UTF8.GetString(data, offset, i - offset);
	}

	private static int ReadBigEndianInt32(byte[] data, ref int offset)
	{
		int result = (data[offset] << 24) | (data[offset + 1] << 16) | (data[offset + 2] << 8) | data[offset + 3];
		offset += 4;
		return result;
	}

	private static int ReadLittleEndianInt32(byte[] data, int offset)
	{
		return data[offset] | (data[offset + 1] << 8) | (data[offset + 2] << 16) | (data[offset + 3] << 24);
	}

	private static DateTime? MacTimeToDateTime(double macTime)
	{
		if (macTime == 0.0)
		{
			return null;
		}
		return new DateTime(2001, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddSeconds(macTime).ToLocalTime();
	}

	private static string? ExtractRoblosecurity(List<BinaryCookie> cookies)
	{
		return cookies.FirstOrDefault((BinaryCookie c) => c.Name == ".ROBLOSECURITY" && c.Domain.Contains(".roblox.com", StringComparison.Ordinal)).Value;
	}
}
