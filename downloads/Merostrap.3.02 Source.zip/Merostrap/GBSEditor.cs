using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using System.Xml.XPath;
using Avalonia.Platform;
using Merostrap.Enums.GBSPresets;
using Merostrap.Utility;

namespace Merostrap;

internal class GBSEditor
{
	public Dictionary<string, string> PresetPaths = new Dictionary<string, string>
	{
		{ "Rendering.FramerateCap", "{UserSettings}/int[@name='FramerateCap']" },
		{ "Rendering.SavedQualityLevel", "{UserSettings}/token[@name='SavedQualityLevel']" },
		{ "Rendering.Fullscreen", "{UserSettings}/bool[@name='Fullscreen']" },
		{ "Rendering.MaxQualityEnabled", "{UserSettings}/bool[@name='MaxQualityEnabled']" },
		{ "Rendering.VignetteEnabled", "{UserSettings}/bool[@name='VignetteEnabled']" },
		{ "Rendering.VignetteEnableOption", "{UserSettings}/bool[@name='VignetteEnabledCustomOption']" },
		{ "Audio.MasterVolume", "{UserSettings}/float[@name='MasterVolume']" },
		{ "Audio.MasterVolumeStudio", "{UserSettings}/float[@name='MasterVolumeStudio']" },
		{ "Audio.PartyVoiceVolume", "{UserSettings}/float[@name='PartyVoiceVolume']" },
		{ "Audio.VoiceChatVolume", "{UserSettings}/float[@name='VoiceChatVolume']" },
		{ "User.MouseSensitivity", "{UserSettings}/float[@name='MouseSensitivity']" },
		{ "User.ShiftLock", "{UserSettings}/token[@name='ControlMode']" },
		{ "User.MouseSensitivityFirstPerson", "{UserSettings}/Vector2[@name='MouseSensitivityFirstPerson']" },
		{ "User.MouseSensitivityThirdPerson", "{UserSettings}/Vector2[@name='MouseSensitivityThirdPerson']" },
		{ "User.CameraYInverted", "{UserSettings}/bool[@name='CameraYInverted']" },
		{ "User.HapticStrength", "{UserSettings}/float[@name='HapticStrength']" },
		{ "UI.Transparency", "{UserSettings}/float[@name='PreferredTransparency']" },
		{ "UI.ReducedMotion", "{UserSettings}/bool[@name='ReducedMotion']" },
		{ "UI.FontSize", "{UserSettings}/token[@name='PreferredTextSize']" },
		{ "UI.PlayerListLayOut", "{UserSettings}/token[@name='PeoplePageLayout']" },
		{ "Misc.PerformanceStatsVisible", "{UserSettings}/bool[@name='PerformanceStatsVisible']" },
		{ "Misc.ChatTranslationEnabled", "{UserSettings}/bool[@name='ChatTranslationEnabled']" },
		{ "Misc.ChatTranslationFTUXShown", "{UserSettings}/bool[@name='ChatTranslationFTUXShown']" },
		{ "User.VREnabled", "{UserSettings}/bool[@name='VREnabled']" }
	};

	public Dictionary<string, string> RootPaths = new Dictionary<string, string> { { "UserSettings", "//Item[@class='UserGameSettings']/Properties" } };

	private static readonly HashSet<string> KnownTypes = new HashSet<string>(StringComparer.Ordinal) { "bool", "int", "float", "token", "string", "Vector2" };

	private static readonly Regex PathTailRegex = new Regex("^(?<parent>.+)/(?<type>[A-Za-z0-9_]+)\\[@name='(?<name>[A-Za-z0-9_]+)'\\]$", RegexOptions.Compiled);

	private static readonly Regex ValidSettingName = new Regex("^[A-Za-z0-9_]+$", RegexOptions.Compiled);

	private string? _savedHash;

	public bool previousReadOnlyState;

	public XDocument? Document { get; set; }

	public static IReadOnlyDictionary<FontSize, string?> FontSizes => new Dictionary<FontSize, string>
	{
		{
			FontSize.x1,
			"1"
		},
		{
			FontSize.x2,
			"2"
		},
		{
			FontSize.x3,
			"3"
		},
		{
			FontSize.x4,
			"4"
		}
	};

	public static IReadOnlyDictionary<PlayerListLayOut, string?> PlayerListLayOuts => new Dictionary<PlayerListLayOut, string>
	{
		{
			PlayerListLayOut.x0,
			"0"
		},
		{
			PlayerListLayOut.x1,
			"1"
		}
	};

	public bool Loaded { get; set; }

	public static string FileLocation
	{
		get
		{
			if (!OperatingSystem.IsLinux())
			{
				if (!OperatingSystem.IsMacOS())
				{
					return Path.Combine(Paths.Roblox, "GlobalBasicSettings_13.xml");
				}
				return Path.Combine(Paths.UserProfile, "Library", "Roblox", "GlobalBasicSettings_13.xml");
			}
			return Path.Combine(Paths.SoberData, "appData", "GlobalBasicSettings_13.xml");
		}
	}

	public bool HasUnsavedChanges
	{
		get
		{
			if (_savedHash == null)
			{
				return false;
			}
			return ComputeHash() != _savedHash;
		}
	}

	public void ApplyProfile(string xml)
	{
		XDocument document = XDocument.Parse(xml);
		if (!HasExpectedStructure(document))
		{
			throw new InvalidDataException("Invalid Roblox settings in profile.");
		}
		if (_savedHash == null)
		{
			_savedHash = ComputeHash();
		}
		Document = document;
		Loaded = true;
	}

	private string ComputeHash()
	{
		if (Document == null)
		{
			return string.Empty;
		}
		return FastHash.FromString(Document.ToString());
	}

	public void SetPreset(string prefix, object? value)
	{
		List<KeyValuePair<string, string>> list = PresetPaths.Where((KeyValuePair<string, string> x) => x.Key.StartsWith(prefix, StringComparison.Ordinal)).ToList();
		if (list.Count == 0)
		{
			App.Logger.Warn("SetPreset: No preset paths found for prefix '" + prefix + "'");
			return;
		}
		foreach (KeyValuePair<string, string> item in list)
		{
			SetValue(item.Value, value);
		}
	}

	public string? GetPreset(string prefix)
	{
		if (PresetPaths.TryGetValue(prefix, out string value))
		{
			return GetValue(value);
		}
		return null;
	}

	public void SetValue(string path, object? value)
	{
		if (Document == null)
		{
			App.Logger.Warn("SetValue: No document loaded, cannot set '" + path + "'.");
			return;
		}
		path = ResolvePath(path, RootPaths);
		XElement xElement = Document.XPathSelectElement(path);
		Match match = PathTailRegex.Match(path);
		string text = xElement?.Name.LocalName ?? (match.Success ? match.Groups["type"].Value : null);
		if (text == null)
		{
			App.Logger.Warn("SetValue: Unsupported path '" + path + "'. Changes will not be applied.");
			return;
		}
		if (text == "Vector2" || (xElement != null && xElement.HasElements))
		{
			App.Logger.Warn("SetValue: '" + path + "' is a compound element, use SetVectorValue. Skipping.");
			return;
		}
		if (!TryNormalizeValue(text, value, out string result))
		{
			App.Logger.Warn($"SetValue: Rejected value '{value}' for {text} at '{path}'.");
			return;
		}
		if (xElement == null)
		{
			xElement = CreateMissingElement(path);
			if (xElement == null)
			{
				App.Logger.Warn("SetValue: Element not found or could not be created for path '" + path + "'. Changes will not be applied.");
				return;
			}
		}
		if (xElement.Value != result)
		{
			App.Logger.Debug($"SetValue: Changing '{path}' from '{xElement.Value}' to '{result}'");
			xElement.Value = result;
		}
	}

	private XElement? CreateMissingElement(string resolvedPath)
	{
		Match match = PathTailRegex.Match(resolvedPath);
		if (!match.Success)
		{
			return null;
		}
		string value = match.Groups["type"].Value;
		string value2 = match.Groups["name"].Value;
		if (!KnownTypes.Contains(value) || !ValidSettingName.IsMatch(value2))
		{
			return null;
		}
		XElement xElement = Document?.XPathSelectElement(match.Groups["parent"].Value);
		if (xElement == null)
		{
			return null;
		}
		XElement xElement2 = new XElement(value, new XAttribute("name", value2));
		if (value == "Vector2")
		{
			xElement2.Add(new XElement("X", "0"), new XElement("Y", "0"));
		}
		xElement.Add(xElement2);
		App.Logger.Info($"SetValue: Created missing element '{value}' with name '{value2}' at path '{resolvedPath}'");
		return xElement2;
	}

	private static string FormatValue(object? value)
	{
		if (value != null)
		{
			if (!(value is bool))
			{
				if (value is IFormattable formattable)
				{
					return formattable.ToString(null, CultureInfo.InvariantCulture);
				}
				return value.ToString() ?? string.Empty;
			}
			return ((bool)value) ? "true" : "false";
		}
		return string.Empty;
	}

	private static bool TryNormalizeFloat(string raw, out string result)
	{
		result = string.Empty;
		raw = raw.Trim();
		if (!float.TryParse(raw, NumberStyles.Float, CultureInfo.InvariantCulture, out var result2) && !float.TryParse(raw, NumberStyles.Float, CultureInfo.CurrentCulture, out result2))
		{
			return false;
		}
		if (!float.IsFinite(result2))
		{
			return false;
		}
		result = result2.ToString(CultureInfo.InvariantCulture);
		return true;
	}

	private static bool TryNormalizeValue(string type, object? value, out string result)
	{
		result = string.Empty;
		string text = FormatValue(value);
		switch (type)
		{
		case "bool":
			if (text.Trim().Equals("true", StringComparison.OrdinalIgnoreCase))
			{
				result = "true";
				return true;
			}
			if (text.Trim().Equals("false", StringComparison.OrdinalIgnoreCase))
			{
				result = "false";
				return true;
			}
			return false;
		case "int":
		case "token":
		{
			if (int.TryParse(text.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var result2))
			{
				result = result2.ToString(CultureInfo.InvariantCulture);
				return true;
			}
			if (decimal.TryParse(text.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out var result3) && result3 == decimal.Truncate(result3) && result3 >= -2147483648m && result3 <= 2147483647m)
			{
				result = ((int)result3).ToString(CultureInfo.InvariantCulture);
				return true;
			}
			return false;
		}
		case "float":
			return TryNormalizeFloat(text, out result);
		case "string":
			result = text;
			return true;
		default:
			return false;
		}
	}

	public string? GetValue(string path)
	{
		path = ResolvePath(path, RootPaths);
		return Document?.XPathSelectElement(path)?.Value;
	}

	public void SetReadOnly(bool readOnly, bool preserveState = false)
	{
		if (!File.Exists(FileLocation))
		{
			return;
		}
		try
		{
			FileAttributes attributes = File.GetAttributes(FileLocation);
			attributes = ((!readOnly) ? (attributes & ~FileAttributes.ReadOnly) : (attributes | FileAttributes.ReadOnly));
			File.SetAttributes(FileLocation, attributes);
			if (!preserveState)
			{
				previousReadOnlyState = readOnly;
			}
		}
		catch (Exception argument)
		{
			App.Logger.Error("Failed to set read-only on " + FileLocation, argument);
		}
	}

	public static bool GetReadOnly()
	{
		if (!File.Exists(FileLocation))
		{
			return false;
		}
		return File.GetAttributes(FileLocation).HasFlag(FileAttributes.ReadOnly);
	}

	public void CreateTemplate()
	{
		App.Logger.Info("Creating template at " + FileLocation + "...");
		try
		{
			string directoryName = Path.GetDirectoryName(FileLocation);
			if (!string.IsNullOrEmpty(directoryName) && !Directory.Exists(directoryName))
			{
				Directory.CreateDirectory(directoryName);
				App.Logger.Info("Created directory: " + directoryName);
			}
			using Stream stream = AssetLoader.Open(new Uri("avares://Merostrap/Resources/GlobalBasicSettings_Template.xml"));
			using FileStream destination = File.Create(FileLocation);
			stream.CopyTo(destination);
			previousReadOnlyState = GetReadOnly();
			App.Logger.Info("Template created successfully!");
		}
		catch (Exception argument)
		{
			App.Logger.Error("Failed to create template at " + FileLocation, argument);
		}
	}

	public void Load()
	{
		App.Logger.Info("Loading from " + FileLocation + "...");
		try
		{
			string directoryName = Path.GetDirectoryName(FileLocation);
			if (!string.IsNullOrEmpty(directoryName) && !Directory.Exists(directoryName))
			{
				Directory.CreateDirectory(directoryName);
				App.Logger.Info("Created directory: " + directoryName);
			}
			LoadDocument();
			App.Logger.Info("Loaded successfully!");
		}
		catch (Exception argument)
		{
			App.Logger.Error("Failed to load, recreating template...", argument);
			if (File.Exists(FileLocation))
			{
				try
				{
					SetReadOnly(readOnly: false, preserveState: true);
					File.Copy(FileLocation, FileLocation + ".broken", overwrite: true);
					App.Logger.Warn("Kept a copy of the broken file at " + FileLocation + ".broken");
				}
				catch
				{
				}
				try
				{
					File.Delete(FileLocation);
				}
				catch
				{
				}
			}
			CreateTemplate();
			try
			{
				LoadDocument();
				App.Logger.Info("Recreated and loaded successfully!");
			}
			catch (Exception value)
			{
				App.Logger.Error("Failed even after recreating!");
				App.Logger.Error(value);
				Loaded = false;
			}
		}
	}

	private void LoadDocument()
	{
		XDocument document = XDocument.Load(FileLocation);
		if (!HasExpectedStructure(document))
		{
			throw new InvalidDataException("GlobalBasicSettings has no UserGameSettings/Properties block.");
		}
		Document = document;
		Loaded = true;
		previousReadOnlyState = GetReadOnly();
		_savedHash = ComputeHash();
		RemoveLegacyJunk();
	}

	private bool HasExpectedStructure(XDocument document)
	{
		if (document.Root?.Name.LocalName == "roblox")
		{
			return document.XPathSelectElement(RootPaths["UserSettings"]) != null;
		}
		return false;
	}

	private void RemoveLegacyJunk()
	{
		if (Document?.Root == null)
		{
			return;
		}
		List<XElement> list = Document.Root.Elements().Where((XElement e) =>
		{
			bool flag;
			switch (e.Name.LocalName)
			{
			case "Item":
			case "External":
			case "SharedStrings":
				flag = true;
				break;
			default:
				flag = false;
				break;
			}
			return !flag;
		}).ToList();
		XElement xElement = Document.XPathSelectElement(RootPaths["UserSettings"]);
		List<XElement> list2 = ((xElement == null) ? new List<XElement>() : xElement.Elements().Where((XElement e) =>
		{
			XAttribute xAttribute = e.Attribute("name");
			return xAttribute != null && !ValidSettingName.IsMatch(xAttribute.Value);
		}).ToList());
		if (list.Count == 0 && list2.Count == 0)
		{
			return;
		}
		foreach (XElement item in list.Concat(list2))
		{
			item.Remove();
		}
		App.Logger.Warn($"Removed {list.Count + list2.Count} malformed element(s) left over from an older editor build.");
	}

	public virtual bool Save()
	{
		App.Logger.Info("Saving to " + FileLocation + "...");
		if (!HasUnsavedChanges)
		{
			App.Logger.Info("No changes, skipping save.");
			return false;
		}
		if (!Loaded || Document == null)
		{
			App.Logger.Error("Save failed – document not loaded.");
			return false;
		}
		if (!HasExpectedStructure(Document))
		{
			App.Logger.Error("Save aborted – document is missing its UserGameSettings/Properties block.");
			return false;
		}
		try
		{
			string directoryName = Path.GetDirectoryName(FileLocation);
			if (!string.IsNullOrEmpty(directoryName) && !Directory.Exists(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
		}
		catch (Exception ex)
		{
			App.Logger.Error("Failed to create directory: " + ex.Message);
			return false;
		}
		bool readOnly = GetReadOnly();
		if (readOnly)
		{
			App.Logger.Debug("File is read‑only; attempting to remove read‑only flag.");
			SetReadOnly(readOnly: false, preserveState: true);
		}
		try
		{
			string text = FileLocation + ".tmp";
			Document.Save(text);
			File.Copy(text, FileLocation, overwrite: true);
			File.Delete(text);
			_savedHash = ComputeHash();
			App.Logger.Info("Save complete!");
			return true;
		}
		catch (Exception ex2)
		{
			App.Logger.Error("Failed to save: " + ex2.Message);
			App.Logger.Error(ex2);
			return false;
		}
		finally
		{
			if (readOnly)
			{
				App.Logger.Debug("Restoring read‑only flag.");
				SetReadOnly(readOnly: true, preserveState: true);
			}
		}
	}

	private static string ResolvePath(string rawPath, Dictionary<string, string> rootPaths)
	{
		return Regex.Replace(rawPath, "\\{(.+?)\\}", (Match match) =>
		{
			string value = match.Groups[1].Value;
			string value2;
			return (!rootPaths.TryGetValue(value, out value2)) ? match.Value : value2;
		});
	}

	public string GetVectorValue(string vectorName, string axis)
	{
		if (!PresetPaths.TryGetValue(vectorName, out string value))
		{
			return "0";
		}
		return (Document?.XPathSelectElement(ResolvePath(value, RootPaths)))?.Element(axis)?.Value ?? "0";
	}

	public void SetVectorValue(string vectorName, string axis, string value)
	{
		if (!PresetPaths.TryGetValue(vectorName, out string value2))
		{
			App.Logger.Warn("SetVectorValue: Unknown vector '" + vectorName + "'");
			return;
		}
		if ((!(axis == "X") && !(axis == "Y")) || 1 == 0)
		{
			App.Logger.Warn($"SetVectorValue: Invalid axis '{axis}' for vector '{vectorName}'");
			return;
		}
		if (!TryNormalizeFloat(value, out string result))
		{
			App.Logger.Warn($"SetVectorValue: Rejected value '{value}' for '{vectorName}.{axis}'");
			return;
		}
		string text = ResolvePath(value2, RootPaths);
		XElement xElement = Document?.XPathSelectElement(text) ?? CreateMissingElement(text);
		if (xElement != null)
		{
			XElement xElement2 = xElement.Element(axis);
			if (xElement2 == null)
			{
				xElement2 = new XElement(axis);
				xElement.Add(xElement2);
				App.Logger.Info($"SetVectorValue: Created missing axis '{axis}' for vector '{vectorName}'");
			}
			xElement2.Value = result;
		}
	}

	public static bool ExportSettings(string exportPath)
	{
		try
		{
			if (!File.Exists(FileLocation))
			{
				return false;
			}
			string directoryName = Path.GetDirectoryName(exportPath);
			if (!string.IsNullOrEmpty(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			File.Copy(FileLocation, exportPath, overwrite: true);
			return true;
		}
		catch
		{
			return false;
		}
	}

	public bool ImportSettings(string importPath)
	{
		try
		{
			if (!File.Exists(importPath))
			{
				return false;
			}
			SetReadOnly(readOnly: false, preserveState: true);
			File.Copy(importPath, FileLocation, overwrite: true);
			Load();
			return true;
		}
		catch
		{
			return false;
		}
	}
}
