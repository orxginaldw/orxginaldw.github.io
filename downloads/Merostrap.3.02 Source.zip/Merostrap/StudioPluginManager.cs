using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Merostrap.Enums;
using Merostrap.Models.APIs.GitHub;
using Merostrap.Utility;

namespace Merostrap;

internal static class StudioPluginManager
{
	private const string VersionApiUrl = "https://api.github.com/repos/Merostrap/MerostrapStudioRPC/releases/latest";

	public static string? OverridePluginDirectory { get; set; }

	private static string PluginFile
	{
		get
		{
			if (!string.IsNullOrEmpty(OverridePluginDirectory))
			{
				return Path.Combine(OverridePluginDirectory, "MerostrapStudioRPC.rbxmx");
			}
			return Path.Combine(Paths.Roblox, "Plugins", "MerostrapStudioRPC.rbxmx");
		}
	}

	private static string VersionCacheFile => Path.Combine(Paths.Cache, "StudioRPCVersion.json");

	public static void Sync()
	{
		if (!App.Settings.Prop.StudioRPC)
		{
			Uninstall();
			return;
		}
		Task.Run(async () =>
		{
			_ = 1;
			try
			{
				GithubRelease githubRelease = await GetLatestRelease();
				if (githubRelease != null)
				{
					string cachedVersion = GetCachedVersion();
					if (!File.Exists(PluginFile) || !File.Exists(VersionCacheFile) || Versioning.CompareVersions(githubRelease.TagName, cachedVersion) == VersionComparison.GreaterThan)
					{
						App.Logger.Info($"Syncing plugin (Local: {cachedVersion}, Remote: {githubRelease.TagName})");
						await DownloadPluginAsync(githubRelease);
					}
				}
			}
			catch (Exception value)
			{
				App.Logger.Error($"Failed to sync Studio RPC plugin: {value}");
			}
		});
	}

	private static async Task DownloadPluginAsync(GithubRelease release)
	{
		GithubReleaseAsset githubReleaseAsset = release.Assets?.FirstOrDefault((GithubReleaseAsset x) => x.Name.EndsWith(".rbxmx", StringComparison.Ordinal));
		if (githubReleaseAsset != null)
		{
			byte[] bytes = await App.HttpClient.GetByteArrayAsync(new Uri(githubReleaseAsset.BrowserDownloadUrl));
			Directory.CreateDirectory(Path.GetDirectoryName(PluginFile));
			await File.WriteAllBytesAsync(PluginFile, bytes);
			var value = new
			{
				Version = release.TagName,
				UpdatedAt = DateTime.Now
			};
			await File.WriteAllTextAsync(VersionCacheFile, JsonSerializer.Serialize(value));
		}
	}

	private static async Task<GithubRelease?> GetLatestRelease()
	{
		try
		{
			return JsonSerializer.Deserialize<GithubRelease>(await App.HttpClient.GetStringAsync(new Uri("https://api.github.com/repos/Merostrap/MerostrapStudioRPC/releases/latest")));
		}
		catch
		{
			return null;
		}
	}

	private static string GetCachedVersion()
	{
		try
		{
			using JsonDocument jsonDocument = JsonDocument.Parse(File.ReadAllText(VersionCacheFile));
			return jsonDocument.RootElement.GetProperty("Version").GetString() ?? "0.0.0";
		}
		catch
		{
			return "0.0.0";
		}
	}

	public static void Uninstall()
	{
		if (File.Exists(PluginFile))
		{
			File.Delete(PluginFile);
		}
		if (File.Exists(VersionCacheFile))
		{
			File.Delete(VersionCacheFile);
		}
	}
}
