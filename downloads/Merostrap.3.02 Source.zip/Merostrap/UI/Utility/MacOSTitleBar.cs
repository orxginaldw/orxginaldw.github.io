#define TRACE
using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Threading;

namespace Merostrap.UI.Utility;

internal static class MacOSTitleBar
{
	private sealed class ThickTitleBarState
	{
		private readonly Window _window;

		private nint _nsWindow;

		private nint _nsToolbar;

		private nint _selSetToolbar;

		private nint _selSetTitlebarAppearsTransparent;

		private nint _selSetTitleVisibility;

		private bool _attached;

		public ThickTitleBarState(Window window)
		{
			_window = window;
		}

		public void Attach()
		{
			if (!_attached)
			{
				if (_window.IsLoaded)
				{
					Setup();
				}
				else
				{
					_window.Opened += OnOpened;
				}
			}
		}

		public void Detach()
		{
			if (_attached)
			{
				_window.Opened -= OnOpened;
				_window.PropertyChanged -= OnWindowPropertyChanged;
				if (_nsWindow != IntPtr.Zero && _selSetToolbar != IntPtr.Zero)
				{
					objc_msgSend_arg(_nsWindow, _selSetToolbar, IntPtr.Zero);
				}
				_attached = false;
			}
		}

		private void OnOpened(object? sender, EventArgs e)
		{
			_window.Opened -= OnOpened;
			Setup();
		}

		private void Setup()
		{
			try
			{
				_nsWindow = _window.TryGetPlatformHandle()?.Handle ?? IntPtr.Zero;
				if (_nsWindow != IntPtr.Zero)
				{
					_selSetToolbar = sel_registerName("setToolbar:");
					_selSetTitlebarAppearsTransparent = sel_registerName("setTitlebarAppearsTransparent:");
					_selSetTitleVisibility = sel_registerName("setTitleVisibility:");
					_nsToolbar = objc_msgSend_ret(objc_getClass("NSToolbar"), sel_registerName("alloc"));
					_nsToolbar = objc_msgSend_arg_ret(_nsToolbar, sel_registerName("initWithIdentifier:"), CreateNSString("filamentTitleBar"));
					if (_nsToolbar != IntPtr.Zero)
					{
						objc_msgSend_bool(_nsToolbar, sel_registerName("setShowsBaselineSeparator:"), arg: false);
						objc_msgSend_arg(_nsWindow, _selSetToolbar, _nsToolbar);
						objc_msgSend_long(_nsWindow, _selSetTitleVisibility, 1L);
						_window.PropertyChanged += OnWindowPropertyChanged;
						_attached = true;
						Trace.TraceInformation("macOS thick title bar: toolbar assigned to NSWindow");
					}
				}
			}
			catch (Exception ex)
			{
				Trace.TraceWarning("macOS thick title bar setup failed: {0}", ex.Message);
			}
		}

		private void OnWindowPropertyChanged(object? sender, AvaloniaPropertyChangedEventArgs e)
		{
			if (e.Property != Window.WindowStateProperty)
			{
				return;
			}
			WindowState newState = e.GetNewValue<WindowState>();
			Dispatcher.UIThread.Post(() =>
			{
				try
				{
					if (newState == WindowState.FullScreen)
					{
						objc_msgSend_arg(_nsWindow, _selSetToolbar, IntPtr.Zero);
						objc_msgSend_bool(_nsWindow, _selSetTitlebarAppearsTransparent, arg: true);
						objc_msgSend_long(_nsWindow, _selSetTitleVisibility, 1L);
					}
					else
					{
						objc_msgSend_arg(_nsWindow, _selSetToolbar, _nsToolbar);
						objc_msgSend_bool(_nsWindow, _selSetTitlebarAppearsTransparent, arg: true);
						objc_msgSend_long(_nsWindow, _selSetTitleVisibility, 1L);
					}
				}
				catch (Exception ex)
				{
					Trace.TraceWarning("macOS thick title bar fullscreen toggle failed: {0}", ex.Message);
				}
			}, DispatcherPriority.Background);
		}
	}

	public static readonly AttachedProperty<bool> IsThickProperty;

	private static readonly ConditionalWeakTable<Window, ThickTitleBarState> States;

	public static bool GetIsThick(Window window)
	{
		return window.GetValue(IsThickProperty);
	}

	public static void SetIsThick(Window window, bool value)
	{
		window.SetValue(IsThickProperty, value);
	}

	static MacOSTitleBar()
	{
		IsThickProperty = AvaloniaProperty.RegisterAttached<Window, bool>("IsThick", typeof(MacOSTitleBar), defaultValue: false);
		States = new ConditionalWeakTable<Window, ThickTitleBarState>();
		IsThickProperty.Changed.AddClassHandler<Window>(OnIsThickChanged);
	}

	private static void OnIsThickChanged(Window window, AvaloniaPropertyChangedEventArgs args)
	{
		if (OperatingSystem.IsMacOS())
		{
			object newValue = args.NewValue;
			ThickTitleBarState value;
			if (newValue is bool && (bool)newValue)
			{
				ThickTitleBarState thickTitleBarState = new ThickTitleBarState(window);
				States.AddOrUpdate(window, thickTitleBarState);
				thickTitleBarState.Attach();
			}
			else if (States.TryGetValue(window, out value))
			{
				value.Detach();
				States.Remove(window);
			}
		}
	}

	private static nint CreateNSString(string str)
	{
		nint receiver = objc_msgSend_ret(objc_getClass("NSString"), sel_registerName("alloc"));
		nint num = Marshal.StringToCoTaskMemUTF8(str);
		try
		{
			return objc_msgSend_arg_ret(receiver, sel_registerName("initWithUTF8String:"), num);
		}
		finally
		{
			Marshal.FreeCoTaskMem(num);
		}
	}

	[DllImport("/usr/lib/libobjc.A.dylib", BestFitMapping = false, CharSet = CharSet.Ansi, ThrowOnUnmappableChar = true)]
	private static extern nint objc_getClass(string name);

	[DllImport("/usr/lib/libobjc.A.dylib", BestFitMapping = false, CharSet = CharSet.Ansi, ThrowOnUnmappableChar = true)]
	private static extern nint sel_registerName(string name);

	[DllImport("/usr/lib/libobjc.A.dylib", EntryPoint = "objc_msgSend")]
	private static extern nint objc_msgSend_ret(nint receiver, nint selector);

	[DllImport("/usr/lib/libobjc.A.dylib", EntryPoint = "objc_msgSend")]
	private static extern void objc_msgSend_arg(nint receiver, nint selector, nint arg);

	[DllImport("/usr/lib/libobjc.A.dylib", EntryPoint = "objc_msgSend")]
	private static extern nint objc_msgSend_arg_ret(nint receiver, nint selector, nint arg);

	[DllImport("/usr/lib/libobjc.A.dylib", EntryPoint = "objc_msgSend")]
	private static extern void objc_msgSend_bool(nint receiver, nint selector, [MarshalAs(UnmanagedType.I1)] bool arg);

	[DllImport("/usr/lib/libobjc.A.dylib", EntryPoint = "objc_msgSend")]
	private static extern void objc_msgSend_long(nint receiver, nint selector, long arg);
}
