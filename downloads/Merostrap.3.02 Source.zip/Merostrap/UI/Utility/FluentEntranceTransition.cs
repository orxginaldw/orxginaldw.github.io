using System;
using System.Threading;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Animation;
using Avalonia.Animation.Easings;
using Avalonia.Media;
using Avalonia.Styling;

namespace Merostrap.UI.Utility;

internal class FluentEntranceTransition : IPageTransition
{
	public double VerticalOffset { get; set; } = 150.0;

	public TimeSpan Duration { get; set; } = TimeSpan.FromMilliseconds(350L);

	public async Task Start(Visual? from, Visual? to, bool forward, CancellationToken cancellationToken)
	{
		if (cancellationToken.IsCancellationRequested)
		{
			return;
		}
		if (App.Settings.Prop.DisableAnimations || App.Settings.Prop.Performance.UseReducedAnimations)
		{
			if (from != null)
			{
				from.IsVisible = false;
				from.Opacity = 1.0;
				if (from.RenderTransform is TranslateTransform translateTransform)
				{
					translateTransform.Y = 0.0;
				}
			}
			if (to != null)
			{
				to.IsVisible = true;
				to.Opacity = 1.0;
				if (to.RenderTransform is TranslateTransform translateTransform2)
				{
					translateTransform2.Y = 0.0;
				}
			}
			return;
		}
		if (from != null)
		{
			await new Animation
			{
				Duration = TimeSpan.FromMilliseconds(100L),
				Easing = new CubicEaseOut(),
				FillMode = FillMode.Forward,
				Children = 
				{
					new KeyFrame
					{
						Setters = { (IAnimationSetter)new Setter(Visual.OpacityProperty, 0.0) },
						Cue = new Cue(1.0)
					}
				}
			}.RunAsync(from, cancellationToken);
			from.IsVisible = false;
		}
		if (to != null)
		{
			to.IsVisible = true;
			await new Animation
			{
				Duration = Duration,
				Easing = new SplineEasing(0.1, 0.9, 0.2),
				FillMode = FillMode.Forward,
				Children = 
				{
					new KeyFrame
					{
						Setters = 
						{
							(IAnimationSetter)new Setter(Visual.OpacityProperty, 0.0),
							(IAnimationSetter)new Setter(TranslateTransform.YProperty, VerticalOffset)
						},
						Cue = new Cue(0.0)
					},
					new KeyFrame
					{
						Setters = 
						{
							(IAnimationSetter)new Setter(Visual.OpacityProperty, 1.0),
							(IAnimationSetter)new Setter(TranslateTransform.YProperty, 0.0)
						},
						Cue = new Cue(1.0)
					}
				}
			}.RunAsync(to, cancellationToken);
		}
	}
}
