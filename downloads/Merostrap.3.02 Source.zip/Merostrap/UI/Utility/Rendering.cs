using System;
using System.Globalization;
using Avalonia.Controls;
using Avalonia.Media;

namespace Merostrap.UI.Utility;

internal static class Rendering
{
	public static double GetTextWidth(TextBlock textBlock)
	{
		if (textBlock == null)
		{
			return 0.0;
		}
		return GetTextWidth(textBlock.Text ?? "", textBlock.FontFamily, textBlock.FontSize);
	}

	public static double GetTextWidth(string text, FontFamily fontFamily, double fontSize)
	{
		if (string.IsNullOrEmpty(text))
		{
			return 0.0;
		}
		try
		{
			return new FormattedText(text, CultureInfo.CurrentCulture, FlowDirection.LeftToRight, new Typeface(fontFamily), fontSize, Brushes.Black).Width;
		}
		catch (Exception)
		{
			return (double)text.Length * fontSize * 0.6;
		}
	}
}
