namespace Merostrap.UI.Utility;

internal enum SlideDirection
{
	Left,
	Right
}
