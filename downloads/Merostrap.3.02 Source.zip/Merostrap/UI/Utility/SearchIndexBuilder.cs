using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using Avalonia;
using Avalonia.Controls;
using Avalonia.VisualTree;
using Merostrap.Models;
using Merostrap.Resources;
using Merostrap.UI.Elements.Controls;

namespace Merostrap.UI.Utility;

internal class SearchIndexBuilder
{
	private readonly Dictionary<string, List<SearchBarItem>> _pageIndexCache = new Dictionary<string, List<SearchBarItem>>();

	private List<SearchBarItem>? _navigationItemsCache;

	public List<SearchBarItem> BuildIndex(List<(string PageTag, string PageTitle, object PageViewModel)> _)
	{
		return GetNavigationItems().ToList();
	}

	private List<SearchBarItem> GetNavigationItems()
	{
		if (_navigationItemsCache != null)
		{
			return _navigationItemsCache;
		}
		var array = new[]
		{
			new
			{
				Display = Strings.Menu_Integrations_Title,
				Tag = "integrations"
			},
			new
			{
				Display = Strings.Menu_Behaviour_Title,
				Tag = "behaviour"
			},
			new
			{
				Display = Strings.Menu_PresetMods_Title,
				Tag = "mods"
			},
			new
			{
				Display = Strings.Menu_FastFlags_Title,
				Tag = "fastflags"
			},
			new
			{
				Display = Strings.Menu_Appearance_Title,
				Tag = "appearance"
			},
			new
			{
				Display = "Preferred region",
				Tag = "quickplay"
			},
			new
			{
				Display = Strings.Menu_GlobalSettings_Title,
				Tag = "globalsettings"
			},
			new
			{
				Display = Strings.Common_Shortcuts,
				Tag = "shortcuts"
			},
			new
			{
				Display = Strings.Common_Deployment,
				Tag = "channels"
			}
		};
		_navigationItemsCache = new List<SearchBarItem>();
		var array2 = array;
		foreach (var anon in array2)
		{
			_navigationItemsCache.Add(new SearchBarItem
			{
				DisplayName = anon.Display,
				Tag = anon.Tag,
				NavigateAction = null,
				PageTag = anon.Tag,
				Category = "Navigation"
			});
		}
		return _navigationItemsCache;
	}

	public void InvalidatePageCache(string pageTag)
	{
		_pageIndexCache.Remove(pageTag);
	}

	public void ClearCache()
	{
		_pageIndexCache.Clear();
		_navigationItemsCache = null;
	}

	public List<SearchBarItem> ScanRenderedPageForElements(Control pageView, string pageTag)
	{
		List<SearchBarItem> list = new List<SearchBarItem>();
		try
		{
			if (_pageIndexCache.ContainsKey(pageTag))
			{
				return list;
			}
			ScanForCardExpanders(pageView, pageTag, "", list);
			ScanForOptionControls(pageView, pageTag, "", list);
			ScanForCardActions(pageView, pageTag, "", list);
			ScanForSquareCards(pageView, pageTag, "", list);
			if (list.Count > 0)
			{
				_pageIndexCache[pageTag] = list;
			}
			return list;
		}
		catch (Exception ex)
		{
			App.Logger.Error("Error scanning rendered page " + pageTag + ": " + ex.Message);
			return list;
		}
	}

	private static void ScanForCardExpanders(Control pageView, string pageTag, string pageTitle, List<SearchBarItem> searchIndex)
	{
		foreach (CardExpander item in pageView.GetVisualDescendants().OfType<CardExpander>())
		{
			string text = (item.Header as string) ?? (item.Header as TextBlock)?.Text;
			if (!string.IsNullOrWhiteSpace(text))
			{
				searchIndex.Add(new SearchBarItem
				{
					DisplayName = text,
					Tag = NormalizeTag(text),
					PageTag = pageTag,
					PageTitle = pageTitle,
					Category = "Section",
					Description = item.Description
				});
			}
		}
	}

	private static void ScanForOptionControls(Control pageView, string pageTag, string pageTitle, List<SearchBarItem> searchIndex)
	{
		foreach (OptionControl item in pageView.GetVisualDescendants().OfType<OptionControl>())
		{
			string header = item.Header;
			if (!string.IsNullOrWhiteSpace(header))
			{
				string parentSectionName = FindParentCardExpander(item)?.Header as string;
				searchIndex.Add(new SearchBarItem
				{
					DisplayName = header,
					Tag = NormalizeTag(header),
					PageTag = pageTag,
					PageTitle = pageTitle,
					Category = "Setting",
					Description = item.Description,
					ParentSectionName = parentSectionName
				});
			}
		}
	}

	private static void ScanForCardActions(Control pageView, string pageTag, string pageTitle, List<SearchBarItem> searchIndex)
	{
		foreach (CardAction item in pageView.GetVisualDescendants().OfType<CardAction>())
		{
			string text = (item.Content as string) ?? (item.Content as TextBlock)?.Text;
			if (!string.IsNullOrWhiteSpace(text))
			{
				searchIndex.Add(new SearchBarItem
				{
					DisplayName = text,
					Tag = NormalizeTag(text),
					PageTag = pageTag,
					PageTitle = pageTitle,
					Category = "Action"
				});
			}
		}
	}

	private static void ScanForSquareCards(Control pageView, string pageTag, string pageTitle, List<SearchBarItem> searchIndex)
	{
		foreach (SquareCard item in pageView.GetVisualDescendants().OfType<SquareCard>())
		{
			string header = item.Header;
			if (!string.IsNullOrWhiteSpace(header))
			{
				searchIndex.Add(new SearchBarItem
				{
					DisplayName = header,
					Tag = NormalizeTag(header),
					PageTag = pageTag,
					PageTitle = pageTitle,
					Category = "Card",
					Description = item.Description
				});
			}
		}
	}

	private static CardExpander? FindParentCardExpander(Control control)
	{
		for (StyledElement styledElement = control.Parent; styledElement != null; styledElement = (styledElement as Control)?.Parent)
		{
			if (styledElement is CardExpander result)
			{
				return result;
			}
		}
		return null;
	}

	private static string NormalizeTag(string text)
	{
		return Regex.Replace(text.ToUpperInvariant(), "[^a-z0-9]+", "-").Trim('-');
	}
}
