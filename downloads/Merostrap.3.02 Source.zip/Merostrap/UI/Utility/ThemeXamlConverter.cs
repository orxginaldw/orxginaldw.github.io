using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace Merostrap.UI.Utility;

internal static class ThemeXamlConverter
{
	private static readonly Dictionary<string, string> PropertyRenameMap = new Dictionary<string, string> { { "Panel.ZIndex", "ZIndex" } };

	private static readonly Dictionary<string, string> BackdropTypeMap = new Dictionary<string, string>
	{
		{ "Mica", "Mica" },
		{ "Acrylic", "Acrylic" },
		{ "Aero", "Aero" },
		{ "Blur", "Aero" },
		{ "None", "None" },
		{ "Disable", "None" },
		{ "Disabled", "None" },
		{ "Default", "None" }
	};

	public static string ConvertThemeXaml(string wpfXaml)
	{
		try
		{
			XDocument xDocument = XDocument.Parse(wpfXaml);
			XElement root = xDocument.Root;
			if (root == null)
			{
				return wpfXaml;
			}
			ConvertPropertiesAndValues(root);
			ConvertControlTypes(root);
			ConvertBackdropAttributes(root);
			return xDocument.ToString();
		}
		catch (Exception)
		{
			return wpfXaml;
		}
	}

	private static void ConvertPropertiesAndValues(XElement element)
	{
		if (element.Name.LocalName == "BloxstrapCustomBootstrapper" || element.Name.LocalName == "Window")
		{
			if (element.Attribute("WindowStyle")?.Value == "None")
			{
				element.SetAttributeValue("SystemDecorations", "None");
			}
			XAttribute xAttribute = element.Attribute("IgnoreTitleBarInset");
			if (xAttribute != null)
			{
				element.SetAttributeValue("IgnoreTitleBarInset", xAttribute.Value.ToUpperInvariant());
			}
			XAttribute xAttribute2 = element.Attribute("BackgroundType");
			if (xAttribute2 != null)
			{
				string valueOrDefault = BackdropTypeMap.GetValueOrDefault(xAttribute2.Value, "None");
				element.SetAttributeValue("WindowBackdropType", valueOrDefault);
				xAttribute2.Remove();
			}
		}
		foreach (XAttribute item in element.Attributes().ToList())
		{
			if (PropertyRenameMap.TryGetValue(item.Name.LocalName, out string value))
			{
				element.SetAttributeValue(value, item.Value);
				if (value != item.Name.LocalName)
				{
					item.Remove();
				}
			}
		}
		foreach (XElement item2 in element.Elements())
		{
			ConvertPropertiesAndValues(item2);
		}
	}

	private static void ConvertControlTypes(XElement element)
	{
		if (element.Name.LocalName == "Label")
		{
			element.Name = element.Name.Namespace + "TextBlock";
		}
		if (element.Name.LocalName == "Window")
		{
			element.Name = element.Name.Namespace + "BloxstrapCustomBootstrapper";
		}
		foreach (XElement item in element.Elements())
		{
			ConvertControlTypes(item);
		}
	}

	private static void ConvertBackdropAttributes(XElement element)
	{
		if (element.Name.LocalName == "BloxstrapCustomBootstrapper" || element.Name.LocalName == "Window")
		{
			XAttribute xAttribute = element.Attribute("WindowBackdropType");
			if (xAttribute != null)
			{
				string value = xAttribute.Value;
				if (BackdropTypeMap.TryGetValue(value, out string value2))
				{
					element.SetAttributeValue("WindowBackdropType", value2);
				}
				else
				{
					element.SetAttributeValue("WindowBackdropType", "None");
				}
			}
		}
		foreach (XElement item in element.Elements())
		{
			ConvertBackdropAttributes(item);
		}
	}
}
