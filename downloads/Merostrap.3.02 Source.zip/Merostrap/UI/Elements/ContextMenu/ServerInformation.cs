using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Data;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Threading;
using CompiledAvaloniaXaml;
using Merostrap.Integrations;
using Merostrap.Resources;
using Merostrap.UI.Elements.Base;
using Merostrap.UI.ViewModels.ContextMenu;

namespace Merostrap.UI.Elements.ContextMenu;

internal class ServerInformation : AvaloniaWindow
{
	private readonly Watcher? _watcher;

	private readonly ServerInformationViewModel _viewModel;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public ServerInformation()
	{
		InitializeComponent();
		_viewModel = new ServerInformationViewModel();
		DataContext = _viewModel;
	}

	public ServerInformation(Watcher watcher)
		: this()
	{
		_watcher = watcher;
		ActivityWatcher activityWatcher = _watcher?.ActivityWatcher;
		if (activityWatcher != null)
		{
			_viewModel.SetWatcher(activityWatcher);
			activityWatcher.OnGameJoin += OnGameJoin;
			activityWatcher.OnGameLeave += OnGameLeave;
			activityWatcher.ShowNotif += OnShowNotif;
			if (activityWatcher.InGame)
			{
				UpdateViewModel(activityWatcher);
				_viewModel.RefreshLocation();
				_viewModel.RefreshUptime();
			}
		}
	}

	private void OnGameJoin(object? sender, EventArgs e)
	{
		ActivityWatcher aw = sender as ActivityWatcher;
		if (aw != null)
		{
			Avalonia.Threading.Dispatcher.UIThread.Invoke(() =>
			{
				UpdateViewModel(aw);
				_viewModel.RefreshLocation();
				_viewModel.RefreshUptime();
			});
		}
	}

	private void OnGameLeave(object? sender, EventArgs e)
	{
		Avalonia.Threading.Dispatcher.UIThread.Invoke(() =>
		{
			_viewModel.ClearData();
		});
	}

	private void OnShowNotif(object? sender, EventArgs e)
	{
		Avalonia.Threading.Dispatcher.UIThread.Invoke(() =>
		{
			_viewModel.RefreshUptime();
			_viewModel.RefreshLocation();
		});
	}

	private void UpdateViewModel(ActivityWatcher aw)
	{
		_viewModel.UpdateData(aw.Data);
	}

	protected override void OnClosed(EventArgs e)
	{
		ActivityWatcher activityWatcher = _watcher?.ActivityWatcher;
		if (activityWatcher != null)
		{
			activityWatcher.OnGameJoin -= OnGameJoin;
			activityWatcher.OnGameLeave -= OnGameLeave;
			activityWatcher.ShowNotif -= OnShowNotif;
		}
		_viewModel.StopUptimeUpdates();
		base.OnClosed(e);
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, ServerInformation P_1)
	{
		XamlIlContext.Context<ServerInformation> context = new XamlIlContext.Context<ServerInformation>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FContextMenu_002FServerInformation_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/ContextMenu/ServerInformation.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Title = Strings.ContextMenu_ServerInformation_Title;
		P_1.Width = 420.0;
		P_1.SizeToContent = SizeToContent.Height;
		P_1.CanResize = false;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid5.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid5.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children.Add(grid6);
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		Grid.SetRow(grid9, 0);
		grid9.Margin = new Thickness(16.0, 8.0, 16.0, 16.0);
		Avalonia.Controls.Controls children2 = grid9.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children2.Add(textBlock);
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = textBlock2);
		context.PushParent(textBlock4);
		TextBlock textBlock5 = textBlock4;
		Grid.SetRow(textBlock5, 0);
		textBlock5.Text = Strings.ContextMenu_ServerInformation_NotInAServer;
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EContextMenu_002EServerInformationViewModel_002CMerostrap_002EHasServerData_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock5.Bind(isVisibleProperty, binding);
		textBlock5.HorizontalAlignment = HorizontalAlignment.Center;
		textBlock5.VerticalAlignment = VerticalAlignment.Center;
		textBlock5.Margin = new Thickness(0.0, 20.0, 0.0, 20.0);
		context.PopParent();
		((ISupportInitialize)textBlock3).EndInit();
		Avalonia.Controls.Controls children3 = grid9.Children;
		Grid grid11;
		Grid grid10 = (grid11 = new Grid());
		((ISupportInitialize)grid10).BeginInit();
		children3.Add(grid10);
		Grid grid12 = (grid4 = grid11);
		context.PushParent(grid4);
		Grid grid13 = grid4;
		StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EContextMenu_002EServerInformationViewModel_002CMerostrap_002EHasServerData_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		grid13.Bind(isVisibleProperty2, binding2);
		RowDefinitions rowDefinitions2 = new RowDefinitions();
		rowDefinitions2.Capacity = 5;
		rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid13.RowDefinitions = rowDefinitions2;
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 2;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid13.ColumnDefinitions = columnDefinitions;
		Avalonia.Controls.Controls children4 = grid13.Children;
		TextBlock textBlock7;
		TextBlock textBlock6 = (textBlock7 = new TextBlock());
		((ISupportInitialize)textBlock6).BeginInit();
		children4.Add(textBlock6);
		Grid.SetRow(textBlock7, 0);
		Grid.SetColumn(textBlock7, 0);
		textBlock7.Margin = new Thickness(0.0, 0.0, 16.0, 12.0);
		textBlock7.VerticalAlignment = VerticalAlignment.Center;
		textBlock7.Text = Strings.ContextMenu_ServerInformation_Type;
		((ISupportInitialize)textBlock7).EndInit();
		Avalonia.Controls.Controls children5 = grid13.Children;
		TextBlock textBlock9;
		TextBlock textBlock8 = (textBlock9 = new TextBlock());
		((ISupportInitialize)textBlock8).BeginInit();
		children5.Add(textBlock8);
		TextBlock textBlock10 = (textBlock4 = textBlock9);
		context.PushParent(textBlock4);
		TextBlock textBlock11 = textBlock4;
		Grid.SetRow(textBlock11, 0);
		Grid.SetColumn(textBlock11, 1);
		StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("TextFillColorTertiaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding3 = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock11.Bind(foregroundProperty, binding3);
		StyledProperty<string?> textProperty = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EContextMenu_002EServerInformationViewModel_002CMerostrap_002EServerType_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding4 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock11.Bind(textProperty, binding4);
		context.PopParent();
		((ISupportInitialize)textBlock10).EndInit();
		Avalonia.Controls.Controls children6 = grid13.Children;
		TextBlock textBlock13;
		TextBlock textBlock12 = (textBlock13 = new TextBlock());
		((ISupportInitialize)textBlock12).BeginInit();
		children6.Add(textBlock12);
		TextBlock textBlock14 = (textBlock4 = textBlock13);
		context.PushParent(textBlock4);
		TextBlock textBlock15 = textBlock4;
		Grid.SetRow(textBlock15, 1);
		Grid.SetColumn(textBlock15, 0);
		textBlock15.Margin = new Thickness(0.0, 0.0, 16.0, 12.0);
		textBlock15.VerticalAlignment = VerticalAlignment.Center;
		textBlock15.Text = Strings.ContextMenu_ServerInformation_InstanceId;
		StyledProperty<bool> isVisibleProperty3 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EContextMenu_002EServerInformationViewModel_002CMerostrap_002EShowInstanceId_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding5 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock15.Bind(isVisibleProperty3, binding5);
		context.PopParent();
		((ISupportInitialize)textBlock14).EndInit();
		Avalonia.Controls.Controls children7 = grid13.Children;
		TextBlock textBlock17;
		TextBlock textBlock16 = (textBlock17 = new TextBlock());
		((ISupportInitialize)textBlock16).BeginInit();
		children7.Add(textBlock16);
		TextBlock textBlock18 = (textBlock4 = textBlock17);
		context.PushParent(textBlock4);
		TextBlock textBlock19 = textBlock4;
		Grid.SetRow(textBlock19, 1);
		Grid.SetColumn(textBlock19, 1);
		StyledProperty<IBrush?> foregroundProperty2 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("TextFillColorTertiaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding6 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock19.Bind(foregroundProperty2, binding6);
		StyledProperty<string?> textProperty2 = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EContextMenu_002EServerInformationViewModel_002CMerostrap_002EInstanceId_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding7 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock19.Bind(textProperty2, binding7);
		StyledProperty<bool> isVisibleProperty4 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EContextMenu_002EServerInformationViewModel_002CMerostrap_002EShowInstanceId_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding8 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock19.Bind(isVisibleProperty4, binding8);
		context.PopParent();
		((ISupportInitialize)textBlock18).EndInit();
		Avalonia.Controls.Controls children8 = grid13.Children;
		TextBlock textBlock21;
		TextBlock textBlock20 = (textBlock21 = new TextBlock());
		((ISupportInitialize)textBlock20).BeginInit();
		children8.Add(textBlock20);
		TextBlock textBlock22 = (textBlock4 = textBlock21);
		context.PushParent(textBlock4);
		TextBlock textBlock23 = textBlock4;
		Grid.SetRow(textBlock23, 2);
		Grid.SetColumn(textBlock23, 0);
		textBlock23.Margin = new Thickness(0.0, 0.0, 16.0, 12.0);
		textBlock23.VerticalAlignment = VerticalAlignment.Center;
		textBlock23.Text = Strings.ContextMenu_ServerInformation_AccessCode;
		StyledProperty<bool> isVisibleProperty5 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EContextMenu_002EServerInformationViewModel_002CMerostrap_002EAccessCodeVisibility_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding9 = compiledBindingExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock23.Bind(isVisibleProperty5, binding9);
		context.PopParent();
		((ISupportInitialize)textBlock22).EndInit();
		Avalonia.Controls.Controls children9 = grid13.Children;
		TextBlock textBlock25;
		TextBlock textBlock24 = (textBlock25 = new TextBlock());
		((ISupportInitialize)textBlock24).BeginInit();
		children9.Add(textBlock24);
		TextBlock textBlock26 = (textBlock4 = textBlock25);
		context.PushParent(textBlock4);
		TextBlock textBlock27 = textBlock4;
		Grid.SetRow(textBlock27, 2);
		Grid.SetColumn(textBlock27, 1);
		StyledProperty<IBrush?> foregroundProperty3 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("TextFillColorTertiaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding10 = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock27.Bind(foregroundProperty3, binding10);
		StyledProperty<string?> textProperty3 = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EContextMenu_002EServerInformationViewModel_002CMerostrap_002EAccessCode_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding11 = compiledBindingExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock27.Bind(textProperty3, binding11);
		StyledProperty<bool> isVisibleProperty6 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EContextMenu_002EServerInformationViewModel_002CMerostrap_002EAccessCodeVisibility_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding12 = compiledBindingExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock27.Bind(isVisibleProperty6, binding12);
		context.PopParent();
		((ISupportInitialize)textBlock26).EndInit();
		Avalonia.Controls.Controls children10 = grid13.Children;
		TextBlock textBlock29;
		TextBlock textBlock28 = (textBlock29 = new TextBlock());
		((ISupportInitialize)textBlock28).BeginInit();
		children10.Add(textBlock28);
		TextBlock textBlock30 = (textBlock4 = textBlock29);
		context.PushParent(textBlock4);
		TextBlock textBlock31 = textBlock4;
		Grid.SetRow(textBlock31, 3);
		Grid.SetColumn(textBlock31, 0);
		textBlock31.Margin = new Thickness(0.0, 0.0, 16.0, 12.0);
		textBlock31.VerticalAlignment = VerticalAlignment.Center;
		textBlock31.Text = Strings.ContextMenu_ServerInformation_Location;
		StyledProperty<bool> isVisibleProperty7 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EContextMenu_002EServerInformationViewModel_002CMerostrap_002EServerLocationVisibility_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding13 = compiledBindingExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock31.Bind(isVisibleProperty7, binding13);
		context.PopParent();
		((ISupportInitialize)textBlock30).EndInit();
		Avalonia.Controls.Controls children11 = grid13.Children;
		TextBlock textBlock33;
		TextBlock textBlock32 = (textBlock33 = new TextBlock());
		((ISupportInitialize)textBlock32).BeginInit();
		children11.Add(textBlock32);
		TextBlock textBlock34 = (textBlock4 = textBlock33);
		context.PushParent(textBlock4);
		TextBlock textBlock35 = textBlock4;
		Grid.SetRow(textBlock35, 3);
		Grid.SetColumn(textBlock35, 1);
		StyledProperty<IBrush?> foregroundProperty4 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("TextFillColorTertiaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding14 = dynamicResourceExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock35.Bind(foregroundProperty4, binding14);
		StyledProperty<string?> textProperty4 = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EContextMenu_002EServerInformationViewModel_002CMerostrap_002EServerLocation_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding15 = compiledBindingExtension11.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock35.Bind(textProperty4, binding15);
		StyledProperty<bool> isVisibleProperty8 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EContextMenu_002EServerInformationViewModel_002CMerostrap_002EServerLocationVisibility_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding16 = compiledBindingExtension12.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock35.Bind(isVisibleProperty8, binding16);
		context.PopParent();
		((ISupportInitialize)textBlock34).EndInit();
		Avalonia.Controls.Controls children12 = grid13.Children;
		TextBlock textBlock37;
		TextBlock textBlock36 = (textBlock37 = new TextBlock());
		((ISupportInitialize)textBlock36).BeginInit();
		children12.Add(textBlock36);
		TextBlock textBlock38 = (textBlock4 = textBlock37);
		context.PushParent(textBlock4);
		TextBlock textBlock39 = textBlock4;
		Grid.SetRow(textBlock39, 4);
		Grid.SetColumn(textBlock39, 0);
		textBlock39.Margin = new Thickness(0.0, 0.0, 16.0, 12.0);
		textBlock39.VerticalAlignment = VerticalAlignment.Center;
		textBlock39.Text = Strings.ContextMenu_ServerInformation_Uptime;
		StyledProperty<bool> isVisibleProperty9 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EContextMenu_002EServerInformationViewModel_002CMerostrap_002EServerUptimeVisibility_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding17 = compiledBindingExtension13.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock39.Bind(isVisibleProperty9, binding17);
		context.PopParent();
		((ISupportInitialize)textBlock38).EndInit();
		Avalonia.Controls.Controls children13 = grid13.Children;
		TextBlock textBlock41;
		TextBlock textBlock40 = (textBlock41 = new TextBlock());
		((ISupportInitialize)textBlock40).BeginInit();
		children13.Add(textBlock40);
		TextBlock textBlock42 = (textBlock4 = textBlock41);
		context.PushParent(textBlock4);
		TextBlock textBlock43 = textBlock4;
		Grid.SetRow(textBlock43, 4);
		Grid.SetColumn(textBlock43, 1);
		StyledProperty<IBrush?> foregroundProperty5 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension5 = new DynamicResourceExtension("TextFillColorTertiaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding18 = dynamicResourceExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock43.Bind(foregroundProperty5, binding18);
		StyledProperty<string?> textProperty5 = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EContextMenu_002EServerInformationViewModel_002CMerostrap_002EServerUptime_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding19 = compiledBindingExtension14.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock43.Bind(textProperty5, binding19);
		StyledProperty<bool> isVisibleProperty10 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension15 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EContextMenu_002EServerInformationViewModel_002CMerostrap_002EServerUptimeVisibility_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding20 = compiledBindingExtension15.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock43.Bind(isVisibleProperty10, binding20);
		context.PopParent();
		((ISupportInitialize)textBlock42).EndInit();
		context.PopParent();
		((ISupportInitialize)grid12).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		Avalonia.Controls.Controls children14 = grid5.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children14.Add(border);
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Grid.SetRow(border4, 1);
		border4.Padding = new Thickness(15.0, 15.0, 15.0, 15.0);
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension6 = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding21 = dynamicResourceExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border4.Bind(backgroundProperty, binding21);
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		border4.Child = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		stackPanel4.Orientation = Orientation.Horizontal;
		stackPanel4.FlowDirection = FlowDirection.LeftToRight;
		stackPanel4.HorizontalAlignment = HorizontalAlignment.Right;
		Avalonia.Controls.Controls children15 = stackPanel4.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children15.Add(button);
		Button button4;
		Button button3 = (button4 = button2);
		context.PushParent(button4);
		Button button5 = button4;
		button5.MinWidth = 100.0;
		CompiledBindingExtension compiledBindingExtension16 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EContextMenu_002EServerInformationViewModel_002CMerostrap_002ECopyButtonText_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ContentControl.ContentProperty;
		CompiledBinding compiledBinding = compiledBindingExtension16.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_4(button5, compiledBinding);
		StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension17 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EContextMenu_002EServerInformationViewModel_002CMerostrap_002ECopyCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding22 = compiledBindingExtension17.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button5.Bind(commandProperty, binding22);
		CompiledBindingExtension compiledBindingExtension18 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Self().Build());
		context.ProvideTargetProperty = Button.CommandParameterProperty;
		CompiledBinding compiledBinding2 = compiledBindingExtension18.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_6(button5, compiledBinding2);
		StyledProperty<bool> isVisibleProperty11 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension19 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EContextMenu_002EServerInformationViewModel_002CMerostrap_002EHasServerData_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding23 = compiledBindingExtension19.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button5.Bind(isVisibleProperty11, binding23);
		context.PopParent();
		((ISupportInitialize)button3).EndInit();
		Avalonia.Controls.Controls children16 = stackPanel4.Children;
		Button button7;
		Button button6 = (button7 = new Button());
		((ISupportInitialize)button6).BeginInit();
		children16.Add(button6);
		Button button8 = (button4 = button7);
		context.PushParent(button4);
		Button button9 = button4;
		button9.Margin = new Thickness(12.0, 0.0, 0.0, 0.0);
		button9.MinWidth = 100.0;
		button9.Content = Strings.Common_Close;
		StyledProperty<ICommand?> commandProperty2 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension20 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EContextMenu_002EServerInformationViewModel_002CMerostrap_002ECloseCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding24 = compiledBindingExtension20.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button9.Bind(commandProperty2, binding24);
		CompiledBindingExtension compiledBindingExtension21 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Ancestor(typeof(Window), 0).Build());
		context.ProvideTargetProperty = Button.CommandParameterProperty;
		CompiledBinding compiledBinding3 = compiledBindingExtension21.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_6(button9, compiledBinding3);
		context.PopParent();
		((ISupportInitialize)button8).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(ServerInformation P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
