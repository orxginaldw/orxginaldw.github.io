using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Data;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using Avalonia.Styling;
using CompiledAvaloniaXaml;
using FluentAvalonia.UI.Controls;
using LucideAvalonia.Enum;
using Merostrap.Integrations;
using Merostrap.Resources;
using Merostrap.UI.Elements.Base;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.ViewModels.ContextMenu;

namespace Merostrap.UI.Elements.ContextMenu;

internal class ServerHistory : AvaloniaWindow
{
	[CompilerGenerated]
	private class XamlClosure_8
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<ServerHistory> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Border border = (Border)obj;
			context.PushParent(border);
			Border border2 = border;
			StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("ControlFillColorDefaultBrush");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border2.Bind(backgroundProperty, binding);
			StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
			DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("ControlStrokeColorDefaultBrush");
			context.ProvideTargetProperty = Border.BorderBrushProperty;
			BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border2.Bind(borderBrushProperty, binding2);
			border2.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
			border2.CornerRadius = new CornerRadius(8.0, 8.0, 8.0, 8.0);
			border2.Margin = new Thickness(0.0, 4.0, 0.0, 4.0);
			border2.Padding = new Thickness(8.0, 8.0, 8.0, 8.0);
			Grid grid2;
			Grid grid = (grid2 = new Grid());
			((ISupportInitialize)grid).BeginInit();
			border2.Child = grid;
			Grid grid4;
			Grid grid3 = (grid4 = grid2);
			context.PushParent(grid4);
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 2;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid4.ColumnDefinitions = columnDefinitions;
			Avalonia.Controls.Controls children = grid4.Children;
			Border border4;
			Border border3 = (border4 = new Border());
			((ISupportInitialize)border3).BeginInit();
			children.Add(border3);
			Border border5 = (border = border4);
			context.PushParent(border);
			Border border6 = border;
			Grid.SetColumn(border6, 0);
			border6.Width = 107.0;
			border6.Height = 107.0;
			border6.CornerRadius = new CornerRadius(4.0, 4.0, 4.0, 4.0);
			border6.ClipToBounds = true;
			Image image2;
			Image image = (image2 = new Image());
			((ISupportInitialize)image).BeginInit();
			border6.Child = image;
			Image image4;
			Image image3 = (image4 = image2);
			context.PushParent(image4);
			StyledProperty<IImage?> sourceProperty = Image.SourceProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EEntities_002EActivityData_002CMerostrap_002EThumbnailBitmap_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Image.SourceProperty;
			CompiledBinding binding3 = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			image4.Bind(sourceProperty, binding3);
			image4.Stretch = Stretch.UniformToFill;
			context.PopParent();
			((ISupportInitialize)image3).EndInit();
			context.PopParent();
			((ISupportInitialize)border5).EndInit();
			Avalonia.Controls.Controls children2 = grid4.Children;
			StackPanel stackPanel2;
			StackPanel stackPanel = (stackPanel2 = new StackPanel());
			((ISupportInitialize)stackPanel).BeginInit();
			children2.Add(stackPanel);
			StackPanel stackPanel4;
			StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
			context.PushParent(stackPanel4);
			StackPanel stackPanel5 = stackPanel4;
			Grid.SetColumn(stackPanel5, 1);
			stackPanel5.Margin = new Thickness(16.0, 0.0, 4.0, 0.0);
			stackPanel5.VerticalAlignment = VerticalAlignment.Center;
			stackPanel5.Spacing = 2.0;
			Avalonia.Controls.Controls children3 = stackPanel5.Children;
			TextBlock textBlock2;
			TextBlock textBlock = (textBlock2 = new TextBlock());
			((ISupportInitialize)textBlock).BeginInit();
			children3.Add(textBlock);
			TextBlock textBlock4;
			TextBlock textBlock3 = (textBlock4 = textBlock2);
			context.PushParent(textBlock4);
			TextBlock textBlock5 = textBlock4;
			textBlock5.FontSize = 16.0;
			textBlock5.FontWeight = FontWeight.DemiBold;
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EEntities_002EActivityData_002CMerostrap_002EUniverseDetails_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EModels_002EEntities_002EUniverseDetails_002CMerostrap_002EData_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EModels_002EAPIs_002ERoblox_002EGameDetailResponse_002CMerostrap_002EName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)
				.Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding4 = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock5.Bind(textProperty, binding4);
			context.PopParent();
			((ISupportInitialize)textBlock3).EndInit();
			Avalonia.Controls.Controls children4 = stackPanel5.Children;
			TextBlock textBlock7;
			TextBlock textBlock6 = (textBlock7 = new TextBlock());
			((ISupportInitialize)textBlock6).BeginInit();
			children4.Add(textBlock6);
			TextBlock textBlock8 = (textBlock4 = textBlock7);
			context.PushParent(textBlock4);
			TextBlock textBlock9 = textBlock4;
			StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
			DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("TextFillColorSecondaryBrush");
			context.ProvideTargetProperty = TextBlock.ForegroundProperty;
			BindingBase binding5 = dynamicResourceExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock9.Bind(foregroundProperty, binding5);
			StyledProperty<string?> textProperty2 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EEntities_002EActivityData_002CMerostrap_002EJobId_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding6 = compiledBindingExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock9.Bind(textProperty2, binding6);
			textBlock9.FontSize = 11.0;
			context.PopParent();
			((ISupportInitialize)textBlock8).EndInit();
			Avalonia.Controls.Controls children5 = stackPanel5.Children;
			StackPanel stackPanel7;
			StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
			((ISupportInitialize)stackPanel6).BeginInit();
			children5.Add(stackPanel6);
			StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
			context.PushParent(stackPanel4);
			StackPanel stackPanel9 = stackPanel4;
			stackPanel9.Margin = new Thickness(0.0, 10.0, 0.0, 0.0);
			stackPanel9.Orientation = Orientation.Horizontal;
			stackPanel9.Spacing = 8.0;
			Avalonia.Controls.Controls children6 = stackPanel9.Children;
			IconButton iconButton2;
			IconButton iconButton = (iconButton2 = new IconButton());
			((ISupportInitialize)iconButton).BeginInit();
			children6.Add(iconButton);
			IconButton iconButton4;
			IconButton iconButton3 = (iconButton4 = iconButton2);
			context.PushParent(iconButton4);
			IconButton iconButton5 = iconButton4;
			iconButton5.Icon = LucideIconNames.Play;
			iconButton5.Content = Strings.ContextMenu_GameHistory_Rejoin;
			StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EEntities_002EActivityData_002CMerostrap_002ERejoinServerCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Button.CommandProperty;
			CompiledBinding binding7 = compiledBindingExtension4.ProvideValue(context);
			context.ProvideTargetProperty = null;
			iconButton5.Bind(commandProperty, binding7);
			iconButton5.Classes.Add("Primary");
			context.PopParent();
			((ISupportInitialize)iconButton3).EndInit();
			Avalonia.Controls.Controls children7 = stackPanel9.Children;
			IconButton iconButton7;
			IconButton iconButton6 = (iconButton7 = new IconButton());
			((ISupportInitialize)iconButton6).BeginInit();
			children7.Add(iconButton6);
			IconButton iconButton8 = (iconButton4 = iconButton7);
			context.PushParent(iconButton4);
			IconButton iconButton9 = iconButton4;
			iconButton9.Icon = LucideIconNames.Link2;
			iconButton9.Content = Strings.Common_Deeplink;
			StyledProperty<ICommand?> commandProperty2 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EEntities_002EActivityData_002CMerostrap_002ECopyDeeplinkCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Button.CommandProperty;
			CompiledBinding binding8 = compiledBindingExtension5.ProvideValue(context);
			context.ProvideTargetProperty = null;
			iconButton9.Bind(commandProperty2, binding8);
			CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Self().Build());
			context.ProvideTargetProperty = Button.CommandParameterProperty;
			CompiledBinding compiledBinding = compiledBindingExtension6.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_6(iconButton9, compiledBinding);
			context.PopParent();
			((ISupportInitialize)iconButton8).EndInit();
			Avalonia.Controls.Controls children8 = stackPanel9.Children;
			IconButton iconButton11;
			IconButton iconButton10 = (iconButton11 = new IconButton());
			((ISupportInitialize)iconButton10).BeginInit();
			children8.Add(iconButton10);
			IconButton iconButton12 = (iconButton4 = iconButton11);
			context.PushParent(iconButton4);
			IconButton iconButton13 = iconButton4;
			iconButton13.Icon = LucideIconNames.Clipboard;
			iconButton13.Content = Strings.Common_ServerID;
			StyledProperty<ICommand?> commandProperty3 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EEntities_002EActivityData_002CMerostrap_002ECopyServerIdCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Button.CommandProperty;
			CompiledBinding binding9 = compiledBindingExtension7.ProvideValue(context);
			context.ProvideTargetProperty = null;
			iconButton13.Bind(commandProperty3, binding9);
			CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Self().Build());
			context.ProvideTargetProperty = Button.CommandParameterProperty;
			CompiledBinding compiledBinding2 = compiledBindingExtension8.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_6(iconButton13, compiledBinding2);
			context.PopParent();
			((ISupportInitialize)iconButton12).EndInit();
			Avalonia.Controls.Controls children9 = stackPanel9.Children;
			IconButton iconButton15;
			IconButton iconButton14 = (iconButton15 = new IconButton());
			((ISupportInitialize)iconButton14).BeginInit();
			children9.Add(iconButton14);
			IconButton iconButton16 = (iconButton4 = iconButton15);
			context.PushParent(iconButton4);
			IconButton iconButton17 = iconButton4;
			iconButton17.Icon = LucideIconNames.Trash2;
			StyledProperty<ICommand?> commandProperty4 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EEntities_002EActivityData_002CMerostrap_002EDeleteHistoryCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Button.CommandProperty;
			CompiledBinding binding10 = compiledBindingExtension9.ProvideValue(context);
			context.ProvideTargetProperty = null;
			iconButton17.Bind(commandProperty4, binding10);
			iconButton17.Classes.Add("Danger");
			context.PopParent();
			((ISupportInitialize)iconButton16).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel8).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel3).EndInit();
			context.PopParent();
			((ISupportInitialize)grid3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<ServerHistory> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<ServerHistory> context = new XamlIlContext.Context<ServerHistory>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FContextMenu_002FServerHistory_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/ContextMenu/ServerHistory.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (ServerHistory)service;
				}
			}
			return context;
		}
	}

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public ServerHistory()
	{
		InitializeComponent();
	}

	public ServerHistory(ActivityWatcher watcher)
		: this()
	{
		ServerHistoryViewModel serverHistoryViewModel = new ServerHistoryViewModel(watcher);
		serverHistoryViewModel.RequestCloseEvent = (EventHandler)Delegate.Combine(serverHistoryViewModel.RequestCloseEvent, (EventHandler)((object? _, EventArgs _) =>
		{
			Close();
		}));
		DataContext = serverHistoryViewModel;
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, ServerHistory P_1)
	{
		XamlIlContext.Context<ServerHistory> context = new XamlIlContext.Context<ServerHistory>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FContextMenu_002FServerHistory_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/ContextMenu/ServerHistory.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Title = Strings.ContextMenu_GameHistory_Title;
		P_1.Width = 580.0;
		P_1.Height = 420.0;
		P_1.MinWidth = 420.0;
		P_1.MinHeight = 420.0;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		Styles styles = P_1.Styles;
		Style style = new Style();
		style.Selector = ((Selector?)null).OfType(typeof(TextBlock)).Class("errorView");
		Setter setter = new Setter();
		setter.Property = Visual.IsVisibleProperty;
		setter.Value = false;
		style.Add(setter);
		styles.Add(style);
		Styles styles2 = P_1.Styles;
		Style style2 = new Style();
		style2.Selector = ((Selector?)null).OfType(typeof(TextBlock)).Class("errorView").PropertyEquals((AvaloniaProperty)Control.TagProperty, (object?)"Failed");
		Setter setter2 = new Setter();
		setter2.Property = Visual.IsVisibleProperty;
		setter2.Value = true;
		style2.Add(setter2);
		styles2.Add(style2);
		Styles styles3 = P_1.Styles;
		Style style3 = new Style();
		style3.Selector = ((Selector?)null).OfType(typeof(Border)).Class("loadingView");
		Setter setter3 = new Setter();
		setter3.Property = Visual.IsVisibleProperty;
		setter3.Value = false;
		style3.Add(setter3);
		styles3.Add(style3);
		Styles styles4 = P_1.Styles;
		Style style4 = new Style();
		style4.Selector = ((Selector?)null).OfType(typeof(Border)).Class("loadingView").PropertyEquals((AvaloniaProperty)Control.TagProperty, (object?)"Unknown");
		Setter setter4 = new Setter();
		setter4.Property = Visual.IsVisibleProperty;
		setter4.Value = true;
		style4.Add(setter4);
		styles4.Add(style4);
		Styles styles5 = P_1.Styles;
		Style style5 = new Style();
		style5.Selector = ((Selector?)null).OfType(typeof(ListBox)).Class("contentView");
		Setter setter5 = new Setter();
		setter5.Property = Visual.IsVisibleProperty;
		setter5.Value = false;
		style5.Add(setter5);
		styles5.Add(style5);
		Styles styles6 = P_1.Styles;
		Style style6 = new Style();
		style6.Selector = ((Selector?)null).OfType(typeof(ListBox)).Class("contentView").PropertyEquals((AvaloniaProperty)Control.TagProperty, (object?)"Successful");
		Setter setter6 = new Setter();
		setter6.Property = Visual.IsVisibleProperty;
		setter6.Value = true;
		style6.Add(setter6);
		styles6.Add(style6);
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid4.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid4.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children.Add(textBlock);
		Grid.SetRow(textBlock2, 0);
		textBlock2.Margin = new Thickness(16.0, 8.0, 16.0, 0.0);
		textBlock2.Text = Strings.ContextMenu_GameHistory_Description;
		textBlock2.TextWrapping = TextWrapping.Wrap;
		((ISupportInitialize)textBlock2).EndInit();
		Avalonia.Controls.Controls children2 = grid4.Children;
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		children2.Add(textBlock3);
		TextBlock textBlock6;
		TextBlock textBlock5 = (textBlock6 = textBlock4);
		context.PushParent(textBlock6);
		Grid.SetRow(textBlock6, 1);
		textBlock6.Classes.Add("errorView");
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EContextMenu_002EServerHistoryViewModel_002CMerostrap_002ELoadState_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Control.TagProperty;
		CompiledBinding compiledBinding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_5(textBlock6, compiledBinding);
		textBlock6.Margin = new Thickness(16.0, 8.0, 16.0, 0.0);
		textBlock6.HorizontalAlignment = HorizontalAlignment.Center;
		textBlock6.VerticalAlignment = VerticalAlignment.Center;
		StyledProperty<string?> textProperty = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EContextMenu_002EServerHistoryViewModel_002CMerostrap_002EError_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock6.Bind(textProperty, binding);
		textBlock6.TextWrapping = TextWrapping.Wrap;
		context.PopParent();
		((ISupportInitialize)textBlock5).EndInit();
		Avalonia.Controls.Controls children3 = grid4.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children3.Add(border);
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Grid.SetRow(border4, 1);
		border4.Classes.Add("loadingView");
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EContextMenu_002EServerHistoryViewModel_002CMerostrap_002ELoadState_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Control.TagProperty;
		CompiledBinding compiledBinding2 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_5(border4, compiledBinding2);
		FAProgressRing fAProgressRing2;
		FAProgressRing fAProgressRing = (fAProgressRing2 = new FAProgressRing());
		((ISupportInitialize)fAProgressRing).BeginInit();
		border4.Child = fAProgressRing;
		fAProgressRing2.IsIndeterminate = true;
		fAProgressRing2.Width = 100.0;
		fAProgressRing2.Height = 100.0;
		fAProgressRing2.VerticalAlignment = VerticalAlignment.Center;
		fAProgressRing2.HorizontalAlignment = HorizontalAlignment.Center;
		((ISupportInitialize)fAProgressRing2).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		Avalonia.Controls.Controls children4 = grid4.Children;
		ListBox listBox2;
		ListBox listBox = (listBox2 = new ListBox());
		((ISupportInitialize)listBox).BeginInit();
		children4.Add(listBox);
		ListBox listBox4;
		ListBox listBox3 = (listBox4 = listBox2);
		context.PushParent(listBox4);
		Grid.SetRow(listBox4, 1);
		listBox4.Classes.Add("contentView");
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EContextMenu_002EServerHistoryViewModel_002CMerostrap_002ELoadState_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Control.TagProperty;
		CompiledBinding compiledBinding3 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_5(listBox4, compiledBinding3);
		listBox4.Margin = new Thickness(8.0, 8.0, 8.0, 8.0);
		listBox4.Background = new ImmutableSolidColorBrush(16777215u);
		StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EContextMenu_002EServerHistoryViewModel_002CMerostrap_002EGameHistory_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding2 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		listBox4.Bind(itemsSourceProperty, binding2);
		DataTemplate dataTemplate;
		DataTemplate itemTemplate = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_8.Build_1), context);
		context.PopParent();
		listBox4.ItemTemplate = itemTemplate;
		context.PopParent();
		((ISupportInitialize)listBox3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(ServerHistory P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
