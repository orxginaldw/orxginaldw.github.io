using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Runtime.CompilerServices;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Controls.Primitives;
using Avalonia.Input.Platform;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Threading;
using CompiledAvaloniaXaml;
using Merostrap.Backend;
using Merostrap.Enums;
using Merostrap.Integrations;
using Merostrap.Resources;
using Merostrap.UI.Elements.Base;

namespace Merostrap.UI.Elements.ContextMenu;

internal class MenuContainer : AvaloniaWindow
{
	private readonly Watcher? _watcher;

	private ServerInformation? _serverInformationWindow;

	private ServerHistory? _gameHistoryWindow;

	private readonly Stopwatch _totalPlaytimeStopwatch = new Stopwatch();

	private readonly TimeSpan _accumulatedTotalPlaytime = TimeSpan.Zero;

	private DispatcherTimer? _playtimeTimer;

	private DateTime? _studioPlaceJoinTime;

	private NativeMenuItem? VersionMenuItem;

	private NativeMenuItem? PlaytimeMenuItem;

	private NativeMenuItem? RichPresenceMenuItem;

	private NativeMenuItem? SoftkeyMenuItem;

	private NativeMenuItem? InviteDeeplinkMenuItem;

	private NativeMenuItem? AutoJoinRegionMenuItem;

	private NativeMenuItem? ServerDetailsMenuItem;

	private NativeMenuItem? GameHistoryMenuItem;

	private NativeMenuItem? CloseRobloxMenuItem;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	private ActivityWatcher? ActivityWatcher => _watcher?.ActivityWatcher;

	public MenuContainer()
	{
		InitializeComponent();
		MapNativeMenuItems();
		if (Application.Current?.ApplicationLifetime is IClassicDesktopStyleApplicationLifetime classicDesktopStyleApplicationLifetime)
		{
			classicDesktopStyleApplicationLifetime.ShutdownMode = ShutdownMode.OnExplicitShutdown;
		}
		Closing += (object? s, WindowClosingEventArgs e) =>
		{
			e.Cancel = true;
			Hide();
		};
	}

	private void MapNativeMenuItems()
	{
		NativeMenu menu = NativeMenu.GetMenu(this);
		if (menu != null)
		{
			List<NativeMenuItem> source = menu.Items.OfType<NativeMenuItem>().ToList();
			VersionMenuItem = source.ElementAtOrDefault(0);
			PlaytimeMenuItem = source.ElementAtOrDefault(1);
			RichPresenceMenuItem = source.ElementAtOrDefault(3);
			SoftkeyMenuItem = source.ElementAtOrDefault(4);
			InviteDeeplinkMenuItem = source.ElementAtOrDefault(5);
			AutoJoinRegionMenuItem = source.ElementAtOrDefault(6);
			ServerDetailsMenuItem = source.ElementAtOrDefault(7);
			GameHistoryMenuItem = source.ElementAtOrDefault(8);
			CloseRobloxMenuItem = source.ElementAtOrDefault(10);
		}
	}

	public MenuContainer(Watcher watcher)
		: this()
	{
		_watcher = watcher;
		if (ActivityWatcher == null)
		{
			return;
		}
		ActivityWatcher.OnGameJoin += ActivityWatcher_OnGameJoin;
		ActivityWatcher.OnGameLeave += ActivityWatcher_OnGameLeave;
		ActivityWatcher.OnStudioPlaceOpened += ActivityWatcher_OnStudioPlaceOpened;
		ActivityWatcher.OnStudioPlaceClosed += ActivityWatcher_OnStudioPlaceClosed;
		Avalonia.Threading.Dispatcher.UIThread.Post(() =>
		{
			if (ActivityWatcher.InRobloxStudio)
			{
				InviteDeeplinkMenuItem?.SetValue(Visual.IsVisibleProperty, value: false);
				ServerDetailsMenuItem?.SetValue(Visual.IsVisibleProperty, value: false);
				GameHistoryMenuItem?.SetValue(Visual.IsVisibleProperty, value: false);
				AutoJoinRegionMenuItem?.SetValue(Visual.IsVisibleProperty, value: false);
				SoftkeyMenuItem?.SetValue(Visual.IsVisibleProperty, value: false);
				CloseRobloxMenuItem?.SetValue(HeaderedSelectingItemsControl.HeaderProperty, Strings.Menu_ContextMenu_CloseStudio);
				if (App.Settings.Prop.PlaytimeCounter)
				{
					StartTotalPlaytimeTimer();
					PlaytimeMenuItem?.SetValue(Visual.IsVisibleProperty, value: true);
					if (ActivityWatcher.InStudioPlace)
					{
						_studioPlaceJoinTime = DateTime.Now;
					}
				}
			}
			else
			{
				if (App.Settings.Prop.PlaytimeCounter)
				{
					StartTotalPlaytimeTimer();
				}
				GameHistoryMenuItem?.SetValue(Visual.IsVisibleProperty, App.Settings.Prop.ShowGameHistoryMenu);
				NativeMenuItem? softkeyMenuItem = SoftkeyMenuItem;
				if (softkeyMenuItem != null)
				{
					softkeyMenuItem.IsVisible = App.Settings.Prop.SoftKeyEnabled && _watcher?.Softkey != null && OperatingSystem.IsWindows();
				}
				NativeMenuItem? softkeyMenuItem2 = SoftkeyMenuItem;
				if (softkeyMenuItem2 != null)
				{
					softkeyMenuItem2.IsChecked = true;
				}
			}
			if (RichPresenceMenuItem != null)
			{
				RichPresenceMenuItem.IsVisible = _watcher?.PlayerRichPresence != null || _watcher?.StudioRichPresence != null;
				_watcher?.PlayerRichPresence?.SetVisibility(RichPresenceMenuItem.IsChecked);
				_watcher?.StudioRichPresence?.SetVisibility(RichPresenceMenuItem.IsChecked);
			}
			VersionMenuItem?.SetValue(NativeMenuItem.HeaderProperty, "Merostrap " + App.Version);
		});
	}

	private void StartTotalPlaytimeTimer()
	{
		_totalPlaytimeStopwatch.Start();
		_playtimeTimer = new DispatcherTimer(TimeSpan.FromSeconds(1L), DispatcherPriority.Normal, PlaytimeTimer_Tick);
		_playtimeTimer.Start();
	}

	private void PlaytimeTimer_Tick(object? sender, EventArgs e)
	{
		TimeSpan ts = _accumulatedTotalPlaytime + _totalPlaytimeStopwatch.Elapsed;
		if (ActivityWatcher != null && PlaytimeMenuItem != null)
		{
			string header;
			if (ActivityWatcher.InStudioPlace && _studioPlaceJoinTime.HasValue)
			{
				header = $"{Strings.Common_Total}: {FormatTimeSpan(ts)} | {Strings.Common_Studio}: {FormatTimeSpan(DateTime.Now - _studioPlaceJoinTime.Value)}";
			}
			else
			{
				header = ((!ActivityWatcher.InGame) ? (Strings.Common_Total + ": " + FormatTimeSpan(ts)) : $"{Strings.Common_Total}: {FormatTimeSpan(ts)} | {Strings.Common_Game}: {FormatTimeSpan(DateTime.Now - ActivityWatcher.Data.TimeJoined)}");
			}
			PlaytimeMenuItem.Header = header;
		}
	}

	private static string FormatTimeSpan(TimeSpan ts)
	{
		if (ts.TotalHours >= 1.0)
		{
			return $"{(int)ts.TotalHours}:{ts.Minutes:D2}:{ts.Seconds:D2}";
		}
		return $"{ts.Minutes}:{ts.Seconds:D2}";
	}

	public async void ShowServerInformationWindow()
	{
		if (_serverInformationWindow == null)
		{
			_serverInformationWindow = new ServerInformation(_watcher);
			_serverInformationWindow.Closed += (object? _, EventArgs _) =>
			{
				_serverInformationWindow = null;
			};
		}
		if (!_serverInformationWindow.IsVisible)
		{
			_serverInformationWindow.Show();
		}
		else
		{
			_serverInformationWindow.Activate();
		}
	}

	private void ActivityWatcher_OnGameJoin(object? sender, EventArgs e)
	{
		Avalonia.Threading.Dispatcher.UIThread.Invoke(() =>
		{
			ActivityWatcher? activityWatcher = ActivityWatcher;
			if ((activityWatcher == null || activityWatcher.Data.ServerType != ServerType.Reserved) && InviteDeeplinkMenuItem != null)
			{
				InviteDeeplinkMenuItem?.SetValue(Visual.IsVisibleProperty, value: true);
			}
			ServerDetailsMenuItem?.SetValue(Visual.IsVisibleProperty, value: true);
			AutoJoinRegionMenuItem?.SetValue(Visual.IsVisibleProperty, value: true);
		});
	}

	private void ActivityWatcher_OnGameLeave(object? sender, EventArgs e)
	{
		Avalonia.Threading.Dispatcher.UIThread.Invoke(() =>
		{
			InviteDeeplinkMenuItem?.SetValue(Visual.IsVisibleProperty, value: false);
			ServerDetailsMenuItem?.SetValue(Visual.IsVisibleProperty, value: false);
			AutoJoinRegionMenuItem?.SetValue(Visual.IsVisibleProperty, value: false);
		});
	}

	private void ActivityWatcher_OnStudioPlaceOpened(object? sender, EventArgs e)
	{
		_studioPlaceJoinTime = DateTime.Now;
	}

	private void ActivityWatcher_OnStudioPlaceClosed(object? sender, EventArgs e)
	{
		_studioPlaceJoinTime = null;
	}

	private void CloseWatcheMenuItem_Click(object? sender, EventArgs e)
	{
		_watcher?.Dispose();
	}

	private void RichPresenceMenuItem_Click(object? sender, EventArgs e)
	{
		if (sender is NativeMenuItem { IsChecked: var isChecked })
		{
			_watcher?.PlayerRichPresence?.SetVisibility(isChecked);
			_watcher?.StudioRichPresence?.SetVisibility(isChecked);
		}
	}

	private void SoftkeyMenuItem_Click(object? sender, EventArgs e)
	{
		if (sender is NativeMenuItem nativeMenuItem)
		{
			_watcher?.Softkey?.SetEnabled(nativeMenuItem.IsChecked);
		}
	}

	private async void InviteDeeplinkMenuItem_Click(object? sender, EventArgs e)
	{
		string text = ActivityWatcher?.Data?.GetInviteDeeplink() ?? Strings.Menu_ContextMenu_NoData;
		IClipboard clipboard = TopLevel.GetTopLevel(this)?.Clipboard;
		if (clipboard != null)
		{
			await clipboard.SetTextAsync(text);
		}
	}

	private void ServerDetailsMenuItem_Click(object? sender, EventArgs e)
	{
		ShowServerInformationWindow();
	}

	private void CloseRobloxMenuItem_Click(object? sender, EventArgs e)
	{
		_watcher?.KillRobloxProcess();
	}

	private void JoinLastServerMenuItem_Click(object? sender, EventArgs e)
	{
		if (ActivityWatcher == null)
		{
			return;
		}
		if (_gameHistoryWindow == null)
		{
			_gameHistoryWindow = new ServerHistory(ActivityWatcher);
			_gameHistoryWindow.Closed += (object? _, EventArgs _) =>
			{
				_gameHistoryWindow = null;
			};
		}
		if (!_gameHistoryWindow.IsVisible)
		{
			_gameHistoryWindow.Show();
		}
		else
		{
			_gameHistoryWindow.Activate();
		}
	}

	private async void AutoJoinRegionMenuItem_Click(object? sender, EventArgs e)
	{
		if (ActivityWatcher == null)
		{
			return;
		}
		NativeNotify.SendMessage("Searching for server", "Looking for the best server in your region...");
		using RobloxServerFetcher fetcher = new RobloxServerFetcher();
		await fetcher.JoinBestServerAsync(ActivityWatcher.Data.PlaceId);
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, MenuContainer P_1)
	{
		XamlIlContext.Context<MenuContainer> context = new XamlIlContext.Context<MenuContainer>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FContextMenu_002FMenuContainer_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/ContextMenu/MenuContainer.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		P_1.Title = "ContextMenuContainer";
		P_1.Width = 0.0;
		P_1.Height = 0.0;
		P_1.ShowInTaskbar = false;
		P_1.WindowDecorations = WindowDecorations.None;
		P_1.Opacity = 0.0;
		NativeMenu nativeMenu = new NativeMenu();
		IList<NativeMenuItemBase> items = nativeMenu.Items;
		NativeMenuItem nativeMenuItem = new NativeMenuItem();
		nativeMenuItem.Header = "Merostrap";
		nativeMenuItem.IsEnabled = false;
		items.Add(nativeMenuItem);
		IList<NativeMenuItemBase> items2 = nativeMenu.Items;
		NativeMenuItem nativeMenuItem2 = new NativeMenuItem();
		nativeMenuItem2.Header = "Total: 00:00";
		nativeMenuItem2.IsEnabled = false;
		items2.Add(nativeMenuItem2);
		nativeMenu.Items.Add(new NativeMenuItemSeparator());
		IList<NativeMenuItemBase> items3 = nativeMenu.Items;
		NativeMenuItem nativeMenuItem3 = new NativeMenuItem();
		nativeMenuItem3.Header = Strings.Common_DiscordRichPresence;
		nativeMenuItem3.IsVisible = false;
		nativeMenuItem3.Click += context.RootObject.RichPresenceMenuItem_Click;
		nativeMenuItem3.ToggleType = MenuItemToggleType.CheckBox;
		nativeMenuItem3.IsChecked = true;
		items3.Add(nativeMenuItem3);
		IList<NativeMenuItemBase> items4 = nativeMenu.Items;
		NativeMenuItem nativeMenuItem4 = new NativeMenuItem();
		nativeMenuItem4.Header = Strings.Menu_Bootstrapper_SoftKey_Title;
		nativeMenuItem4.IsVisible = false;
		nativeMenuItem4.Click += context.RootObject.SoftkeyMenuItem_Click;
		nativeMenuItem4.ToggleType = MenuItemToggleType.CheckBox;
		nativeMenuItem4.IsChecked = true;
		items4.Add(nativeMenuItem4);
		IList<NativeMenuItemBase> items5 = nativeMenu.Items;
		NativeMenuItem nativeMenuItem5 = new NativeMenuItem();
		nativeMenuItem5.Header = Strings.ContextMenu_CopyDeeplinkInvite;
		nativeMenuItem5.IsVisible = false;
		nativeMenuItem5.Click += context.RootObject.InviteDeeplinkMenuItem_Click;
		items5.Add(nativeMenuItem5);
		IList<NativeMenuItemBase> items6 = nativeMenu.Items;
		NativeMenuItem nativeMenuItem6 = new NativeMenuItem();
		nativeMenuItem6.Header = Strings.Menu_ContextMenu_RegionJoin;
		nativeMenuItem6.IsVisible = false;
		nativeMenuItem6.Click += context.RootObject.AutoJoinRegionMenuItem_Click;
		items6.Add(nativeMenuItem6);
		IList<NativeMenuItemBase> items7 = nativeMenu.Items;
		NativeMenuItem nativeMenuItem7 = new NativeMenuItem();
		nativeMenuItem7.Header = Strings.ContextMenu_ServerInformation_Title;
		nativeMenuItem7.IsVisible = false;
		nativeMenuItem7.Click += context.RootObject.ServerDetailsMenuItem_Click;
		items7.Add(nativeMenuItem7);
		IList<NativeMenuItemBase> items8 = nativeMenu.Items;
		NativeMenuItem nativeMenuItem8 = new NativeMenuItem();
		nativeMenuItem8.Header = Strings.ContextMenu_GameHistory_Title;
		nativeMenuItem8.Click += context.RootObject.JoinLastServerMenuItem_Click;
		items8.Add(nativeMenuItem8);
		nativeMenu.Items.Add(new NativeMenuItemSeparator());
		IList<NativeMenuItemBase> items9 = nativeMenu.Items;
		NativeMenuItem nativeMenuItem9 = new NativeMenuItem();
		nativeMenuItem9.Header = Strings.ContextMenu_CloseRoblox;
		nativeMenuItem9.Click += context.RootObject.CloseRobloxMenuItem_Click;
		items9.Add(nativeMenuItem9);
		IList<NativeMenuItemBase> items10 = nativeMenu.Items;
		NativeMenuItem nativeMenuItem10 = new NativeMenuItem();
		nativeMenuItem10.Header = Strings.Menu_ContextMenu_CloseWatcher;
		nativeMenuItem10.Click += context.RootObject.CloseWatcheMenuItem_Click;
		items10.Add(nativeMenuItem10);
		NativeMenu.SetMenu(P_1, nativeMenu);
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(MenuContainer P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
