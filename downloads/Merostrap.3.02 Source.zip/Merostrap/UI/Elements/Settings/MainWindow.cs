using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;
using Avalonia;
using Avalonia.Animation;
using Avalonia.Animation.Easings;
using Avalonia.Controls;
using Avalonia.Controls.Notifications;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using Avalonia.Styling;
using Avalonia.Threading;
using Avalonia.VisualTree;
using CompiledAvaloniaXaml;
using FluentAvalonia.UI.Controls;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.Enums;
using Merostrap.Enums.Messagebox;
using Merostrap.Macros;
using Merostrap.Models;
using Merostrap.Models.APIs.Config;
using Merostrap.Models.Persistable;
using Merostrap.Resources;
using Merostrap.UI.Elements.Base;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.Utility;
using Merostrap.UI.ViewModels;
using Merostrap.UI.ViewModels.Settings;

namespace Merostrap.UI.Elements.Settings;

internal class MainWindow : AvaloniaWindow
{
	private sealed class NotificationEntry
	{
		public required Border Element { get; init; }

		public required TranslateTransform Transform { get; init; }

		public CancellationTokenSource? TimeoutCts { get; set; }
	}

	[CompilerGenerated]
	private class XamlClosure_35
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<MainWindow> context = CreateContext(P_0);
			context.IntermediateRoot = new StackPanel();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((AvaloniaObject)obj).SetValue(Layoutable.VerticalAlignmentProperty, VerticalAlignment.Center, BindingPriority.Template);
			((AvaloniaObject)obj).SetValue(StackPanel.OrientationProperty, Orientation.Horizontal, BindingPriority.Template);
			((AvaloniaObject)obj).SetValue(StackPanel.SpacingProperty, 8.0, BindingPriority.Template);
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<MainWindow> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<MainWindow> context = new XamlIlContext.Context<MainWindow>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FMainWindow_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/MainWindow.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (MainWindow)service;
				}
			}
			return context;
		}

		public static object Build_2(IServiceProvider P_0)
		{
			XamlIlContext.Context<MainWindow> context = CreateContext(P_0);
			context.IntermediateRoot = new StackPanel();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			StackPanel stackPanel = (StackPanel)obj;
			context.PushParent(stackPanel);
			stackPanel.VerticalAlignment = VerticalAlignment.Center;
			stackPanel.Orientation = Orientation.Horizontal;
			stackPanel.Spacing = 8.0;
			Avalonia.Controls.Controls children = stackPanel.Children;
			Button button2;
			Button button = (button2 = new Button());
			((ISupportInitialize)button).BeginInit();
			children.Add(button);
			Button button4;
			Button button3 = (button4 = button2);
			context.PushParent(button4);
			button4.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
			button4.Background = new ImmutableSolidColorBrush(16777215u);
			button4.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
			StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Ancestor(typeof(Window), 0).Property(StyledElement.DataContextProperty, PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor).TypeCast<MainWindowViewModel>()
				.Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMainWindowViewModel_002CMerostrap_002EBreadcrumbItemClickedCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)
				.Build());
			context.ProvideTargetProperty = Button.CommandProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			button4.Bind(commandProperty, binding);
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension();
			context.ProvideTargetProperty = Button.CommandParameterProperty;
			CompiledBinding compiledBinding = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_6(button4, compiledBinding);
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBreadcrumbItemModel_002CMerostrap_002EContent_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = ContentControl.ContentProperty;
			CompiledBinding compiledBinding2 = compiledBindingExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_4(button4, compiledBinding2);
			button4.FontSize = 14.0;
			button4.FontWeight = FontWeight.DemiBold;
			StyledProperty<IBrush?> foregroundProperty = TemplatedControl.ForegroundProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("TextFillColorPrimaryBrush");
			context.ProvideTargetProperty = TemplatedControl.ForegroundProperty;
			BindingBase binding2 = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			button4.Bind(foregroundProperty, binding2);
			StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBreadcrumbItemModel_002CMerostrap_002EIsLast_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding3 = compiledBindingExtension4.ProvideValue(context);
			context.ProvideTargetProperty = null;
			button4.Bind(isVisibleProperty, binding3);
			context.PopParent();
			((ISupportInitialize)button3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}
	}

	private readonly MainWindowViewModel? _viewModel;

	private readonly HashSet<string> _indexedPageTags = new HashSet<string>();

	private readonly SearchIndexBuilder _searchIndexBuilder = new SearchIndexBuilder();

	private bool _isIndexingAllPagesStarted;

	private const double NotificationHeight = 80.0;

	private const double NotificationSpacing = 15.0;

	private const double NotificationSlideDistance = 500.0;

	private const int MaxVisibleNotifications = 3;

	private readonly List<NotificationEntry> _notifications = new List<NotificationEntry>();

	private SearchBarItem? _pendingSearchScrollItem;

	private readonly Dictionary<string, (string Title, LucideIconNames Icon)> _pageInfo = new Dictionary<string, (string, LucideIconNames)>
	{
		["integrations"] = (Strings.Menu_Integrations_Title, LucideIconNames.Plus),
		["behaviour"] = (Strings.Menu_Behaviour_Title, LucideIconNames.Play),
		["linuxsettings"] = (Strings.Menu_LinuxSettings_Title, LucideIconNames.Settings),
		["mods"] = (Strings.Menu_PresetMods_Title, LucideIconNames.BookOpen),
		["fastflags"] = (Strings.Menu_FastFlags_Title, LucideIconNames.Flag),
		["appearance"] = (Strings.Menu_Appearance_Title, LucideIconNames.Palette),
		["globalsettings"] = (Strings.Menu_GlobalSettings_Title, LucideIconNames.PenLine),
		["shortcuts"] = (Strings.Common_Shortcuts, LucideIconNames.Link2),
		["performance"] = ("Performance", LucideIconNames.Gauge),
		["profiles"] = ("Profiles", LucideIconNames.Layers),
		["macros"] = ("Macros", LucideIconNames.Command),
		["channels"] = (Strings.Common_Deployment, LucideIconNames.HardDriveUpload)
	};

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal FANavigationView NavView;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal FANavigationViewItem gbs;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal FANavigationViewItem linux;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal FAInfoBar AlertBar;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TransitioningContentControl PageContentControl;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal AccountSelectorView AccountSelectorView;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Panel NotificationPanel;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Border OffscreenIndexingCanvas;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal SearchDialog SearchOverlay;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	protected override bool ApplyTopPadding => false;

	public static MainWindow? Instance { get; private set; }

	public static WindowNotificationManager? NotificationManager { get; private set; }

	private static Merostrap.Models.Persistable.WindowState State => App.State.Prop.SettingsWindow;

	public NextAction CloseAction => _viewModel?.CloseAction ?? NextAction.Terminate;

	public MainWindow()
	{
		Instance = this;
		InitializeComponent();
	}

	public MainWindow(bool showAlreadyRunningWarning)
		: this()
	{
		_viewModel = new MainWindowViewModel();
		DataContext = _viewModel;
		MainWindowViewModel? viewModel = _viewModel;
		viewModel.RequestSaveNoticeEvent = (EventHandler)Delegate.Combine(viewModel.RequestSaveNoticeEvent, (EventHandler)((object? _, EventArgs _) =>
		{
			ShowSaveNotification();
		}));
		MainWindowViewModel? viewModel2 = _viewModel;
		viewModel2.RequestCloseWindowEvent = (EventHandler)Delegate.Combine(viewModel2.RequestCloseWindowEvent, (EventHandler)((object? _, EventArgs _) =>
		{
			Close();
		}));
		_viewModel.SearchBar.SearchResultSelected += (object? _, SearchBarItem item) =>
		{
			OnSearchResultSelected(item);
		};
		SearchDialog overlay = this.FindControl<SearchDialog>("SearchOverlay");
		if (overlay != null)
		{
			overlay.Subscribe(_viewModel.SearchBar);
			overlay.Dismissed += (object? _, EventArgs _) =>
			{
				overlay.Hide();
			};
		}
		App.Logger.Debug("Initializing settings window");
		if (showAlreadyRunningWarning)
		{
			ShowAlreadyRunningNotification();
		}
		gbs.Opacity = (_viewModel.GBSEnabled ? 1.0 : 0.5);
		gbs.IsEnabled = _viewModel.GBSEnabled;
		LoadState();
		App.RemoteData.Subscribe((object? _, EventArgs _) =>
		{
			Avalonia.Threading.Dispatcher.UIThread.Post(() =>
			{
				RemoteDataBase prop = App.RemoteData.Prop;
				if (prop != null)
				{
					bool flag = prop.AlertEnabled && !string.IsNullOrWhiteSpace(prop.AlertContent);
					AlertBar.IsOpen = flag;
					if (flag)
					{
						AlertBar.Message = prop.AlertContent;
						AlertBar.Severity = prop.AlertSeverity;
					}
				}
			});
		});
		_viewModel.PropertyChanged += OnViewModelPropertyChanged;
		Closing += MainWindow_Closing;
		Closed += MainWindow_Closed;
		UpdatePageView(_viewModel.CurrentPage);
		Avalonia.Threading.Dispatcher.UIThread.Post(() =>
		{
			UpdateSelectedNavigationViewItem(_viewModel.SelectedPage);
		}, DispatcherPriority.Loaded);
	}

	protected override async void OnOpened(EventArgs e)
	{
		base.OnOpened(e);
		MacroWorkspace.Current.RestoreOverlay();
		NotificationManager = new WindowNotificationManager(TopLevel.GetTopLevel(this))
		{
			Position = NotificationPosition.TopRight,
			MaxItems = 3
		};
	}

	public void StartIndexingAllPagesIfNeeded()
	{
		if (!_isIndexingAllPagesStarted)
		{
			_isIndexingAllPagesStarted = true;
			IndexMissingPagesAsync();
		}
	}

	private void TitleBarGrid_PointerPressed(object sender, PointerPressedEventArgs e)
	{
		if (e.GetCurrentPoint(this).Properties.IsLeftButtonPressed)
		{
			BeginMoveDrag(e);
		}
	}

	private void OnViewModelPropertyChanged(object? sender, PropertyChangedEventArgs e)
	{
		if (_viewModel != null)
		{
			if (e.PropertyName == "CurrentPage")
			{
				UpdatePageView(_viewModel.CurrentPage);
			}
			else if (e.PropertyName == "SelectedPage")
			{
				UpdateSelectedNavigationViewItem(_viewModel.SelectedPage);
			}
		}
	}

	private void OnSearchResultSelected(SearchBarItem item)
	{
		this.FindControl<SearchDialog>("SearchOverlay")?.Hide();
		_pendingSearchScrollItem = item;
		if (_viewModel?.SelectedPage != item.PageTag)
		{
			SaveCurrentPage();
			GetNavigationAction(item.PageTag ?? "")?.Invoke();
		}
		else
		{
			ScrollToSearchItem(item);
		}
	}

	private Action? GetNavigationAction(string pageTag)
	{
		return pageTag switch
		{
			"integrations" => (Action?)(() =>
			{
				_viewModel?.NavigateToIntegrationsCommand.Execute(null);
			}), 
			"behaviour" => () =>
			{
				_viewModel?.NavigateToBehaviourCommand.Execute(null);
			}, 
			"linuxsettings" => () =>
			{
				_viewModel?.NavigateToLinuxSettingsCommand.Execute(null);
			}, 
			"mods" => () =>
			{
				_viewModel?.NavigateToPresetModsCommand.Execute(null);
			}, 
			"fastflags" => () =>
			{
				_viewModel?.NavigateToFastFlagsCommand.Execute(null);
			}, 
			"appearance" => () =>
			{
				_viewModel?.NavigateToAppearanceCommand.Execute(null);
			}, 
			"regionselector" => () =>
			{
				_viewModel?.NavigateToRegionSelectorCommand.Execute(null);
			}, 
			"globalsettings" => () =>
			{
				_viewModel?.NavigateToGlobalSettingsCommand.Execute(null);
			}, 
			"shortcuts" => () =>
			{
				_viewModel?.NavigateToShortcutsCommand.Execute(null);
			}, 
			"quickplay" => () =>
			{
				_viewModel?.NavigateToQuickPlayCommand.Execute(null);
			}, 
			"performance" => () =>
			{
				_viewModel?.NavigateToPerformanceCommand.Execute(null);
			}, 
			"profiles" => () =>
			{
				_viewModel?.NavigateToProfilesCommand.Execute(null);
			}, 
			"macros" => () =>
			{
				_viewModel?.NavigateToMacrosCommand.Execute(null);
			}, 
			"channels" => () =>
			{
				_viewModel?.NavigateToChannelsCommand.Execute(null);
			}, 
			_ => null, 
		};
	}

	private void UpdatePageView(object? viewModel)
	{
		SaveCurrentPage();
		TransitioningContentControl transitioningContentControl = this.FindControl<TransitioningContentControl>("PageContentControl");
		if (transitioningContentControl == null || viewModel == null)
		{
			return;
		}
		string pageTag = _viewModel?.SelectedPage ?? "";
		Control view = ResolveViewForViewModel(viewModel);
		if (view == null || view.DataContext == viewModel)
		{
			return;
		}
		view.DataContext = viewModel;
		transitioningContentControl.Content = view;
		Avalonia.Threading.Dispatcher.UIThread.Post(() =>
		{
			if (!string.IsNullOrEmpty(pageTag) && _pageInfo.TryGetValue(pageTag, out (string, LucideIconNames) value) && !_indexedPageTags.Contains(pageTag))
			{
				IndexPage(view, pageTag, value.Item1, value.Item2);
				_indexedPageTags.Add(pageTag);
			}
			if (_pendingSearchScrollItem != null)
			{
				Avalonia.Threading.Dispatcher.UIThread.Post(() =>
				{
					ScrollToSearchItem(_pendingSearchScrollItem);
					_pendingSearchScrollItem = null;
				}, DispatcherPriority.Render);
			}
		}, DispatcherPriority.Background);
	}

	private void NavView_ItemInvoked(object? sender, FANavigationViewItemInvokedEventArgs e)
	{
		if (e.InvokedItemContainer is FANavigationViewItem { Tag: string tag })
		{
			if (tag == "about")
			{
				_viewModel?.OpenAboutCommand.Execute(null);
			}
			else if (_viewModel == null || !(_viewModel.SelectedPage == tag))
			{
				SaveCurrentPage();
				GetNavigationAction(tag)?.Invoke();
			}
		}
	}

	private void OpenSearchOverlay(object? sender, RoutedEventArgs e)
	{
		if (_viewModel != null)
		{
			StartIndexingAllPagesIfNeeded();
			this.FindControl<SearchDialog>("SearchOverlay")?.Show();
		}
	}

	private void UpdateSelectedNavigationViewItem(string selectedPage)
	{
		FANavigationView fANavigationView = this.FindControl<FANavigationView>("NavView");
		if (fANavigationView == null)
		{
			return;
		}
		foreach (object menuItem in fANavigationView.MenuItems)
		{
			if (menuItem is FANavigationViewItem { Tag: string tag } fANavigationViewItem && tag == selectedPage)
			{
				fANavigationView.SelectedItem = fANavigationViewItem;
				return;
			}
		}
		foreach (object footerMenuItem in fANavigationView.FooterMenuItems)
		{
			if (footerMenuItem is FANavigationViewItem { Tag: string tag2 } fANavigationViewItem2 && tag2 == selectedPage)
			{
				fANavigationView.SelectedItem = fANavigationViewItem2;
				break;
			}
		}
	}

	private static Control? ResolveViewForViewModel(object viewModel)
	{
		string text = viewModel.GetType().Name.Replace("ViewModel", "", StringComparison.Ordinal);
		string[] array = new string[7]
		{
			"Merostrap.UI.Elements.Settings.Pages.GlobalSettings." + text,
			"Merostrap.UI.Elements.Settings.Pages.FastFlags." + text,
			"Merostrap.UI.Elements.Settings.Pages.Mods." + text + "Page",
			"Merostrap.UI.Elements.Settings.Pages." + text + "Page",
			"Merostrap.UI.Elements.Settings.Pages." + text,
			"Merostrap.UI.Elements.Settings." + text + "Page",
			"Merostrap.UI.Elements.Settings." + text
		};
		foreach (string text2 in array)
		{
			Type type = Type.GetType(text2) ?? Assembly.GetExecutingAssembly().GetType(text2);
			if (type != null && typeof(Control).IsAssignableFrom(type))
			{
				try
				{
					return Activator.CreateInstance(type) as Control;
				}
				catch (Exception ex)
				{
					App.Logger.Error("Failed to create view " + text2 + ": " + ex.Message);
				}
			}
		}
		return null;
	}

	public void LoadState()
	{
		PixelRect? pixelRect = Screens.Primary?.Bounds;
		if (pixelRect.HasValue)
		{
			if (State.Left > (double)pixelRect.Value.Width)
			{
				State.Left = 0.0;
			}
			if (State.Top > (double)pixelRect.Value.Height)
			{
				State.Top = 0.0;
			}
		}
		if (State.Width > 0.0)
		{
			Width = State.Width;
		}
		if (State.Height > 0.0)
		{
			Height = State.Height;
		}
		if (State.Left > 0.0 && State.Top > 0.0)
		{
			WindowStartupLocation = WindowStartupLocation.Manual;
			Position = new PixelPoint((int)State.Left, (int)State.Top);
		}
	}

	private void ShowSaveNotification()
	{
		ShowNotification(Strings.Menu_SettingsSaved_Title, Strings.Menu_SettingsSaved_Message, FAInfoBarSeverity.Success, 3000);
	}

	private async void ShowAlreadyRunningNotification()
	{
		await Task.Delay(500);
		ShowNotification(Strings.Menu_AlreadyRunning_Title, Strings.Menu_AlreadyRunning_Caption, FAInfoBarSeverity.Warning, 5000);
	}

	public static void ShowGlobalNotification(string title, string subtitle, FAInfoBarSeverity type, int timeout = 3000, LucideIconNames? icon = null)
	{
		Avalonia.Threading.Dispatcher.UIThread.Post(() =>
		{
			Instance?.ShowNotification(title, subtitle, type, timeout, icon);
		});
	}

	public void ShowNotification(string title, string subtitle, FAInfoBarSeverity type, int timeout, LucideIconNames? customIcon = null)
	{
		Panel panel = this.FindControl<Panel>("NotificationPanel");
		if (panel == null)
		{
			return;
		}
		LucideIconNames? lucideIconNames = customIcon;
		if (!lucideIconNames.HasValue)
		{
			if (type == FAInfoBarSeverity.Success)
			{
			}
		}
		else
		{
			lucideIconNames.GetValueOrDefault();
		}
		Grid grid = new Grid
		{
			ColumnDefinitions = new ColumnDefinitions("Auto,*,Auto"),
			Margin = new Thickness(0.0)
		};
		Lucide lucide = new Lucide
		{
			Icon = ((type == FAInfoBarSeverity.Success) ? LucideIconNames.Check : LucideIconNames.X),
			StrokeBrush = new SolidColorBrush((type == FAInfoBarSeverity.Success) ? Color.Parse("#00D084") : Color.Parse("#FFB900")),
			Margin = new Thickness(25.0, 15.0, 20.0, 15.0),
			FontSize = 20.0,
			Width = 20.0,
			Height = 20.0
		};
		Grid.SetColumn(lucide, 0);
		grid.Children.Add(lucide);
		StackPanel stackPanel = new StackPanel
		{
			VerticalAlignment = VerticalAlignment.Center,
			Spacing = 2.0
		};
		TextBlock textBlock = new TextBlock
		{
			Text = title,
			FontWeight = FontWeight.DemiBold,
			FontSize = 16.0,
			Margin = new Thickness(0.0, 2.0)
		};
		textBlock.Bind(TextBlock.ForegroundProperty, new DynamicResourceExtension("TextFillColorPrimaryBrush"));
		TextBlock textBlock2 = new TextBlock
		{
			Text = subtitle,
			FontSize = 12.0,
			TextWrapping = TextWrapping.Wrap,
			Margin = new Thickness(0.0, 2.0)
		};
		textBlock2.Bind(TextBlock.ForegroundProperty, new DynamicResourceExtension("TextFillColorSecondaryBrush"));
		stackPanel.Children.Add(textBlock);
		stackPanel.Children.Add(textBlock2);
		Grid.SetColumn(stackPanel, 1);
		grid.Children.Add(stackPanel);
		IconButton iconButton = new IconButton
		{
			Icon = LucideIconNames.X,
			IconSize = 12.0,
			CornerRadius = new CornerRadius(0.0, 10.0, 10.0, 0.0),
			Background = Brushes.Transparent,
			BorderThickness = new Thickness(0.0),
			Padding = new Thickness(8.0, 4.0, 8.0, 4.0),
			VerticalAlignment = VerticalAlignment.Stretch,
			HorizontalAlignment = HorizontalAlignment.Right,
			Margin = new Thickness(20.0, 0.0, 0.0, 0.0),
			Width = 50.0
		};
		iconButton.Bind(TemplatedControl.ForegroundProperty, new DynamicResourceExtension("TextFillColorSecondaryBrush"));
		Grid.SetColumn(iconButton, 2);
		grid.Children.Add(iconButton);
		TranslateTransform transform = new TranslateTransform(500.0, 0.0)
		{
			Transitions = new Transitions
			{
				new DoubleTransition
				{
					Property = TranslateTransform.XProperty,
					Duration = TimeSpan.FromMilliseconds(350L),
					Easing = new QuarticEaseOut()
				},
				new DoubleTransition
				{
					Property = TranslateTransform.YProperty,
					Duration = TimeSpan.FromMilliseconds(300L),
					Easing = new QuarticEaseOut()
				}
			}
		};
		Border border = new Border
		{
			Margin = new Thickness(0.0, 15.0, 15.0, 0.0),
			MinWidth = 350.0,
			Height = 80.0,
			CornerRadius = new CornerRadius(10.0),
			RenderTransform = transform,
			Child = grid,
			BoxShadow = new BoxShadows(new BoxShadow
			{
				Blur = 10.0,
				OffsetY = 4.0,
				Color = Color.Parse("#40000000")
			}),
			HorizontalAlignment = HorizontalAlignment.Right,
			VerticalAlignment = VerticalAlignment.Top
		};
		border.Bind(Border.BackgroundProperty, new DynamicResourceExtension("NotificationBackgroundColor"));
		NotificationEntry entry = new NotificationEntry
		{
			Element = border,
			Transform = transform
		};
		iconButton.Click += (object? s, RoutedEventArgs e) =>
		{
			e.Handled = true;
			Dismiss();
		};
		border.PointerPressed += (object? s, PointerPressedEventArgs e) =>
		{
			if (!(e.Source is IconButton))
			{
				Dismiss();
			}
		};
		_notifications.Insert(0, entry);
		panel.Children.Add(border);
		while (_notifications.Count > 3)
		{
			List<NotificationEntry> notifications = _notifications;
			DismissNotification(notifications[notifications.Count - 1]);
		}
		RepositionNotifications();
		CancellationTokenSource cts = new CancellationTokenSource();
		entry.TimeoutCts = cts;
		Avalonia.Threading.Dispatcher.UIThread.InvokeAsync(async () =>
		{
			await Task.Delay(50);
			if (!cts.IsCancellationRequested)
			{
				transform.X = 0.0;
				await Task.Delay(timeout);
				if (!cts.IsCancellationRequested)
				{
					Dismiss();
				}
			}
		});
		void Dismiss()
		{
			DismissNotification(entry);
		}
	}

	private async void DismissNotification(NotificationEntry entry)
	{
		if (_notifications.Remove(entry))
		{
			entry.TimeoutCts?.Cancel();
			RepositionNotifications();
			entry.Transform.X = 500.0;
			await Task.Delay(350);
			Panel panel = this.FindControl<Panel>("NotificationPanel");
			if (panel != null && panel.Children.Contains(entry.Element))
			{
				panel.Children.Remove(entry.Element);
			}
		}
	}

	private void RepositionNotifications()
	{
		for (int i = 0; i < _notifications.Count; i++)
		{
			_notifications[i].Transform.Y = (double)i * 95.0;
		}
	}

	public void ShowLoading(string message = "Loading...")
	{
		Grid grid = this.FindControl<Grid>("LoadingOverlay");
		TextBlock textBlock = this.FindControl<TextBlock>("LoadingOverlayText");
		if (grid != null && textBlock != null)
		{
			textBlock.Text = message;
			grid.IsVisible = true;
		}
	}

	public void HideLoading()
	{
		Grid? grid = this.FindControl<Grid>("LoadingOverlay");
		if (grid != null)
		{
			grid.IsVisible = false;
		}
	}

	private async Task IndexMissingPagesAsync()
	{
		if (_viewModel == null)
		{
			return;
		}
		List<string> list = new List<string>
		{
			"integrations", "behaviour", "channels", "performance", "profiles", "macros", "mods", "appearance", "fastflags", "globalsettings",
			"shortcuts"
		};
		if (OperatingSystem.IsLinux())
		{
			list.Add("linuxsettings");
		}
		if (!_viewModel.GBSEnabled)
		{
			list.Remove("globalsettings");
		}
		List<string> list2 = list.Where((string tag) => !_indexedPageTags.Contains(tag)).ToList();
		if (list2.Count == 0)
		{
			return;
		}
		Avalonia.Threading.Dispatcher.UIThread.Post(() =>
		{
			_viewModel.SearchBar.IsIndexing = true;
		});
		Border stagingArea = this.FindControl<Border>("OffscreenIndexingCanvas");
		if (stagingArea == null)
		{
			App.Logger.Error("OffscreenIndexingCanvas not found");
			Avalonia.Threading.Dispatcher.UIThread.Post(() =>
			{
				_viewModel.SearchBar.IsIndexing = false;
			});
			return;
		}
		stagingArea.IsVisible = true;
		try
		{
			foreach (string pageTag in list2)
			{
				try
				{
					object obj = pageTag switch
					{
						"integrations" => (object)new IntegrationsViewModel(), 
						"behaviour" => new BehaviourViewModel(), 
						"linuxsettings" => new LinuxSettingsViewModel(), 
						"mods" => new ModsPresetsViewModel(), 
						"fastflags" => new FastFlagsViewModel(), 
						"appearance" => new AppearanceViewModel(), 
						"globalsettings" => new GlobalSettingsViewModel(), 
						"shortcuts" => new ShortcutsViewModel(), 
						"channels" => new ChannelViewModel(), 
						"performance" => new PerformanceViewModel(), 
						"profiles" => new ProfilesViewModel(), 
						"macros" => new MacrosViewModel(), 
						_ => null, 
					};
					if (obj != null)
					{
						Control view = ResolveViewForViewModel(obj);
						if (view != null)
						{
							view.DataContext = obj;
							Border container = (Border)(stagingArea.Child = new Border
							{
								Child = view
							});
							await Avalonia.Threading.Dispatcher.UIThread.InvokeAsync(() =>
							{
							}, DispatcherPriority.Render);
							await Avalonia.Threading.Dispatcher.UIThread.InvokeAsync(() =>
							{
							}, DispatcherPriority.Background);
							var (pageTitle, pageIcon) = _pageInfo[pageTag];
							IndexPage(view, pageTag, pageTitle, pageIcon);
							_indexedPageTags.Add(pageTag);
							container.Child = null;
							stagingArea.Child = null;
							view.DataContext = null;
							stagingArea.UpdateLayout();
							await Task.Delay(30);
						}
					}
				}
				catch (Exception ex)
				{
					App.Logger.Error("Error indexing " + pageTag + ": " + ex.Message);
				}
			}
		}
		finally
		{
			stagingArea.IsVisible = false;
			Avalonia.Threading.Dispatcher.UIThread.Post(() =>
			{
				_viewModel.SearchBar.IsIndexing = false;
				_viewModel.SearchBar.RefreshSearchResults();
			});
		}
	}

	private void IndexPage(Control pageView, string pageTag, string pageTitle, LucideIconNames pageIcon)
	{
		if (_viewModel == null)
		{
			return;
		}
		try
		{
			List<SearchBarItem> list = _searchIndexBuilder.ScanRenderedPageForElements(pageView, pageTag);
			if (list.Count <= 0)
			{
				return;
			}
			Action navigationAction = GetNavigationAction(pageTag);
			foreach (SearchBarItem item in list)
			{
				item.PageName = pageTitle;
				item.IconSymbol = pageIcon;
				if (navigationAction != null)
				{
					item.NavigateAction = navigationAction;
				}
			}
			HashSet<string> hiddenControlHeaders = (from name in (from c in pageView.GetVisualDescendants()
					where !c.IsVisible
					select c).Select((Visual c) =>
				{
					if (c is OptionControl { Header: var header })
					{
						return header?.ToString();
					}
					if (c is CardExpander { Header: var header2 })
					{
						return header2?.ToString();
					}
					if (c is CardAction { Header: var header3 })
					{
						return header3?.ToString();
					}
					return (c is TextBlock textBlock) ? textBlock.Text : null;
				})
				where !string.IsNullOrEmpty(name)
				select name).ToHashSet();
			List<SearchBarItem> list2 = list.Where((SearchBarItem item) => !hiddenControlHeaders.Contains(item.DisplayName)).ToList();
			if (list2.Count > 0)
			{
				_viewModel.SearchBar.GetSearchIndex().AddRange(list2);
			}
		}
		catch (Exception ex)
		{
			App.Logger.Error("Failed to scan page " + pageTag + ": " + ex.Message);
		}
	}

	private void ScrollToSearchItem(SearchBarItem item)
	{
		try
		{
			if (!(this.FindControl<TransitioningContentControl>("PageContentControl")?.Content is Control visual))
			{
				return;
			}
			if (!string.IsNullOrWhiteSpace(item.ParentSectionName))
			{
				CardExpander? cardExpander = visual.GetVisualDescendants().OfType<CardExpander>().FirstOrDefault((CardExpander ce) => ce.Header as string == item.ParentSectionName);
				if (cardExpander != null)
				{
					cardExpander.IsExpanded = true;
				}
			}
			Control control = null;
			switch (item.Category)
			{
			case "Section":
				control = visual.GetVisualDescendants().OfType<CardExpander>().FirstOrDefault((CardExpander ce) => ce.Header as string == item.DisplayName);
				break;
			case "Setting":
				control = visual.GetVisualDescendants().OfType<OptionControl>().FirstOrDefault((OptionControl oc) => oc.Header == item.DisplayName);
				break;
			case "Action":
				control = visual.GetVisualDescendants().OfType<CardAction>().FirstOrDefault((CardAction ca) => ca.Content as string == item.DisplayName);
				break;
			case "Label":
				control = visual.GetVisualDescendants().OfType<TextBlock>().FirstOrDefault((TextBlock tb) => tb.Text == item.DisplayName);
				break;
			}
			control?.BringIntoView();
		}
		catch (Exception ex)
		{
			App.Logger.Error("Failed scrolling to item: " + ex.Message);
		}
	}

	private void SaveCurrentPage()
	{
		if (_viewModel?.CurrentPage != null)
		{
			App.State.Prop.LastPage = _viewModel.CurrentPage.GetType().FullName;
			App.State.SaveSetting("LastPage");
		}
	}

	private async void MainWindow_Closing(object? sender, CancelEventArgs e)
	{
		if (MainWindowViewModel.HasUnsavedChanges)
		{
			e.Cancel = true;
			switch (await Frontend.ShowMessageBox(Strings.Menu_UnsavedChangesPrompt, MessageBoxImage.Warning, MessageBoxButton.YesNoCancel))
			{
			case MessageBoxResult.Yes:
				_viewModel?.SaveSettings();
				break;
			case MessageBoxResult.Cancel:
				return;
			}
			Closing -= MainWindow_Closing;
			Close();
		}
		else
		{
			State.Width = Width;
			State.Height = Height;
			State.Left = Position.X;
			State.Top = Position.Y;
			SaveCurrentPage();
		}
	}

	private void MainWindow_Closed(object? sender, EventArgs e)
	{
		NotificationManager = null;
		App.Logger.Info("Settings window closed");
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		NavView = nameScope?.Find<FANavigationView>("NavView");
		gbs = nameScope?.Find<FANavigationViewItem>("gbs");
		linux = nameScope?.Find<FANavigationViewItem>("linux");
		AlertBar = nameScope?.Find<FAInfoBar>("AlertBar");
		PageContentControl = nameScope?.Find<TransitioningContentControl>("PageContentControl");
		AccountSelectorView = nameScope?.Find<AccountSelectorView>("AccountSelectorView");
		NotificationPanel = nameScope?.Find<Panel>("NotificationPanel");
		OffscreenIndexingCanvas = nameScope?.Find<Border>("OffscreenIndexingCanvas");
		SearchOverlay = nameScope?.Find<SearchDialog>("SearchOverlay");
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, MainWindow P_1)
	{
		XamlIlContext.Context<MainWindow> context = new XamlIlContext.Context<MainWindow>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FMainWindow_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/MainWindow.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Title = Strings.Menu_Title;
		P_1.Width = 1125.0;
		P_1.Height = 700.0;
		P_1.MinWidth = 750.0;
		P_1.MinHeight = 415.0;
		P_1.CanResize = true;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 3;
		rowDefinitions.Add(new RowDefinition(new GridLength(36.0, GridUnitType.Pixel)));
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		rowDefinitions.Add(new RowDefinition(new GridLength(56.0, GridUnitType.Pixel)));
		grid5.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid5.Children;
		Panel panel2;
		Panel panel = (panel2 = new Panel());
		((ISupportInitialize)panel).BeginInit();
		children.Add(panel);
		Panel panel4;
		Panel panel3 = (panel4 = panel2);
		context.PushParent(panel4);
		Grid.SetRow(panel4, 0);
		StyledProperty<IBrush?> backgroundProperty = Panel.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = Panel.BackgroundProperty;
		BindingBase binding = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		panel4.Bind(backgroundProperty, binding);
		panel4.AddHandler(InputElement.PointerPressedEvent, context.RootObject.TitleBarGrid_PointerPressed);
		context.PopParent();
		((ISupportInitialize)panel3).EndInit();
		Avalonia.Controls.Controls children2 = grid5.Children;
		FANavigationView fANavigationView2;
		FANavigationView fANavigationView = (fANavigationView2 = new FANavigationView());
		((ISupportInitialize)fANavigationView).BeginInit();
		children2.Add(fANavigationView);
		FANavigationView fANavigationView4;
		FANavigationView fANavigationView3 = (fANavigationView4 = fANavigationView2);
		context.PushParent(fANavigationView4);
		fANavigationView4.Name = "NavView";
		object element = fANavigationView4;
		context.AvaloniaNameScope.Register("NavView", element);
		Grid.SetRow(fANavigationView4, 1);
		StyledProperty<IBrush?> backgroundProperty2 = TemplatedControl.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = TemplatedControl.BackgroundProperty;
		BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		fANavigationView4.Bind(backgroundProperty2, binding2);
		fANavigationView4.IsBackButtonVisible = false;
		fANavigationView4.IsSettingsVisible = false;
		fANavigationView4.ItemInvoked += context.RootObject.NavView_ItemInvoked;
		fANavigationView4.OpenPaneLength = 220.0;
		fANavigationView4.PaneDisplayMode = FANavigationViewPaneDisplayMode.Left;
		IconButton iconButton2;
		IconButton iconButton = (iconButton2 = new IconButton());
		((ISupportInitialize)iconButton).BeginInit();
		fANavigationView4.PaneToggleRowContent = iconButton;
		IconButton iconButton4;
		IconButton iconButton3 = (iconButton4 = iconButton2);
		context.PushParent(iconButton4);
		IconButton iconButton5 = iconButton4;
		iconButton5.Icon = LucideIconNames.Search;
		iconButton5.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.OpenSearchOverlay), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		iconButton5.Width = 40.0;
		iconButton5.Height = 36.0;
		iconButton5.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
		iconButton5.Margin = new Thickness(4.0, 2.0, 4.0, 2.0);
		StyledProperty<IBrush?> backgroundProperty3 = TemplatedControl.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("NavigationViewItemBackground");
		context.ProvideTargetProperty = TemplatedControl.BackgroundProperty;
		BindingBase binding3 = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		iconButton5.Bind(backgroundProperty3, binding3);
		StyledProperty<IBrush?> foregroundProperty = TemplatedControl.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("NavigationViewItemForeground");
		context.ProvideTargetProperty = TemplatedControl.ForegroundProperty;
		BindingBase binding4 = dynamicResourceExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		iconButton5.Bind(foregroundProperty, binding4);
		iconButton5.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
		iconButton5.BorderBrush = new ImmutableSolidColorBrush(16777215u);
		StyledProperty<CornerRadius> cornerRadiusProperty = TemplatedControl.CornerRadiusProperty;
		DynamicResourceExtension dynamicResourceExtension5 = new DynamicResourceExtension("ControlCornerRadius");
		context.ProvideTargetProperty = TemplatedControl.CornerRadiusProperty;
		BindingBase binding5 = dynamicResourceExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		iconButton5.Bind(cornerRadiusProperty, binding5);
		iconButton5.IconSize = 14.0;
		Styles styles = iconButton5.Styles;
		Style style;
		Style item = (style = new Style());
		context.PushParent(style);
		Style style2 = style;
		style2.Selector = ((Selector?)null).OfType(typeof(IconButton));
		Style style3 = (style = new Style());
		context.PushParent(style);
		Style style4 = style;
		style4.Selector = ((Selector?)null).Nesting().Class(":pointerover");
		Setter setter2;
		Setter setter = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter3 = setter2;
		setter3.Property = TemplatedControl.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension6 = new DynamicResourceExtension("NavigationViewButtonForegroundPointerOver");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value = dynamicResourceExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter3.Value = value;
		context.PopParent();
		style4.Add(setter);
		context.PopParent();
		style2.Add(style3);
		Style style5 = (style = new Style());
		context.PushParent(style);
		Style style6 = style;
		style6.Selector = ((Selector?)null).Nesting().Class(":pointerover").Template()
			.OfType(typeof(Border))
			.Name("PART_LayoutRoot");
		Setter setter4 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter5 = setter2;
		setter5.Property = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension7 = new DynamicResourceExtension("NavigationViewButtonBackgroundPointerOver");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value2 = dynamicResourceExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter5.Value = value2;
		context.PopParent();
		style6.Add(setter4);
		context.PopParent();
		style2.Add(style5);
		Style style7 = (style = new Style());
		context.PushParent(style);
		Style style8 = style;
		style8.Selector = ((Selector?)null).Nesting().Class(":pressed");
		Setter setter6 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter7 = setter2;
		setter7.Property = TemplatedControl.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension8 = new DynamicResourceExtension("NavigationViewButtonForegroundPressed");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value3 = dynamicResourceExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter7.Value = value3;
		context.PopParent();
		style8.Add(setter6);
		context.PopParent();
		style2.Add(style7);
		Style style9 = (style = new Style());
		context.PushParent(style);
		Style style10 = style;
		style10.Selector = ((Selector?)null).Nesting().Class(":pressed").Template()
			.OfType(typeof(Border))
			.Name("PART_LayoutRoot");
		Setter setter8 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter9 = setter2;
		setter9.Property = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension9 = new DynamicResourceExtension("NavigationViewButtonBackgroundPressed");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value4 = dynamicResourceExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter9.Value = value4;
		context.PopParent();
		style10.Add(setter8);
		context.PopParent();
		style2.Add(style9);
		context.PopParent();
		styles.Add(item);
		context.PopParent();
		((ISupportInitialize)iconButton3).EndInit();
		IList<object> menuItems = fANavigationView4.MenuItems;
		FANavigationViewItem fANavigationViewItem2;
		FANavigationViewItem fANavigationViewItem = (fANavigationViewItem2 = new FANavigationViewItem());
		((ISupportInitialize)fANavigationViewItem).BeginInit();
		menuItems.Add(fANavigationViewItem);
		fANavigationViewItem2.Content = "Profiles";
		fANavigationViewItem2.Tag = "profiles";
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		fANavigationViewItem2.Icon = lucide;
		lucide2.Icon = LucideIconNames.Layers;
		((ISupportInitialize)lucide2).EndInit();
		((ISupportInitialize)fANavigationViewItem2).EndInit();
		IList<object> menuItems2 = fANavigationView4.MenuItems;
		FANavigationViewItem fANavigationViewItem4;
		FANavigationViewItem fANavigationViewItem3 = (fANavigationViewItem4 = new FANavigationViewItem());
		((ISupportInitialize)fANavigationViewItem3).BeginInit();
		menuItems2.Add(fANavigationViewItem3);
		fANavigationViewItem4.Content = "Performance";
		fANavigationViewItem4.Tag = "performance";
		Lucide lucide4;
		Lucide lucide3 = (lucide4 = new Lucide());
		((ISupportInitialize)lucide3).BeginInit();
		fANavigationViewItem4.Icon = lucide3;
		lucide4.Icon = LucideIconNames.Gauge;
		((ISupportInitialize)lucide4).EndInit();
		((ISupportInitialize)fANavigationViewItem4).EndInit();
		IList<object> menuItems3 = fANavigationView4.MenuItems;
		FANavigationViewItem fANavigationViewItem6;
		FANavigationViewItem fANavigationViewItem5 = (fANavigationViewItem6 = new FANavigationViewItem());
		((ISupportInitialize)fANavigationViewItem5).BeginInit();
		menuItems3.Add(fANavigationViewItem5);
		fANavigationViewItem6.Content = "Macros";
		fANavigationViewItem6.Tag = "macros";
		Lucide lucide6;
		Lucide lucide5 = (lucide6 = new Lucide());
		((ISupportInitialize)lucide5).BeginInit();
		fANavigationViewItem6.Icon = lucide5;
		lucide6.Icon = LucideIconNames.Command;
		((ISupportInitialize)lucide6).EndInit();
		((ISupportInitialize)fANavigationViewItem6).EndInit();
		IList<object> menuItems4 = fANavigationView4.MenuItems;
		FANavigationViewItem fANavigationViewItem8;
		FANavigationViewItem fANavigationViewItem7 = (fANavigationViewItem8 = new FANavigationViewItem());
		((ISupportInitialize)fANavigationViewItem7).BeginInit();
		menuItems4.Add(fANavigationViewItem7);
		fANavigationViewItem8.Content = Strings.Menu_Integrations_Title;
		fANavigationViewItem8.Tag = "integrations";
		Lucide lucide8;
		Lucide lucide7 = (lucide8 = new Lucide());
		((ISupportInitialize)lucide7).BeginInit();
		fANavigationViewItem8.Icon = lucide7;
		lucide8.Icon = LucideIconNames.Plus;
		((ISupportInitialize)lucide8).EndInit();
		((ISupportInitialize)fANavigationViewItem8).EndInit();
		IList<object> menuItems5 = fANavigationView4.MenuItems;
		FANavigationViewItem fANavigationViewItem10;
		FANavigationViewItem fANavigationViewItem9 = (fANavigationViewItem10 = new FANavigationViewItem());
		((ISupportInitialize)fANavigationViewItem9).BeginInit();
		menuItems5.Add(fANavigationViewItem9);
		fANavigationViewItem10.Content = Strings.Menu_Behaviour_Title;
		fANavigationViewItem10.Tag = "behaviour";
		Lucide lucide10;
		Lucide lucide9 = (lucide10 = new Lucide());
		((ISupportInitialize)lucide9).BeginInit();
		fANavigationViewItem10.Icon = lucide9;
		lucide10.Icon = LucideIconNames.Play;
		((ISupportInitialize)lucide10).EndInit();
		((ISupportInitialize)fANavigationViewItem10).EndInit();
		IList<object> menuItems6 = fANavigationView4.MenuItems;
		FANavigationViewItem fANavigationViewItem12;
		FANavigationViewItem fANavigationViewItem11 = (fANavigationViewItem12 = new FANavigationViewItem());
		((ISupportInitialize)fANavigationViewItem11).BeginInit();
		menuItems6.Add(fANavigationViewItem11);
		fANavigationViewItem12.Content = "Games";
		fANavigationViewItem12.Tag = "quickplay";
		Lucide lucide12;
		Lucide lucide11 = (lucide12 = new Lucide());
		((ISupportInitialize)lucide11).BeginInit();
		fANavigationViewItem12.Icon = lucide11;
		lucide12.Icon = LucideIconNames.Gamepad2;
		((ISupportInitialize)lucide12).EndInit();
		((ISupportInitialize)fANavigationViewItem12).EndInit();
		IList<object> menuItems7 = fANavigationView4.MenuItems;
		FANavigationViewItem fANavigationViewItem14;
		FANavigationViewItem fANavigationViewItem13 = (fANavigationViewItem14 = new FANavigationViewItem());
		((ISupportInitialize)fANavigationViewItem13).BeginInit();
		menuItems7.Add(fANavigationViewItem13);
		fANavigationViewItem14.Content = Strings.Common_Deployment;
		fANavigationViewItem14.Tag = "channels";
		Lucide lucide14;
		Lucide lucide13 = (lucide14 = new Lucide());
		((ISupportInitialize)lucide13).BeginInit();
		fANavigationViewItem14.Icon = lucide13;
		lucide14.Icon = LucideIconNames.HardDriveUpload;
		((ISupportInitialize)lucide14).EndInit();
		((ISupportInitialize)fANavigationViewItem14).EndInit();
		IList<object> menuItems8 = fANavigationView4.MenuItems;
		FANavigationViewItem fANavigationViewItem16;
		FANavigationViewItem fANavigationViewItem15 = (fANavigationViewItem16 = new FANavigationViewItem());
		((ISupportInitialize)fANavigationViewItem15).BeginInit();
		menuItems8.Add(fANavigationViewItem15);
		fANavigationViewItem16.Content = Strings.Menu_PresetMods_Title;
		fANavigationViewItem16.Tag = "mods";
		Lucide lucide16;
		Lucide lucide15 = (lucide16 = new Lucide());
		((ISupportInitialize)lucide15).BeginInit();
		fANavigationViewItem16.Icon = lucide15;
		lucide16.Icon = LucideIconNames.BookOpen;
		((ISupportInitialize)lucide16).EndInit();
		((ISupportInitialize)fANavigationViewItem16).EndInit();
		IList<object> menuItems9 = fANavigationView4.MenuItems;
		FANavigationViewItem fANavigationViewItem18;
		FANavigationViewItem fANavigationViewItem17 = (fANavigationViewItem18 = new FANavigationViewItem());
		((ISupportInitialize)fANavigationViewItem17).BeginInit();
		menuItems9.Add(fANavigationViewItem17);
		fANavigationViewItem18.Content = Strings.Menu_Appearance_Title;
		fANavigationViewItem18.Tag = "appearance";
		Lucide lucide18;
		Lucide lucide17 = (lucide18 = new Lucide());
		((ISupportInitialize)lucide17).BeginInit();
		fANavigationViewItem18.Icon = lucide17;
		lucide18.Icon = LucideIconNames.Palette;
		((ISupportInitialize)lucide18).EndInit();
		((ISupportInitialize)fANavigationViewItem18).EndInit();
		IList<object> menuItems10 = fANavigationView4.MenuItems;
		FANavigationViewItem fANavigationViewItem20;
		FANavigationViewItem fANavigationViewItem19 = (fANavigationViewItem20 = new FANavigationViewItem());
		((ISupportInitialize)fANavigationViewItem19).BeginInit();
		menuItems10.Add(fANavigationViewItem19);
		fANavigationViewItem20.Content = Strings.Menu_FastFlags_Title;
		fANavigationViewItem20.Tag = "fastflags";
		Lucide lucide20;
		Lucide lucide19 = (lucide20 = new Lucide());
		((ISupportInitialize)lucide19).BeginInit();
		fANavigationViewItem20.Icon = lucide19;
		lucide20.Icon = LucideIconNames.Flag;
		((ISupportInitialize)lucide20).EndInit();
		((ISupportInitialize)fANavigationViewItem20).EndInit();
		IList<object> menuItems11 = fANavigationView4.MenuItems;
		FANavigationViewItem fANavigationViewItem22;
		FANavigationViewItem fANavigationViewItem21 = (fANavigationViewItem22 = new FANavigationViewItem());
		((ISupportInitialize)fANavigationViewItem21).BeginInit();
		menuItems11.Add(fANavigationViewItem21);
		fANavigationViewItem22.Name = "gbs";
		element = fANavigationViewItem22;
		context.AvaloniaNameScope.Register("gbs", element);
		fANavigationViewItem22.Content = Strings.Menu_GlobalSettings_Title;
		fANavigationViewItem22.Tag = "globalsettings";
		Lucide lucide22;
		Lucide lucide21 = (lucide22 = new Lucide());
		((ISupportInitialize)lucide21).BeginInit();
		fANavigationViewItem22.Icon = lucide21;
		lucide22.Icon = LucideIconNames.PenLine;
		((ISupportInitialize)lucide22).EndInit();
		((ISupportInitialize)fANavigationViewItem22).EndInit();
		IList<object> menuItems12 = fANavigationView4.MenuItems;
		FANavigationViewItem fANavigationViewItem24;
		FANavigationViewItem fANavigationViewItem23 = (fANavigationViewItem24 = new FANavigationViewItem());
		((ISupportInitialize)fANavigationViewItem23).BeginInit();
		menuItems12.Add(fANavigationViewItem23);
		fANavigationViewItem24.Name = "linux";
		element = fANavigationViewItem24;
		context.AvaloniaNameScope.Register("linux", element);
		fANavigationViewItem24.IsVisible = GlobalViewModel.IsLinux;
		fANavigationViewItem24.Content = Strings.Menu_LinuxSettings_Title;
		fANavigationViewItem24.Tag = "linuxsettings";
		Lucide lucide24;
		Lucide lucide23 = (lucide24 = new Lucide());
		((ISupportInitialize)lucide23).BeginInit();
		fANavigationViewItem24.Icon = lucide23;
		lucide24.Icon = LucideIconNames.Settings;
		((ISupportInitialize)lucide24).EndInit();
		((ISupportInitialize)fANavigationViewItem24).EndInit();
		IList<object> menuItems13 = fANavigationView4.MenuItems;
		FANavigationViewItem fANavigationViewItem26;
		FANavigationViewItem fANavigationViewItem25 = (fANavigationViewItem26 = new FANavigationViewItem());
		((ISupportInitialize)fANavigationViewItem25).BeginInit();
		menuItems13.Add(fANavigationViewItem25);
		fANavigationViewItem26.Content = Strings.Common_Shortcuts;
		fANavigationViewItem26.Tag = "shortcuts";
		Lucide lucide26;
		Lucide lucide25 = (lucide26 = new Lucide());
		((ISupportInitialize)lucide25).BeginInit();
		fANavigationViewItem26.Icon = lucide25;
		lucide26.Icon = LucideIconNames.Link2;
		((ISupportInitialize)lucide26).EndInit();
		((ISupportInitialize)fANavigationViewItem26).EndInit();
		IList<object> footerMenuItems = fANavigationView4.FooterMenuItems;
		FANavigationViewItem fANavigationViewItem28;
		FANavigationViewItem fANavigationViewItem27 = (fANavigationViewItem28 = new FANavigationViewItem());
		((ISupportInitialize)fANavigationViewItem27).BeginInit();
		footerMenuItems.Add(fANavigationViewItem27);
		fANavigationViewItem28.Content = Strings.Menu_About_Title;
		fANavigationViewItem28.Tag = "about";
		Lucide lucide28;
		Lucide lucide27 = (lucide28 = new Lucide());
		((ISupportInitialize)lucide27).BeginInit();
		fANavigationViewItem28.Icon = lucide27;
		lucide28.Icon = LucideIconNames.CircleAlert;
		((ISupportInitialize)lucide28).EndInit();
		((ISupportInitialize)fANavigationViewItem28).EndInit();
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		fANavigationView4.Content = grid6;
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		RowDefinitions rowDefinitions2 = new RowDefinitions();
		rowDefinitions2.Capacity = 2;
		rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions2.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid9.RowDefinitions = rowDefinitions2;
		Avalonia.Controls.Controls children3 = grid9.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children3.Add(border);
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Border border5 = border4;
		Grid.SetRow(border5, 0);
		StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension10 = new DynamicResourceExtension("ControlElevationBorderBrush");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding6 = dynamicResourceExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(borderBrushProperty, binding6);
		border5.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		border5.Child = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		StackPanel stackPanel5 = stackPanel4;
		Avalonia.Controls.Controls children4 = stackPanel5.Children;
		StackPanel stackPanel7;
		StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
		((ISupportInitialize)stackPanel6).BeginInit();
		children4.Add(stackPanel6);
		StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
		context.PushParent(stackPanel4);
		StackPanel stackPanel9 = stackPanel4;
		stackPanel9.Margin = new Thickness(18.0, 8.0, 18.0, 0.0);
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMainWindowViewModel_002CMerostrap_002EHasBreadcrumbs_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding7 = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		stackPanel9.Bind(isVisibleProperty, binding7);
		Avalonia.Controls.Controls children5 = stackPanel9.Children;
		StackPanel stackPanel11;
		StackPanel stackPanel10 = (stackPanel11 = new StackPanel());
		((ISupportInitialize)stackPanel10).BeginInit();
		children5.Add(stackPanel10);
		StackPanel stackPanel12 = (stackPanel4 = stackPanel11);
		context.PushParent(stackPanel4);
		StackPanel stackPanel13 = stackPanel4;
		stackPanel13.Orientation = Orientation.Horizontal;
		stackPanel13.Margin = new Thickness(0.0, 0.0, 0.0, 4.0);
		Avalonia.Controls.Controls children6 = stackPanel13.Children;
		ItemsControl itemsControl2;
		ItemsControl itemsControl = (itemsControl2 = new ItemsControl());
		((ISupportInitialize)itemsControl).BeginInit();
		children6.Add(itemsControl);
		ItemsControl itemsControl4;
		ItemsControl itemsControl3 = (itemsControl4 = itemsControl2);
		context.PushParent(itemsControl4);
		StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMainWindowViewModel_002CMerostrap_002EHasBreadcrumbs_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding8 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		itemsControl4.Bind(isVisibleProperty2, binding8);
		StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMainWindowViewModel_002CMerostrap_002EBreadcrumbItems_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding9 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		itemsControl4.Bind(itemsSourceProperty, binding9);
		itemsControl4.ItemsPanel = new ItemsPanelTemplate
		{
			Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_35.Build_1), context)
		};
		DataTemplate dataTemplate;
		DataTemplate itemTemplate = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.DataType = typeof(BreadcrumbItemModel);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_35.Build_2), context);
		context.PopParent();
		itemsControl4.ItemTemplate = itemTemplate;
		context.PopParent();
		((ISupportInitialize)itemsControl3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel12).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel8).EndInit();
		Avalonia.Controls.Controls children7 = stackPanel5.Children;
		FAInfoBar fAInfoBar2;
		FAInfoBar fAInfoBar = (fAInfoBar2 = new FAInfoBar());
		((ISupportInitialize)fAInfoBar).BeginInit();
		children7.Add(fAInfoBar);
		fAInfoBar2.Name = "AlertBar";
		element = fAInfoBar2;
		context.AvaloniaNameScope.Register("AlertBar", element);
		fAInfoBar2.Margin = new Thickness(12.0, 4.0, 12.0, 8.0);
		fAInfoBar2.IsOpen = false;
		fAInfoBar2.IsClosable = false;
		fAInfoBar2.Severity = FAInfoBarSeverity.Informational;
		((ISupportInitialize)fAInfoBar2).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		Avalonia.Controls.Controls children8 = grid9.Children;
		Panel panel6;
		Panel panel5 = (panel6 = new Panel());
		((ISupportInitialize)panel5).BeginInit();
		children8.Add(panel5);
		Grid.SetRow(panel6, 1);
		Avalonia.Controls.Controls children9 = panel6.Children;
		TransitioningContentControl transitioningContentControl2;
		TransitioningContentControl transitioningContentControl = (transitioningContentControl2 = new TransitioningContentControl());
		((ISupportInitialize)transitioningContentControl).BeginInit();
		children9.Add(transitioningContentControl);
		transitioningContentControl2.Name = "PageContentControl";
		element = transitioningContentControl2;
		context.AvaloniaNameScope.Register("PageContentControl", element);
		transitioningContentControl2.HorizontalAlignment = HorizontalAlignment.Stretch;
		transitioningContentControl2.VerticalAlignment = VerticalAlignment.Stretch;
		FluentEntranceTransition fluentEntranceTransition = new FluentEntranceTransition();
		fluentEntranceTransition.VerticalOffset = 150.0;
		fluentEntranceTransition.Duration = TimeSpan.FromTicks(3500000L);
		transitioningContentControl2.PageTransition = fluentEntranceTransition;
		((ISupportInitialize)transitioningContentControl2).EndInit();
		((ISupportInitialize)panel6).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		context.PopParent();
		((ISupportInitialize)fANavigationView3).EndInit();
		Avalonia.Controls.Controls children10 = grid5.Children;
		Border border7;
		Border border6 = (border7 = new Border());
		((ISupportInitialize)border6).BeginInit();
		children10.Add(border6);
		Border border8 = (border4 = border7);
		context.PushParent(border4);
		Border border9 = border4;
		Grid.SetRow(border9, 2);
		border9.Height = 56.0;
		border9.Padding = new Thickness(0.0, 0.0, 16.0, 0.0);
		StyledProperty<IBrush?> backgroundProperty4 = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension11 = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding10 = dynamicResourceExtension11.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border9.Bind(backgroundProperty4, binding10);
		StyledProperty<IBrush?> borderBrushProperty2 = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension12 = new DynamicResourceExtension("ControlStrokeColorDefault");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding11 = dynamicResourceExtension12.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border9.Bind(borderBrushProperty2, binding11);
		border9.BorderThickness = new Thickness(0.0, 1.0, 0.0, 0.0);
		Grid grid11;
		Grid grid10 = (grid11 = new Grid());
		((ISupportInitialize)grid10).BeginInit();
		border9.Child = grid10;
		Grid grid12 = (grid4 = grid11);
		context.PushParent(grid4);
		Grid grid13 = grid4;
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 6;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid13.ColumnDefinitions = columnDefinitions;
		grid13.ColumnSpacing = 8.0;
		Avalonia.Controls.Controls children11 = grid13.Children;
		AccountSelectorView accountSelectorView2;
		AccountSelectorView accountSelectorView = (accountSelectorView2 = new AccountSelectorView());
		((ISupportInitialize)accountSelectorView).BeginInit();
		children11.Add(accountSelectorView);
		accountSelectorView2.Name = "AccountSelectorView";
		element = accountSelectorView2;
		context.AvaloniaNameScope.Register("AccountSelectorView", element);
		Grid.SetColumn(accountSelectorView2, 0);
		accountSelectorView2.Margin = new Thickness(8.0, 0.0, 0.0, 0.0);
		((ISupportInitialize)accountSelectorView2).EndInit();
		Avalonia.Controls.Controls children12 = grid13.Children;
		IconButton iconButton7;
		IconButton iconButton6 = (iconButton7 = new IconButton());
		((ISupportInitialize)iconButton6).BeginInit();
		children12.Add(iconButton6);
		IconButton iconButton8 = (iconButton4 = iconButton7);
		context.PushParent(iconButton4);
		IconButton iconButton9 = iconButton4;
		Grid.SetColumn(iconButton9, 2);
		iconButton9.FontWeight = FontWeight.DemiBold;
		iconButton9.Height = 36.0;
		iconButton9.Padding = new Thickness(20.0, 0.0, 20.0, 0.0);
		iconButton9.Classes.Add("DropDownButton");
		iconButton9.Classes.Add("Primary");
		StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMainWindowViewModel_002CMerostrap_002ESaveAndLaunchSettingsCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding12 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		iconButton9.Bind(commandProperty, binding12);
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMainWindowViewModel_002CMerostrap_002ELaunchButtonText_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ContentControl.ContentProperty;
		CompiledBinding compiledBinding = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_4(iconButton9, compiledBinding);
		MenuFlyout menuFlyout;
		MenuFlyout flyout = (menuFlyout = new MenuFlyout());
		context.PushParent(menuFlyout);
		menuFlyout.Placement = PlacementMode.TopEdgeAlignedRight;
		ItemCollection items = menuFlyout.Items;
		MenuItem menuItem2;
		MenuItem menuItem = (menuItem2 = new MenuItem());
		((ISupportInitialize)menuItem).BeginInit();
		items.Add(menuItem);
		MenuItem menuItem4;
		MenuItem menuItem3 = (menuItem4 = menuItem2);
		context.PushParent(menuItem4);
		MenuItem menuItem5 = menuItem4;
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMainWindowViewModel_002CMerostrap_002EPlayerMenuItemText_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = HeaderedSelectingItemsControl.HeaderProperty;
		CompiledBinding compiledBinding2 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_14(menuItem5, compiledBinding2);
		StyledProperty<ICommand?> commandProperty2 = MenuItem.CommandProperty;
		CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMainWindowViewModel_002CMerostrap_002ESetLaunchModeCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = MenuItem.CommandProperty;
		CompiledBinding binding13 = compiledBindingExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		menuItem5.Bind(commandProperty2, binding13);
		menuItem5.CommandParameter = LaunchMode.Player;
		Lucide lucide30;
		Lucide lucide29 = (lucide30 = new Lucide());
		((ISupportInitialize)lucide29).BeginInit();
		menuItem5.Icon = lucide29;
		lucide30.Icon = LucideIconNames.Gamepad2;
		((ISupportInitialize)lucide30).EndInit();
		context.PopParent();
		((ISupportInitialize)menuItem3).EndInit();
		ItemCollection items2 = menuFlyout.Items;
		MenuItem menuItem7;
		MenuItem menuItem6 = (menuItem7 = new MenuItem());
		((ISupportInitialize)menuItem6).BeginInit();
		items2.Add(menuItem6);
		MenuItem menuItem8 = (menuItem4 = menuItem7);
		context.PushParent(menuItem4);
		MenuItem menuItem9 = menuItem4;
		menuItem9.Header = Strings.Common_Studio;
		StyledProperty<ICommand?> commandProperty3 = MenuItem.CommandProperty;
		CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMainWindowViewModel_002CMerostrap_002ESetLaunchModeCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = MenuItem.CommandProperty;
		CompiledBinding binding14 = compiledBindingExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		menuItem9.Bind(commandProperty3, binding14);
		menuItem9.CommandParameter = LaunchMode.Studio;
		Lucide lucide32;
		Lucide lucide31 = (lucide32 = new Lucide());
		((ISupportInitialize)lucide31).BeginInit();
		menuItem9.Icon = lucide31;
		lucide32.Icon = LucideIconNames.Wrench;
		((ISupportInitialize)lucide32).EndInit();
		context.PopParent();
		((ISupportInitialize)menuItem8).EndInit();
		context.PopParent();
		iconButton9.Flyout = flyout;
		context.PopParent();
		((ISupportInitialize)iconButton8).EndInit();
		Avalonia.Controls.Controls children13 = grid13.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children13.Add(button);
		Button button4;
		Button button3 = (button4 = button2);
		context.PushParent(button4);
		Button button5 = button4;
		button5.FontWeight = FontWeight.DemiBold;
		Grid.SetColumn(button5, 3);
		button5.Height = 36.0;
		button5.Padding = new Thickness(20.0, 0.0, 20.0, 0.0);
		button5.Classes.Add("accent");
		StyledProperty<ICommand?> commandProperty4 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMainWindowViewModel_002CMerostrap_002ERestartAppCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding15 = compiledBindingExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button5.Bind(commandProperty4, binding15);
		button5.Content = Strings.Menu_Restart;
		context.PopParent();
		((ISupportInitialize)button3).EndInit();
		Avalonia.Controls.Controls children14 = grid13.Children;
		Button button7;
		Button button6 = (button7 = new Button());
		((ISupportInitialize)button6).BeginInit();
		children14.Add(button6);
		Button button8 = (button4 = button7);
		context.PushParent(button4);
		Button button9 = button4;
		button9.FontWeight = FontWeight.DemiBold;
		Grid.SetColumn(button9, 4);
		button9.Height = 36.0;
		button9.Padding = new Thickness(20.0, 0.0, 20.0, 0.0);
		button9.Classes.Add("accent");
		StyledProperty<ICommand?> commandProperty5 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMainWindowViewModel_002CMerostrap_002ESaveSettingsCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding16 = compiledBindingExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button9.Bind(commandProperty5, binding16);
		button9.Content = Strings.Menu_Save;
		context.PopParent();
		((ISupportInitialize)button8).EndInit();
		Avalonia.Controls.Controls children15 = grid13.Children;
		Button button11;
		Button button10 = (button11 = new Button());
		((ISupportInitialize)button10).BeginInit();
		children15.Add(button10);
		Button button12 = (button4 = button11);
		context.PushParent(button4);
		Button button13 = button4;
		button13.FontWeight = FontWeight.DemiBold;
		Grid.SetColumn(button13, 5);
		button13.Height = 36.0;
		button13.Padding = new Thickness(20.0, 0.0, 20.0, 0.0);
		StyledProperty<ICommand?> commandProperty6 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMainWindowViewModel_002CMerostrap_002ECloseWindowCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding17 = compiledBindingExtension11.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button13.Bind(commandProperty6, binding17);
		button13.Content = Strings.Common_Close;
		context.PopParent();
		((ISupportInitialize)button12).EndInit();
		context.PopParent();
		((ISupportInitialize)grid12).EndInit();
		context.PopParent();
		((ISupportInitialize)border8).EndInit();
		Avalonia.Controls.Controls children16 = grid5.Children;
		Panel panel8;
		Panel panel7 = (panel8 = new Panel());
		((ISupportInitialize)panel7).BeginInit();
		children16.Add(panel7);
		panel8.Name = "NotificationPanel";
		element = panel8;
		context.AvaloniaNameScope.Register("NotificationPanel", element);
		Grid.SetRow(panel8, 0);
		Grid.SetRowSpan(panel8, 3);
		panel8.Margin = new Thickness(0.0, 50.0, 0.0, 0.0);
		panel8.HorizontalAlignment = HorizontalAlignment.Stretch;
		panel8.VerticalAlignment = VerticalAlignment.Top;
		panel8.ZIndex = 1000;
		((ISupportInitialize)panel8).EndInit();
		Avalonia.Controls.Controls children17 = grid5.Children;
		Border border11;
		Border border10 = (border11 = new Border());
		((ISupportInitialize)border10).BeginInit();
		children17.Add(border10);
		border11.Name = "OffscreenIndexingCanvas";
		element = border11;
		context.AvaloniaNameScope.Register("OffscreenIndexingCanvas", element);
		Grid.SetRow(border11, 1);
		Grid.SetColumn(border11, 1);
		border11.Width = 905.0;
		border11.Height = 700.0;
		border11.IsHitTestVisible = false;
		border11.IsVisible = false;
		border11.Opacity = 0.0;
		border11.ZIndex = -1000;
		((ISupportInitialize)border11).EndInit();
		Avalonia.Controls.Controls children18 = grid5.Children;
		SearchDialog searchDialog2;
		SearchDialog searchDialog = (searchDialog2 = new SearchDialog());
		((ISupportInitialize)searchDialog).BeginInit();
		children18.Add(searchDialog);
		searchDialog2.Name = "SearchOverlay";
		element = searchDialog2;
		context.AvaloniaNameScope.Register("SearchOverlay", element);
		Grid.SetRow(searchDialog2, 0);
		Grid.SetRowSpan(searchDialog2, 3);
		searchDialog2.ZIndex = 2000;
		((ISupportInitialize)searchDialog2).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(MainWindow P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
