using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Input;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Controls.Presenters;
using Avalonia.Controls.Primitives;
using Avalonia.Controls.Shapes;
using Avalonia.Data;
using Avalonia.Data.Converters;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using Avalonia.Styling;
using CompiledAvaloniaXaml;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.Models;
using Merostrap.Resources;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.Elements.Dialogs;
using Merostrap.UI.ViewModels.Settings;

namespace Merostrap.UI.Elements.Settings;

internal class AccountSelectorView : UserControl, IDisposable
{
	[CompilerGenerated]
	private class XamlClosure_34
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<AccountSelectorView> context = CreateContext(P_0);
			context.IntermediateRoot = new StackPanel();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((AvaloniaObject)obj).SetValue(StackPanel.SpacingProperty, 0.0, BindingPriority.Template);
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<AccountSelectorView> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<AccountSelectorView> context = new XamlIlContext.Context<AccountSelectorView>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FAccountSelectorView_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/AccountSelectorView.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (AccountSelectorView)service;
				}
			}
			return context;
		}

		public static object Build_2(IServiceProvider P_0)
		{
			XamlIlContext.Context<AccountSelectorView> context = CreateContext(P_0);
			context.IntermediateRoot = new Button();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Button button = (Button)obj;
			context.PushParent(button);
			button.Background = new ImmutableSolidColorBrush(16777215u);
			button.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
			button.Padding = new Thickness(12.0, 10.0, 12.0, 10.0);
			button.HorizontalAlignment = HorizontalAlignment.Stretch;
			button.HorizontalContentAlignment = HorizontalAlignment.Stretch;
			StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Ancestor(typeof(ItemsControl), 0).Property(StyledElement.DataContextProperty, PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor).TypeCast<AccountSelectorViewModel>()
				.Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EAccountSelectorViewModel_002CMerostrap_002ESelectAccountCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)
				.Build());
			context.ProvideTargetProperty = Button.CommandProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			button.Bind(commandProperty, binding);
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension();
			context.ProvideTargetProperty = Button.CommandParameterProperty;
			CompiledBinding compiledBinding = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_6(button, compiledBinding);
			Styles styles = button.Styles;
			Style style;
			Style item = (style = new Style());
			context.PushParent(style);
			style.Selector = ((Selector?)null).OfType(typeof(Button)).Class(":pointerover").Template()
				.OfType(typeof(ContentPresenter));
			Setter setter2;
			Setter setter = (setter2 = new Setter());
			context.PushParent(setter2);
			setter2.Property = ContentPresenter.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("ControlFillColorSecondaryBrush");
			context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
			BindingBase value = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			setter2.Value = value;
			context.PopParent();
			style.Add(setter);
			context.PopParent();
			styles.Add(item);
			Grid grid2;
			Grid grid = (grid2 = new Grid());
			((ISupportInitialize)grid).BeginInit();
			button.Content = grid;
			Grid grid4;
			Grid grid3 = (grid4 = grid2);
			context.PushParent(grid4);
			Grid grid5 = grid4;
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 2;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid5.ColumnDefinitions = columnDefinitions;
			grid5.HorizontalAlignment = HorizontalAlignment.Stretch;
			grid5.VerticalAlignment = VerticalAlignment.Center;
			Avalonia.Controls.Controls children = grid5.Children;
			Grid grid7;
			Grid grid6 = (grid7 = new Grid());
			((ISupportInitialize)grid6).BeginInit();
			children.Add(grid6);
			Grid grid8 = (grid4 = grid7);
			context.PushParent(grid4);
			Grid grid9 = grid4;
			Grid.SetColumn(grid9, 0);
			ColumnDefinitions columnDefinitions2 = new ColumnDefinitions();
			columnDefinitions2.Capacity = 2;
			columnDefinitions2.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid9.ColumnDefinitions = columnDefinitions2;
			grid9.HorizontalAlignment = HorizontalAlignment.Stretch;
			grid9.VerticalAlignment = VerticalAlignment.Center;
			Avalonia.Controls.Controls children2 = grid9.Children;
			Grid grid11;
			Grid grid10 = (grid11 = new Grid());
			((ISupportInitialize)grid10).BeginInit();
			children2.Add(grid10);
			Grid grid12 = (grid4 = grid11);
			context.PushParent(grid4);
			Grid grid13 = grid4;
			Grid.SetColumn(grid13, 0);
			grid13.Width = 32.0;
			grid13.Height = 32.0;
			Avalonia.Controls.Controls children3 = grid13.Children;
			Border border2;
			Border border = (border2 = new Border());
			((ISupportInitialize)border).BeginInit();
			children3.Add(border);
			Border border4;
			Border border3 = (border4 = border2);
			context.PushParent(border4);
			border4.CornerRadius = new CornerRadius(16.0, 16.0, 16.0, 16.0);
			StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("ControlFillColorSecondaryBrush");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border4.Bind(backgroundProperty, binding2);
			border4.ClipToBounds = true;
			Panel panel2;
			Panel panel = (panel2 = new Panel());
			((ISupportInitialize)panel).BeginInit();
			border4.Child = panel;
			Panel panel4;
			Panel panel3 = (panel4 = panel2);
			context.PushParent(panel4);
			Avalonia.Controls.Controls children4 = panel4.Children;
			Lucide lucide2;
			Lucide lucide = (lucide2 = new Lucide());
			((ISupportInitialize)lucide).BeginInit();
			children4.Add(lucide);
			Lucide lucide4;
			Lucide lucide3 = (lucide4 = lucide2);
			context.PushParent(lucide4);
			lucide4.Icon = LucideIconNames.User;
			lucide4.Height = 16.0;
			lucide4.Width = 16.0;
			StyledProperty<IBrush?> foregroundProperty = TemplatedControl.ForegroundProperty;
			DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("TextFillColorSecondaryBrush");
			context.ProvideTargetProperty = TemplatedControl.ForegroundProperty;
			BindingBase binding3 = dynamicResourceExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			lucide4.Bind(foregroundProperty, binding3);
			lucide4.HorizontalAlignment = HorizontalAlignment.Center;
			lucide4.VerticalAlignment = VerticalAlignment.Center;
			StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers._002EAccountWithAvatar_002CMerostrap_002EAvatarUrl_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
			{
				Converter = StringConverters.IsNullOrEmpty
			};
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding4 = compiledBindingExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			lucide4.Bind(isVisibleProperty, binding4);
			context.PopParent();
			((ISupportInitialize)lucide3).EndInit();
			Avalonia.Controls.Controls children5 = panel4.Children;
			RemoteImage remoteImage2;
			RemoteImage remoteImage = (remoteImage2 = new RemoteImage());
			((ISupportInitialize)remoteImage).BeginInit();
			children5.Add(remoteImage);
			RemoteImage remoteImage4;
			RemoteImage remoteImage3 = (remoteImage4 = remoteImage2);
			context.PushParent(remoteImage4);
			StyledProperty<string?> urlProperty = RemoteImage.UrlProperty;
			CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers._002EAccountWithAvatar_002CMerostrap_002EAvatarUrl_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = RemoteImage.UrlProperty;
			CompiledBinding binding5 = compiledBindingExtension4.ProvideValue(context);
			context.ProvideTargetProperty = null;
			remoteImage4.Bind(urlProperty, binding5);
			remoteImage4.Stretch = Stretch.UniformToFill;
			StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers._002EAccountWithAvatar_002CMerostrap_002EAvatarUrl_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
			{
				Converter = StringConverters.IsNotNullOrEmpty
			};
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding6 = compiledBindingExtension5.ProvideValue(context);
			context.ProvideTargetProperty = null;
			remoteImage4.Bind(isVisibleProperty2, binding6);
			context.PopParent();
			((ISupportInitialize)remoteImage3).EndInit();
			context.PopParent();
			((ISupportInitialize)panel3).EndInit();
			context.PopParent();
			((ISupportInitialize)border3).EndInit();
			Avalonia.Controls.Controls children6 = grid13.Children;
			Ellipse ellipse2;
			Ellipse ellipse = (ellipse2 = new Ellipse());
			((ISupportInitialize)ellipse).BeginInit();
			children6.Add(ellipse);
			Ellipse ellipse4;
			Ellipse ellipse3 = (ellipse4 = ellipse2);
			context.PushParent(ellipse4);
			ellipse4.Width = 10.0;
			ellipse4.Height = 10.0;
			ellipse4.HorizontalAlignment = HorizontalAlignment.Right;
			ellipse4.VerticalAlignment = VerticalAlignment.Bottom;
			ellipse4.Margin = new Thickness(0.0, 0.0, -2.0, -2.0);
			CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers._002EAccountWithAvatar_002CMerostrap_002EPresenceStatus_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = ToolTip.TipProperty;
			CompiledBinding compiledBinding2 = compiledBindingExtension6.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_11((ToolTip)(object)ellipse4, compiledBinding2);
			StyledProperty<IBrush?> fillProperty = Shape.FillProperty;
			CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers._002EAccountWithAvatar_002CMerostrap_002EPresenceBrush_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Shape.FillProperty;
			CompiledBinding binding7 = compiledBindingExtension7.ProvideValue(context);
			context.ProvideTargetProperty = null;
			ellipse4.Bind(fillProperty, binding7);
			StyledProperty<bool> isVisibleProperty3 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers._002EAccountWithAvatar_002CMerostrap_002EPresenceStatus_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
			{
				Converter = StringConverters.IsNotNullOrEmpty
			};
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding8 = compiledBindingExtension8.ProvideValue(context);
			context.ProvideTargetProperty = null;
			ellipse4.Bind(isVisibleProperty3, binding8);
			context.PopParent();
			((ISupportInitialize)ellipse3).EndInit();
			context.PopParent();
			((ISupportInitialize)grid12).EndInit();
			Avalonia.Controls.Controls children7 = grid9.Children;
			StackPanel stackPanel2;
			StackPanel stackPanel = (stackPanel2 = new StackPanel());
			((ISupportInitialize)stackPanel).BeginInit();
			children7.Add(stackPanel);
			StackPanel stackPanel4;
			StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
			context.PushParent(stackPanel4);
			StackPanel stackPanel5 = stackPanel4;
			Grid.SetColumn(stackPanel5, 1);
			stackPanel5.Margin = new Thickness(12.0, 0.0, 0.0, 0.0);
			stackPanel5.VerticalAlignment = VerticalAlignment.Center;
			stackPanel5.Spacing = 2.0;
			stackPanel5.MaxWidth = 125.0;
			Avalonia.Controls.Controls children8 = stackPanel5.Children;
			TextBlock textBlock2;
			TextBlock textBlock = (textBlock2 = new TextBlock());
			((ISupportInitialize)textBlock).BeginInit();
			children8.Add(textBlock);
			TextBlock textBlock4;
			TextBlock textBlock3 = (textBlock4 = textBlock2);
			context.PushParent(textBlock4);
			TextBlock textBlock5 = textBlock4;
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers._002EAccountWithAvatar_002CMerostrap_002EDisplayName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding9 = compiledBindingExtension9.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock5.Bind(textProperty, binding9);
			textBlock5.FontSize = 12.0;
			textBlock5.FontWeight = FontWeight.DemiBold;
			textBlock5.TextTrimming = TextTrimming.CharacterEllipsis;
			context.PopParent();
			((ISupportInitialize)textBlock3).EndInit();
			Avalonia.Controls.Controls children9 = stackPanel5.Children;
			TextBlock textBlock7;
			TextBlock textBlock6 = (textBlock7 = new TextBlock());
			((ISupportInitialize)textBlock6).BeginInit();
			children9.Add(textBlock6);
			TextBlock textBlock8 = (textBlock4 = textBlock7);
			context.PushParent(textBlock4);
			TextBlock textBlock9 = textBlock4;
			StyledProperty<string?> textProperty2 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers._002EAccountWithAvatar_002CMerostrap_002EUsername_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
			{
				StringFormat = "@{0}"
			};
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding10 = compiledBindingExtension10.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock9.Bind(textProperty2, binding10);
			textBlock9.FontSize = 10.0;
			textBlock9.TextTrimming = TextTrimming.CharacterEllipsis;
			context.PopParent();
			((ISupportInitialize)textBlock8).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel3).EndInit();
			context.PopParent();
			((ISupportInitialize)grid8).EndInit();
			Avalonia.Controls.Controls children10 = grid5.Children;
			StackPanel stackPanel7;
			StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
			((ISupportInitialize)stackPanel6).BeginInit();
			children10.Add(stackPanel6);
			StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
			context.PushParent(stackPanel4);
			StackPanel stackPanel9 = stackPanel4;
			Grid.SetColumn(stackPanel9, 1);
			stackPanel9.Orientation = Orientation.Horizontal;
			stackPanel9.Spacing = 4.0;
			stackPanel9.Margin = new Thickness(12.0, 0.0, 0.0, 0.0);
			Avalonia.Controls.Controls children11 = stackPanel9.Children;
			IconButton iconButton2;
			IconButton iconButton = (iconButton2 = new IconButton());
			((ISupportInitialize)iconButton).BeginInit();
			children11.Add(iconButton);
			IconButton iconButton4;
			IconButton iconButton3 = (iconButton4 = iconButton2);
			context.PushParent(iconButton4);
			IconButton iconButton5 = iconButton4;
			iconButton5.Width = 32.0;
			iconButton5.Height = 32.0;
			iconButton5.Padding = new Thickness(4.0, 4.0, 4.0, 4.0);
			iconButton5.Icon = LucideIconNames.ArrowLeftRight;
			iconButton5.IconSize = 14.0;
			ToolTip.SetTip(iconButton5, "Use this account");
			StyledProperty<ICommand?> commandProperty2 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Ancestor(typeof(ItemsControl), 0).Property(StyledElement.DataContextProperty, PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor).TypeCast<AccountSelectorViewModel>()
				.Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EAccountSelectorViewModel_002CMerostrap_002EApplyAccountCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)
				.Build());
			context.ProvideTargetProperty = Button.CommandProperty;
			CompiledBinding binding11 = compiledBindingExtension11.ProvideValue(context);
			context.ProvideTargetProperty = null;
			iconButton5.Bind(commandProperty2, binding11);
			CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension();
			context.ProvideTargetProperty = Button.CommandParameterProperty;
			CompiledBinding compiledBinding3 = compiledBindingExtension12.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_6(iconButton5, compiledBinding3);
			context.PopParent();
			((ISupportInitialize)iconButton3).EndInit();
			Avalonia.Controls.Controls children12 = stackPanel9.Children;
			IconButton iconButton7;
			IconButton iconButton6 = (iconButton7 = new IconButton());
			((ISupportInitialize)iconButton6).BeginInit();
			children12.Add(iconButton6);
			IconButton iconButton8 = (iconButton4 = iconButton7);
			context.PushParent(iconButton4);
			IconButton iconButton9 = iconButton4;
			iconButton9.Width = 32.0;
			iconButton9.Height = 32.0;
			iconButton9.Padding = new Thickness(4.0, 4.0, 4.0, 4.0);
			iconButton9.Icon = LucideIconNames.Trash2;
			iconButton9.IconSize = 14.0;
			iconButton9.Classes.Add("Danger");
			ToolTip.SetTip(iconButton9, "Remove this account");
			StyledProperty<ICommand?> commandProperty3 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Ancestor(typeof(ItemsControl), 0).Property(StyledElement.DataContextProperty, PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor).TypeCast<AccountSelectorViewModel>()
				.Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EAccountSelectorViewModel_002CMerostrap_002EDeleteAccountCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)
				.Build());
			context.ProvideTargetProperty = Button.CommandProperty;
			CompiledBinding binding12 = compiledBindingExtension13.ProvideValue(context);
			context.ProvideTargetProperty = null;
			iconButton9.Bind(commandProperty3, binding12);
			CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension();
			context.ProvideTargetProperty = Button.CommandParameterProperty;
			CompiledBinding compiledBinding4 = compiledBindingExtension14.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_6(iconButton9, compiledBinding4);
			context.PopParent();
			((ISupportInitialize)iconButton8).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel8).EndInit();
			context.PopParent();
			((ISupportInitialize)grid3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}
	}

	private readonly AccountSelectorViewModel? _viewModel;

	private bool _disposed;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button AccountButton;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Popup AccountDropdown;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public AccountSelectorView()
	{
		InitializeComponent();
		_viewModel = new AccountSelectorViewModel();
		DataContext = _viewModel;
	}

	protected override void OnInitialized()
	{
		base.OnInitialized();
		AccountSelectorViewModel? viewModel = _viewModel;
		if (viewModel != null)
		{
			viewModel.OnManualAddRequested += HandleManualAddRequested;
		}
	}

	protected override void OnLoaded(RoutedEventArgs e)
	{
		base.OnLoaded(e);
	}

	private async void HandleManualAddRequested()
	{
		await ShowManualAccountDialogAsync();
	}

	private async Task ShowManualAccountDialogAsync()
	{
		try
		{
			App.Logger.Info("Showing manual cookie dialog");
			ManualCookieDialog manualCookieDialog = new ManualCookieDialog();
			IClassicDesktopStyleApplicationLifetime classicDesktopStyleApplicationLifetime = Application.Current?.ApplicationLifetime as IClassicDesktopStyleApplicationLifetime;
			Window window = classicDesktopStyleApplicationLifetime?.MainWindow ?? ((classicDesktopStyleApplicationLifetime != null && classicDesktopStyleApplicationLifetime.Windows.Count > 0) ? classicDesktopStyleApplicationLifetime.Windows[0] : null);
			if (window != null)
			{
				AccountManagerAccount accountManagerAccount = await manualCookieDialog.ShowDialog<AccountManagerAccount>(window);
				if (accountManagerAccount != null)
				{
					App.Logger.Info("Dialog returned account: " + accountManagerAccount.Username);
					_viewModel?.AddAccountDirect(accountManagerAccount);
				}
			}
			else
			{
				App.Logger.Error("Could not find a parent window.");
			}
		}
		catch (Exception ex)
		{
			App.Logger.Error("Couldn't show manual dialog: " + ex.Message);
		}
		finally
		{
			AccountSelectorViewModel? viewModel = _viewModel;
			if (viewModel != null)
			{
				viewModel.IsAddingAccount = false;
			}
		}
	}

	protected override void OnUnloaded(RoutedEventArgs e)
	{
		AccountSelectorViewModel? viewModel = _viewModel;
		if (viewModel != null)
		{
			viewModel.OnManualAddRequested -= HandleManualAddRequested;
		}
		base.OnUnloaded(e);
	}

	public void Dispose()
	{
		Dispose(disposing: true);
		GC.SuppressFinalize(this);
	}

	protected virtual void Dispose(bool disposing)
	{
		if (!_disposed)
		{
			if (disposing)
			{
				_viewModel?.Dispose();
			}
			_disposed = true;
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		AccountButton = nameScope?.Find<Button>("AccountButton");
		AccountDropdown = nameScope?.Find<Popup>("AccountDropdown");
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, AccountSelectorView P_1)
	{
		XamlIlContext.Context<AccountSelectorView> context = new XamlIlContext.Context<AccountSelectorView>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FAccountSelectorView_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/AccountSelectorView.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		Styles styles = P_1.Styles;
		Style style;
		Style item = (style = new Style());
		context.PushParent(style);
		Style style2 = style;
		style2.Selector = ((Selector?)null).OfType(typeof(Button)).Name("AccountButton");
		Setter setter = new Setter();
		setter.Property = TemplatedControl.BackgroundProperty;
		setter.Value = new ImmutableSolidColorBrush(16777215u);
		style2.Add(setter);
		Setter setter3;
		Setter setter2 = (setter3 = new Setter());
		context.PushParent(setter3);
		Setter setter4 = setter3;
		setter4.Property = TemplatedControl.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("TextFillColorSecondaryBrush");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter4.Value = value;
		context.PopParent();
		style2.Add(setter2);
		Setter setter5 = new Setter();
		setter5.Property = TemplatedControl.BorderThicknessProperty;
		setter5.Value = new Thickness(0.0, 0.0, 0.0, 0.0);
		style2.Add(setter5);
		Setter setter6 = new Setter();
		setter6.Property = TemplatedControl.PaddingProperty;
		setter6.Value = new Thickness(10.0, 0.0, 10.0, 0.0);
		style2.Add(setter6);
		Setter setter7 = new Setter();
		setter7.Property = Layoutable.HeightProperty;
		setter7.Value = 40.0;
		style2.Add(setter7);
		Setter setter8 = new Setter();
		setter8.Property = TemplatedControl.CornerRadiusProperty;
		setter8.Value = new CornerRadius(6.0, 6.0, 6.0, 6.0);
		style2.Add(setter8);
		Setter setter9 = new Setter();
		setter9.Property = InputElement.CursorProperty;
		setter9.Value = new Cursor(StandardCursorType.Hand);
		style2.Add(setter9);
		Setter setter10 = new Setter();
		setter10.Property = Layoutable.HorizontalAlignmentProperty;
		setter10.Value = HorizontalAlignment.Stretch;
		style2.Add(setter10);
		context.PopParent();
		styles.Add(item);
		Styles styles2 = P_1.Styles;
		Style item2 = (style = new Style());
		context.PushParent(style);
		Style style3 = style;
		style3.Selector = ((Selector?)null).OfType(typeof(Button)).Name("AccountButton").Class(":pointerover")
			.Template()
			.OfType(typeof(ContentPresenter));
		Setter setter11 = (setter3 = new Setter());
		context.PushParent(setter3);
		Setter setter12 = setter3;
		setter12.Property = ContentPresenter.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("SystemAccentColor10");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value2 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter12.Value = value2;
		context.PopParent();
		style3.Add(setter11);
		context.PopParent();
		styles2.Add(item2);
		Styles styles3 = P_1.Styles;
		Style item3 = (style = new Style());
		context.PushParent(style);
		Style style4 = style;
		style4.Selector = ((Selector?)null).OfType(typeof(Button)).Name("AccountButton").Class(":pointerover");
		Setter setter13 = (setter3 = new Setter());
		context.PushParent(setter3);
		Setter setter14 = setter3;
		setter14.Property = TemplatedControl.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("TextFillColorPrimaryBrush");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value3 = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter14.Value = value3;
		context.PopParent();
		style4.Add(setter13);
		context.PopParent();
		styles3.Add(item3);
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		grid5.HorizontalAlignment = HorizontalAlignment.Stretch;
		Avalonia.Controls.Controls children = grid5.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children.Add(button);
		Button button4;
		Button button3 = (button4 = button2);
		context.PushParent(button4);
		Button button5 = button4;
		button5.Name = "AccountButton";
		object element = button5;
		context.AvaloniaNameScope.Register("AccountButton", element);
		button5.Classes.Add("nav-button");
		button5.HorizontalAlignment = HorizontalAlignment.Stretch;
		button5.HorizontalContentAlignment = HorizontalAlignment.Left;
		button5.VerticalContentAlignment = VerticalAlignment.Center;
		StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EAccountSelectorViewModel_002CMerostrap_002EToggleDropdownCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button5.Bind(commandProperty, binding);
		Styles styles4 = button5.Styles;
		Style item4 = (style = new Style());
		context.PushParent(style);
		Style style5 = style;
		style5.Selector = ((Selector?)null).OfType(typeof(Button)).Class(":pointerover").Template()
			.OfType(typeof(ContentPresenter));
		Setter setter15 = (setter3 = new Setter());
		context.PushParent(setter3);
		Setter setter16 = setter3;
		setter16.Property = ContentPresenter.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("ControlFillColorSecondaryBrush");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value4 = dynamicResourceExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter16.Value = value4;
		context.PopParent();
		style5.Add(setter15);
		context.PopParent();
		styles4.Add(item4);
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		button5.Content = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		StackPanel stackPanel5 = stackPanel4;
		stackPanel5.Orientation = Orientation.Horizontal;
		stackPanel5.Spacing = 8.0;
		Avalonia.Controls.Controls children2 = stackPanel5.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children2.Add(grid6);
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		grid9.Width = 32.0;
		grid9.Height = 32.0;
		Avalonia.Controls.Controls children3 = grid9.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children3.Add(border);
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Border border5 = border4;
		border5.CornerRadius = new CornerRadius(16.0, 16.0, 16.0, 16.0);
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension5 = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding2 = dynamicResourceExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(backgroundProperty, binding2);
		StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension6 = new DynamicResourceExtension("ControlStrokeColorDefaultBrush");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding3 = dynamicResourceExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(borderBrushProperty, binding3);
		border5.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		Avalonia.Controls.Controls children4 = grid9.Children;
		Border border7;
		Border border6 = (border7 = new Border());
		((ISupportInitialize)border6).BeginInit();
		children4.Add(border6);
		Border border8 = (border4 = border7);
		context.PushParent(border4);
		Border border9 = border4;
		border9.CornerRadius = new CornerRadius(16.0, 16.0, 16.0, 16.0);
		border9.ClipToBounds = true;
		Panel panel2;
		Panel panel = (panel2 = new Panel());
		((ISupportInitialize)panel).BeginInit();
		border9.Child = panel;
		Panel panel4;
		Panel panel3 = (panel4 = panel2);
		context.PushParent(panel4);
		Avalonia.Controls.Controls children5 = panel4.Children;
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		children5.Add(lucide);
		Lucide lucide4;
		Lucide lucide3 = (lucide4 = lucide2);
		context.PushParent(lucide4);
		lucide4.Icon = LucideIconNames.User;
		lucide4.Height = 18.0;
		lucide4.Width = 18.0;
		StyledProperty<IBrush?> foregroundProperty = TemplatedControl.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension7 = new DynamicResourceExtension("TextFillColorSecondaryBrush");
		context.ProvideTargetProperty = TemplatedControl.ForegroundProperty;
		BindingBase binding4 = dynamicResourceExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide4.Bind(foregroundProperty, binding4);
		lucide4.HorizontalAlignment = HorizontalAlignment.Center;
		lucide4.VerticalAlignment = VerticalAlignment.Center;
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EAccountSelectorViewModel_002CMerostrap_002ECurrentAccountAvatarUrl_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Converter = StringConverters.IsNullOrEmpty
		};
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding5 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide4.Bind(isVisibleProperty, binding5);
		context.PopParent();
		((ISupportInitialize)lucide3).EndInit();
		Avalonia.Controls.Controls children6 = panel4.Children;
		RemoteImage remoteImage2;
		RemoteImage remoteImage = (remoteImage2 = new RemoteImage());
		((ISupportInitialize)remoteImage).BeginInit();
		children6.Add(remoteImage);
		RemoteImage remoteImage4;
		RemoteImage remoteImage3 = (remoteImage4 = remoteImage2);
		context.PushParent(remoteImage4);
		StyledProperty<string?> urlProperty = RemoteImage.UrlProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EAccountSelectorViewModel_002CMerostrap_002ECurrentAccountAvatarUrl_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = RemoteImage.UrlProperty;
		CompiledBinding binding6 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		remoteImage4.Bind(urlProperty, binding6);
		remoteImage4.Stretch = Stretch.UniformToFill;
		StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EAccountSelectorViewModel_002CMerostrap_002ECurrentAccountAvatarUrl_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Converter = StringConverters.IsNotNullOrEmpty
		};
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding7 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		remoteImage4.Bind(isVisibleProperty2, binding7);
		context.PopParent();
		((ISupportInitialize)remoteImage3).EndInit();
		context.PopParent();
		((ISupportInitialize)panel3).EndInit();
		context.PopParent();
		((ISupportInitialize)border8).EndInit();
		Avalonia.Controls.Controls children7 = grid9.Children;
		Ellipse ellipse2;
		Ellipse ellipse = (ellipse2 = new Ellipse());
		((ISupportInitialize)ellipse).BeginInit();
		children7.Add(ellipse);
		Ellipse ellipse4;
		Ellipse ellipse3 = (ellipse4 = ellipse2);
		context.PushParent(ellipse4);
		ellipse4.Width = 10.0;
		ellipse4.Height = 10.0;
		ellipse4.HorizontalAlignment = HorizontalAlignment.Right;
		ellipse4.VerticalAlignment = VerticalAlignment.Bottom;
		ellipse4.Margin = new Thickness(0.0, 0.0, -2.0, -2.0);
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EAccountSelectorViewModel_002CMerostrap_002EPresenceTooltip_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ToolTip.TipProperty;
		CompiledBinding compiledBinding = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_11((ToolTip)(object)ellipse4, compiledBinding);
		StyledProperty<IBrush?> fillProperty = Shape.FillProperty;
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EAccountSelectorViewModel_002CMerostrap_002EPresenceBrush_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Shape.FillProperty;
		CompiledBinding binding8 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		ellipse4.Bind(fillProperty, binding8);
		StyledProperty<bool> isVisibleProperty3 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EAccountSelectorViewModel_002CMerostrap_002ECurrentAccount_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Converter = ObjectConverters.IsNotNull
		};
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding9 = compiledBindingExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		ellipse4.Bind(isVisibleProperty3, binding9);
		context.PopParent();
		((ISupportInitialize)ellipse3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		Avalonia.Controls.Controls children8 = stackPanel5.Children;
		StackPanel stackPanel7;
		StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
		((ISupportInitialize)stackPanel6).BeginInit();
		children8.Add(stackPanel6);
		StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
		context.PushParent(stackPanel4);
		StackPanel stackPanel9 = stackPanel4;
		stackPanel9.Orientation = Orientation.Vertical;
		stackPanel9.VerticalAlignment = VerticalAlignment.Center;
		stackPanel9.Spacing = 1.0;
		stackPanel9.HorizontalAlignment = HorizontalAlignment.Stretch;
		StyledProperty<bool> isVisibleProperty4 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EAccountSelectorViewModel_002CMerostrap_002ECurrentAccount_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Converter = ObjectConverters.IsNotNull
		};
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding10 = compiledBindingExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		stackPanel9.Bind(isVisibleProperty4, binding10);
		Avalonia.Controls.Controls children9 = stackPanel9.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children9.Add(textBlock);
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = textBlock2);
		context.PushParent(textBlock4);
		TextBlock textBlock5 = textBlock4;
		StyledProperty<string?> textProperty = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EAccountSelectorViewModel_002CMerostrap_002ECurrentAccount_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EModels_002EAccountManagerAccount_002CMerostrap_002EDisplayName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding11 = compiledBindingExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock5.Bind(textProperty, binding11);
		textBlock5.FontSize = 11.0;
		textBlock5.FontWeight = FontWeight.DemiBold;
		StyledProperty<IBrush?> foregroundProperty2 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension8 = new DynamicResourceExtension("TextFillColorPrimaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding12 = dynamicResourceExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock5.Bind(foregroundProperty2, binding12);
		textBlock5.TextTrimming = TextTrimming.CharacterEllipsis;
		context.PopParent();
		((ISupportInitialize)textBlock3).EndInit();
		Avalonia.Controls.Controls children10 = stackPanel9.Children;
		TextBlock textBlock7;
		TextBlock textBlock6 = (textBlock7 = new TextBlock());
		((ISupportInitialize)textBlock6).BeginInit();
		children10.Add(textBlock6);
		TextBlock textBlock8 = (textBlock4 = textBlock7);
		context.PushParent(textBlock4);
		TextBlock textBlock9 = textBlock4;
		StyledProperty<string?> textProperty2 = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EAccountSelectorViewModel_002CMerostrap_002ECurrentAccountDisplayName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding13 = compiledBindingExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock9.Bind(textProperty2, binding13);
		textBlock9.FontSize = 9.0;
		StyledProperty<IBrush?> foregroundProperty3 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension9 = new DynamicResourceExtension("TextFillColorSecondaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding14 = dynamicResourceExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock9.Bind(foregroundProperty3, binding14);
		textBlock9.TextTrimming = TextTrimming.CharacterEllipsis;
		context.PopParent();
		((ISupportInitialize)textBlock8).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel8).EndInit();
		Avalonia.Controls.Controls children11 = stackPanel5.Children;
		TextBlock textBlock11;
		TextBlock textBlock10 = (textBlock11 = new TextBlock());
		((ISupportInitialize)textBlock10).BeginInit();
		children11.Add(textBlock10);
		TextBlock textBlock12 = (textBlock4 = textBlock11);
		context.PushParent(textBlock4);
		TextBlock textBlock13 = textBlock4;
		textBlock13.Text = Strings.Menu_AccountSelector_NotLoggedIn;
		textBlock13.FontSize = 11.0;
		textBlock13.FontWeight = FontWeight.DemiBold;
		StyledProperty<IBrush?> foregroundProperty4 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension10 = new DynamicResourceExtension("TextFillColorPrimaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding15 = dynamicResourceExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock13.Bind(foregroundProperty4, binding15);
		textBlock13.VerticalAlignment = VerticalAlignment.Center;
		StyledProperty<bool> isVisibleProperty5 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EAccountSelectorViewModel_002CMerostrap_002ECurrentAccount_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Converter = ObjectConverters.IsNull
		};
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding16 = compiledBindingExtension11.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock13.Bind(isVisibleProperty5, binding16);
		context.PopParent();
		((ISupportInitialize)textBlock12).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)button3).EndInit();
		Avalonia.Controls.Controls children12 = grid5.Children;
		Popup popup2;
		Popup popup = (popup2 = new Popup());
		((ISupportInitialize)popup).BeginInit();
		children12.Add(popup);
		Popup popup4;
		Popup popup3 = (popup4 = popup2);
		context.PushParent(popup4);
		popup4.Name = "AccountDropdown";
		element = popup4;
		context.AvaloniaNameScope.Register("AccountDropdown", element);
		StyledProperty<bool> isOpenProperty = Popup.IsOpenProperty;
		CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EAccountSelectorViewModel_002CMerostrap_002EIsDropdownOpen_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Popup.IsOpenProperty;
		CompiledBinding binding17 = compiledBindingExtension12.ProvideValue(context);
		context.ProvideTargetProperty = null;
		popup4.Bind(isOpenProperty, binding17);
		popup4.Placement = PlacementMode.Bottom;
		StyledProperty<Control?> placementTargetProperty = Popup.PlacementTargetProperty;
		CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().ElementName(context.AvaloniaNameScope, "AccountButton").Build());
		context.ProvideTargetProperty = Popup.PlacementTargetProperty;
		CompiledBinding binding18 = compiledBindingExtension13.ProvideValue(context);
		context.ProvideTargetProperty = null;
		popup4.Bind(placementTargetProperty, binding18);
		popup4.VerticalOffset = 6.0;
		popup4.IsLightDismissEnabled = true;
		popup4.MaxHeight = 450.0;
		Border border11;
		Border border10 = (border11 = new Border());
		((ISupportInitialize)border10).BeginInit();
		popup4.Child = border10;
		Border border12 = (border4 = border11);
		context.PushParent(border4);
		Border border13 = border4;
		border13.MinWidth = 260.0;
		border13.MaxHeight = 420.0;
		border13.Background = new ImmutableSolidColorBrush(4281150765u);
		StyledProperty<IBrush?> borderBrushProperty2 = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension11 = new DynamicResourceExtension("FrostBorderDefault");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding19 = dynamicResourceExtension11.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border13.Bind(borderBrushProperty2, binding19);
		border13.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		border13.CornerRadius = new CornerRadius(6.0, 6.0, 6.0, 6.0);
		border13.BoxShadow = BoxShadows.Parse("0 8 32 0 #20000000");
		Grid grid11;
		Grid grid10 = (grid11 = new Grid());
		((ISupportInitialize)grid10).BeginInit();
		border13.Child = grid10;
		Grid grid12 = (grid4 = grid11);
		context.PushParent(grid4);
		Grid grid13 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid13.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children13 = grid13.Children;
		Border border15;
		Border border14 = (border15 = new Border());
		((ISupportInitialize)border14).BeginInit();
		children13.Add(border14);
		Border border16 = (border4 = border15);
		context.PushParent(border4);
		Border border17 = border4;
		Grid.SetRow(border17, 0);
		border17.Padding = new Thickness(12.0, 12.0, 12.0, 12.0);
		StyledProperty<IBrush?> backgroundProperty2 = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension12 = new DynamicResourceExtension("ControlFillColorSecondaryBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding20 = dynamicResourceExtension12.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border17.Bind(backgroundProperty2, binding20);
		StyledProperty<IBrush?> borderBrushProperty3 = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension13 = new DynamicResourceExtension("ControlStrokeColorDefaultBrush");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding21 = dynamicResourceExtension13.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border17.Bind(borderBrushProperty3, binding21);
		border17.BorderThickness = new Thickness(0.0, 0.0, 0.0, 1.0);
		Grid grid15;
		Grid grid14 = (grid15 = new Grid());
		((ISupportInitialize)grid14).BeginInit();
		border17.Child = grid14;
		Grid grid16 = (grid4 = grid15);
		context.PushParent(grid4);
		Grid grid17 = grid4;
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 2;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid17.ColumnDefinitions = columnDefinitions;
		Avalonia.Controls.Controls children14 = grid17.Children;
		Button button7;
		Button button6 = (button7 = new Button());
		((ISupportInitialize)button6).BeginInit();
		children14.Add(button6);
		Button button8 = (button4 = button7);
		context.PushParent(button4);
		Button button9 = button4;
		Grid.SetColumn(button9, 0);
		button9.Content = Strings.Menu_AccountSelector_AddAccount;
		StyledProperty<ICommand?> commandProperty2 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EAccountSelectorViewModel_002CMerostrap_002EAddAccountCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding22 = compiledBindingExtension14.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button9.Bind(commandProperty2, binding22);
		StyledProperty<bool> isEnabledProperty = InputElement.IsEnabledProperty;
		CompiledBindingExtension compiledBindingExtension15 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EAccountSelectorViewModel_002CMerostrap_002EIsAddingAccount_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = InputElement.IsEnabledProperty;
		CompiledBinding binding23 = compiledBindingExtension15.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button9.Bind(isEnabledProperty, binding23);
		button9.Height = 32.0;
		button9.Margin = new Thickness(0.0, 0.0, 4.0, 0.0);
		button9.HorizontalAlignment = HorizontalAlignment.Stretch;
		context.PopParent();
		((ISupportInitialize)button8).EndInit();
		Avalonia.Controls.Controls children15 = grid17.Children;
		Border border19;
		Border border18 = (border19 = new Border());
		((ISupportInitialize)border18).BeginInit();
		children15.Add(border18);
		Border border20 = (border4 = border19);
		context.PushParent(border4);
		Border border21 = border4;
		Grid.SetColumn(border21, 1);
		border21.Width = 36.0;
		border21.Height = 32.0;
		border21.CornerRadius = new CornerRadius(6.0, 6.0, 6.0, 6.0);
		border21.ClipToBounds = true;
		ComboBox comboBox2;
		ComboBox comboBox = (comboBox2 = new ComboBox());
		((ISupportInitialize)comboBox).BeginInit();
		border21.Child = comboBox;
		ComboBox comboBox4;
		ComboBox comboBox3 = (comboBox4 = comboBox2);
		context.PushParent(comboBox4);
		StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension16 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EAccountSelectorViewModel_002CMerostrap_002EAddMethods_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding24 = compiledBindingExtension16.ProvideValue(context);
		context.ProvideTargetProperty = null;
		comboBox4.Bind(itemsSourceProperty, binding24);
		CompiledBindingExtension compiledBindingExtension17 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EAccountSelectorViewModel_002CMerostrap_002ESelectedAddMethod_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = SelectingItemsControl.SelectedItemProperty;
		CompiledBinding compiledBinding2 = compiledBindingExtension17.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_10(comboBox4, compiledBinding2);
		StyledProperty<bool> isEnabledProperty2 = InputElement.IsEnabledProperty;
		CompiledBindingExtension compiledBindingExtension18 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EAccountSelectorViewModel_002CMerostrap_002EIsAddingAccount_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = InputElement.IsEnabledProperty;
		CompiledBinding binding25 = compiledBindingExtension18.ProvideValue(context);
		context.ProvideTargetProperty = null;
		comboBox4.Bind(isEnabledProperty2, binding25);
		comboBox4.Width = 36.0;
		comboBox4.Height = 32.0;
		comboBox4.MinWidth = 0.0;
		comboBox4.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
		comboBox4.HorizontalContentAlignment = HorizontalAlignment.Center;
		comboBox4.VerticalContentAlignment = VerticalAlignment.Center;
		comboBox4.CornerRadius = new CornerRadius(6.0, 6.0, 6.0, 6.0);
		comboBox4.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		StyledProperty<IBrush?> borderBrushProperty4 = TemplatedControl.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension14 = new DynamicResourceExtension("ControlStrokeColorDefaultBrush");
		context.ProvideTargetProperty = TemplatedControl.BorderBrushProperty;
		BindingBase binding26 = dynamicResourceExtension14.ProvideValue(context);
		context.ProvideTargetProperty = null;
		comboBox4.Bind(borderBrushProperty4, binding26);
		Styles styles5 = comboBox4.Styles;
		Style style6 = new Style();
		style6.Selector = ((Selector?)null).OfType(typeof(ComboBox)).Template().OfType(typeof(ContentPresenter));
		Setter setter17 = new Setter();
		setter17.Property = Visual.OpacityProperty;
		setter17.Value = 0.0;
		style6.Add(setter17);
		styles5.Add(style6);
		Styles styles6 = comboBox4.Styles;
		Style style7 = new Style();
		style7.Selector = ((Selector?)null).OfType(typeof(ComboBox)).Template().OfType(typeof(ContentControl));
		Setter setter18 = new Setter();
		setter18.Property = Visual.OpacityProperty;
		setter18.Value = 0.0;
		style7.Add(setter18);
		styles6.Add(style7);
		context.PopParent();
		((ISupportInitialize)comboBox3).EndInit();
		context.PopParent();
		((ISupportInitialize)border20).EndInit();
		context.PopParent();
		((ISupportInitialize)grid16).EndInit();
		context.PopParent();
		((ISupportInitialize)border16).EndInit();
		Avalonia.Controls.Controls children16 = grid13.Children;
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		children16.Add(scrollViewer);
		ScrollViewer scrollViewer4;
		ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
		context.PushParent(scrollViewer4);
		Grid.SetRow(scrollViewer4, 1);
		scrollViewer4.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
		scrollViewer4.MaxHeight = 175.0;
		StyledProperty<bool> isVisibleProperty6 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension19 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EAccountSelectorViewModel_002CMerostrap_002EAccounts_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.System_002ECollections_002EObjectModel_002ECollection_00601_002CSystem_002ERuntime_002ECount_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding27 = compiledBindingExtension19.ProvideValue(context);
		context.ProvideTargetProperty = null;
		scrollViewer4.Bind(isVisibleProperty6, binding27);
		ItemsControl itemsControl2;
		ItemsControl itemsControl = (itemsControl2 = new ItemsControl());
		((ISupportInitialize)itemsControl).BeginInit();
		scrollViewer4.Content = itemsControl;
		ItemsControl itemsControl4;
		ItemsControl itemsControl3 = (itemsControl4 = itemsControl2);
		context.PushParent(itemsControl4);
		StyledProperty<IEnumerable?> itemsSourceProperty2 = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension20 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EAccountSelectorViewModel_002CMerostrap_002EAccounts_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding28 = compiledBindingExtension20.ProvideValue(context);
		context.ProvideTargetProperty = null;
		itemsControl4.Bind(itemsSourceProperty2, binding28);
		itemsControl4.ItemsPanel = new ItemsPanelTemplate
		{
			Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_34.Build_1), context)
		};
		DataTemplate dataTemplate;
		DataTemplate itemTemplate = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_34.Build_2), context);
		context.PopParent();
		itemsControl4.ItemTemplate = itemTemplate;
		context.PopParent();
		((ISupportInitialize)itemsControl3).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer3).EndInit();
		Avalonia.Controls.Controls children17 = grid13.Children;
		TextBlock textBlock15;
		TextBlock textBlock14 = (textBlock15 = new TextBlock());
		((ISupportInitialize)textBlock14).BeginInit();
		children17.Add(textBlock14);
		TextBlock textBlock16 = (textBlock4 = textBlock15);
		context.PushParent(textBlock4);
		TextBlock textBlock17 = textBlock4;
		Grid.SetRow(textBlock17, 1);
		textBlock17.Text = Strings.Menu_AccountSelector_AskToAddAccount;
		textBlock17.FontSize = 12.0;
		textBlock17.TextAlignment = TextAlignment.Center;
		textBlock17.HorizontalAlignment = HorizontalAlignment.Center;
		textBlock17.VerticalAlignment = VerticalAlignment.Center;
		textBlock17.Padding = new Thickness(16.0, 24.0, 16.0, 24.0);
		StyledProperty<bool> isVisibleProperty7 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension21 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EAccountSelectorViewModel_002CMerostrap_002EAccounts_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.System_002ECollections_002EObjectModel_002ECollection_00601_002CSystem_002ERuntime_002ECount_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)
			.Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding29 = compiledBindingExtension21.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock17.Bind(isVisibleProperty7, binding29);
		context.PopParent();
		((ISupportInitialize)textBlock16).EndInit();
		context.PopParent();
		((ISupportInitialize)grid12).EndInit();
		context.PopParent();
		((ISupportInitialize)border12).EndInit();
		context.PopParent();
		((ISupportInitialize)popup3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(AccountSelectorView P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
