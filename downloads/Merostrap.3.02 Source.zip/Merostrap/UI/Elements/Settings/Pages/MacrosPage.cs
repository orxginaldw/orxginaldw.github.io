using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Controls.Presenters;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.Converters;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using Avalonia.Styling;
using CompiledAvaloniaXaml;
using LucideAvalonia;
using LucideAvalonia.Enum;

namespace Merostrap.UI.Elements.Settings.Pages;

internal class MacrosPage : UserControl
{
	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Image GameThumbnail;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal ToggleButton MasterToggle;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button GameSettingsButton;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public MacrosPage()
	{
		InitializeComponent();
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		GameThumbnail = nameScope?.Find<Image>("GameThumbnail");
		MasterToggle = nameScope?.Find<ToggleButton>("MasterToggle");
		GameSettingsButton = nameScope?.Find<Button>("GameSettingsButton");
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, MacrosPage P_1)
	{
		XamlIlContext.Context<MacrosPage> context = new XamlIlContext.Context<MacrosPage>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FPages_002FMacrosPage_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/Pages/MacrosPage.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		Styles styles = P_1.Styles;
		Style style;
		Style item = (style = new Style());
		context.PushParent(style);
		Style style2 = style;
		style2.Selector = ((Selector?)null).OfType(typeof(ToggleButton)).Class("game-enable");
		Setter setter2;
		Setter setter = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter3 = setter2;
		setter3.Property = TemplatedControl.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("AccentFillColorDefaultBrush");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter3.Value = value;
		context.PopParent();
		style2.Add(setter);
		Setter setter4 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter5 = setter2;
		setter5.Property = TemplatedControl.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("TextOnAccentFillColorPrimaryBrush");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value2 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter5.Value = value2;
		context.PopParent();
		style2.Add(setter4);
		Setter setter6 = new Setter();
		setter6.Property = ContentControl.HorizontalContentAlignmentProperty;
		setter6.Value = HorizontalAlignment.Center;
		style2.Add(setter6);
		Setter setter7 = new Setter();
		setter7.Property = TemplatedControl.FontWeightProperty;
		setter7.Value = FontWeight.DemiBold;
		style2.Add(setter7);
		Setter setter8 = new Setter();
		setter8.Property = TemplatedControl.CornerRadiusProperty;
		setter8.Value = new CornerRadius(6.0, 6.0, 6.0, 6.0);
		style2.Add(setter8);
		context.PopParent();
		styles.Add(item);
		Styles styles2 = P_1.Styles;
		Style item2 = (style = new Style());
		context.PushParent(style);
		Style style3 = style;
		style3.Selector = ((Selector?)null).OfType(typeof(ToggleButton)).Class("game-enable").Class(":pointerover")
			.Template()
			.OfType(typeof(ContentPresenter));
		Setter setter9 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter10 = setter2;
		setter10.Property = ContentPresenter.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("AccentFillColorSecondaryBrush");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value3 = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter10.Value = value3;
		context.PopParent();
		style3.Add(setter9);
		Setter setter11 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter12 = setter2;
		setter12.Property = ContentPresenter.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("TextOnAccentFillColorPrimaryBrush");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value4 = dynamicResourceExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter12.Value = value4;
		context.PopParent();
		style3.Add(setter11);
		context.PopParent();
		styles2.Add(item2);
		Styles styles3 = P_1.Styles;
		Style item3 = (style = new Style());
		context.PushParent(style);
		Style style4 = style;
		style4.Selector = ((Selector?)null).OfType(typeof(ToggleButton)).Class("game-enable").Class(":pressed")
			.Template()
			.OfType(typeof(ContentPresenter));
		Setter setter13 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter14 = setter2;
		setter14.Property = ContentPresenter.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension5 = new DynamicResourceExtension("AccentFillColorTertiaryBrush");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value5 = dynamicResourceExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter14.Value = value5;
		context.PopParent();
		style4.Add(setter13);
		Setter setter15 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter16 = setter2;
		setter16.Property = ContentPresenter.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension6 = new DynamicResourceExtension("TextOnAccentFillColorPrimaryBrush");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value6 = dynamicResourceExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter16.Value = value6;
		context.PopParent();
		style4.Add(setter15);
		context.PopParent();
		styles3.Add(item3);
		Styles styles4 = P_1.Styles;
		Style style5 = new Style();
		style5.Selector = ((Selector?)null).OfType(typeof(ToggleButton)).Class("game-enable").Class(":checked")
			.Template()
			.OfType(typeof(ContentPresenter));
		Setter setter17 = new Setter();
		setter17.Property = ContentPresenter.BackgroundProperty;
		setter17.Value = new ImmutableSolidColorBrush(4290261570u);
		style5.Add(setter17);
		Setter setter18 = new Setter();
		setter18.Property = ContentPresenter.ForegroundProperty;
		setter18.Value = new ImmutableSolidColorBrush(uint.MaxValue);
		style5.Add(setter18);
		styles4.Add(style5);
		Styles styles5 = P_1.Styles;
		Style style6 = new Style();
		style6.Selector = ((Selector?)null).OfType(typeof(ToggleButton)).Class("game-enable").Class(":checked")
			.Class(":pointerover")
			.Template()
			.OfType(typeof(ContentPresenter));
		Setter setter19 = new Setter();
		setter19.Property = ContentPresenter.BackgroundProperty;
		setter19.Value = new ImmutableSolidColorBrush(4291312460u);
		style6.Add(setter19);
		Setter setter20 = new Setter();
		setter20.Property = ContentPresenter.ForegroundProperty;
		setter20.Value = new ImmutableSolidColorBrush(uint.MaxValue);
		style6.Add(setter20);
		styles5.Add(style6);
		Styles styles6 = P_1.Styles;
		Style style7 = new Style();
		style7.Selector = ((Selector?)null).OfType(typeof(ToggleButton)).Class("game-enable").Class(":checked")
			.Class(":pressed")
			.Template()
			.OfType(typeof(ContentPresenter));
		Setter setter21 = new Setter();
		setter21.Property = ContentPresenter.BackgroundProperty;
		setter21.Value = new ImmutableSolidColorBrush(4288161335u);
		style7.Add(setter21);
		Setter setter22 = new Setter();
		setter22.Property = ContentPresenter.ForegroundProperty;
		setter22.Value = new ImmutableSolidColorBrush(uint.MaxValue);
		style7.Add(setter22);
		styles6.Add(style7);
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		P_1.Content = scrollViewer;
		ScrollViewer scrollViewer4;
		ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
		context.PushParent(scrollViewer4);
		scrollViewer4.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		scrollViewer4.Content = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		StackPanel stackPanel5 = stackPanel4;
		stackPanel5.Margin = new Thickness(14.0, 18.0, 14.0, 18.0);
		stackPanel5.Spacing = 22.0;
		Avalonia.Controls.Controls children = stackPanel5.Children;
		StackPanel stackPanel7;
		StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
		((ISupportInitialize)stackPanel6).BeginInit();
		children.Add(stackPanel6);
		stackPanel7.Spacing = 6.0;
		Avalonia.Controls.Controls children2 = stackPanel7.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children2.Add(textBlock);
		textBlock2.Text = "Game macros";
		textBlock2.FontSize = 24.0;
		textBlock2.FontWeight = FontWeight.DemiBold;
		((ISupportInitialize)textBlock2).EndInit();
		((ISupportInitialize)stackPanel7).EndInit();
		Avalonia.Controls.Controls children3 = stackPanel5.Children;
		WrapPanel wrapPanel2;
		WrapPanel wrapPanel = (wrapPanel2 = new WrapPanel());
		((ISupportInitialize)wrapPanel).BeginInit();
		children3.Add(wrapPanel);
		WrapPanel wrapPanel4;
		WrapPanel wrapPanel3 = (wrapPanel4 = wrapPanel2);
		context.PushParent(wrapPanel4);
		Avalonia.Controls.Controls children4 = wrapPanel4.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children4.Add(border);
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Border border5 = border4;
		border5.MaxWidth = 420.0;
		border5.HorizontalAlignment = HorizontalAlignment.Left;
		border5.VerticalAlignment = VerticalAlignment.Top;
		border5.CornerRadius = new CornerRadius(10.0, 10.0, 10.0, 10.0);
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension7 = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding = dynamicResourceExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(backgroundProperty, binding);
		StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension8 = new DynamicResourceExtension("ControlStrokeColorDefaultBrush");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding2 = dynamicResourceExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(borderBrushProperty, binding2);
		border5.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		border5.ClipToBounds = true;
		StackPanel stackPanel9;
		StackPanel stackPanel8 = (stackPanel9 = new StackPanel());
		((ISupportInitialize)stackPanel8).BeginInit();
		border5.Child = stackPanel8;
		StackPanel stackPanel10 = (stackPanel4 = stackPanel9);
		context.PushParent(stackPanel4);
		StackPanel stackPanel11 = stackPanel4;
		Avalonia.Controls.Controls children5 = stackPanel11.Children;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		children5.Add(grid);
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		grid5.Height = 236.0;
		grid5.ClipToBounds = true;
		Avalonia.Controls.Controls children6 = grid5.Children;
		Image image2;
		Image image = (image2 = new Image());
		((ISupportInitialize)image).BeginInit();
		children6.Add(image);
		Image image4;
		Image image3 = (image4 = image2);
		context.PushParent(image4);
		image4.Name = "GameThumbnail";
		object element = image4;
		context.AvaloniaNameScope.Register("GameThumbnail", element);
		image4.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "avares://Merostrap/Resources/Games/Deepwoken.png");
		image4.Stretch = Stretch.UniformToFill;
		AutomationProperties.SetName(image4, "Deepwoken game artwork");
		context.PopParent();
		((ISupportInitialize)image3).EndInit();
		Avalonia.Controls.Controls children7 = grid5.Children;
		Border border7;
		Border border6 = (border7 = new Border());
		((ISupportInitialize)border6).BeginInit();
		children7.Add(border6);
		border7.IsHitTestVisible = false;
		LinearGradientBrush linearGradientBrush = new LinearGradientBrush();
		linearGradientBrush.StartPoint = new RelativePoint(0.0, 0.0, RelativeUnit.Relative);
		linearGradientBrush.EndPoint = new RelativePoint(0.0, 1.0, RelativeUnit.Relative);
		GradientStops gradientStops = linearGradientBrush.GradientStops;
		GradientStop gradientStop = new GradientStop();
		gradientStop.Color = Color.FromUInt32(725270u);
		gradientStop.Offset = 0.35;
		gradientStops.Add(gradientStop);
		GradientStops gradientStops2 = linearGradientBrush.GradientStops;
		GradientStop gradientStop2 = new GradientStop();
		gradientStop2.Color = Color.FromUInt32(3993702678u);
		gradientStop2.Offset = 1.0;
		gradientStops2.Add(gradientStop2);
		border7.Background = linearGradientBrush;
		((ISupportInitialize)border7).EndInit();
		Avalonia.Controls.Controls children8 = grid5.Children;
		Border border9;
		Border border8 = (border9 = new Border());
		((ISupportInitialize)border8).BeginInit();
		children8.Add(border8);
		Border border10 = (border4 = border9);
		context.PushParent(border4);
		Border border11 = border4;
		border11.HorizontalAlignment = HorizontalAlignment.Right;
		border11.VerticalAlignment = VerticalAlignment.Top;
		border11.Margin = new Thickness(16.0, 16.0, 16.0, 16.0);
		border11.Padding = new Thickness(10.0, 5.0, 10.0, 5.0);
		border11.CornerRadius = new CornerRadius(12.0, 12.0, 12.0, 12.0);
		border11.Background = new ImmutableSolidColorBrush(3860406310u);
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		border11.Child = textBlock3;
		TextBlock textBlock6;
		TextBlock textBlock5 = (textBlock6 = textBlock4);
		context.PushParent(textBlock6);
		TextBlock textBlock7 = textBlock6;
		StyledProperty<string?> textProperty = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMacrosViewModel_002CMerostrap_002EGameStateLabel_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding3 = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock7.Bind(textProperty, binding3);
		textBlock7.FontSize = 12.0;
		textBlock7.FontWeight = FontWeight.DemiBold;
		textBlock7.Foreground = new ImmutableSolidColorBrush(4294309370u);
		context.PopParent();
		((ISupportInitialize)textBlock5).EndInit();
		context.PopParent();
		((ISupportInitialize)border10).EndInit();
		Avalonia.Controls.Controls children9 = grid5.Children;
		StackPanel stackPanel13;
		StackPanel stackPanel12 = (stackPanel13 = new StackPanel());
		((ISupportInitialize)stackPanel12).BeginInit();
		children9.Add(stackPanel12);
		StackPanel stackPanel14 = (stackPanel4 = stackPanel13);
		context.PushParent(stackPanel4);
		StackPanel stackPanel15 = stackPanel4;
		stackPanel15.VerticalAlignment = VerticalAlignment.Bottom;
		stackPanel15.Margin = new Thickness(20.0, 0.0, 20.0, 18.0);
		stackPanel15.Spacing = 4.0;
		Avalonia.Controls.Controls children10 = stackPanel15.Children;
		TextBlock textBlock9;
		TextBlock textBlock8 = (textBlock9 = new TextBlock());
		((ISupportInitialize)textBlock8).BeginInit();
		children10.Add(textBlock8);
		textBlock9.Text = "Deepwoken";
		textBlock9.FontSize = 27.0;
		textBlock9.FontWeight = FontWeight.DemiBold;
		textBlock9.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
		((ISupportInitialize)textBlock9).EndInit();
		Avalonia.Controls.Controls children11 = stackPanel15.Children;
		TextBlock textBlock11;
		TextBlock textBlock10 = (textBlock11 = new TextBlock());
		((ISupportInitialize)textBlock10).BeginInit();
		children11.Add(textBlock10);
		TextBlock textBlock12 = (textBlock6 = textBlock11);
		context.PushParent(textBlock6);
		TextBlock textBlock13 = textBlock6;
		StyledProperty<string?> textProperty2 = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMacrosViewModel_002CMerostrap_002EWorkspace_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EPresetName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding4 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock13.Bind(textProperty2, binding4);
		textBlock13.FontSize = 13.0;
		textBlock13.Foreground = new ImmutableSolidColorBrush(4291942364u);
		context.PopParent();
		((ISupportInitialize)textBlock12).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel14).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		Avalonia.Controls.Controls children12 = stackPanel11.Children;
		StackPanel stackPanel17;
		StackPanel stackPanel16 = (stackPanel17 = new StackPanel());
		((ISupportInitialize)stackPanel16).BeginInit();
		children12.Add(stackPanel16);
		StackPanel stackPanel18 = (stackPanel4 = stackPanel17);
		context.PushParent(stackPanel4);
		StackPanel stackPanel19 = stackPanel4;
		stackPanel19.Margin = new Thickness(16.0, 16.0, 16.0, 16.0);
		stackPanel19.Spacing = 12.0;
		Avalonia.Controls.Controls children13 = stackPanel19.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children13.Add(grid6);
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 3;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(10.0, GridUnitType.Pixel)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(42.0, GridUnitType.Pixel)));
		grid9.ColumnDefinitions = columnDefinitions;
		Avalonia.Controls.Controls children14 = grid9.Children;
		ToggleButton toggleButton2;
		ToggleButton toggleButton = (toggleButton2 = new ToggleButton());
		((ISupportInitialize)toggleButton).BeginInit();
		children14.Add(toggleButton);
		ToggleButton toggleButton4;
		ToggleButton toggleButton3 = (toggleButton4 = toggleButton2);
		context.PushParent(toggleButton4);
		toggleButton4.Name = "MasterToggle";
		element = toggleButton4;
		context.AvaloniaNameScope.Register("MasterToggle", element);
		toggleButton4.Classes.Add("game-enable");
		toggleButton4.Height = 42.0;
		toggleButton4.HorizontalAlignment = HorizontalAlignment.Stretch;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMacrosViewModel_002CMerostrap_002EEnableButtonLabel_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ContentControl.ContentProperty;
		CompiledBinding compiledBinding = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_4(toggleButton4, compiledBinding);
		StyledProperty<bool?> isCheckedProperty = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMacrosViewModel_002CMerostrap_002ELaunchWithRoblox_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding5 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleButton4.Bind(isCheckedProperty, binding5);
		StyledProperty<bool> isEnabledProperty = InputElement.IsEnabledProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMacrosViewModel_002CMerostrap_002EWorkspace_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002ERuntimeAvailable_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = InputElement.IsEnabledProperty;
		CompiledBinding binding6 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleButton4.Bind(isEnabledProperty, binding6);
		AutomationProperties.SetName(toggleButton4, "Enable or disable Deepwoken macros");
		ToolTip.SetTip(toggleButton4, "Enable Deepwoken macros with Roblox. Disable to stop them and turn off automatic startup.");
		context.PopParent();
		((ISupportInitialize)toggleButton3).EndInit();
		Avalonia.Controls.Controls children15 = grid9.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children15.Add(button);
		Button button4;
		Button button3 = (button4 = button2);
		context.PushParent(button4);
		button4.Name = "GameSettingsButton";
		element = button4;
		context.AvaloniaNameScope.Register("GameSettingsButton", element);
		Grid.SetColumn(button4, 2);
		button4.Width = 42.0;
		button4.Height = 42.0;
		button4.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
		button4.HorizontalAlignment = HorizontalAlignment.Stretch;
		button4.HorizontalContentAlignment = HorizontalAlignment.Center;
		button4.VerticalContentAlignment = VerticalAlignment.Center;
		StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMacrosViewModel_002CMerostrap_002EWorkspace_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EOpenWindowCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding7 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button4.Bind(commandProperty, binding7);
		AutomationProperties.SetName(button4, "Deepwoken macro settings");
		ToolTip.SetTip(button4, "Configure Deepwoken macros, hotkeys, and presets");
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		button4.Content = lucide;
		lucide2.Icon = LucideIconNames.Settings;
		lucide2.Width = 18.0;
		lucide2.Height = 18.0;
		((ISupportInitialize)lucide2).EndInit();
		context.PopParent();
		((ISupportInitialize)button3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel18).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel10).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		context.PopParent();
		((ISupportInitialize)wrapPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(MacrosPage P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
