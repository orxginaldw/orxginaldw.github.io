using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Documents;
using Avalonia.Controls.Primitives;
using Avalonia.Controls.Shapes;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Input.Platform;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using Avalonia.Platform.Storage;
using Avalonia.Threading;
using Avalonia.VisualTree;
using CompiledAvaloniaXaml;
using FluentAvalonia.UI.Controls;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.Enums.Messagebox;
using Merostrap.Models;
using Merostrap.Resources;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.Elements.Dialogs;

namespace Merostrap.UI.Elements.Settings.Pages.FastFlags;

internal class FastFlagEditor : UserControl, INotifyPropertyChanged, IDisposable
{
	[CompilerGenerated]
	private class XamlClosure_38
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<FastFlagEditor> context = CreateContext(P_0);
			context.IntermediateRoot = new Lucide();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((Layoutable)obj).Height = 20.0;
			((Layoutable)obj).Width = 20.0;
			((Layoutable)obj).HorizontalAlignment = HorizontalAlignment.Center;
			((Layoutable)obj).VerticalAlignment = VerticalAlignment.Center;
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<FastFlagEditor> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<FastFlagEditor> context = new XamlIlContext.Context<FastFlagEditor>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FPages_002FFastFlags_002FFastFlagEditor_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/Pages/FastFlags/FastFlagEditor.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (FastFlagEditor)service;
				}
			}
			return context;
		}
	}

	private readonly ObservableCollection<FastFlag> _fastFlagList = new ObservableCollection<FastFlag>();

	private bool _showPresets = true;

	private bool _disposed;

	private string _searchFilter = string.Empty;

	private CancellationTokenSource? _searchCancellationTokenSource;

	private static readonly JsonSerializerOptions _jsonOptions = new JsonSerializerOptions
	{
		ReadCommentHandling = JsonCommentHandling.Skip,
		AllowTrailingCommas = true
	};

	private DataGrid? _dataGrid;

	private TextBox? _searchTextBox;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal IconButton DeleteSelectedButton;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal ToggleButton TogglePresetsButton;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBlock TotalFlagsTextBlock;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBox SearchTextBox;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBlock SuggestionTextBlock;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Run SuggestionKeywordRun;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal DataGrid DataGrid;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBlock EmptyTextBlock;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Grid DragOverlay;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public new event PropertyChangedEventHandler? PropertyChanged;

	protected void OnPropertyChanged([CallerMemberName] string? propertyName = null)
	{
		PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
	}

	protected bool SetProperty<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
	{
		if (EqualityComparer<T>.Default.Equals(field, value))
		{
			return false;
		}
		field = value;
		OnPropertyChanged(propertyName);
		return true;
	}

	public FastFlagEditor()
	{
		InitializeComponent();
		App.FrostRPC?.SetPage("FastFlag Editor");
	}

	protected override void OnLoaded(RoutedEventArgs e)
	{
		base.OnLoaded(e);
		_dataGrid = this.FindControl<DataGrid>("DataGrid");
		_searchTextBox = this.FindControl<TextBox>("SearchTextBox");
		Focus();
		ReloadList();
	}

	public void ReloadList()
	{
		if (_dataGrid == null)
		{
			return;
		}
		_fastFlagList.Clear();
		IEnumerable<string> values = FastFlagManager.PresetFlags.Values;
		foreach (KeyValuePair<string, object> item2 in App.FastFlags.Prop.OrderBy((KeyValuePair<string, object> x) => x.Key))
		{
			if (item2.Key.Contains(_searchFilter, StringComparison.OrdinalIgnoreCase))
			{
				FastFlag item = new FastFlag
				{
					Name = item2.Key,
					Value = (item2.Value?.ToString() ?? ""),
					Preset = (values.Contains(item2.Key) ? LucideIconNames.CircleCheck : LucideIconNames.CircleX)
				};
				_fastFlagList.Add(item);
			}
		}
		DataGrid dataGrid = _dataGrid;
		if (dataGrid.ItemsSource == null)
		{
			IEnumerable enumerable = (dataGrid.ItemsSource = _fastFlagList);
		}
		EmptyTextBlock.IsVisible = _fastFlagList.Count == 0 && App.FastFlags.Prop.Count == 0;
		IconButton deleteSelectedButton = DeleteSelectedButton;
		if (deleteSelectedButton != null)
		{
			deleteSelectedButton.IsEnabled = false;
		}
		UpdateTotalFlagsCount();
		Avalonia.Threading.Dispatcher.UIThread.Post(UpdatePresetIcons, DispatcherPriority.Loaded);
	}

	private void UpdatePresetIcons()
	{
		if (_dataGrid == null)
		{
			return;
		}
		foreach (DataGridRow item in _dataGrid.GetVisualDescendants().OfType<DataGridRow>())
		{
			if (item.DataContext is FastFlag fastFlag)
			{
				Lucide lucide = item.GetVisualDescendants().OfType<Lucide>().FirstOrDefault();
				if (lucide != null)
				{
					lucide.Width = 20.0;
					lucide.Height = 20.0;
					lucide.Icon = fastFlag.Preset;
					lucide.StrokeBrush = Foreground;
					IBrush strokeBrush = lucide.StrokeBrush;
					lucide.StrokeBrush = null;
					lucide.StrokeBrush = strokeBrush;
				}
			}
		}
	}

	protected override void OnKeyDown(KeyEventArgs e)
	{
		base.OnKeyDown(e);
		if (e.KeyModifiers.HasFlag(KeyModifiers.Control))
		{
			switch (e.Key)
			{
			case Key.Z:
				App.FastFlags.Undo();
				ReloadList();
				e.Handled = true;
				break;
			case Key.Y:
				App.FastFlags.Redo();
				ReloadList();
				e.Handled = true;
				break;
			}
		}
	}

	public void UpdateTotalFlagsCount()
	{
		int count = _fastFlagList.Count;
		TotalFlagsTextBlock.Text = $"{Strings.Menu_FastFlagEditor_TotalFlags}: {count}";
	}

	private async void AddButton_Click(object sender, RoutedEventArgs e)
	{
		App.FrostRPC?.SetDialog("Add FastFlag");
		ShowAddDialog();
	}

	private async void ShowAddDialog()
	{
		if (!(TopLevel.GetTopLevel(this) is Window owner))
		{
			return;
		}
		App.FrostRPC?.SetDialog("Add FastFlag");
		AddFastFlagDialog dialog = new AddFastFlagDialog();
		await dialog.ShowDialog(owner);
		App.FrostRPC?.ClearDialog();
		if (dialog.Result == MessageBoxResult.OK)
		{
			if (dialog.Tabs.SelectedIndex == 0)
			{
				await AddSingle(dialog.FlagNameTextBox.Text?.Trim() ?? string.Empty, dialog.FlagValueTextBox.Text ?? string.Empty);
			}
			else if (dialog.Tabs.SelectedIndex == 1)
			{
				await ImportJSON(dialog.JsonTextBox.Text ?? string.Empty);
			}
		}
	}

	private async Task AddSingle(string name, string value)
	{
		FastFlag entry;
		if (App.FastFlags.GetValue(name) == null)
		{
			entry = new FastFlag
			{
				Name = name,
				Value = value
			};
			if (!name.Contains(_searchFilter, StringComparison.OrdinalIgnoreCase))
			{
				ClearSearch();
			}
			App.FastFlags.SetValue(entry.Name, entry.Value);
			_fastFlagList.Add(entry);
		}
		else
		{
			Frontend.ShowMessageBox(Strings.Menu_FastFlagEditor_AlreadyExists);
			bool flag = false;
			if (!_showPresets && FastFlagManager.PresetFlags.Values.Contains(name))
			{
				TogglePresetsButton.IsChecked = true;
				_showPresets = true;
				flag = true;
			}
			if (!name.Contains(_searchFilter, StringComparison.OrdinalIgnoreCase))
			{
				ClearSearch(refresh: false);
				flag = true;
			}
			if (flag)
			{
				ReloadList();
			}
			entry = _fastFlagList.FirstOrDefault((FastFlag x) => x.Name == name);
		}
		RemoteDataManager remoteManager = new RemoteDataManager();
		await remoteManager.LoadData();
		if (!DecodeBase64Flags(remoteManager.Prop.AllowedFastFlags).Contains(name) && await Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.Menu_FastFlagEditor_NotInWhiteList, name), MessageBoxImage.Warning, MessageBoxButton.YesNo) == MessageBoxResult.Yes)
		{
			App.FastFlags.SetValue(name, null);
			if (entry != null)
			{
				_fastFlagList.Remove(entry);
			}
			else
			{
				ReloadList();
			}
			UpdateTotalFlagsCount();
			return;
		}
		if (entry != null)
		{
			DataGrid.SelectedItem = entry;
			DataGrid.ScrollIntoView(entry, null);
		}
		UpdateTotalFlagsCount();
		ReloadList();
	}

	private async Task ImportJSON(string json)
	{
		Dictionary<string, object> list = null;
		json = json.Trim();
		if (!json.StartsWith('{'))
		{
			json = "{" + json;
		}
		if (!json.EndsWith('}'))
		{
			int num = json.LastIndexOf('}');
			json = ((num == -1) ? (json + "}") : json.Substring(0, num + 1));
		}
		try
		{
			list = JsonSerializer.Deserialize<Dictionary<string, object>>(json, _jsonOptions);
			if (list == null)
			{
				throw new InvalidOperationException("JSON returned null");
			}
		}
		catch (Exception ex)
		{
			Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.Menu_FastFlagEditor_InvalidJSON, ex.Message), MessageBoxImage.Error);
			ShowAddDialog();
			return;
		}
		App.FastFlags.suspendUndoSnapshot = true;
		App.FastFlags.SaveUndoSnapshot();
		List<string> list2 = (from x in App.FastFlags.Prop
			where list.ContainsKey(x.Key)
			select x.Key).ToList();
		bool flag = false;
		if (list2.Count > 0)
		{
			string text = string.Format(CultureInfo.InvariantCulture, Strings.Menu_FastFlagEditor_ConflictingImport, list2.Count, string.Join(", ", list2.Take(25)));
			if (list2.Count > 25)
			{
				text += "...";
			}
			flag = await Frontend.ShowMessageBox(text, MessageBoxImage.Question, MessageBoxButton.YesNo) == MessageBoxResult.Yes;
		}
		foreach (KeyValuePair<string, object> item in list)
		{
			if (!App.FastFlags.Prop.ContainsKey(item.Key) || flag)
			{
				string text2 = item.Value?.ToString();
				if (text2 != null)
				{
					App.FastFlags.SetValue(item.Key, text2);
				}
			}
		}
		App.FastFlags.suspendUndoSnapshot = false;
		RemoteDataManager remoteManager = new RemoteDataManager();
		await remoteManager.LoadData();
		HashSet<string> base64Flags = DecodeBase64Flags(remoteManager.Prop.AllowedFastFlags);
		List<string> invalidFlags = list.Keys.Where((string item) => !base64Flags.Contains(item)).ToList();
		if (invalidFlags.Count > 0 && await Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.Menu_FastFlagEditor_NotInWhiteList, invalidFlags.Count), MessageBoxImage.Warning, MessageBoxButton.YesNo) == MessageBoxResult.Yes)
		{
			foreach (string item2 in invalidFlags)
			{
				App.FastFlags.SetValue(item2, null);
			}
		}
		ClearSearch();
		ReloadList();
	}

	private void DeleteButton_Click(object sender, RoutedEventArgs e)
	{
		if (_dataGrid == null)
		{
			return;
		}
		App.FastFlags.SaveUndoSnapshot();
		App.FastFlags.suspendUndoSnapshot = true;
		List<FastFlag> list = new List<FastFlag>();
		foreach (FastFlag item in _dataGrid.SelectedItems.OfType<FastFlag>())
		{
			list.Add(item);
		}
		foreach (FastFlag item2 in list)
		{
			_fastFlagList.Remove(item2);
			App.FastFlags.SetValue(item2.Name, null);
		}
		App.FastFlags.suspendUndoSnapshot = false;
		ReloadList();
	}

	private async void DeleteAllButton_Click(object sender, RoutedEventArgs e)
	{
		if (!_fastFlagList.Any() && App.FastFlags.Prop.Count <= 0)
		{
			await Frontend.ShowMessageBox(Strings.Menu_FastFlagEditor_NoFlagDelete);
		}
		else
		{
			if (await Frontend.ShowMessageBox(Strings.Menu_FastFlagEditor_ConfirmDeleteAll, MessageBoxImage.Warning, MessageBoxButton.YesNo) != MessageBoxResult.Yes)
			{
				return;
			}
			try
			{
				App.FastFlags.SaveUndoSnapshot();
				App.FastFlags.suspendUndoSnapshot = true;
				_fastFlagList.Clear();
				foreach (string item in App.FastFlags.Prop.Keys.ToList())
				{
					App.FastFlags.SetValue(item, null);
				}
				App.FastFlags.suspendUndoSnapshot = false;
				ReloadList();
			}
			catch (Exception ex)
			{
				await Frontend.ShowMessageBox("An error occurred:\n" + ex.Message, MessageBoxImage.Error);
			}
		}
	}

	private async void CopyJSONButton_Click(object sender, RoutedEventArgs e)
	{
		string text = BuildFormattedJSON();
		try
		{
			IClipboard clipboard = TopLevel.GetTopLevel(this)?.Clipboard;
			if (clipboard != null)
			{
				await clipboard.SetTextAsync(text);
			}
		}
		catch (Exception ex)
		{
			await Frontend.ShowMessageBox("An error occurred:\n" + ex.Message, MessageBoxImage.Error);
		}
	}

	private void ExportJSONButton_Click(object sender, RoutedEventArgs e)
	{
		string json = BuildFormattedJSON();
		SaveJSONToFile(json);
	}

	private static string BuildFormattedJSON()
	{
		Dictionary<string, object> prop = App.FastFlags.Prop;
		IOrderedEnumerable<IGrouping<string, KeyValuePair<string, object>>> orderedEnumerable = from g in prop.GroupBy((KeyValuePair<string, object> kvp) =>
			{
				Match match = Regex.Match(kvp.Key, "^[A-Z]+[a-z]*");
				return (!match.Success) ? "Other" : match.Value;
			})
			orderby g.Key
			select g;
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendLine("{");
		int count = prop.Count;
		int num = 0;
		int num2 = 0;
		foreach (IGrouping<string, KeyValuePair<string, object>> item in orderedEnumerable)
		{
			if (num2 > 0)
			{
				stringBuilder.AppendLine();
			}
			foreach (KeyValuePair<string, object> item2 in item.OrderByDescending((KeyValuePair<string, object> kvp) => kvp.Key.Length + (kvp.Value?.ToString()?.Length).GetValueOrDefault()))
			{
				num++;
				bool flag = num == count;
				string text = $"    \"{item2.Key}\": \"{item2.Value}\"";
				if (!flag)
				{
					text += ",";
				}
				stringBuilder.AppendLine(text);
			}
			num2++;
		}
		stringBuilder.AppendLine("}");
		return stringBuilder.ToString();
	}

	private async void SaveJSONToFile(string json)
	{
		try
		{
			TopLevel topLevel = TopLevel.GetTopLevel(this);
			if (topLevel == null)
			{
				return;
			}
			IStorageFile storageFile = await topLevel.StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
			{
				Title = "ESave JSON or TXT File",
				SuggestedFileName = "MerostrapExport.json",
				DefaultExtension = "json",
				FileTypeChoices = new _003C_003Ez__ReadOnlyArray<FilePickerFileType>(new FilePickerFileType[2]
				{
					new FilePickerFileType("JSON Files")
					{
						Patterns = new _003C_003Ez__ReadOnlySingleElementList<string>("*.json")
					},
					new FilePickerFileType("TXT Files")
					{
						Patterns = new _003C_003Ez__ReadOnlySingleElementList<string>("*.txt")
					}
				})
			});
			if (storageFile == null)
			{
				return;
			}
			await using Stream stream = await storageFile.OpenWriteAsync();
			using StreamWriter writer = new StreamWriter(stream);
			await writer.WriteAsync(json);
			await Frontend.ShowMessageBox(Strings.Menu_FastFlagEditor_Exported);
		}
		catch (Exception ex)
		{
			await Frontend.ShowMessageBox("An error occurred while saving:\n" + ex.Message, MessageBoxImage.Error);
		}
	}

	private async void FlagProfiles_Click(object sender, RoutedEventArgs e)
	{
		if (!(TopLevel.GetTopLevel(this) is Window owner))
		{
			return;
		}
		App.FrostRPC?.SetDialog("Profiles");
		FlagProfilesDialog dialog = new FlagProfilesDialog();
		await dialog.ShowDialog(owner);
		App.FrostRPC?.ClearDialog();
		if (dialog.Result != MessageBoxResult.OK)
		{
			return;
		}
		if (dialog.Tabs.SelectedIndex == 0)
		{
			string text = dialog.SaveProfile.Text?.Trim() ?? string.Empty;
			if (string.IsNullOrWhiteSpace(text))
			{
				return;
			}
			App.FastFlags.SaveProfile(text);
		}
		else if (dialog.Tabs.SelectedIndex == 1)
		{
			string text2 = dialog.LoadProfile.SelectedValue?.ToString();
			if (string.IsNullOrEmpty(text2))
			{
				return;
			}
			App.FastFlags.LoadProfile(text2, dialog.ClearFlags.IsChecked == true);
		}
		await Task.Delay(1000);
		ReloadList();
	}

	private async void CleanListButton_Click(object sender, RoutedEventArgs e)
	{
		App.FrostRPC?.SetDialog("Dialog: Cleaning List");
		App.FastFlags.suspendUndoSnapshot = true;
		App.FastFlags.SaveUndoSnapshot();
		try
		{
			RemoteDataManager remoteManager = new RemoteDataManager();
			await remoteManager.LoadData();
			HashSet<string> hashSet = DecodeBase64Flags(remoteManager.Prop.AllowedFastFlags);
			App.Logger.Info($"Loaded {hashSet.Count} allowed flags.");
			IEnumerable<FastFlag> allFlags = App.FastFlags.GetAllFlags();
			Dictionary<string, object> dictionary = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
			foreach (FastFlag item in allFlags)
			{
				string text = item.Name.Trim();
				if (!hashSet.Contains(text))
				{
					dictionary[text] = item.Value;
					App.FastFlags.SetValue(text, null);
				}
			}
			int count = dictionary.Count;
			if (count == 0)
			{
				await Frontend.ShowMessageBox(Strings.Menu_FastFlagEditor_NoInvalid);
				return;
			}
			await Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.Menu_FastFlagEditor_HaveBeenRemoved, count));
			ReloadList();
		}
		catch (Exception ex)
		{
			await Frontend.ShowMessageBox("An error occurred during FastFlag cleanup: " + ex.Message, MessageBoxImage.Error);
		}
		finally
		{
			App.FastFlags.suspendUndoSnapshot = false;
			App.FrostRPC?.ClearDialog();
		}
	}

	private static HashSet<string> DecodeBase64Flags(string? base64)
	{
		HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		if (string.IsNullOrWhiteSpace(base64))
		{
			return hashSet;
		}
		try
		{
			byte[] bytes = Convert.FromBase64String(base64.Trim().Replace("\n", "", StringComparison.Ordinal).Replace("\r", "", StringComparison.Ordinal));
			using JsonDocument jsonDocument = JsonDocument.Parse(Encoding.UTF8.GetString(bytes));
			if (jsonDocument.RootElement.TryGetProperty("Allowed", out var value))
			{
				foreach (JsonElement item in value.EnumerateArray())
				{
					string text = item.GetString()?.Trim();
					if (!string.IsNullOrEmpty(text))
					{
						hashSet.Add(text);
					}
				}
			}
		}
		catch (Exception ex)
		{
			App.Logger.Error("Failed to decode Base64: " + ex.Message);
		}
		return hashSet;
	}

	private void ToggleButton_Click(object sender, RoutedEventArgs e)
	{
		if (sender is ToggleButton toggleButton)
		{
			_showPresets = toggleButton.IsChecked ?? true;
			ReloadList();
		}
	}

	private void DataGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
	{
		if (!(e.Row.DataContext is FastFlag fastFlag) || !(e.EditingElement is TextBox textBox))
		{
			return;
		}
		App.FastFlags.suspendUndoSnapshot = true;
		App.FastFlags.SaveUndoSnapshot();
		string text = textBox.Text?.Trim() ?? string.Empty;
		string text2 = e.Column.Header?.ToString() ?? string.Empty;
		if (text2 == Strings.Common_Name)
		{
			string name = fastFlag.Name;
			if (!(text == name) && !string.IsNullOrEmpty(text))
			{
				if (App.FastFlags.GetValue(text) != null)
				{
					Frontend.ShowMessageBox(Strings.Menu_FastFlagEditor_AlreadyExists);
					e.Cancel = true;
					textBox.Text = name;
				}
				else
				{
					App.FastFlags.SetValue(name, null);
					App.FastFlags.SetValue(text, fastFlag.Value);
					fastFlag.Name = text;
					if (!text.Contains(_searchFilter, StringComparison.OrdinalIgnoreCase))
					{
						ClearSearch();
					}
					IEnumerable<string> values = FastFlagManager.PresetFlags.Values;
					fastFlag.Preset = (values.Contains(text) ? LucideIconNames.CircleCheck : LucideIconNames.CircleX);
					ReloadList();
				}
			}
		}
		else if (text2 == Strings.Common_Value)
		{
			string value = (fastFlag.Value = text);
			App.FastFlags.SetValue(fastFlag.Name, value);
		}
		App.FastFlags.suspendUndoSnapshot = false;
	}

	private void DataGrid_SelectionChanged(object? sender, SelectionChangedEventArgs e)
	{
		if (_dataGrid != null && DeleteSelectedButton != null)
		{
			DeleteSelectedButton.IsEnabled = _dataGrid.SelectedItems.Count > 0;
		}
	}

	private void ClearSearch(bool refresh = true)
	{
		SearchTextBox.Text = "";
		_searchFilter = "";
		if (refresh)
		{
			ReloadList();
		}
	}

	private async void SearchTextBox_TextChanged(object? sender, TextChangedEventArgs e)
	{
		string newSearch = SearchTextBox.Text?.Trim() ?? "";
		_searchCancellationTokenSource?.Cancel();
		_searchCancellationTokenSource = new CancellationTokenSource();
		try
		{
			await Task.Delay(70, _searchCancellationTokenSource.Token);
			_searchFilter = newSearch;
			ReloadList();
			ShowSearchSuggestion(newSearch);
		}
		catch (TaskCanceledException)
		{
		}
	}

	private void SuggestionTextBlock_PointerPressed(object? sender, PointerPressedEventArgs e)
	{
		string text = SuggestionKeywordRun.Text;
		if (!string.IsNullOrEmpty(text))
		{
			SearchTextBox.Text = text;
			SearchTextBox.CaretIndex = text.Length;
		}
	}

	private void ShowSearchSuggestion(string searchFilter)
	{
		if (!string.IsNullOrWhiteSpace(searchFilter))
		{
			string text = (from flag in App.FastFlags.Prop.Keys
				where flag.Contains(searchFilter, StringComparison.OrdinalIgnoreCase)
				orderby !flag.StartsWith(searchFilter, StringComparison.OrdinalIgnoreCase), flag.IndexOf(searchFilter, StringComparison.OrdinalIgnoreCase), flag.Length
				select flag).FirstOrDefault();
			if (string.IsNullOrEmpty(text))
			{
				SuggestionKeywordRun.Text = text;
			}
		}
	}

	private void OnDragEnter(object? sender, DragEventArgs e)
	{
		if (e.DataTransfer.Contains(DataFormat.File))
		{
			DragOverlay.IsVisible = true;
		}
	}

	private void OnDragLeave(object? sender, DragEventArgs e)
	{
		DragOverlay.IsVisible = false;
	}

	private async void OnDrop(object? sender, DragEventArgs e)
	{
		DragOverlay.IsVisible = false;
		IStorageItem[] array = e.DataTransfer.TryGetFiles();
		if (array == null)
		{
			return;
		}
		string[] supportedExtensions = new string[2] { ".json", ".txt" };
		List<string> list = (from f in array
			select f.TryGetLocalPath() into p
			where !string.IsNullOrEmpty(p)
			select (p) into p
			where supportedExtensions.Contains(System.IO.Path.GetExtension(p), StringComparer.OrdinalIgnoreCase)
			select p).ToList();
		if (list.Count == 0)
		{
			await Frontend.ShowMessageBox(Strings.Menu_FastFlagEditor_FileExtensionWarning);
			return;
		}
		foreach (string path in list)
		{
			try
			{
				await ImportJSON(await File.ReadAllTextAsync(path));
			}
			catch (Exception ex)
			{
				await Frontend.ShowMessageBox("Failed to read/import '" + System.IO.Path.GetFileName(path) + "': " + ex.Message, MessageBoxImage.Error);
			}
		}
	}

	public void Dispose()
	{
		Dispose(disposing: true);
		GC.SuppressFinalize(this);
	}

	protected virtual void Dispose(bool disposing)
	{
		if (!_disposed)
		{
			if (disposing)
			{
				_searchCancellationTokenSource?.Cancel();
				_searchCancellationTokenSource?.Dispose();
				_searchCancellationTokenSource = null;
			}
			_disposed = true;
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		DeleteSelectedButton = nameScope?.Find<IconButton>("DeleteSelectedButton");
		TogglePresetsButton = nameScope?.Find<ToggleButton>("TogglePresetsButton");
		TotalFlagsTextBlock = nameScope?.Find<TextBlock>("TotalFlagsTextBlock");
		SearchTextBox = nameScope?.Find<TextBox>("SearchTextBox");
		SuggestionTextBlock = nameScope?.Find<TextBlock>("SuggestionTextBlock");
		SuggestionKeywordRun = nameScope?.Find<Run>("SuggestionKeywordRun");
		DataGrid = nameScope?.Find<DataGrid>("DataGrid");
		EmptyTextBlock = nameScope?.Find<TextBlock>("EmptyTextBlock");
		DragOverlay = nameScope?.Find<Grid>("DragOverlay");
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, FastFlagEditor P_1)
	{
		XamlIlContext.Context<FastFlagEditor> context = new XamlIlContext.Context<FastFlagEditor>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FPages_002FFastFlags_002FFastFlagEditor_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/Pages/FastFlags/FastFlagEditor.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Focusable = true;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		DragDrop.SetAllowDrop(grid5, value: true);
		grid5.AddHandler(DragDrop.DropEvent, context.RootObject.OnDrop);
		grid5.AddHandler(DragDrop.DragEnterEvent, context.RootObject.OnDragEnter);
		grid5.AddHandler(DragDrop.DragLeaveEvent, context.RootObject.OnDragLeave);
		grid5.Background = new ImmutableSolidColorBrush(16777215u);
		Avalonia.Controls.Controls children = grid5.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children.Add(grid6);
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 4;
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid9.RowDefinitions = rowDefinitions;
		grid9.Margin = new Thickness(14.0, 14.0, 14.0, 14.0);
		Avalonia.Controls.Controls children2 = grid9.Children;
		FAInfoBar fAInfoBar2;
		FAInfoBar fAInfoBar = (fAInfoBar2 = new FAInfoBar());
		((ISupportInitialize)fAInfoBar).BeginInit();
		children2.Add(fAInfoBar);
		Grid.SetRow(fAInfoBar2, 0);
		fAInfoBar2.Message = Strings.Menu_FastFlagEditor_WhiteList;
		fAInfoBar2.Severity = FAInfoBarSeverity.Informational;
		fAInfoBar2.IsOpen = true;
		fAInfoBar2.IsClosable = false;
		fAInfoBar2.Margin = new Thickness(0.0, 4.0, 0.0, 8.0);
		((ISupportInitialize)fAInfoBar2).EndInit();
		Avalonia.Controls.Controls children3 = grid9.Children;
		WrapPanel wrapPanel2;
		WrapPanel wrapPanel = (wrapPanel2 = new WrapPanel());
		((ISupportInitialize)wrapPanel).BeginInit();
		children3.Add(wrapPanel);
		Grid.SetRow(wrapPanel2, 1);
		wrapPanel2.Orientation = Orientation.Horizontal;
		wrapPanel2.Margin = new Thickness(0.0, 0.0, 0.0, 0.0);
		Avalonia.Controls.Controls children4 = wrapPanel2.Children;
		IconButton iconButton2;
		IconButton iconButton = (iconButton2 = new IconButton());
		((ISupportInitialize)iconButton).BeginInit();
		children4.Add(iconButton);
		iconButton2.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.AddButton_Click), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		iconButton2.Icon = LucideIconNames.Plus;
		iconButton2.Content = Strings.Menu_FastFlagEditor_AddNew;
		iconButton2.Margin = new Thickness(0.0, 0.0, 8.0, 8.0);
		((ISupportInitialize)iconButton2).EndInit();
		Avalonia.Controls.Controls children5 = wrapPanel2.Children;
		IconButton iconButton5;
		IconButton iconButton4 = (iconButton5 = new IconButton());
		((ISupportInitialize)iconButton4).BeginInit();
		children5.Add(iconButton4);
		iconButton5.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.DeleteButton_Click), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		iconButton5.Icon = LucideIconNames.Trash2;
		iconButton5.Classes.Add("Danger");
		iconButton5.Content = Strings.Menu_FastFlagEditor_DeleteSelected;
		iconButton5.Margin = new Thickness(0.0, 0.0, 8.0, 8.0);
		iconButton5.Name = "DeleteSelectedButton";
		object element = iconButton5;
		context.AvaloniaNameScope.Register("DeleteSelectedButton", element);
		iconButton5.IsEnabled = false;
		((ISupportInitialize)iconButton5).EndInit();
		Avalonia.Controls.Controls children6 = wrapPanel2.Children;
		IconButton iconButton7;
		IconButton iconButton6 = (iconButton7 = new IconButton());
		((ISupportInitialize)iconButton6).BeginInit();
		children6.Add(iconButton6);
		iconButton7.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.DeleteAllButton_Click), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		iconButton7.Icon = LucideIconNames.Trash;
		iconButton7.Content = Strings.Common_DeleteAll;
		iconButton7.Margin = new Thickness(0.0, 0.0, 8.0, 8.0);
		((ISupportInitialize)iconButton7).EndInit();
		Avalonia.Controls.Controls children7 = wrapPanel2.Children;
		IconButton iconButton9;
		IconButton iconButton8 = (iconButton9 = new IconButton());
		((ISupportInitialize)iconButton8).BeginInit();
		children7.Add(iconButton8);
		iconButton9.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.CopyJSONButton_Click), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		iconButton9.Icon = LucideIconNames.Clipboard;
		iconButton9.Content = Strings.Common_CopyAll;
		iconButton9.Margin = new Thickness(0.0, 0.0, 8.0, 8.0);
		((ISupportInitialize)iconButton9).EndInit();
		Avalonia.Controls.Controls children8 = wrapPanel2.Children;
		IconButton iconButton11;
		IconButton iconButton10 = (iconButton11 = new IconButton());
		((ISupportInitialize)iconButton10).BeginInit();
		children8.Add(iconButton10);
		iconButton11.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.ExportJSONButton_Click), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		iconButton11.Icon = LucideIconNames.ArrowRightFromLine;
		iconButton11.Content = Strings.Menu_FastFlagEditor_ExportJson;
		iconButton11.Margin = new Thickness(0.0, 0.0, 8.0, 8.0);
		((ISupportInitialize)iconButton11).EndInit();
		Avalonia.Controls.Controls children9 = wrapPanel2.Children;
		IconButton iconButton13;
		IconButton iconButton12 = (iconButton13 = new IconButton());
		((ISupportInitialize)iconButton12).BeginInit();
		children9.Add(iconButton12);
		iconButton13.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.FlagProfiles_Click), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		iconButton13.Icon = LucideIconNames.FilePenLine;
		iconButton13.Content = Strings.Common_Profiles;
		iconButton13.Margin = new Thickness(0.0, 0.0, 8.0, 8.0);
		((ISupportInitialize)iconButton13).EndInit();
		Avalonia.Controls.Controls children10 = wrapPanel2.Children;
		IconButton iconButton15;
		IconButton iconButton14 = (iconButton15 = new IconButton());
		((ISupportInitialize)iconButton14).BeginInit();
		children10.Add(iconButton14);
		iconButton15.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.CleanListButton_Click), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		iconButton15.Icon = LucideIconNames.Funnel;
		iconButton15.Content = Strings.Menu_FastFlagEditor_CleanList;
		iconButton15.Margin = new Thickness(0.0, 0.0, 8.0, 8.0);
		((ISupportInitialize)iconButton15).EndInit();
		Avalonia.Controls.Controls children11 = wrapPanel2.Children;
		ToggleButton toggleButton2;
		ToggleButton toggleButton = (toggleButton2 = new ToggleButton());
		((ISupportInitialize)toggleButton).BeginInit();
		children11.Add(toggleButton);
		toggleButton2.Name = "TogglePresetsButton";
		element = toggleButton2;
		context.AvaloniaNameScope.Register("TogglePresetsButton", element);
		toggleButton2.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.ToggleButton_Click), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		toggleButton2.Content = Strings.Menu_FastFlagEditor_ShowPresetFlags;
		toggleButton2.IsChecked = false;
		toggleButton2.VerticalAlignment = VerticalAlignment.Center;
		toggleButton2.Margin = new Thickness(0.0, 0.0, 8.0, 8.0);
		((ISupportInitialize)toggleButton2).EndInit();
		((ISupportInitialize)wrapPanel2).EndInit();
		Avalonia.Controls.Controls children12 = grid9.Children;
		Grid grid11;
		Grid grid10 = (grid11 = new Grid());
		((ISupportInitialize)grid10).BeginInit();
		children12.Add(grid10);
		Grid.SetRow(grid11, 2);
		RowDefinitions rowDefinitions2 = new RowDefinitions();
		rowDefinitions2.Capacity = 2;
		rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid11.RowDefinitions = rowDefinitions2;
		grid11.Margin = new Thickness(0.0, 0.0, 1.0, 4.0);
		Avalonia.Controls.Controls children13 = grid11.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children13.Add(textBlock);
		textBlock2.Name = "TotalFlagsTextBlock";
		element = textBlock2;
		context.AvaloniaNameScope.Register("TotalFlagsTextBlock", element);
		Grid.SetRow(textBlock2, 0);
		textBlock2.HorizontalAlignment = HorizontalAlignment.Right;
		textBlock2.Margin = new Thickness(0.0, 0.0, 8.0, 8.0);
		textBlock2.FontWeight = FontWeight.Medium;
		textBlock2.FontSize = 12.0;
		textBlock2.Text = Strings.Menu_FastFlagEditor_TotalFlags;
		((ISupportInitialize)textBlock2).EndInit();
		Avalonia.Controls.Controls children14 = grid11.Children;
		Grid grid13;
		Grid grid12 = (grid13 = new Grid());
		((ISupportInitialize)grid12).BeginInit();
		children14.Add(grid12);
		Grid.SetRow(grid13, 1);
		Avalonia.Controls.Controls children15 = grid13.Children;
		TextBox textBox2;
		TextBox textBox = (textBox2 = new TextBox());
		((ISupportInitialize)textBox).BeginInit();
		children15.Add(textBox);
		textBox2.Name = "SearchTextBox";
		element = textBox2;
		context.AvaloniaNameScope.Register("SearchTextBox", element);
		textBox2.VerticalContentAlignment = VerticalAlignment.Center;
		textBox2.PlaceholderText = Strings.Common_Search;
		textBox2.AddHandler(TextBox.TextChangedEvent, context.RootObject.SearchTextBox_TextChanged);
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		textBox2.InnerLeftContent = lucide;
		lucide2.Height = 16.0;
		lucide2.Width = 16.0;
		lucide2.Icon = LucideIconNames.Search;
		lucide2.Margin = new Thickness(10.0, 0.0, 0.0, 0.0);
		lucide2.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)lucide2).EndInit();
		((ISupportInitialize)textBox2).EndInit();
		Avalonia.Controls.Controls children16 = grid13.Children;
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		children16.Add(textBlock3);
		textBlock4.Name = "SuggestionTextBlock";
		element = textBlock4;
		context.AvaloniaNameScope.Register("SuggestionTextBlock", element);
		textBlock4.Cursor = new Cursor(StandardCursorType.Hand);
		textBlock4.AddHandler(InputElement.PointerPressedEvent, context.RootObject.SuggestionTextBlock_PointerPressed);
		textBlock4.Margin = new Thickness(12.0, 0.0, 11.0, 0.0);
		textBlock4.HorizontalAlignment = HorizontalAlignment.Right;
		textBlock4.VerticalAlignment = VerticalAlignment.Center;
		textBlock4.FontSize = 14.0;
		textBlock4.Foreground = new ImmutableSolidColorBrush(4283540205u);
		textBlock4.Opacity = 0.0;
		textBlock4.IsVisible = false;
		InlineCollection? inlines = textBlock4.Inlines;
		Run run = new Run();
		((ISupportInitialize)run).BeginInit();
		run.Text = "Looking for ";
		((ISupportInitialize)run).EndInit();
		inlines.Add(run);
		textBlock4.Inlines.Add(" ");
		InlineCollection? inlines2 = textBlock4.Inlines;
		Run run2 = new Run();
		((ISupportInitialize)run2).BeginInit();
		run2.Name = "SuggestionKeywordRun";
		element = run2;
		context.AvaloniaNameScope.Register("SuggestionKeywordRun", element);
		run2.Text = "";
		run2.FontWeight = FontWeight.Bold;
		((ISupportInitialize)run2).EndInit();
		inlines2.Add(run2);
		textBlock4.Inlines.Add(" ");
		InlineCollection? inlines3 = textBlock4.Inlines;
		Run run3 = new Run();
		((ISupportInitialize)run3).BeginInit();
		run3.Text = "?";
		((ISupportInitialize)run3).EndInit();
		inlines3.Add(run3);
		((ISupportInitialize)textBlock4).EndInit();
		((ISupportInitialize)grid13).EndInit();
		((ISupportInitialize)grid11).EndInit();
		Avalonia.Controls.Controls children17 = grid9.Children;
		Grid grid15;
		Grid grid14 = (grid15 = new Grid());
		((ISupportInitialize)grid14).BeginInit();
		children17.Add(grid14);
		Grid grid16 = (grid4 = grid15);
		context.PushParent(grid4);
		Grid grid17 = grid4;
		Grid.SetRow(grid17, 3);
		Avalonia.Controls.Controls children18 = grid17.Children;
		DataGrid dataGrid2;
		DataGrid dataGrid = (dataGrid2 = new DataGrid());
		((ISupportInitialize)dataGrid).BeginInit();
		children18.Add(dataGrid);
		DataGrid dataGrid4;
		DataGrid dataGrid3 = (dataGrid4 = dataGrid2);
		context.PushParent(dataGrid4);
		dataGrid4.Name = "DataGrid";
		element = dataGrid4;
		context.AvaloniaNameScope.Register("DataGrid", element);
		dataGrid4.AutoGenerateColumns = false;
		dataGrid4.AddHandler(DataGrid.SelectionChangedEvent, context.RootObject.DataGrid_SelectionChanged);
		dataGrid4.CanUserResizeColumns = true;
		dataGrid4.CellEditEnding += context.RootObject.DataGrid_CellEditEnding;
		dataGrid4.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
		dataGrid4.GridLinesVisibility = DataGridGridLinesVisibility.Horizontal;
		dataGrid4.HeadersVisibility = DataGridHeadersVisibility.All;
		ObservableCollection<DataGridColumn> columns = dataGrid4.Columns;
		DataGridTemplateColumn dataGridTemplateColumn;
		DataGridTemplateColumn item = (dataGridTemplateColumn = new DataGridTemplateColumn());
		context.PushParent(dataGridTemplateColumn);
		dataGridTemplateColumn.MinWidth = 67.0;
		dataGridTemplateColumn.Width = (DataGridLength)new DataGridLengthConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "Auto");
		dataGridTemplateColumn.Header = Strings.Common_Presets;
		dataGridTemplateColumn.CanUserResize = false;
		StyledProperty<bool> isVisibleProperty = DataGridColumn.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().ElementName(context.AvaloniaNameScope, "TogglePresetsButton").Property(ToggleButton.IsCheckedProperty, PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor).Build());
		context.ProvideTargetProperty = DataGridColumn.IsVisibleProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		dataGridTemplateColumn.Bind(isVisibleProperty, binding);
		DataTemplate dataTemplate = new DataTemplate();
		dataTemplate.DataType = typeof(FastFlag);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_38.Build_1), context);
		dataGridTemplateColumn.CellTemplate = dataTemplate;
		context.PopParent();
		columns.Add(item);
		ObservableCollection<DataGridColumn> columns2 = dataGrid4.Columns;
		DataGridTextColumn dataGridTextColumn;
		DataGridTextColumn item2 = (dataGridTextColumn = new DataGridTextColumn());
		context.PushParent(dataGridTextColumn);
		DataGridTextColumn dataGridTextColumn2 = dataGridTextColumn;
		dataGridTextColumn2.Width = (DataGridLength)new DataGridLengthConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "*");
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EFastFlag_002CMerostrap_002EName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EControls_002EDataGridBoundColumn_002CAvalonia_002EControls_002EDataGrid_002EBinding_0021Property();
		CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		dataGridTextColumn2.Binding = binding2;
		dataGridTextColumn2.Header = Strings.Common_Name;
		context.PopParent();
		columns2.Add(item2);
		ObservableCollection<DataGridColumn> columns3 = dataGrid4.Columns;
		DataGridTextColumn item3 = (dataGridTextColumn = new DataGridTextColumn());
		context.PushParent(dataGridTextColumn);
		DataGridTextColumn dataGridTextColumn3 = dataGridTextColumn;
		dataGridTextColumn3.Width = (DataGridLength)new DataGridLengthConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "250");
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EFastFlag_002CMerostrap_002EValue_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EControls_002EDataGridBoundColumn_002CAvalonia_002EControls_002EDataGrid_002EBinding_0021Property();
		CompiledBinding binding3 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		dataGridTextColumn3.Binding = binding3;
		dataGridTextColumn3.Header = Strings.Common_Value;
		context.PopParent();
		columns3.Add(item3);
		context.PopParent();
		((ISupportInitialize)dataGrid3).EndInit();
		Avalonia.Controls.Controls children19 = grid17.Children;
		TextBlock textBlock7;
		TextBlock textBlock6 = (textBlock7 = new TextBlock());
		((ISupportInitialize)textBlock6).BeginInit();
		children19.Add(textBlock6);
		TextBlock textBlock5;
		TextBlock textBlock8 = (textBlock5 = textBlock7);
		context.PushParent(textBlock5);
		TextBlock textBlock9 = textBlock5;
		textBlock9.Name = "EmptyTextBlock";
		element = textBlock9;
		context.AvaloniaNameScope.Register("EmptyTextBlock", element);
		textBlock9.Text = Strings.Menu_FastFlagEditor_NoFlags;
		textBlock9.FontSize = 16.0;
		textBlock9.FontWeight = FontWeight.Medium;
		textBlock9.HorizontalAlignment = HorizontalAlignment.Center;
		textBlock9.VerticalAlignment = VerticalAlignment.Center;
		textBlock9.IsHitTestVisible = false;
		textBlock9.IsVisible = false;
		StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("TextFillColorSecondaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding4 = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock9.Bind(foregroundProperty, binding4);
		textBlock9.TextAlignment = TextAlignment.Center;
		context.PopParent();
		((ISupportInitialize)textBlock8).EndInit();
		context.PopParent();
		((ISupportInitialize)grid16).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		Avalonia.Controls.Controls children20 = grid5.Children;
		Grid grid19;
		Grid grid18 = (grid19 = new Grid());
		((ISupportInitialize)grid18).BeginInit();
		children20.Add(grid18);
		Grid grid20 = (grid4 = grid19);
		context.PushParent(grid4);
		Grid grid21 = grid4;
		grid21.Name = "DragOverlay";
		element = grid21;
		context.AvaloniaNameScope.Register("DragOverlay", element);
		grid21.IsHitTestVisible = false;
		grid21.IsVisible = false;
		grid21.Background = new ImmutableSolidColorBrush(2281701376u);
		Avalonia.Controls.Controls children21 = grid21.Children;
		TextBlock textBlock11;
		TextBlock textBlock10 = (textBlock11 = new TextBlock());
		((ISupportInitialize)textBlock10).BeginInit();
		children21.Add(textBlock10);
		textBlock11.Text = Strings.Menu_FastFlagEditor_DragOverlay;
		textBlock11.FontSize = 20.0;
		textBlock11.FontWeight = FontWeight.DemiBold;
		textBlock11.HorizontalAlignment = HorizontalAlignment.Center;
		textBlock11.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)textBlock11).EndInit();
		Avalonia.Controls.Controls children22 = grid21.Children;
		Grid grid23;
		Grid grid22 = (grid23 = new Grid());
		((ISupportInitialize)grid22).BeginInit();
		children22.Add(grid22);
		Grid grid24 = (grid4 = grid23);
		context.PushParent(grid4);
		Grid grid25 = grid4;
		Avalonia.Controls.Controls children23 = grid25.Children;
		Avalonia.Controls.Shapes.Path path2;
		Avalonia.Controls.Shapes.Path path = (path2 = new Avalonia.Controls.Shapes.Path());
		((ISupportInitialize)path).BeginInit();
		children23.Add(path);
		Avalonia.Controls.Shapes.Path path4;
		Avalonia.Controls.Shapes.Path path3 = (path4 = path2);
		context.PushParent(path4);
		Avalonia.Controls.Shapes.Path path5 = path4;
		StyledProperty<IBrush?> strokeProperty = Shape.StrokeProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("AccentButtonBackground");
		context.ProvideTargetProperty = Shape.StrokeProperty;
		BindingBase binding5 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		path5.Bind(strokeProperty, binding5);
		path5.StrokeThickness = 3.0;
		path5.StrokeJoin = PenLineJoin.Round;
		path5.Data = Geometry.Parse("M 0,0 L 30,0 M 0,0 L 0,30");
		path5.HorizontalAlignment = HorizontalAlignment.Left;
		path5.VerticalAlignment = VerticalAlignment.Top;
		path5.Margin = new Thickness(10.0, 10.0, 0.0, 0.0);
		context.PopParent();
		((ISupportInitialize)path3).EndInit();
		Avalonia.Controls.Controls children24 = grid25.Children;
		Avalonia.Controls.Shapes.Path path7;
		Avalonia.Controls.Shapes.Path path6 = (path7 = new Avalonia.Controls.Shapes.Path());
		((ISupportInitialize)path6).BeginInit();
		children24.Add(path6);
		Avalonia.Controls.Shapes.Path path8 = (path4 = path7);
		context.PushParent(path4);
		Avalonia.Controls.Shapes.Path path9 = path4;
		StyledProperty<IBrush?> strokeProperty2 = Shape.StrokeProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("AccentButtonBackground");
		context.ProvideTargetProperty = Shape.StrokeProperty;
		BindingBase binding6 = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		path9.Bind(strokeProperty2, binding6);
		path9.StrokeThickness = 3.0;
		path9.StrokeJoin = PenLineJoin.Round;
		path9.Data = Geometry.Parse("M 30,0 L 0,0 M 30,0 L 30,30");
		path9.HorizontalAlignment = HorizontalAlignment.Right;
		path9.VerticalAlignment = VerticalAlignment.Top;
		path9.Margin = new Thickness(0.0, 10.0, 10.0, 0.0);
		context.PopParent();
		((ISupportInitialize)path8).EndInit();
		Avalonia.Controls.Controls children25 = grid25.Children;
		Avalonia.Controls.Shapes.Path path11;
		Avalonia.Controls.Shapes.Path path10 = (path11 = new Avalonia.Controls.Shapes.Path());
		((ISupportInitialize)path10).BeginInit();
		children25.Add(path10);
		Avalonia.Controls.Shapes.Path path12 = (path4 = path11);
		context.PushParent(path4);
		Avalonia.Controls.Shapes.Path path13 = path4;
		StyledProperty<IBrush?> strokeProperty3 = Shape.StrokeProperty;
		DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("AccentButtonBackground");
		context.ProvideTargetProperty = Shape.StrokeProperty;
		BindingBase binding7 = dynamicResourceExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		path13.Bind(strokeProperty3, binding7);
		path13.StrokeThickness = 3.0;
		path13.StrokeJoin = PenLineJoin.Round;
		path13.Data = Geometry.Parse("M 0,30 L 30,30 M 0,30 L 0,0");
		path13.HorizontalAlignment = HorizontalAlignment.Left;
		path13.VerticalAlignment = VerticalAlignment.Bottom;
		path13.Margin = new Thickness(10.0, 0.0, 0.0, 10.0);
		context.PopParent();
		((ISupportInitialize)path12).EndInit();
		Avalonia.Controls.Controls children26 = grid25.Children;
		Avalonia.Controls.Shapes.Path path15;
		Avalonia.Controls.Shapes.Path path14 = (path15 = new Avalonia.Controls.Shapes.Path());
		((ISupportInitialize)path14).BeginInit();
		children26.Add(path14);
		Avalonia.Controls.Shapes.Path path16 = (path4 = path15);
		context.PushParent(path4);
		Avalonia.Controls.Shapes.Path path17 = path4;
		StyledProperty<IBrush?> strokeProperty4 = Shape.StrokeProperty;
		DynamicResourceExtension dynamicResourceExtension5 = new DynamicResourceExtension("AccentButtonBackground");
		context.ProvideTargetProperty = Shape.StrokeProperty;
		BindingBase binding8 = dynamicResourceExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		path17.Bind(strokeProperty4, binding8);
		path17.StrokeThickness = 3.0;
		path17.StrokeJoin = PenLineJoin.Round;
		path17.Data = Geometry.Parse("M 30,30 L 0,30 M 30,30 L 30,0");
		path17.HorizontalAlignment = HorizontalAlignment.Right;
		path17.VerticalAlignment = VerticalAlignment.Bottom;
		path17.Margin = new Thickness(0.0, 0.0, 10.0, 10.0);
		context.PopParent();
		((ISupportInitialize)path16).EndInit();
		context.PopParent();
		((ISupportInitialize)grid24).EndInit();
		context.PopParent();
		((ISupportInitialize)grid20).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(FastFlagEditor P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
