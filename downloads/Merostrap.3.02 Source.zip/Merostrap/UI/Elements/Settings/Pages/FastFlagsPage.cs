using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Data.Converters;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using CompiledAvaloniaXaml;
using LucideAvalonia.Enum;
using Merostrap.Resources;
using Merostrap.UI.Elements.Controls;

namespace Merostrap.UI.Elements.Settings.Pages;

internal class FastFlagsPage : UserControl
{
	[CompilerGenerated]
	private class XamlClosure_40
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<FastFlagsPage> context = CreateContext(P_0);
			context.IntermediateRoot = new TextBlock();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			TextBlock textBlock = (TextBlock)obj;
			context.PushParent(textBlock);
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension2;
			CompiledBindingExtension compiledBindingExtension = (compiledBindingExtension2 = new CompiledBindingExtension());
			context.PushParent(compiledBindingExtension2);
			StaticResourceExtension staticResourceExtension = new StaticResourceExtension("EnumNameConverter");
			context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EData_002ECompiledBinding_002CAvalonia_002EBase_002EConverter_0021Property();
			object? obj2 = staticResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			compiledBindingExtension2.Converter = (IValueConverter)obj2;
			context.PopParent();
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock.Bind(textProperty, binding);
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<FastFlagsPage> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<FastFlagsPage> context = new XamlIlContext.Context<FastFlagsPage>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FPages_002FFastFlagsPage_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/Pages/FastFlagsPage.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (FastFlagsPage)service;
				}
			}
			return context;
		}

		public static object Build_2(IServiceProvider P_0)
		{
			XamlIlContext.Context<FastFlagsPage> context = CreateContext(P_0);
			context.IntermediateRoot = new TextBlock();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			TextBlock textBlock = (TextBlock)obj;
			context.PushParent(textBlock);
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.System_002ECollections_002EGeneric_002EKeyValuePair_00602_002CSystem_002ERuntime_002EValue_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock.Bind(textProperty, binding);
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_3(IServiceProvider P_0)
		{
			XamlIlContext.Context<FastFlagsPage> context = CreateContext(P_0);
			context.IntermediateRoot = new TextBlock();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			TextBlock textBlock = (TextBlock)obj;
			context.PushParent(textBlock);
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension2;
			CompiledBindingExtension compiledBindingExtension = (compiledBindingExtension2 = new CompiledBindingExtension());
			context.PushParent(compiledBindingExtension2);
			StaticResourceExtension staticResourceExtension = new StaticResourceExtension("EnumNameConverter");
			context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EData_002ECompiledBinding_002CAvalonia_002EBase_002EConverter_0021Property();
			object? obj2 = staticResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			compiledBindingExtension2.Converter = (IValueConverter)obj2;
			context.PopParent();
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock.Bind(textProperty, binding);
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_4(IServiceProvider P_0)
		{
			XamlIlContext.Context<FastFlagsPage> context = CreateContext(P_0);
			context.IntermediateRoot = new TextBlock();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			TextBlock textBlock = (TextBlock)obj;
			context.PushParent(textBlock);
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension2;
			CompiledBindingExtension compiledBindingExtension = (compiledBindingExtension2 = new CompiledBindingExtension());
			context.PushParent(compiledBindingExtension2);
			StaticResourceExtension staticResourceExtension = new StaticResourceExtension("EnumNameConverter");
			context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EData_002ECompiledBinding_002CAvalonia_002EBase_002EConverter_0021Property();
			object? obj2 = staticResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			compiledBindingExtension2.Converter = (IValueConverter)obj2;
			context.PopParent();
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock.Bind(textProperty, binding);
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal OptionControl ManagerEnabled;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal OptionControl Reset;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public FastFlagsPage()
	{
		InitializeComponent();
		App.FrostRPC?.SetPage("FastFlags Settings");
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		ManagerEnabled = nameScope?.Find<OptionControl>("ManagerEnabled");
		Reset = nameScope?.Find<OptionControl>("Reset");
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, FastFlagsPage P_1)
	{
		XamlIlContext.Context<FastFlagsPage> context = new XamlIlContext.Context<FastFlagsPage>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FPages_002FFastFlagsPage_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/Pages/FastFlagsPage.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		P_1.Content = scrollViewer;
		ScrollViewer scrollViewer4;
		ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
		context.PushParent(scrollViewer4);
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		scrollViewer4.Content = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		StackPanel stackPanel5 = stackPanel4;
		stackPanel5.Margin = new Thickness(14.0, 14.0, 14.0, 14.0);
		Avalonia.Controls.Controls children = stackPanel5.Children;
		OptionControl optionControl2;
		OptionControl optionControl = (optionControl2 = new OptionControl());
		((ISupportInitialize)optionControl).BeginInit();
		children.Add(optionControl);
		OptionControl optionControl4;
		OptionControl optionControl3 = (optionControl4 = optionControl2);
		context.PushParent(optionControl4);
		OptionControl optionControl5 = optionControl4;
		optionControl5.Header = "Ask before using FastFlags";
		optionControl5.Description = "Show a Yes/No prompt when a game opens from the Roblox website. No skips saved flags and Performance mode's graphics flags for that launch.";
		ToggleSwitch toggleSwitch2;
		ToggleSwitch toggleSwitch = (toggleSwitch2 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch).BeginInit();
		optionControl5.InnerContent = toggleSwitch;
		ToggleSwitch toggleSwitch4;
		ToggleSwitch toggleSwitch3 = (toggleSwitch4 = toggleSwitch2);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch5 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EFastFlagsViewModel_002CMerostrap_002EAskBeforeUsingFastFlags_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch5.Bind(isCheckedProperty, binding);
		context.PopParent();
		((ISupportInitialize)toggleSwitch3).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl3).EndInit();
		Avalonia.Controls.Controls children2 = stackPanel5.Children;
		CardAction cardAction2;
		CardAction cardAction = (cardAction2 = new CardAction());
		((ISupportInitialize)cardAction).BeginInit();
		children2.Add(cardAction);
		CardAction cardAction4;
		CardAction cardAction3 = (cardAction4 = cardAction2);
		context.PushParent(cardAction4);
		cardAction4.Icon = LucideIconNames.FilePenLine;
		cardAction4.Header = Strings.Menu_FastFlagEditor_Title;
		cardAction4.Description = Strings.Menu_FastFlags_Editor_Description;
		StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EFastFlagsViewModel_002CMerostrap_002EOpenFastFlagEditorCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		cardAction4.Bind(commandProperty, binding2);
		context.PopParent();
		((ISupportInitialize)cardAction3).EndInit();
		Avalonia.Controls.Controls children3 = stackPanel5.Children;
		OptionControl optionControl7;
		OptionControl optionControl6 = (optionControl7 = new OptionControl());
		((ISupportInitialize)optionControl6).BeginInit();
		children3.Add(optionControl6);
		OptionControl optionControl8 = (optionControl4 = optionControl7);
		context.PushParent(optionControl4);
		OptionControl optionControl9 = optionControl4;
		optionControl9.Name = "ManagerEnabled";
		object element = optionControl9;
		context.AvaloniaNameScope.Register("ManagerEnabled", element);
		optionControl9.Header = Strings.Menu_FastFlags_ManagerEnabled_Title;
		optionControl9.Description = Strings.Menu_FastFlags_ManagerEnabled_Description;
		ToggleSwitch toggleSwitch7;
		ToggleSwitch toggleSwitch6 = (toggleSwitch7 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch6).BeginInit();
		optionControl9.InnerContent = toggleSwitch6;
		ToggleSwitch toggleSwitch8 = (toggleSwitch4 = toggleSwitch7);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch9 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty2 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EFastFlagsViewModel_002CMerostrap_002EUseFastFlagManager_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding3 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch9.Bind(isCheckedProperty2, binding3);
		context.PopParent();
		((ISupportInitialize)toggleSwitch8).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl8).EndInit();
		Avalonia.Controls.Controls children4 = stackPanel5.Children;
		OptionControl optionControl11;
		OptionControl optionControl10 = (optionControl11 = new OptionControl());
		((ISupportInitialize)optionControl10).BeginInit();
		children4.Add(optionControl10);
		OptionControl optionControl12 = (optionControl4 = optionControl11);
		context.PushParent(optionControl4);
		OptionControl optionControl13 = optionControl4;
		optionControl13.Name = "Reset";
		element = optionControl13;
		context.AvaloniaNameScope.Register("Reset", element);
		optionControl13.Header = Strings.Menu_FastFlags_Reset_Title;
		ToggleSwitch toggleSwitch11;
		ToggleSwitch toggleSwitch10 = (toggleSwitch11 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch10).BeginInit();
		optionControl13.InnerContent = toggleSwitch10;
		ToggleSwitch toggleSwitch12 = (toggleSwitch4 = toggleSwitch11);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch13 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty3 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EFastFlagsViewModel_002CMerostrap_002EResetConfiguration_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding4 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch13.Bind(isCheckedProperty3, binding4);
		context.PopParent();
		((ISupportInitialize)toggleSwitch12).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl12).EndInit();
		Avalonia.Controls.Controls children5 = stackPanel5.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children5.Add(border);
		border2.Height = 12.0;
		((ISupportInitialize)border2).EndInit();
		Avalonia.Controls.Controls children6 = stackPanel5.Children;
		OptionControl optionControl15;
		OptionControl optionControl14 = (optionControl15 = new OptionControl());
		((ISupportInitialize)optionControl14).BeginInit();
		children6.Add(optionControl14);
		OptionControl optionControl16 = (optionControl4 = optionControl15);
		context.PushParent(optionControl4);
		OptionControl optionControl17 = optionControl4;
		optionControl17.Header = Strings.Menu_FastFlags_Presets_MSAA_Title;
		optionControl17.Description = Strings.Menu_FastFlags_Presets_MSAA_Description;
		ComboBox comboBox2;
		ComboBox comboBox = (comboBox2 = new ComboBox());
		((ISupportInitialize)comboBox).BeginInit();
		optionControl17.InnerContent = comboBox;
		ComboBox comboBox4;
		ComboBox comboBox3 = (comboBox4 = comboBox2);
		context.PushParent(comboBox4);
		ComboBox comboBox5 = comboBox4;
		comboBox5.Margin = new Thickness(0.0, 0.0, 0.0, 0.0);
		comboBox5.Padding = new Thickness(10.0, 5.0, 10.0, 5.0);
		comboBox5.MinWidth = 200.0;
		StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EFastFlagsViewModel_002CMerostrap_002EMSAALevels_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.System_002ECollections_002EGeneric_002EIReadOnlyDictionary_00602_002CSystem_002ERuntime_002EKeys_39_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.OneTime
		};
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding5 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		comboBox5.Bind(itemsSourceProperty, binding5);
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EFastFlagsViewModel_002CMerostrap_002ESelectedMSAALevel_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = SelectingItemsControl.SelectedItemProperty;
		CompiledBinding compiledBinding = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_10(comboBox5, compiledBinding);
		DataTemplate dataTemplate;
		DataTemplate itemTemplate = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_40.Build_1), context);
		context.PopParent();
		comboBox5.ItemTemplate = itemTemplate;
		context.PopParent();
		((ISupportInitialize)comboBox3).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl16).EndInit();
		Avalonia.Controls.Controls children7 = stackPanel5.Children;
		OptionControl optionControl19;
		OptionControl optionControl18 = (optionControl19 = new OptionControl());
		((ISupportInitialize)optionControl18).BeginInit();
		children7.Add(optionControl18);
		OptionControl optionControl20 = (optionControl4 = optionControl19);
		context.PushParent(optionControl4);
		OptionControl optionControl21 = optionControl4;
		optionControl21.Header = Strings.Menu_FastFlags_Presets_PauseVoxelizer_Title;
		optionControl21.Description = Strings.Menu_FastFlags_Presets_PauseVoxelizer_Description;
		ToggleSwitch toggleSwitch15;
		ToggleSwitch toggleSwitch14 = (toggleSwitch15 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch14).BeginInit();
		optionControl21.InnerContent = toggleSwitch14;
		ToggleSwitch toggleSwitch16 = (toggleSwitch4 = toggleSwitch15);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch17 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty4 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EFastFlagsViewModel_002CMerostrap_002EPauseVoxelizer_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding6 = compiledBindingExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch17.Bind(isCheckedProperty4, binding6);
		context.PopParent();
		((ISupportInitialize)toggleSwitch16).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl20).EndInit();
		Avalonia.Controls.Controls children8 = stackPanel5.Children;
		OptionControl optionControl23;
		OptionControl optionControl22 = (optionControl23 = new OptionControl());
		((ISupportInitialize)optionControl22).BeginInit();
		children8.Add(optionControl22);
		OptionControl optionControl24 = (optionControl4 = optionControl23);
		context.PushParent(optionControl4);
		OptionControl optionControl25 = optionControl4;
		optionControl25.Header = Strings.Menu_FastFlags_Presets_GraySky_Title;
		optionControl25.Description = Strings.Menu_FastFlags_Presets_GraySky_Description;
		ToggleSwitch toggleSwitch19;
		ToggleSwitch toggleSwitch18 = (toggleSwitch19 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch18).BeginInit();
		optionControl25.InnerContent = toggleSwitch18;
		ToggleSwitch toggleSwitch20 = (toggleSwitch4 = toggleSwitch19);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch21 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty5 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EFastFlagsViewModel_002CMerostrap_002EGraySky_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding7 = compiledBindingExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch21.Bind(isCheckedProperty5, binding7);
		context.PopParent();
		((ISupportInitialize)toggleSwitch20).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl24).EndInit();
		Avalonia.Controls.Controls children9 = stackPanel5.Children;
		OptionControl optionControl27;
		OptionControl optionControl26 = (optionControl27 = new OptionControl());
		((ISupportInitialize)optionControl26).BeginInit();
		children9.Add(optionControl26);
		OptionControl optionControl28 = (optionControl4 = optionControl27);
		context.PushParent(optionControl4);
		OptionControl optionControl29 = optionControl4;
		optionControl29.Header = Strings.Menu_FastFlags_Presets_RemoveGrass_Title;
		optionControl29.Description = Strings.Menu_FastFlags_Presets_RemoveGrass_Description;
		ToggleSwitch toggleSwitch23;
		ToggleSwitch toggleSwitch22 = (toggleSwitch23 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch22).BeginInit();
		optionControl29.InnerContent = toggleSwitch22;
		ToggleSwitch toggleSwitch24 = (toggleSwitch4 = toggleSwitch23);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch25 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty6 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EFastFlagsViewModel_002CMerostrap_002ERemoveGrass_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding8 = compiledBindingExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch25.Bind(isCheckedProperty6, binding8);
		context.PopParent();
		((ISupportInitialize)toggleSwitch24).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl28).EndInit();
		Avalonia.Controls.Controls children10 = stackPanel5.Children;
		CardExpander cardExpander2;
		CardExpander cardExpander = (cardExpander2 = new CardExpander());
		((ISupportInitialize)cardExpander).BeginInit();
		children10.Add(cardExpander);
		CardExpander cardExpander4;
		CardExpander cardExpander3 = (cardExpander4 = cardExpander2);
		context.PushParent(cardExpander4);
		StyledProperty<bool> isExpandedProperty = CardExpander.IsExpandedProperty;
		CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension();
		compiledBindingExtension10.Path = new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EFastFlagsViewModel_002CMerostrap_002ELowPolyMeshesEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build();
		compiledBindingExtension10.Mode = BindingMode.OneWay;
		context.ProvideTargetProperty = CardExpander.IsExpandedProperty;
		CompiledBinding binding9 = compiledBindingExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		cardExpander4.Bind(isExpandedProperty, binding9);
		cardExpander4.Classes.Add("NoUserExpansion");
		cardExpander4.Header = Strings.Menu_FastFlags_Presets_LowPolyMeshes_Title;
		cardExpander4.Description = Strings.Menu_FastFlags_Presets_LowPolyMeshes_Description;
		ToggleSwitch toggleSwitch27;
		ToggleSwitch toggleSwitch26 = (toggleSwitch27 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch26).BeginInit();
		cardExpander4.HeaderContent = toggleSwitch26;
		ToggleSwitch toggleSwitch28 = (toggleSwitch4 = toggleSwitch27);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch29 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty7 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EFastFlagsViewModel_002CMerostrap_002ELowPolyMeshesEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding10 = compiledBindingExtension11.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch29.Bind(isCheckedProperty7, binding10);
		context.PopParent();
		((ISupportInitialize)toggleSwitch28).EndInit();
		StackPanel stackPanel7;
		StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
		((ISupportInitialize)stackPanel6).BeginInit();
		cardExpander4.Content = stackPanel6;
		StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
		context.PushParent(stackPanel4);
		StackPanel stackPanel9 = stackPanel4;
		stackPanel9.Margin = new Thickness(0.0, 8.0, 0.0, 0.0);
		stackPanel9.Spacing = 8.0;
		Avalonia.Controls.Controls children11 = stackPanel9.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children11.Add(textBlock);
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = textBlock2);
		context.PushParent(textBlock4);
		textBlock4.Padding = new Thickness(4.0, 4.0, 4.0, 4.0);
		textBlock4.Text = Strings.Menu_FastFlags_Presets_LowPolyMeshes_Information;
		textBlock4.FontSize = 13.0;
		StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("TextFillColorSecondaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding11 = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock4.Bind(foregroundProperty, binding11);
		textBlock4.TextAlignment = TextAlignment.Center;
		textBlock4.TextWrapping = TextWrapping.Wrap;
		context.PopParent();
		((ISupportInitialize)textBlock3).EndInit();
		Avalonia.Controls.Controls children12 = stackPanel9.Children;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		children12.Add(grid);
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 3;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid4.ColumnDefinitions = columnDefinitions;
		Avalonia.Controls.Controls children13 = grid4.Children;
		TextBlock textBlock6;
		TextBlock textBlock5 = (textBlock6 = new TextBlock());
		((ISupportInitialize)textBlock5).BeginInit();
		children13.Add(textBlock5);
		Grid.SetColumn(textBlock6, 0);
		textBlock6.Text = Strings.Common_Performance;
		textBlock6.FontSize = 13.0;
		textBlock6.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)textBlock6).EndInit();
		Avalonia.Controls.Controls children14 = grid4.Children;
		Slider slider2;
		Slider slider = (slider2 = new Slider());
		((ISupportInitialize)slider).BeginInit();
		children14.Add(slider);
		Slider slider4;
		Slider slider3 = (slider4 = slider2);
		context.PushParent(slider4);
		Grid.SetColumn(slider4, 1);
		slider4.Margin = new Thickness(12.0, 0.0, 12.0, 0.0);
		slider4.Minimum = 0.0;
		slider4.Maximum = 9.0;
		slider4.TickFrequency = 1.0;
		slider4.IsSnapToTickEnabled = true;
		StyledProperty<double> valueProperty = RangeBase.ValueProperty;
		CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EFastFlagsViewModel_002CMerostrap_002ELowPolyMeshesLevel_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = RangeBase.ValueProperty;
		CompiledBinding binding12 = compiledBindingExtension12.ProvideValue(context);
		context.ProvideTargetProperty = null;
		slider4.Bind(valueProperty, binding12);
		context.PopParent();
		((ISupportInitialize)slider3).EndInit();
		Avalonia.Controls.Controls children15 = grid4.Children;
		TextBlock textBlock8;
		TextBlock textBlock7 = (textBlock8 = new TextBlock());
		((ISupportInitialize)textBlock7).BeginInit();
		children15.Add(textBlock7);
		Grid.SetColumn(textBlock8, 2);
		textBlock8.Text = Strings.Common_Quality;
		textBlock8.FontSize = 13.0;
		textBlock8.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)textBlock8).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel8).EndInit();
		context.PopParent();
		((ISupportInitialize)cardExpander3).EndInit();
		Avalonia.Controls.Controls children16 = stackPanel5.Children;
		OptionControl optionControl31;
		OptionControl optionControl30 = (optionControl31 = new OptionControl());
		((ISupportInitialize)optionControl30).BeginInit();
		children16.Add(optionControl30);
		OptionControl optionControl32 = (optionControl4 = optionControl31);
		context.PushParent(optionControl4);
		OptionControl optionControl33 = optionControl4;
		optionControl33.Header = Strings.Menu_FastFlags_Presets_FixDisplayScaling_Title;
		optionControl33.Description = Strings.Menu_FastFlags_Presets_FixDisplayScaling_Description;
		optionControl33.HelpLink = "https://bloxstraplabs.com/wiki/features/engine-settings/#preserving-rendering-quality";
		ToggleSwitch toggleSwitch31;
		ToggleSwitch toggleSwitch30 = (toggleSwitch31 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch30).BeginInit();
		optionControl33.InnerContent = toggleSwitch30;
		ToggleSwitch toggleSwitch32 = (toggleSwitch4 = toggleSwitch31);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch33 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty8 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EFastFlagsViewModel_002CMerostrap_002EFixDisplayScaling_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding13 = compiledBindingExtension13.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch33.Bind(isCheckedProperty8, binding13);
		context.PopParent();
		((ISupportInitialize)toggleSwitch32).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl32).EndInit();
		Avalonia.Controls.Controls children17 = stackPanel5.Children;
		OptionControl optionControl35;
		OptionControl optionControl34 = (optionControl35 = new OptionControl());
		((ISupportInitialize)optionControl34).BeginInit();
		children17.Add(optionControl34);
		OptionControl optionControl36 = (optionControl4 = optionControl35);
		context.PushParent(optionControl4);
		OptionControl optionControl37 = optionControl4;
		optionControl37.Header = Strings.Menu_FastFlags_Presets_RenderingMode_Title;
		optionControl37.Description = Strings.Menu_FastFlags_Presets_RenderingMode_Description;
		ComboBox comboBox7;
		ComboBox comboBox6 = (comboBox7 = new ComboBox());
		((ISupportInitialize)comboBox6).BeginInit();
		optionControl37.InnerContent = comboBox6;
		ComboBox comboBox8 = (comboBox4 = comboBox7);
		context.PushParent(comboBox4);
		ComboBox comboBox9 = comboBox4;
		comboBox9.MinWidth = 200.0;
		comboBox9.Margin = new Thickness(0.0, 0.0, 0.0, 0.0);
		comboBox9.Padding = new Thickness(10.0, 5.0, 10.0, 5.0);
		StyledProperty<IEnumerable?> itemsSourceProperty2 = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EFastFlagsViewModel_002CMerostrap_002ERenderingModeOptions_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.OneTime
		};
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding14 = compiledBindingExtension14.ProvideValue(context);
		context.ProvideTargetProperty = null;
		comboBox9.Bind(itemsSourceProperty2, binding14);
		CompiledBindingExtension compiledBindingExtension15 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EFastFlagsViewModel_002CMerostrap_002ESelectedRenderingModeItem_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = SelectingItemsControl.SelectedItemProperty;
		CompiledBinding compiledBinding2 = compiledBindingExtension15.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_10(comboBox9, compiledBinding2);
		DataTemplate itemTemplate2 = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_40.Build_2), context);
		context.PopParent();
		comboBox9.ItemTemplate = itemTemplate2;
		context.PopParent();
		((ISupportInitialize)comboBox8).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl36).EndInit();
		Avalonia.Controls.Controls children18 = stackPanel5.Children;
		OptionControl optionControl39;
		OptionControl optionControl38 = (optionControl39 = new OptionControl());
		((ISupportInitialize)optionControl38).BeginInit();
		children18.Add(optionControl38);
		OptionControl optionControl40 = (optionControl4 = optionControl39);
		context.PushParent(optionControl4);
		OptionControl optionControl41 = optionControl4;
		optionControl41.Header = Strings.Menu_FastFlags_Presets_OverrideGraphicQuality_Title;
		optionControl41.Description = Strings.Menu_FastFlags_Presets_OverrideGraphicQuality_Description;
		ComboBox comboBox11;
		ComboBox comboBox10 = (comboBox11 = new ComboBox());
		((ISupportInitialize)comboBox10).BeginInit();
		optionControl41.InnerContent = comboBox10;
		ComboBox comboBox12 = (comboBox4 = comboBox11);
		context.PushParent(comboBox4);
		ComboBox comboBox13 = comboBox4;
		comboBox13.MinWidth = 200.0;
		comboBox13.Margin = new Thickness(0.0, 0.0, 0.0, 0.0);
		comboBox13.Padding = new Thickness(10.0, 5.0, 10.0, 5.0);
		StyledProperty<IEnumerable?> itemsSourceProperty3 = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension16 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EFastFlagsViewModel_002CMerostrap_002EQualityLevels_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.System_002ECollections_002EGeneric_002EIReadOnlyDictionary_00602_002CSystem_002ERuntime_002EKeys_41_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.OneTime
		};
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding15 = compiledBindingExtension16.ProvideValue(context);
		context.ProvideTargetProperty = null;
		comboBox13.Bind(itemsSourceProperty3, binding15);
		CompiledBindingExtension compiledBindingExtension17 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EFastFlagsViewModel_002CMerostrap_002ESelectedQualityLevel_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = SelectingItemsControl.SelectedItemProperty;
		CompiledBinding compiledBinding3 = compiledBindingExtension17.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_10(comboBox13, compiledBinding3);
		DataTemplate itemTemplate3 = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_40.Build_3), context);
		context.PopParent();
		comboBox13.ItemTemplate = itemTemplate3;
		context.PopParent();
		((ISupportInitialize)comboBox12).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl40).EndInit();
		Avalonia.Controls.Controls children19 = stackPanel5.Children;
		OptionControl optionControl43;
		OptionControl optionControl42 = (optionControl43 = new OptionControl());
		((ISupportInitialize)optionControl42).BeginInit();
		children19.Add(optionControl42);
		OptionControl optionControl44 = (optionControl4 = optionControl43);
		context.PushParent(optionControl4);
		OptionControl optionControl45 = optionControl4;
		optionControl45.Header = Strings.Menu_FastFlags_Presets_TextureQuality_Title;
		optionControl45.Description = Strings.Menu_FastFlags_Presets_TextureQuality_Description;
		ComboBox comboBox15;
		ComboBox comboBox14 = (comboBox15 = new ComboBox());
		((ISupportInitialize)comboBox14).BeginInit();
		optionControl45.InnerContent = comboBox14;
		ComboBox comboBox16 = (comboBox4 = comboBox15);
		context.PushParent(comboBox4);
		ComboBox comboBox17 = comboBox4;
		comboBox17.Width = 200.0;
		comboBox17.Margin = new Thickness(5.0, 0.0, 0.0, 0.0);
		comboBox17.Padding = new Thickness(10.0, 5.0, 10.0, 5.0);
		StyledProperty<IEnumerable?> itemsSourceProperty4 = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension18 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EFastFlagsViewModel_002CMerostrap_002ETextureQualities_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.System_002ECollections_002EGeneric_002EIReadOnlyDictionary_00602_002CSystem_002ERuntime_002EKeys_42_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.OneTime
		};
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding16 = compiledBindingExtension18.ProvideValue(context);
		context.ProvideTargetProperty = null;
		comboBox17.Bind(itemsSourceProperty4, binding16);
		CompiledBindingExtension compiledBindingExtension19 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EFastFlagsViewModel_002CMerostrap_002ESelectedTextureQuality_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = SelectingItemsControl.SelectedItemProperty;
		CompiledBinding compiledBinding4 = compiledBindingExtension19.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_10(comboBox17, compiledBinding4);
		DataTemplate itemTemplate4 = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_40.Build_4), context);
		context.PopParent();
		comboBox17.ItemTemplate = itemTemplate4;
		context.PopParent();
		((ISupportInitialize)comboBox16).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl44).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(FastFlagsPage P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
