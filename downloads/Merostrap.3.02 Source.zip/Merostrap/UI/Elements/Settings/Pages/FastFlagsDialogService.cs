using System;
using System.Threading.Tasks;
using Merostrap.UI.ViewModels.Settings;

namespace Merostrap.UI.Elements.Settings.Pages;

internal class FastFlagsDialogService(MainWindowViewModel mainVm) : IDialogService
{
	private readonly MainWindowViewModel _mainVm = mainVm ?? throw new ArgumentNullException("mainVm");

	public Task OpenFastFlagEditorAsync()
	{
		_mainVm.NavigateToFastFlagEditorCommand.Execute(null);
		return Task.CompletedTask;
	}
}
