using System;
using Merostrap.UI.ViewModels.Settings;

namespace Merostrap.UI.Elements.Settings.Pages;

internal class PresetModsDialogService(MainWindowViewModel mainVm)
{
	private readonly MainWindowViewModel _mainVm = mainVm ?? throw new ArgumentNullException("mainVm");

	public void OpenCommunityMods()
	{
		_mainVm.NavigateToCommunityModsCommand.Execute(null);
	}

	public void OpenMods()
	{
		_mainVm.NavigateToMyModsCommand.Execute(null);
	}

	public void OpenModGenerator()
	{
		_mainVm.NavigateToModGeneratorCommand.Execute(null);
	}
}
