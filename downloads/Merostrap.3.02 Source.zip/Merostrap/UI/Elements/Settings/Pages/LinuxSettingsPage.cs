using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using CompiledAvaloniaXaml;
using LucideAvalonia.Enum;
using Merostrap.Resources;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.ViewModels;

namespace Merostrap.UI.Elements.Settings.Pages;

internal class LinuxSettingsPage : UserControl
{
	[CompilerGenerated]
	private class XamlClosure_48
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<LinuxSettingsPage> context = CreateContext(P_0);
			context.IntermediateRoot = new StackPanel();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			StackPanel stackPanel = (StackPanel)obj;
			context.PushParent(stackPanel);
			stackPanel.Orientation = Orientation.Horizontal;
			stackPanel.Spacing = 4.0;
			stackPanel.Margin = new Thickness(0.0, 2.0, 0.0, 2.0);
			Avalonia.Controls.Controls children = stackPanel.Children;
			TextBox textBox2;
			TextBox textBox = (textBox2 = new TextBox());
			((ISupportInitialize)textBox).BeginInit();
			children.Add(textBox);
			TextBox textBox4;
			TextBox textBox3 = (textBox4 = textBox2);
			context.PushParent(textBox4);
			TextBox textBox5 = textBox4;
			StyledProperty<string?> textProperty = TextBox.TextProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers._002EEnvEntry_002CMerostrap_002EKey_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
			{
				UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
			};
			context.ProvideTargetProperty = TextBox.TextProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBox5.Bind(textProperty, binding);
			textBox5.Width = 150.0;
			textBox5.PlaceholderText = Strings.Menu_LinuxSettings_Variable;
			textBox5.Padding = new Thickness(8.0, 5.0, 8.0, 5.0);
			context.PopParent();
			((ISupportInitialize)textBox3).EndInit();
			Avalonia.Controls.Controls children2 = stackPanel.Children;
			TextBox textBox7;
			TextBox textBox6 = (textBox7 = new TextBox());
			((ISupportInitialize)textBox6).BeginInit();
			children2.Add(textBox6);
			TextBox textBox8 = (textBox4 = textBox7);
			context.PushParent(textBox4);
			TextBox textBox9 = textBox4;
			StyledProperty<string?> textProperty2 = TextBox.TextProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers._002EEnvEntry_002CMerostrap_002EValue_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
			{
				UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
			};
			context.ProvideTargetProperty = TextBox.TextProperty;
			CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBox9.Bind(textProperty2, binding2);
			textBox9.Width = 200.0;
			textBox9.PlaceholderText = Strings.Common_Value;
			textBox9.Padding = new Thickness(8.0, 5.0, 8.0, 5.0);
			context.PopParent();
			((ISupportInitialize)textBox8).EndInit();
			Avalonia.Controls.Controls children3 = stackPanel.Children;
			IconButton iconButton2;
			IconButton iconButton = (iconButton2 = new IconButton());
			((ISupportInitialize)iconButton).BeginInit();
			children3.Add(iconButton);
			IconButton iconButton4;
			IconButton iconButton3 = (iconButton4 = iconButton2);
			context.PushParent(iconButton4);
			iconButton4.Icon = LucideIconNames.Trash2;
			iconButton4.Classes.Add("Danger");
			StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers._002EEnvEntry_002CMerostrap_002ERemoveCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Button.CommandProperty;
			CompiledBinding binding3 = compiledBindingExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			iconButton4.Bind(commandProperty, binding3);
			iconButton4.Width = 30.0;
			iconButton4.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
			ToolTip.SetTip(iconButton4, Strings.Common_Remove);
			context.PopParent();
			((ISupportInitialize)iconButton3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<LinuxSettingsPage> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<LinuxSettingsPage> context = new XamlIlContext.Context<LinuxSettingsPage>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FPages_002FLinuxSettingsPage_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/Pages/LinuxSettingsPage.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (LinuxSettingsPage)service;
				}
			}
			return context;
		}
	}

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public LinuxSettingsPage()
	{
		InitializeComponent();
		App.FrostRPC?.SetPage("Sober Settings");
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, LinuxSettingsPage P_1)
	{
		XamlIlContext.Context<LinuxSettingsPage> context = new XamlIlContext.Context<LinuxSettingsPage>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FPages_002FLinuxSettingsPage_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/Pages/LinuxSettingsPage.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		P_1.Content = scrollViewer;
		ScrollViewer scrollViewer4;
		ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
		context.PushParent(scrollViewer4);
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		scrollViewer4.Content = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		StackPanel stackPanel5 = stackPanel4;
		stackPanel5.Margin = new Thickness(14.0, 14.0, 14.0, 14.0);
		Avalonia.Controls.Controls children = stackPanel5.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children.Add(textBlock);
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = textBlock2);
		context.PushParent(textBlock4);
		textBlock4.Margin = new Thickness(0.0, 8.0, 0.0, 0.0);
		textBlock4.FontSize = 20.0;
		textBlock4.FontWeight = FontWeight.Bold;
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002ESoberEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock4.Bind(isVisibleProperty, binding);
		textBlock4.Text = Strings.Common_Sober;
		context.PopParent();
		((ISupportInitialize)textBlock3).EndInit();
		Avalonia.Controls.Controls children2 = stackPanel5.Children;
		OptionControl optionControl2;
		OptionControl optionControl = (optionControl2 = new OptionControl());
		((ISupportInitialize)optionControl).BeginInit();
		children2.Add(optionControl);
		OptionControl optionControl4;
		OptionControl optionControl3 = (optionControl4 = optionControl2);
		context.PushParent(optionControl4);
		OptionControl optionControl5 = optionControl4;
		optionControl5.Header = Strings.Menu_LinuxSettings_AllowGamepadPermission_Title;
		StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002ESoberEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		optionControl5.Bind(isVisibleProperty2, binding2);
		optionControl5.Description = Strings.Menu_LinuxSettings_AllowGamepadPermission_Description;
		ToggleSwitch toggleSwitch2;
		ToggleSwitch toggleSwitch = (toggleSwitch2 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch).BeginInit();
		optionControl5.InnerContent = toggleSwitch;
		ToggleSwitch toggleSwitch4;
		ToggleSwitch toggleSwitch3 = (toggleSwitch4 = toggleSwitch2);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch5 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002ESoberAllowGamepadPermission_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding3 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch5.Bind(isCheckedProperty, binding3);
		context.PopParent();
		((ISupportInitialize)toggleSwitch3).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl3).EndInit();
		Avalonia.Controls.Controls children3 = stackPanel5.Children;
		OptionControl optionControl7;
		OptionControl optionControl6 = (optionControl7 = new OptionControl());
		((ISupportInitialize)optionControl6).BeginInit();
		children3.Add(optionControl6);
		OptionControl optionControl8 = (optionControl4 = optionControl7);
		context.PushParent(optionControl4);
		OptionControl optionControl9 = optionControl4;
		optionControl9.Header = Strings.Menu_LinuxSettings_EnableGameMode_Title;
		StyledProperty<bool> isVisibleProperty3 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002ESoberEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding4 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		optionControl9.Bind(isVisibleProperty3, binding4);
		optionControl9.Description = Strings.Menu_LinuxSettings_EnableGameMode_Description;
		ToggleSwitch toggleSwitch7;
		ToggleSwitch toggleSwitch6 = (toggleSwitch7 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch6).BeginInit();
		optionControl9.InnerContent = toggleSwitch6;
		ToggleSwitch toggleSwitch8 = (toggleSwitch4 = toggleSwitch7);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch9 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty2 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002ESoberEnableGamemode_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding5 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch9.Bind(isCheckedProperty2, binding5);
		context.PopParent();
		((ISupportInitialize)toggleSwitch8).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl8).EndInit();
		Avalonia.Controls.Controls children4 = stackPanel5.Children;
		OptionControl optionControl11;
		OptionControl optionControl10 = (optionControl11 = new OptionControl());
		((ISupportInitialize)optionControl10).BeginInit();
		children4.Add(optionControl10);
		OptionControl optionControl12 = (optionControl4 = optionControl11);
		context.PushParent(optionControl4);
		OptionControl optionControl13 = optionControl4;
		optionControl13.Header = Strings.Menu_LinuxSettings_EnableHiDpi_Title;
		StyledProperty<bool> isVisibleProperty4 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002ESoberEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding6 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		optionControl13.Bind(isVisibleProperty4, binding6);
		optionControl13.Description = Strings.Menu_LinuxSettings_EnableHiDpi_Description;
		ToggleSwitch toggleSwitch11;
		ToggleSwitch toggleSwitch10 = (toggleSwitch11 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch10).BeginInit();
		optionControl13.InnerContent = toggleSwitch10;
		ToggleSwitch toggleSwitch12 = (toggleSwitch4 = toggleSwitch11);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch13 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty3 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002ESoberEnableHiDpi_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding7 = compiledBindingExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch13.Bind(isCheckedProperty3, binding7);
		context.PopParent();
		((ISupportInitialize)toggleSwitch12).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl12).EndInit();
		Avalonia.Controls.Controls children5 = stackPanel5.Children;
		OptionControl optionControl15;
		OptionControl optionControl14 = (optionControl15 = new OptionControl());
		((ISupportInitialize)optionControl14).BeginInit();
		children5.Add(optionControl14);
		OptionControl optionControl16 = (optionControl4 = optionControl15);
		context.PushParent(optionControl4);
		OptionControl optionControl17 = optionControl4;
		optionControl17.Header = Strings.Menu_LinuxSettings_TouchInputMode_Title;
		StyledProperty<bool> isVisibleProperty5 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002ESoberEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding8 = compiledBindingExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		optionControl17.Bind(isVisibleProperty5, binding8);
		optionControl17.Description = Strings.Menu_LinuxSettings_TouchInputMode_Description;
		ToggleSwitch toggleSwitch15;
		ToggleSwitch toggleSwitch14 = (toggleSwitch15 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch14).BeginInit();
		optionControl17.InnerContent = toggleSwitch14;
		ToggleSwitch toggleSwitch16 = (toggleSwitch4 = toggleSwitch15);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch17 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty4 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002ESoberTouchMode_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding9 = compiledBindingExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch17.Bind(isCheckedProperty4, binding9);
		context.PopParent();
		((ISupportInitialize)toggleSwitch16).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl16).EndInit();
		Avalonia.Controls.Controls children6 = stackPanel5.Children;
		OptionControl optionControl19;
		OptionControl optionControl18 = (optionControl19 = new OptionControl());
		((ISupportInitialize)optionControl18).BeginInit();
		children6.Add(optionControl18);
		OptionControl optionControl20 = (optionControl4 = optionControl19);
		context.PushParent(optionControl4);
		OptionControl optionControl21 = optionControl4;
		optionControl21.Header = Strings.Menu_LinuxSettings_UseConsoleExperience_Title;
		StyledProperty<bool> isVisibleProperty6 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002ESoberEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding10 = compiledBindingExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		optionControl21.Bind(isVisibleProperty6, binding10);
		optionControl21.Description = Strings.Menu_LinuxSettings_UseConsoleExperience_Description;
		ToggleSwitch toggleSwitch19;
		ToggleSwitch toggleSwitch18 = (toggleSwitch19 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch18).BeginInit();
		optionControl21.InnerContent = toggleSwitch18;
		ToggleSwitch toggleSwitch20 = (toggleSwitch4 = toggleSwitch19);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch21 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty5 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002ESoberUseConsoleExperience_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding11 = compiledBindingExtension11.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch21.Bind(isCheckedProperty5, binding11);
		context.PopParent();
		((ISupportInitialize)toggleSwitch20).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl20).EndInit();
		Avalonia.Controls.Controls children7 = stackPanel5.Children;
		OptionControl optionControl23;
		OptionControl optionControl22 = (optionControl23 = new OptionControl());
		((ISupportInitialize)optionControl22).BeginInit();
		children7.Add(optionControl22);
		OptionControl optionControl24 = (optionControl4 = optionControl23);
		context.PushParent(optionControl4);
		OptionControl optionControl25 = optionControl4;
		optionControl25.Header = Strings.Menu_LinuxSettings_ForceLegacyOpenGL_Title;
		StyledProperty<bool> isVisibleProperty7 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002ESoberEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding12 = compiledBindingExtension12.ProvideValue(context);
		context.ProvideTargetProperty = null;
		optionControl25.Bind(isVisibleProperty7, binding12);
		optionControl25.Description = Strings.Menu_LinuxSettings_ForceLegacyOpenGL_Description;
		ToggleSwitch toggleSwitch23;
		ToggleSwitch toggleSwitch22 = (toggleSwitch23 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch22).BeginInit();
		optionControl25.InnerContent = toggleSwitch22;
		ToggleSwitch toggleSwitch24 = (toggleSwitch4 = toggleSwitch23);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch25 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty6 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002ESoberUseOpengl_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding13 = compiledBindingExtension13.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch25.Bind(isCheckedProperty6, binding13);
		context.PopParent();
		((ISupportInitialize)toggleSwitch24).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl24).EndInit();
		Avalonia.Controls.Controls children8 = stackPanel5.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children8.Add(border);
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		border4.Height = 12.0;
		StyledProperty<bool> isVisibleProperty8 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002ESoberEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding14 = compiledBindingExtension14.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border4.Bind(isVisibleProperty8, binding14);
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		Avalonia.Controls.Controls children9 = stackPanel5.Children;
		TextBlock textBlock6;
		TextBlock textBlock5 = (textBlock6 = new TextBlock());
		((ISupportInitialize)textBlock5).BeginInit();
		children9.Add(textBlock5);
		textBlock6.Margin = new Thickness(0.0, 8.0, 0.0, 0.0);
		textBlock6.IsVisible = GlobalViewModel.IsLinux;
		textBlock6.FontSize = 20.0;
		textBlock6.FontWeight = FontWeight.Bold;
		textBlock6.Text = Strings.Common_Studio;
		((ISupportInitialize)textBlock6).EndInit();
		Avalonia.Controls.Controls children10 = stackPanel5.Children;
		CardAction cardAction2;
		CardAction cardAction = (cardAction2 = new CardAction());
		((ISupportInitialize)cardAction).BeginInit();
		children10.Add(cardAction);
		CardAction cardAction4;
		CardAction cardAction3 = (cardAction4 = cardAction2);
		context.PushParent(cardAction4);
		cardAction4.Icon = LucideIconNames.Settings;
		cardAction4.Header = Strings.Menu_LinuxSettings_AdvancedWineSettings;
		StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension15 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002EOpenWineCfgCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding15 = compiledBindingExtension15.ProvideValue(context);
		context.ProvideTargetProperty = null;
		cardAction4.Bind(commandProperty, binding15);
		StyledProperty<bool> isVisibleProperty9 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension16 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002EIsWineAvailable_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding16 = compiledBindingExtension16.ProvideValue(context);
		context.ProvideTargetProperty = null;
		cardAction4.Bind(isVisibleProperty9, binding16);
		context.PopParent();
		((ISupportInitialize)cardAction3).EndInit();
		Avalonia.Controls.Controls children11 = stackPanel5.Children;
		OptionControl optionControl27;
		OptionControl optionControl26 = (optionControl27 = new OptionControl());
		((ISupportInitialize)optionControl26).BeginInit();
		children11.Add(optionControl26);
		OptionControl optionControl28 = (optionControl4 = optionControl27);
		context.PushParent(optionControl4);
		OptionControl optionControl29 = optionControl4;
		optionControl29.IsVisible = GlobalViewModel.IsLinux;
		optionControl29.Header = Strings.Menu_LinuxSettings_WebPages_Title;
		optionControl29.Description = Strings.Menu_LinuxSettings_WebPages_Description;
		ToggleSwitch toggleSwitch27;
		ToggleSwitch toggleSwitch26 = (toggleSwitch27 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch26).BeginInit();
		optionControl29.InnerContent = toggleSwitch26;
		ToggleSwitch toggleSwitch28 = (toggleSwitch4 = toggleSwitch27);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch29 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty7 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension17 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002EEnableWebView2_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding17 = compiledBindingExtension17.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch29.Bind(isCheckedProperty7, binding17);
		context.PopParent();
		((ISupportInitialize)toggleSwitch28).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl28).EndInit();
		Avalonia.Controls.Controls children12 = stackPanel5.Children;
		OptionControl optionControl31;
		OptionControl optionControl30 = (optionControl31 = new OptionControl());
		((ISupportInitialize)optionControl30).BeginInit();
		children12.Add(optionControl30);
		OptionControl optionControl32 = (optionControl4 = optionControl31);
		context.PushParent(optionControl4);
		OptionControl optionControl33 = optionControl4;
		optionControl33.IsVisible = GlobalViewModel.IsLinux;
		optionControl33.Header = Strings.Menu_LinuxSettings_GraphicsRenderer_Title;
		optionControl33.Description = Strings.Menu_LinuxSettings_GraphicsRenderer_Description;
		ComboBox comboBox2;
		ComboBox comboBox = (comboBox2 = new ComboBox());
		((ISupportInitialize)comboBox).BeginInit();
		optionControl33.InnerContent = comboBox;
		ComboBox comboBox4;
		ComboBox comboBox3 = (comboBox4 = comboBox2);
		context.PushParent(comboBox4);
		comboBox4.Width = 200.0;
		StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension18 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002EStudioRendererOptions_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.OneTime
		};
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding18 = compiledBindingExtension18.ProvideValue(context);
		context.ProvideTargetProperty = null;
		comboBox4.Bind(itemsSourceProperty, binding18);
		CompiledBindingExtension compiledBindingExtension19 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002ESelectedStudioRenderer_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = SelectingItemsControl.SelectedItemProperty;
		CompiledBinding compiledBinding = compiledBindingExtension19.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_10(comboBox4, compiledBinding);
		context.PopParent();
		((ISupportInitialize)comboBox3).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl32).EndInit();
		Avalonia.Controls.Controls children13 = stackPanel5.Children;
		CardExpander cardExpander2;
		CardExpander cardExpander = (cardExpander2 = new CardExpander());
		((ISupportInitialize)cardExpander).BeginInit();
		children13.Add(cardExpander);
		CardExpander cardExpander4;
		CardExpander cardExpander3 = (cardExpander4 = cardExpander2);
		context.PushParent(cardExpander4);
		cardExpander4.IsVisible = GlobalViewModel.IsLinux;
		cardExpander4.Header = Strings.Menu_LinuxSettings_VirtualDesktops_Title;
		cardExpander4.Classes.Add("NoUserExpansion");
		cardExpander4.Description = Strings.Menu_LinuxSettings_VirtualDesktops_Description;
		StyledProperty<bool> isExpandedProperty = CardExpander.IsExpandedProperty;
		CompiledBindingExtension compiledBindingExtension20 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002EVirtualDesktopEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.OneWay
		};
		context.ProvideTargetProperty = CardExpander.IsExpandedProperty;
		CompiledBinding binding19 = compiledBindingExtension20.ProvideValue(context);
		context.ProvideTargetProperty = null;
		cardExpander4.Bind(isExpandedProperty, binding19);
		ToggleSwitch toggleSwitch31;
		ToggleSwitch toggleSwitch30 = (toggleSwitch31 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch30).BeginInit();
		cardExpander4.HeaderContent = toggleSwitch30;
		ToggleSwitch toggleSwitch32 = (toggleSwitch4 = toggleSwitch31);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch33 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty8 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension21 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002EVirtualDesktopEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding20 = compiledBindingExtension21.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch33.Bind(isCheckedProperty8, binding20);
		context.PopParent();
		((ISupportInitialize)toggleSwitch32).EndInit();
		StackPanel stackPanel7;
		StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
		((ISupportInitialize)stackPanel6).BeginInit();
		cardExpander4.Content = stackPanel6;
		StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
		context.PushParent(stackPanel4);
		StackPanel stackPanel9 = stackPanel4;
		stackPanel9.Spacing = 4.0;
		Avalonia.Controls.Controls children14 = stackPanel9.Children;
		TextBox textBox2;
		TextBox textBox = (textBox2 = new TextBox());
		((ISupportInitialize)textBox).BeginInit();
		children14.Add(textBox);
		TextBox textBox4;
		TextBox textBox3 = (textBox4 = textBox2);
		context.PushParent(textBox4);
		TextBox textBox5 = textBox4;
		StyledProperty<string?> textProperty = TextBox.TextProperty;
		CompiledBindingExtension compiledBindingExtension22 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002EVirtualDesktopResolution_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = TextBox.TextProperty;
		CompiledBinding binding21 = compiledBindingExtension22.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBox5.Bind(textProperty, binding21);
		StyledProperty<bool> isEnabledProperty = InputElement.IsEnabledProperty;
		CompiledBindingExtension compiledBindingExtension23 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002EVirtualDesktopEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = InputElement.IsEnabledProperty;
		CompiledBinding binding22 = compiledBindingExtension23.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBox5.Bind(isEnabledProperty, binding22);
		textBox5.PlaceholderText = Strings.Menu_LinuxSettings_ResolutionPlaceholder;
		context.PopParent();
		((ISupportInitialize)textBox3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel8).EndInit();
		context.PopParent();
		((ISupportInitialize)cardExpander3).EndInit();
		Avalonia.Controls.Controls children15 = stackPanel5.Children;
		OptionControl optionControl35;
		OptionControl optionControl34 = (optionControl35 = new OptionControl());
		((ISupportInitialize)optionControl34).BeginInit();
		children15.Add(optionControl34);
		OptionControl optionControl36 = (optionControl4 = optionControl35);
		context.PushParent(optionControl4);
		OptionControl optionControl37 = optionControl4;
		optionControl37.IsVisible = GlobalViewModel.IsLinux;
		optionControl37.Header = Strings.Menu_LinuxSettings_LauncherCommand_Title;
		optionControl37.Description = Strings.Menu_LinuxSettings_LauncherCommand_Description;
		TextBox textBox7;
		TextBox textBox6 = (textBox7 = new TextBox());
		((ISupportInitialize)textBox6).BeginInit();
		optionControl37.InnerContent = textBox6;
		TextBox textBox8 = (textBox4 = textBox7);
		context.PushParent(textBox4);
		TextBox textBox9 = textBox4;
		StyledProperty<string?> textProperty2 = TextBox.TextProperty;
		CompiledBindingExtension compiledBindingExtension24 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002EStudioLauncher_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = TextBox.TextProperty;
		CompiledBinding binding23 = compiledBindingExtension24.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBox9.Bind(textProperty2, binding23);
		textBox9.PlaceholderText = Strings.Menu_LinuxSettings_LauncherPlaceholder;
		context.PopParent();
		((ISupportInitialize)textBox8).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl36).EndInit();
		Avalonia.Controls.Controls children16 = stackPanel5.Children;
		OptionControl optionControl39;
		OptionControl optionControl38 = (optionControl39 = new OptionControl());
		((ISupportInitialize)optionControl38).BeginInit();
		children16.Add(optionControl38);
		OptionControl optionControl40 = (optionControl4 = optionControl39);
		context.PushParent(optionControl4);
		OptionControl optionControl41 = optionControl4;
		optionControl41.IsVisible = GlobalViewModel.IsLinux;
		optionControl41.Header = Strings.Menu_LinuxSettings_GameMode_Title;
		optionControl41.Description = Strings.Menu_LinuxSettings_GameMode_Description;
		ToggleSwitch toggleSwitch35;
		ToggleSwitch toggleSwitch34 = (toggleSwitch35 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch34).BeginInit();
		optionControl41.InnerContent = toggleSwitch34;
		ToggleSwitch toggleSwitch36 = (toggleSwitch4 = toggleSwitch35);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch37 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty9 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension25 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002EStudioGameMode_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding24 = compiledBindingExtension25.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch37.Bind(isCheckedProperty9, binding24);
		context.PopParent();
		((ISupportInitialize)toggleSwitch36).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl40).EndInit();
		Avalonia.Controls.Controls children17 = stackPanel5.Children;
		OptionControl optionControl43;
		OptionControl optionControl42 = (optionControl43 = new OptionControl());
		((ISupportInitialize)optionControl42).BeginInit();
		children17.Add(optionControl42);
		OptionControl optionControl44 = (optionControl4 = optionControl43);
		context.PushParent(optionControl4);
		OptionControl optionControl45 = optionControl4;
		optionControl45.IsVisible = GlobalViewModel.IsLinux;
		optionControl45.Header = Strings.Menu_LinuxSettings_DebugMode_Title;
		optionControl45.Description = Strings.Menu_LinuxSettings_DebugMode_Description;
		ToggleSwitch toggleSwitch39;
		ToggleSwitch toggleSwitch38 = (toggleSwitch39 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch38).BeginInit();
		optionControl45.InnerContent = toggleSwitch38;
		ToggleSwitch toggleSwitch40 = (toggleSwitch4 = toggleSwitch39);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch41 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty10 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension26 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002EStudioDebug_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding25 = compiledBindingExtension26.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch41.Bind(isCheckedProperty10, binding25);
		context.PopParent();
		((ISupportInitialize)toggleSwitch40).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl44).EndInit();
		Avalonia.Controls.Controls children18 = stackPanel5.Children;
		OptionControl optionControl47;
		OptionControl optionControl46 = (optionControl47 = new OptionControl());
		((ISupportInitialize)optionControl46).BeginInit();
		children18.Add(optionControl46);
		OptionControl optionControl48 = (optionControl4 = optionControl47);
		context.PushParent(optionControl4);
		OptionControl optionControl49 = optionControl4;
		optionControl49.IsVisible = GlobalViewModel.IsLinux;
		optionControl49.Header = Strings.Menu_LinuxSettings_EnvironmentVariables_Title;
		optionControl49.Description = Strings.Menu_LinuxSettings_EnvironmentVariables_Description;
		StackPanel stackPanel11;
		StackPanel stackPanel10 = (stackPanel11 = new StackPanel());
		((ISupportInitialize)stackPanel10).BeginInit();
		optionControl49.InnerContent = stackPanel10;
		StackPanel stackPanel12 = (stackPanel4 = stackPanel11);
		context.PushParent(stackPanel4);
		StackPanel stackPanel13 = stackPanel4;
		stackPanel13.Spacing = 8.0;
		Avalonia.Controls.Controls children19 = stackPanel13.Children;
		ItemsControl itemsControl2;
		ItemsControl itemsControl = (itemsControl2 = new ItemsControl());
		((ISupportInitialize)itemsControl).BeginInit();
		children19.Add(itemsControl);
		ItemsControl itemsControl4;
		ItemsControl itemsControl3 = (itemsControl4 = itemsControl2);
		context.PushParent(itemsControl4);
		StyledProperty<IEnumerable?> itemsSourceProperty2 = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension27 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002EStudioEnvEntries_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding26 = compiledBindingExtension27.ProvideValue(context);
		context.ProvideTargetProperty = null;
		itemsControl4.Bind(itemsSourceProperty2, binding26);
		DataTemplate dataTemplate;
		DataTemplate itemTemplate = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_48.Build_1), context);
		context.PopParent();
		itemsControl4.ItemTemplate = itemTemplate;
		context.PopParent();
		((ISupportInitialize)itemsControl3).EndInit();
		Avalonia.Controls.Controls children20 = stackPanel13.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children20.Add(button);
		Button button4;
		Button button3 = (button4 = button2);
		context.PushParent(button4);
		button4.Content = Strings.Menu_LinuxSettings_AddVariable;
		StyledProperty<ICommand?> commandProperty2 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension28 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ELinuxSettingsViewModel_002CMerostrap_002EAddStudioEnvCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding27 = compiledBindingExtension28.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button4.Bind(commandProperty2, binding27);
		button4.HorizontalAlignment = HorizontalAlignment.Left;
		button4.Margin = new Thickness(0.0, 4.0, 0.0, 0.0);
		context.PopParent();
		((ISupportInitialize)button3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel12).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl48).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(LinuxSettingsPage P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
