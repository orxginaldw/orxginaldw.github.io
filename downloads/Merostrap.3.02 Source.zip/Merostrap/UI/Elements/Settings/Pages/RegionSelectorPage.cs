using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Styling;
using CompiledAvaloniaXaml;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.UI.ViewModels.Settings;

namespace Merostrap.UI.Elements.Settings.Pages;

internal class RegionSelectorPage : UserControl
{
	[CompilerGenerated]
	private class XamlClosure_57
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<RegionSelectorPage> context = CreateContext(P_0);
			context.IntermediateRoot = new Grid();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Grid grid = (Grid)obj;
			context.PushParent(grid);
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 3;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(24.0, GridUnitType.Pixel)));
			grid.ColumnDefinitions = columnDefinitions;
			grid.MinWidth = 260.0;
			grid.VerticalAlignment = VerticalAlignment.Center;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ERegionChoice_002CMerostrap_002ETooltip_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = ToolTip.TipProperty;
			CompiledBinding compiledBinding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_11((ToolTip)(object)grid, compiledBinding);
			Avalonia.Controls.Controls children = grid.Children;
			TextBlock textBlock2;
			TextBlock textBlock = (textBlock2 = new TextBlock());
			((ISupportInitialize)textBlock).BeginInit();
			children.Add(textBlock);
			TextBlock textBlock4;
			TextBlock textBlock3 = (textBlock4 = textBlock2);
			context.PushParent(textBlock4);
			TextBlock textBlock5 = textBlock4;
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ERegionChoice_002CMerostrap_002EName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock5.Bind(textProperty, binding);
			textBlock5.TextTrimming = TextTrimming.CharacterEllipsis;
			textBlock5.VerticalAlignment = VerticalAlignment.Center;
			textBlock5.Margin = new Thickness(0.0, 0.0, 16.0, 0.0);
			context.PopParent();
			((ISupportInitialize)textBlock3).EndInit();
			Avalonia.Controls.Controls children2 = grid.Children;
			TextBlock textBlock7;
			TextBlock textBlock6 = (textBlock7 = new TextBlock());
			((ISupportInitialize)textBlock6).BeginInit();
			children2.Add(textBlock6);
			TextBlock textBlock8 = (textBlock4 = textBlock7);
			context.PushParent(textBlock4);
			TextBlock textBlock9 = textBlock4;
			Grid.SetColumn(textBlock9, 1);
			StyledProperty<string?> textProperty2 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ERegionChoice_002CMerostrap_002ELatencyText_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding2 = compiledBindingExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock9.Bind(textProperty2, binding2);
			StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ERegionChoice_002CMerostrap_002EShowConnection_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding3 = compiledBindingExtension4.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock9.Bind(isVisibleProperty, binding3);
			textBlock9.VerticalAlignment = VerticalAlignment.Center;
			textBlock9.FontSize = 12.0;
			context.PopParent();
			((ISupportInitialize)textBlock8).EndInit();
			Avalonia.Controls.Controls children3 = grid.Children;
			Lucide lucide2;
			Lucide lucide = (lucide2 = new Lucide());
			((ISupportInitialize)lucide).BeginInit();
			children3.Add(lucide);
			Lucide lucide4;
			Lucide lucide3 = (lucide4 = lucide2);
			context.PushParent(lucide4);
			Grid.SetColumn(lucide4, 2);
			lucide4.Icon = LucideIconNames.Wifi;
			lucide4.Width = 16.0;
			lucide4.Height = 16.0;
			lucide4.HorizontalAlignment = HorizontalAlignment.Right;
			lucide4.VerticalAlignment = VerticalAlignment.Center;
			StyledProperty<IBrush?> strokeBrushProperty = Lucide.StrokeBrushProperty;
			CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ERegionChoice_002CMerostrap_002ESignalBrush_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
			CompiledBinding binding4 = compiledBindingExtension5.ProvideValue(context);
			context.ProvideTargetProperty = null;
			lucide4.Bind(strokeBrushProperty, binding4);
			StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ERegionChoice_002CMerostrap_002EShowConnection_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding5 = compiledBindingExtension6.ProvideValue(context);
			context.ProvideTargetProperty = null;
			lucide4.Bind(isVisibleProperty2, binding5);
			context.PopParent();
			((ISupportInitialize)lucide3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<RegionSelectorPage> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<RegionSelectorPage> context = new XamlIlContext.Context<RegionSelectorPage>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FPages_002FRegionSelectorPage_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/Pages/RegionSelectorPage.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (RegionSelectorPage)service;
				}
			}
			return context;
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal ComboBox PreferredRegionPicker;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public RegionSelectorPage()
	{
		InitializeComponent();
	}

	protected override void OnAttachedToVisualTree(VisualTreeAttachmentEventArgs e)
	{
		base.OnAttachedToVisualTree(e);
		if (DataContext is RegionSelectorViewModel regionSelectorViewModel)
		{
			regionSelectorViewModel.LoadAsync();
		}
	}

	protected override void OnDetachedFromVisualTree(VisualTreeAttachmentEventArgs e)
	{
		if (DataContext is RegionSelectorViewModel regionSelectorViewModel)
		{
			regionSelectorViewModel.Dispose();
		}
		base.OnDetachedFromVisualTree(e);
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		PreferredRegionPicker = this.FindNameScope()?.Find<ComboBox>("PreferredRegionPicker");
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, RegionSelectorPage P_1)
	{
		XamlIlContext.Context<RegionSelectorPage> context = new XamlIlContext.Context<RegionSelectorPage>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FPages_002FRegionSelectorPage_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/Pages/RegionSelectorPage.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		Styles styles = P_1.Styles;
		Style style = new Style();
		style.Selector = ((Selector?)null).OfType(typeof(ComboBoxItem));
		Setter setter = new Setter();
		setter.Property = ContentControl.HorizontalContentAlignmentProperty;
		setter.Value = HorizontalAlignment.Stretch;
		style.Add(setter);
		styles.Add(style);
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		P_1.Content = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		stackPanel4.Margin = new Thickness(14.0, 18.0, 14.0, 18.0);
		stackPanel4.Spacing = 18.0;
		Avalonia.Controls.Controls children = stackPanel4.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children.Add(textBlock);
		textBlock2.Text = "Preferred region";
		textBlock2.FontSize = 24.0;
		textBlock2.FontWeight = FontWeight.DemiBold;
		((ISupportInitialize)textBlock2).EndInit();
		Avalonia.Controls.Controls children2 = stackPanel4.Children;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		children2.Add(grid);
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 3;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(10.0, GridUnitType.Pixel)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(42.0, GridUnitType.Pixel)));
		grid4.ColumnDefinitions = columnDefinitions;
		grid4.Width = 520.0;
		grid4.HorizontalAlignment = HorizontalAlignment.Left;
		Avalonia.Controls.Controls children3 = grid4.Children;
		ComboBox comboBox2;
		ComboBox comboBox = (comboBox2 = new ComboBox());
		((ISupportInitialize)comboBox).BeginInit();
		children3.Add(comboBox);
		ComboBox comboBox4;
		ComboBox comboBox3 = (comboBox4 = comboBox2);
		context.PushParent(comboBox4);
		comboBox4.Name = "PreferredRegionPicker";
		object element = comboBox4;
		context.AvaloniaNameScope.Register("PreferredRegionPicker", element);
		StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ERegionSelectorViewModel_002CMerostrap_002ERegions_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		comboBox4.Bind(itemsSourceProperty, binding);
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ERegionSelectorViewModel_002CMerostrap_002ESelectedOption_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = SelectingItemsControl.SelectedItemProperty;
		CompiledBinding compiledBinding = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_10(comboBox4, compiledBinding);
		comboBox4.HorizontalAlignment = HorizontalAlignment.Stretch;
		comboBox4.HorizontalContentAlignment = HorizontalAlignment.Stretch;
		comboBox4.VerticalContentAlignment = VerticalAlignment.Center;
		comboBox4.Height = 42.0;
		comboBox4.MaxDropDownHeight = 360.0;
		AutomationProperties.SetName(comboBox4, "Preferred region");
		DataTemplate dataTemplate;
		DataTemplate itemTemplate = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.DataType = typeof(RegionChoice);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_57.Build_1), context);
		context.PopParent();
		comboBox4.ItemTemplate = itemTemplate;
		context.PopParent();
		((ISupportInitialize)comboBox3).EndInit();
		Avalonia.Controls.Controls children4 = grid4.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children4.Add(button);
		Button button4;
		Button button3 = (button4 = button2);
		context.PushParent(button4);
		Grid.SetColumn(button4, 2);
		button4.Width = 42.0;
		button4.Height = 42.0;
		button4.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
		StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ERegionSelectorViewModel_002CMerostrap_002EReloadCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding2 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button4.Bind(commandProperty, binding2);
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002ERegionSelectorViewModel_002CMerostrap_002EStatus_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ToolTip.TipProperty;
		CompiledBinding compiledBinding2 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_11((ToolTip)(object)button4, compiledBinding2);
		AutomationProperties.SetName(button4, "Refresh regions and connection measurements");
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		button4.Content = lucide;
		lucide2.Icon = LucideIconNames.RefreshCw;
		lucide2.Width = 17.0;
		lucide2.Height = 17.0;
		((ISupportInitialize)lucide2).EndInit();
		context.PopParent();
		((ISupportInitialize)button3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(RegionSelectorPage P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
