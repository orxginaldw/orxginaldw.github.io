using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using CompiledAvaloniaXaml;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.UI.Elements.Dialogs;
using Merostrap.UI.ViewModels.Settings;

namespace Merostrap.UI.Elements.Settings.Pages;

internal class ProfilesPage : UserControl
{
	[CompilerGenerated]
	private class XamlClosure_55
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<ProfilesPage> context = CreateContext(P_0);
			context.IntermediateRoot = new WrapPanel();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<ProfilesPage> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<ProfilesPage> context = new XamlIlContext.Context<ProfilesPage>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FPages_002FProfilesPage_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/Pages/ProfilesPage.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (ProfilesPage)service;
				}
			}
			return context;
		}

		public static object Build_2(IServiceProvider P_0)
		{
			XamlIlContext.Context<ProfilesPage> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Border border = (Border)obj;
			context.PushParent(border);
			Border border2 = border;
			border2.Width = 350.0;
			border2.Margin = new Thickness(0.0, 0.0, 14.0, 14.0);
			border2.Padding = new Thickness(18.0, 18.0, 18.0, 18.0);
			border2.CornerRadius = new CornerRadius(10.0, 10.0, 10.0, 10.0);
			StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("ControlFillColorDefaultBrush");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border2.Bind(backgroundProperty, binding);
			StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
			DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("ControlStrokeColorDefaultBrush");
			context.ProvideTargetProperty = Border.BorderBrushProperty;
			BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border2.Bind(borderBrushProperty, binding2);
			border2.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
			StackPanel stackPanel2;
			StackPanel stackPanel = (stackPanel2 = new StackPanel());
			((ISupportInitialize)stackPanel).BeginInit();
			border2.Child = stackPanel;
			StackPanel stackPanel4;
			StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
			context.PushParent(stackPanel4);
			StackPanel stackPanel5 = stackPanel4;
			stackPanel5.Spacing = 16.0;
			Avalonia.Controls.Controls children = stackPanel5.Children;
			Grid grid2;
			Grid grid = (grid2 = new Grid());
			((ISupportInitialize)grid).BeginInit();
			children.Add(grid);
			Grid grid4;
			Grid grid3 = (grid4 = grid2);
			context.PushParent(grid4);
			Grid grid5 = grid4;
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 3;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(72.0, GridUnitType.Pixel)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(14.0, GridUnitType.Pixel)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid5.ColumnDefinitions = columnDefinitions;
			Avalonia.Controls.Controls children2 = grid5.Children;
			Border border4;
			Border border3 = (border4 = new Border());
			((ISupportInitialize)border3).BeginInit();
			children2.Add(border3);
			Border border5 = (border = border4);
			context.PushParent(border);
			Border border6 = border;
			border6.Width = 72.0;
			border6.Height = 72.0;
			border6.CornerRadius = new CornerRadius(10.0, 10.0, 10.0, 10.0);
			border6.ClipToBounds = true;
			StyledProperty<IBrush?> backgroundProperty2 = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("SubtleFillColorSecondaryBrush");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding3 = dynamicResourceExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border6.Bind(backgroundProperty2, binding3);
			Grid grid7;
			Grid grid6 = (grid7 = new Grid());
			((ISupportInitialize)grid6).BeginInit();
			border6.Child = grid6;
			Grid grid8 = (grid4 = grid7);
			context.PushParent(grid4);
			Grid grid9 = grid4;
			Avalonia.Controls.Controls children3 = grid9.Children;
			Lucide lucide2;
			Lucide lucide = (lucide2 = new Lucide());
			((ISupportInitialize)lucide).BeginInit();
			children3.Add(lucide);
			Lucide lucide4;
			Lucide lucide3 = (lucide4 = lucide2);
			context.PushParent(lucide4);
			lucide4.Icon = LucideIconNames.Gamepad2;
			lucide4.Width = 28.0;
			lucide4.Height = 28.0;
			StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileCard_002CMerostrap_002EHasIcon_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding4 = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			lucide4.Bind(isVisibleProperty, binding4);
			context.PopParent();
			((ISupportInitialize)lucide3).EndInit();
			Avalonia.Controls.Controls children4 = grid9.Children;
			Image image2;
			Image image = (image2 = new Image());
			((ISupportInitialize)image).BeginInit();
			children4.Add(image);
			Image image4;
			Image image3 = (image4 = image2);
			context.PushParent(image4);
			StyledProperty<IImage?> sourceProperty = Image.SourceProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileCard_002CMerostrap_002EIcon_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Image.SourceProperty;
			CompiledBinding binding5 = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			image4.Bind(sourceProperty, binding5);
			image4.Stretch = Stretch.UniformToFill;
			StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileCard_002CMerostrap_002EHasIcon_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding6 = compiledBindingExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			image4.Bind(isVisibleProperty2, binding6);
			context.PopParent();
			((ISupportInitialize)image3).EndInit();
			context.PopParent();
			((ISupportInitialize)grid8).EndInit();
			context.PopParent();
			((ISupportInitialize)border5).EndInit();
			Avalonia.Controls.Controls children5 = grid5.Children;
			StackPanel stackPanel7;
			StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
			((ISupportInitialize)stackPanel6).BeginInit();
			children5.Add(stackPanel6);
			StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
			context.PushParent(stackPanel4);
			StackPanel stackPanel9 = stackPanel4;
			Grid.SetColumn(stackPanel9, 2);
			stackPanel9.Spacing = 5.0;
			stackPanel9.VerticalAlignment = VerticalAlignment.Center;
			Avalonia.Controls.Controls children6 = stackPanel9.Children;
			TextBlock textBlock2;
			TextBlock textBlock = (textBlock2 = new TextBlock());
			((ISupportInitialize)textBlock).BeginInit();
			children6.Add(textBlock);
			TextBlock textBlock4;
			TextBlock textBlock3 = (textBlock4 = textBlock2);
			context.PushParent(textBlock4);
			TextBlock textBlock5 = textBlock4;
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileCard_002CMerostrap_002EName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding7 = compiledBindingExtension4.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock5.Bind(textProperty, binding7);
			textBlock5.FontSize = 17.0;
			textBlock5.FontWeight = FontWeight.DemiBold;
			textBlock5.TextTrimming = TextTrimming.CharacterEllipsis;
			CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileCard_002CMerostrap_002EName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = ToolTip.TipProperty;
			CompiledBinding compiledBinding = compiledBindingExtension5.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_11((ToolTip)(object)textBlock5, compiledBinding);
			context.PopParent();
			((ISupportInitialize)textBlock3).EndInit();
			Avalonia.Controls.Controls children7 = stackPanel9.Children;
			TextBlock textBlock7;
			TextBlock textBlock6 = (textBlock7 = new TextBlock());
			((ISupportInitialize)textBlock6).BeginInit();
			children7.Add(textBlock6);
			TextBlock textBlock8 = (textBlock4 = textBlock7);
			context.PushParent(textBlock4);
			TextBlock textBlock9 = textBlock4;
			StyledProperty<string?> textProperty2 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileCard_002CMerostrap_002EGameName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding8 = compiledBindingExtension6.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock9.Bind(textProperty2, binding8);
			StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
			DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("TextFillColorSecondaryBrush");
			context.ProvideTargetProperty = TextBlock.ForegroundProperty;
			BindingBase binding9 = dynamicResourceExtension4.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock9.Bind(foregroundProperty, binding9);
			textBlock9.TextTrimming = TextTrimming.CharacterEllipsis;
			CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileCard_002CMerostrap_002EGameName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = ToolTip.TipProperty;
			CompiledBinding compiledBinding2 = compiledBindingExtension7.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_11((ToolTip)(object)textBlock9, compiledBinding2);
			context.PopParent();
			((ISupportInitialize)textBlock8).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel8).EndInit();
			context.PopParent();
			((ISupportInitialize)grid3).EndInit();
			Avalonia.Controls.Controls children8 = stackPanel5.Children;
			Grid grid11;
			Grid grid10 = (grid11 = new Grid());
			((ISupportInitialize)grid10).BeginInit();
			children8.Add(grid10);
			Grid grid12 = (grid4 = grid11);
			context.PushParent(grid4);
			Grid grid13 = grid4;
			ColumnDefinitions columnDefinitions2 = new ColumnDefinitions();
			columnDefinitions2.Capacity = 7;
			columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions2.Add(new ColumnDefinition(new GridLength(8.0, GridUnitType.Pixel)));
			columnDefinitions2.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions2.Add(new ColumnDefinition(new GridLength(8.0, GridUnitType.Pixel)));
			columnDefinitions2.Add(new ColumnDefinition(new GridLength(36.0, GridUnitType.Pixel)));
			columnDefinitions2.Add(new ColumnDefinition(new GridLength(8.0, GridUnitType.Pixel)));
			columnDefinitions2.Add(new ColumnDefinition(new GridLength(36.0, GridUnitType.Pixel)));
			grid13.ColumnDefinitions = columnDefinitions2;
			Avalonia.Controls.Controls children9 = grid13.Children;
			Button button2;
			Button button = (button2 = new Button());
			((ISupportInitialize)button).BeginInit();
			children9.Add(button);
			Button button4;
			Button button3 = (button4 = button2);
			context.PushParent(button4);
			Button button5 = button4;
			CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileCard_002CMerostrap_002EApplyLabel_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = ContentControl.ContentProperty;
			CompiledBinding compiledBinding3 = compiledBindingExtension8.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_4(button5, compiledBinding3);
			button5.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.ApplyClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
			StyledProperty<bool> isEnabledProperty = InputElement.IsEnabledProperty;
			CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileCard_002CMerostrap_002ECanApply_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = InputElement.IsEnabledProperty;
			CompiledBinding binding10 = compiledBindingExtension9.ProvideValue(context);
			context.ProvideTargetProperty = null;
			button5.Bind(isEnabledProperty, binding10);
			button5.Classes.Add("accent");
			button5.Height = 36.0;
			button5.HorizontalAlignment = HorizontalAlignment.Stretch;
			button5.HorizontalContentAlignment = HorizontalAlignment.Center;
			context.PopParent();
			((ISupportInitialize)button3).EndInit();
			Avalonia.Controls.Controls children10 = grid13.Children;
			Button button7;
			Button button6 = (button7 = new Button());
			((ISupportInitialize)button6).BeginInit();
			children10.Add(button6);
			Button button8 = (button4 = button7);
			context.PushParent(button4);
			Button button9 = button4;
			Grid.SetColumn(button9, 2);
			button9.Content = "Update";
			button9.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.SaveClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
			StyledProperty<bool> isVisibleProperty3 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileCard_002CMerostrap_002EIsActive_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding11 = compiledBindingExtension10.ProvideValue(context);
			context.ProvideTargetProperty = null;
			button9.Bind(isVisibleProperty3, binding11);
			button9.Height = 36.0;
			ToolTip.SetTip(button9, "Replace this profile's saved settings with your current settings");
			context.PopParent();
			((ISupportInitialize)button8).EndInit();
			Avalonia.Controls.Controls children11 = grid13.Children;
			Button button11;
			Button button10 = (button11 = new Button());
			((ISupportInitialize)button10).BeginInit();
			children11.Add(button10);
			Grid.SetColumn(button11, 4);
			button11.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.EditClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
			button11.Height = 36.0;
			button11.Width = 36.0;
			button11.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
			ToolTip.SetTip(button11, "Edit profile");
			AutomationProperties.SetName(button11, "Edit profile");
			Lucide lucide6;
			Lucide lucide5 = (lucide6 = new Lucide());
			((ISupportInitialize)lucide5).BeginInit();
			button11.Content = lucide5;
			lucide6.Icon = LucideIconNames.Pencil;
			lucide6.Width = 16.0;
			lucide6.Height = 16.0;
			((ISupportInitialize)lucide6).EndInit();
			((ISupportInitialize)button11).EndInit();
			Avalonia.Controls.Controls children12 = grid13.Children;
			Button button13;
			Button button12 = (button13 = new Button());
			((ISupportInitialize)button12).BeginInit();
			children12.Add(button12);
			Grid.SetColumn(button13, 6);
			button13.Height = 36.0;
			button13.Width = 36.0;
			button13.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
			ToolTip.SetTip(button13, "Delete profile");
			AutomationProperties.SetName(button13, "Delete profile");
			Flyout flyout = new Flyout();
			StackPanel stackPanel11;
			StackPanel stackPanel10 = (stackPanel11 = new StackPanel());
			((ISupportInitialize)stackPanel10).BeginInit();
			flyout.Content = stackPanel10;
			stackPanel11.Width = 240.0;
			stackPanel11.Spacing = 12.0;
			Avalonia.Controls.Controls children13 = stackPanel11.Children;
			TextBlock textBlock11;
			TextBlock textBlock10 = (textBlock11 = new TextBlock());
			((ISupportInitialize)textBlock10).BeginInit();
			children13.Add(textBlock10);
			textBlock11.Text = "Delete this profile?";
			textBlock11.FontWeight = FontWeight.DemiBold;
			((ISupportInitialize)textBlock11).EndInit();
			Avalonia.Controls.Controls children14 = stackPanel11.Children;
			TextBlock textBlock13;
			TextBlock textBlock12 = (textBlock13 = new TextBlock());
			((ISupportInitialize)textBlock12).BeginInit();
			children14.Add(textBlock12);
			textBlock13.Text = "Your current settings will stay as they are.";
			textBlock13.TextWrapping = TextWrapping.Wrap;
			((ISupportInitialize)textBlock13).EndInit();
			Avalonia.Controls.Controls children15 = stackPanel11.Children;
			Button button15;
			Button button14 = (button15 = new Button());
			((ISupportInitialize)button14).BeginInit();
			children15.Add(button14);
			button15.Content = "Delete profile";
			button15.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.DeleteClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
			((ISupportInitialize)button15).EndInit();
			((ISupportInitialize)stackPanel11).EndInit();
			button13.Flyout = flyout;
			Lucide lucide8;
			Lucide lucide7 = (lucide8 = new Lucide());
			((ISupportInitialize)lucide7).BeginInit();
			button13.Content = lucide7;
			lucide8.Icon = LucideIconNames.Trash2;
			lucide8.Width = 16.0;
			lucide8.Height = 16.0;
			((ISupportInitialize)lucide8).EndInit();
			((ISupportInitialize)button13).EndInit();
			context.PopParent();
			((ISupportInitialize)grid12).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button CreateProfileButton;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public ProfilesPage()
	{
		InitializeComponent();
	}

	private async Task EditAsync(ProfileCard? card)
	{
		if (!(DataContext is ProfilesViewModel owner) || !(TopLevel.GetTopLevel(this) is Window window))
		{
			return;
		}
		using ProfileEditorViewModel editor = new ProfileEditorViewModel(owner, card);
		await new ProfileEditorWindow(editor)
		{
			RequestedThemeVariant = window.ActualThemeVariant
		}.ShowDialog<bool>(window);
	}

	private async void CreateClicked(object? sender, RoutedEventArgs e)
	{
		await EditAsync(null);
	}

	private async void EditClicked(object? sender, RoutedEventArgs e)
	{
		if (sender is Control { DataContext: ProfileCard dataContext })
		{
			await EditAsync(dataContext);
		}
	}

	private void ApplyClicked(object? sender, RoutedEventArgs e)
	{
		if (DataContext is ProfilesViewModel profilesViewModel && sender is Control { DataContext: ProfileCard dataContext })
		{
			profilesViewModel.Apply(dataContext);
		}
	}

	private void SaveClicked(object? sender, RoutedEventArgs e)
	{
		if (DataContext is ProfilesViewModel profilesViewModel && sender is Control { DataContext: ProfileCard dataContext })
		{
			profilesViewModel.SaveCurrent(dataContext);
		}
	}

	private void DeleteClicked(object? sender, RoutedEventArgs e)
	{
		if (DataContext is ProfilesViewModel profilesViewModel && sender is Control { DataContext: ProfileCard dataContext })
		{
			profilesViewModel.Delete(dataContext);
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		CreateProfileButton = this.FindNameScope()?.Find<Button>("CreateProfileButton");
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, ProfilesPage P_1)
	{
		XamlIlContext.Context<ProfilesPage> context = new XamlIlContext.Context<ProfilesPage>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FPages_002FProfilesPage_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/Pages/ProfilesPage.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		P_1.Content = scrollViewer;
		ScrollViewer scrollViewer4;
		ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
		context.PushParent(scrollViewer4);
		scrollViewer4.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		scrollViewer4.Content = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		stackPanel4.Margin = new Thickness(14.0, 18.0, 14.0, 18.0);
		stackPanel4.Spacing = 20.0;
		Avalonia.Controls.Controls children = stackPanel4.Children;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		children.Add(grid);
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 2;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid2.ColumnDefinitions = columnDefinitions;
		Avalonia.Controls.Controls children2 = grid2.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children2.Add(textBlock);
		textBlock2.Text = "Profiles";
		textBlock2.FontSize = 24.0;
		textBlock2.FontWeight = FontWeight.DemiBold;
		textBlock2.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)textBlock2).EndInit();
		Avalonia.Controls.Controls children3 = grid2.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children3.Add(button);
		button2.Name = "CreateProfileButton";
		object element = button2;
		context.AvaloniaNameScope.Register("CreateProfileButton", element);
		Grid.SetColumn(button2, 1);
		button2.Classes.Add("accent");
		button2.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.CreateClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button2.Height = 38.0;
		StackPanel stackPanel6;
		StackPanel stackPanel5 = (stackPanel6 = new StackPanel());
		((ISupportInitialize)stackPanel5).BeginInit();
		button2.Content = stackPanel5;
		stackPanel6.Orientation = Orientation.Horizontal;
		stackPanel6.Spacing = 8.0;
		Avalonia.Controls.Controls children4 = stackPanel6.Children;
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		children4.Add(lucide);
		lucide2.Icon = LucideIconNames.Plus;
		lucide2.Width = 16.0;
		lucide2.Height = 16.0;
		((ISupportInitialize)lucide2).EndInit();
		Avalonia.Controls.Controls children5 = stackPanel6.Children;
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		children5.Add(textBlock3);
		textBlock4.Text = "Create profile";
		((ISupportInitialize)textBlock4).EndInit();
		((ISupportInitialize)stackPanel6).EndInit();
		((ISupportInitialize)button2).EndInit();
		((ISupportInitialize)grid2).EndInit();
		Avalonia.Controls.Controls children6 = stackPanel4.Children;
		ItemsControl itemsControl2;
		ItemsControl itemsControl = (itemsControl2 = new ItemsControl());
		((ISupportInitialize)itemsControl).BeginInit();
		children6.Add(itemsControl);
		ItemsControl itemsControl4;
		ItemsControl itemsControl3 = (itemsControl4 = itemsControl2);
		context.PushParent(itemsControl4);
		StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfilesViewModel_002CMerostrap_002EProfiles_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		itemsControl4.Bind(itemsSourceProperty, binding);
		itemsControl4.ItemsPanel = new ItemsPanelTemplate
		{
			Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_55.Build_1), context)
		};
		DataTemplate dataTemplate;
		DataTemplate itemTemplate = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.DataType = typeof(ProfileCard);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_55.Build_2), context);
		context.PopParent();
		itemsControl4.ItemTemplate = itemTemplate;
		context.PopParent();
		((ISupportInitialize)itemsControl3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(ProfilesPage P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
