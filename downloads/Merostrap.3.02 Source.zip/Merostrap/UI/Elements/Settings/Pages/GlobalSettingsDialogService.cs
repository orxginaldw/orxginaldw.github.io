using System;
using System.Threading.Tasks;
using Merostrap.UI.ViewModels.Settings;

namespace Merostrap.UI.Elements.Settings.Pages;

internal class GlobalSettingsDialogService(MainWindowViewModel mainVm) : IDialogServiceGlobal
{
	private readonly MainWindowViewModel _mainVm = mainVm ?? throw new ArgumentNullException("mainVm");

	public Task OpenGlobalSettingsEditorAsync()
	{
		_mainVm.NavigateToGlobalSettingsEditorCommand.Execute(null);
		return Task.CompletedTask;
	}
}
