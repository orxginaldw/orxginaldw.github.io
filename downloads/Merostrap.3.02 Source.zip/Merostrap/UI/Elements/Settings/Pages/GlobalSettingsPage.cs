using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Windows.Input;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Data.Converters;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using CompiledAvaloniaXaml;
using FluentAvalonia.UI.Controls;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.Resources;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.ViewModels.Settings;

namespace Merostrap.UI.Elements.Settings.Pages;

internal class GlobalSettingsPage : UserControl
{
	[CompilerGenerated]
	private class XamlClosure_45
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<GlobalSettingsPage> context = CreateContext(P_0);
			context.IntermediateRoot = new TextBlock();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			TextBlock textBlock = (TextBlock)obj;
			context.PushParent(textBlock);
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension2;
			CompiledBindingExtension compiledBindingExtension = (compiledBindingExtension2 = new CompiledBindingExtension());
			context.PushParent(compiledBindingExtension2);
			StaticResourceExtension staticResourceExtension = new StaticResourceExtension("EnumNameConverter");
			context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EData_002ECompiledBinding_002CAvalonia_002EBase_002EConverter_0021Property();
			object? obj2 = staticResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			compiledBindingExtension2.Converter = (IValueConverter)obj2;
			context.PopParent();
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock.Bind(textProperty, binding);
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<GlobalSettingsPage> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<GlobalSettingsPage> context = new XamlIlContext.Context<GlobalSettingsPage>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FPages_002FGlobalSettingsPage_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/Pages/GlobalSettingsPage.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (GlobalSettingsPage)service;
				}
			}
			return context;
		}

		public static object Build_2(IServiceProvider P_0)
		{
			XamlIlContext.Context<GlobalSettingsPage> context = CreateContext(P_0);
			context.IntermediateRoot = new TextBlock();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			TextBlock textBlock = (TextBlock)obj;
			context.PushParent(textBlock);
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension2;
			CompiledBindingExtension compiledBindingExtension = (compiledBindingExtension2 = new CompiledBindingExtension());
			context.PushParent(compiledBindingExtension2);
			StaticResourceExtension staticResourceExtension = new StaticResourceExtension("EnumNameConverter");
			context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EData_002ECompiledBinding_002CAvalonia_002EBase_002EConverter_0021Property();
			object? obj2 = staticResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			compiledBindingExtension2.Converter = (IValueConverter)obj2;
			context.PopParent();
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock.Bind(textProperty, binding);
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}
	}

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public GlobalSettingsPage()
	{
		InitializeComponent();
		App.FrostRPC?.SetPage("Global Settings");
	}

	private void ValidateUInt32(object? sender, TextInputEventArgs e)
	{
		if (sender is TextBox textBox && !string.IsNullOrEmpty(e.Text))
		{
			string text = textBox.Text ?? string.Empty;
			int caretIndex = textBox.CaretIndex;
			string s = text.Insert(caretIndex, e.Text);
			e.Handled = !uint.TryParse(s, out var _);
		}
	}

	private void ValidateFloat(object? sender, TextInputEventArgs e)
	{
		if (sender is TextBox textBox && !string.IsNullOrEmpty(e.Text))
		{
			string text = textBox.Text ?? string.Empty;
			int caretIndex = textBox.CaretIndex;
			string input = text.Insert(caretIndex, e.Text);
			e.Handled = !Regex.IsMatch(input, "^-?\\d*\\.?\\d*$");
		}
	}

	protected override void OnAttachedToVisualTree(VisualTreeAttachmentEventArgs e)
	{
		base.OnAttachedToVisualTree(e);
		InitializeFreshViewModel();
	}

	private void InitializeFreshViewModel()
	{
		try
		{
			App.GlobalSettings.Load();
			if (TopLevel.GetTopLevel(this)?.DataContext is MainWindowViewModel mainVm)
			{
				GlobalSettingsDialogService dialogService = new GlobalSettingsDialogService(mainVm);
				DataContext = new GlobalSettingsViewModel(dialogService);
			}
			else
			{
				DataContext = new GlobalSettingsViewModel();
			}
			App.Logger.Info("ViewModel reinitialized and data reloaded.");
		}
		catch (Exception argument)
		{
			App.Logger.Error("Unhandled exception: ", argument);
			DataContext = new GlobalSettingsViewModel();
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, GlobalSettingsPage P_1)
	{
		XamlIlContext.Context<GlobalSettingsPage> context = new XamlIlContext.Context<GlobalSettingsPage>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FPages_002FGlobalSettingsPage_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/Pages/GlobalSettingsPage.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		P_1.Content = scrollViewer;
		ScrollViewer scrollViewer4;
		ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
		context.PushParent(scrollViewer4);
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		scrollViewer4.Content = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		StackPanel stackPanel5 = stackPanel4;
		stackPanel5.Margin = new Thickness(14.0, 14.0, 14.0, 14.0);
		Avalonia.Controls.Controls children = stackPanel5.Children;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		children.Add(grid);
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 3;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid5.ColumnDefinitions = columnDefinitions;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid5.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children2 = grid5.Children;
		CardAction cardAction2;
		CardAction cardAction = (cardAction2 = new CardAction());
		((ISupportInitialize)cardAction).BeginInit();
		children2.Add(cardAction);
		CardAction cardAction4;
		CardAction cardAction3 = (cardAction4 = cardAction2);
		context.PushParent(cardAction4);
		CardAction cardAction5 = cardAction4;
		Grid.SetColumn(cardAction5, 0);
		Grid.SetRow(cardAction5, 0);
		cardAction5.Margin = new Thickness(0.0, 0.0, 4.0, 0.0);
		cardAction5.Icon = LucideIconNames.Import;
		cardAction5.Header = Strings.Common_Import;
		StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EImportCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		cardAction5.Bind(commandProperty, binding);
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Self().Build());
		context.ProvideTargetProperty = Button.CommandParameterProperty;
		CompiledBinding compiledBinding = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_6(cardAction5, compiledBinding);
		context.PopParent();
		((ISupportInitialize)cardAction3).EndInit();
		Avalonia.Controls.Controls children3 = grid5.Children;
		CardAction cardAction7;
		CardAction cardAction6 = (cardAction7 = new CardAction());
		((ISupportInitialize)cardAction6).BeginInit();
		children3.Add(cardAction6);
		CardAction cardAction8 = (cardAction4 = cardAction7);
		context.PushParent(cardAction4);
		CardAction cardAction9 = cardAction4;
		Grid.SetColumn(cardAction9, 1);
		Grid.SetRow(cardAction9, 0);
		cardAction9.Margin = new Thickness(4.0, 0.0, 4.0, 0.0);
		cardAction9.Icon = LucideIconNames.FolderOpen;
		cardAction9.Header = Strings.Menu_GlobalSettings_OpenRobloxFolder;
		StyledProperty<ICommand?> commandProperty2 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EOpenRobloxFolderCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding2 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		cardAction9.Bind(commandProperty2, binding2);
		context.PopParent();
		((ISupportInitialize)cardAction8).EndInit();
		Avalonia.Controls.Controls children4 = grid5.Children;
		CardAction cardAction11;
		CardAction cardAction10 = (cardAction11 = new CardAction());
		((ISupportInitialize)cardAction10).BeginInit();
		children4.Add(cardAction10);
		CardAction cardAction12 = (cardAction4 = cardAction11);
		context.PushParent(cardAction4);
		CardAction cardAction13 = cardAction4;
		Grid.SetColumn(cardAction13, 2);
		Grid.SetRow(cardAction13, 0);
		cardAction13.Margin = new Thickness(4.0, 0.0, 0.0, 0.0);
		cardAction13.Icon = LucideIconNames.ArrowRightFromLine;
		cardAction13.Header = Strings.Common_Export;
		StyledProperty<ICommand?> commandProperty3 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EExportCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding3 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		cardAction13.Bind(commandProperty3, binding3);
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Self().Build());
		context.ProvideTargetProperty = Button.CommandParameterProperty;
		CompiledBinding compiledBinding2 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_6(cardAction13, compiledBinding2);
		context.PopParent();
		((ISupportInitialize)cardAction12).EndInit();
		Avalonia.Controls.Controls children5 = grid5.Children;
		CardAction cardAction15;
		CardAction cardAction14 = (cardAction15 = new CardAction());
		((ISupportInitialize)cardAction14).BeginInit();
		children5.Add(cardAction14);
		CardAction cardAction16 = (cardAction4 = cardAction15);
		context.PushParent(cardAction4);
		CardAction cardAction17 = cardAction4;
		Grid.SetColumnSpan(cardAction17, 3);
		Grid.SetRow(cardAction17, 1);
		cardAction17.Margin = new Thickness(0.0, 0.0, 4.0, 0.0);
		cardAction17.Icon = LucideIconNames.FilePenLine;
		cardAction17.Header = Strings.Menu_GBSEditor_Title;
		cardAction17.Description = Strings.Menu_GlobalSettingsEditor_Description;
		StyledProperty<ICommand?> commandProperty4 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EOpenGlobalSettingsEditorCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding4 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		cardAction17.Bind(commandProperty4, binding4);
		context.PopParent();
		((ISupportInitialize)cardAction16).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		Avalonia.Controls.Controls children6 = stackPanel5.Children;
		OptionControl optionControl2;
		OptionControl optionControl = (optionControl2 = new OptionControl());
		((ISupportInitialize)optionControl).BeginInit();
		children6.Add(optionControl);
		OptionControl optionControl4;
		OptionControl optionControl3 = (optionControl4 = optionControl2);
		context.PushParent(optionControl4);
		OptionControl optionControl5 = optionControl4;
		optionControl5.Description = Strings.Menu_GBSEditor_ReadOnly_Description;
		optionControl5.Header = Strings.Menu_GBSEditor_ReadOnly_Title;
		StackPanel stackPanel7;
		StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
		((ISupportInitialize)stackPanel6).BeginInit();
		optionControl5.InnerContent = stackPanel6;
		StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
		context.PushParent(stackPanel4);
		StackPanel stackPanel9 = stackPanel4;
		stackPanel9.Orientation = Orientation.Horizontal;
		stackPanel9.Spacing = 8.0;
		Avalonia.Controls.Controls children7 = stackPanel9.Children;
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		children7.Add(lucide);
		Lucide lucide4;
		Lucide lucide3 = (lucide4 = lucide2);
		context.PushParent(lucide4);
		lucide4.Icon = LucideIconNames.TriangleAlert;
		lucide4.VerticalAlignment = VerticalAlignment.Center;
		lucide4.StrokeBrush = new ImmutableSolidColorBrush(4294944000u);
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EIsWarningVisible_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding5 = compiledBindingExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide4.Bind(isVisibleProperty, binding5);
		CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EWarningTooltipText_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ToolTip.TipProperty;
		CompiledBinding compiledBinding3 = compiledBindingExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_11((ToolTip)(object)lucide4, compiledBinding3);
		context.PopParent();
		((ISupportInitialize)lucide3).EndInit();
		Avalonia.Controls.Controls children8 = stackPanel9.Children;
		ToggleSwitch toggleSwitch2;
		ToggleSwitch toggleSwitch = (toggleSwitch2 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch).BeginInit();
		children8.Add(toggleSwitch);
		ToggleSwitch toggleSwitch4;
		ToggleSwitch toggleSwitch3 = (toggleSwitch4 = toggleSwitch2);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch5 = toggleSwitch4;
		Grid.SetColumn(toggleSwitch5, 1);
		toggleSwitch5.Margin = new Thickness(5.0, 0.0, 0.0, 0.0);
		StyledProperty<bool?> isCheckedProperty = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EReadOnly_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding6 = compiledBindingExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch5.Bind(isCheckedProperty, binding6);
		context.PopParent();
		((ISupportInitialize)toggleSwitch3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel8).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl3).EndInit();
		Avalonia.Controls.Controls children9 = stackPanel5.Children;
		StackPanel stackPanel11;
		StackPanel stackPanel10 = (stackPanel11 = new StackPanel());
		((ISupportInitialize)stackPanel10).BeginInit();
		children9.Add(stackPanel10);
		StackPanel stackPanel12 = (stackPanel4 = stackPanel11);
		context.PushParent(stackPanel4);
		StackPanel stackPanel13 = stackPanel4;
		Avalonia.Controls.Controls children10 = stackPanel13.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children10.Add(border);
		border2.Height = 12.0;
		((ISupportInitialize)border2).EndInit();
		Avalonia.Controls.Controls children11 = stackPanel13.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children11.Add(textBlock);
		textBlock2.FontSize = 20.0;
		textBlock2.FontWeight = FontWeight.Bold;
		textBlock2.Text = Strings.Menu_GlobalSettings_GraphicsSettings_Title;
		textBlock2.Margin = new Thickness(0.0, 10.0, 0.0, 10.0);
		((ISupportInitialize)textBlock2).EndInit();
		Avalonia.Controls.Controls children12 = stackPanel13.Children;
		StackPanel stackPanel15;
		StackPanel stackPanel14 = (stackPanel15 = new StackPanel());
		((ISupportInitialize)stackPanel14).BeginInit();
		children12.Add(stackPanel14);
		StackPanel stackPanel16 = (stackPanel4 = stackPanel15);
		context.PushParent(stackPanel4);
		StackPanel stackPanel17 = stackPanel4;
		Avalonia.Controls.Controls children13 = stackPanel17.Children;
		OptionControl optionControl7;
		OptionControl optionControl6 = (optionControl7 = new OptionControl());
		((ISupportInitialize)optionControl6).BeginInit();
		children13.Add(optionControl6);
		OptionControl optionControl8 = (optionControl4 = optionControl7);
		context.PushParent(optionControl4);
		OptionControl optionControl9 = optionControl4;
		optionControl9.Header = Strings.Menu_GlobalSettings_FramerateLimit_Title;
		optionControl9.Description = Strings.Menu_GlobalSettings_FramerateLimit_Description;
		TextBox textBox2;
		TextBox textBox = (textBox2 = new TextBox());
		((ISupportInitialize)textBox).BeginInit();
		optionControl9.InnerContent = textBox;
		TextBox textBox4;
		TextBox textBox3 = (textBox4 = textBox2);
		context.PushParent(textBox4);
		TextBox textBox5 = textBox4;
		textBox5.Width = 150.0;
		StyledProperty<string?> textProperty = TextBox.TextProperty;
		CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EFramerateCap_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = TextBox.TextProperty;
		CompiledBinding binding7 = compiledBindingExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBox5.Bind(textProperty, binding7);
		context.PopParent();
		((ISupportInitialize)textBox3).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl8).EndInit();
		Avalonia.Controls.Controls children14 = stackPanel17.Children;
		OptionControl optionControl11;
		OptionControl optionControl10 = (optionControl11 = new OptionControl());
		((ISupportInitialize)optionControl10).BeginInit();
		children14.Add(optionControl10);
		OptionControl optionControl12 = (optionControl4 = optionControl11);
		context.PushParent(optionControl4);
		OptionControl optionControl13 = optionControl4;
		optionControl13.Header = Strings.Menu_GlobalSettings_StartQuality_Title;
		optionControl13.Description = Strings.Menu_GlobalSettings_StartQuality_Description;
		ShowValueSlider showValueSlider2;
		ShowValueSlider showValueSlider = (showValueSlider2 = new ShowValueSlider());
		((ISupportInitialize)showValueSlider).BeginInit();
		optionControl13.InnerContent = showValueSlider;
		ShowValueSlider showValueSlider4;
		ShowValueSlider showValueSlider3 = (showValueSlider4 = showValueSlider2);
		context.PushParent(showValueSlider4);
		ShowValueSlider showValueSlider5 = showValueSlider4;
		showValueSlider5.Minimum = 0.0;
		showValueSlider5.Maximum = 10.0;
		showValueSlider5.Width = 250.0;
		showValueSlider5.TickFrequency = 1.0;
		showValueSlider5.IsSnapToTickEnabled = true;
		StyledProperty<double> valueProperty = RangeBase.ValueProperty;
		CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EGraphicsQuality_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = RangeBase.ValueProperty;
		CompiledBinding binding8 = compiledBindingExtension11.ProvideValue(context);
		context.ProvideTargetProperty = null;
		showValueSlider5.Bind(valueProperty, binding8);
		showValueSlider5.ShowValue = true;
		context.PopParent();
		((ISupportInitialize)showValueSlider3).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl12).EndInit();
		Avalonia.Controls.Controls children15 = stackPanel17.Children;
		OptionControl optionControl15;
		OptionControl optionControl14 = (optionControl15 = new OptionControl());
		((ISupportInitialize)optionControl14).BeginInit();
		children15.Add(optionControl14);
		OptionControl optionControl16 = (optionControl4 = optionControl15);
		context.PushParent(optionControl4);
		OptionControl optionControl17 = optionControl4;
		optionControl17.Header = Strings.Menu_GlobalSettings_Fullscreen_Title;
		optionControl17.Description = Strings.Menu_GlobalSettings_Fullscreen_Description;
		ToggleSwitch toggleSwitch7;
		ToggleSwitch toggleSwitch6 = (toggleSwitch7 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch6).BeginInit();
		optionControl17.InnerContent = toggleSwitch6;
		ToggleSwitch toggleSwitch8 = (toggleSwitch4 = toggleSwitch7);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch9 = toggleSwitch4;
		toggleSwitch9.Margin = new Thickness(5.0, 0.0, 0.0, 0.0);
		StyledProperty<bool?> isCheckedProperty2 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EFullscreen_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding9 = compiledBindingExtension12.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch9.Bind(isCheckedProperty2, binding9);
		context.PopParent();
		((ISupportInitialize)toggleSwitch8).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl16).EndInit();
		Avalonia.Controls.Controls children16 = stackPanel17.Children;
		OptionControl optionControl19;
		OptionControl optionControl18 = (optionControl19 = new OptionControl());
		((ISupportInitialize)optionControl18).BeginInit();
		children16.Add(optionControl18);
		OptionControl optionControl20 = (optionControl4 = optionControl19);
		context.PushParent(optionControl4);
		OptionControl optionControl21 = optionControl4;
		optionControl21.Header = Strings.Menu_GlobalSettings_MaxQuality_Title;
		optionControl21.Description = Strings.Menu_GlobalSettings_MaxQuality_Description;
		ToggleSwitch toggleSwitch11;
		ToggleSwitch toggleSwitch10 = (toggleSwitch11 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch10).BeginInit();
		optionControl21.InnerContent = toggleSwitch10;
		ToggleSwitch toggleSwitch12 = (toggleSwitch4 = toggleSwitch11);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch13 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty3 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EMaxQualityEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding10 = compiledBindingExtension13.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch13.Bind(isCheckedProperty3, binding10);
		context.PopParent();
		((ISupportInitialize)toggleSwitch12).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl20).EndInit();
		Avalonia.Controls.Controls children17 = stackPanel17.Children;
		OptionControl optionControl23;
		OptionControl optionControl22 = (optionControl23 = new OptionControl());
		((ISupportInitialize)optionControl22).BeginInit();
		children17.Add(optionControl22);
		OptionControl optionControl24 = (optionControl4 = optionControl23);
		context.PushParent(optionControl4);
		OptionControl optionControl25 = optionControl4;
		optionControl25.Header = Strings.Menu_GlobalSettings_Vignette_Title;
		optionControl25.Description = Strings.Menu_GlobalSettings_Vignette_Description;
		ToggleSwitch toggleSwitch15;
		ToggleSwitch toggleSwitch14 = (toggleSwitch15 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch14).BeginInit();
		optionControl25.InnerContent = toggleSwitch14;
		ToggleSwitch toggleSwitch16 = (toggleSwitch4 = toggleSwitch15);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch17 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty4 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EVignetteEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding11 = compiledBindingExtension14.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch17.Bind(isCheckedProperty4, binding11);
		context.PopParent();
		((ISupportInitialize)toggleSwitch16).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl24).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel16).EndInit();
		Avalonia.Controls.Controls children18 = stackPanel13.Children;
		Border border4;
		Border border3 = (border4 = new Border());
		((ISupportInitialize)border3).BeginInit();
		children18.Add(border3);
		border4.Height = 12.0;
		((ISupportInitialize)border4).EndInit();
		Avalonia.Controls.Controls children19 = stackPanel13.Children;
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		children19.Add(textBlock3);
		textBlock4.FontSize = 20.0;
		textBlock4.FontWeight = FontWeight.Bold;
		textBlock4.Text = Strings.Menu_GlobalSettings_AudioSettings_Title;
		textBlock4.Margin = new Thickness(0.0, 10.0, 0.0, 10.0);
		((ISupportInitialize)textBlock4).EndInit();
		Avalonia.Controls.Controls children20 = stackPanel13.Children;
		StackPanel stackPanel19;
		StackPanel stackPanel18 = (stackPanel19 = new StackPanel());
		((ISupportInitialize)stackPanel18).BeginInit();
		children20.Add(stackPanel18);
		StackPanel stackPanel20 = (stackPanel4 = stackPanel19);
		context.PushParent(stackPanel4);
		StackPanel stackPanel21 = stackPanel4;
		Avalonia.Controls.Controls children21 = stackPanel21.Children;
		OptionControl optionControl27;
		OptionControl optionControl26 = (optionControl27 = new OptionControl());
		((ISupportInitialize)optionControl26).BeginInit();
		children21.Add(optionControl26);
		OptionControl optionControl28 = (optionControl4 = optionControl27);
		context.PushParent(optionControl4);
		OptionControl optionControl29 = optionControl4;
		optionControl29.Header = Strings.Menu_GlobalSettings_MasterVolume_Title;
		optionControl29.Description = Strings.Menu_GlobalSettings_MasterVolume_Description;
		ShowValueSlider showValueSlider7;
		ShowValueSlider showValueSlider6 = (showValueSlider7 = new ShowValueSlider());
		((ISupportInitialize)showValueSlider6).BeginInit();
		optionControl29.InnerContent = showValueSlider6;
		ShowValueSlider showValueSlider8 = (showValueSlider4 = showValueSlider7);
		context.PushParent(showValueSlider4);
		ShowValueSlider showValueSlider9 = showValueSlider4;
		showValueSlider9.Width = 250.0;
		showValueSlider9.Minimum = 0.0;
		showValueSlider9.Maximum = 1.0;
		showValueSlider9.TickFrequency = 0.1;
		showValueSlider9.IsSnapToTickEnabled = true;
		StyledProperty<double> valueProperty2 = RangeBase.ValueProperty;
		CompiledBindingExtension compiledBindingExtension15 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EMasterVolume_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = RangeBase.ValueProperty;
		CompiledBinding binding12 = compiledBindingExtension15.ProvideValue(context);
		context.ProvideTargetProperty = null;
		showValueSlider9.Bind(valueProperty2, binding12);
		showValueSlider9.ShowValue = true;
		context.PopParent();
		((ISupportInitialize)showValueSlider8).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl28).EndInit();
		Avalonia.Controls.Controls children22 = stackPanel21.Children;
		OptionControl optionControl31;
		OptionControl optionControl30 = (optionControl31 = new OptionControl());
		((ISupportInitialize)optionControl30).BeginInit();
		children22.Add(optionControl30);
		OptionControl optionControl32 = (optionControl4 = optionControl31);
		context.PushParent(optionControl4);
		OptionControl optionControl33 = optionControl4;
		optionControl33.Header = Strings.Menu_GlobalSettings_StudioVolume_Title;
		optionControl33.Description = Strings.Menu_GlobalSettings_StudioVolume_Description;
		ShowValueSlider showValueSlider11;
		ShowValueSlider showValueSlider10 = (showValueSlider11 = new ShowValueSlider());
		((ISupportInitialize)showValueSlider10).BeginInit();
		optionControl33.InnerContent = showValueSlider10;
		ShowValueSlider showValueSlider12 = (showValueSlider4 = showValueSlider11);
		context.PushParent(showValueSlider4);
		ShowValueSlider showValueSlider13 = showValueSlider4;
		showValueSlider13.Width = 250.0;
		showValueSlider13.Minimum = 0.0;
		showValueSlider13.Maximum = 1.0;
		showValueSlider13.TickFrequency = 0.1;
		showValueSlider13.IsSnapToTickEnabled = true;
		StyledProperty<double> valueProperty3 = RangeBase.ValueProperty;
		CompiledBindingExtension compiledBindingExtension16 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EMasterVolumeStudio_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = RangeBase.ValueProperty;
		CompiledBinding binding13 = compiledBindingExtension16.ProvideValue(context);
		context.ProvideTargetProperty = null;
		showValueSlider13.Bind(valueProperty3, binding13);
		showValueSlider13.ShowValue = true;
		context.PopParent();
		((ISupportInitialize)showValueSlider12).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl32).EndInit();
		Avalonia.Controls.Controls children23 = stackPanel21.Children;
		OptionControl optionControl35;
		OptionControl optionControl34 = (optionControl35 = new OptionControl());
		((ISupportInitialize)optionControl34).BeginInit();
		children23.Add(optionControl34);
		OptionControl optionControl36 = (optionControl4 = optionControl35);
		context.PushParent(optionControl4);
		OptionControl optionControl37 = optionControl4;
		optionControl37.Header = Strings.Menu_GlobalSettings_PartyVolume_Title;
		optionControl37.Description = Strings.Menu_GlobalSettings_PartyVolume_Description;
		ShowValueSlider showValueSlider15;
		ShowValueSlider showValueSlider14 = (showValueSlider15 = new ShowValueSlider());
		((ISupportInitialize)showValueSlider14).BeginInit();
		optionControl37.InnerContent = showValueSlider14;
		ShowValueSlider showValueSlider16 = (showValueSlider4 = showValueSlider15);
		context.PushParent(showValueSlider4);
		ShowValueSlider showValueSlider17 = showValueSlider4;
		showValueSlider17.Width = 250.0;
		showValueSlider17.Minimum = 0.0;
		showValueSlider17.Maximum = 1.0;
		showValueSlider17.TickFrequency = 0.1;
		showValueSlider17.IsSnapToTickEnabled = true;
		StyledProperty<double> valueProperty4 = RangeBase.ValueProperty;
		CompiledBindingExtension compiledBindingExtension17 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EPartyVoiceVolume_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = RangeBase.ValueProperty;
		CompiledBinding binding14 = compiledBindingExtension17.ProvideValue(context);
		context.ProvideTargetProperty = null;
		showValueSlider17.Bind(valueProperty4, binding14);
		showValueSlider17.ShowValue = true;
		context.PopParent();
		((ISupportInitialize)showValueSlider16).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl36).EndInit();
		Avalonia.Controls.Controls children24 = stackPanel21.Children;
		OptionControl optionControl39;
		OptionControl optionControl38 = (optionControl39 = new OptionControl());
		((ISupportInitialize)optionControl38).BeginInit();
		children24.Add(optionControl38);
		OptionControl optionControl40 = (optionControl4 = optionControl39);
		context.PushParent(optionControl4);
		OptionControl optionControl41 = optionControl4;
		optionControl41.Header = Strings.Menu_GlobalSettings_VoiceChatVolume_Title;
		optionControl41.Description = Strings.Menu_GlobalSettings_VoiceChatVolume_Description;
		ShowValueSlider showValueSlider19;
		ShowValueSlider showValueSlider18 = (showValueSlider19 = new ShowValueSlider());
		((ISupportInitialize)showValueSlider18).BeginInit();
		optionControl41.InnerContent = showValueSlider18;
		ShowValueSlider showValueSlider20 = (showValueSlider4 = showValueSlider19);
		context.PushParent(showValueSlider4);
		ShowValueSlider showValueSlider21 = showValueSlider4;
		showValueSlider21.Width = 250.0;
		showValueSlider21.Minimum = 0.0;
		showValueSlider21.Maximum = 1.0;
		showValueSlider21.TickFrequency = 0.1;
		showValueSlider21.IsSnapToTickEnabled = true;
		StyledProperty<double> valueProperty5 = RangeBase.ValueProperty;
		CompiledBindingExtension compiledBindingExtension18 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EVoiceChatVolume_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = RangeBase.ValueProperty;
		CompiledBinding binding15 = compiledBindingExtension18.ProvideValue(context);
		context.ProvideTargetProperty = null;
		showValueSlider21.Bind(valueProperty5, binding15);
		showValueSlider21.ShowValue = true;
		context.PopParent();
		((ISupportInitialize)showValueSlider20).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl40).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel20).EndInit();
		Avalonia.Controls.Controls children25 = stackPanel13.Children;
		Border border6;
		Border border5 = (border6 = new Border());
		((ISupportInitialize)border5).BeginInit();
		children25.Add(border5);
		border6.Height = 12.0;
		((ISupportInitialize)border6).EndInit();
		Avalonia.Controls.Controls children26 = stackPanel13.Children;
		TextBlock textBlock6;
		TextBlock textBlock5 = (textBlock6 = new TextBlock());
		((ISupportInitialize)textBlock5).BeginInit();
		children26.Add(textBlock5);
		textBlock6.FontSize = 20.0;
		textBlock6.FontWeight = FontWeight.Bold;
		textBlock6.Text = Strings.Menu_GlobalSettings_InputSettings_Title;
		textBlock6.Margin = new Thickness(0.0, 10.0, 0.0, 10.0);
		((ISupportInitialize)textBlock6).EndInit();
		Avalonia.Controls.Controls children27 = stackPanel13.Children;
		StackPanel stackPanel23;
		StackPanel stackPanel22 = (stackPanel23 = new StackPanel());
		((ISupportInitialize)stackPanel22).BeginInit();
		children27.Add(stackPanel22);
		StackPanel stackPanel24 = (stackPanel4 = stackPanel23);
		context.PushParent(stackPanel4);
		StackPanel stackPanel25 = stackPanel4;
		Avalonia.Controls.Controls children28 = stackPanel25.Children;
		OptionControl optionControl43;
		OptionControl optionControl42 = (optionControl43 = new OptionControl());
		((ISupportInitialize)optionControl42).BeginInit();
		children28.Add(optionControl42);
		OptionControl optionControl44 = (optionControl4 = optionControl43);
		context.PushParent(optionControl4);
		OptionControl optionControl45 = optionControl4;
		optionControl45.Header = Strings.Menu_GlobalSettings_Sensitivity_Title;
		optionControl45.Description = Strings.Menu_GlobalSettings_Sensitivity_Description;
		TextBox textBox7;
		TextBox textBox6 = (textBox7 = new TextBox());
		((ISupportInitialize)textBox6).BeginInit();
		optionControl45.InnerContent = textBox6;
		TextBox textBox8 = (textBox4 = textBox7);
		context.PushParent(textBox4);
		TextBox textBox9 = textBox4;
		textBox9.Width = 150.0;
		StyledProperty<string?> textProperty2 = TextBox.TextProperty;
		CompiledBindingExtension compiledBindingExtension19 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EMouseSensitivity_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBox.TextProperty;
		CompiledBinding binding16 = compiledBindingExtension19.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBox9.Bind(textProperty2, binding16);
		context.PopParent();
		((ISupportInitialize)textBox8).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl44).EndInit();
		Avalonia.Controls.Controls children29 = stackPanel25.Children;
		OptionControl optionControl47;
		OptionControl optionControl46 = (optionControl47 = new OptionControl());
		((ISupportInitialize)optionControl46).BeginInit();
		children29.Add(optionControl46);
		OptionControl optionControl48 = (optionControl4 = optionControl47);
		context.PushParent(optionControl4);
		OptionControl optionControl49 = optionControl4;
		optionControl49.Header = Strings.Menu_GlobalSettings_ShiftLock_Title;
		optionControl49.Description = Strings.Menu_GlobalSettings_ShiftLock_Description;
		ToggleSwitch toggleSwitch19;
		ToggleSwitch toggleSwitch18 = (toggleSwitch19 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch18).BeginInit();
		optionControl49.InnerContent = toggleSwitch18;
		ToggleSwitch toggleSwitch20 = (toggleSwitch4 = toggleSwitch19);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch21 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty5 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension20 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EShiftLock_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding17 = compiledBindingExtension20.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch21.Bind(isCheckedProperty5, binding17);
		context.PopParent();
		((ISupportInitialize)toggleSwitch20).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl48).EndInit();
		Avalonia.Controls.Controls children30 = stackPanel25.Children;
		OptionControl optionControl51;
		OptionControl optionControl50 = (optionControl51 = new OptionControl());
		((ISupportInitialize)optionControl50).BeginInit();
		children30.Add(optionControl50);
		OptionControl optionControl52 = (optionControl4 = optionControl51);
		context.PushParent(optionControl4);
		OptionControl optionControl53 = optionControl4;
		optionControl53.Header = Strings.Menu_GlobalSettings_FirstPersonSensitivity_Title;
		optionControl53.Description = Strings.Menu_GlobalSettings_FirstPersonSensitivity_Description;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		optionControl53.InnerContent = grid6;
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		grid9.Margin = new Thickness(0.0, 0.0, 0.0, 4.0);
		ColumnDefinitions columnDefinitions2 = new ColumnDefinitions();
		columnDefinitions2.Capacity = 4;
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid9.ColumnDefinitions = columnDefinitions2;
		Avalonia.Controls.Controls children31 = grid9.Children;
		TextBlock textBlock8;
		TextBlock textBlock7 = (textBlock8 = new TextBlock());
		((ISupportInitialize)textBlock7).BeginInit();
		children31.Add(textBlock7);
		TextBlock textBlock10;
		TextBlock textBlock9 = (textBlock10 = textBlock8);
		context.PushParent(textBlock10);
		TextBlock textBlock11 = textBlock10;
		Grid.SetColumn(textBlock11, 0);
		textBlock11.Text = "X:";
		textBlock11.VerticalAlignment = VerticalAlignment.Center;
		textBlock11.Margin = new Thickness(0.0, 0.0, 4.0, 0.0);
		StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("TextFillColorSecondaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding18 = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock11.Bind(foregroundProperty, binding18);
		context.PopParent();
		((ISupportInitialize)textBlock9).EndInit();
		Avalonia.Controls.Controls children32 = grid9.Children;
		TextBox textBox11;
		TextBox textBox10 = (textBox11 = new TextBox());
		((ISupportInitialize)textBox10).BeginInit();
		children32.Add(textBox10);
		TextBox textBox12 = (textBox4 = textBox11);
		context.PushParent(textBox4);
		TextBox textBox13 = textBox4;
		textBox13.Width = 150.0;
		Grid.SetColumn(textBox13, 1);
		textBox13.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
		StyledProperty<string?> textProperty3 = TextBox.TextProperty;
		CompiledBindingExtension compiledBindingExtension21 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EMouseSensitivityFirstPersonX_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = TextBox.TextProperty;
		CompiledBinding binding19 = compiledBindingExtension21.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBox13.Bind(textProperty3, binding19);
		context.PopParent();
		((ISupportInitialize)textBox12).EndInit();
		Avalonia.Controls.Controls children33 = grid9.Children;
		TextBlock textBlock13;
		TextBlock textBlock12 = (textBlock13 = new TextBlock());
		((ISupportInitialize)textBlock12).BeginInit();
		children33.Add(textBlock12);
		TextBlock textBlock14 = (textBlock10 = textBlock13);
		context.PushParent(textBlock10);
		TextBlock textBlock15 = textBlock10;
		Grid.SetColumn(textBlock15, 2);
		textBlock15.Text = "Y:";
		textBlock15.VerticalAlignment = VerticalAlignment.Center;
		textBlock15.Margin = new Thickness(0.0, 0.0, 4.0, 0.0);
		StyledProperty<IBrush?> foregroundProperty2 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("TextFillColorSecondaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding20 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock15.Bind(foregroundProperty2, binding20);
		context.PopParent();
		((ISupportInitialize)textBlock14).EndInit();
		Avalonia.Controls.Controls children34 = grid9.Children;
		TextBox textBox15;
		TextBox textBox14 = (textBox15 = new TextBox());
		((ISupportInitialize)textBox14).BeginInit();
		children34.Add(textBox14);
		TextBox textBox16 = (textBox4 = textBox15);
		context.PushParent(textBox4);
		TextBox textBox17 = textBox4;
		textBox17.Width = 150.0;
		Grid.SetColumn(textBox17, 3);
		StyledProperty<string?> textProperty4 = TextBox.TextProperty;
		CompiledBindingExtension compiledBindingExtension22 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EMouseSensitivityFirstPersonY_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = TextBox.TextProperty;
		CompiledBinding binding21 = compiledBindingExtension22.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBox17.Bind(textProperty4, binding21);
		context.PopParent();
		((ISupportInitialize)textBox16).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl52).EndInit();
		Avalonia.Controls.Controls children35 = stackPanel25.Children;
		OptionControl optionControl55;
		OptionControl optionControl54 = (optionControl55 = new OptionControl());
		((ISupportInitialize)optionControl54).BeginInit();
		children35.Add(optionControl54);
		OptionControl optionControl56 = (optionControl4 = optionControl55);
		context.PushParent(optionControl4);
		OptionControl optionControl57 = optionControl4;
		optionControl57.Header = Strings.Menu_GlobalSettings_ThirdPersonSensitivity_Title;
		optionControl57.Description = Strings.Menu_GlobalSettings_ThirdPersonSensitivity_Description;
		Grid grid11;
		Grid grid10 = (grid11 = new Grid());
		((ISupportInitialize)grid10).BeginInit();
		optionControl57.InnerContent = grid10;
		Grid grid12 = (grid4 = grid11);
		context.PushParent(grid4);
		Grid grid13 = grid4;
		grid13.Margin = new Thickness(0.0, 0.0, 0.0, 4.0);
		ColumnDefinitions columnDefinitions3 = new ColumnDefinitions();
		columnDefinitions3.Capacity = 4;
		columnDefinitions3.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions3.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions3.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions3.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid13.ColumnDefinitions = columnDefinitions3;
		Avalonia.Controls.Controls children36 = grid13.Children;
		TextBlock textBlock17;
		TextBlock textBlock16 = (textBlock17 = new TextBlock());
		((ISupportInitialize)textBlock16).BeginInit();
		children36.Add(textBlock16);
		TextBlock textBlock18 = (textBlock10 = textBlock17);
		context.PushParent(textBlock10);
		TextBlock textBlock19 = textBlock10;
		Grid.SetColumn(textBlock19, 0);
		textBlock19.Text = "X:";
		textBlock19.VerticalAlignment = VerticalAlignment.Center;
		textBlock19.Margin = new Thickness(0.0, 0.0, 4.0, 0.0);
		StyledProperty<IBrush?> foregroundProperty3 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("TextFillColorSecondaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding22 = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock19.Bind(foregroundProperty3, binding22);
		context.PopParent();
		((ISupportInitialize)textBlock18).EndInit();
		Avalonia.Controls.Controls children37 = grid13.Children;
		TextBox textBox19;
		TextBox textBox18 = (textBox19 = new TextBox());
		((ISupportInitialize)textBox18).BeginInit();
		children37.Add(textBox18);
		TextBox textBox20 = (textBox4 = textBox19);
		context.PushParent(textBox4);
		TextBox textBox21 = textBox4;
		textBox21.Width = 150.0;
		Grid.SetColumn(textBox21, 1);
		textBox21.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
		StyledProperty<string?> textProperty5 = TextBox.TextProperty;
		CompiledBindingExtension compiledBindingExtension23 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EMouseSensitivityThirdPersonX_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = TextBox.TextProperty;
		CompiledBinding binding23 = compiledBindingExtension23.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBox21.Bind(textProperty5, binding23);
		context.PopParent();
		((ISupportInitialize)textBox20).EndInit();
		Avalonia.Controls.Controls children38 = grid13.Children;
		TextBlock textBlock21;
		TextBlock textBlock20 = (textBlock21 = new TextBlock());
		((ISupportInitialize)textBlock20).BeginInit();
		children38.Add(textBlock20);
		TextBlock textBlock22 = (textBlock10 = textBlock21);
		context.PushParent(textBlock10);
		TextBlock textBlock23 = textBlock10;
		Grid.SetColumn(textBlock23, 2);
		textBlock23.Text = "Y:";
		textBlock23.VerticalAlignment = VerticalAlignment.Center;
		textBlock23.Margin = new Thickness(0.0, 0.0, 4.0, 0.0);
		StyledProperty<IBrush?> foregroundProperty4 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("TextFillColorSecondaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding24 = dynamicResourceExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock23.Bind(foregroundProperty4, binding24);
		context.PopParent();
		((ISupportInitialize)textBlock22).EndInit();
		Avalonia.Controls.Controls children39 = grid13.Children;
		TextBox textBox23;
		TextBox textBox22 = (textBox23 = new TextBox());
		((ISupportInitialize)textBox22).BeginInit();
		children39.Add(textBox22);
		TextBox textBox24 = (textBox4 = textBox23);
		context.PushParent(textBox4);
		TextBox textBox25 = textBox4;
		textBox25.Width = 150.0;
		Grid.SetColumn(textBox25, 3);
		StyledProperty<string?> textProperty6 = TextBox.TextProperty;
		CompiledBindingExtension compiledBindingExtension24 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EMouseSensitivityThirdPersonY_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = TextBox.TextProperty;
		CompiledBinding binding25 = compiledBindingExtension24.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBox25.Bind(textProperty6, binding25);
		context.PopParent();
		((ISupportInitialize)textBox24).EndInit();
		context.PopParent();
		((ISupportInitialize)grid12).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl56).EndInit();
		Avalonia.Controls.Controls children40 = stackPanel25.Children;
		OptionControl optionControl59;
		OptionControl optionControl58 = (optionControl59 = new OptionControl());
		((ISupportInitialize)optionControl58).BeginInit();
		children40.Add(optionControl58);
		OptionControl optionControl60 = (optionControl4 = optionControl59);
		context.PushParent(optionControl4);
		OptionControl optionControl61 = optionControl4;
		optionControl61.Header = Strings.Menu_GlobalSettings_InvertY_Title;
		optionControl61.Description = Strings.Menu_GlobalSettings_InvertY_Description;
		ToggleSwitch toggleSwitch23;
		ToggleSwitch toggleSwitch22 = (toggleSwitch23 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch22).BeginInit();
		optionControl61.InnerContent = toggleSwitch22;
		ToggleSwitch toggleSwitch24 = (toggleSwitch4 = toggleSwitch23);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch25 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty6 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension25 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002ECameraYInverted_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding26 = compiledBindingExtension25.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch25.Bind(isCheckedProperty6, binding26);
		context.PopParent();
		((ISupportInitialize)toggleSwitch24).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl60).EndInit();
		Avalonia.Controls.Controls children41 = stackPanel25.Children;
		OptionControl optionControl63;
		OptionControl optionControl62 = (optionControl63 = new OptionControl());
		((ISupportInitialize)optionControl62).BeginInit();
		children41.Add(optionControl62);
		OptionControl optionControl64 = (optionControl4 = optionControl63);
		context.PushParent(optionControl4);
		OptionControl optionControl65 = optionControl4;
		optionControl65.Header = Strings.Menu_GlobalSettings_HapticStrength_Title;
		optionControl65.Description = Strings.Menu_GlobalSettings_HapticStrength_Description;
		ShowValueSlider showValueSlider23;
		ShowValueSlider showValueSlider22 = (showValueSlider23 = new ShowValueSlider());
		((ISupportInitialize)showValueSlider22).BeginInit();
		optionControl65.InnerContent = showValueSlider22;
		ShowValueSlider showValueSlider24 = (showValueSlider4 = showValueSlider23);
		context.PushParent(showValueSlider4);
		ShowValueSlider showValueSlider25 = showValueSlider4;
		showValueSlider25.Width = 250.0;
		showValueSlider25.Minimum = 0.0;
		showValueSlider25.Maximum = 1.0;
		showValueSlider25.TickFrequency = 0.1;
		showValueSlider25.IsSnapToTickEnabled = true;
		StyledProperty<double> valueProperty6 = RangeBase.ValueProperty;
		CompiledBindingExtension compiledBindingExtension26 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EHapticStrength_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = RangeBase.ValueProperty;
		CompiledBinding binding27 = compiledBindingExtension26.ProvideValue(context);
		context.ProvideTargetProperty = null;
		showValueSlider25.Bind(valueProperty6, binding27);
		showValueSlider25.ShowValue = true;
		context.PopParent();
		((ISupportInitialize)showValueSlider24).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl64).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel24).EndInit();
		Avalonia.Controls.Controls children42 = stackPanel13.Children;
		Border border8;
		Border border7 = (border8 = new Border());
		((ISupportInitialize)border7).BeginInit();
		children42.Add(border7);
		border8.Height = 12.0;
		((ISupportInitialize)border8).EndInit();
		Avalonia.Controls.Controls children43 = stackPanel13.Children;
		TextBlock textBlock25;
		TextBlock textBlock24 = (textBlock25 = new TextBlock());
		((ISupportInitialize)textBlock24).BeginInit();
		children43.Add(textBlock24);
		textBlock25.FontSize = 20.0;
		textBlock25.FontWeight = FontWeight.Bold;
		textBlock25.Text = Strings.Menu_GlobalSettings_Accessibility_Title;
		textBlock25.Margin = new Thickness(0.0, 10.0, 0.0, 10.0);
		((ISupportInitialize)textBlock25).EndInit();
		Avalonia.Controls.Controls children44 = stackPanel13.Children;
		StackPanel stackPanel27;
		StackPanel stackPanel26 = (stackPanel27 = new StackPanel());
		((ISupportInitialize)stackPanel26).BeginInit();
		children44.Add(stackPanel26);
		StackPanel stackPanel28 = (stackPanel4 = stackPanel27);
		context.PushParent(stackPanel4);
		StackPanel stackPanel29 = stackPanel4;
		Avalonia.Controls.Controls children45 = stackPanel29.Children;
		OptionControl optionControl67;
		OptionControl optionControl66 = (optionControl67 = new OptionControl());
		((ISupportInitialize)optionControl66).BeginInit();
		children45.Add(optionControl66);
		OptionControl optionControl68 = (optionControl4 = optionControl67);
		context.PushParent(optionControl4);
		OptionControl optionControl69 = optionControl4;
		optionControl69.Header = Strings.Menu_GlobalSettings_UITransparency_Title;
		optionControl69.Description = Strings.Menu_GlobalSettings_UITransparency_Description;
		TextBox textBox27;
		TextBox textBox26 = (textBox27 = new TextBox());
		((ISupportInitialize)textBox26).BeginInit();
		optionControl69.InnerContent = textBox26;
		TextBox textBox28 = (textBox4 = textBox27);
		context.PushParent(textBox4);
		TextBox textBox29 = textBox4;
		textBox29.Width = 150.0;
		StyledProperty<string?> textProperty7 = TextBox.TextProperty;
		CompiledBindingExtension compiledBindingExtension27 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EUITransparency_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBox.TextProperty;
		CompiledBinding binding28 = compiledBindingExtension27.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBox29.Bind(textProperty7, binding28);
		context.PopParent();
		((ISupportInitialize)textBox28).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl68).EndInit();
		Avalonia.Controls.Controls children46 = stackPanel29.Children;
		OptionControl optionControl71;
		OptionControl optionControl70 = (optionControl71 = new OptionControl());
		((ISupportInitialize)optionControl70).BeginInit();
		children46.Add(optionControl70);
		OptionControl optionControl72 = (optionControl4 = optionControl71);
		context.PushParent(optionControl4);
		OptionControl optionControl73 = optionControl4;
		optionControl73.Header = Strings.Menu_GlobalSettings_PlayerListLayout_Title;
		optionControl73.Description = Strings.Menu_GlobalSettings_PlayerListLayout_Description;
		ComboBox comboBox2;
		ComboBox comboBox = (comboBox2 = new ComboBox());
		((ISupportInitialize)comboBox).BeginInit();
		optionControl73.InnerContent = comboBox;
		ComboBox comboBox4;
		ComboBox comboBox3 = (comboBox4 = comboBox2);
		context.PushParent(comboBox4);
		ComboBox comboBox5 = comboBox4;
		comboBox5.Width = 150.0;
		comboBox5.Margin = new Thickness(4.0, 0.0, 4.0, 0.0);
		comboBox5.Padding = new Thickness(10.0, 5.0, 10.0, 5.0);
		comboBox5.HorizontalAlignment = HorizontalAlignment.Stretch;
		StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension28 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EPlayerListLayOuts_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.System_002ECollections_002EGeneric_002EIReadOnlyDictionary_00602_002CSystem_002ERuntime_002EKeys_44_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.OneTime
		};
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding29 = compiledBindingExtension28.ProvideValue(context);
		context.ProvideTargetProperty = null;
		comboBox5.Bind(itemsSourceProperty, binding29);
		CompiledBindingExtension compiledBindingExtension29 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002ESelectedPlayerListLayOut_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = SelectingItemsControl.SelectedValueProperty;
		CompiledBinding compiledBinding4 = compiledBindingExtension29.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_15(comboBox5, compiledBinding4);
		DataTemplate dataTemplate;
		DataTemplate itemTemplate = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_45.Build_1), context);
		context.PopParent();
		comboBox5.ItemTemplate = itemTemplate;
		context.PopParent();
		((ISupportInitialize)comboBox3).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl72).EndInit();
		Avalonia.Controls.Controls children47 = stackPanel29.Children;
		OptionControl optionControl75;
		OptionControl optionControl74 = (optionControl75 = new OptionControl());
		((ISupportInitialize)optionControl74).BeginInit();
		children47.Add(optionControl74);
		OptionControl optionControl76 = (optionControl4 = optionControl75);
		context.PushParent(optionControl4);
		OptionControl optionControl77 = optionControl4;
		optionControl77.Header = Strings.Menu_GlobalSettings_TextSize_Title;
		optionControl77.Description = Strings.Menu_GlobalSettings_TextSize_Description;
		ComboBox comboBox7;
		ComboBox comboBox6 = (comboBox7 = new ComboBox());
		((ISupportInitialize)comboBox6).BeginInit();
		optionControl77.InnerContent = comboBox6;
		ComboBox comboBox8 = (comboBox4 = comboBox7);
		context.PushParent(comboBox4);
		ComboBox comboBox9 = comboBox4;
		comboBox9.Width = 150.0;
		comboBox9.Margin = new Thickness(4.0, 0.0, 4.0, 0.0);
		comboBox9.Padding = new Thickness(10.0, 5.0, 10.0, 5.0);
		comboBox9.HorizontalAlignment = HorizontalAlignment.Stretch;
		StyledProperty<IEnumerable?> itemsSourceProperty2 = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension30 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EFontSizes_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.System_002ECollections_002EGeneric_002EIReadOnlyDictionary_00602_002CSystem_002ERuntime_002EKeys_46_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.OneTime
		};
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding30 = compiledBindingExtension30.ProvideValue(context);
		context.ProvideTargetProperty = null;
		comboBox9.Bind(itemsSourceProperty2, binding30);
		CompiledBindingExtension compiledBindingExtension31 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002ESelectedFontSize_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = SelectingItemsControl.SelectedValueProperty;
		CompiledBinding compiledBinding5 = compiledBindingExtension31.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_15(comboBox9, compiledBinding5);
		DataTemplate itemTemplate2 = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_45.Build_2), context);
		context.PopParent();
		comboBox9.ItemTemplate = itemTemplate2;
		context.PopParent();
		((ISupportInitialize)comboBox8).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl76).EndInit();
		Avalonia.Controls.Controls children48 = stackPanel29.Children;
		OptionControl optionControl79;
		OptionControl optionControl78 = (optionControl79 = new OptionControl());
		((ISupportInitialize)optionControl78).BeginInit();
		children48.Add(optionControl78);
		OptionControl optionControl80 = (optionControl4 = optionControl79);
		context.PushParent(optionControl4);
		OptionControl optionControl81 = optionControl4;
		optionControl81.Header = Strings.Menu_GlobalSettings_ReducedMotion_Title;
		optionControl81.Description = Strings.Menu_GlobalSettings_ReducedMotion_Description;
		ToggleSwitch toggleSwitch27;
		ToggleSwitch toggleSwitch26 = (toggleSwitch27 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch26).BeginInit();
		optionControl81.InnerContent = toggleSwitch26;
		ToggleSwitch toggleSwitch28 = (toggleSwitch4 = toggleSwitch27);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch29 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty7 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension32 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EReducedMotion_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding31 = compiledBindingExtension32.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch29.Bind(isCheckedProperty7, binding31);
		context.PopParent();
		((ISupportInitialize)toggleSwitch28).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl80).EndInit();
		Avalonia.Controls.Controls children49 = stackPanel29.Children;
		OptionControl optionControl83;
		OptionControl optionControl82 = (optionControl83 = new OptionControl());
		((ISupportInitialize)optionControl82).BeginInit();
		children49.Add(optionControl82);
		OptionControl optionControl84 = (optionControl4 = optionControl83);
		context.PushParent(optionControl4);
		OptionControl optionControl85 = optionControl4;
		optionControl85.Header = Strings.Menu_GlobalSettings_PerfStats_Title;
		optionControl85.Description = Strings.Menu_GlobalSettings_PerfStats_Description;
		ToggleSwitch toggleSwitch31;
		ToggleSwitch toggleSwitch30 = (toggleSwitch31 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch30).BeginInit();
		optionControl85.InnerContent = toggleSwitch30;
		ToggleSwitch toggleSwitch32 = (toggleSwitch4 = toggleSwitch31);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch33 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty8 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension33 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EPerformanceStatsVisible_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding32 = compiledBindingExtension33.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch33.Bind(isCheckedProperty8, binding32);
		context.PopParent();
		((ISupportInitialize)toggleSwitch32).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl84).EndInit();
		Avalonia.Controls.Controls children50 = stackPanel29.Children;
		OptionControl optionControl87;
		OptionControl optionControl86 = (optionControl87 = new OptionControl());
		((ISupportInitialize)optionControl86).BeginInit();
		children50.Add(optionControl86);
		OptionControl optionControl88 = (optionControl4 = optionControl87);
		context.PushParent(optionControl4);
		OptionControl optionControl89 = optionControl4;
		optionControl89.Header = Strings.Menu_GlobalSettings_VRMode_Title;
		optionControl89.Description = Strings.Menu_GlobalSettings_VRMode_Description;
		ToggleSwitch toggleSwitch35;
		ToggleSwitch toggleSwitch34 = (toggleSwitch35 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch34).BeginInit();
		optionControl89.InnerContent = toggleSwitch34;
		ToggleSwitch toggleSwitch36 = (toggleSwitch4 = toggleSwitch35);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch37 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty9 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension34 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EGlobalSettingsViewModel_002CMerostrap_002EVREnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding33 = compiledBindingExtension34.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch37.Bind(isCheckedProperty9, binding33);
		context.PopParent();
		((ISupportInitialize)toggleSwitch36).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl88).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel28).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel12).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(GlobalSettingsPage P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
