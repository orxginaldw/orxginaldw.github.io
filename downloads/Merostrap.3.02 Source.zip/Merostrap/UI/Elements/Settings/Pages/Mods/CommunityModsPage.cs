using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Documents;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Data.Converters;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Styling;
using CompiledAvaloniaXaml;
using FluentAvalonia.UI.Controls;
using LucideAvalonia.Enum;
using Merostrap.Enums;
using Merostrap.Models.APIs.Config;
using Merostrap.Resources;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.ViewModels.Settings;
using Merostrap.UI.ViewModels.Settings.Mods;

namespace Merostrap.UI.Elements.Settings.Pages.Mods;

internal class CommunityModsPage : UserControl
{
	[CompilerGenerated]
	private class XamlClosure_49
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<CommunityModsPage> context = CreateContext(P_0);
			context.IntermediateRoot = new UniformWrapPanel();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((AvaloniaObject)obj).SetValue(UniformWrapPanel.MinItemWidthProperty, 270.0, BindingPriority.Template);
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<CommunityModsPage> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<CommunityModsPage> context = new XamlIlContext.Context<CommunityModsPage>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FPages_002FMods_002FCommunityModsPage_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/Pages/Mods/CommunityModsPage.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (CommunityModsPage)service;
				}
			}
			return context;
		}

		public static object Build_2(IServiceProvider P_0)
		{
			XamlIlContext.Context<CommunityModsPage> context = CreateContext(P_0);
			context.IntermediateRoot = new Card();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Card card = (Card)obj;
			context.PushParent(card);
			card.VerticalAlignment = VerticalAlignment.Top;
			card.Height = 270.0;
			card.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
			card.HorizontalAlignment = HorizontalAlignment.Stretch;
			card.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
			card.CornerRadius = new CornerRadius(8.0, 8.0, 8.0, 8.0);
			card.ClipToBounds = true;
			Grid grid2;
			Grid grid = (grid2 = new Grid());
			((ISupportInitialize)grid).BeginInit();
			card.Content = grid;
			Grid grid4;
			Grid grid3 = (grid4 = grid2);
			context.PushParent(grid4);
			Grid grid5 = grid4;
			RowDefinitions rowDefinitions = new RowDefinitions();
			rowDefinitions.Capacity = 4;
			rowDefinitions.Add(new RowDefinition(new GridLength(140.0, GridUnitType.Pixel)));
			rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
			rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
			rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid5.RowDefinitions = rowDefinitions;
			Avalonia.Controls.Controls children = grid5.Children;
			Border border2;
			Border border = (border2 = new Border());
			((ISupportInitialize)border).BeginInit();
			children.Add(border);
			Border border4;
			Border border3 = (border4 = border2);
			context.PushParent(border4);
			Grid.SetRow(border4, 0);
			border4.CornerRadius = new CornerRadius(8.0, 8.0, 0.0, 0.0);
			border4.ClipToBounds = true;
			Grid grid7;
			Grid grid6 = (grid7 = new Grid());
			((ISupportInitialize)grid6).BeginInit();
			border4.Child = grid6;
			Grid grid8 = (grid4 = grid7);
			context.PushParent(grid4);
			Avalonia.Controls.Controls children2 = grid4.Children;
			Image image2;
			Image image = (image2 = new Image());
			((ISupportInitialize)image).BeginInit();
			children2.Add(image);
			Image image4;
			Image image3 = (image4 = image2);
			context.PushParent(image4);
			StyledProperty<IImage?> sourceProperty = Image.SourceProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EAPIs_002EConfig_002ECommunityMod_002CMerostrap_002EThumbnail_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Image.SourceProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			image4.Bind(sourceProperty, binding);
			image4.Stretch = Stretch.UniformToFill;
			image4.HorizontalAlignment = HorizontalAlignment.Stretch;
			image4.VerticalAlignment = VerticalAlignment.Stretch;
			RenderOptions.SetBitmapInterpolationMode(image4, BitmapInterpolationMode.HighQuality);
			context.PopParent();
			((ISupportInitialize)image3).EndInit();
			context.PopParent();
			((ISupportInitialize)grid8).EndInit();
			context.PopParent();
			((ISupportInitialize)border3).EndInit();
			Avalonia.Controls.Controls children3 = grid5.Children;
			TextBlock textBlock2;
			TextBlock textBlock = (textBlock2 = new TextBlock());
			((ISupportInitialize)textBlock).BeginInit();
			children3.Add(textBlock);
			TextBlock textBlock4;
			TextBlock textBlock3 = (textBlock4 = textBlock2);
			context.PushParent(textBlock4);
			TextBlock textBlock5 = textBlock4;
			Grid.SetRow(textBlock5, 1);
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EAPIs_002EConfig_002ECommunityMod_002CMerostrap_002EName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock5.Bind(textProperty, binding2);
			textBlock5.FontWeight = FontWeight.Bold;
			textBlock5.FontSize = 16.0;
			textBlock5.Margin = new Thickness(12.0, 8.0, 12.0, 0.0);
			textBlock5.TextTrimming = TextTrimming.CharacterEllipsis;
			context.PopParent();
			((ISupportInitialize)textBlock3).EndInit();
			Avalonia.Controls.Controls children4 = grid5.Children;
			TextBlock textBlock7;
			TextBlock textBlock6 = (textBlock7 = new TextBlock());
			((ISupportInitialize)textBlock6).BeginInit();
			children4.Add(textBlock6);
			TextBlock textBlock8 = (textBlock4 = textBlock7);
			context.PushParent(textBlock4);
			TextBlock textBlock9 = textBlock4;
			Grid.SetRow(textBlock9, 2);
			StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("TextFillColorSecondaryBrush");
			context.ProvideTargetProperty = TextBlock.ForegroundProperty;
			BindingBase binding3 = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock9.Bind(foregroundProperty, binding3);
			textBlock9.FontSize = 12.0;
			textBlock9.Margin = new Thickness(12.0, 2.0, 12.0, 4.0);
			textBlock9.TextTrimming = TextTrimming.CharacterEllipsis;
			InlineCollection? inlines = textBlock9.Inlines;
			Run run = new Run();
			((ISupportInitialize)run).BeginInit();
			run.Text = "By: ";
			((ISupportInitialize)run).EndInit();
			inlines.Add(run);
			textBlock9.Inlines.Add(" ");
			InlineCollection? inlines2 = textBlock9.Inlines;
			Run run2 = new Run();
			((ISupportInitialize)run2).BeginInit();
			Run run3 = run2;
			context.PushParent(run3);
			Run run4 = run3;
			StyledProperty<string?> textProperty2 = Run.TextProperty;
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EAPIs_002EConfig_002ECommunityMod_002CMerostrap_002EAuthor_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Run.TextProperty;
			CompiledBinding binding4 = compiledBindingExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			run4.Bind(textProperty2, binding4);
			run4.FontWeight = FontWeight.DemiBold;
			context.PopParent();
			((ISupportInitialize)run2).EndInit();
			inlines2.Add(run2);
			textBlock9.Inlines.Add(" ");
			InlineCollection? inlines3 = textBlock9.Inlines;
			Run run5 = new Run();
			((ISupportInitialize)run5).BeginInit();
			run5.Text = " | ";
			((ISupportInitialize)run5).EndInit();
			inlines3.Add(run5);
			textBlock9.Inlines.Add(" ");
			InlineCollection? inlines4 = textBlock9.Inlines;
			Run run6 = new Run();
			((ISupportInitialize)run6).BeginInit();
			run3 = run6;
			context.PushParent(run3);
			Run run7 = run3;
			StyledProperty<string?> textProperty3 = Run.TextProperty;
			CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EAPIs_002EConfig_002ECommunityMod_002CMerostrap_002EModTypeDisplay_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
			{
				Mode = BindingMode.OneWay
			};
			context.ProvideTargetProperty = Run.TextProperty;
			CompiledBinding binding5 = compiledBindingExtension4.ProvideValue(context);
			context.ProvideTargetProperty = null;
			run7.Bind(textProperty3, binding5);
			context.PopParent();
			((ISupportInitialize)run6).EndInit();
			inlines4.Add(run6);
			context.PopParent();
			((ISupportInitialize)textBlock8).EndInit();
			Avalonia.Controls.Controls children5 = grid5.Children;
			Grid grid10;
			Grid grid9 = (grid10 = new Grid());
			((ISupportInitialize)grid9).BeginInit();
			children5.Add(grid9);
			Grid grid11 = (grid4 = grid10);
			context.PushParent(grid4);
			Grid grid12 = grid4;
			Grid.SetRow(grid12, 3);
			grid12.Margin = new Thickness(8.0, 8.0, 8.0, 8.0);
			grid12.VerticalAlignment = VerticalAlignment.Bottom;
			RowDefinitions rowDefinitions2 = new RowDefinitions();
			rowDefinitions2.Capacity = 2;
			rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
			rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid12.RowDefinitions = rowDefinitions2;
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 2;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid12.ColumnDefinitions = columnDefinitions;
			Avalonia.Controls.Controls children6 = grid12.Children;
			ProgressBar progressBar2;
			ProgressBar progressBar = (progressBar2 = new ProgressBar());
			((ISupportInitialize)progressBar).BeginInit();
			children6.Add(progressBar);
			ProgressBar progressBar4;
			ProgressBar progressBar3 = (progressBar4 = progressBar2);
			context.PushParent(progressBar4);
			Grid.SetRow(progressBar4, 0);
			Grid.SetColumnSpan(progressBar4, 2);
			progressBar4.Margin = new Thickness(0.0, 0.0, 0.0, 8.0);
			StyledProperty<double> valueProperty = RangeBase.ValueProperty;
			CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EAPIs_002EConfig_002ECommunityMod_002CMerostrap_002EDownloadProgress_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = RangeBase.ValueProperty;
			CompiledBinding binding6 = compiledBindingExtension5.ProvideValue(context);
			context.ProvideTargetProperty = null;
			progressBar4.Bind(valueProperty, binding6);
			progressBar4.Maximum = 100.0;
			progressBar4.Height = 4.0;
			StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EAPIs_002EConfig_002ECommunityMod_002CMerostrap_002EIsDownloading_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding7 = compiledBindingExtension6.ProvideValue(context);
			context.ProvideTargetProperty = null;
			progressBar4.Bind(isVisibleProperty, binding7);
			context.PopParent();
			((ISupportInitialize)progressBar3).EndInit();
			Avalonia.Controls.Controls children7 = grid12.Children;
			IconButton iconButton2;
			IconButton iconButton = (iconButton2 = new IconButton());
			((ISupportInitialize)iconButton).BeginInit();
			children7.Add(iconButton);
			IconButton iconButton4;
			IconButton iconButton3 = (iconButton4 = iconButton2);
			context.PushParent(iconButton4);
			IconButton iconButton5 = iconButton4;
			Grid.SetColumn(iconButton5, 0);
			Grid.SetRow(iconButton5, 1);
			iconButton5.Height = 34.0;
			iconButton5.HorizontalAlignment = HorizontalAlignment.Stretch;
			iconButton5.Content = Strings.Common_Download;
			iconButton5.Icon = LucideIconNames.Download;
			iconButton5.Classes.Add("Primary");
			StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EAPIs_002EConfig_002ECommunityMod_002CMerostrap_002EDownloadCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Button.CommandProperty;
			CompiledBinding binding8 = compiledBindingExtension7.ProvideValue(context);
			context.ProvideTargetProperty = null;
			iconButton5.Bind(commandProperty, binding8);
			CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension();
			context.ProvideTargetProperty = Button.CommandParameterProperty;
			CompiledBinding compiledBinding = compiledBindingExtension8.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_6(iconButton5, compiledBinding);
			context.PopParent();
			((ISupportInitialize)iconButton3).EndInit();
			Avalonia.Controls.Controls children8 = grid12.Children;
			IconButton iconButton7;
			IconButton iconButton6 = (iconButton7 = new IconButton());
			((ISupportInitialize)iconButton6).BeginInit();
			children8.Add(iconButton6);
			IconButton iconButton8 = (iconButton4 = iconButton7);
			context.PushParent(iconButton4);
			IconButton iconButton9 = iconButton4;
			Grid.SetColumn(iconButton9, 1);
			Grid.SetRow(iconButton9, 1);
			iconButton9.Height = 34.0;
			iconButton9.Margin = new Thickness(2.0, 0.0, 0.0, 0.0);
			iconButton9.Icon = LucideIconNames.Info;
			StyledProperty<ICommand?> commandProperty2 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Ancestor(typeof(UserControl), 0).Property(StyledElement.DataContextProperty, PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor).TypeCast<CommunityModsViewModel>()
				.Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002ECommunityModsViewModel_002CMerostrap_002EOpenModInfoDialogCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)
				.Build());
			context.ProvideTargetProperty = Button.CommandProperty;
			CompiledBinding binding9 = compiledBindingExtension9.ProvideValue(context);
			context.ProvideTargetProperty = null;
			iconButton9.Bind(commandProperty2, binding9);
			CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Self().Build());
			context.ProvideTargetProperty = Button.CommandParameterProperty;
			CompiledBinding compiledBinding2 = compiledBindingExtension10.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_6(iconButton9, compiledBinding2);
			context.PopParent();
			((ISupportInitialize)iconButton8).EndInit();
			context.PopParent();
			((ISupportInitialize)grid11).EndInit();
			context.PopParent();
			((ISupportInitialize)grid3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}
	}

	private CommunityModsDialogService? _dialogService;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public CommunityModsPage()
	{
		InitializeComponent();
		App.FrostRPC?.SetPage("Community Mods");
		DataContextChanged += OnDataContextChanged;
	}

	private void OnDataContextChanged(object? sender, EventArgs e)
	{
		if (DataContext is CommunityModsViewModel communityModsViewModel)
		{
			communityModsViewModel.OpenPresetModsEvent -= OnOpenPresetMods;
			communityModsViewModel.OpenModsEvent -= OnOpenMods;
			communityModsViewModel.OpenModGeneratorEvent -= OnOpenModGenerator;
			communityModsViewModel.OpenPresetModsEvent += OnOpenPresetMods;
			communityModsViewModel.OpenModsEvent += OnOpenMods;
			communityModsViewModel.OpenModGeneratorEvent += OnOpenModGenerator;
		}
	}

	private void OnOpenPresetMods(object? sender, EventArgs e)
	{
		EnsureDialogService()?.OpenPresetMods();
	}

	private void OnOpenMods(object? sender, EventArgs e)
	{
		EnsureDialogService()?.OpenMods();
	}

	private void OnOpenModGenerator(object? sender, EventArgs e)
	{
		EnsureDialogService()?.OpenModGenerator();
	}

	private CommunityModsDialogService? EnsureDialogService()
	{
		if (_dialogService != null)
		{
			return _dialogService;
		}
		if (TopLevel.GetTopLevel(this)?.DataContext is MainWindowViewModel mainVm)
		{
			_dialogService = new CommunityModsDialogService(mainVm);
		}
		return _dialogService;
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, CommunityModsPage P_1)
	{
		XamlIlContext.Context<CommunityModsPage> context = new XamlIlContext.Context<CommunityModsPage>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FPages_002FMods_002FCommunityModsPage_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/Pages/Mods/CommunityModsPage.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		Styles styles = P_1.Styles;
		Style style;
		Style item = (style = new Style());
		context.PushParent(style);
		style.Selector = ((Selector?)null).OfType(typeof(WrapPanel)).Class("FilterBar").Child()
			.OfType(typeof(ToggleButton));
		Setter setter = new Setter();
		setter.Property = Layoutable.MarginProperty;
		setter.Value = new Thickness(4.0, 4.0, 4.0, 4.0);
		style.Add(setter);
		Setter setter2 = new Setter();
		setter2.Property = TemplatedControl.PaddingProperty;
		setter2.Value = new Thickness(12.0, 6.0, 12.0, 6.0);
		style.Add(setter2);
		Setter setter4;
		Setter setter3 = (setter4 = new Setter());
		context.PushParent(setter4);
		setter4.Property = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Ancestor(typeof(UserControl), 0).Property(StyledElement.DataContextProperty, PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor).TypeCast<CommunityModsViewModel>()
			.Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002ECommunityModsViewModel_002CMerostrap_002ESetFilterCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)
			.Build());
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		CompiledBinding value = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter4.Value = value;
		context.PopParent();
		style.Add(setter3);
		context.PopParent();
		styles.Add(item);
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		P_1.Content = scrollViewer;
		ScrollViewer scrollViewer4;
		ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
		context.PushParent(scrollViewer4);
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		scrollViewer4.Content = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		StackPanel stackPanel5 = stackPanel4;
		stackPanel5.Margin = new Thickness(14.0, 14.0, 14.0, 14.0);
		Avalonia.Controls.Controls children = stackPanel5.Children;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		children.Add(grid);
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 3;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid5.ColumnDefinitions = columnDefinitions;
		Avalonia.Controls.Controls children2 = grid5.Children;
		CardAction cardAction2;
		CardAction cardAction = (cardAction2 = new CardAction());
		((ISupportInitialize)cardAction).BeginInit();
		children2.Add(cardAction);
		CardAction cardAction4;
		CardAction cardAction3 = (cardAction4 = cardAction2);
		context.PushParent(cardAction4);
		CardAction cardAction5 = cardAction4;
		Grid.SetColumn(cardAction5, 0);
		cardAction5.Margin = new Thickness(0.0, 0.0, 4.0, 0.0);
		cardAction5.Header = Strings.Menu_PresetMods_Title;
		cardAction5.Icon = LucideIconNames.BookOpen;
		cardAction5.Description = Strings.Menu_PresetMods_Description;
		StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002ECommunityModsViewModel_002CMerostrap_002EOpenPresetModsCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		cardAction5.Bind(commandProperty, binding);
		context.PopParent();
		((ISupportInitialize)cardAction3).EndInit();
		Avalonia.Controls.Controls children3 = grid5.Children;
		CardAction cardAction7;
		CardAction cardAction6 = (cardAction7 = new CardAction());
		((ISupportInitialize)cardAction6).BeginInit();
		children3.Add(cardAction6);
		CardAction cardAction8 = (cardAction4 = cardAction7);
		context.PushParent(cardAction4);
		CardAction cardAction9 = cardAction4;
		Grid.SetColumn(cardAction9, 1);
		cardAction9.Margin = new Thickness(2.0, 0.0, 2.0, 0.0);
		cardAction9.Header = Strings.Menu_Mods_Title;
		cardAction9.Icon = LucideIconNames.List;
		cardAction9.Description = Strings.Menu_Mods_Description;
		StyledProperty<ICommand?> commandProperty2 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002ECommunityModsViewModel_002CMerostrap_002EOpenModsCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding2 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		cardAction9.Bind(commandProperty2, binding2);
		context.PopParent();
		((ISupportInitialize)cardAction8).EndInit();
		Avalonia.Controls.Controls children4 = grid5.Children;
		CardAction cardAction11;
		CardAction cardAction10 = (cardAction11 = new CardAction());
		((ISupportInitialize)cardAction10).BeginInit();
		children4.Add(cardAction10);
		CardAction cardAction12 = (cardAction4 = cardAction11);
		context.PushParent(cardAction4);
		CardAction cardAction13 = cardAction4;
		Grid.SetColumn(cardAction13, 2);
		cardAction13.Margin = new Thickness(4.0, 0.0, 0.0, 0.0);
		cardAction13.Header = Strings.Menu_ModGenerator_Title;
		cardAction13.Icon = LucideIconNames.PaintbrushVertical;
		cardAction13.Description = Strings.Menu_ModGenerator_Description;
		StyledProperty<ICommand?> commandProperty3 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002ECommunityModsViewModel_002CMerostrap_002EOpenModGeneratorCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding3 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		cardAction13.Bind(commandProperty3, binding3);
		context.PopParent();
		((ISupportInitialize)cardAction12).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		Avalonia.Controls.Controls children5 = stackPanel5.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children5.Add(border);
		border2.Height = 12.0;
		((ISupportInitialize)border2).EndInit();
		Avalonia.Controls.Controls children6 = stackPanel5.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children6.Add(grid6);
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002ECommunityModsViewModel_002CMerostrap_002EIsLoading_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding4 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		grid9.Bind(isVisibleProperty, binding4);
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 3;
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid9.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children7 = grid9.Children;
		StackPanel stackPanel7;
		StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
		((ISupportInitialize)stackPanel6).BeginInit();
		children7.Add(stackPanel6);
		StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
		context.PushParent(stackPanel4);
		StackPanel stackPanel9 = stackPanel4;
		Grid.SetRow(stackPanel9, 0);
		stackPanel9.Margin = new Thickness(0.0, 0.0, 0.0, 8.0);
		Avalonia.Controls.Controls children8 = stackPanel9.Children;
		TextBox textBox2;
		TextBox textBox = (textBox2 = new TextBox());
		((ISupportInitialize)textBox).BeginInit();
		children8.Add(textBox);
		TextBox textBox4;
		TextBox textBox3 = (textBox4 = textBox2);
		context.PushParent(textBox4);
		textBox4.PlaceholderText = Strings.Menu_CommunityMods_SearchMods;
		StyledProperty<string?> textProperty = TextBox.TextProperty;
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002ECommunityModsViewModel_002CMerostrap_002ESearchQuery_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
		};
		context.ProvideTargetProperty = TextBox.TextProperty;
		CompiledBinding binding5 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBox4.Bind(textProperty, binding5);
		textBox4.Margin = new Thickness(4.0, 0.0, 12.0, 0.0);
		context.PopParent();
		((ISupportInitialize)textBox3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel8).EndInit();
		Avalonia.Controls.Controls children9 = grid9.Children;
		WrapPanel wrapPanel2;
		WrapPanel wrapPanel = (wrapPanel2 = new WrapPanel());
		((ISupportInitialize)wrapPanel).BeginInit();
		children9.Add(wrapPanel);
		WrapPanel wrapPanel4;
		WrapPanel wrapPanel3 = (wrapPanel4 = wrapPanel2);
		context.PushParent(wrapPanel4);
		Grid.SetRow(wrapPanel4, 1);
		wrapPanel4.Orientation = Orientation.Horizontal;
		wrapPanel4.Margin = new Thickness(0.0, 0.0, 0.0, 8.0);
		wrapPanel4.Classes.Add("FilterBar");
		Avalonia.Controls.Controls children10 = wrapPanel4.Children;
		ToggleButton toggleButton2;
		ToggleButton toggleButton = (toggleButton2 = new ToggleButton());
		((ISupportInitialize)toggleButton).BeginInit();
		children10.Add(toggleButton);
		ToggleButton toggleButton4;
		ToggleButton toggleButton3 = (toggleButton4 = toggleButton2);
		context.PushParent(toggleButton4);
		ToggleButton toggleButton5 = toggleButton4;
		toggleButton5.Content = Strings.Common_All;
		StyledProperty<ICommand?> commandProperty4 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002ECommunityModsViewModel_002CMerostrap_002ESetFilterCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding6 = compiledBindingExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleButton5.Bind(commandProperty4, binding6);
		toggleButton5.CommandParameter = null;
		StyledProperty<bool?> isCheckedProperty = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002ECommunityModsViewModel_002CMerostrap_002EActiveFilter_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		compiledBindingExtension8.Mode = BindingMode.OneWay;
		compiledBindingExtension8.Converter = ObjectConverters.IsNull;
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding7 = compiledBindingExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleButton5.Bind(isCheckedProperty, binding7);
		context.PopParent();
		((ISupportInitialize)toggleButton3).EndInit();
		Avalonia.Controls.Controls children11 = wrapPanel4.Children;
		ToggleButton toggleButton7;
		ToggleButton toggleButton6 = (toggleButton7 = new ToggleButton());
		((ISupportInitialize)toggleButton6).BeginInit();
		children11.Add(toggleButton6);
		ToggleButton toggleButton8 = (toggleButton4 = toggleButton7);
		context.PushParent(toggleButton4);
		ToggleButton toggleButton9 = toggleButton4;
		toggleButton9.Content = Strings.Menu_CommunityMods_ColorMods;
		StyledProperty<ICommand?> commandProperty5 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002ECommunityModsViewModel_002CMerostrap_002ESetFilterCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding8 = compiledBindingExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleButton9.Bind(commandProperty5, binding8);
		toggleButton9.CommandParameter = ModType.ColorMod;
		StyledProperty<bool?> isCheckedProperty2 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension11;
		CompiledBindingExtension compiledBindingExtension10 = (compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002ECommunityModsViewModel_002CMerostrap_002EActiveFilter_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build()));
		context.PushParent(compiledBindingExtension11);
		CompiledBindingExtension compiledBindingExtension12 = compiledBindingExtension11;
		compiledBindingExtension12.Mode = BindingMode.OneWay;
		StaticResourceExtension staticResourceExtension = new StaticResourceExtension("EnumToBoolConverter");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EData_002ECompiledBinding_002CAvalonia_002EBase_002EConverter_0021Property();
		object? obj = staticResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		compiledBindingExtension12.Converter = (IValueConverter)obj;
		compiledBindingExtension12.ConverterParameter = ModType.ColorMod;
		context.PopParent();
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding9 = compiledBindingExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleButton9.Bind(isCheckedProperty2, binding9);
		context.PopParent();
		((ISupportInitialize)toggleButton8).EndInit();
		Avalonia.Controls.Controls children12 = wrapPanel4.Children;
		ToggleButton toggleButton11;
		ToggleButton toggleButton10 = (toggleButton11 = new ToggleButton());
		((ISupportInitialize)toggleButton10).BeginInit();
		children12.Add(toggleButton10);
		ToggleButton toggleButton12 = (toggleButton4 = toggleButton11);
		context.PushParent(toggleButton4);
		ToggleButton toggleButton13 = toggleButton4;
		toggleButton13.Content = Strings.Menu_CommunityMods_Themes;
		StyledProperty<ICommand?> commandProperty6 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002ECommunityModsViewModel_002CMerostrap_002ESetFilterCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding10 = compiledBindingExtension13.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleButton13.Bind(commandProperty6, binding10);
		toggleButton13.CommandParameter = ModType.CustomTheme;
		StyledProperty<bool?> isCheckedProperty3 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension14 = (compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002ECommunityModsViewModel_002CMerostrap_002EActiveFilter_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build()));
		context.PushParent(compiledBindingExtension11);
		CompiledBindingExtension compiledBindingExtension15 = compiledBindingExtension11;
		compiledBindingExtension15.Mode = BindingMode.OneWay;
		StaticResourceExtension staticResourceExtension2 = new StaticResourceExtension("EnumToBoolConverter");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EData_002ECompiledBinding_002CAvalonia_002EBase_002EConverter_0021Property();
		object? obj2 = staticResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		compiledBindingExtension15.Converter = (IValueConverter)obj2;
		compiledBindingExtension15.ConverterParameter = ModType.CustomTheme;
		context.PopParent();
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding11 = compiledBindingExtension14.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleButton13.Bind(isCheckedProperty3, binding11);
		context.PopParent();
		((ISupportInitialize)toggleButton12).EndInit();
		Avalonia.Controls.Controls children13 = wrapPanel4.Children;
		ToggleButton toggleButton15;
		ToggleButton toggleButton14 = (toggleButton15 = new ToggleButton());
		((ISupportInitialize)toggleButton14).BeginInit();
		children13.Add(toggleButton14);
		ToggleButton toggleButton16 = (toggleButton4 = toggleButton15);
		context.PushParent(toggleButton4);
		ToggleButton toggleButton17 = toggleButton4;
		toggleButton17.Content = Strings.Menu_CommunityMods_Misc;
		StyledProperty<ICommand?> commandProperty7 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension16 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002ECommunityModsViewModel_002CMerostrap_002ESetFilterCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding12 = compiledBindingExtension16.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleButton17.Bind(commandProperty7, binding12);
		toggleButton17.CommandParameter = ModType.MiscMod;
		StyledProperty<bool?> isCheckedProperty4 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension17 = (compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002ECommunityModsViewModel_002CMerostrap_002EActiveFilter_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build()));
		context.PushParent(compiledBindingExtension11);
		CompiledBindingExtension compiledBindingExtension18 = compiledBindingExtension11;
		compiledBindingExtension18.Mode = BindingMode.OneWay;
		StaticResourceExtension staticResourceExtension3 = new StaticResourceExtension("EnumToBoolConverter");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EData_002ECompiledBinding_002CAvalonia_002EBase_002EConverter_0021Property();
		object? obj3 = staticResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		compiledBindingExtension18.Converter = (IValueConverter)obj3;
		compiledBindingExtension18.ConverterParameter = ModType.MiscMod;
		context.PopParent();
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding13 = compiledBindingExtension17.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleButton17.Bind(isCheckedProperty4, binding13);
		context.PopParent();
		((ISupportInitialize)toggleButton16).EndInit();
		Avalonia.Controls.Controls children14 = wrapPanel4.Children;
		ToggleButton toggleButton19;
		ToggleButton toggleButton18 = (toggleButton19 = new ToggleButton());
		((ISupportInitialize)toggleButton18).BeginInit();
		children14.Add(toggleButton18);
		ToggleButton toggleButton20 = (toggleButton4 = toggleButton19);
		context.PushParent(toggleButton4);
		ToggleButton toggleButton21 = toggleButton4;
		toggleButton21.Content = Strings.Menu_CommunityMods_SkyBox;
		StyledProperty<ICommand?> commandProperty8 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension19 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002ECommunityModsViewModel_002CMerostrap_002ESetFilterCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding14 = compiledBindingExtension19.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleButton21.Bind(commandProperty8, binding14);
		toggleButton21.CommandParameter = ModType.SkyBox;
		StyledProperty<bool?> isCheckedProperty5 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension20 = (compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002ECommunityModsViewModel_002CMerostrap_002EActiveFilter_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build()));
		context.PushParent(compiledBindingExtension11);
		CompiledBindingExtension compiledBindingExtension21 = compiledBindingExtension11;
		compiledBindingExtension21.Mode = BindingMode.OneWay;
		StaticResourceExtension staticResourceExtension4 = new StaticResourceExtension("EnumToBoolConverter");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EData_002ECompiledBinding_002CAvalonia_002EBase_002EConverter_0021Property();
		object? obj4 = staticResourceExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		compiledBindingExtension21.Converter = (IValueConverter)obj4;
		compiledBindingExtension21.ConverterParameter = ModType.SkyBox;
		context.PopParent();
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding15 = compiledBindingExtension20.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleButton21.Bind(isCheckedProperty5, binding15);
		context.PopParent();
		((ISupportInitialize)toggleButton20).EndInit();
		Avalonia.Controls.Controls children15 = wrapPanel4.Children;
		ToggleButton toggleButton23;
		ToggleButton toggleButton22 = (toggleButton23 = new ToggleButton());
		((ISupportInitialize)toggleButton22).BeginInit();
		children15.Add(toggleButton22);
		ToggleButton toggleButton24 = (toggleButton4 = toggleButton23);
		context.PushParent(toggleButton4);
		ToggleButton toggleButton25 = toggleButton4;
		toggleButton25.Content = Strings.Menu_CommunityMods_Cursor;
		StyledProperty<ICommand?> commandProperty9 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension22 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002ECommunityModsViewModel_002CMerostrap_002ESetFilterCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding16 = compiledBindingExtension22.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleButton25.Bind(commandProperty9, binding16);
		toggleButton25.CommandParameter = ModType.Cursor;
		StyledProperty<bool?> isCheckedProperty6 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension23 = (compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002ECommunityModsViewModel_002CMerostrap_002EActiveFilter_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build()));
		context.PushParent(compiledBindingExtension11);
		CompiledBindingExtension compiledBindingExtension24 = compiledBindingExtension11;
		compiledBindingExtension24.Mode = BindingMode.OneWay;
		StaticResourceExtension staticResourceExtension5 = new StaticResourceExtension("EnumToBoolConverter");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EData_002ECompiledBinding_002CAvalonia_002EBase_002EConverter_0021Property();
		object? obj5 = staticResourceExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		compiledBindingExtension24.Converter = (IValueConverter)obj5;
		compiledBindingExtension24.ConverterParameter = ModType.Cursor;
		context.PopParent();
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding17 = compiledBindingExtension23.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleButton25.Bind(isCheckedProperty6, binding17);
		context.PopParent();
		((ISupportInitialize)toggleButton24).EndInit();
		Avalonia.Controls.Controls children16 = wrapPanel4.Children;
		ToggleButton toggleButton27;
		ToggleButton toggleButton26 = (toggleButton27 = new ToggleButton());
		((ISupportInitialize)toggleButton26).BeginInit();
		children16.Add(toggleButton26);
		ToggleButton toggleButton28 = (toggleButton4 = toggleButton27);
		context.PushParent(toggleButton4);
		ToggleButton toggleButton29 = toggleButton4;
		toggleButton29.Content = Strings.Menu_CommunityMods_AvatarEditor;
		StyledProperty<ICommand?> commandProperty10 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension25 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002ECommunityModsViewModel_002CMerostrap_002ESetFilterCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding18 = compiledBindingExtension25.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleButton29.Bind(commandProperty10, binding18);
		toggleButton29.CommandParameter = ModType.AvatarEditor;
		StyledProperty<bool?> isCheckedProperty7 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension26 = (compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002ECommunityModsViewModel_002CMerostrap_002EActiveFilter_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build()));
		context.PushParent(compiledBindingExtension11);
		CompiledBindingExtension compiledBindingExtension27 = compiledBindingExtension11;
		compiledBindingExtension27.Mode = BindingMode.OneWay;
		StaticResourceExtension staticResourceExtension6 = new StaticResourceExtension("EnumToBoolConverter");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EData_002ECompiledBinding_002CAvalonia_002EBase_002EConverter_0021Property();
		object? obj6 = staticResourceExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		compiledBindingExtension27.Converter = (IValueConverter)obj6;
		compiledBindingExtension27.ConverterParameter = ModType.AvatarEditor;
		context.PopParent();
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding19 = compiledBindingExtension26.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleButton29.Bind(isCheckedProperty7, binding19);
		context.PopParent();
		((ISupportInitialize)toggleButton28).EndInit();
		context.PopParent();
		((ISupportInitialize)wrapPanel3).EndInit();
		Avalonia.Controls.Controls children17 = grid9.Children;
		ItemsControl itemsControl2;
		ItemsControl itemsControl = (itemsControl2 = new ItemsControl());
		((ISupportInitialize)itemsControl).BeginInit();
		children17.Add(itemsControl);
		ItemsControl itemsControl4;
		ItemsControl itemsControl3 = (itemsControl4 = itemsControl2);
		context.PushParent(itemsControl4);
		Grid.SetRow(itemsControl4, 2);
		StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension28 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002ECommunityModsViewModel_002CMerostrap_002EMods_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding20 = compiledBindingExtension28.ProvideValue(context);
		context.ProvideTargetProperty = null;
		itemsControl4.Bind(itemsSourceProperty, binding20);
		itemsControl4.ItemsPanel = new ItemsPanelTemplate
		{
			Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_49.Build_1), context)
		};
		DataTemplate dataTemplate;
		DataTemplate itemTemplate = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.DataType = typeof(CommunityMod);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_49.Build_2), context);
		context.PopParent();
		itemsControl4.ItemTemplate = itemTemplate;
		context.PopParent();
		((ISupportInitialize)itemsControl3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(CommunityModsPage P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
