using System;
using System.Threading.Tasks;
using Merostrap.UI.ViewModels.Settings;
using Merostrap.UI.ViewModels.Settings.Mods;

namespace Merostrap.UI.Elements.Settings.Pages.Mods;

internal class ModsDialogService(MainWindowViewModel mainVm) : IModsDialogService
{
	private readonly MainWindowViewModel _mainVm = mainVm ?? throw new ArgumentNullException("mainVm");

	public Task OpenCommunityModsAsync()
	{
		_mainVm.NavigateToCommunityModsCommand.Execute(null);
		return Task.CompletedTask;
	}

	public Task OpenPresetModsAsync()
	{
		_mainVm.NavigateToPresetModsCommand.Execute(null);
		return Task.CompletedTask;
	}

	public Task OpenModGeneratorAsync()
	{
		_mainVm.NavigateToModGeneratorCommand.Execute(null);
		return Task.CompletedTask;
	}
}
