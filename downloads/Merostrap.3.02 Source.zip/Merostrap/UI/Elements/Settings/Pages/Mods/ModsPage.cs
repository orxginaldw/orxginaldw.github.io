using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Avalonia;
using Avalonia.Animation;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Controls.Shapes;
using Avalonia.Data;
using Avalonia.Data.Converters;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using Avalonia.Platform.Storage;
using Avalonia.Styling;
using CompiledAvaloniaXaml;
using LucideAvalonia.Enum;
using Merostrap.Models;
using Merostrap.Resources;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.ViewModels.Settings;
using Merostrap.UI.ViewModels.Settings.Mods;

namespace Merostrap.UI.Elements.Settings.Pages.Mods;

internal class ModsPage : UserControl
{
	[CompilerGenerated]
	private class XamlClosure_51
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<ModsPage> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Border border = (Border)obj;
			context.PushParent(border);
			border.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
			border.Padding = new Thickness(8.0, 8.0, 8.0, 8.0);
			border.CornerRadius = new CornerRadius(4.0, 4.0, 4.0, 4.0);
			StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("ControlFillColorDefaultBrush");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border.Bind(backgroundProperty, binding);
			border.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
			StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
			DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("ControlElevationBorderBrush");
			context.ProvideTargetProperty = Border.BorderBrushProperty;
			BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border.Bind(borderBrushProperty, binding2);
			Grid grid2;
			Grid grid = (grid2 = new Grid());
			((ISupportInitialize)grid).BeginInit();
			border.Child = grid;
			Grid grid4;
			Grid grid3 = (grid4 = grid2);
			context.PushParent(grid4);
			grid4.ColumnDefinitions.Add(new ColumnDefinition
			{
				Width = new GridLength(0.0, GridUnitType.Auto)
			});
			grid4.ColumnDefinitions.Add(new ColumnDefinition
			{
				Width = new GridLength(0.0, GridUnitType.Auto)
			});
			grid4.ColumnDefinitions.Add(new ColumnDefinition
			{
				Width = new GridLength(1.0, GridUnitType.Star)
			});
			grid4.ColumnDefinitions.Add(new ColumnDefinition
			{
				Width = new GridLength(0.0, GridUnitType.Auto)
			});
			grid4.ColumnDefinitions.Add(new ColumnDefinition
			{
				Width = new GridLength(0.0, GridUnitType.Auto)
			});
			grid4.RowDefinitions.Add(new RowDefinition
			{
				Height = new GridLength(0.0, GridUnitType.Auto)
			});
			grid4.RowDefinitions.Add(new RowDefinition
			{
				Height = new GridLength(0.0, GridUnitType.Auto)
			});
			Avalonia.Controls.Controls children = grid4.Children;
			IconButton iconButton2;
			IconButton iconButton = (iconButton2 = new IconButton());
			((ISupportInitialize)iconButton).BeginInit();
			children.Add(iconButton);
			IconButton iconButton4;
			IconButton iconButton3 = (iconButton4 = iconButton2);
			context.PushParent(iconButton4);
			IconButton iconButton5 = iconButton4;
			Grid.SetRow(iconButton5, 0);
			Grid.SetColumn(iconButton5, 0);
			iconButton5.Icon = LucideIconNames.ArrowUp;
			iconButton5.Margin = new Thickness(0.0, 0.0, 4.0, 0.0);
			iconButton5.VerticalAlignment = VerticalAlignment.Center;
			StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().VisualAncestor(typeof(ListBox), 0).Property(StyledElement.DataContextProperty, PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor).TypeCast<ModsViewModel>()
				.Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002EMoveUpCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)
				.Build());
			context.ProvideTargetProperty = Button.CommandProperty;
			CompiledBinding binding3 = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			iconButton5.Bind(commandProperty, binding3);
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension();
			context.ProvideTargetProperty = Button.CommandParameterProperty;
			CompiledBinding compiledBinding = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_6(iconButton5, compiledBinding);
			context.PopParent();
			((ISupportInitialize)iconButton3).EndInit();
			Avalonia.Controls.Controls children2 = grid4.Children;
			IconButton iconButton7;
			IconButton iconButton6 = (iconButton7 = new IconButton());
			((ISupportInitialize)iconButton6).BeginInit();
			children2.Add(iconButton6);
			IconButton iconButton8 = (iconButton4 = iconButton7);
			context.PushParent(iconButton4);
			IconButton iconButton9 = iconButton4;
			Grid.SetRow(iconButton9, 0);
			Grid.SetColumn(iconButton9, 1);
			iconButton9.Icon = LucideIconNames.ArrowDown;
			iconButton9.Margin = new Thickness(0.0, 0.0, 4.0, 0.0);
			iconButton9.VerticalAlignment = VerticalAlignment.Center;
			StyledProperty<ICommand?> commandProperty2 = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().VisualAncestor(typeof(ListBox), 0).Property(StyledElement.DataContextProperty, PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor).TypeCast<ModsViewModel>()
				.Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002EMoveDownCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)
				.Build());
			context.ProvideTargetProperty = Button.CommandProperty;
			CompiledBinding binding4 = compiledBindingExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			iconButton9.Bind(commandProperty2, binding4);
			CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension();
			context.ProvideTargetProperty = Button.CommandParameterProperty;
			CompiledBinding compiledBinding2 = compiledBindingExtension4.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_6(iconButton9, compiledBinding2);
			context.PopParent();
			((ISupportInitialize)iconButton8).EndInit();
			Avalonia.Controls.Controls children3 = grid4.Children;
			StackPanel stackPanel2;
			StackPanel stackPanel = (stackPanel2 = new StackPanel());
			((ISupportInitialize)stackPanel).BeginInit();
			children3.Add(stackPanel);
			StackPanel stackPanel4;
			StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
			context.PushParent(stackPanel4);
			StackPanel stackPanel5 = stackPanel4;
			Grid.SetRow(stackPanel5, 0);
			Grid.SetColumn(stackPanel5, 2);
			stackPanel5.VerticalAlignment = VerticalAlignment.Center;
			stackPanel5.Margin = new Thickness(4.0, 0.0, 4.0, 0.0);
			Avalonia.Controls.Controls children4 = stackPanel5.Children;
			TextBlock textBlock2;
			TextBlock textBlock = (textBlock2 = new TextBlock());
			((ISupportInitialize)textBlock).BeginInit();
			children4.Add(textBlock);
			TextBlock textBlock4;
			TextBlock textBlock3 = (textBlock4 = textBlock2);
			context.PushParent(textBlock4);
			TextBlock textBlock5 = textBlock4;
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EModConfig_002CMerostrap_002EFolderName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding5 = compiledBindingExtension5.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock5.Bind(textProperty, binding5);
			textBlock5.FontWeight = FontWeight.Medium;
			textBlock5.TextTrimming = TextTrimming.CharacterEllipsis;
			context.PopParent();
			((ISupportInitialize)textBlock3).EndInit();
			Avalonia.Controls.Controls children5 = stackPanel5.Children;
			StackPanel stackPanel7;
			StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
			((ISupportInitialize)stackPanel6).BeginInit();
			children5.Add(stackPanel6);
			StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
			context.PushParent(stackPanel4);
			StackPanel stackPanel9 = stackPanel4;
			stackPanel9.Orientation = Orientation.Horizontal;
			stackPanel9.Spacing = 8.0;
			stackPanel9.Margin = new Thickness(0.0, 2.0, 0.0, 0.0);
			Avalonia.Controls.Controls children6 = stackPanel9.Children;
			TextBlock textBlock7;
			TextBlock textBlock6 = (textBlock7 = new TextBlock());
			((ISupportInitialize)textBlock6).BeginInit();
			children6.Add(textBlock6);
			TextBlock textBlock8 = (textBlock4 = textBlock7);
			context.PushParent(textBlock4);
			TextBlock textBlock9 = textBlock4;
			StyledProperty<string?> textProperty2 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EModConfig_002CMerostrap_002EPriorityDisplay_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding6 = compiledBindingExtension6.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock9.Bind(textProperty2, binding6);
			textBlock9.FontSize = 11.0;
			StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
			DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("TextFillColorTertiaryBrush");
			context.ProvideTargetProperty = TextBlock.ForegroundProperty;
			BindingBase binding7 = dynamicResourceExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock9.Bind(foregroundProperty, binding7);
			context.PopParent();
			((ISupportInitialize)textBlock8).EndInit();
			Avalonia.Controls.Controls children7 = stackPanel9.Children;
			TextBlock textBlock11;
			TextBlock textBlock10 = (textBlock11 = new TextBlock());
			((ISupportInitialize)textBlock10).BeginInit();
			children7.Add(textBlock10);
			TextBlock textBlock12 = (textBlock4 = textBlock11);
			context.PushParent(textBlock4);
			TextBlock textBlock13 = textBlock4;
			StyledProperty<string?> textProperty3 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EModConfig_002CMerostrap_002EFileCountDisplay_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding8 = compiledBindingExtension7.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock13.Bind(textProperty3, binding8);
			textBlock13.FontSize = 11.0;
			StyledProperty<IBrush?> foregroundProperty2 = TextBlock.ForegroundProperty;
			DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("TextFillColorTertiaryBrush");
			context.ProvideTargetProperty = TextBlock.ForegroundProperty;
			BindingBase binding9 = dynamicResourceExtension4.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock13.Bind(foregroundProperty2, binding9);
			context.PopParent();
			((ISupportInitialize)textBlock12).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel8).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel3).EndInit();
			Avalonia.Controls.Controls children8 = grid4.Children;
			ToggleSwitch toggleSwitch2;
			ToggleSwitch toggleSwitch = (toggleSwitch2 = new ToggleSwitch());
			((ISupportInitialize)toggleSwitch).BeginInit();
			children8.Add(toggleSwitch);
			ToggleSwitch toggleSwitch4;
			ToggleSwitch toggleSwitch3 = (toggleSwitch4 = toggleSwitch2);
			context.PushParent(toggleSwitch4);
			Grid.SetRow(toggleSwitch4, 0);
			Grid.SetColumn(toggleSwitch4, 3);
			StyledProperty<bool?> isCheckedProperty = ToggleButton.IsCheckedProperty;
			CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EModConfig_002CMerostrap_002EEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
			CompiledBinding binding10 = compiledBindingExtension8.ProvideValue(context);
			context.ProvideTargetProperty = null;
			toggleSwitch4.Bind(isCheckedProperty, binding10);
			toggleSwitch4.Margin = new Thickness(8.0, 0.0, 8.0, 0.0);
			toggleSwitch4.VerticalAlignment = VerticalAlignment.Center;
			context.PopParent();
			((ISupportInitialize)toggleSwitch3).EndInit();
			Avalonia.Controls.Controls children9 = grid4.Children;
			ComboBox comboBox2;
			ComboBox comboBox = (comboBox2 = new ComboBox());
			((ISupportInitialize)comboBox).BeginInit();
			children9.Add(comboBox);
			ComboBox comboBox4;
			ComboBox comboBox3 = (comboBox4 = comboBox2);
			context.PushParent(comboBox4);
			Grid.SetRow(comboBox4, 0);
			Grid.SetColumn(comboBox4, 4);
			comboBox4.Width = 125.0;
			comboBox4.Margin = new Thickness(4.0, 0.0, 0.0, 0.0);
			comboBox4.ItemsSource = ModsViewModel.TargetOptions;
			CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EModConfig_002CMerostrap_002ETarget_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = SelectingItemsControl.SelectedItemProperty;
			CompiledBinding compiledBinding3 = compiledBindingExtension9.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_10(comboBox4, compiledBinding3);
			comboBox4.VerticalAlignment = VerticalAlignment.Center;
			context.PopParent();
			((ISupportInitialize)comboBox3).EndInit();
			context.PopParent();
			((ISupportInitialize)grid3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<ModsPage> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<ModsPage> context = new XamlIlContext.Context<ModsPage>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FPages_002FMods_002FModsPage_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/Pages/Mods/ModsPage.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (ModsPage)service;
				}
			}
			return context;
		}

		public static object Build_2(IServiceProvider P_0)
		{
			XamlIlContext.Context<ModsPage> context = CreateContext(P_0);
			context.IntermediateRoot = new WrapPanel();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((AvaloniaObject)obj).SetValue(Layoutable.HorizontalAlignmentProperty, HorizontalAlignment.Center, BindingPriority.Template);
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_3(IServiceProvider P_0)
		{
			XamlIlContext.Context<ModsPage> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Border border = (Border)obj;
			context.PushParent(border);
			border.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
			border.Padding = new Thickness(8.0, 8.0, 8.0, 8.0);
			border.Width = 56.0;
			border.Height = 56.0;
			StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("ControlFillColorSecondaryBrush");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border.Bind(backgroundProperty, binding);
			StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
			DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("ControlStrokeColorDefaultBrush");
			context.ProvideTargetProperty = Border.BorderBrushProperty;
			BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border.Bind(borderBrushProperty, binding2);
			border.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
			border.CornerRadius = new CornerRadius(4.0, 4.0, 4.0, 4.0);
			Viewbox viewbox2;
			Viewbox viewbox = (viewbox2 = new Viewbox());
			((ISupportInitialize)viewbox).BeginInit();
			border.Child = viewbox;
			Viewbox viewbox4;
			Viewbox viewbox3 = (viewbox4 = viewbox2);
			context.PushParent(viewbox4);
			viewbox4.Stretch = Stretch.Uniform;
			Path path2;
			Path path = (path2 = new Path());
			((ISupportInitialize)path).BeginInit();
			viewbox4.Child = path;
			Path path4;
			Path path3 = (path4 = path2);
			context.PushParent(path4);
			StyledProperty<Geometry?> dataProperty = Path.DataProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EGlyphItem_002CMerostrap_002EData_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Path.DataProperty;
			CompiledBinding binding3 = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			path4.Bind(dataProperty, binding3);
			StyledProperty<IBrush?> fillProperty = Shape.FillProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EGlyphItem_002CMerostrap_002EBrush_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Shape.FillProperty;
			CompiledBinding binding4 = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			path4.Bind(fillProperty, binding4);
			path4.Margin = new Thickness(0.0, 0.0, 10.0, 8.0);
			context.PopParent();
			((ISupportInitialize)path3).EndInit();
			context.PopParent();
			((ISupportInitialize)viewbox3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}
	}

	private bool _viewModelSetUp;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal ListBox ModsListBox;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public ModsPage()
	{
		InitializeComponent();
		App.FrostRPC?.SetPage("Mods");
		Loaded += (object? s, RoutedEventArgs e) =>
		{
			SetupViewModelIfNeeded();
		};
	}

	private void SetupViewModelIfNeeded()
	{
		if (_viewModelSetUp)
		{
			return;
		}
		try
		{
			if (TopLevel.GetTopLevel(this)?.DataContext is MainWindowViewModel mainVm)
			{
				CreateViewModelWithDialogService(mainVm);
				_viewModelSetUp = true;
			}
			else
			{
				CreateFallbackViewModel();
				_viewModelSetUp = true;
			}
		}
		catch (Exception argument)
		{
			App.Logger.Error("Unhandled exception: ", argument);
			CreateFallbackViewModel();
			_viewModelSetUp = true;
		}
	}

	private void CreateViewModelWithDialogService(MainWindowViewModel mainVm)
	{
		ModsViewModel dataContext = new ModsViewModel(new ModsDialogService(mainVm));
		DataContext = dataContext;
	}

	private void CreateFallbackViewModel()
	{
		ModsViewModel dataContext = new ModsViewModel();
		DataContext = dataContext;
	}

	private void Page_DragEnter(object? sender, DragEventArgs e)
	{
		e.Handled = true;
		if (DataContext is ModsViewModel modsViewModel)
		{
			modsViewModel.IsDragOver = true;
		}
	}

	private void Page_DragLeave(object? sender, DragEventArgs e)
	{
		e.Handled = true;
		if (DataContext is ModsViewModel modsViewModel)
		{
			modsViewModel.IsDragOver = false;
		}
	}

	private async void Page_Drop(object? sender, DragEventArgs e)
	{
		e.Handled = true;
		if (!(DataContext is ModsViewModel modsViewModel))
		{
			return;
		}
		modsViewModel.IsDragOver = false;
		IStorageItem[] array = e.DataTransfer.TryGetFiles();
		if (array != null)
		{
			string[] array2 = (from f in array
				select f.TryGetLocalPath() into p
				where !string.IsNullOrEmpty(p)
				select p).ToArray();
			if (array2.Length != 0)
			{
				await modsViewModel.ImportFromPaths(array2);
			}
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		ModsListBox = this.FindNameScope()?.Find<ListBox>("ModsListBox");
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, ModsPage P_1)
	{
		XamlIlContext.Context<ModsPage> context = new XamlIlContext.Context<ModsPage>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FPages_002FMods_002FModsPage_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/Pages/Mods/ModsPage.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Background = new ImmutableSolidColorBrush(16777215u);
		DragDrop.SetAllowDrop(P_1, value: true);
		P_1.AddHandler(DragDrop.DropEvent, context.RootObject.Page_Drop);
		P_1.AddHandler(DragDrop.DragEnterEvent, context.RootObject.Page_DragEnter);
		P_1.AddHandler(DragDrop.DragLeaveEvent, context.RootObject.Page_DragLeave);
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		Avalonia.Controls.Controls children = grid5.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children.Add(grid6);
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 3;
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid9.RowDefinitions = rowDefinitions;
		grid9.Margin = new Thickness(14.0, 14.0, 14.0, 14.0);
		grid9.Background = new ImmutableSolidColorBrush(16777215u);
		Avalonia.Controls.Controls children2 = grid9.Children;
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		children2.Add(stackPanel);
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		StackPanel stackPanel5 = stackPanel4;
		Grid.SetRow(stackPanel5, 0);
		Avalonia.Controls.Controls children3 = stackPanel5.Children;
		Grid grid11;
		Grid grid10 = (grid11 = new Grid());
		((ISupportInitialize)grid10).BeginInit();
		children3.Add(grid10);
		Grid grid12 = (grid4 = grid11);
		context.PushParent(grid4);
		Grid grid13 = grid4;
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 3;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid13.ColumnDefinitions = columnDefinitions;
		Avalonia.Controls.Controls children4 = grid13.Children;
		CardAction cardAction2;
		CardAction cardAction = (cardAction2 = new CardAction());
		((ISupportInitialize)cardAction).BeginInit();
		children4.Add(cardAction);
		CardAction cardAction4;
		CardAction cardAction3 = (cardAction4 = cardAction2);
		context.PushParent(cardAction4);
		CardAction cardAction5 = cardAction4;
		Grid.SetColumn(cardAction5, 0);
		cardAction5.Margin = new Thickness(0.0, 0.0, 4.0, 0.0);
		cardAction5.Header = Strings.Menu_CommunityMods_Title;
		cardAction5.Icon = LucideIconNames.House;
		cardAction5.Description = Strings.Menu_CommunityMods_Description;
		StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002EOpenCommunityModsCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		cardAction5.Bind(commandProperty, binding);
		context.PopParent();
		((ISupportInitialize)cardAction3).EndInit();
		Avalonia.Controls.Controls children5 = grid13.Children;
		CardAction cardAction7;
		CardAction cardAction6 = (cardAction7 = new CardAction());
		((ISupportInitialize)cardAction6).BeginInit();
		children5.Add(cardAction6);
		CardAction cardAction8 = (cardAction4 = cardAction7);
		context.PushParent(cardAction4);
		CardAction cardAction9 = cardAction4;
		Grid.SetColumn(cardAction9, 1);
		cardAction9.Margin = new Thickness(2.0, 0.0, 2.0, 0.0);
		cardAction9.Header = Strings.Menu_PresetMods_Title;
		cardAction9.Icon = LucideIconNames.BookOpen;
		cardAction9.Description = Strings.Menu_PresetMods_Description;
		StyledProperty<ICommand?> commandProperty2 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002EOpenPresetModsCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		cardAction9.Bind(commandProperty2, binding2);
		context.PopParent();
		((ISupportInitialize)cardAction8).EndInit();
		Avalonia.Controls.Controls children6 = grid13.Children;
		CardAction cardAction11;
		CardAction cardAction10 = (cardAction11 = new CardAction());
		((ISupportInitialize)cardAction10).BeginInit();
		children6.Add(cardAction10);
		CardAction cardAction12 = (cardAction4 = cardAction11);
		context.PushParent(cardAction4);
		CardAction cardAction13 = cardAction4;
		Grid.SetColumn(cardAction13, 2);
		cardAction13.Margin = new Thickness(4.0, 0.0, 0.0, 0.0);
		cardAction13.Header = Strings.Menu_ModGenerator_Title;
		cardAction13.Icon = LucideIconNames.PaintbrushVertical;
		cardAction13.Description = Strings.Menu_ModGenerator_Description;
		StyledProperty<ICommand?> commandProperty3 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002EOpenModGeneratorCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding3 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		cardAction13.Bind(commandProperty3, binding3);
		context.PopParent();
		((ISupportInitialize)cardAction12).EndInit();
		context.PopParent();
		((ISupportInitialize)grid12).EndInit();
		Avalonia.Controls.Controls children7 = stackPanel5.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children7.Add(border);
		border2.Height = 12.0;
		((ISupportInitialize)border2).EndInit();
		Avalonia.Controls.Controls children8 = stackPanel5.Children;
		IconButton iconButton2;
		IconButton iconButton = (iconButton2 = new IconButton());
		((ISupportInitialize)iconButton).BeginInit();
		children8.Add(iconButton);
		IconButton iconButton4;
		IconButton iconButton3 = (iconButton4 = iconButton2);
		context.PushParent(iconButton4);
		IconButton iconButton5 = iconButton4;
		iconButton5.Icon = LucideIconNames.Plus;
		iconButton5.Content = Strings.Menu_Mods_AddNewMod;
		iconButton5.HorizontalAlignment = HorizontalAlignment.Stretch;
		StyledProperty<ICommand?> commandProperty4 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002EAddModCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding4 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		iconButton5.Bind(commandProperty4, binding4);
		iconButton5.Margin = new Thickness(0.0, 0.0, 0.0, 4.0);
		context.PopParent();
		((ISupportInitialize)iconButton3).EndInit();
		Avalonia.Controls.Controls children9 = stackPanel5.Children;
		Grid grid15;
		Grid grid14 = (grid15 = new Grid());
		((ISupportInitialize)grid14).BeginInit();
		children9.Add(grid14);
		Grid grid16 = (grid4 = grid15);
		context.PushParent(grid4);
		Grid grid17 = grid4;
		ColumnDefinitions columnDefinitions2 = new ColumnDefinitions();
		columnDefinitions2.Capacity = 2;
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid17.ColumnDefinitions = columnDefinitions2;
		grid17.Margin = new Thickness(0.0, 4.0, 0.0, 0.0);
		Avalonia.Controls.Controls children10 = grid17.Children;
		IconButton iconButton7;
		IconButton iconButton6 = (iconButton7 = new IconButton());
		((ISupportInitialize)iconButton6).BeginInit();
		children10.Add(iconButton6);
		IconButton iconButton8 = (iconButton4 = iconButton7);
		context.PushParent(iconButton4);
		IconButton iconButton9 = iconButton4;
		iconButton9.Icon = LucideIconNames.Folder;
		iconButton9.Content = Strings.Menu_Mods_ImportFolder;
		iconButton9.HorizontalAlignment = HorizontalAlignment.Stretch;
		iconButton9.Margin = new Thickness(0.0, 0.0, 2.0, 0.0);
		StyledProperty<ICommand?> commandProperty5 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002EImportFolderCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding5 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		iconButton9.Bind(commandProperty5, binding5);
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Self().Build());
		context.ProvideTargetProperty = Button.CommandParameterProperty;
		CompiledBinding compiledBinding = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_6(iconButton9, compiledBinding);
		context.PopParent();
		((ISupportInitialize)iconButton8).EndInit();
		Avalonia.Controls.Controls children11 = grid17.Children;
		IconButton iconButton11;
		IconButton iconButton10 = (iconButton11 = new IconButton());
		((ISupportInitialize)iconButton10).BeginInit();
		children11.Add(iconButton10);
		IconButton iconButton12 = (iconButton4 = iconButton11);
		context.PushParent(iconButton4);
		IconButton iconButton13 = iconButton4;
		iconButton13.Icon = LucideIconNames.FolderArchive;
		iconButton13.Content = Strings.Menu_Mods_ImportZIP;
		iconButton13.HorizontalAlignment = HorizontalAlignment.Stretch;
		iconButton13.Margin = new Thickness(2.0, 0.0, 0.0, 0.0);
		Grid.SetColumn(iconButton13, 1);
		StyledProperty<ICommand?> commandProperty6 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002EImportZipCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding6 = compiledBindingExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		iconButton13.Bind(commandProperty6, binding6);
		CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Self().Build());
		context.ProvideTargetProperty = Button.CommandParameterProperty;
		CompiledBinding compiledBinding2 = compiledBindingExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_6(iconButton13, compiledBinding2);
		context.PopParent();
		((ISupportInitialize)iconButton12).EndInit();
		context.PopParent();
		((ISupportInitialize)grid16).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		Avalonia.Controls.Controls children12 = grid9.Children;
		Grid grid19;
		Grid grid18 = (grid19 = new Grid());
		((ISupportInitialize)grid18).BeginInit();
		children12.Add(grid18);
		Grid grid20 = (grid4 = grid19);
		context.PushParent(grid4);
		Grid grid21 = grid4;
		Grid.SetRow(grid21, 1);
		ColumnDefinitions columnDefinitions3 = new ColumnDefinitions();
		columnDefinitions3.Capacity = 2;
		columnDefinitions3.Add(new ColumnDefinition(new GridLength(2.0, GridUnitType.Star)));
		columnDefinitions3.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid21.ColumnDefinitions = columnDefinitions3;
		grid21.Margin = new Thickness(0.0, 4.0, 0.0, 0.0);
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002EHasMods_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding7 = compiledBindingExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		grid21.Bind(isVisibleProperty, binding7);
		Avalonia.Controls.Controls children13 = grid21.Children;
		Border border4;
		Border border3 = (border4 = new Border());
		((ISupportInitialize)border3).BeginInit();
		children13.Add(border3);
		Border border6;
		Border border5 = (border6 = border4);
		context.PushParent(border6);
		Border border7 = border6;
		Grid.SetColumn(border7, 0);
		border7.Padding = new Thickness(0.0, 0.0, 4.0, 0.0);
		ListBox listBox2;
		ListBox listBox = (listBox2 = new ListBox());
		((ISupportInitialize)listBox).BeginInit();
		border7.Child = listBox;
		ListBox listBox4;
		ListBox listBox3 = (listBox4 = listBox2);
		context.PushParent(listBox4);
		listBox4.Name = "ModsListBox";
		object element = listBox4;
		context.AvaloniaNameScope.Register("ModsListBox", element);
		StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002EModifications_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding8 = compiledBindingExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		listBox4.Bind(itemsSourceProperty, binding8);
		CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002ESelectedMod_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = SelectingItemsControl.SelectedItemProperty;
		CompiledBinding compiledBinding3 = compiledBindingExtension11.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_10(listBox4, compiledBinding3);
		StyledProperty<IBrush?> backgroundProperty = TemplatedControl.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("ControlFillColorSecondaryBrush");
		context.ProvideTargetProperty = TemplatedControl.BackgroundProperty;
		BindingBase binding9 = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		listBox4.Bind(backgroundProperty, binding9);
		StyledProperty<IBrush?> borderBrushProperty = TemplatedControl.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("ControlElevationBorderBrush");
		context.ProvideTargetProperty = TemplatedControl.BorderBrushProperty;
		BindingBase binding10 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		listBox4.Bind(borderBrushProperty, binding10);
		listBox4.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		listBox4.CornerRadius = new CornerRadius(6.0, 6.0, 6.0, 6.0);
		DataTemplate dataTemplate;
		DataTemplate itemTemplate = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		DataTemplate dataTemplate2 = dataTemplate;
		dataTemplate2.DataType = typeof(ModConfig);
		dataTemplate2.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_51.Build_1), context);
		context.PopParent();
		listBox4.ItemTemplate = itemTemplate;
		Styles styles = listBox4.Styles;
		Style style = new Style();
		style.Selector = ((Selector?)null).OfType(typeof(ListBoxItem));
		Setter setter = new Setter();
		setter.Property = TemplatedControl.PaddingProperty;
		setter.Value = new Thickness(0.0, 0.0, 0.0, 0.0);
		style.Add(setter);
		styles.Add(style);
		context.PopParent();
		((ISupportInitialize)listBox3).EndInit();
		context.PopParent();
		((ISupportInitialize)border5).EndInit();
		Avalonia.Controls.Controls children14 = grid21.Children;
		Border border9;
		Border border8 = (border9 = new Border());
		((ISupportInitialize)border8).BeginInit();
		children14.Add(border8);
		Border border10 = (border6 = border9);
		context.PushParent(border6);
		Border border11 = border6;
		Grid.SetColumn(border11, 1);
		border11.Padding = new Thickness(4.0, 0.0, 0.0, 0.0);
		StackPanel stackPanel7;
		StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
		((ISupportInitialize)stackPanel6).BeginInit();
		border11.Child = stackPanel6;
		StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
		context.PushParent(stackPanel4);
		StackPanel stackPanel9 = stackPanel4;
		Avalonia.Controls.Controls children15 = stackPanel9.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children15.Add(textBlock);
		textBlock2.Text = Strings.Menu_Mods_SelectedModAction;
		textBlock2.FontWeight = FontWeight.DemiBold;
		textBlock2.Margin = new Thickness(0.0, 0.0, 0.0, 8.0);
		((ISupportInitialize)textBlock2).EndInit();
		Avalonia.Controls.Controls children16 = stackPanel9.Children;
		StackPanel stackPanel11;
		StackPanel stackPanel10 = (stackPanel11 = new StackPanel());
		((ISupportInitialize)stackPanel10).BeginInit();
		children16.Add(stackPanel10);
		StackPanel stackPanel12 = (stackPanel4 = stackPanel11);
		context.PushParent(stackPanel4);
		StackPanel stackPanel13 = stackPanel4;
		StyledProperty<bool> isEnabledProperty = InputElement.IsEnabledProperty;
		CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002ESelectedMod_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Converter = ObjectConverters.IsNotNull
		};
		context.ProvideTargetProperty = InputElement.IsEnabledProperty;
		CompiledBinding binding11 = compiledBindingExtension12.ProvideValue(context);
		context.ProvideTargetProperty = null;
		stackPanel13.Bind(isEnabledProperty, binding11);
		Avalonia.Controls.Controls children17 = stackPanel13.Children;
		TextBox textBox2;
		TextBox textBox = (textBox2 = new TextBox());
		((ISupportInitialize)textBox).BeginInit();
		children17.Add(textBox);
		TextBox textBox4;
		TextBox textBox3 = (textBox4 = textBox2);
		context.PushParent(textBox4);
		textBox4.PlaceholderText = "New name";
		StyledProperty<string?> textProperty = TextBox.TextProperty;
		CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002ENewName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBox.TextProperty;
		CompiledBinding binding12 = compiledBindingExtension13.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBox4.Bind(textProperty, binding12);
		textBox4.Margin = new Thickness(0.0, 4.0, 0.0, 4.0);
		context.PopParent();
		((ISupportInitialize)textBox3).EndInit();
		Avalonia.Controls.Controls children18 = stackPanel13.Children;
		IconButton iconButton15;
		IconButton iconButton14 = (iconButton15 = new IconButton());
		((ISupportInitialize)iconButton14).BeginInit();
		children18.Add(iconButton14);
		IconButton iconButton16 = (iconButton4 = iconButton15);
		context.PushParent(iconButton4);
		IconButton iconButton17 = iconButton4;
		iconButton17.Icon = LucideIconNames.Pencil;
		iconButton17.Content = Strings.Common_Rename;
		StyledProperty<ICommand?> commandProperty7 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002ERenameModCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding13 = compiledBindingExtension14.ProvideValue(context);
		context.ProvideTargetProperty = null;
		iconButton17.Bind(commandProperty7, binding13);
		iconButton17.HorizontalAlignment = HorizontalAlignment.Stretch;
		iconButton17.Margin = new Thickness(0.0, 4.0, 0.0, 4.0);
		context.PopParent();
		((ISupportInitialize)iconButton16).EndInit();
		Avalonia.Controls.Controls children19 = stackPanel13.Children;
		IconButton iconButton19;
		IconButton iconButton18 = (iconButton19 = new IconButton());
		((ISupportInitialize)iconButton18).BeginInit();
		children19.Add(iconButton18);
		IconButton iconButton20 = (iconButton4 = iconButton19);
		context.PushParent(iconButton4);
		IconButton iconButton21 = iconButton4;
		StyledProperty<ICommand?> commandProperty8 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension15 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002EExportModCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding14 = compiledBindingExtension15.ProvideValue(context);
		context.ProvideTargetProperty = null;
		iconButton21.Bind(commandProperty8, binding14);
		CompiledBindingExtension compiledBindingExtension16 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002ESelectedMod_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandParameterProperty;
		CompiledBinding compiledBinding4 = compiledBindingExtension16.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_6(iconButton21, compiledBinding4);
		iconButton21.Content = Strings.Common_Export;
		iconButton21.Icon = LucideIconNames.ArrowRightFromLine;
		iconButton21.Margin = new Thickness(0.0, 4.0, 0.0, 4.0);
		context.PopParent();
		((ISupportInitialize)iconButton20).EndInit();
		Avalonia.Controls.Controls children20 = stackPanel13.Children;
		IconButton iconButton23;
		IconButton iconButton22 = (iconButton23 = new IconButton());
		((ISupportInitialize)iconButton22).BeginInit();
		children20.Add(iconButton22);
		IconButton iconButton24 = (iconButton4 = iconButton23);
		context.PushParent(iconButton4);
		IconButton iconButton25 = iconButton4;
		iconButton25.Icon = LucideIconNames.Type;
		iconButton25.Content = Strings.Menu_Mods_PreviewFont;
		StyledProperty<ICommand?> commandProperty9 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension17 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002ETogglePreviewCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding15 = compiledBindingExtension17.ProvideValue(context);
		context.ProvideTargetProperty = null;
		iconButton25.Bind(commandProperty9, binding15);
		iconButton25.HorizontalAlignment = HorizontalAlignment.Stretch;
		iconButton25.Margin = new Thickness(0.0, 4.0, 0.0, 4.0);
		StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension18 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002EHasFontPreview_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding16 = compiledBindingExtension18.ProvideValue(context);
		context.ProvideTargetProperty = null;
		iconButton25.Bind(isVisibleProperty2, binding16);
		context.PopParent();
		((ISupportInitialize)iconButton24).EndInit();
		Avalonia.Controls.Controls children21 = stackPanel13.Children;
		Grid grid23;
		Grid grid22 = (grid23 = new Grid());
		((ISupportInitialize)grid22).BeginInit();
		children21.Add(grid22);
		Grid grid24 = (grid4 = grid23);
		context.PushParent(grid4);
		Grid grid25 = grid4;
		ColumnDefinitions columnDefinitions4 = new ColumnDefinitions();
		columnDefinitions4.Capacity = 2;
		columnDefinitions4.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions4.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid25.ColumnDefinitions = columnDefinitions4;
		grid25.Margin = new Thickness(0.0, 4.0, 0.0, 4.0);
		Avalonia.Controls.Controls children22 = grid25.Children;
		IconButton iconButton27;
		IconButton iconButton26 = (iconButton27 = new IconButton());
		((ISupportInitialize)iconButton26).BeginInit();
		children22.Add(iconButton26);
		IconButton iconButton28 = (iconButton4 = iconButton27);
		context.PushParent(iconButton4);
		IconButton iconButton29 = iconButton4;
		Grid.SetColumn(iconButton29, 0);
		iconButton29.Icon = LucideIconNames.Trash2;
		iconButton29.Content = Strings.Common_Delete;
		iconButton29.Classes.Add("Danger");
		StyledProperty<ICommand?> commandProperty10 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension19 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002EDeleteModCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding17 = compiledBindingExtension19.ProvideValue(context);
		context.ProvideTargetProperty = null;
		iconButton29.Bind(commandProperty10, binding17);
		CompiledBindingExtension compiledBindingExtension20 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002ESelectedMod_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandParameterProperty;
		CompiledBinding compiledBinding5 = compiledBindingExtension20.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_6(iconButton29, compiledBinding5);
		iconButton29.HorizontalAlignment = HorizontalAlignment.Stretch;
		iconButton29.Margin = new Thickness(0.0, 0.0, 2.0, 0.0);
		context.PopParent();
		((ISupportInitialize)iconButton28).EndInit();
		Avalonia.Controls.Controls children23 = grid25.Children;
		IconButton iconButton31;
		IconButton iconButton30 = (iconButton31 = new IconButton());
		((ISupportInitialize)iconButton30).BeginInit();
		children23.Add(iconButton30);
		IconButton iconButton32 = (iconButton4 = iconButton31);
		context.PushParent(iconButton4);
		IconButton iconButton33 = iconButton4;
		Grid.SetColumn(iconButton33, 1);
		iconButton33.Icon = LucideIconNames.Folder;
		iconButton33.Content = Strings.Common_OpenFolder;
		StyledProperty<ICommand?> commandProperty11 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension21 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002EOpenModFolderCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding18 = compiledBindingExtension21.ProvideValue(context);
		context.ProvideTargetProperty = null;
		iconButton33.Bind(commandProperty11, binding18);
		CompiledBindingExtension compiledBindingExtension22 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002ESelectedMod_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandParameterProperty;
		CompiledBinding compiledBinding6 = compiledBindingExtension22.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_6(iconButton33, compiledBinding6);
		iconButton33.HorizontalAlignment = HorizontalAlignment.Stretch;
		iconButton33.Margin = new Thickness(2.0, 0.0, 0.0, 0.0);
		context.PopParent();
		((ISupportInitialize)iconButton32).EndInit();
		context.PopParent();
		((ISupportInitialize)grid24).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel12).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel8).EndInit();
		context.PopParent();
		((ISupportInitialize)border10).EndInit();
		context.PopParent();
		((ISupportInitialize)grid20).EndInit();
		Avalonia.Controls.Controls children24 = grid9.Children;
		Grid grid27;
		Grid grid26 = (grid27 = new Grid());
		((ISupportInitialize)grid26).BeginInit();
		children24.Add(grid26);
		Grid grid28 = (grid4 = grid27);
		context.PushParent(grid4);
		Grid grid29 = grid4;
		Grid.SetRow(grid29, 1);
		grid29.HorizontalAlignment = HorizontalAlignment.Center;
		grid29.VerticalAlignment = VerticalAlignment.Center;
		StyledProperty<bool> isVisibleProperty3 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension23 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002EHasMods_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding19 = compiledBindingExtension23.ProvideValue(context);
		context.ProvideTargetProperty = null;
		grid29.Bind(isVisibleProperty3, binding19);
		Avalonia.Controls.Controls children25 = grid29.Children;
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		children25.Add(textBlock3);
		textBlock4.Text = Strings.Menu_Mods_NoneInstalled;
		textBlock4.FontSize = 20.0;
		textBlock4.Opacity = 0.5;
		textBlock4.FontWeight = FontWeight.Bold;
		textBlock4.HorizontalAlignment = HorizontalAlignment.Center;
		textBlock4.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)textBlock4).EndInit();
		context.PopParent();
		((ISupportInitialize)grid28).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		Avalonia.Controls.Controls children26 = grid5.Children;
		Border border13;
		Border border12 = (border13 = new Border());
		((ISupportInitialize)border12).BeginInit();
		children26.Add(border12);
		Border border14 = (border6 = border13);
		context.PushParent(border6);
		Border border15 = border6;
		StyledProperty<bool> isVisibleProperty4 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension24 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002EIsPreviewOpen_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding20 = compiledBindingExtension24.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border15.Bind(isVisibleProperty4, binding20);
		border15.Background = new ImmutableSolidColorBrush(3422552064u);
		border15.HorizontalAlignment = HorizontalAlignment.Stretch;
		border15.VerticalAlignment = VerticalAlignment.Stretch;
		border15.ZIndex = 1000;
		border15.Opacity = 1.0;
		Transitions transitions = new Transitions();
		DoubleTransition doubleTransition = new DoubleTransition();
		doubleTransition.Property = Visual.OpacityProperty;
		doubleTransition.Duration = TimeSpan.FromTicks(3000000L);
		transitions.Add(doubleTransition);
		border15.Transitions = transitions;
		Grid grid31;
		Grid grid30 = (grid31 = new Grid());
		((ISupportInitialize)grid30).BeginInit();
		border15.Child = grid30;
		Grid grid32 = (grid4 = grid31);
		context.PushParent(grid4);
		Grid grid33 = grid4;
		grid33.HorizontalAlignment = HorizontalAlignment.Center;
		grid33.VerticalAlignment = VerticalAlignment.Center;
		grid33.MaxWidth = 800.0;
		grid33.MaxHeight = 600.0;
		Avalonia.Controls.Controls children27 = grid33.Children;
		Border border17;
		Border border16 = (border17 = new Border());
		((ISupportInitialize)border16).BeginInit();
		children27.Add(border16);
		Border border18 = (border6 = border17);
		context.PushParent(border6);
		Border border19 = border6;
		StyledProperty<IBrush?> backgroundProperty2 = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("LayerFillColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding21 = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border19.Bind(backgroundProperty2, binding21);
		border19.CornerRadius = new CornerRadius(12.0, 12.0, 12.0, 12.0);
		border19.Padding = new Thickness(20.0, 20.0, 20.0, 20.0);
		border19.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		StyledProperty<IBrush?> borderBrushProperty2 = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("ControlStrokeColorDefault");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding22 = dynamicResourceExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border19.Bind(borderBrushProperty2, binding22);
		Grid grid35;
		Grid grid34 = (grid35 = new Grid());
		((ISupportInitialize)grid34).BeginInit();
		border19.Child = grid34;
		Grid grid36 = (grid4 = grid35);
		context.PushParent(grid4);
		Grid grid37 = grid4;
		RowDefinitions rowDefinitions2 = new RowDefinitions();
		rowDefinitions2.Capacity = 5;
		rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions2.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid37.RowDefinitions = rowDefinitions2;
		Avalonia.Controls.Controls children28 = grid37.Children;
		Grid grid39;
		Grid grid38 = (grid39 = new Grid());
		((ISupportInitialize)grid38).BeginInit();
		children28.Add(grid38);
		Grid grid40 = (grid4 = grid39);
		context.PushParent(grid4);
		Grid grid41 = grid4;
		Grid.SetRow(grid41, 0);
		ColumnDefinitions columnDefinitions5 = new ColumnDefinitions();
		columnDefinitions5.Capacity = 2;
		columnDefinitions5.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions5.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid41.ColumnDefinitions = columnDefinitions5;
		Avalonia.Controls.Controls children29 = grid41.Children;
		StackPanel stackPanel15;
		StackPanel stackPanel14 = (stackPanel15 = new StackPanel());
		((ISupportInitialize)stackPanel14).BeginInit();
		children29.Add(stackPanel14);
		StackPanel stackPanel16 = (stackPanel4 = stackPanel15);
		context.PushParent(stackPanel4);
		StackPanel stackPanel17 = stackPanel4;
		Avalonia.Controls.Controls children30 = stackPanel17.Children;
		TextBlock textBlock6;
		TextBlock textBlock5 = (textBlock6 = new TextBlock());
		((ISupportInitialize)textBlock5).BeginInit();
		children30.Add(textBlock5);
		TextBlock textBlock8;
		TextBlock textBlock7 = (textBlock8 = textBlock6);
		context.PushParent(textBlock8);
		TextBlock textBlock9 = textBlock8;
		textBlock9.Text = Strings.Menu_Mods_Preview_Font_Preview;
		textBlock9.FontSize = 18.0;
		textBlock9.FontWeight = FontWeight.DemiBold;
		StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension5 = new DynamicResourceExtension("TextFillColorPrimaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding23 = dynamicResourceExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock9.Bind(foregroundProperty, binding23);
		context.PopParent();
		((ISupportInitialize)textBlock7).EndInit();
		Avalonia.Controls.Controls children31 = stackPanel17.Children;
		TextBlock textBlock11;
		TextBlock textBlock10 = (textBlock11 = new TextBlock());
		((ISupportInitialize)textBlock10).BeginInit();
		children31.Add(textBlock10);
		TextBlock textBlock12 = (textBlock8 = textBlock11);
		context.PushParent(textBlock8);
		TextBlock textBlock13 = textBlock8;
		StyledProperty<string?> textProperty2 = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension25 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002EPreviewStatus_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding24 = compiledBindingExtension25.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock13.Bind(textProperty2, binding24);
		textBlock13.FontSize = 12.0;
		StyledProperty<IBrush?> foregroundProperty2 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension6 = new DynamicResourceExtension("TextFillColorSecondaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding25 = dynamicResourceExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock13.Bind(foregroundProperty2, binding25);
		context.PopParent();
		((ISupportInitialize)textBlock12).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel16).EndInit();
		Avalonia.Controls.Controls children32 = grid41.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children32.Add(button);
		Button button4;
		Button button3 = (button4 = button2);
		context.PushParent(button4);
		Button button5 = button4;
		Grid.SetColumn(button5, 1);
		StyledProperty<ICommand?> commandProperty12 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension26 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002ETogglePreviewCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding26 = compiledBindingExtension26.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button5.Bind(commandProperty12, binding26);
		button5.Content = "✕";
		button5.Background = new ImmutableSolidColorBrush(16777215u);
		button5.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
		button5.FontSize = 20.0;
		StyledProperty<IBrush?> foregroundProperty3 = TemplatedControl.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension7 = new DynamicResourceExtension("TextFillColorSecondaryBrush");
		context.ProvideTargetProperty = TemplatedControl.ForegroundProperty;
		BindingBase binding27 = dynamicResourceExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button5.Bind(foregroundProperty3, binding27);
		button5.Cursor = new Cursor(StandardCursorType.Hand);
		context.PopParent();
		((ISupportInitialize)button3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid40).EndInit();
		Avalonia.Controls.Controls children33 = grid37.Children;
		Border border21;
		Border border20 = (border21 = new Border());
		((ISupportInitialize)border20).BeginInit();
		children33.Add(border20);
		border21.Height = 12.0;
		Grid.SetRow(border21, 1);
		((ISupportInitialize)border21).EndInit();
		Avalonia.Controls.Controls children34 = grid37.Children;
		StackPanel stackPanel19;
		StackPanel stackPanel18 = (stackPanel19 = new StackPanel());
		((ISupportInitialize)stackPanel18).BeginInit();
		children34.Add(stackPanel18);
		StackPanel stackPanel20 = (stackPanel4 = stackPanel19);
		context.PushParent(stackPanel4);
		StackPanel stackPanel21 = stackPanel4;
		Grid.SetRow(stackPanel21, 2);
		stackPanel21.Orientation = Orientation.Horizontal;
		stackPanel21.Margin = new Thickness(0.0, 0.0, 0.0, 12.0);
		stackPanel21.HorizontalAlignment = HorizontalAlignment.Center;
		stackPanel21.Spacing = 12.0;
		Avalonia.Controls.Controls children35 = stackPanel21.Children;
		TextBlock textBlock15;
		TextBlock textBlock14 = (textBlock15 = new TextBlock());
		((ISupportInitialize)textBlock14).BeginInit();
		children35.Add(textBlock14);
		TextBlock textBlock16 = (textBlock8 = textBlock15);
		context.PushParent(textBlock8);
		TextBlock textBlock17 = textBlock8;
		textBlock17.Text = Strings.Menu_Mods_Preview_FontVariant;
		textBlock17.VerticalAlignment = VerticalAlignment.Center;
		StyledProperty<IBrush?> foregroundProperty4 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension8 = new DynamicResourceExtension("TextFillColorSecondaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding28 = dynamicResourceExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock17.Bind(foregroundProperty4, binding28);
		context.PopParent();
		((ISupportInitialize)textBlock16).EndInit();
		Avalonia.Controls.Controls children36 = stackPanel21.Children;
		ComboBox comboBox2;
		ComboBox comboBox = (comboBox2 = new ComboBox());
		((ISupportInitialize)comboBox).BeginInit();
		children36.Add(comboBox);
		ComboBox comboBox4;
		ComboBox comboBox3 = (comboBox4 = comboBox2);
		context.PushParent(comboBox4);
		StyledProperty<IEnumerable?> itemsSourceProperty2 = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension27 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002EFontVariants_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding29 = compiledBindingExtension27.ProvideValue(context);
		context.ProvideTargetProperty = null;
		comboBox4.Bind(itemsSourceProperty2, binding29);
		CompiledBindingExtension compiledBindingExtension28 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002ESelectedFontVariant_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = SelectingItemsControl.SelectedItemProperty;
		CompiledBinding compiledBinding7 = compiledBindingExtension28.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_10(comboBox4, compiledBinding7);
		comboBox4.MinWidth = 120.0;
		comboBox4.VerticalAlignment = VerticalAlignment.Center;
		context.PopParent();
		((ISupportInitialize)comboBox3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel20).EndInit();
		Avalonia.Controls.Controls children37 = grid37.Children;
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		children37.Add(scrollViewer);
		ScrollViewer scrollViewer4;
		ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
		context.PushParent(scrollViewer4);
		Grid.SetRow(scrollViewer4, 3);
		scrollViewer4.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
		scrollViewer4.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
		StyledProperty<bool> isEnabledProperty2 = InputElement.IsEnabledProperty;
		CompiledBindingExtension compiledBindingExtension29 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002EIsLoadingPreview_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = InputElement.IsEnabledProperty;
		CompiledBinding binding30 = compiledBindingExtension29.ProvideValue(context);
		context.ProvideTargetProperty = null;
		scrollViewer4.Bind(isEnabledProperty2, binding30);
		Grid grid43;
		Grid grid42 = (grid43 = new Grid());
		((ISupportInitialize)grid42).BeginInit();
		scrollViewer4.Content = grid42;
		Grid grid44 = (grid4 = grid43);
		context.PushParent(grid4);
		Grid grid45 = grid4;
		StyledProperty<bool> isEnabledProperty3 = InputElement.IsEnabledProperty;
		CompiledBindingExtension compiledBindingExtension30 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002EIsLoadingPreview_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = InputElement.IsEnabledProperty;
		CompiledBinding binding31 = compiledBindingExtension30.ProvideValue(context);
		context.ProvideTargetProperty = null;
		grid45.Bind(isEnabledProperty3, binding31);
		Avalonia.Controls.Controls children38 = grid45.Children;
		Grid grid47;
		Grid grid46 = (grid47 = new Grid());
		((ISupportInitialize)grid46).BeginInit();
		children38.Add(grid46);
		Grid grid48 = (grid4 = grid47);
		context.PushParent(grid4);
		Grid grid49 = grid4;
		StyledProperty<bool> isVisibleProperty5 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension31 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002EIsLoadingPreview_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding32 = compiledBindingExtension31.ProvideValue(context);
		context.ProvideTargetProperty = null;
		grid49.Bind(isVisibleProperty5, binding32);
		grid49.HorizontalAlignment = HorizontalAlignment.Center;
		grid49.VerticalAlignment = VerticalAlignment.Center;
		Avalonia.Controls.Controls children39 = grid49.Children;
		StackPanel stackPanel23;
		StackPanel stackPanel22 = (stackPanel23 = new StackPanel());
		((ISupportInitialize)stackPanel22).BeginInit();
		children39.Add(stackPanel22);
		StackPanel stackPanel24 = (stackPanel4 = stackPanel23);
		context.PushParent(stackPanel4);
		StackPanel stackPanel25 = stackPanel4;
		Avalonia.Controls.Controls children40 = stackPanel25.Children;
		ProgressBar progressBar2;
		ProgressBar progressBar = (progressBar2 = new ProgressBar());
		((ISupportInitialize)progressBar).BeginInit();
		children40.Add(progressBar);
		progressBar2.IsIndeterminate = true;
		progressBar2.Width = 200.0;
		progressBar2.Height = 4.0;
		((ISupportInitialize)progressBar2).EndInit();
		Avalonia.Controls.Controls children41 = stackPanel25.Children;
		TextBlock textBlock19;
		TextBlock textBlock18 = (textBlock19 = new TextBlock());
		((ISupportInitialize)textBlock18).BeginInit();
		children41.Add(textBlock18);
		TextBlock textBlock20 = (textBlock8 = textBlock19);
		context.PushParent(textBlock8);
		TextBlock textBlock21 = textBlock8;
		textBlock21.Text = Strings.Menu_Mods_Preview_Loading_Glyphs;
		textBlock21.FontSize = 14.0;
		textBlock21.Margin = new Thickness(0.0, 8.0, 0.0, 0.0);
		StyledProperty<IBrush?> foregroundProperty5 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension9 = new DynamicResourceExtension("TextFillColorSecondaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding33 = dynamicResourceExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock21.Bind(foregroundProperty5, binding33);
		context.PopParent();
		((ISupportInitialize)textBlock20).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel24).EndInit();
		context.PopParent();
		((ISupportInitialize)grid48).EndInit();
		Avalonia.Controls.Controls children42 = grid45.Children;
		ItemsControl itemsControl2;
		ItemsControl itemsControl = (itemsControl2 = new ItemsControl());
		((ISupportInitialize)itemsControl).BeginInit();
		children42.Add(itemsControl);
		ItemsControl itemsControl4;
		ItemsControl itemsControl3 = (itemsControl4 = itemsControl2);
		context.PushParent(itemsControl4);
		StyledProperty<IEnumerable?> itemsSourceProperty3 = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension32 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002EPreviewGlyphItems_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding34 = compiledBindingExtension32.ProvideValue(context);
		context.ProvideTargetProperty = null;
		itemsControl4.Bind(itemsSourceProperty3, binding34);
		StyledProperty<bool> isVisibleProperty6 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension33 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002EIsLoadingPreview_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			FallbackValue = "True"
		};
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding35 = compiledBindingExtension33.ProvideValue(context);
		context.ProvideTargetProperty = null;
		itemsControl4.Bind(isVisibleProperty6, binding35);
		itemsControl4.ItemsPanel = new ItemsPanelTemplate
		{
			Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_51.Build_2), context)
		};
		DataTemplate itemTemplate2 = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_51.Build_3), context);
		context.PopParent();
		itemsControl4.ItemTemplate = itemTemplate2;
		context.PopParent();
		((ISupportInitialize)itemsControl3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid44).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer3).EndInit();
		Avalonia.Controls.Controls children43 = grid37.Children;
		StackPanel stackPanel27;
		StackPanel stackPanel26 = (stackPanel27 = new StackPanel());
		((ISupportInitialize)stackPanel26).BeginInit();
		children43.Add(stackPanel26);
		StackPanel stackPanel28 = (stackPanel4 = stackPanel27);
		context.PushParent(stackPanel4);
		StackPanel stackPanel29 = stackPanel4;
		Grid.SetRow(stackPanel29, 4);
		stackPanel29.Orientation = Orientation.Horizontal;
		stackPanel29.Margin = new Thickness(0.0, 12.0, 0.0, 0.0);
		stackPanel29.HorizontalAlignment = HorizontalAlignment.Center;
		Avalonia.Controls.Controls children44 = stackPanel29.Children;
		Button button7;
		Button button6 = (button7 = new Button());
		((ISupportInitialize)button6).BeginInit();
		children44.Add(button6);
		Button button8 = (button4 = button7);
		context.PushParent(button4);
		Button button9 = button4;
		button9.Content = Strings.Common_Close;
		StyledProperty<ICommand?> commandProperty13 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension34 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002ETogglePreviewCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding36 = compiledBindingExtension34.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button9.Bind(commandProperty13, binding36);
		button9.Padding = new Thickness(20.0, 8.0, 20.0, 8.0);
		context.PopParent();
		((ISupportInitialize)button8).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel28).EndInit();
		context.PopParent();
		((ISupportInitialize)grid36).EndInit();
		context.PopParent();
		((ISupportInitialize)border18).EndInit();
		context.PopParent();
		((ISupportInitialize)grid32).EndInit();
		context.PopParent();
		((ISupportInitialize)border14).EndInit();
		Avalonia.Controls.Controls children45 = grid5.Children;
		Grid grid51;
		Grid grid50 = (grid51 = new Grid());
		((ISupportInitialize)grid50).BeginInit();
		children45.Add(grid50);
		Grid grid52 = (grid4 = grid51);
		context.PushParent(grid4);
		Grid grid53 = grid4;
		grid53.IsHitTestVisible = false;
		StyledProperty<bool> isVisibleProperty7 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension35 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EMods_002EModsViewModel_002CMerostrap_002EIsDragOver_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding37 = compiledBindingExtension35.ProvideValue(context);
		context.ProvideTargetProperty = null;
		grid53.Bind(isVisibleProperty7, binding37);
		grid53.Background = new ImmutableSolidColorBrush(2281701376u);
		Avalonia.Controls.Controls children46 = grid53.Children;
		TextBlock textBlock23;
		TextBlock textBlock22 = (textBlock23 = new TextBlock());
		((ISupportInitialize)textBlock22).BeginInit();
		children46.Add(textBlock22);
		textBlock23.Text = Strings.Menu_Mods_DragOverlay;
		textBlock23.FontSize = 20.0;
		textBlock23.FontWeight = FontWeight.DemiBold;
		textBlock23.HorizontalAlignment = HorizontalAlignment.Center;
		textBlock23.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)textBlock23).EndInit();
		Avalonia.Controls.Controls children47 = grid53.Children;
		Grid grid55;
		Grid grid54 = (grid55 = new Grid());
		((ISupportInitialize)grid54).BeginInit();
		children47.Add(grid54);
		Grid grid56 = (grid4 = grid55);
		context.PushParent(grid4);
		Grid grid57 = grid4;
		Avalonia.Controls.Controls children48 = grid57.Children;
		Path path2;
		Path path = (path2 = new Path());
		((ISupportInitialize)path).BeginInit();
		children48.Add(path);
		Path path4;
		Path path3 = (path4 = path2);
		context.PushParent(path4);
		Path path5 = path4;
		StyledProperty<IBrush?> strokeProperty = Shape.StrokeProperty;
		DynamicResourceExtension dynamicResourceExtension10 = new DynamicResourceExtension("AccentButtonBackground");
		context.ProvideTargetProperty = Shape.StrokeProperty;
		BindingBase binding38 = dynamicResourceExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		path5.Bind(strokeProperty, binding38);
		path5.StrokeThickness = 3.0;
		path5.StrokeJoin = PenLineJoin.Round;
		path5.Data = Geometry.Parse("M 0,0 L 30,0 M 0,0 L 0,30");
		path5.HorizontalAlignment = HorizontalAlignment.Left;
		path5.VerticalAlignment = VerticalAlignment.Top;
		path5.Margin = new Thickness(10.0, 10.0, 0.0, 0.0);
		context.PopParent();
		((ISupportInitialize)path3).EndInit();
		Avalonia.Controls.Controls children49 = grid57.Children;
		Path path7;
		Path path6 = (path7 = new Path());
		((ISupportInitialize)path6).BeginInit();
		children49.Add(path6);
		Path path8 = (path4 = path7);
		context.PushParent(path4);
		Path path9 = path4;
		StyledProperty<IBrush?> strokeProperty2 = Shape.StrokeProperty;
		DynamicResourceExtension dynamicResourceExtension11 = new DynamicResourceExtension("AccentButtonBackground");
		context.ProvideTargetProperty = Shape.StrokeProperty;
		BindingBase binding39 = dynamicResourceExtension11.ProvideValue(context);
		context.ProvideTargetProperty = null;
		path9.Bind(strokeProperty2, binding39);
		path9.StrokeThickness = 3.0;
		path9.StrokeJoin = PenLineJoin.Round;
		path9.Data = Geometry.Parse("M 30,0 L 0,0 M 30,0 L 30,30");
		path9.HorizontalAlignment = HorizontalAlignment.Right;
		path9.VerticalAlignment = VerticalAlignment.Top;
		path9.Margin = new Thickness(0.0, 10.0, 10.0, 0.0);
		context.PopParent();
		((ISupportInitialize)path8).EndInit();
		Avalonia.Controls.Controls children50 = grid57.Children;
		Path path11;
		Path path10 = (path11 = new Path());
		((ISupportInitialize)path10).BeginInit();
		children50.Add(path10);
		Path path12 = (path4 = path11);
		context.PushParent(path4);
		Path path13 = path4;
		StyledProperty<IBrush?> strokeProperty3 = Shape.StrokeProperty;
		DynamicResourceExtension dynamicResourceExtension12 = new DynamicResourceExtension("AccentButtonBackground");
		context.ProvideTargetProperty = Shape.StrokeProperty;
		BindingBase binding40 = dynamicResourceExtension12.ProvideValue(context);
		context.ProvideTargetProperty = null;
		path13.Bind(strokeProperty3, binding40);
		path13.StrokeThickness = 3.0;
		path13.StrokeJoin = PenLineJoin.Round;
		path13.Data = Geometry.Parse("M 0,30 L 30,30 M 0,30 L 0,0");
		path13.HorizontalAlignment = HorizontalAlignment.Left;
		path13.VerticalAlignment = VerticalAlignment.Bottom;
		path13.Margin = new Thickness(10.0, 0.0, 0.0, 10.0);
		context.PopParent();
		((ISupportInitialize)path12).EndInit();
		Avalonia.Controls.Controls children51 = grid57.Children;
		Path path15;
		Path path14 = (path15 = new Path());
		((ISupportInitialize)path14).BeginInit();
		children51.Add(path14);
		Path path16 = (path4 = path15);
		context.PushParent(path4);
		Path path17 = path4;
		StyledProperty<IBrush?> strokeProperty4 = Shape.StrokeProperty;
		DynamicResourceExtension dynamicResourceExtension13 = new DynamicResourceExtension("AccentButtonBackground");
		context.ProvideTargetProperty = Shape.StrokeProperty;
		BindingBase binding41 = dynamicResourceExtension13.ProvideValue(context);
		context.ProvideTargetProperty = null;
		path17.Bind(strokeProperty4, binding41);
		path17.StrokeThickness = 3.0;
		path17.StrokeJoin = PenLineJoin.Round;
		path17.Data = Geometry.Parse("M 30,30 L 0,30 M 30,30 L 30,0");
		path17.HorizontalAlignment = HorizontalAlignment.Right;
		path17.VerticalAlignment = VerticalAlignment.Bottom;
		path17.Margin = new Thickness(0.0, 0.0, 10.0, 10.0);
		context.PopParent();
		((ISupportInitialize)path16).EndInit();
		context.PopParent();
		((ISupportInitialize)grid56).EndInit();
		context.PopParent();
		((ISupportInitialize)grid52).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(ModsPage P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
