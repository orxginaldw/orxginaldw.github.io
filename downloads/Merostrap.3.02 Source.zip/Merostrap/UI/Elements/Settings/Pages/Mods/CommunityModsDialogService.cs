using System;
using Merostrap.UI.ViewModels.Settings;

namespace Merostrap.UI.Elements.Settings.Pages.Mods;

internal class CommunityModsDialogService(MainWindowViewModel mainVm)
{
	private readonly MainWindowViewModel _mainVm = mainVm ?? throw new ArgumentNullException("mainVm");

	public void OpenPresetMods()
	{
		_mainVm.NavigateToPresetModsCommand.Execute(null);
	}

	public void OpenMods()
	{
		_mainVm.NavigateToMyModsCommand.Execute(null);
	}

	public void OpenModGenerator()
	{
		_mainVm.NavigateToModGeneratorCommand.Execute(null);
	}
}
