using System;
using Merostrap.UI.ViewModels.Settings;

namespace Merostrap.UI.Elements.Settings.Pages.Mods;

internal class ModGeneratorDialogService(MainWindowViewModel mainVm)
{
	private readonly MainWindowViewModel _mainVm = mainVm ?? throw new ArgumentNullException("mainVm");

	public void OpenCommunityMods()
	{
		_mainVm.NavigateToCommunityModsCommand.Execute(null);
	}

	public void OpenPresetMods()
	{
		_mainVm.NavigateToPresetModsCommand.Execute(null);
	}

	public void OpenMyMods()
	{
		_mainVm.NavigateToMyModsCommand.Execute(null);
	}
}
