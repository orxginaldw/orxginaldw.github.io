using System;
using System.CodeDom.Compiler;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml.XPath;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Data;
using Avalonia.Data.Converters;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using CompiledAvaloniaXaml;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.Models;
using Merostrap.Resources;

namespace Merostrap.UI.Elements.Settings.Pages.GlobalSettings;

internal class GlobalSettingsEditor : UserControl, IDisposable
{
	[CompilerGenerated]
	private class XamlClosure_43
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<GlobalSettingsEditor> context = CreateContext(P_0);
			context.IntermediateRoot = new TextBox();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			TextBox textBox = (TextBox)obj;
			context.PushParent(textBox);
			StyledProperty<string?> textProperty = TextBox.TextProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EGlobalSetting_002CMerostrap_002EValue_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBox.TextProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBox.Bind(textProperty, binding);
			StyledProperty<bool> isEnabledProperty = InputElement.IsEnabledProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Merostrap_002EModels_002EGlobalSetting_002CMerostrap_002EIsVector_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = InputElement.IsEnabledProperty;
			CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBox.Bind(isEnabledProperty, binding2);
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<GlobalSettingsEditor> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<GlobalSettingsEditor> context = new XamlIlContext.Context<GlobalSettingsEditor>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FPages_002FGlobalSettings_002FGlobalSettingsEditor_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/Pages/GlobalSettings/GlobalSettingsEditor.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (GlobalSettingsEditor)service;
				}
			}
			return context;
		}

		public static object Build_2(IServiceProvider P_0)
		{
			XamlIlContext.Context<GlobalSettingsEditor> context = CreateContext(P_0);
			context.IntermediateRoot = new TextBlock();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			TextBlock textBlock = (TextBlock)obj;
			context.PushParent(textBlock);
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EGlobalSetting_002CMerostrap_002EValue_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock.Bind(textProperty, binding);
			textBlock.VerticalAlignment = VerticalAlignment.Center;
			textBlock.Margin = new Thickness(10.0, 0.0, 10.0, 0.0);
			StyledProperty<double> opacityProperty = Visual.OpacityProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EGlobalSetting_002CMerostrap_002EIsVector_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
			{
				Converter = DimIfTrue
			};
			context.ProvideTargetProperty = Visual.OpacityProperty;
			CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock.Bind(opacityProperty, binding2);
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_3(IServiceProvider P_0)
		{
			XamlIlContext.Context<GlobalSettingsEditor> context = CreateContext(P_0);
			context.IntermediateRoot = new TextBox();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			TextBox textBox = (TextBox)obj;
			context.PushParent(textBox);
			StyledProperty<string?> textProperty = TextBox.TextProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EGlobalSetting_002CMerostrap_002EVectorX_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBox.TextProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBox.Bind(textProperty, binding);
			StyledProperty<bool> isEnabledProperty = InputElement.IsEnabledProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EGlobalSetting_002CMerostrap_002EIsVector_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = InputElement.IsEnabledProperty;
			CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBox.Bind(isEnabledProperty, binding2);
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_4(IServiceProvider P_0)
		{
			XamlIlContext.Context<GlobalSettingsEditor> context = CreateContext(P_0);
			context.IntermediateRoot = new TextBlock();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			TextBlock textBlock = (TextBlock)obj;
			context.PushParent(textBlock);
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EGlobalSetting_002CMerostrap_002EVectorX_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock.Bind(textProperty, binding);
			textBlock.VerticalAlignment = VerticalAlignment.Center;
			textBlock.Margin = new Thickness(10.0, 0.0, 10.0, 0.0);
			StyledProperty<double> opacityProperty = Visual.OpacityProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EGlobalSetting_002CMerostrap_002EIsVector_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
			{
				Converter = DimIfFalse
			};
			context.ProvideTargetProperty = Visual.OpacityProperty;
			CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock.Bind(opacityProperty, binding2);
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_5(IServiceProvider P_0)
		{
			XamlIlContext.Context<GlobalSettingsEditor> context = CreateContext(P_0);
			context.IntermediateRoot = new TextBox();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			TextBox textBox = (TextBox)obj;
			context.PushParent(textBox);
			StyledProperty<string?> textProperty = TextBox.TextProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EGlobalSetting_002CMerostrap_002EVectorY_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBox.TextProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBox.Bind(textProperty, binding);
			StyledProperty<bool> isEnabledProperty = InputElement.IsEnabledProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EGlobalSetting_002CMerostrap_002EIsVector_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = InputElement.IsEnabledProperty;
			CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBox.Bind(isEnabledProperty, binding2);
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_6(IServiceProvider P_0)
		{
			XamlIlContext.Context<GlobalSettingsEditor> context = CreateContext(P_0);
			context.IntermediateRoot = new TextBlock();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			TextBlock textBlock = (TextBlock)obj;
			context.PushParent(textBlock);
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EGlobalSetting_002CMerostrap_002EVectorY_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock.Bind(textProperty, binding);
			textBlock.VerticalAlignment = VerticalAlignment.Center;
			textBlock.Margin = new Thickness(10.0, 0.0, 10.0, 0.0);
			StyledProperty<double> opacityProperty = Visual.OpacityProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EGlobalSetting_002CMerostrap_002EIsVector_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
			{
				Converter = DimIfFalse
			};
			context.ProvideTargetProperty = Visual.OpacityProperty;
			CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock.Bind(opacityProperty, binding2);
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}
	}

	public static readonly IValueConverter DimIfTrue = new FuncValueConverter<bool, double>((bool x) => (!x) ? 1.0 : 0.3);

	public static readonly IValueConverter DimIfFalse = new FuncValueConverter<bool, double>((bool x) => (!x) ? 0.3 : 1.0);

	private readonly ObservableCollection<GlobalSetting> _globalSettingsList = new ObservableCollection<GlobalSetting>();

	private string _searchFilter = string.Empty;

	private CancellationTokenSource? _searchCancellationTokenSource;

	private bool _disposed;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBox SearchTextBox;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal DataGrid DataGrid;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public GlobalSettingsEditor()
	{
		InitializeComponent();
		DataGrid.ItemsSource = _globalSettingsList;
		App.FrostRPC?.SetPage("Global Settings Editor");
	}

	protected override void OnLoaded(RoutedEventArgs e)
	{
		base.OnLoaded(e);
		if (!App.GlobalSettings.Loaded)
		{
			App.GlobalSettings.Load();
		}
		ReloadList();
	}

	public void ReloadList()
	{
		_globalSettingsList.Clear();
		if (App.GlobalSettings.Document == null)
		{
			App.GlobalSettings.Load();
		}
		string expression = App.GlobalSettings.RootPaths["UserSettings"];
		XElement xElement = App.GlobalSettings.Document?.XPathSelectElement(expression);
		if (xElement == null)
		{
			return;
		}
		foreach (XElement item in from x in xElement.Elements()
			orderby x.Attribute("name")?.Value
			select x)
		{
			string text = item.Attribute("name")?.Value;
			if (!string.IsNullOrEmpty(text) && (string.IsNullOrEmpty(_searchFilter) || text.Contains(_searchFilter, StringComparison.OrdinalIgnoreCase)))
			{
				GlobalSetting globalSetting = new GlobalSetting
				{
					Name = text
				};
				if (item.Name.LocalName == "Vector2")
				{
					globalSetting.IsVector = true;
					globalSetting.VectorX = item.Element("X")?.Value ?? "0";
					globalSetting.VectorY = item.Element("Y")?.Value ?? "0";
					globalSetting.Value = string.Empty;
				}
				else
				{
					globalSetting.IsVector = false;
					globalSetting.Value = item.Value ?? string.Empty;
					globalSetting.VectorX = string.Empty;
					globalSetting.VectorY = string.Empty;
				}
				_globalSettingsList.Add(globalSetting);
			}
		}
	}

	private async void SearchTextBox_TextChanged(object? sender, TextChangedEventArgs e)
	{
		_searchCancellationTokenSource?.Cancel();
		_searchCancellationTokenSource = new CancellationTokenSource();
		try
		{
			await Task.Delay(70, _searchCancellationTokenSource.Token);
			_searchFilter = (sender as TextBox)?.Text?.Trim() ?? "";
			ReloadList();
		}
		catch (TaskCanceledException)
		{
		}
	}

	private void DataGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
	{
		if (!(e.Row.DataContext is GlobalSetting globalSetting) || !(e.EditingElement is TextBox { Text: var text }))
		{
			return;
		}
		string text2 = text?.Trim() ?? string.Empty;
		string text3 = e.Column.Header?.ToString() ?? string.Empty;
		string text4 = App.GlobalSettings.RootPaths["UserSettings"] + "/*[@name='" + globalSetting.Name + "']";
		if (globalSetting.IsVector)
		{
			if (text3 == Strings.Menu_GBSEditor_VectorX)
			{
				globalSetting.VectorX = text2;
				App.GlobalSettings.Document?.XPathSelectElement(text4 + "/X")?.SetValue(text2);
			}
			else if (text3 == Strings.Menu_GBSEditor_VectorY)
			{
				globalSetting.VectorY = text2;
				App.GlobalSettings.Document?.XPathSelectElement(text4 + "/Y")?.SetValue(text2);
			}
		}
		else if (text3 == Strings.Common_Value)
		{
			globalSetting.Value = text2;
			App.GlobalSettings.Document?.XPathSelectElement(text4)?.SetValue(text2);
		}
	}

	public void Dispose()
	{
		Dispose(disposing: true);
		GC.SuppressFinalize(this);
	}

	protected virtual void Dispose(bool disposing)
	{
		if (!_disposed)
		{
			if (disposing)
			{
				_searchCancellationTokenSource?.Cancel();
				_searchCancellationTokenSource?.Dispose();
				_searchCancellationTokenSource = null;
			}
			_disposed = true;
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		SearchTextBox = nameScope?.Find<TextBox>("SearchTextBox");
		DataGrid = nameScope?.Find<DataGrid>("DataGrid");
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, GlobalSettingsEditor P_1)
	{
		XamlIlContext.Context<GlobalSettingsEditor> context = new XamlIlContext.Context<GlobalSettingsEditor>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FPages_002FGlobalSettings_002FGlobalSettingsEditor_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/Pages/GlobalSettings/GlobalSettingsEditor.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid4.RowDefinitions = rowDefinitions;
		grid4.Margin = new Thickness(14.0, 14.0, 14.0, 14.0);
		Avalonia.Controls.Controls children = grid4.Children;
		Grid grid6;
		Grid grid5 = (grid6 = new Grid());
		((ISupportInitialize)grid5).BeginInit();
		children.Add(grid5);
		Grid.SetRow(grid6, 0);
		grid6.Margin = new Thickness(0.0, 0.0, 0.0, 10.0);
		Avalonia.Controls.Controls children2 = grid6.Children;
		TextBox textBox2;
		TextBox textBox = (textBox2 = new TextBox());
		((ISupportInitialize)textBox).BeginInit();
		children2.Add(textBox);
		textBox2.Name = "SearchTextBox";
		object element = textBox2;
		context.AvaloniaNameScope.Register("SearchTextBox", element);
		textBox2.VerticalContentAlignment = VerticalAlignment.Center;
		textBox2.PlaceholderText = "Search settings...";
		textBox2.AddHandler(TextBox.TextChangedEvent, context.RootObject.SearchTextBox_TextChanged);
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		textBox2.InnerLeftContent = lucide;
		lucide2.Height = 16.0;
		lucide2.Width = 16.0;
		lucide2.Icon = LucideIconNames.Search;
		lucide2.Margin = new Thickness(10.0, 0.0, 0.0, 0.0);
		lucide2.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)lucide2).EndInit();
		((ISupportInitialize)textBox2).EndInit();
		((ISupportInitialize)grid6).EndInit();
		Avalonia.Controls.Controls children3 = grid4.Children;
		DataGrid dataGrid2;
		DataGrid dataGrid = (dataGrid2 = new DataGrid());
		((ISupportInitialize)dataGrid).BeginInit();
		children3.Add(dataGrid);
		DataGrid dataGrid4;
		DataGrid dataGrid3 = (dataGrid4 = dataGrid2);
		context.PushParent(dataGrid4);
		Grid.SetRow(dataGrid4, 1);
		dataGrid4.Name = "DataGrid";
		element = dataGrid4;
		context.AvaloniaNameScope.Register("DataGrid", element);
		dataGrid4.AutoGenerateColumns = false;
		dataGrid4.CanUserResizeColumns = true;
		dataGrid4.CellEditEnding += context.RootObject.DataGrid_CellEditEnding;
		dataGrid4.GridLinesVisibility = DataGridGridLinesVisibility.Horizontal;
		ObservableCollection<DataGridColumn> columns = dataGrid4.Columns;
		DataGridTextColumn dataGridTextColumn;
		DataGridTextColumn item = (dataGridTextColumn = new DataGridTextColumn());
		context.PushParent(dataGridTextColumn);
		dataGridTextColumn.Header = Strings.Common_Name;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EGlobalSetting_002CMerostrap_002EName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EControls_002EDataGridBoundColumn_002CAvalonia_002EControls_002EDataGrid_002EBinding_0021Property();
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		dataGridTextColumn.Binding = binding;
		dataGridTextColumn.IsReadOnly = true;
		dataGridTextColumn.Width = (DataGridLength)new DataGridLengthConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "*");
		context.PopParent();
		columns.Add(item);
		ObservableCollection<DataGridColumn> columns2 = dataGrid4.Columns;
		DataGridTemplateColumn dataGridTemplateColumn;
		DataGridTemplateColumn item2 = (dataGridTemplateColumn = new DataGridTemplateColumn());
		context.PushParent(dataGridTemplateColumn);
		DataGridTemplateColumn dataGridTemplateColumn2 = dataGridTemplateColumn;
		dataGridTemplateColumn2.Header = Strings.Common_Value;
		dataGridTemplateColumn2.Width = (DataGridLength)new DataGridLengthConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "150");
		DataTemplate dataTemplate;
		DataTemplate cellEditingTemplate = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_43.Build_1), context);
		context.PopParent();
		dataGridTemplateColumn2.CellEditingTemplate = cellEditingTemplate;
		DataTemplate cellTemplate = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_43.Build_2), context);
		context.PopParent();
		dataGridTemplateColumn2.CellTemplate = cellTemplate;
		context.PopParent();
		columns2.Add(item2);
		ObservableCollection<DataGridColumn> columns3 = dataGrid4.Columns;
		DataGridTemplateColumn item3 = (dataGridTemplateColumn = new DataGridTemplateColumn());
		context.PushParent(dataGridTemplateColumn);
		DataGridTemplateColumn dataGridTemplateColumn3 = dataGridTemplateColumn;
		dataGridTemplateColumn3.Header = Strings.Menu_GBSEditor_VectorX;
		dataGridTemplateColumn3.Width = (DataGridLength)new DataGridLengthConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "100");
		DataTemplate cellEditingTemplate2 = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_43.Build_3), context);
		context.PopParent();
		dataGridTemplateColumn3.CellEditingTemplate = cellEditingTemplate2;
		DataTemplate cellTemplate2 = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_43.Build_4), context);
		context.PopParent();
		dataGridTemplateColumn3.CellTemplate = cellTemplate2;
		context.PopParent();
		columns3.Add(item3);
		ObservableCollection<DataGridColumn> columns4 = dataGrid4.Columns;
		DataGridTemplateColumn item4 = (dataGridTemplateColumn = new DataGridTemplateColumn());
		context.PushParent(dataGridTemplateColumn);
		DataGridTemplateColumn dataGridTemplateColumn4 = dataGridTemplateColumn;
		dataGridTemplateColumn4.Header = Strings.Menu_GBSEditor_VectorY;
		dataGridTemplateColumn4.Width = (DataGridLength)new DataGridLengthConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "100");
		DataTemplate cellEditingTemplate3 = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_43.Build_5), context);
		context.PopParent();
		dataGridTemplateColumn4.CellEditingTemplate = cellEditingTemplate3;
		DataTemplate cellTemplate3 = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_43.Build_6), context);
		context.PopParent();
		dataGridTemplateColumn4.CellTemplate = cellTemplate3;
		context.PopParent();
		columns4.Add(item4);
		context.PopParent();
		((ISupportInitialize)dataGrid3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(GlobalSettingsEditor P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
