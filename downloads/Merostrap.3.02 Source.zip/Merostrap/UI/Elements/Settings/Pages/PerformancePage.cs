using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Data.Converters;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using CompiledAvaloniaXaml;
using Merostrap.UI.Elements.Controls;

namespace Merostrap.UI.Elements.Settings.Pages;

internal class PerformancePage : UserControl
{
	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBlock ProfileStatus;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal ToggleSwitch PerformanceModeToggle;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal ToggleSwitch GameCpuPriorityToggle;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal ToggleSwitch NearbyServersToggle;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal ToggleSwitch NetworkModeToggle;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal ToggleSwitch NoShadowsToggle;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public PerformancePage()
	{
		InitializeComponent();
	}

	protected override void OnUnloaded(RoutedEventArgs e)
	{
		base.OnUnloaded(e);
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		ProfileStatus = nameScope?.Find<TextBlock>("ProfileStatus");
		PerformanceModeToggle = nameScope?.Find<ToggleSwitch>("PerformanceModeToggle");
		GameCpuPriorityToggle = nameScope?.Find<ToggleSwitch>("GameCpuPriorityToggle");
		NearbyServersToggle = nameScope?.Find<ToggleSwitch>("NearbyServersToggle");
		NetworkModeToggle = nameScope?.Find<ToggleSwitch>("NetworkModeToggle");
		NoShadowsToggle = nameScope?.Find<ToggleSwitch>("NoShadowsToggle");
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, PerformancePage P_1)
	{
		XamlIlContext.Context<PerformancePage> context = new XamlIlContext.Context<PerformancePage>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FPages_002FPerformancePage_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/Pages/PerformancePage.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		P_1.Content = scrollViewer;
		ScrollViewer scrollViewer4;
		ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
		context.PushParent(scrollViewer4);
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		scrollViewer4.Content = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		stackPanel4.Margin = new Thickness(14.0, 14.0, 14.0, 14.0);
		stackPanel4.Spacing = 6.0;
		Avalonia.Controls.Controls children = stackPanel4.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children.Add(textBlock);
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = textBlock2);
		context.PushParent(textBlock4);
		textBlock4.Name = "ProfileStatus";
		object element = textBlock4;
		context.AvaloniaNameScope.Register("ProfileStatus", element);
		StyledProperty<string?> textProperty = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EPerformanceViewModel_002CMerostrap_002EStatus_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock4.Bind(textProperty, binding);
		textBlock4.TextWrapping = TextWrapping.Wrap;
		textBlock4.Margin = new Thickness(4.0, 0.0, 4.0, 0.0);
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EPerformanceViewModel_002CMerostrap_002EStatus_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Converter = StringConverters.IsNotNullOrEmpty
		};
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock4.Bind(isVisibleProperty, binding2);
		context.PopParent();
		((ISupportInitialize)textBlock3).EndInit();
		Avalonia.Controls.Controls children2 = stackPanel4.Children;
		TextBlock textBlock6;
		TextBlock textBlock5 = (textBlock6 = new TextBlock());
		((ISupportInitialize)textBlock5).BeginInit();
		children2.Add(textBlock5);
		textBlock6.Text = "Background activity";
		textBlock6.FontSize = 20.0;
		textBlock6.FontWeight = FontWeight.DemiBold;
		textBlock6.Margin = new Thickness(4.0, 10.0, 4.0, 6.0);
		((ISupportInitialize)textBlock6).EndInit();
		Avalonia.Controls.Controls children3 = stackPanel4.Children;
		OptionControl optionControl2;
		OptionControl optionControl = (optionControl2 = new OptionControl());
		((ISupportInitialize)optionControl).BeginInit();
		children3.Add(optionControl);
		OptionControl optionControl4;
		OptionControl optionControl3 = (optionControl4 = optionControl2);
		context.PushParent(optionControl4);
		OptionControl optionControl5 = optionControl4;
		optionControl5.Header = "Performance mode";
		optionControl5.Description = "Reduce background activity during play.";
		ToggleSwitch toggleSwitch2;
		ToggleSwitch toggleSwitch = (toggleSwitch2 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch).BeginInit();
		optionControl5.InnerContent = toggleSwitch;
		ToggleSwitch toggleSwitch4;
		ToggleSwitch toggleSwitch3 = (toggleSwitch4 = toggleSwitch2);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch5 = toggleSwitch4;
		toggleSwitch5.Name = "PerformanceModeToggle";
		element = toggleSwitch5;
		context.AvaloniaNameScope.Register("PerformanceModeToggle", element);
		AutomationProperties.SetName(toggleSwitch5, "Performance mode");
		StyledProperty<bool?> isCheckedProperty = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EPerformanceViewModel_002CMerostrap_002EEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding3 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch5.Bind(isCheckedProperty, binding3);
		context.PopParent();
		((ISupportInitialize)toggleSwitch3).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl3).EndInit();
		Avalonia.Controls.Controls children4 = stackPanel4.Children;
		OptionControl optionControl7;
		OptionControl optionControl6 = (optionControl7 = new OptionControl());
		((ISupportInitialize)optionControl6).BeginInit();
		children4.Add(optionControl6);
		OptionControl optionControl8 = (optionControl4 = optionControl7);
		context.PushParent(optionControl4);
		OptionControl optionControl9 = optionControl4;
		optionControl9.Header = "Prioritize Roblox CPU time";
		StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EPerformanceViewModel_002CMerostrap_002EWindowsSupported_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding4 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		optionControl9.Bind(isVisibleProperty2, binding4);
		ToggleSwitch toggleSwitch7;
		ToggleSwitch toggleSwitch6 = (toggleSwitch7 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch6).BeginInit();
		optionControl9.InnerContent = toggleSwitch6;
		ToggleSwitch toggleSwitch8 = (toggleSwitch4 = toggleSwitch7);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch9 = toggleSwitch4;
		toggleSwitch9.Name = "GameCpuPriorityToggle";
		element = toggleSwitch9;
		context.AvaloniaNameScope.Register("GameCpuPriorityToggle", element);
		StyledProperty<bool?> isCheckedProperty2 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EPerformanceViewModel_002CMerostrap_002EPrioritizeGameCpu_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding5 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch9.Bind(isCheckedProperty2, binding5);
		context.PopParent();
		((ISupportInitialize)toggleSwitch8).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl8).EndInit();
		Avalonia.Controls.Controls children5 = stackPanel4.Children;
		OptionControl optionControl11;
		OptionControl optionControl10 = (optionControl11 = new OptionControl());
		((ISupportInitialize)optionControl10).BeginInit();
		children5.Add(optionControl10);
		OptionControl optionControl12 = (optionControl4 = optionControl11);
		context.PushParent(optionControl4);
		OptionControl optionControl13 = optionControl4;
		optionControl13.Header = "Prefer nearby public servers";
		ToggleSwitch toggleSwitch11;
		ToggleSwitch toggleSwitch10 = (toggleSwitch11 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch10).BeginInit();
		optionControl13.InnerContent = toggleSwitch10;
		ToggleSwitch toggleSwitch12 = (toggleSwitch4 = toggleSwitch11);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch13 = toggleSwitch4;
		toggleSwitch13.Name = "NearbyServersToggle";
		element = toggleSwitch13;
		context.AvaloniaNameScope.Register("NearbyServersToggle", element);
		StyledProperty<bool?> isCheckedProperty3 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EPerformanceViewModel_002CMerostrap_002EPreferNearbyServers_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding6 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch13.Bind(isCheckedProperty3, binding6);
		context.PopParent();
		((ISupportInitialize)toggleSwitch12).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl12).EndInit();
		Avalonia.Controls.Controls children6 = stackPanel4.Children;
		OptionControl optionControl15;
		OptionControl optionControl14 = (optionControl15 = new OptionControl());
		((ISupportInitialize)optionControl14).BeginInit();
		children6.Add(optionControl14);
		OptionControl optionControl16 = (optionControl4 = optionControl15);
		context.PushParent(optionControl4);
		OptionControl optionControl17 = optionControl4;
		optionControl17.Header = "Network mode";
		optionControl17.Description = "Reduce background network activity.";
		ToggleSwitch toggleSwitch15;
		ToggleSwitch toggleSwitch14 = (toggleSwitch15 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch14).BeginInit();
		optionControl17.InnerContent = toggleSwitch14;
		ToggleSwitch toggleSwitch16 = (toggleSwitch4 = toggleSwitch15);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch17 = toggleSwitch4;
		toggleSwitch17.Name = "NetworkModeToggle";
		element = toggleSwitch17;
		context.AvaloniaNameScope.Register("NetworkModeToggle", element);
		StyledProperty<bool?> isCheckedProperty4 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EPerformanceViewModel_002CMerostrap_002ENetworkMode_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding7 = compiledBindingExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch17.Bind(isCheckedProperty4, binding7);
		context.PopParent();
		((ISupportInitialize)toggleSwitch16).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl16).EndInit();
		Avalonia.Controls.Controls children7 = stackPanel4.Children;
		OptionControl optionControl19;
		OptionControl optionControl18 = (optionControl19 = new OptionControl());
		((ISupportInitialize)optionControl18).BeginInit();
		children7.Add(optionControl18);
		OptionControl optionControl20 = (optionControl4 = optionControl19);
		context.PushParent(optionControl4);
		OptionControl optionControl21 = optionControl4;
		optionControl21.Header = "Low render quality";
		StyledProperty<bool> isEnabledProperty = InputElement.IsEnabledProperty;
		CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EPerformanceViewModel_002CMerostrap_002ECanCustomizeGraphics_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = InputElement.IsEnabledProperty;
		CompiledBinding binding8 = compiledBindingExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		optionControl21.Bind(isEnabledProperty, binding8);
		ToggleSwitch toggleSwitch19;
		ToggleSwitch toggleSwitch18 = (toggleSwitch19 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch18).BeginInit();
		optionControl21.InnerContent = toggleSwitch18;
		ToggleSwitch toggleSwitch20 = (toggleSwitch4 = toggleSwitch19);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch21 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty5 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EPerformanceViewModel_002CMerostrap_002ELowerRenderQuality_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding9 = compiledBindingExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch21.Bind(isCheckedProperty5, binding9);
		context.PopParent();
		((ISupportInitialize)toggleSwitch20).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl20).EndInit();
		Avalonia.Controls.Controls children8 = stackPanel4.Children;
		OptionControl optionControl23;
		OptionControl optionControl22 = (optionControl23 = new OptionControl());
		((ISupportInitialize)optionControl22).BeginInit();
		children8.Add(optionControl22);
		OptionControl optionControl24 = (optionControl4 = optionControl23);
		context.PushParent(optionControl4);
		OptionControl optionControl25 = optionControl4;
		optionControl25.Header = "Lower texture quality";
		ToggleSwitch toggleSwitch23;
		ToggleSwitch toggleSwitch22 = (toggleSwitch23 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch22).BeginInit();
		optionControl25.InnerContent = toggleSwitch22;
		ToggleSwitch toggleSwitch24 = (toggleSwitch4 = toggleSwitch23);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch25 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty6 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EPerformanceViewModel_002CMerostrap_002ELowTextures_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding10 = compiledBindingExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch25.Bind(isCheckedProperty6, binding10);
		StyledProperty<bool> isEnabledProperty2 = InputElement.IsEnabledProperty;
		CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EPerformanceViewModel_002CMerostrap_002ECanCustomizeGraphics_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = InputElement.IsEnabledProperty;
		CompiledBinding binding11 = compiledBindingExtension11.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch25.Bind(isEnabledProperty2, binding11);
		context.PopParent();
		((ISupportInitialize)toggleSwitch24).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl24).EndInit();
		Avalonia.Controls.Controls children9 = stackPanel4.Children;
		OptionControl optionControl27;
		OptionControl optionControl26 = (optionControl27 = new OptionControl());
		((ISupportInitialize)optionControl26).BeginInit();
		children9.Add(optionControl26);
		OptionControl optionControl28 = (optionControl4 = optionControl27);
		context.PushParent(optionControl4);
		OptionControl optionControl29 = optionControl4;
		optionControl29.Header = "Reduce grass";
		ToggleSwitch toggleSwitch27;
		ToggleSwitch toggleSwitch26 = (toggleSwitch27 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch26).BeginInit();
		optionControl29.InnerContent = toggleSwitch26;
		ToggleSwitch toggleSwitch28 = (toggleSwitch4 = toggleSwitch27);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch29 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty7 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EPerformanceViewModel_002CMerostrap_002EReduceGrass_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding12 = compiledBindingExtension12.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch29.Bind(isCheckedProperty7, binding12);
		StyledProperty<bool> isEnabledProperty3 = InputElement.IsEnabledProperty;
		CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EPerformanceViewModel_002CMerostrap_002ECanCustomizeGraphics_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = InputElement.IsEnabledProperty;
		CompiledBinding binding13 = compiledBindingExtension13.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch29.Bind(isEnabledProperty3, binding13);
		context.PopParent();
		((ISupportInitialize)toggleSwitch28).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl28).EndInit();
		Avalonia.Controls.Controls children10 = stackPanel4.Children;
		OptionControl optionControl31;
		OptionControl optionControl30 = (optionControl31 = new OptionControl());
		((ISupportInitialize)optionControl30).BeginInit();
		children10.Add(optionControl30);
		OptionControl optionControl32 = (optionControl4 = optionControl31);
		context.PushParent(optionControl4);
		OptionControl optionControl33 = optionControl4;
		optionControl33.Header = "No shadows";
		optionControl33.Description = "Apply baked-shadow reduction and legacy player-shadow removal on the next Roblox launch. Roblox may ignore the legacy setting; some shadows may remain.";
		StyledProperty<bool> isEnabledProperty4 = InputElement.IsEnabledProperty;
		CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EPerformanceViewModel_002CMerostrap_002EGraphicsSupported_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = InputElement.IsEnabledProperty;
		CompiledBinding binding14 = compiledBindingExtension14.ProvideValue(context);
		context.ProvideTargetProperty = null;
		optionControl33.Bind(isEnabledProperty4, binding14);
		ToggleSwitch toggleSwitch31;
		ToggleSwitch toggleSwitch30 = (toggleSwitch31 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch30).BeginInit();
		optionControl33.InnerContent = toggleSwitch30;
		ToggleSwitch toggleSwitch32 = (toggleSwitch4 = toggleSwitch31);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch33 = toggleSwitch4;
		toggleSwitch33.Name = "NoShadowsToggle";
		element = toggleSwitch33;
		context.AvaloniaNameScope.Register("NoShadowsToggle", element);
		AutomationProperties.SetName(toggleSwitch33, "No shadows");
		StyledProperty<bool?> isCheckedProperty8 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension15 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EPerformanceViewModel_002CMerostrap_002ENoShadows_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding15 = compiledBindingExtension15.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch33.Bind(isCheckedProperty8, binding15);
		context.PopParent();
		((ISupportInitialize)toggleSwitch32).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl32).EndInit();
		Avalonia.Controls.Controls children11 = stackPanel4.Children;
		OptionControl optionControl35;
		OptionControl optionControl34 = (optionControl35 = new OptionControl());
		((ISupportInitialize)optionControl34).BeginInit();
		children11.Add(optionControl34);
		OptionControl optionControl36 = (optionControl4 = optionControl35);
		context.PushParent(optionControl4);
		OptionControl optionControl37 = optionControl4;
		optionControl37.Header = "Reduce anti-aliasing";
		ToggleSwitch toggleSwitch35;
		ToggleSwitch toggleSwitch34 = (toggleSwitch35 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch34).BeginInit();
		optionControl37.InnerContent = toggleSwitch34;
		ToggleSwitch toggleSwitch36 = (toggleSwitch4 = toggleSwitch35);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch37 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty9 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension16 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EPerformanceViewModel_002CMerostrap_002EReduceAntiAliasing_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding16 = compiledBindingExtension16.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch37.Bind(isCheckedProperty9, binding16);
		StyledProperty<bool> isEnabledProperty5 = InputElement.IsEnabledProperty;
		CompiledBindingExtension compiledBindingExtension17 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EPerformanceViewModel_002CMerostrap_002ECanCustomizeGraphics_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = InputElement.IsEnabledProperty;
		CompiledBinding binding17 = compiledBindingExtension17.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch37.Bind(isEnabledProperty5, binding17);
		context.PopParent();
		((ISupportInitialize)toggleSwitch36).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl36).EndInit();
		Avalonia.Controls.Controls children12 = stackPanel4.Children;
		OptionControl optionControl39;
		OptionControl optionControl38 = (optionControl39 = new OptionControl());
		((ISupportInitialize)optionControl38).BeginInit();
		children12.Add(optionControl38);
		OptionControl optionControl40 = (optionControl4 = optionControl39);
		context.PushParent(optionControl4);
		OptionControl optionControl41 = optionControl4;
		optionControl41.Header = "Avoid background downloads";
		ToggleSwitch toggleSwitch39;
		ToggleSwitch toggleSwitch38 = (toggleSwitch39 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch38).BeginInit();
		optionControl41.InnerContent = toggleSwitch38;
		ToggleSwitch toggleSwitch40 = (toggleSwitch4 = toggleSwitch39);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch41 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty10 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension18 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EPerformanceViewModel_002CMerostrap_002EAvoidBackgroundDownloads_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding18 = compiledBindingExtension18.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch41.Bind(isCheckedProperty10, binding18);
		StyledProperty<bool> isEnabledProperty6 = InputElement.IsEnabledProperty;
		CompiledBindingExtension compiledBindingExtension19 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EPerformanceViewModel_002CMerostrap_002ECanCustomize_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = InputElement.IsEnabledProperty;
		CompiledBinding binding19 = compiledBindingExtension19.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch41.Bind(isEnabledProperty6, binding19);
		context.PopParent();
		((ISupportInitialize)toggleSwitch40).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl40).EndInit();
		Avalonia.Controls.Controls children13 = stackPanel4.Children;
		OptionControl optionControl43;
		OptionControl optionControl42 = (optionControl43 = new OptionControl());
		((ISupportInitialize)optionControl42).BeginInit();
		children13.Add(optionControl42);
		OptionControl optionControl44 = (optionControl4 = optionControl43);
		context.PushParent(optionControl4);
		OptionControl optionControl45 = optionControl4;
		optionControl45.Header = "Reduce launcher animations";
		ToggleSwitch toggleSwitch43;
		ToggleSwitch toggleSwitch42 = (toggleSwitch43 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch42).BeginInit();
		optionControl45.InnerContent = toggleSwitch42;
		ToggleSwitch toggleSwitch44 = (toggleSwitch4 = toggleSwitch43);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch45 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty11 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension20 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EPerformanceViewModel_002CMerostrap_002EReduceAnimations_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding20 = compiledBindingExtension20.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch45.Bind(isCheckedProperty11, binding20);
		StyledProperty<bool> isEnabledProperty7 = InputElement.IsEnabledProperty;
		CompiledBindingExtension compiledBindingExtension21 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EPerformanceViewModel_002CMerostrap_002ECanCustomize_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = InputElement.IsEnabledProperty;
		CompiledBinding binding21 = compiledBindingExtension21.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch45.Bind(isEnabledProperty7, binding21);
		context.PopParent();
		((ISupportInitialize)toggleSwitch44).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl44).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(PerformancePage P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
