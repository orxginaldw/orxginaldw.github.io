using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Data.Converters;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using CompiledAvaloniaXaml;
using FluentAvalonia.UI.Controls;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.Resources;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.ViewModels;

namespace Merostrap.UI.Elements.Settings.Pages;

internal class BehaviourPage : UserControl
{
	[CompilerGenerated]
	private class XamlClosure_37
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<BehaviourPage> context = CreateContext(P_0);
			context.IntermediateRoot = new TextBlock();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			TextBlock textBlock = (TextBlock)obj;
			context.PushParent(textBlock);
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension();
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock.Bind(textProperty, binding);
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<BehaviourPage> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<BehaviourPage> context = new XamlIlContext.Context<BehaviourPage>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FPages_002FBehaviourPage_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/Pages/BehaviourPage.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (BehaviourPage)service;
				}
			}
			return context;
		}

		public static object Build_2(IServiceProvider P_0)
		{
			XamlIlContext.Context<BehaviourPage> context = CreateContext(P_0);
			context.IntermediateRoot = new TextBlock();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			TextBlock textBlock = (TextBlock)obj;
			context.PushParent(textBlock);
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension2;
			CompiledBindingExtension compiledBindingExtension = (compiledBindingExtension2 = new CompiledBindingExtension());
			context.PushParent(compiledBindingExtension2);
			StaticResourceExtension staticResourceExtension = new StaticResourceExtension("EnumNameConverter");
			context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EData_002ECompiledBinding_002CAvalonia_002EBase_002EConverter_0021Property();
			object? obj2 = staticResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			compiledBindingExtension2.Converter = (IValueConverter)obj2;
			context.PopParent();
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock.Bind(textProperty, binding);
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_3(IServiceProvider P_0)
		{
			XamlIlContext.Context<BehaviourPage> context = CreateContext(P_0);
			context.IntermediateRoot = new TextBlock();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			TextBlock textBlock = (TextBlock)obj;
			context.PushParent(textBlock);
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension2;
			CompiledBindingExtension compiledBindingExtension = (compiledBindingExtension2 = new CompiledBindingExtension());
			context.PushParent(compiledBindingExtension2);
			StaticResourceExtension staticResourceExtension = new StaticResourceExtension("EnumNameConverter");
			context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EData_002ECompiledBinding_002CAvalonia_002EBase_002EConverter_0021Property();
			object? obj2 = staticResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			compiledBindingExtension2.Converter = (IValueConverter)obj2;
			context.PopParent();
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock.Bind(textProperty, binding);
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal ToggleSwitch MultiInstanceToggle;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBlock MultiInstanceWarning;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public BehaviourPage()
	{
		InitializeComponent();
		App.FrostRPC?.SetPage("Bootstrapper");
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		MultiInstanceToggle = nameScope?.Find<ToggleSwitch>("MultiInstanceToggle");
		MultiInstanceWarning = nameScope?.Find<TextBlock>("MultiInstanceWarning");
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, BehaviourPage P_1)
	{
		XamlIlContext.Context<BehaviourPage> context = new XamlIlContext.Context<BehaviourPage>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSettings_002FPages_002FBehaviourPage_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Settings/Pages/BehaviourPage.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		P_1.Content = scrollViewer;
		ScrollViewer scrollViewer4;
		ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
		context.PushParent(scrollViewer4);
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		scrollViewer4.Content = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		StackPanel stackPanel5 = stackPanel4;
		stackPanel5.Margin = new Thickness(14.0, 14.0, 14.0, 14.0);
		Avalonia.Controls.Controls children = stackPanel5.Children;
		StackPanel stackPanel7;
		StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
		((ISupportInitialize)stackPanel6).BeginInit();
		children.Add(stackPanel6);
		StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
		context.PushParent(stackPanel4);
		StackPanel stackPanel9 = stackPanel4;
		stackPanel9.IsVisible = GlobalViewModel.IsWindows;
		Avalonia.Controls.Controls children2 = stackPanel9.Children;
		OptionControl optionControl2;
		OptionControl optionControl = (optionControl2 = new OptionControl());
		((ISupportInitialize)optionControl).BeginInit();
		children2.Add(optionControl);
		OptionControl optionControl4;
		OptionControl optionControl3 = (optionControl4 = optionControl2);
		context.PushParent(optionControl4);
		OptionControl optionControl5 = optionControl4;
		optionControl5.Header = "Multi-instance launching";
		optionControl5.Description = "Run multiple Roblox accounts at once. Close all Roblox clients before the first launch.";
		ToggleSwitch toggleSwitch2;
		ToggleSwitch toggleSwitch = (toggleSwitch2 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch).BeginInit();
		optionControl5.InnerContent = toggleSwitch;
		ToggleSwitch toggleSwitch4;
		ToggleSwitch toggleSwitch3 = (toggleSwitch4 = toggleSwitch2);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch5 = toggleSwitch4;
		toggleSwitch5.Name = "MultiInstanceToggle";
		object element = toggleSwitch5;
		context.AvaloniaNameScope.Register("MultiInstanceToggle", element);
		StyledProperty<bool?> isCheckedProperty = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002EMultiInstances_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch5.Bind(isCheckedProperty, binding);
		AutomationProperties.SetName(toggleSwitch5, "Multi-instance launching");
		context.PopParent();
		((ISupportInitialize)toggleSwitch3).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl3).EndInit();
		Avalonia.Controls.Controls children3 = stackPanel9.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children3.Add(textBlock);
		textBlock2.Name = "MultiInstanceWarning";
		element = textBlock2;
		context.AvaloniaNameScope.Register("MultiInstanceWarning", element);
		textBlock2.Margin = new Thickness(14.0, 4.0, 14.0, 14.0);
		textBlock2.TextWrapping = TextWrapping.Wrap;
		textBlock2.Text = "Warning: Multi-instance launching may result in an account ban. Enable only at your own risk.";
		((ISupportInitialize)textBlock2).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel8).EndInit();
		Avalonia.Controls.Controls children4 = stackPanel5.Children;
		OptionControl optionControl7;
		OptionControl optionControl6 = (optionControl7 = new OptionControl());
		((ISupportInitialize)optionControl6).BeginInit();
		children4.Add(optionControl6);
		OptionControl optionControl8 = (optionControl4 = optionControl7);
		context.PushParent(optionControl4);
		OptionControl optionControl9 = optionControl4;
		optionControl9.Header = Strings.Menu_Behaviour_ConfirmLaunches_Title;
		optionControl9.Description = Strings.Menu_Behaviour_ConfirmLaunches_Description;
		ToggleSwitch toggleSwitch7;
		ToggleSwitch toggleSwitch6 = (toggleSwitch7 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch6).BeginInit();
		optionControl9.InnerContent = toggleSwitch6;
		ToggleSwitch toggleSwitch8 = (toggleSwitch4 = toggleSwitch7);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch9 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty2 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002EConfirmLaunches_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch9.Bind(isCheckedProperty2, binding2);
		context.PopParent();
		((ISupportInitialize)toggleSwitch8).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl8).EndInit();
		Avalonia.Controls.Controls children5 = stackPanel5.Children;
		OptionControl optionControl11;
		OptionControl optionControl10 = (optionControl11 = new OptionControl());
		((ISupportInitialize)optionControl10).BeginInit();
		children5.Add(optionControl10);
		OptionControl optionControl12 = (optionControl4 = optionControl11);
		context.PushParent(optionControl4);
		OptionControl optionControl13 = optionControl4;
		optionControl13.Header = Strings.Menu_Behaviour_EnableVirtualDisplay_Title;
		optionControl13.Description = Strings.Menu_Behaviour_EnableVirtualDisplay_Description;
		optionControl13.IsVisible = GlobalViewModel.IsMacOS;
		StackPanel stackPanel11;
		StackPanel stackPanel10 = (stackPanel11 = new StackPanel());
		((ISupportInitialize)stackPanel10).BeginInit();
		optionControl13.InnerContent = stackPanel10;
		StackPanel stackPanel12 = (stackPanel4 = stackPanel11);
		context.PushParent(stackPanel4);
		StackPanel stackPanel13 = stackPanel4;
		stackPanel13.Orientation = Orientation.Horizontal;
		stackPanel13.Spacing = 8.0;
		Avalonia.Controls.Controls children6 = stackPanel13.Children;
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		children6.Add(lucide);
		lucide2.Icon = LucideIconNames.CircleAlert;
		lucide2.VerticalAlignment = VerticalAlignment.Center;
		lucide2.StrokeBrush = new ImmutableSolidColorBrush(4294944000u);
		ToolTip.SetTip(lucide2, "This feature is experimental and may not work as expected.");
		((ISupportInitialize)lucide2).EndInit();
		Avalonia.Controls.Controls children7 = stackPanel13.Children;
		ToggleSwitch toggleSwitch11;
		ToggleSwitch toggleSwitch10 = (toggleSwitch11 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch10).BeginInit();
		children7.Add(toggleSwitch10);
		ToggleSwitch toggleSwitch12 = (toggleSwitch4 = toggleSwitch11);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch13 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty3 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002ELaunchWithVirtualDisplay_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding3 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch13.Bind(isCheckedProperty3, binding3);
		context.PopParent();
		((ISupportInitialize)toggleSwitch12).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel12).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl12).EndInit();
		Avalonia.Controls.Controls children8 = stackPanel5.Children;
		OptionControl optionControl15;
		OptionControl optionControl14 = (optionControl15 = new OptionControl());
		((ISupportInitialize)optionControl14).BeginInit();
		children8.Add(optionControl14);
		OptionControl optionControl16 = (optionControl4 = optionControl15);
		context.PushParent(optionControl4);
		OptionControl optionControl17 = optionControl4;
		optionControl17.Header = Strings.Menu_Behaviour_CloseCrashHandler_Title;
		optionControl17.Description = Strings.Menu_Behaviour_CloseCrashHandler_Description;
		optionControl17.IsVisible = GlobalViewModel.IsWindows;
		ToggleSwitch toggleSwitch15;
		ToggleSwitch toggleSwitch14 = (toggleSwitch15 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch14).BeginInit();
		optionControl17.InnerContent = toggleSwitch14;
		ToggleSwitch toggleSwitch16 = (toggleSwitch4 = toggleSwitch15);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch17 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty4 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002ECloseCrashHandler_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding4 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch17.Bind(isCheckedProperty4, binding4);
		context.PopParent();
		((ISupportInitialize)toggleSwitch16).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl16).EndInit();
		Avalonia.Controls.Controls children9 = stackPanel5.Children;
		OptionControl optionControl19;
		OptionControl optionControl18 = (optionControl19 = new OptionControl());
		((ISupportInitialize)optionControl18).BeginInit();
		children9.Add(optionControl18);
		OptionControl optionControl20 = (optionControl4 = optionControl19);
		context.PushParent(optionControl4);
		OptionControl optionControl21 = optionControl4;
		optionControl21.Header = Strings.Menu_Behaviour_BackgroundUpdates_Title;
		optionControl21.Description = Strings.Menu_Behaviour_BackgroundUpdates_Description;
		optionControl21.IsVisible = GlobalViewModel.IsWindows;
		ToggleSwitch toggleSwitch19;
		ToggleSwitch toggleSwitch18 = (toggleSwitch19 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch18).BeginInit();
		optionControl21.InnerContent = toggleSwitch18;
		ToggleSwitch toggleSwitch20 = (toggleSwitch4 = toggleSwitch19);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch21 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty5 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002EBackgroundUpdates_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding5 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch21.Bind(isCheckedProperty5, binding5);
		context.PopParent();
		((ISupportInitialize)toggleSwitch20).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl20).EndInit();
		Avalonia.Controls.Controls children10 = stackPanel5.Children;
		OptionControl optionControl23;
		OptionControl optionControl22 = (optionControl23 = new OptionControl());
		((ISupportInitialize)optionControl22).BeginInit();
		children10.Add(optionControl22);
		OptionControl optionControl24 = (optionControl4 = optionControl23);
		context.PushParent(optionControl4);
		OptionControl optionControl25 = optionControl4;
		optionControl25.Header = Strings.Menu_Behaviour_AllowCookieAccess_Title;
		StyledProperty<string?> descriptionProperty = OptionControl.DescriptionProperty;
		CompiledBindingExtension compiledBindingExtension7;
		CompiledBindingExtension compiledBindingExtension6 = (compiledBindingExtension7 = new CompiledBindingExtension());
		context.PushParent(compiledBindingExtension7);
		compiledBindingExtension7.Source = Strings.Menu_Behaviour_AllowCookieAccess_Description;
		StaticResourceExtension staticResourceExtension = new StaticResourceExtension("StringFormatConverter");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EData_002ECompiledBinding_002CAvalonia_002EBase_002EConverter_0021Property();
		object? obj = staticResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		compiledBindingExtension7.Converter = (IValueConverter)obj;
		compiledBindingExtension7.ConverterParameter = "https://github.com/fishstrap/fishstrap/wiki/Account-Access#what-will-fishstrap-access-with-your-account";
		context.PopParent();
		context.ProvideTargetProperty = OptionControl.DescriptionProperty;
		CompiledBinding binding6 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		optionControl25.Bind(descriptionProperty, binding6);
		StackPanel stackPanel15;
		StackPanel stackPanel14 = (stackPanel15 = new StackPanel());
		((ISupportInitialize)stackPanel14).BeginInit();
		optionControl25.InnerContent = stackPanel14;
		StackPanel stackPanel16 = (stackPanel4 = stackPanel15);
		context.PushParent(stackPanel4);
		StackPanel stackPanel17 = stackPanel4;
		stackPanel17.Orientation = Orientation.Horizontal;
		stackPanel17.Spacing = 8.0;
		Avalonia.Controls.Controls children11 = stackPanel17.Children;
		Lucide lucide4;
		Lucide lucide3 = (lucide4 = new Lucide());
		((ISupportInitialize)lucide3).BeginInit();
		children11.Add(lucide3);
		Lucide lucide6;
		Lucide lucide5 = (lucide6 = lucide4);
		context.PushParent(lucide6);
		lucide6.Icon = LucideIconNames.TriangleAlert;
		lucide6.VerticalAlignment = VerticalAlignment.Center;
		lucide6.StrokeBrush = new ImmutableSolidColorBrush(4294944000u);
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002ECookieLoadingFailed_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding7 = compiledBindingExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide6.Bind(isVisibleProperty, binding7);
		context.PopParent();
		((ISupportInitialize)lucide5).EndInit();
		Avalonia.Controls.Controls children12 = stackPanel17.Children;
		ToggleSwitch toggleSwitch23;
		ToggleSwitch toggleSwitch22 = (toggleSwitch23 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch22).BeginInit();
		children12.Add(toggleSwitch22);
		ToggleSwitch toggleSwitch24 = (toggleSwitch4 = toggleSwitch23);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch25 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty6 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002ECookieAccess_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding8 = compiledBindingExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch25.Bind(isCheckedProperty6, binding8);
		context.PopParent();
		((ISupportInitialize)toggleSwitch24).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel16).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl24).EndInit();
		Avalonia.Controls.Controls children13 = stackPanel5.Children;
		CardExpander cardExpander2;
		CardExpander cardExpander = (cardExpander2 = new CardExpander());
		((ISupportInitialize)cardExpander).BeginInit();
		children13.Add(cardExpander);
		CardExpander cardExpander4;
		CardExpander cardExpander3 = (cardExpander4 = cardExpander2);
		context.PushParent(cardExpander4);
		CardExpander cardExpander5 = cardExpander4;
		cardExpander5.Header = Strings.Menu_Bootstrapper_SoftKey_Title;
		cardExpander5.Description = Strings.Menu_Bootstrapper_SoftKey_Description;
		cardExpander5.Classes.Add("NoUserExpansion");
		StyledProperty<bool> isExpandedProperty = CardExpander.IsExpandedProperty;
		CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002ESoftKeyEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.OneWay
		};
		context.ProvideTargetProperty = CardExpander.IsExpandedProperty;
		CompiledBinding binding9 = compiledBindingExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		cardExpander5.Bind(isExpandedProperty, binding9);
		cardExpander5.IsVisible = GlobalViewModel.IsWindows;
		ToggleSwitch toggleSwitch27;
		ToggleSwitch toggleSwitch26 = (toggleSwitch27 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch26).BeginInit();
		cardExpander5.HeaderContent = toggleSwitch26;
		ToggleSwitch toggleSwitch28 = (toggleSwitch4 = toggleSwitch27);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch29 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty7 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002ESoftKeyEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding10 = compiledBindingExtension11.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch29.Bind(isCheckedProperty7, binding10);
		context.PopParent();
		((ISupportInitialize)toggleSwitch28).EndInit();
		StackPanel stackPanel19;
		StackPanel stackPanel18 = (stackPanel19 = new StackPanel());
		((ISupportInitialize)stackPanel18).BeginInit();
		cardExpander5.Content = stackPanel18;
		StackPanel stackPanel20 = (stackPanel4 = stackPanel19);
		context.PushParent(stackPanel4);
		Avalonia.Controls.Controls children14 = stackPanel4.Children;
		OptionControl optionControl27;
		OptionControl optionControl26 = (optionControl27 = new OptionControl());
		((ISupportInitialize)optionControl26).BeginInit();
		children14.Add(optionControl26);
		OptionControl optionControl28 = (optionControl4 = optionControl27);
		context.PushParent(optionControl4);
		OptionControl optionControl29 = optionControl4;
		optionControl29.Header = Strings.Menu_Bootstrapper_SoftKeyProfile_Title;
		optionControl29.Description = Strings.Menu_Bootstrapper_SoftKeyProfile_Description;
		ComboBox comboBox2;
		ComboBox comboBox = (comboBox2 = new ComboBox());
		((ISupportInitialize)comboBox).BeginInit();
		optionControl29.InnerContent = comboBox;
		ComboBox comboBox4;
		ComboBox comboBox3 = (comboBox4 = comboBox2);
		context.PushParent(comboBox4);
		ComboBox comboBox5 = comboBox4;
		comboBox5.MinWidth = 200.0;
		StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002ESoftKeyProfiles_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding11 = compiledBindingExtension12.ProvideValue(context);
		context.ProvideTargetProperty = null;
		comboBox5.Bind(itemsSourceProperty, binding11);
		CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002ESoftKeyProfile_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = SelectingItemsControl.SelectedItemProperty;
		CompiledBinding compiledBinding = compiledBindingExtension13.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_10(comboBox5, compiledBinding);
		DataTemplate dataTemplate;
		DataTemplate itemTemplate = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_37.Build_1), context);
		context.PopParent();
		comboBox5.ItemTemplate = itemTemplate;
		context.PopParent();
		((ISupportInitialize)comboBox3).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl28).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel20).EndInit();
		context.PopParent();
		((ISupportInitialize)cardExpander3).EndInit();
		Avalonia.Controls.Controls children15 = stackPanel5.Children;
		CardExpander cardExpander7;
		CardExpander cardExpander6 = (cardExpander7 = new CardExpander());
		((ISupportInitialize)cardExpander6).BeginInit();
		children15.Add(cardExpander6);
		CardExpander cardExpander8 = (cardExpander4 = cardExpander7);
		context.PushParent(cardExpander4);
		CardExpander cardExpander9 = cardExpander4;
		cardExpander9.Header = Strings.Menu_Bootstrapper_Experimental_BetterMatchmaking_Title;
		cardExpander9.Description = Strings.Menu_Bootstrapper_Experimental_BetterMatchmaking_Description;
		cardExpander9.Classes.Add("NoUserExpansion");
		StyledProperty<bool> isExpandedProperty2 = CardExpander.IsExpandedProperty;
		CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002EEnableBetterMatchmaking_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.OneWay
		};
		context.ProvideTargetProperty = CardExpander.IsExpandedProperty;
		CompiledBinding binding12 = compiledBindingExtension14.ProvideValue(context);
		context.ProvideTargetProperty = null;
		cardExpander9.Bind(isExpandedProperty2, binding12);
		ToggleSwitch toggleSwitch31;
		ToggleSwitch toggleSwitch30 = (toggleSwitch31 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch30).BeginInit();
		cardExpander9.HeaderContent = toggleSwitch30;
		ToggleSwitch toggleSwitch32 = (toggleSwitch4 = toggleSwitch31);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch33 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty8 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension15 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002EEnableBetterMatchmaking_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding13 = compiledBindingExtension15.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch33.Bind(isCheckedProperty8, binding13);
		context.PopParent();
		((ISupportInitialize)toggleSwitch32).EndInit();
		StackPanel stackPanel22;
		StackPanel stackPanel21 = (stackPanel22 = new StackPanel());
		((ISupportInitialize)stackPanel21).BeginInit();
		cardExpander9.Content = stackPanel21;
		StackPanel stackPanel23 = (stackPanel4 = stackPanel22);
		context.PushParent(stackPanel4);
		Avalonia.Controls.Controls children16 = stackPanel4.Children;
		OptionControl optionControl31;
		OptionControl optionControl30 = (optionControl31 = new OptionControl());
		((ISupportInitialize)optionControl30).BeginInit();
		children16.Add(optionControl30);
		OptionControl optionControl32 = (optionControl4 = optionControl31);
		context.PushParent(optionControl4);
		OptionControl optionControl33 = optionControl4;
		optionControl33.Header = Strings.Menu_Bootstrapper_PreferredRegion_Title;
		optionControl33.Description = Strings.Menu_Bootstrapper_PreferredRegion_Description;
		StackPanel stackPanel25;
		StackPanel stackPanel24 = (stackPanel25 = new StackPanel());
		((ISupportInitialize)stackPanel24).BeginInit();
		optionControl33.InnerContent = stackPanel24;
		StackPanel stackPanel26 = (stackPanel4 = stackPanel25);
		context.PushParent(stackPanel4);
		StackPanel stackPanel27 = stackPanel4;
		stackPanel27.Orientation = Orientation.Horizontal;
		stackPanel27.VerticalAlignment = VerticalAlignment.Center;
		Avalonia.Controls.Controls children17 = stackPanel27.Children;
		FAProgressRing fAProgressRing2;
		FAProgressRing fAProgressRing = (fAProgressRing2 = new FAProgressRing());
		((ISupportInitialize)fAProgressRing).BeginInit();
		children17.Add(fAProgressRing);
		FAProgressRing fAProgressRing4;
		FAProgressRing fAProgressRing3 = (fAProgressRing4 = fAProgressRing2);
		context.PushParent(fAProgressRing4);
		StyledProperty<bool> isActiveProperty = FAProgressRing.IsActiveProperty;
		CompiledBindingExtension compiledBindingExtension16 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002EIsLoadingRegions_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = FAProgressRing.IsActiveProperty;
		CompiledBinding binding14 = compiledBindingExtension16.ProvideValue(context);
		context.ProvideTargetProperty = null;
		fAProgressRing4.Bind(isActiveProperty, binding14);
		fAProgressRing4.Width = 20.0;
		fAProgressRing4.Height = 20.0;
		fAProgressRing4.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
		StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension17 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002EIsLoadingRegions_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding15 = compiledBindingExtension17.ProvideValue(context);
		context.ProvideTargetProperty = null;
		fAProgressRing4.Bind(isVisibleProperty2, binding15);
		context.PopParent();
		((ISupportInitialize)fAProgressRing3).EndInit();
		Avalonia.Controls.Controls children18 = stackPanel27.Children;
		ComboBox comboBox7;
		ComboBox comboBox6 = (comboBox7 = new ComboBox());
		((ISupportInitialize)comboBox6).BeginInit();
		children18.Add(comboBox6);
		ComboBox comboBox8 = (comboBox4 = comboBox7);
		context.PushParent(comboBox4);
		ComboBox comboBox9 = comboBox4;
		comboBox9.MinWidth = 200.0;
		StyledProperty<IEnumerable?> itemsSourceProperty2 = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension18 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002EAvailableRegions_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding16 = compiledBindingExtension18.ProvideValue(context);
		context.ProvideTargetProperty = null;
		comboBox9.Bind(itemsSourceProperty2, binding16);
		CompiledBindingExtension compiledBindingExtension19 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002ESelectedRegion_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = SelectingItemsControl.SelectedItemProperty;
		CompiledBinding compiledBinding2 = compiledBindingExtension19.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_10(comboBox9, compiledBinding2);
		context.PopParent();
		((ISupportInitialize)comboBox8).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel26).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl32).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel23).EndInit();
		context.PopParent();
		((ISupportInitialize)cardExpander8).EndInit();
		Avalonia.Controls.Controls children19 = stackPanel5.Children;
		CardExpander cardExpander11;
		CardExpander cardExpander10 = (cardExpander11 = new CardExpander());
		((ISupportInitialize)cardExpander10).BeginInit();
		children19.Add(cardExpander10);
		CardExpander cardExpander12 = (cardExpander4 = cardExpander11);
		context.PushParent(cardExpander4);
		CardExpander cardExpander13 = cardExpander4;
		cardExpander13.Header = Strings.Menu_Bootstrapper_AppStorage_Title;
		cardExpander13.Description = Strings.Menu_Bootstrapper_AppStorage_Description;
		cardExpander13.IsExpanded = true;
		StackPanel stackPanel29;
		StackPanel stackPanel28 = (stackPanel29 = new StackPanel());
		((ISupportInitialize)stackPanel28).BeginInit();
		cardExpander13.Content = stackPanel28;
		StackPanel stackPanel30 = (stackPanel4 = stackPanel29);
		context.PushParent(stackPanel4);
		StackPanel stackPanel31 = stackPanel4;
		stackPanel31.Margin = new Thickness(0.0, 8.0, 0.0, 0.0);
		Avalonia.Controls.Controls children20 = stackPanel31.Children;
		OptionControl optionControl35;
		OptionControl optionControl34 = (optionControl35 = new OptionControl());
		((ISupportInitialize)optionControl34).BeginInit();
		children20.Add(optionControl34);
		OptionControl optionControl36 = (optionControl4 = optionControl35);
		context.PushParent(optionControl4);
		OptionControl optionControl37 = optionControl4;
		optionControl37.Header = Strings.Menu_Bootstrapper_RobloxTheme_Title;
		optionControl37.Description = Strings.Menu_Bootstrapper_RobloxTheme_Description;
		ComboBox comboBox11;
		ComboBox comboBox10 = (comboBox11 = new ComboBox());
		((ISupportInitialize)comboBox10).BeginInit();
		optionControl37.InnerContent = comboBox10;
		ComboBox comboBox12 = (comboBox4 = comboBox11);
		context.PushParent(comboBox4);
		ComboBox comboBox13 = comboBox4;
		comboBox13.MinWidth = 200.0;
		StyledProperty<IEnumerable?> itemsSourceProperty3 = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension20 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002ERobloxThemes_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding17 = compiledBindingExtension20.ProvideValue(context);
		context.ProvideTargetProperty = null;
		comboBox13.Bind(itemsSourceProperty3, binding17);
		CompiledBindingExtension compiledBindingExtension21 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002ERobloxTheme_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = SelectingItemsControl.SelectedItemProperty;
		CompiledBinding compiledBinding3 = compiledBindingExtension21.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_10(comboBox13, compiledBinding3);
		DataTemplate itemTemplate2 = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_37.Build_2), context);
		context.PopParent();
		comboBox13.ItemTemplate = itemTemplate2;
		context.PopParent();
		((ISupportInitialize)comboBox12).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl36).EndInit();
		Avalonia.Controls.Controls children21 = stackPanel31.Children;
		OptionControl optionControl39;
		OptionControl optionControl38 = (optionControl39 = new OptionControl());
		((ISupportInitialize)optionControl38).BeginInit();
		children21.Add(optionControl38);
		OptionControl optionControl40 = (optionControl4 = optionControl39);
		context.PushParent(optionControl4);
		OptionControl optionControl41 = optionControl4;
		optionControl41.Header = Strings.Menu_Bootstrapper_EnableRobloxBackgroundApp_Title;
		optionControl41.Description = Strings.Menu_Bootstrapper_EnableRobloxBackgroundApp_Description;
		ToggleSwitch toggleSwitch35;
		ToggleSwitch toggleSwitch34 = (toggleSwitch35 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch34).BeginInit();
		optionControl41.InnerContent = toggleSwitch34;
		ToggleSwitch toggleSwitch36 = (toggleSwitch4 = toggleSwitch35);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch37 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty9 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension22 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002EEnableRobloxBackgroundApp_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding18 = compiledBindingExtension22.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch37.Bind(isCheckedProperty9, binding18);
		context.PopParent();
		((ISupportInitialize)toggleSwitch36).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl40).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel30).EndInit();
		context.PopParent();
		((ISupportInitialize)cardExpander12).EndInit();
		Avalonia.Controls.Controls children22 = stackPanel5.Children;
		CardExpander cardExpander15;
		CardExpander cardExpander14 = (cardExpander15 = new CardExpander());
		((ISupportInitialize)cardExpander14).BeginInit();
		children22.Add(cardExpander14);
		CardExpander cardExpander16 = (cardExpander4 = cardExpander15);
		context.PushParent(cardExpander4);
		CardExpander cardExpander17 = cardExpander4;
		cardExpander17.IsExpanded = true;
		cardExpander17.Header = Strings.Menu_Bootstrapper_CleanUp_Title;
		cardExpander17.Description = Strings.Menu_Bootstrapper_CleanUp_Description;
		StackPanel stackPanel33;
		StackPanel stackPanel32 = (stackPanel33 = new StackPanel());
		((ISupportInitialize)stackPanel32).BeginInit();
		cardExpander17.Content = stackPanel32;
		StackPanel stackPanel34 = (stackPanel4 = stackPanel33);
		context.PushParent(stackPanel4);
		StackPanel stackPanel35 = stackPanel4;
		Avalonia.Controls.Controls children23 = stackPanel35.Children;
		OptionControl optionControl43;
		OptionControl optionControl42 = (optionControl43 = new OptionControl());
		((ISupportInitialize)optionControl42).BeginInit();
		children23.Add(optionControl42);
		OptionControl optionControl44 = (optionControl4 = optionControl43);
		context.PushParent(optionControl4);
		OptionControl optionControl45 = optionControl4;
		optionControl45.Header = Strings.Menu_Bootstrapper_Cleaner_Age_Title;
		optionControl45.Description = Strings.Menu_Bootstrapper_Cleaner_Age_Description;
		ComboBox comboBox15;
		ComboBox comboBox14 = (comboBox15 = new ComboBox());
		((ISupportInitialize)comboBox14).BeginInit();
		optionControl45.InnerContent = comboBox14;
		ComboBox comboBox16 = (comboBox4 = comboBox15);
		context.PushParent(comboBox4);
		ComboBox comboBox17 = comboBox4;
		comboBox17.MinWidth = 200.0;
		StyledProperty<IEnumerable?> itemsSourceProperty4 = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension23 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002ECleanerOptions_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding19 = compiledBindingExtension23.ProvideValue(context);
		context.ProvideTargetProperty = null;
		comboBox17.Bind(itemsSourceProperty4, binding19);
		CompiledBindingExtension compiledBindingExtension24 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002ECleanerOption_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = SelectingItemsControl.SelectedItemProperty;
		CompiledBinding compiledBinding4 = compiledBindingExtension24.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_10(comboBox17, compiledBinding4);
		DataTemplate itemTemplate3 = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_37.Build_3), context);
		context.PopParent();
		comboBox17.ItemTemplate = itemTemplate3;
		context.PopParent();
		((ISupportInitialize)comboBox16).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl44).EndInit();
		Avalonia.Controls.Controls children24 = stackPanel35.Children;
		OptionControl optionControl47;
		OptionControl optionControl46 = (optionControl47 = new OptionControl());
		((ISupportInitialize)optionControl46).BeginInit();
		children24.Add(optionControl46);
		OptionControl optionControl48 = (optionControl4 = optionControl47);
		context.PushParent(optionControl4);
		OptionControl optionControl49 = optionControl4;
		optionControl49.Header = Strings.Menu_Bootstrapper_Cleaner_Cache_Title;
		optionControl49.Description = Strings.Menu_Bootstrapper_Cleaner_Cache_Description;
		ToggleSwitch toggleSwitch39;
		ToggleSwitch toggleSwitch38 = (toggleSwitch39 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch38).BeginInit();
		optionControl49.InnerContent = toggleSwitch38;
		ToggleSwitch toggleSwitch40 = (toggleSwitch4 = toggleSwitch39);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch41 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty10 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension25 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002ECleanerCache_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding20 = compiledBindingExtension25.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch41.Bind(isCheckedProperty10, binding20);
		context.PopParent();
		((ISupportInitialize)toggleSwitch40).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl48).EndInit();
		Avalonia.Controls.Controls children25 = stackPanel35.Children;
		OptionControl optionControl51;
		OptionControl optionControl50 = (optionControl51 = new OptionControl());
		((ISupportInitialize)optionControl50).BeginInit();
		children25.Add(optionControl50);
		OptionControl optionControl52 = (optionControl4 = optionControl51);
		context.PushParent(optionControl4);
		OptionControl optionControl53 = optionControl4;
		optionControl53.Header = Strings.Menu_Bootstrapper_Cleaner_Logs_Title;
		optionControl53.Description = Strings.Menu_Bootstrapper_Cleaner_Logs_Description;
		ToggleSwitch toggleSwitch43;
		ToggleSwitch toggleSwitch42 = (toggleSwitch43 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch42).BeginInit();
		optionControl53.InnerContent = toggleSwitch42;
		ToggleSwitch toggleSwitch44 = (toggleSwitch4 = toggleSwitch43);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch45 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty11 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension26 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002ECleanerLogs_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding21 = compiledBindingExtension26.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch45.Bind(isCheckedProperty11, binding21);
		context.PopParent();
		((ISupportInitialize)toggleSwitch44).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl52).EndInit();
		Avalonia.Controls.Controls children26 = stackPanel35.Children;
		OptionControl optionControl55;
		OptionControl optionControl54 = (optionControl55 = new OptionControl());
		((ISupportInitialize)optionControl54).BeginInit();
		children26.Add(optionControl54);
		OptionControl optionControl56 = (optionControl4 = optionControl55);
		context.PushParent(optionControl4);
		OptionControl optionControl57 = optionControl4;
		optionControl57.Header = Strings.Menu_Bootstrapper_Cleaner_IncludeBloxstrap_Title;
		optionControl57.Description = Strings.Menu_Bootstrapper_Cleaner_IncludeBloxstrap_Description;
		ToggleSwitch toggleSwitch47;
		ToggleSwitch toggleSwitch46 = (toggleSwitch47 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch46).BeginInit();
		optionControl57.InnerContent = toggleSwitch46;
		ToggleSwitch toggleSwitch48 = (toggleSwitch4 = toggleSwitch47);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch49 = toggleSwitch4;
		StyledProperty<bool?> isCheckedProperty12 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension27 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EBehaviourViewModel_002CMerostrap_002ECleanerMerostrap_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding22 = compiledBindingExtension27.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch49.Bind(isCheckedProperty12, binding22);
		context.PopParent();
		((ISupportInitialize)toggleSwitch48).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl56).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel34).EndInit();
		context.PopParent();
		((ISupportInitialize)cardExpander16).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(BehaviourPage P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
