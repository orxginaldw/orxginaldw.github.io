using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Platform;
using Merostrap.Macros;
using Merostrap.Macros.Health;

namespace Merostrap.UI.Elements.Macros;

public static class HudAutoDetection
{
	public static async Task<DetectedHudBars?> PickAsync(Window owner)
	{
		owner.Hide();
		try
		{
			WindowsHealthCapture.FocusRobloxForDetection();
			await Task.Delay(350);
			(HealthRegion Area, HealthPixels Pixels, DetectedHudBars Found) scan = await Task.Run(async () =>
			{
				for (int attempt = 0; attempt < 40; attempt++)
				{
					try
					{
						HealthRegion healthRegion = WindowsHealthCapture.ForegroundRobloxArea();
						if ((object)healthRegion != null)
						{
							WindowsHealthCapture windowsHealthCapture = new WindowsHealthCapture();
							HealthPixels healthPixels = new HealthPixels(healthRegion.Width, healthRegion.Height, new byte[healthRegion.Width * healthRegion.Height * 4]);
							int num = (healthRegion.Height + 1) / 2;
							for (int i = 0; i < healthRegion.Height; i += num)
							{
								HealthPixels healthPixels2 = windowsHealthCapture.Capture(new HealthRegion(healthRegion.X, healthRegion.Y + i, healthRegion.Width, Math.Min(num, healthRegion.Height - i)));
								Array.Copy(healthPixels2.Bgra, 0, healthPixels.Bgra, i * healthRegion.Width * 4, healthPixels2.Bgra.Length);
							}
							if (WindowsHealthCapture.ForegroundRobloxArea() == healthRegion)
							{
								DetectedHudBars detectedHudBars = HudBarDetector.Detect(healthPixels);
								if ((object)detectedHudBars != null)
								{
									return (Area: healthRegion, Pixels: healthPixels, Found: detectedHudBars);
								}
							}
						}
						else if (attempt < 4)
						{
							WindowsHealthCapture.FocusRobloxForDetection();
						}
					}
					catch (Exception ex) when ((ex is Win32Exception || ex is ArgumentException) ? true : false)
					{
					}
					await Task.Delay(250);
				}
				return ((HealthRegion Area, HealthPixels Pixels, DetectedHudBars Found))(Area: null, Pixels: null, Found: null);
			});
			owner.Show();
			owner.Activate();
			DetectedHudBars bars = scan.Found;
			if ((object)bars == null || (object)scan.Pixels == null || (object)scan.Area == null)
			{
				await ShowMissing(owner);
				return null;
			}
			using (WriteableBitmap health = Bitmap(HudBarDetector.Crop(scan.Pixels, bars.Health)))
			{
				using WriteableBitmap parry = Bitmap(HudBarDetector.Crop(scan.Pixels, bars.Parry));
				HudDetectionDialog dialog = new HudDetectionDialog
				{
					Title = "Detected bars",
					Width = 680.0,
					SizeToContent = SizeToContent.Height,
					CanResize = false
				};
				Button button = new Button
				{
					Content = "Use these bars"
				};
				Button button2 = new Button
				{
					Content = "Cancel"
				};
				button.Click += (object? _, RoutedEventArgs _) =>
				{
					dialog.Close(true);
				};
				button2.Click += (object? _, RoutedEventArgs _) =>
				{
					dialog.Close(false);
				};
				dialog.Content = new StackPanel
				{
					Margin = new Thickness(20.0),
					Spacing = 12.0,
					Children = 
					{
						(Control)new TextBlock
						{
							Text = "Health"
						},
						(Control)new Image
						{
							Source = health,
							Height = 44.0,
							Stretch = Stretch.Uniform
						},
						(Control)new TextBlock
						{
							Text = "Parry · confirm the cooldown is full"
						},
						(Control)new Image
						{
							Source = parry,
							Height = 20.0,
							Stretch = Stretch.Fill
						},
						(Control)new StackPanel
						{
							Orientation = Orientation.Horizontal,
							Spacing = 8.0,
							Children = 
							{
								(Control)button,
								(Control)button2
							}
						}
					}
				};
				if (!(await dialog.ShowDialog<bool>(owner)))
				{
					return null;
				}
				return bars with
				{
					Health = Absolute(bars.Health),
					Parry = Absolute(bars.Parry)
				};
			}
			HealthRegion Absolute(HealthRegion r)
			{
				return r with
				{
					X = r.X + scan.Area.X,
					Y = r.Y + scan.Area.Y
				};
			}
		}
		finally
		{
			owner.Show();
			owner.Activate();
		}
	}

	private static WriteableBitmap Bitmap(HealthPixels pixels)
	{
		WriteableBitmap writeableBitmap = new WriteableBitmap(new PixelSize(pixels.Width, pixels.Height), new Vector(96.0, 96.0), PixelFormat.Bgra8888, AlphaFormat.Opaque);
		using ILockedFramebuffer lockedFramebuffer = writeableBitmap.Lock();
		for (int i = 0; i < pixels.Height; i++)
		{
			Marshal.Copy(pixels.Bgra, i * pixels.Width * 4, lockedFramebuffer.Address + i * lockedFramebuffer.RowBytes, pixels.Width * 4);
		}
		return writeableBitmap;
	}

	private static async Task ShowMissing(Window owner)
	{
		HudDetectionDialog dialog = new HudDetectionDialog
		{
			Title = "Auto-detect",
			Width = 430.0,
			SizeToContent = SizeToContent.Height,
			CanResize = false
		};
		Button button = new Button
		{
			Content = "OK"
		};
		button.Click += (object? _, RoutedEventArgs _) =>
		{
			dialog.Close();
		};
		dialog.Content = new StackPanel
		{
			Margin = new Thickness(20.0),
			Spacing = 16.0,
			Children = 
			{
				(Control)new TextBlock
				{
					Text = "Couldn't identify both bars. Auto-detection doesn't work in the Depths; select the bars manually there. Elsewhere, switch to Roblox with the HUD visible and parry ready, then try again.",
					TextWrapping = TextWrapping.Wrap
				},
				(Control)button
			}
		};
		await dialog.ShowDialog(owner);
	}
}
