using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using Avalonia.Platform;
using Avalonia.Threading;
using CompiledAvaloniaXaml;
using Merostrap.Macros;

namespace Merostrap.UI.Elements.Macros;

public class FlowStateCooldownOverlay : Window
{
	private readonly FlowStateOverlayController _model;

	private readonly DispatcherTimer _save = new DispatcherTimer
	{
		Interval = TimeSpan.FromMilliseconds(300L)
	};

	private bool _positionReady;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public FlowStateCooldownOverlay()
		: this(MacroWorkspace.Current.FlowStateOverlay)
	{
	}

	public FlowStateCooldownOverlay(FlowStateOverlayController model)
	{
		FlowStateCooldownOverlay flowStateCooldownOverlay = this;
		_model = model;
		InitializeComponent();
		DataContext = model;
		Win32Properties.AddWindowStylesCallback(this, (uint style, uint extended) => (style: (style & 0xFF30FFFFu) | 0x80000000u, exStyle: extended | 0x8000080));
		Win32Properties.AddWndProcHookCallback(this, delegate(nint handle, uint message, nint wParam, nint lParam, ref bool handled)
		{
			if (message == 33)
			{
				handled = true;
				return new IntPtr(3);
			}
			return IntPtr.Zero;
		});
		Opened += (object? _, EventArgs _) =>
		{
			PixelPoint pixelPoint = new PixelPoint(model.X ?? 24, model.Y ?? 240);
			Screen screen = flowStateCooldownOverlay.Screens.ScreenFromPoint(pixelPoint) ?? flowStateCooldownOverlay.Screens.Primary;
			if ((object)screen != null)
			{
				PixelRect workingArea = screen.WorkingArea;
				pixelPoint = new PixelPoint(Math.Clamp(pixelPoint.X, workingArea.X, Math.Max(workingArea.X, workingArea.Right - (int)(flowStateCooldownOverlay.Width * screen.Scaling))), Math.Clamp(pixelPoint.Y, workingArea.Y, Math.Max(workingArea.Y, workingArea.Bottom - (int)(flowStateCooldownOverlay.Height * screen.Scaling))));
			}
			flowStateCooldownOverlay.Position = pixelPoint;
			flowStateCooldownOverlay._positionReady = true;
			if (OperatingSystem.IsWindows())
			{
				nint? num = flowStateCooldownOverlay.TryGetPlatformHandle()?.Handle;
				if (num.HasValue)
				{
					nint valueOrDefault = num.GetValueOrDefault();
					if (valueOrDefault != IntPtr.Zero)
					{
						SetWindowDisplayAffinity(valueOrDefault, 17u);
					}
				}
			}
		};
		_save.Tick += (object? _, EventArgs _) =>
		{
			flowStateCooldownOverlay.FlushPosition();
		};
		PositionChanged += (object? _, PixelPointEventArgs _) =>
		{
			if (flowStateCooldownOverlay._positionReady)
			{
				flowStateCooldownOverlay._save.Stop();
				flowStateCooldownOverlay._save.Start();
			}
		};
		Closing += (object? _, WindowClosingEventArgs _) =>
		{
			if (flowStateCooldownOverlay.IsVisible)
			{
				flowStateCooldownOverlay.FlushPosition();
			}
			flowStateCooldownOverlay._positionReady = false;
			flowStateCooldownOverlay._save.Stop();
		};
	}

	protected override void OnPropertyChanged(AvaloniaPropertyChangedEventArgs change)
	{
		base.OnPropertyChanged(change);
		if (change.Property == Visual.IsVisibleProperty && !IsVisible && _positionReady)
		{
			FlushPosition();
		}
	}

	private void FlushPosition()
	{
		_save.Stop();
		if (_positionReady)
		{
			_model.SavePosition(Position.X, Position.Y);
		}
	}

	private void DragPressed(object? sender, PointerPressedEventArgs e)
	{
		if (e.GetCurrentPoint(this).Properties.IsLeftButtonPressed)
		{
			BeginMoveDrag(e);
		}
	}

	[DllImport("user32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool SetWindowDisplayAffinity(nint window, uint affinity);

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, FlowStateCooldownOverlay P_1)
	{
		XamlIlContext.Context<FlowStateCooldownOverlay> context = new XamlIlContext.Context<FlowStateCooldownOverlay>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FMacros_002FFlowStateCooldownOverlay_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Macros/FlowStateCooldownOverlay.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Title = "Merostrap Flow State cooldown";
		StyledProperty<double> widthProperty = Layoutable.WidthProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EFlowStateOverlayController_002CMerostrap_002EBarWidth_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Layoutable.WidthProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		P_1.Bind(widthProperty, binding);
		StyledProperty<double> heightProperty = Layoutable.HeightProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EFlowStateOverlayController_002CMerostrap_002EBarHeight_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Layoutable.HeightProperty;
		CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		P_1.Bind(heightProperty, binding2);
		StyledProperty<double> minHeightProperty = Layoutable.MinHeightProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EFlowStateOverlayController_002CMerostrap_002EBarHeight_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Layoutable.MinHeightProperty;
		CompiledBinding binding3 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		P_1.Bind(minHeightProperty, binding3);
		StyledProperty<double> maxHeightProperty = Layoutable.MaxHeightProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EFlowStateOverlayController_002CMerostrap_002EBarHeight_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Layoutable.MaxHeightProperty;
		CompiledBinding binding4 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		P_1.Bind(maxHeightProperty, binding4);
		P_1.CanResize = false;
		P_1.WindowDecorations = WindowDecorations.None;
		P_1.Topmost = true;
		P_1.ShowInTaskbar = false;
		P_1.ShowActivated = false;
		P_1.Background = new ImmutableSolidColorBrush(16777215u);
		P_1.TransparencyLevelHint = new WindowTransparencyLevel[1] { WindowTransparencyLevel.Transparent };
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		P_1.Content = border;
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		border4.AddHandler(InputElement.PointerPressedEvent, context.RootObject.DragPressed);
		border4.Background = new ImmutableSolidColorBrush(4280296994u);
		border4.BorderBrush = new ImmutableSolidColorBrush(4283463018u);
		border4.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		border4.CornerRadius = new CornerRadius(0.0, 0.0, 0.0, 0.0);
		border4.ClipToBounds = true;
		AutomationProperties.SetName(border4, "Flow State cooldown");
		AttachedProperty<string?> helpTextProperty = AutomationProperties.HelpTextProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EFlowStateOverlayController_002CMerostrap_002EStatus_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = AutomationProperties.HelpTextProperty;
		CompiledBinding binding5 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border4.Bind(helpTextProperty, binding5);
		ThresholdFill thresholdFill2;
		ThresholdFill thresholdFill = (thresholdFill2 = new ThresholdFill());
		((ISupportInitialize)thresholdFill).BeginInit();
		border4.Child = thresholdFill;
		ThresholdFill thresholdFill4;
		ThresholdFill thresholdFill3 = (thresholdFill4 = thresholdFill2);
		context.PushParent(thresholdFill4);
		StyledProperty<Orientation> orientationProperty = ThresholdFill.OrientationProperty;
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EFlowStateOverlayController_002CMerostrap_002EOrientation_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ThresholdFill.OrientationProperty;
		CompiledBinding binding6 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		thresholdFill4.Bind(orientationProperty, binding6);
		StyledProperty<double> valueProperty = ThresholdFill.ValueProperty;
		CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EFlowStateOverlayController_002CMerostrap_002EFill_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ThresholdFill.ValueProperty;
		CompiledBinding binding7 = compiledBindingExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		thresholdFill4.Bind(valueProperty, binding7);
		StyledProperty<IBrush?> fillProperty = ThresholdFill.FillProperty;
		CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EFlowStateOverlayController_002CMerostrap_002EFillBrush_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ThresholdFill.FillProperty;
		CompiledBinding binding8 = compiledBindingExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		thresholdFill4.Bind(fillProperty, binding8);
		thresholdFill4.IsHitTestVisible = false;
		context.PopParent();
		((ISupportInitialize)thresholdFill3).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(FlowStateCooldownOverlay P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
