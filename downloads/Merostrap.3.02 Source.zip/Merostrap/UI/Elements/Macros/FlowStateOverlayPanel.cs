using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using CompiledAvaloniaXaml;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.Macros;

namespace Merostrap.UI.Elements.Macros;

public class FlowStateOverlayPanel : UserControl
{
	[CompilerGenerated]
	private class XamlClosure_25
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<FlowStateOverlayPanel> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Border border = (Border)obj;
			context.PushParent(border);
			border.SetValue(Layoutable.WidthProperty, 28.0, BindingPriority.Template);
			border.SetValue(Layoutable.HeightProperty, 28.0, BindingPriority.Template);
			StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EFlowStateOverlayController_002CMerostrap_002EFillBrush_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Border.BackgroundProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border.Bind(backgroundProperty, binding);
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<FlowStateOverlayPanel> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<FlowStateOverlayPanel> context = new XamlIlContext.Context<FlowStateOverlayPanel>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FMacros_002FFlowStateOverlayPanel_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Macros/FlowStateOverlayPanel.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (FlowStateOverlayPanel)service;
				}
			}
			return context;
		}
	}

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public FlowStateOverlayPanel()
	{
		InitializeComponent();
	}

	private async void ColorClicked(object? sender, RoutedEventArgs e)
	{
		object dataContext = DataContext;
		if (!(dataContext is FlowStateOverlayController model) || !(TopLevel.GetTopLevel(this) is Window window))
		{
			return;
		}
		using ((window.DataContext as MacroWorkspace)?.PauseForSettingsEdit())
		{
			string text = await new MacroColourDialog(model.BarColor).ShowPickerAsync(window);
			if (text != null)
			{
				model.BarColor = text;
			}
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, FlowStateOverlayPanel P_1)
	{
		XamlIlContext.Context<FlowStateOverlayPanel> context = new XamlIlContext.Context<FlowStateOverlayPanel>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FMacros_002FFlowStateOverlayPanel_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Macros/FlowStateOverlayPanel.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		P_1.Content = border;
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Border border5 = border4;
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("MacroSurface");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(backgroundProperty, binding);
		StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("MacroBorder");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(borderBrushProperty, binding2);
		border5.BorderThickness = new Thickness(0.0, 0.0, 0.0, 1.0);
		border5.Padding = new Thickness(12.0, 0.0, 12.0, 12.0);
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		border5.Child = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		stackPanel4.Spacing = 8.0;
		Avalonia.Controls.Controls children = stackPanel4.Children;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		children.Add(grid);
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 4;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(26.0, GridUnitType.Pixel)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(52.0, GridUnitType.Pixel)));
		grid5.ColumnDefinitions = columnDefinitions;
		grid5.MinHeight = 48.0;
		Avalonia.Controls.Controls children2 = grid5.Children;
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		children2.Add(lucide);
		Lucide lucide4;
		Lucide lucide3 = (lucide4 = lucide2);
		context.PushParent(lucide4);
		Lucide lucide5 = lucide4;
		lucide5.Icon = LucideIconNames.Activity;
		lucide5.Width = 17.0;
		lucide5.Height = 17.0;
		StyledProperty<IBrush?> strokeBrushProperty = Lucide.StrokeBrushProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
		BindingBase binding3 = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide5.Bind(strokeBrushProperty, binding3);
		lucide5.VerticalAlignment = VerticalAlignment.Center;
		context.PopParent();
		((ISupportInitialize)lucide3).EndInit();
		Avalonia.Controls.Controls children3 = grid5.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children3.Add(textBlock);
		Grid.SetColumn(textBlock2, 1);
		textBlock2.Text = "Flow State overlay";
		textBlock2.FontSize = 13.0;
		textBlock2.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)textBlock2).EndInit();
		Avalonia.Controls.Controls children4 = grid5.Children;
		Border border7;
		Border border6 = (border7 = new Border());
		((ISupportInitialize)border6).BeginInit();
		children4.Add(border6);
		Border border8 = (border4 = border7);
		context.PushParent(border4);
		Border border9 = border4;
		Grid.SetColumn(border9, 2);
		border9.VerticalAlignment = VerticalAlignment.Center;
		StyledProperty<IBrush?> backgroundProperty2 = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("MacroTextField");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding4 = dynamicResourceExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border9.Bind(backgroundProperty2, binding4);
		StyledProperty<IBrush?> borderBrushProperty2 = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension5 = new DynamicResourceExtension("MacroBorder");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding5 = dynamicResourceExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border9.Bind(borderBrushProperty2, binding5);
		border9.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		border9.CornerRadius = new CornerRadius(4.0, 4.0, 4.0, 4.0);
		border9.Padding = new Thickness(8.0, 4.0, 8.0, 4.0);
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		border9.Child = textBlock3;
		TextBlock textBlock6;
		TextBlock textBlock5 = (textBlock6 = textBlock4);
		context.PushParent(textBlock6);
		StyledProperty<string?> textProperty = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EFlowStateOverlayController_002CMerostrap_002EStatus_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding6 = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock6.Bind(textProperty, binding6);
		textBlock6.FontSize = 11.0;
		StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension6 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding7 = dynamicResourceExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock6.Bind(foregroundProperty, binding7);
		context.PopParent();
		((ISupportInitialize)textBlock5).EndInit();
		context.PopParent();
		((ISupportInitialize)border8).EndInit();
		Avalonia.Controls.Controls children5 = grid5.Children;
		ToggleSwitch toggleSwitch2;
		ToggleSwitch toggleSwitch = (toggleSwitch2 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch).BeginInit();
		children5.Add(toggleSwitch);
		ToggleSwitch toggleSwitch4;
		ToggleSwitch toggleSwitch3 = (toggleSwitch4 = toggleSwitch2);
		context.PushParent(toggleSwitch4);
		Grid.SetColumn(toggleSwitch4, 3);
		StyledProperty<bool?> isCheckedProperty = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EFlowStateOverlayController_002CMerostrap_002EEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding8 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch4.Bind(isCheckedProperty, binding8);
		toggleSwitch4.OnContent = "";
		toggleSwitch4.OffContent = "";
		toggleSwitch4.HorizontalAlignment = HorizontalAlignment.Right;
		toggleSwitch4.VerticalAlignment = VerticalAlignment.Center;
		AutomationProperties.SetName(toggleSwitch4, "Enable Flow State cooldown overlay");
		context.PopParent();
		((ISupportInitialize)toggleSwitch3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		Avalonia.Controls.Controls children6 = stackPanel4.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children6.Add(grid6);
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		ColumnDefinitions columnDefinitions2 = new ColumnDefinitions();
		columnDefinitions2.Capacity = 3;
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(26.0, GridUnitType.Pixel)));
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(190.0, GridUnitType.Pixel)));
		grid9.ColumnDefinitions = columnDefinitions2;
		grid9.MinHeight = 34.0;
		Avalonia.Controls.Controls children7 = grid9.Children;
		Lucide lucide7;
		Lucide lucide6 = (lucide7 = new Lucide());
		((ISupportInitialize)lucide6).BeginInit();
		children7.Add(lucide6);
		Lucide lucide8 = (lucide4 = lucide7);
		context.PushParent(lucide4);
		Lucide lucide9 = lucide4;
		lucide9.Icon = LucideIconNames.PanelsTopLeft;
		lucide9.Width = 16.0;
		lucide9.Height = 16.0;
		StyledProperty<IBrush?> strokeBrushProperty2 = Lucide.StrokeBrushProperty;
		DynamicResourceExtension dynamicResourceExtension7 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
		BindingBase binding9 = dynamicResourceExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide9.Bind(strokeBrushProperty2, binding9);
		lucide9.VerticalAlignment = VerticalAlignment.Center;
		context.PopParent();
		((ISupportInitialize)lucide8).EndInit();
		Avalonia.Controls.Controls children8 = grid9.Children;
		TextBlock textBlock8;
		TextBlock textBlock7 = (textBlock8 = new TextBlock());
		((ISupportInitialize)textBlock7).BeginInit();
		children8.Add(textBlock7);
		Grid.SetColumn(textBlock8, 1);
		textBlock8.Text = "Layout";
		textBlock8.FontSize = 12.0;
		textBlock8.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)textBlock8).EndInit();
		Avalonia.Controls.Controls children9 = grid9.Children;
		ComboBox comboBox2;
		ComboBox comboBox = (comboBox2 = new ComboBox());
		((ISupportInitialize)comboBox).BeginInit();
		children9.Add(comboBox);
		ComboBox comboBox4;
		ComboBox comboBox3 = (comboBox4 = comboBox2);
		context.PushParent(comboBox4);
		Grid.SetColumn(comboBox4, 2);
		StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EFlowStateOverlayController_002CMerostrap_002ELayouts_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding10 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		comboBox4.Bind(itemsSourceProperty, binding10);
		DirectProperty<SelectingItemsControl, int> selectedIndexProperty = SelectingItemsControl.SelectedIndexProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EFlowStateOverlayController_002CMerostrap_002ELayoutIndex_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = SelectingItemsControl.SelectedIndexProperty;
		CompiledBinding binding11 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		comboBox4.Bind(selectedIndexProperty, binding11);
		comboBox4.Height = 34.0;
		comboBox4.HorizontalAlignment = HorizontalAlignment.Stretch;
		AutomationProperties.SetName(comboBox4, "Flow State overlay layout");
		context.PopParent();
		((ISupportInitialize)comboBox3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		Avalonia.Controls.Controls children10 = stackPanel4.Children;
		Grid grid11;
		Grid grid10 = (grid11 = new Grid());
		((ISupportInitialize)grid10).BeginInit();
		children10.Add(grid10);
		Grid grid12 = (grid4 = grid11);
		context.PushParent(grid4);
		Grid grid13 = grid4;
		ColumnDefinitions columnDefinitions3 = new ColumnDefinitions();
		columnDefinitions3.Capacity = 3;
		columnDefinitions3.Add(new ColumnDefinition(new GridLength(26.0, GridUnitType.Pixel)));
		columnDefinitions3.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions3.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid13.ColumnDefinitions = columnDefinitions3;
		grid13.MinHeight = 34.0;
		Avalonia.Controls.Controls children11 = grid13.Children;
		Lucide lucide11;
		Lucide lucide10 = (lucide11 = new Lucide());
		((ISupportInitialize)lucide10).BeginInit();
		children11.Add(lucide10);
		Lucide lucide12 = (lucide4 = lucide11);
		context.PushParent(lucide4);
		Lucide lucide13 = lucide4;
		lucide13.Icon = LucideIconNames.Palette;
		lucide13.Width = 16.0;
		lucide13.Height = 16.0;
		StyledProperty<IBrush?> strokeBrushProperty3 = Lucide.StrokeBrushProperty;
		DynamicResourceExtension dynamicResourceExtension8 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
		BindingBase binding12 = dynamicResourceExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide13.Bind(strokeBrushProperty3, binding12);
		lucide13.VerticalAlignment = VerticalAlignment.Center;
		context.PopParent();
		((ISupportInitialize)lucide12).EndInit();
		Avalonia.Controls.Controls children12 = grid13.Children;
		TextBlock textBlock10;
		TextBlock textBlock9 = (textBlock10 = new TextBlock());
		((ISupportInitialize)textBlock9).BeginInit();
		children12.Add(textBlock9);
		Grid.SetColumn(textBlock10, 1);
		textBlock10.Text = "Colour";
		textBlock10.FontSize = 12.0;
		textBlock10.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)textBlock10).EndInit();
		Avalonia.Controls.Controls children13 = grid13.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children13.Add(button);
		Button button4;
		Button button3 = (button4 = button2);
		context.PushParent(button4);
		Grid.SetColumn(button4, 2);
		button4.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.ColorClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button4.Width = 28.0;
		button4.Height = 28.0;
		button4.MinWidth = 0.0;
		button4.MinHeight = 0.0;
		button4.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
		button4.Cursor = new Cursor(StandardCursorType.Hand);
		AutomationProperties.SetName(button4, "Choose Flow State overlay colour");
		ControlTemplate controlTemplate;
		ControlTemplate template = (controlTemplate = new ControlTemplate());
		context.PushParent(controlTemplate);
		controlTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_25.Build_1), context);
		context.PopParent();
		button4.Template = template;
		context.PopParent();
		((ISupportInitialize)button3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid12).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(FlowStateOverlayPanel P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
