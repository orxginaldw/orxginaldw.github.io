using System;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Layout;
using Avalonia.Media;

namespace Merostrap.UI.Elements.Macros;

public sealed class ThresholdFill : Control
{
	public static readonly StyledProperty<Orientation> OrientationProperty;

	public static readonly StyledProperty<double> ValueProperty;

	public static readonly StyledProperty<IBrush?> FillProperty;

	public static readonly StyledProperty<double> MinimumProperty;

	public static readonly StyledProperty<double> MaximumProperty;

	public Orientation Orientation
	{
		get
		{
			return GetValue(OrientationProperty);
		}
		set
		{
			SetValue(OrientationProperty, value);
		}
	}

	public double Minimum
	{
		get
		{
			return GetValue(MinimumProperty);
		}
		set
		{
			SetValue(MinimumProperty, value);
		}
	}

	public double Maximum
	{
		get
		{
			return GetValue(MaximumProperty);
		}
		set
		{
			SetValue(MaximumProperty, value);
		}
	}

	public double Value
	{
		get
		{
			return GetValue(ValueProperty);
		}
		set
		{
			SetValue(ValueProperty, value);
		}
	}

	public IBrush? Fill
	{
		get
		{
			return GetValue(FillProperty);
		}
		set
		{
			SetValue(FillProperty, value);
		}
	}

	static ThresholdFill()
	{
		OrientationProperty = AvaloniaProperty.Register<ThresholdFill, Orientation>("Orientation", Orientation.Horizontal);
		ValueProperty = AvaloniaProperty.Register<ThresholdFill, double>("Value", 0.0);
		FillProperty = AvaloniaProperty.Register<ThresholdFill, IBrush>("Fill");
		MinimumProperty = AvaloniaProperty.Register<ThresholdFill, double>("Minimum", 0.0);
		MaximumProperty = AvaloniaProperty.Register<ThresholdFill, double>("Maximum", 100.0);
		Visual.AffectsRender<ThresholdFill>(new AvaloniaProperty[5] { ValueProperty, FillProperty, MinimumProperty, MaximumProperty, OrientationProperty });
	}

	public override void Render(DrawingContext context)
	{
		if (Fill != null)
		{
			double num = Math.Clamp((Value - Minimum) / Math.Max(1.0, Maximum - Minimum), 0.0, 1.0);
			Rect rect = ((Orientation == Orientation.Vertical) ? new Rect(0.0, Bounds.Height * (1.0 - num), Bounds.Width, Bounds.Height * num) : new Rect(0.0, 0.0, Bounds.Width * num, Bounds.Height));
			context.FillRectangle(Fill, rect, 4f);
		}
	}
}
