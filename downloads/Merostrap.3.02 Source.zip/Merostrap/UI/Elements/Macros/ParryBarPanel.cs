using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Runtime.CompilerServices;
using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using Avalonia.Platform.Storage;
using Avalonia.Styling;
using CompiledAvaloniaXaml;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.Macros;

namespace Merostrap.UI.Elements.Macros;

public class ParryBarPanel : UserControl
{
	[CompilerGenerated]
	private class XamlClosure_30
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<ParryBarPanel> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Border border = (Border)obj;
			context.PushParent(border);
			border.SetValue(Layoutable.WidthProperty, 28.0, BindingPriority.Template);
			border.SetValue(Layoutable.HeightProperty, 28.0, BindingPriority.Template);
			border.SetValue(Border.CornerRadiusProperty, new CornerRadius(0.0, 0.0, 0.0, 0.0), BindingPriority.Template);
			StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EParryBarController_002CMerostrap_002EFillBrush_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Border.BackgroundProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border.Bind(backgroundProperty, binding);
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<ParryBarPanel> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<ParryBarPanel> context = new XamlIlContext.Context<ParryBarPanel>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FMacros_002FParryBarPanel_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Macros/ParryBarPanel.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (ParryBarPanel)service;
				}
			}
			return context;
		}

		public unsafe static object Build_2(IServiceProvider P_0)
		{
			XamlIlContext.Context<ParryBarPanel> context = CreateContext(P_0);
			context.IntermediateRoot = new Grid();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Grid grid = (Grid)obj;
			context.PushParent(grid);
			grid.SetValue(Layoutable.MarginProperty, new Thickness(0.0, 5.0, 0.0, 5.0), BindingPriority.Template);
			Avalonia.Controls.Controls children = grid.Children;
			Border border2;
			Border border = (border2 = new Border());
			((ISupportInitialize)border).BeginInit();
			children.Add(border);
			Border border4;
			Border border3 = (border4 = border2);
			context.PushParent(border4);
			StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("MacroInput");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border4.Bind(backgroundProperty, binding);
			StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
			DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("MacroBorder");
			context.ProvideTargetProperty = Border.BorderBrushProperty;
			BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border4.Bind(borderBrushProperty, binding2);
			border4.SetValue(Border.BorderThicknessProperty, new Thickness(1.0, 1.0, 1.0, 1.0), BindingPriority.Template);
			border4.SetValue(Border.CornerRadiusProperty, new CornerRadius(4.0, 4.0, 4.0, 4.0), BindingPriority.Template);
			context.PopParent();
			((ISupportInitialize)border3).EndInit();
			Avalonia.Controls.Controls children2 = grid.Children;
			ThresholdFill thresholdFill2;
			ThresholdFill thresholdFill = (thresholdFill2 = new ThresholdFill());
			((ISupportInitialize)thresholdFill).BeginInit();
			children2.Add(thresholdFill);
			ThresholdFill thresholdFill4;
			ThresholdFill thresholdFill3 = (thresholdFill4 = thresholdFill2);
			context.PushParent(thresholdFill4);
			thresholdFill4.SetValue(ThresholdFill.MinimumProperty, 50.0, BindingPriority.Template);
			thresholdFill4.SetValue(ThresholdFill.MaximumProperty, 300.0, BindingPriority.Template);
			StyledProperty<double> valueProperty = ThresholdFill.ValueProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EParryBarController_002CMerostrap_002EScalePercent_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = ThresholdFill.ValueProperty;
			CompiledBinding binding3 = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			thresholdFill4.Bind(valueProperty, binding3);
			StyledProperty<IBrush?> fillProperty = ThresholdFill.FillProperty;
			DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("MacroAccent");
			context.ProvideTargetProperty = ThresholdFill.FillProperty;
			BindingBase binding4 = dynamicResourceExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			thresholdFill4.Bind(fillProperty, binding4);
			thresholdFill4.SetValue(InputElement.IsHitTestVisibleProperty, value: false, BindingPriority.Template);
			context.PopParent();
			((ISupportInitialize)thresholdFill3).EndInit();
			Avalonia.Controls.Controls children3 = grid.Children;
			Track track2;
			Track track = (track2 = new Track());
			((ISupportInitialize)track).BeginInit();
			children3.Add(track);
			Track track4;
			Track track3 = (track4 = track2);
			context.PushParent(track4);
			track4.Name = "PART_Track";
			object element = track4;
			context.AvaloniaNameScope.Register("PART_Track", element);
			track4.Bind(Track.MinimumProperty, new TemplateBinding(RangeBase.MinimumProperty).ProvideValue());
			track4.Bind(Track.MaximumProperty, new TemplateBinding(RangeBase.MaximumProperty).ProvideValue());
			track4.Bind(Track.ValueProperty, new TemplateBinding(RangeBase.ValueProperty)
			{
				Mode = BindingMode.TwoWay
			}.ProvideValue());
			track4.SetValue(Track.OrientationProperty, Orientation.Horizontal, BindingPriority.Template);
			StyledProperty<Button?> decreaseButtonProperty = Track.DecreaseButtonProperty;
			RepeatButton repeatButton2;
			RepeatButton repeatButton = (repeatButton2 = new RepeatButton());
			((ISupportInitialize)repeatButton).BeginInit();
			track4.SetValue(decreaseButtonProperty, repeatButton, BindingPriority.Template);
			RepeatButton repeatButton4;
			RepeatButton repeatButton3 = (repeatButton4 = repeatButton2);
			context.PushParent(repeatButton4);
			StyledProperty<IBrush?> backgroundProperty2 = TemplatedControl.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("MacroSelection");
			context.ProvideTargetProperty = TemplatedControl.BackgroundProperty;
			BindingBase binding5 = dynamicResourceExtension4.ProvideValue(context);
			context.ProvideTargetProperty = null;
			repeatButton4.Bind(backgroundProperty2, binding5);
			repeatButton4.SetValue(InputElement.FocusableProperty, value: false, BindingPriority.Template);
			repeatButton4.SetValue(TemplatedControl.TemplateProperty, new ControlTemplate
			{
				Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&Build_3), context)
			}, BindingPriority.Template);
			context.PopParent();
			((ISupportInitialize)repeatButton3).EndInit();
			StyledProperty<Button?> increaseButtonProperty = Track.IncreaseButtonProperty;
			RepeatButton repeatButton6;
			RepeatButton repeatButton5 = (repeatButton6 = new RepeatButton());
			((ISupportInitialize)repeatButton5).BeginInit();
			track4.SetValue(increaseButtonProperty, repeatButton5, BindingPriority.Template);
			repeatButton6.SetValue(TemplatedControl.BackgroundProperty, new ImmutableSolidColorBrush(16777215u), BindingPriority.Template);
			repeatButton6.SetValue(InputElement.FocusableProperty, value: false, BindingPriority.Template);
			repeatButton6.SetValue(TemplatedControl.TemplateProperty, new ControlTemplate
			{
				Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&Build_4), context)
			}, BindingPriority.Template);
			((ISupportInitialize)repeatButton6).EndInit();
			StyledProperty<Thumb?> thumbProperty = Track.ThumbProperty;
			Thumb thumb2;
			Thumb thumb = (thumb2 = new Thumb());
			((ISupportInitialize)thumb).BeginInit();
			track4.SetValue(thumbProperty, thumb, BindingPriority.Template);
			Thumb thumb4;
			Thumb thumb3 = (thumb4 = thumb2);
			context.PushParent(thumb4);
			thumb4.SetValue(Layoutable.WidthProperty, 6.0, BindingPriority.Template);
			StyledProperty<IBrush?> backgroundProperty3 = TemplatedControl.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension5 = new DynamicResourceExtension("MacroAccent");
			context.ProvideTargetProperty = TemplatedControl.BackgroundProperty;
			BindingBase binding6 = dynamicResourceExtension5.ProvideValue(context);
			context.ProvideTargetProperty = null;
			thumb4.Bind(backgroundProperty3, binding6);
			thumb4.SetValue(TemplatedControl.TemplateProperty, new ControlTemplate
			{
				Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&Build_5), context)
			}, BindingPriority.Template);
			context.PopParent();
			((ISupportInitialize)thumb3).EndInit();
			context.PopParent();
			((ISupportInitialize)track3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_3(IServiceProvider P_0)
		{
			XamlIlContext.Context<ParryBarPanel> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((AvaloniaObject)obj).SetValue(Border.BackgroundProperty, (IBrush)new ImmutableSolidColorBrush(16777215u), BindingPriority.Template);
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_4(IServiceProvider P_0)
		{
			XamlIlContext.Context<ParryBarPanel> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((AvaloniaObject)obj).SetValue(Border.BackgroundProperty, (IBrush)new ImmutableSolidColorBrush(16777215u), BindingPriority.Template);
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_5(IServiceProvider P_0)
		{
			XamlIlContext.Context<ParryBarPanel> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((AvaloniaObject)obj).Bind((AvaloniaProperty)Border.BackgroundProperty, new TemplateBinding(TemplatedControl.BackgroundProperty).ProvideValue());
			((AvaloniaObject)obj).SetValue(Border.CornerRadiusProperty, new CornerRadius(3.0, 3.0, 3.0, 3.0), BindingPriority.Template);
			((AvaloniaObject)obj).SetValue(Layoutable.MarginProperty, new Thickness(0.0, -3.0, 0.0, -3.0), BindingPriority.Template);
			((ISupportInitialize)obj).EndInit();
			return obj;
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Slider SizeBar;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBlock ImageError;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public ParryBarPanel()
	{
		InitializeComponent();
		SizeBar.AddHandler(InputElement.PointerPressedEvent, SizePressed, RoutingStrategies.Tunnel);
		SizeBar.AddHandler(InputElement.PointerMovedEvent, SizeMoved, RoutingStrategies.Tunnel);
		SizeBar.AddHandler(InputElement.PointerReleasedEvent, SizeReleased, RoutingStrategies.Tunnel);
	}

	private void SetSize(PointerEventArgs e)
	{
		if (DataContext is ParryBarController parryBarController)
		{
			parryBarController.ScalePercent = 50.0 + 250.0 * Math.Clamp(e.GetPosition(SizeBar).X / SizeBar.Bounds.Width, 0.0, 1.0);
		}
	}

	private void SizePressed(object? sender, PointerPressedEventArgs e)
	{
		if (e.GetCurrentPoint(SizeBar).Properties.IsLeftButtonPressed)
		{
			SizeBar.Focus();
			e.Pointer.Capture(SizeBar);
			SetSize(e);
			e.Handled = true;
		}
	}

	private void SizeMoved(object? sender, PointerEventArgs e)
	{
		if (e.Pointer.Captured == SizeBar)
		{
			SetSize(e);
			e.Handled = true;
		}
	}

	private void SizeReleased(object? sender, PointerReleasedEventArgs e)
	{
		if (e.Pointer.Captured == SizeBar)
		{
			SetSize(e);
			e.Pointer.Capture(null);
			e.Handled = true;
		}
	}

	private async void AutoDetectClicked(object? sender, RoutedEventArgs e)
	{
		if (DataContext is ParryBarController parryBarController && TopLevel.GetTopLevel(this) is Window owner)
		{
			await parryBarController.SelectRegionAsync(owner, automatic: true);
		}
	}

	private async void ImageClicked(object? sender, RoutedEventArgs e)
	{
		object dataContext = DataContext;
		if (!(dataContext is ParryBarController model) || !(TopLevel.GetTopLevel(this) is Window window))
		{
			return;
		}
		ImageError.IsVisible = false;
		try
		{
			IReadOnlyList<IStorageFile> readOnlyList = await window.StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
			{
				Title = "Choose parry bar image",
				AllowMultiple = false,
				FileTypeFilter = new _003C_003Ez__ReadOnlySingleElementList<FilePickerFileType>(new FilePickerFileType("Images and GIFs")
				{
					Patterns = new _003C_003Ez__ReadOnlyArray<string>(new string[5] { "*.png", "*.jpg", "*.jpeg", "*.webp", "*.gif" })
				})
			});
			if (readOnlyList.Count > 0)
			{
				string text = readOnlyList[0].TryGetLocalPath();
				if (text != null)
				{
					model.SetImage(text);
				}
			}
		}
		catch (Exception)
		{
			ImageError.Text = "Could not open this image. Try a PNG or JPG.";
			ImageError.IsVisible = true;
		}
	}

	private void RemoveImageClicked(object? sender, RoutedEventArgs e)
	{
		if (DataContext is ParryBarController parryBarController)
		{
			parryBarController.ClearImage();
		}
		ImageError.IsVisible = false;
	}

	private async void ColorClicked(object? sender, RoutedEventArgs e)
	{
		object dataContext = DataContext;
		if (!(dataContext is ParryBarController model) || !(TopLevel.GetTopLevel(this) is Window window))
		{
			return;
		}
		using ((window.DataContext as MacroWorkspace)?.PauseForSettingsEdit())
		{
			string text = await new MacroColourDialog(model.BarColor).ShowPickerAsync(window);
			if (text != null)
			{
				model.BarColor = text;
			}
		}
	}

	private async void SelectClicked(object? sender, RoutedEventArgs e)
	{
		if (DataContext is ParryBarController parryBarController && TopLevel.GetTopLevel(this) is Window owner)
		{
			await parryBarController.SelectRegionAsync(owner);
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		SizeBar = nameScope?.Find<Slider>("SizeBar");
		ImageError = nameScope?.Find<TextBlock>("ImageError");
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, ParryBarPanel P_1)
	{
		XamlIlContext.Context<ParryBarPanel> context = new XamlIlContext.Context<ParryBarPanel>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FMacros_002FParryBarPanel_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Macros/ParryBarPanel.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		Styles styles = P_1.Styles;
		Style style;
		Style item = (style = new Style());
		context.PushParent(style);
		style.Selector = ((Selector?)null).OfType(typeof(Border)).Class("parry-section");
		Setter setter2;
		Setter setter = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter3 = setter2;
		setter3.Property = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("MacroSurface");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter3.Value = value;
		context.PopParent();
		style.Add(setter);
		Setter setter4 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter5 = setter2;
		setter5.Property = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("MacroBorder");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value2 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter5.Value = value2;
		context.PopParent();
		style.Add(setter4);
		Setter setter6 = new Setter();
		setter6.Property = Border.BorderThicknessProperty;
		setter6.Value = new Thickness(0.0, 0.0, 0.0, 1.0);
		style.Add(setter6);
		Setter setter7 = new Setter();
		setter7.Property = Border.CornerRadiusProperty;
		setter7.Value = new CornerRadius(0.0, 0.0, 0.0, 0.0);
		style.Add(setter7);
		Setter setter8 = new Setter();
		setter8.Property = Decorator.PaddingProperty;
		setter8.Value = new Thickness(12.0, 0.0, 12.0, 12.0);
		style.Add(setter8);
		context.PopParent();
		styles.Add(item);
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		P_1.Content = border;
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Border border5 = border4;
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("MacroSurface");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(backgroundProperty, binding);
		StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("MacroBorder");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding2 = dynamicResourceExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(borderBrushProperty, binding2);
		border5.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		border5.CornerRadius = new CornerRadius(0.0, 0.0, 0.0, 0.0);
		border5.ClipToBounds = true;
		border5.Margin = new Thickness(2.0, 0.0, 2.0, 0.0);
		border5.VerticalAlignment = VerticalAlignment.Top;
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		border5.Child = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		StackPanel stackPanel5 = stackPanel4;
		stackPanel5.Spacing = 0.0;
		Avalonia.Controls.Controls children = stackPanel5.Children;
		Border border7;
		Border border6 = (border7 = new Border());
		((ISupportInitialize)border6).BeginInit();
		children.Add(border6);
		Border border8 = (border4 = border7);
		context.PushParent(border4);
		Border border9 = border4;
		border9.Classes.Add("parry-section");
		StackPanel stackPanel7;
		StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
		((ISupportInitialize)stackPanel6).BeginInit();
		border9.Child = stackPanel6;
		StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
		context.PushParent(stackPanel4);
		StackPanel stackPanel9 = stackPanel4;
		stackPanel9.Spacing = 8.0;
		Avalonia.Controls.Controls children2 = stackPanel9.Children;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		children2.Add(grid);
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 4;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(26.0, GridUnitType.Pixel)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(52.0, GridUnitType.Pixel)));
		grid5.ColumnDefinitions = columnDefinitions;
		grid5.MinHeight = 48.0;
		Avalonia.Controls.Controls children3 = grid5.Children;
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		children3.Add(lucide);
		Lucide lucide4;
		Lucide lucide3 = (lucide4 = lucide2);
		context.PushParent(lucide4);
		Lucide lucide5 = lucide4;
		lucide5.Icon = LucideIconNames.Shield;
		lucide5.Width = 17.0;
		lucide5.Height = 17.0;
		StyledProperty<IBrush?> strokeBrushProperty = Lucide.StrokeBrushProperty;
		DynamicResourceExtension dynamicResourceExtension5 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
		BindingBase binding3 = dynamicResourceExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide5.Bind(strokeBrushProperty, binding3);
		lucide5.VerticalAlignment = VerticalAlignment.Center;
		context.PopParent();
		((ISupportInitialize)lucide3).EndInit();
		Avalonia.Controls.Controls children4 = grid5.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children4.Add(textBlock);
		Grid.SetColumn(textBlock2, 1);
		textBlock2.Text = "Parry Bar";
		textBlock2.FontSize = 13.0;
		textBlock2.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)textBlock2).EndInit();
		Avalonia.Controls.Controls children5 = grid5.Children;
		Border border11;
		Border border10 = (border11 = new Border());
		((ISupportInitialize)border10).BeginInit();
		children5.Add(border10);
		Border border12 = (border4 = border11);
		context.PushParent(border4);
		Border border13 = border4;
		Grid.SetColumn(border13, 2);
		border13.VerticalAlignment = VerticalAlignment.Center;
		StyledProperty<IBrush?> backgroundProperty2 = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension6 = new DynamicResourceExtension("MacroTextField");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding4 = dynamicResourceExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border13.Bind(backgroundProperty2, binding4);
		StyledProperty<IBrush?> borderBrushProperty2 = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension7 = new DynamicResourceExtension("MacroBorder");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding5 = dynamicResourceExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border13.Bind(borderBrushProperty2, binding5);
		border13.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		border13.CornerRadius = new CornerRadius(4.0, 4.0, 4.0, 4.0);
		border13.Padding = new Thickness(8.0, 4.0, 8.0, 4.0);
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		border13.Child = textBlock3;
		TextBlock textBlock6;
		TextBlock textBlock5 = (textBlock6 = textBlock4);
		context.PushParent(textBlock6);
		TextBlock textBlock7 = textBlock6;
		StyledProperty<string?> textProperty = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EParryBarController_002CMerostrap_002EStatus_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding6 = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock7.Bind(textProperty, binding6);
		textBlock7.FontSize = 11.0;
		StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension8 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding7 = dynamicResourceExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock7.Bind(foregroundProperty, binding7);
		context.PopParent();
		((ISupportInitialize)textBlock5).EndInit();
		context.PopParent();
		((ISupportInitialize)border12).EndInit();
		Avalonia.Controls.Controls children6 = grid5.Children;
		ToggleSwitch toggleSwitch2;
		ToggleSwitch toggleSwitch = (toggleSwitch2 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch).BeginInit();
		children6.Add(toggleSwitch);
		ToggleSwitch toggleSwitch4;
		ToggleSwitch toggleSwitch3 = (toggleSwitch4 = toggleSwitch2);
		context.PushParent(toggleSwitch4);
		Grid.SetColumn(toggleSwitch4, 3);
		StyledProperty<bool?> isCheckedProperty = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EParryBarController_002CMerostrap_002EEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding8 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch4.Bind(isCheckedProperty, binding8);
		toggleSwitch4.OnContent = "";
		toggleSwitch4.OffContent = "";
		toggleSwitch4.HorizontalAlignment = HorizontalAlignment.Right;
		toggleSwitch4.VerticalAlignment = VerticalAlignment.Center;
		AutomationProperties.SetName(toggleSwitch4, "Enable parry bar");
		context.PopParent();
		((ISupportInitialize)toggleSwitch3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		Avalonia.Controls.Controls children7 = stackPanel9.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children7.Add(grid6);
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		ColumnDefinitions columnDefinitions2 = new ColumnDefinitions();
		columnDefinitions2.Capacity = 2;
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid9.ColumnDefinitions = columnDefinitions2;
		Avalonia.Controls.Controls children8 = grid9.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children8.Add(button);
		button2.Content = "Auto-detect";
		button2.Height = 34.0;
		button2.HorizontalAlignment = HorizontalAlignment.Stretch;
		button2.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
		button2.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.AutoDetectClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		((ISupportInitialize)button2).EndInit();
		Avalonia.Controls.Controls children9 = grid9.Children;
		Button button5;
		Button button4 = (button5 = new Button());
		((ISupportInitialize)button4).BeginInit();
		children9.Add(button4);
		Button button3;
		Button button6 = (button3 = button5);
		context.PushParent(button3);
		Button button7 = button3;
		Grid.SetColumn(button7, 1);
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EParryBarController_002CMerostrap_002ESelectionLabel_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ContentControl.ContentProperty;
		CompiledBinding compiledBinding = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_4(button7, compiledBinding);
		button7.Height = 34.0;
		button7.HorizontalAlignment = HorizontalAlignment.Stretch;
		button7.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.SelectClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		ToolTip.SetTip(button7, "Select the original coloured cooldown bar while it is full.");
		context.PopParent();
		((ISupportInitialize)button6).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel8).EndInit();
		context.PopParent();
		((ISupportInitialize)border8).EndInit();
		Avalonia.Controls.Controls children10 = stackPanel5.Children;
		Border border15;
		Border border14 = (border15 = new Border());
		((ISupportInitialize)border14).BeginInit();
		children10.Add(border14);
		Border border16 = (border4 = border15);
		context.PushParent(border4);
		Border border17 = border4;
		border17.Classes.Add("parry-section");
		StackPanel stackPanel11;
		StackPanel stackPanel10 = (stackPanel11 = new StackPanel());
		((ISupportInitialize)stackPanel10).BeginInit();
		border17.Child = stackPanel10;
		StackPanel stackPanel12 = (stackPanel4 = stackPanel11);
		context.PushParent(stackPanel4);
		StackPanel stackPanel13 = stackPanel4;
		stackPanel13.Spacing = 8.0;
		stackPanel13.Margin = new Thickness(0.0, 8.0, 0.0, 0.0);
		Avalonia.Controls.Controls children11 = stackPanel13.Children;
		Grid grid11;
		Grid grid10 = (grid11 = new Grid());
		((ISupportInitialize)grid10).BeginInit();
		children11.Add(grid10);
		Grid grid12 = (grid4 = grid11);
		context.PushParent(grid4);
		Grid grid13 = grid4;
		ColumnDefinitions columnDefinitions3 = new ColumnDefinitions();
		columnDefinitions3.Capacity = 3;
		columnDefinitions3.Add(new ColumnDefinition(new GridLength(26.0, GridUnitType.Pixel)));
		columnDefinitions3.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions3.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid13.ColumnDefinitions = columnDefinitions3;
		grid13.MinHeight = 34.0;
		Avalonia.Controls.Controls children12 = grid13.Children;
		Lucide lucide7;
		Lucide lucide6 = (lucide7 = new Lucide());
		((ISupportInitialize)lucide6).BeginInit();
		children12.Add(lucide6);
		Lucide lucide8 = (lucide4 = lucide7);
		context.PushParent(lucide4);
		Lucide lucide9 = lucide4;
		lucide9.Icon = LucideIconNames.Palette;
		lucide9.Width = 16.0;
		lucide9.Height = 16.0;
		StyledProperty<IBrush?> strokeBrushProperty2 = Lucide.StrokeBrushProperty;
		DynamicResourceExtension dynamicResourceExtension9 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
		BindingBase binding9 = dynamicResourceExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide9.Bind(strokeBrushProperty2, binding9);
		lucide9.VerticalAlignment = VerticalAlignment.Center;
		context.PopParent();
		((ISupportInitialize)lucide8).EndInit();
		Avalonia.Controls.Controls children13 = grid13.Children;
		TextBlock textBlock9;
		TextBlock textBlock8 = (textBlock9 = new TextBlock());
		((ISupportInitialize)textBlock8).BeginInit();
		children13.Add(textBlock8);
		Grid.SetColumn(textBlock9, 1);
		textBlock9.Text = "Colour";
		textBlock9.VerticalAlignment = VerticalAlignment.Center;
		textBlock9.FontSize = 12.0;
		((ISupportInitialize)textBlock9).EndInit();
		Avalonia.Controls.Controls children14 = grid13.Children;
		Button button9;
		Button button8 = (button9 = new Button());
		((ISupportInitialize)button8).BeginInit();
		children14.Add(button8);
		Button button10 = (button3 = button9);
		context.PushParent(button3);
		Button button11 = button3;
		Grid.SetColumn(button11, 2);
		button11.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.ColorClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button11.Width = 28.0;
		button11.Height = 28.0;
		button11.MinWidth = 0.0;
		button11.MinHeight = 0.0;
		button11.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
		button11.Cursor = new Cursor(StandardCursorType.Hand);
		AutomationProperties.SetName(button11, "Choose parry bar colour");
		ToolTip.SetTip(button11, "Choose colour");
		ControlTemplate controlTemplate;
		ControlTemplate template = (controlTemplate = new ControlTemplate());
		context.PushParent(controlTemplate);
		controlTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_30.Build_1), context);
		context.PopParent();
		button11.Template = template;
		context.PopParent();
		((ISupportInitialize)button10).EndInit();
		context.PopParent();
		((ISupportInitialize)grid12).EndInit();
		Avalonia.Controls.Controls children15 = stackPanel13.Children;
		Grid grid15;
		Grid grid14 = (grid15 = new Grid());
		((ISupportInitialize)grid14).BeginInit();
		children15.Add(grid14);
		Grid grid16 = (grid4 = grid15);
		context.PushParent(grid4);
		Grid grid17 = grid4;
		ColumnDefinitions columnDefinitions4 = new ColumnDefinitions();
		columnDefinitions4.Capacity = 4;
		columnDefinitions4.Add(new ColumnDefinition(new GridLength(26.0, GridUnitType.Pixel)));
		columnDefinitions4.Add(new ColumnDefinition(new GridLength(74.0, GridUnitType.Pixel)));
		columnDefinitions4.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions4.Add(new ColumnDefinition(new GridLength(72.0, GridUnitType.Pixel)));
		grid17.ColumnDefinitions = columnDefinitions4;
		grid17.ColumnSpacing = 12.0;
		grid17.MinHeight = 34.0;
		Avalonia.Controls.Controls children16 = grid17.Children;
		Lucide lucide11;
		Lucide lucide10 = (lucide11 = new Lucide());
		((ISupportInitialize)lucide10).BeginInit();
		children16.Add(lucide10);
		Lucide lucide12 = (lucide4 = lucide11);
		context.PushParent(lucide4);
		Lucide lucide13 = lucide4;
		lucide13.Icon = LucideIconNames.Maximize;
		lucide13.Width = 16.0;
		lucide13.Height = 16.0;
		StyledProperty<IBrush?> strokeBrushProperty3 = Lucide.StrokeBrushProperty;
		DynamicResourceExtension dynamicResourceExtension10 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
		BindingBase binding10 = dynamicResourceExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide13.Bind(strokeBrushProperty3, binding10);
		lucide13.VerticalAlignment = VerticalAlignment.Center;
		context.PopParent();
		((ISupportInitialize)lucide12).EndInit();
		Avalonia.Controls.Controls children17 = grid17.Children;
		TextBlock textBlock11;
		TextBlock textBlock10 = (textBlock11 = new TextBlock());
		((ISupportInitialize)textBlock10).BeginInit();
		children17.Add(textBlock10);
		Grid.SetColumn(textBlock11, 1);
		textBlock11.Text = "Size";
		textBlock11.VerticalAlignment = VerticalAlignment.Center;
		textBlock11.FontSize = 12.0;
		((ISupportInitialize)textBlock11).EndInit();
		Avalonia.Controls.Controls children18 = grid17.Children;
		Slider slider2;
		Slider slider = (slider2 = new Slider());
		((ISupportInitialize)slider).BeginInit();
		children18.Add(slider);
		Slider slider4;
		Slider slider3 = (slider4 = slider2);
		context.PushParent(slider4);
		slider4.Name = "SizeBar";
		object element = slider4;
		context.AvaloniaNameScope.Register("SizeBar", element);
		Grid.SetColumn(slider4, 2);
		slider4.Height = 34.0;
		slider4.Minimum = 50.0;
		slider4.Maximum = 300.0;
		slider4.TickFrequency = 1.0;
		slider4.IsSnapToTickEnabled = true;
		StyledProperty<double> valueProperty = RangeBase.ValueProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EParryBarController_002CMerostrap_002EScalePercent_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = RangeBase.ValueProperty;
		CompiledBinding binding11 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		slider4.Bind(valueProperty, binding11);
		AutomationProperties.SetName(slider4, "Parry bar size");
		slider4.Cursor = new Cursor(StandardCursorType.Hand);
		ControlTemplate template2 = (controlTemplate = new ControlTemplate());
		context.PushParent(controlTemplate);
		controlTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_30.Build_2), context);
		context.PopParent();
		slider4.Template = template2;
		context.PopParent();
		((ISupportInitialize)slider3).EndInit();
		Avalonia.Controls.Controls children19 = grid17.Children;
		Grid grid19;
		Grid grid18 = (grid19 = new Grid());
		((ISupportInitialize)grid18).BeginInit();
		children19.Add(grid18);
		Grid grid20 = (grid4 = grid19);
		context.PushParent(grid4);
		Grid grid21 = grid4;
		Grid.SetColumn(grid21, 3);
		grid21.Width = 72.0;
		Avalonia.Controls.Controls children20 = grid21.Children;
		NumericUpDown numericUpDown2;
		NumericUpDown numericUpDown = (numericUpDown2 = new NumericUpDown());
		((ISupportInitialize)numericUpDown).BeginInit();
		children20.Add(numericUpDown);
		NumericUpDown numericUpDown4;
		NumericUpDown numericUpDown3 = (numericUpDown4 = numericUpDown2);
		context.PushParent(numericUpDown4);
		numericUpDown4.Width = 72.0;
		numericUpDown4.Height = 34.0;
		numericUpDown4.Padding = new Thickness(10.0, 5.0, 24.0, 5.0);
		numericUpDown4.Minimum = decimal.Parse("50", CultureInfo.InvariantCulture);
		numericUpDown4.Maximum = decimal.Parse("300", CultureInfo.InvariantCulture);
		numericUpDown4.Increment = decimal.Parse("1", CultureInfo.InvariantCulture);
		numericUpDown4.FormatString = "0";
		numericUpDown4.ShowButtonSpinner = false;
		StyledProperty<decimal?> valueProperty2 = NumericUpDown.ValueProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EParryBarController_002CMerostrap_002EScalePercent_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = NumericUpDown.ValueProperty;
		CompiledBinding binding12 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		numericUpDown4.Bind(valueProperty2, binding12);
		AutomationProperties.SetName(numericUpDown4, "Parry bar size percentage");
		context.PopParent();
		((ISupportInitialize)numericUpDown3).EndInit();
		Avalonia.Controls.Controls children21 = grid21.Children;
		TextBlock textBlock13;
		TextBlock textBlock12 = (textBlock13 = new TextBlock());
		((ISupportInitialize)textBlock12).BeginInit();
		children21.Add(textBlock12);
		TextBlock textBlock14 = (textBlock6 = textBlock13);
		context.PushParent(textBlock6);
		TextBlock textBlock15 = textBlock6;
		textBlock15.Text = "%";
		StyledProperty<IBrush?> foregroundProperty2 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension11 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding13 = dynamicResourceExtension11.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock15.Bind(foregroundProperty2, binding13);
		textBlock15.FontSize = 12.0;
		textBlock15.HorizontalAlignment = HorizontalAlignment.Right;
		textBlock15.Margin = new Thickness(0.0, 0.0, 10.0, 0.0);
		textBlock15.VerticalAlignment = VerticalAlignment.Center;
		textBlock15.IsHitTestVisible = false;
		context.PopParent();
		((ISupportInitialize)textBlock14).EndInit();
		context.PopParent();
		((ISupportInitialize)grid20).EndInit();
		context.PopParent();
		((ISupportInitialize)grid16).EndInit();
		Avalonia.Controls.Controls children22 = stackPanel13.Children;
		Grid grid23;
		Grid grid22 = (grid23 = new Grid());
		((ISupportInitialize)grid22).BeginInit();
		children22.Add(grid22);
		Grid grid24 = (grid4 = grid23);
		context.PushParent(grid4);
		Grid grid25 = grid4;
		ColumnDefinitions columnDefinitions5 = new ColumnDefinitions();
		columnDefinitions5.Capacity = 4;
		columnDefinitions5.Add(new ColumnDefinition(new GridLength(26.0, GridUnitType.Pixel)));
		columnDefinitions5.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions5.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions5.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid25.ColumnDefinitions = columnDefinitions5;
		grid25.MinHeight = 34.0;
		Avalonia.Controls.Controls children23 = grid25.Children;
		Lucide lucide15;
		Lucide lucide14 = (lucide15 = new Lucide());
		((ISupportInitialize)lucide14).BeginInit();
		children23.Add(lucide14);
		Lucide lucide16 = (lucide4 = lucide15);
		context.PushParent(lucide4);
		Lucide lucide17 = lucide4;
		lucide17.Icon = LucideIconNames.Image;
		lucide17.Width = 16.0;
		lucide17.Height = 16.0;
		StyledProperty<IBrush?> strokeBrushProperty4 = Lucide.StrokeBrushProperty;
		DynamicResourceExtension dynamicResourceExtension12 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
		BindingBase binding14 = dynamicResourceExtension12.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide17.Bind(strokeBrushProperty4, binding14);
		lucide17.VerticalAlignment = VerticalAlignment.Center;
		context.PopParent();
		((ISupportInitialize)lucide16).EndInit();
		Avalonia.Controls.Controls children24 = grid25.Children;
		TextBlock textBlock17;
		TextBlock textBlock16 = (textBlock17 = new TextBlock());
		((ISupportInitialize)textBlock16).BeginInit();
		children24.Add(textBlock16);
		Grid.SetColumn(textBlock17, 1);
		textBlock17.Text = "Image";
		textBlock17.VerticalAlignment = VerticalAlignment.Center;
		textBlock17.FontSize = 12.0;
		((ISupportInitialize)textBlock17).EndInit();
		Avalonia.Controls.Controls children25 = grid25.Children;
		Button button13;
		Button button12 = (button13 = new Button());
		((ISupportInitialize)button12).BeginInit();
		children25.Add(button12);
		Button button14 = (button3 = button13);
		context.PushParent(button3);
		Button button15 = button3;
		Grid.SetColumn(button15, 2);
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EParryBarController_002CMerostrap_002EImageLabel_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ContentControl.ContentProperty;
		CompiledBinding compiledBinding2 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_4(button15, compiledBinding2);
		button15.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.ImageClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button15.Height = 34.0;
		button15.MaxWidth = 180.0;
		context.PopParent();
		((ISupportInitialize)button14).EndInit();
		Avalonia.Controls.Controls children26 = grid25.Children;
		Button button17;
		Button button16 = (button17 = new Button());
		((ISupportInitialize)button16).BeginInit();
		children26.Add(button16);
		Button button18 = (button3 = button17);
		context.PushParent(button3);
		Button button19 = button3;
		Grid.SetColumn(button19, 3);
		button19.Content = "Remove";
		button19.Margin = new Thickness(8.0, 0.0, 0.0, 0.0);
		button19.Height = 34.0;
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EParryBarController_002CMerostrap_002EHasImage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding15 = compiledBindingExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button19.Bind(isVisibleProperty, binding15);
		button19.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.RemoveImageClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		context.PopParent();
		((ISupportInitialize)button18).EndInit();
		context.PopParent();
		((ISupportInitialize)grid24).EndInit();
		Avalonia.Controls.Controls children27 = stackPanel13.Children;
		TextBlock textBlock19;
		TextBlock textBlock18 = (textBlock19 = new TextBlock());
		((ISupportInitialize)textBlock18).BeginInit();
		children27.Add(textBlock18);
		TextBlock textBlock20 = (textBlock6 = textBlock19);
		context.PushParent(textBlock6);
		TextBlock textBlock21 = textBlock6;
		textBlock21.Name = "ImageError";
		element = textBlock21;
		context.AvaloniaNameScope.Register("ImageError", element);
		textBlock21.IsVisible = false;
		textBlock21.FontSize = 12.0;
		StyledProperty<IBrush?> foregroundProperty3 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension13 = new DynamicResourceExtension("MacroAccent");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding16 = dynamicResourceExtension13.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock21.Bind(foregroundProperty3, binding16);
		textBlock21.TextWrapping = TextWrapping.Wrap;
		context.PopParent();
		((ISupportInitialize)textBlock20).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel12).EndInit();
		context.PopParent();
		((ISupportInitialize)border16).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(ParryBarPanel P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
