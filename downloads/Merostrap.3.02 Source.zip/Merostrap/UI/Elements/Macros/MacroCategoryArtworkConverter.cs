using System;
using System.Collections.Generic;
using System.Globalization;
using Avalonia.Data.Converters;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Platform;

namespace Merostrap.UI.Elements.Macros;

public sealed class MacroCategoryArtworkConverter : IValueConverter
{
	private static readonly Dictionary<string, IBrush> Artwork = new Dictionary<string, IBrush>
	{
		["Combat"] = Load("Combat"),
		["Hallowtide"] = Load("Hallowtide"),
		["Silentheart"] = Load("Silentheart"),
		["Mantras"] = Load("Mantras"),
		["Inventory"] = Load("Inventory"),
		["Training"] = Load("Training"),
		["Utility"] = Load("Utility"),
		["Chat"] = Load("Chat"),
		["Health"] = Load("Health"),
		["Parry Bar"] = Load("ParryBar")
	};

	private static IBrush Load(string name)
	{
		return new ImageBrush(new Bitmap(AssetLoader.Open(new Uri("avares://Merostrap/Resources/Macros/" + name + ".png"))))
		{
			Stretch = Stretch.Uniform
		};
	}

	public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
	{
		bool flag = Artwork.TryGetValue((value as string) ?? "", out IBrush value2);
		string text = parameter as string;
		if (!(text == "visible"))
		{
			if (text == "fallback")
			{
				return !flag;
			}
			return value2;
		}
		return flag;
	}

	public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
	{
		throw new NotSupportedException();
	}
}
