using System;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Platform;
using Merostrap.Macros;
using Merostrap.Macros.Health;

namespace Merostrap.UI.Elements.Macros;

public static class RitualAutoDetection
{
	public static async Task<HealthRegion?> PickAsync(Window owner)
	{
		owner.Hide();
		try
		{
			WindowsHealthCapture.FocusRobloxForDetection();
			await Task.Delay(350);
			(HealthRegion Area, HealthPixels Pixels, HealthRegion Region) scan = await Task.Run(() =>
			{
				nint num = WindowsHealthCapture.ForegroundRobloxWindow();
				HealthRegion healthRegion = WindowsHealthCapture.ForegroundRobloxArea(top: true);
				if ((object)healthRegion == null)
				{
					return ((HealthRegion Area, HealthPixels Pixels, HealthRegion Region))(Area: null, Pixels: null, Region: null);
				}
				WindowsHealthCapture windowsHealthCapture = new WindowsHealthCapture();
				HealthPixels healthPixels = new HealthPixels(healthRegion.Width, healthRegion.Height, new byte[healthRegion.Width * healthRegion.Height * 4]);
				for (int i = 0; i < healthRegion.Height; i += 300)
				{
					if (num == IntPtr.Zero || WindowsHealthCapture.ForegroundRobloxWindow() != num || WindowsHealthCapture.ForegroundRobloxArea(top: true) != healthRegion)
					{
						return ((HealthRegion Area, HealthPixels Pixels, HealthRegion Region))(Area: null, Pixels: null, Region: null);
					}
					HealthPixels healthPixels2 = windowsHealthCapture.Capture(new HealthRegion(healthRegion.X, healthRegion.Y + i, healthRegion.Width, Math.Min(300, healthRegion.Height - i)));
					Array.Copy(healthPixels2.Bgra, 0, healthPixels.Bgra, i * healthRegion.Width * 4, healthPixels2.Bgra.Length);
				}
				HealthRegion item = RitualPromptDetector.Detect(healthPixels);
				return (WindowsHealthCapture.ForegroundRobloxWindow() != num || !(WindowsHealthCapture.ForegroundRobloxArea(top: true) == healthRegion)) ? (Area: null, Pixels: null, Region: null) : (Area: healthRegion, Pixels: healthPixels, Region: item);
			});
			owner.Show();
			owner.Activate();
			Window dialog = new Window
			{
				Title = "Ritual prompt",
				Width = 520.0,
				SizeToContent = SizeToContent.Height,
				CanResize = false,
				WindowStartupLocation = WindowStartupLocation.CenterOwner
			};
			HealthRegion region = scan.Region;
			if ((object)region == null || (object)scan.Pixels == null || (object)scan.Area == null)
			{
				Button button = new Button
				{
					Content = "OK"
				};
				button.Click += (object? _, RoutedEventArgs _) =>
				{
					dialog.Close();
				};
				dialog.Content = new StackPanel
				{
					Margin = new Thickness(20.0),
					Spacing = 16.0,
					Children = 
					{
						(Control)new TextBlock
						{
							Text = "Couldn't identify the outlined prompt frame. Show the frame with its letters or numbers visible in Roblox and retry, or use Select area. Your saved area has been kept.",
							TextWrapping = TextWrapping.Wrap
						},
						(Control)button
					}
				};
				await dialog.ShowDialog(owner);
				return null;
			}
			using WriteableBitmap bitmap = Bitmap(RitualPromptDetector.HudCrop(scan.Pixels, region));
			Button button2 = new Button
			{
				Content = "Use this area"
			};
			Button button3 = new Button
			{
				Content = "Cancel"
			};
			button2.Click += (object? _, RoutedEventArgs _) =>
			{
				dialog.Close(true);
			};
			button3.Click += (object? _, RoutedEventArgs _) =>
			{
				dialog.Close(false);
			};
			dialog.Content = new StackPanel
			{
				Margin = new Thickness(20.0),
				Spacing = 16.0,
				Children = 
				{
					(Control)new TextBlock
					{
						Text = "Confirm this area covers the outlined prompt frame and both rows, excluding the title.",
						TextWrapping = TextWrapping.Wrap
					},
					(Control)new Image
					{
						Source = bitmap,
						Height = 120.0,
						Stretch = Stretch.Uniform
					},
					(Control)new StackPanel
					{
						Orientation = Orientation.Horizontal,
						Spacing = 8.0,
						Children = 
						{
							(Control)button2,
							(Control)button3
						}
					}
				}
			};
			if (!(await dialog.ShowDialog<bool>(owner)))
			{
				return null;
			}
			return region with
			{
				X = region.X + scan.Area.X,
				Y = region.Y + scan.Area.Y
			};
		}
		finally
		{
			owner.Show();
			owner.Activate();
		}
	}

	private static WriteableBitmap Bitmap(HealthPixels pixels)
	{
		WriteableBitmap writeableBitmap = new WriteableBitmap(new PixelSize(pixels.Width, pixels.Height), new Vector(96.0, 96.0), PixelFormat.Bgra8888, AlphaFormat.Opaque);
		using ILockedFramebuffer lockedFramebuffer = writeableBitmap.Lock();
		for (int i = 0; i < pixels.Height; i++)
		{
			Marshal.Copy(pixels.Bgra, i * pixels.Width * 4, lockedFramebuffer.Address + i * lockedFramebuffer.RowBytes, pixels.Width * 4);
		}
		return writeableBitmap;
	}
}
