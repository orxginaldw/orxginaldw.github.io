using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Runtime.CompilerServices;
using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using CompiledAvaloniaXaml;
using Merostrap.Macros;

namespace Merostrap.UI.Elements.Macros;

public class HealthPanel : UserControl
{
	[CompilerGenerated]
	private class XamlClosure_26
	{
		public unsafe static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<HealthPanel> context = CreateContext(P_0);
			context.IntermediateRoot = new Grid();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Grid grid = (Grid)obj;
			context.PushParent(grid);
			Grid grid2 = grid;
			grid2.SetValue(Layoutable.MarginProperty, new Thickness(0.0, 5.0, 0.0, 5.0), BindingPriority.Template);
			Avalonia.Controls.Controls children = grid2.Children;
			Border border2;
			Border border = (border2 = new Border());
			((ISupportInitialize)border).BeginInit();
			children.Add(border);
			Border border4;
			Border border3 = (border4 = border2);
			context.PushParent(border4);
			Border border5 = border4;
			StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("MacroInput");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border5.Bind(backgroundProperty, binding);
			StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
			DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("MacroBorder");
			context.ProvideTargetProperty = Border.BorderBrushProperty;
			BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border5.Bind(borderBrushProperty, binding2);
			border5.SetValue(Border.BorderThicknessProperty, new Thickness(1.0, 1.0, 1.0, 1.0), BindingPriority.Template);
			border5.SetValue(Border.CornerRadiusProperty, new CornerRadius(4.0, 4.0, 4.0, 4.0), BindingPriority.Template);
			context.PopParent();
			((ISupportInitialize)border3).EndInit();
			Avalonia.Controls.Controls children2 = grid2.Children;
			ThresholdFill thresholdFill2;
			ThresholdFill thresholdFill = (thresholdFill2 = new ThresholdFill());
			((ISupportInitialize)thresholdFill).BeginInit();
			children2.Add(thresholdFill);
			ThresholdFill thresholdFill4;
			ThresholdFill thresholdFill3 = (thresholdFill4 = thresholdFill2);
			context.PushParent(thresholdFill4);
			StyledProperty<double> valueProperty = ThresholdFill.ValueProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EHealthAutomation_002CMerostrap_002EDeafenPercent_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = ThresholdFill.ValueProperty;
			CompiledBinding binding3 = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			thresholdFill4.Bind(valueProperty, binding3);
			StyledProperty<IBrush?> fillProperty = ThresholdFill.FillProperty;
			DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("MacroAccent");
			context.ProvideTargetProperty = ThresholdFill.FillProperty;
			BindingBase binding4 = dynamicResourceExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			thresholdFill4.Bind(fillProperty, binding4);
			thresholdFill4.SetValue(InputElement.IsHitTestVisibleProperty, value: false, BindingPriority.Template);
			context.PopParent();
			((ISupportInitialize)thresholdFill3).EndInit();
			Avalonia.Controls.Controls children3 = grid2.Children;
			Track track2;
			Track track = (track2 = new Track());
			((ISupportInitialize)track).BeginInit();
			children3.Add(track);
			Track track4;
			Track track3 = (track4 = track2);
			context.PushParent(track4);
			track4.Name = "PART_Track";
			object element = track4;
			context.AvaloniaNameScope.Register("PART_Track", element);
			track4.Bind(Track.MinimumProperty, new TemplateBinding(RangeBase.MinimumProperty).ProvideValue());
			track4.Bind(Track.MaximumProperty, new TemplateBinding(RangeBase.MaximumProperty).ProvideValue());
			track4.Bind(Track.ValueProperty, new TemplateBinding(RangeBase.ValueProperty)
			{
				Mode = BindingMode.TwoWay
			}.ProvideValue());
			track4.SetValue(Track.OrientationProperty, Orientation.Horizontal, BindingPriority.Template);
			StyledProperty<Button?> decreaseButtonProperty = Track.DecreaseButtonProperty;
			RepeatButton repeatButton2;
			RepeatButton repeatButton = (repeatButton2 = new RepeatButton());
			((ISupportInitialize)repeatButton).BeginInit();
			track4.SetValue(decreaseButtonProperty, repeatButton, BindingPriority.Template);
			RepeatButton repeatButton4;
			RepeatButton repeatButton3 = (repeatButton4 = repeatButton2);
			context.PushParent(repeatButton4);
			StyledProperty<IBrush?> backgroundProperty2 = TemplatedControl.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("MacroSelection");
			context.ProvideTargetProperty = TemplatedControl.BackgroundProperty;
			BindingBase binding5 = dynamicResourceExtension4.ProvideValue(context);
			context.ProvideTargetProperty = null;
			repeatButton4.Bind(backgroundProperty2, binding5);
			repeatButton4.SetValue(InputElement.FocusableProperty, value: false, BindingPriority.Template);
			repeatButton4.SetValue(TemplatedControl.TemplateProperty, new ControlTemplate
			{
				Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&Build_2), context)
			}, BindingPriority.Template);
			context.PopParent();
			((ISupportInitialize)repeatButton3).EndInit();
			StyledProperty<Button?> increaseButtonProperty = Track.IncreaseButtonProperty;
			RepeatButton repeatButton6;
			RepeatButton repeatButton5 = (repeatButton6 = new RepeatButton());
			((ISupportInitialize)repeatButton5).BeginInit();
			track4.SetValue(increaseButtonProperty, repeatButton5, BindingPriority.Template);
			repeatButton6.SetValue(TemplatedControl.BackgroundProperty, new ImmutableSolidColorBrush(16777215u), BindingPriority.Template);
			repeatButton6.SetValue(InputElement.FocusableProperty, value: false, BindingPriority.Template);
			repeatButton6.SetValue(TemplatedControl.TemplateProperty, new ControlTemplate
			{
				Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&Build_3), context)
			}, BindingPriority.Template);
			((ISupportInitialize)repeatButton6).EndInit();
			StyledProperty<Thumb?> thumbProperty = Track.ThumbProperty;
			Thumb thumb2;
			Thumb thumb = (thumb2 = new Thumb());
			((ISupportInitialize)thumb).BeginInit();
			track4.SetValue(thumbProperty, thumb, BindingPriority.Template);
			Thumb thumb4;
			Thumb thumb3 = (thumb4 = thumb2);
			context.PushParent(thumb4);
			thumb4.SetValue(Layoutable.WidthProperty, 6.0, BindingPriority.Template);
			StyledProperty<IBrush?> backgroundProperty3 = TemplatedControl.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension5 = new DynamicResourceExtension("MacroAccent");
			context.ProvideTargetProperty = TemplatedControl.BackgroundProperty;
			BindingBase binding6 = dynamicResourceExtension5.ProvideValue(context);
			context.ProvideTargetProperty = null;
			thumb4.Bind(backgroundProperty3, binding6);
			thumb4.SetValue(TemplatedControl.TemplateProperty, new ControlTemplate
			{
				Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&Build_4), context)
			}, BindingPriority.Template);
			context.PopParent();
			((ISupportInitialize)thumb3).EndInit();
			context.PopParent();
			((ISupportInitialize)track3).EndInit();
			Avalonia.Controls.Controls children4 = grid2.Children;
			Grid grid4;
			Grid grid3 = (grid4 = new Grid());
			((ISupportInitialize)grid3).BeginInit();
			children4.Add(grid3);
			Grid grid5 = (grid = grid4);
			context.PushParent(grid);
			Grid grid6 = grid;
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 5;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid6.ColumnDefinitions = columnDefinitions;
			grid6.SetValue(InputElement.IsHitTestVisibleProperty, value: false, BindingPriority.Template);
			Avalonia.Controls.Controls children5 = grid6.Children;
			Border border7;
			Border border6 = (border7 = new Border());
			((ISupportInitialize)border6).BeginInit();
			children5.Add(border6);
			Border border8 = (border4 = border7);
			context.PushParent(border4);
			Border border9 = border4;
			border9.SetValue(Grid.ColumnProperty, 0, BindingPriority.Template);
			border9.SetValue(Layoutable.HorizontalAlignmentProperty, HorizontalAlignment.Right, BindingPriority.Template);
			border9.SetValue(Layoutable.WidthProperty, 2.0, BindingPriority.Template);
			StyledProperty<IBrush?> backgroundProperty4 = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension6 = new DynamicResourceExtension("MacroBorder");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding7 = dynamicResourceExtension6.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border9.Bind(backgroundProperty4, binding7);
			context.PopParent();
			((ISupportInitialize)border8).EndInit();
			Avalonia.Controls.Controls children6 = grid6.Children;
			Border border11;
			Border border10 = (border11 = new Border());
			((ISupportInitialize)border10).BeginInit();
			children6.Add(border10);
			Border border12 = (border4 = border11);
			context.PushParent(border4);
			Border border13 = border4;
			border13.SetValue(Grid.ColumnProperty, 1, BindingPriority.Template);
			border13.SetValue(Layoutable.HorizontalAlignmentProperty, HorizontalAlignment.Right, BindingPriority.Template);
			border13.SetValue(Layoutable.WidthProperty, 2.0, BindingPriority.Template);
			StyledProperty<IBrush?> backgroundProperty5 = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension7 = new DynamicResourceExtension("MacroBorder");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding8 = dynamicResourceExtension7.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border13.Bind(backgroundProperty5, binding8);
			context.PopParent();
			((ISupportInitialize)border12).EndInit();
			Avalonia.Controls.Controls children7 = grid6.Children;
			Border border15;
			Border border14 = (border15 = new Border());
			((ISupportInitialize)border14).BeginInit();
			children7.Add(border14);
			Border border16 = (border4 = border15);
			context.PushParent(border4);
			Border border17 = border4;
			border17.SetValue(Grid.ColumnProperty, 2, BindingPriority.Template);
			border17.SetValue(Layoutable.HorizontalAlignmentProperty, HorizontalAlignment.Right, BindingPriority.Template);
			border17.SetValue(Layoutable.WidthProperty, 2.0, BindingPriority.Template);
			StyledProperty<IBrush?> backgroundProperty6 = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension8 = new DynamicResourceExtension("MacroBorder");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding9 = dynamicResourceExtension8.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border17.Bind(backgroundProperty6, binding9);
			context.PopParent();
			((ISupportInitialize)border16).EndInit();
			Avalonia.Controls.Controls children8 = grid6.Children;
			Border border19;
			Border border18 = (border19 = new Border());
			((ISupportInitialize)border18).BeginInit();
			children8.Add(border18);
			Border border20 = (border4 = border19);
			context.PushParent(border4);
			Border border21 = border4;
			border21.SetValue(Grid.ColumnProperty, 3, BindingPriority.Template);
			border21.SetValue(Layoutable.HorizontalAlignmentProperty, HorizontalAlignment.Right, BindingPriority.Template);
			border21.SetValue(Layoutable.WidthProperty, 2.0, BindingPriority.Template);
			StyledProperty<IBrush?> backgroundProperty7 = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension9 = new DynamicResourceExtension("MacroBorder");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding10 = dynamicResourceExtension9.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border21.Bind(backgroundProperty7, binding10);
			context.PopParent();
			((ISupportInitialize)border20).EndInit();
			context.PopParent();
			((ISupportInitialize)grid5).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<HealthPanel> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<HealthPanel> context = new XamlIlContext.Context<HealthPanel>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FMacros_002FHealthPanel_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Macros/HealthPanel.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (HealthPanel)service;
				}
			}
			return context;
		}

		public static object Build_2(IServiceProvider P_0)
		{
			XamlIlContext.Context<HealthPanel> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((AvaloniaObject)obj).SetValue(Border.BackgroundProperty, (IBrush)new ImmutableSolidColorBrush(16777215u), BindingPriority.Template);
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_3(IServiceProvider P_0)
		{
			XamlIlContext.Context<HealthPanel> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((AvaloniaObject)obj).SetValue(Border.BackgroundProperty, (IBrush)new ImmutableSolidColorBrush(16777215u), BindingPriority.Template);
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_4(IServiceProvider P_0)
		{
			XamlIlContext.Context<HealthPanel> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((AvaloniaObject)obj).Bind((AvaloniaProperty)Border.BackgroundProperty, new TemplateBinding(TemplatedControl.BackgroundProperty).ProvideValue());
			((AvaloniaObject)obj).SetValue(Border.CornerRadiusProperty, new CornerRadius(3.0, 3.0, 3.0, 3.0), BindingPriority.Template);
			((AvaloniaObject)obj).SetValue(Layoutable.MarginProperty, new Thickness(0.0, -3.0, 0.0, -3.0), BindingPriority.Template);
			((ISupportInitialize)obj).EndInit();
			return obj;
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Slider DeafenBar;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public HealthPanel()
	{
		InitializeComponent();
		DeafenBar.AddHandler(InputElement.PointerPressedEvent, BarPressed, RoutingStrategies.Tunnel);
		DeafenBar.AddHandler(InputElement.PointerMovedEvent, BarMoved, RoutingStrategies.Tunnel);
		DeafenBar.AddHandler(InputElement.PointerReleasedEvent, BarReleased, RoutingStrategies.Tunnel);
	}

	private void SetBarPosition(PointerEventArgs e)
	{
		int value = (int)Math.Round(Math.Clamp(e.GetPosition(DeafenBar).X / DeafenBar.Bounds.Width, 0.0, 1.0) * 100.0);
		if (DataContext is HealthAutomation healthAutomation)
		{
			healthAutomation.DeafenPercent = Math.Clamp(value, 1, 100);
		}
	}

	private void BarPressed(object? sender, PointerPressedEventArgs e)
	{
		if (e.GetCurrentPoint(DeafenBar).Properties.IsLeftButtonPressed)
		{
			DeafenBar.Focus();
			e.Pointer.Capture(DeafenBar);
			SetBarPosition(e);
			e.Handled = true;
		}
	}

	private void BarMoved(object? sender, PointerEventArgs e)
	{
		if (e.Pointer.Captured == DeafenBar)
		{
			SetBarPosition(e);
			e.Handled = true;
		}
	}

	private void BarReleased(object? sender, PointerReleasedEventArgs e)
	{
		if (e.Pointer.Captured == DeafenBar)
		{
			SetBarPosition(e);
			e.Pointer.Capture(null);
			e.Handled = true;
		}
	}

	private async void AutoDetectClicked(object? sender, RoutedEventArgs e)
	{
		if (DataContext is HealthAutomation healthAutomation && TopLevel.GetTopLevel(this) is Window owner)
		{
			await healthAutomation.SelectRegionAsync(owner, automatic: true);
		}
	}

	private async void SelectRegionClicked(object? sender, RoutedEventArgs e)
	{
		if (DataContext is HealthAutomation healthAutomation && TopLevel.GetTopLevel(this) is Window owner)
		{
			await healthAutomation.SelectRegionAsync(owner);
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		DeafenBar = this.FindNameScope()?.Find<Slider>("DeafenBar");
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, HealthPanel P_1)
	{
		XamlIlContext.Context<HealthPanel> context = new XamlIlContext.Context<HealthPanel>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FMacros_002FHealthPanel_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Macros/HealthPanel.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		P_1.Content = border;
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Border border5 = border4;
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("MacroSurface");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(backgroundProperty, binding);
		StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("MacroBorder");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(borderBrushProperty, binding2);
		border5.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		border5.CornerRadius = new CornerRadius(0.0, 0.0, 0.0, 0.0);
		border5.ClipToBounds = true;
		border5.Margin = new Thickness(2.0, 0.0, 2.0, 0.0);
		border5.VerticalAlignment = VerticalAlignment.Top;
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		border5.Child = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		StackPanel stackPanel5 = stackPanel4;
		stackPanel5.Spacing = 0.0;
		Avalonia.Controls.Controls children = stackPanel5.Children;
		Border border7;
		Border border6 = (border7 = new Border());
		((ISupportInitialize)border6).BeginInit();
		children.Add(border6);
		Border border8 = (border4 = border7);
		context.PushParent(border4);
		Border border9 = border4;
		StyledProperty<IBrush?> backgroundProperty2 = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("MacroSurface");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding3 = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border9.Bind(backgroundProperty2, binding3);
		StyledProperty<IBrush?> borderBrushProperty2 = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("MacroBorder");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding4 = dynamicResourceExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border9.Bind(borderBrushProperty2, binding4);
		border9.BorderThickness = new Thickness(0.0, 0.0, 0.0, 1.0);
		border9.Padding = new Thickness(12.0, 0.0, 12.0, 12.0);
		StackPanel stackPanel7;
		StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
		((ISupportInitialize)stackPanel6).BeginInit();
		border9.Child = stackPanel6;
		StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
		context.PushParent(stackPanel4);
		StackPanel stackPanel9 = stackPanel4;
		stackPanel9.Spacing = 8.0;
		Avalonia.Controls.Controls children2 = stackPanel9.Children;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		children2.Add(grid);
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 3;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid5.ColumnDefinitions = columnDefinitions;
		grid5.MinHeight = 48.0;
		Avalonia.Controls.Controls children3 = grid5.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children3.Add(textBlock);
		textBlock2.Text = "Health tracking";
		textBlock2.FontSize = 13.0;
		textBlock2.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)textBlock2).EndInit();
		Avalonia.Controls.Controls children4 = grid5.Children;
		Border border11;
		Border border10 = (border11 = new Border());
		((ISupportInitialize)border10).BeginInit();
		children4.Add(border10);
		Border border12 = (border4 = border11);
		context.PushParent(border4);
		Border border13 = border4;
		Grid.SetColumn(border13, 1);
		border13.Height = 34.0;
		border13.VerticalAlignment = VerticalAlignment.Center;
		StyledProperty<IBrush?> backgroundProperty3 = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension5 = new DynamicResourceExtension("MacroTextField");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding5 = dynamicResourceExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border13.Bind(backgroundProperty3, binding5);
		StyledProperty<IBrush?> borderBrushProperty3 = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension6 = new DynamicResourceExtension("MacroBorder");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding6 = dynamicResourceExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border13.Bind(borderBrushProperty3, binding6);
		border13.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		border13.CornerRadius = new CornerRadius(5.0, 5.0, 5.0, 5.0);
		border13.Padding = new Thickness(10.0, 5.0, 10.0, 5.0);
		border13.Margin = new Thickness(12.0, 0.0, 12.0, 0.0);
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		border13.Child = textBlock3;
		TextBlock textBlock6;
		TextBlock textBlock5 = (textBlock6 = textBlock4);
		context.PushParent(textBlock6);
		TextBlock textBlock7 = textBlock6;
		StyledProperty<string?> textProperty = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EHealthAutomation_002CMerostrap_002EReading_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding7 = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock7.Bind(textProperty, binding7);
		textBlock7.VerticalAlignment = VerticalAlignment.Center;
		textBlock7.FontSize = 12.0;
		StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension7 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding8 = dynamicResourceExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock7.Bind(foregroundProperty, binding8);
		ToolTip.SetTip(textBlock7, "Current health");
		context.PopParent();
		((ISupportInitialize)textBlock5).EndInit();
		context.PopParent();
		((ISupportInitialize)border12).EndInit();
		Avalonia.Controls.Controls children5 = grid5.Children;
		ToggleSwitch toggleSwitch2;
		ToggleSwitch toggleSwitch = (toggleSwitch2 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch).BeginInit();
		children5.Add(toggleSwitch);
		ToggleSwitch toggleSwitch4;
		ToggleSwitch toggleSwitch3 = (toggleSwitch4 = toggleSwitch2);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch5 = toggleSwitch4;
		Grid.SetColumn(toggleSwitch5, 2);
		StyledProperty<bool?> isCheckedProperty = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EHealthAutomation_002CMerostrap_002EEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding9 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch5.Bind(isCheckedProperty, binding9);
		toggleSwitch5.VerticalAlignment = VerticalAlignment.Center;
		toggleSwitch5.MinWidth = 0.0;
		toggleSwitch5.Width = 40.0;
		toggleSwitch5.OnContent = "";
		toggleSwitch5.OffContent = "";
		AutomationProperties.SetName(toggleSwitch5, "Health tracking");
		context.PopParent();
		((ISupportInitialize)toggleSwitch3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		Avalonia.Controls.Controls children6 = stackPanel9.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children6.Add(grid6);
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		ColumnDefinitions columnDefinitions2 = new ColumnDefinitions();
		columnDefinitions2.Capacity = 2;
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid9.ColumnDefinitions = columnDefinitions2;
		grid9.MinHeight = 34.0;
		Avalonia.Controls.Controls children7 = grid9.Children;
		TextBlock textBlock9;
		TextBlock textBlock8 = (textBlock9 = new TextBlock());
		((ISupportInitialize)textBlock8).BeginInit();
		children7.Add(textBlock8);
		TextBlock textBlock10 = (textBlock6 = textBlock9);
		context.PushParent(textBlock6);
		TextBlock textBlock11 = textBlock6;
		textBlock11.Text = "Health bar";
		StyledProperty<IBrush?> foregroundProperty2 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension8 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding10 = dynamicResourceExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock11.Bind(foregroundProperty2, binding10);
		textBlock11.FontSize = 12.0;
		textBlock11.VerticalAlignment = VerticalAlignment.Center;
		context.PopParent();
		((ISupportInitialize)textBlock10).EndInit();
		Avalonia.Controls.Controls children8 = grid9.Children;
		StackPanel stackPanel11;
		StackPanel stackPanel10 = (stackPanel11 = new StackPanel());
		((ISupportInitialize)stackPanel10).BeginInit();
		children8.Add(stackPanel10);
		StackPanel stackPanel12 = (stackPanel4 = stackPanel11);
		context.PushParent(stackPanel4);
		StackPanel stackPanel13 = stackPanel4;
		Grid.SetColumn(stackPanel13, 1);
		stackPanel13.Orientation = Orientation.Horizontal;
		stackPanel13.Spacing = 8.0;
		Avalonia.Controls.Controls children9 = stackPanel13.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children9.Add(button);
		button2.Content = "Auto-detect";
		button2.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.AutoDetectClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button2.Width = 104.0;
		button2.Height = 34.0;
		button2.Padding = new Thickness(10.0, 0.0, 10.0, 0.0);
		((ISupportInitialize)button2).EndInit();
		Avalonia.Controls.Controls children10 = stackPanel13.Children;
		Button button5;
		Button button4 = (button5 = new Button());
		((ISupportInitialize)button4).BeginInit();
		children10.Add(button4);
		Button button3;
		Button button6 = (button3 = button5);
		context.PushParent(button3);
		Button button7 = button3;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EHealthAutomation_002CMerostrap_002ERegionLabel_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ContentControl.ContentProperty;
		CompiledBinding compiledBinding = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_4(button7, compiledBinding);
		button7.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.SelectRegionClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button7.MinWidth = 104.0;
		button7.Height = 34.0;
		button7.Padding = new Thickness(10.0, 0.0, 10.0, 0.0);
		context.PopParent();
		((ISupportInitialize)button6).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel12).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		Avalonia.Controls.Controls children11 = stackPanel9.Children;
		TextBlock textBlock13;
		TextBlock textBlock12 = (textBlock13 = new TextBlock());
		((ISupportInitialize)textBlock12).BeginInit();
		children11.Add(textBlock12);
		TextBlock textBlock14 = (textBlock6 = textBlock13);
		context.PushParent(textBlock6);
		TextBlock textBlock15 = textBlock6;
		StyledProperty<string?> textProperty2 = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EHealthAutomation_002CMerostrap_002EStatus_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding11 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock15.Bind(textProperty2, binding11);
		StyledProperty<IBrush?> foregroundProperty3 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension9 = new DynamicResourceExtension("MacroSubtle");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding12 = dynamicResourceExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock15.Bind(foregroundProperty3, binding12);
		textBlock15.FontSize = 11.0;
		textBlock15.TextWrapping = TextWrapping.Wrap;
		context.PopParent();
		((ISupportInitialize)textBlock14).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel8).EndInit();
		context.PopParent();
		((ISupportInitialize)border8).EndInit();
		Avalonia.Controls.Controls children12 = stackPanel5.Children;
		Border border15;
		Border border14 = (border15 = new Border());
		((ISupportInitialize)border14).BeginInit();
		children12.Add(border14);
		Border border16 = (border4 = border15);
		context.PushParent(border4);
		Border border17 = border4;
		StyledProperty<IBrush?> backgroundProperty4 = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension10 = new DynamicResourceExtension("MacroSurface");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding13 = dynamicResourceExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border17.Bind(backgroundProperty4, binding13);
		StyledProperty<IBrush?> borderBrushProperty4 = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension11 = new DynamicResourceExtension("MacroBorder");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding14 = dynamicResourceExtension11.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border17.Bind(borderBrushProperty4, binding14);
		border17.BorderThickness = new Thickness(0.0, 0.0, 0.0, 1.0);
		border17.Padding = new Thickness(12.0, 0.0, 12.0, 12.0);
		StackPanel stackPanel15;
		StackPanel stackPanel14 = (stackPanel15 = new StackPanel());
		((ISupportInitialize)stackPanel14).BeginInit();
		border17.Child = stackPanel14;
		StackPanel stackPanel16 = (stackPanel4 = stackPanel15);
		context.PushParent(stackPanel4);
		StackPanel stackPanel17 = stackPanel4;
		stackPanel17.Spacing = 8.0;
		Avalonia.Controls.Controls children13 = stackPanel17.Children;
		Grid grid11;
		Grid grid10 = (grid11 = new Grid());
		((ISupportInitialize)grid10).BeginInit();
		children13.Add(grid10);
		Grid grid12 = (grid4 = grid11);
		context.PushParent(grid4);
		Grid grid13 = grid4;
		ColumnDefinitions columnDefinitions3 = new ColumnDefinitions();
		columnDefinitions3.Capacity = 2;
		columnDefinitions3.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions3.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid13.ColumnDefinitions = columnDefinitions3;
		grid13.MinHeight = 48.0;
		Avalonia.Controls.Controls children14 = grid13.Children;
		TextBlock textBlock17;
		TextBlock textBlock16 = (textBlock17 = new TextBlock());
		((ISupportInitialize)textBlock16).BeginInit();
		children14.Add(textBlock16);
		textBlock17.Text = "Auto Deafen";
		textBlock17.FontSize = 13.0;
		textBlock17.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)textBlock17).EndInit();
		Avalonia.Controls.Controls children15 = grid13.Children;
		ToggleSwitch toggleSwitch7;
		ToggleSwitch toggleSwitch6 = (toggleSwitch7 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch6).BeginInit();
		children15.Add(toggleSwitch6);
		ToggleSwitch toggleSwitch8 = (toggleSwitch4 = toggleSwitch7);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch9 = toggleSwitch4;
		Grid.SetColumn(toggleSwitch9, 1);
		StyledProperty<bool?> isCheckedProperty2 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EHealthAutomation_002CMerostrap_002EAutoDeafen_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding15 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch9.Bind(isCheckedProperty2, binding15);
		toggleSwitch9.VerticalAlignment = VerticalAlignment.Center;
		toggleSwitch9.MinWidth = 0.0;
		toggleSwitch9.Width = 40.0;
		toggleSwitch9.OnContent = "";
		toggleSwitch9.OffContent = "";
		AutomationProperties.SetName(toggleSwitch9, "Auto deafen");
		context.PopParent();
		((ISupportInitialize)toggleSwitch8).EndInit();
		context.PopParent();
		((ISupportInitialize)grid12).EndInit();
		Avalonia.Controls.Controls children16 = stackPanel17.Children;
		Grid grid15;
		Grid grid14 = (grid15 = new Grid());
		((ISupportInitialize)grid14).BeginInit();
		children16.Add(grid14);
		Grid grid16 = (grid4 = grid15);
		context.PushParent(grid4);
		Grid grid17 = grid4;
		ColumnDefinitions columnDefinitions4 = new ColumnDefinitions();
		columnDefinitions4.Capacity = 3;
		columnDefinitions4.Add(new ColumnDefinition(new GridLength(100.0, GridUnitType.Pixel)));
		columnDefinitions4.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions4.Add(new ColumnDefinition(new GridLength(72.0, GridUnitType.Pixel)));
		grid17.ColumnDefinitions = columnDefinitions4;
		grid17.ColumnSpacing = 12.0;
		grid17.MinHeight = 34.0;
		Avalonia.Controls.Controls children17 = grid17.Children;
		TextBlock textBlock19;
		TextBlock textBlock18 = (textBlock19 = new TextBlock());
		((ISupportInitialize)textBlock18).BeginInit();
		children17.Add(textBlock18);
		TextBlock textBlock20 = (textBlock6 = textBlock19);
		context.PushParent(textBlock6);
		TextBlock textBlock21 = textBlock6;
		textBlock21.Text = "Deafen at";
		StyledProperty<IBrush?> foregroundProperty4 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension12 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding16 = dynamicResourceExtension12.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock21.Bind(foregroundProperty4, binding16);
		textBlock21.FontSize = 12.0;
		textBlock21.VerticalAlignment = VerticalAlignment.Center;
		context.PopParent();
		((ISupportInitialize)textBlock20).EndInit();
		Avalonia.Controls.Controls children18 = grid17.Children;
		Slider slider2;
		Slider slider = (slider2 = new Slider());
		((ISupportInitialize)slider).BeginInit();
		children18.Add(slider);
		Slider slider4;
		Slider slider3 = (slider4 = slider2);
		context.PushParent(slider4);
		slider4.Name = "DeafenBar";
		object element = slider4;
		context.AvaloniaNameScope.Register("DeafenBar", element);
		Grid.SetColumn(slider4, 1);
		slider4.Height = 34.0;
		slider4.Minimum = 1.0;
		slider4.Maximum = 100.0;
		slider4.TickFrequency = 1.0;
		slider4.IsSnapToTickEnabled = true;
		StyledProperty<double> valueProperty = RangeBase.ValueProperty;
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EHealthAutomation_002CMerostrap_002EDeafenPercent_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = RangeBase.ValueProperty;
		CompiledBinding binding17 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		slider4.Bind(valueProperty, binding17);
		AutomationProperties.SetName(slider4, "Deafen health threshold");
		slider4.Cursor = new Cursor(StandardCursorType.Hand);
		ControlTemplate controlTemplate;
		ControlTemplate template = (controlTemplate = new ControlTemplate());
		context.PushParent(controlTemplate);
		controlTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_26.Build_1), context);
		context.PopParent();
		slider4.Template = template;
		context.PopParent();
		((ISupportInitialize)slider3).EndInit();
		Avalonia.Controls.Controls children19 = grid17.Children;
		Grid grid19;
		Grid grid18 = (grid19 = new Grid());
		((ISupportInitialize)grid18).BeginInit();
		children19.Add(grid18);
		Grid grid20 = (grid4 = grid19);
		context.PushParent(grid4);
		Grid grid21 = grid4;
		Grid.SetColumn(grid21, 2);
		grid21.Width = 72.0;
		Avalonia.Controls.Controls children20 = grid21.Children;
		NumericUpDown numericUpDown2;
		NumericUpDown numericUpDown = (numericUpDown2 = new NumericUpDown());
		((ISupportInitialize)numericUpDown).BeginInit();
		children20.Add(numericUpDown);
		NumericUpDown numericUpDown4;
		NumericUpDown numericUpDown3 = (numericUpDown4 = numericUpDown2);
		context.PushParent(numericUpDown4);
		numericUpDown4.Width = 72.0;
		numericUpDown4.Height = 34.0;
		numericUpDown4.Padding = new Thickness(10.0, 5.0, 24.0, 5.0);
		numericUpDown4.Minimum = decimal.Parse("1", CultureInfo.InvariantCulture);
		numericUpDown4.Maximum = decimal.Parse("100", CultureInfo.InvariantCulture);
		numericUpDown4.Increment = decimal.Parse("1", CultureInfo.InvariantCulture);
		numericUpDown4.FormatString = "0";
		numericUpDown4.ShowButtonSpinner = false;
		StyledProperty<decimal?> valueProperty2 = NumericUpDown.ValueProperty;
		CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EHealthAutomation_002CMerostrap_002EDeafenPercent_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = NumericUpDown.ValueProperty;
		CompiledBinding binding18 = compiledBindingExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		numericUpDown4.Bind(valueProperty2, binding18);
		AutomationProperties.SetName(numericUpDown4, "Deafen health percentage");
		context.PopParent();
		((ISupportInitialize)numericUpDown3).EndInit();
		Avalonia.Controls.Controls children21 = grid21.Children;
		TextBlock textBlock23;
		TextBlock textBlock22 = (textBlock23 = new TextBlock());
		((ISupportInitialize)textBlock22).BeginInit();
		children21.Add(textBlock22);
		TextBlock textBlock24 = (textBlock6 = textBlock23);
		context.PushParent(textBlock6);
		TextBlock textBlock25 = textBlock6;
		textBlock25.Text = "%";
		StyledProperty<IBrush?> foregroundProperty5 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension13 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding19 = dynamicResourceExtension13.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock25.Bind(foregroundProperty5, binding19);
		textBlock25.FontSize = 12.0;
		textBlock25.HorizontalAlignment = HorizontalAlignment.Right;
		textBlock25.Margin = new Thickness(0.0, 0.0, 10.0, 0.0);
		textBlock25.VerticalAlignment = VerticalAlignment.Center;
		textBlock25.IsHitTestVisible = false;
		context.PopParent();
		((ISupportInitialize)textBlock24).EndInit();
		context.PopParent();
		((ISupportInitialize)grid20).EndInit();
		context.PopParent();
		((ISupportInitialize)grid16).EndInit();
		Avalonia.Controls.Controls children22 = stackPanel17.Children;
		Grid grid23;
		Grid grid22 = (grid23 = new Grid());
		((ISupportInitialize)grid22).BeginInit();
		children22.Add(grid22);
		Grid grid24 = (grid4 = grid23);
		context.PushParent(grid4);
		Grid grid25 = grid4;
		ColumnDefinitions columnDefinitions5 = new ColumnDefinitions();
		columnDefinitions5.Capacity = 2;
		columnDefinitions5.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions5.Add(new ColumnDefinition(new GridLength(140.0, GridUnitType.Pixel)));
		grid25.ColumnDefinitions = columnDefinitions5;
		grid25.MinHeight = 34.0;
		Avalonia.Controls.Controls children23 = grid25.Children;
		TextBlock textBlock27;
		TextBlock textBlock26 = (textBlock27 = new TextBlock());
		((ISupportInitialize)textBlock26).BeginInit();
		children23.Add(textBlock26);
		TextBlock textBlock28 = (textBlock6 = textBlock27);
		context.PushParent(textBlock6);
		TextBlock textBlock29 = textBlock6;
		textBlock29.Text = "Discord deafen key";
		StyledProperty<IBrush?> foregroundProperty6 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension14 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding20 = dynamicResourceExtension14.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock29.Bind(foregroundProperty6, binding20);
		textBlock29.FontSize = 12.0;
		textBlock29.VerticalAlignment = VerticalAlignment.Center;
		context.PopParent();
		((ISupportInitialize)textBlock28).EndInit();
		Avalonia.Controls.Controls children24 = grid25.Children;
		KeybindButton keybindButton2;
		KeybindButton keybindButton = (keybindButton2 = new KeybindButton());
		((ISupportInitialize)keybindButton).BeginInit();
		children24.Add(keybindButton);
		KeybindButton keybindButton4;
		KeybindButton keybindButton3 = (keybindButton4 = keybindButton2);
		context.PushParent(keybindButton4);
		Grid.SetColumn(keybindButton4, 1);
		keybindButton4.Width = 110.0;
		keybindButton4.Height = 34.0;
		StyledProperty<string> valueProperty3 = KeybindButton.ValueProperty;
		CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EHealthAutomation_002CMerostrap_002EDeafenKey_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = KeybindButton.ValueProperty;
		CompiledBinding binding21 = compiledBindingExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		keybindButton4.Bind(valueProperty3, binding21);
		AutomationProperties.SetName(keybindButton4, "Discord toggle deafen key");
		ToolTip.SetTip(keybindButton4, "Use the same custom Toggle Deafen key in Discord. Start Discord undeafened.");
		context.PopParent();
		((ISupportInitialize)keybindButton3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid24).EndInit();
		Avalonia.Controls.Controls children25 = stackPanel17.Children;
		TextBlock textBlock31;
		TextBlock textBlock30 = (textBlock31 = new TextBlock());
		((ISupportInitialize)textBlock30).BeginInit();
		children25.Add(textBlock30);
		TextBlock textBlock32 = (textBlock6 = textBlock31);
		context.PushParent(textBlock6);
		TextBlock textBlock33 = textBlock6;
		StyledProperty<string?> textProperty3 = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EHealthAutomation_002CMerostrap_002EDeafenStatus_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding22 = compiledBindingExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock33.Bind(textProperty3, binding22);
		StyledProperty<IBrush?> foregroundProperty7 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension15 = new DynamicResourceExtension("MacroAccent");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding23 = dynamicResourceExtension15.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock33.Bind(foregroundProperty7, binding23);
		textBlock33.FontSize = 11.0;
		textBlock33.TextWrapping = TextWrapping.Wrap;
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EHealthAutomation_002CMerostrap_002EAutoDeafen_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding24 = compiledBindingExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock33.Bind(isVisibleProperty, binding24);
		context.PopParent();
		((ISupportInitialize)textBlock32).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel16).EndInit();
		context.PopParent();
		((ISupportInitialize)border16).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(HealthPanel P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
