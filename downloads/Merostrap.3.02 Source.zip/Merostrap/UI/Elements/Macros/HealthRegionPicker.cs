using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Shapes;
using Avalonia.Input;
using Avalonia.Media;
using Avalonia.Platform;
using Merostrap.Macros.Health;

namespace Merostrap.UI.Elements.Macros;

public sealed class HealthRegionPicker : Window
{
	private readonly Canvas _canvas = new Canvas();

	private readonly Rectangle _selection = new Rectangle
	{
		Stroke = Brush.Parse("#D0BAFF"),
		StrokeThickness = 2.0,
		Fill = Brush.Parse("#30B8A8FF"),
		IsVisible = false
	};

	private readonly Action<HealthRegion?> _finish;

	private Point? _start;

	private HealthRegionPicker(Screen screen, Action<HealthRegion?> finish, string hintText, int maxHeight)
	{
		HealthRegionPicker healthRegionPicker = this;
		_finish = finish;
		Title = "Merostrap · Select area";
		WindowDecorations = WindowDecorations.None;
		CanResize = false;
		Topmost = true;
		ShowInTaskbar = false;
		Position = screen.Bounds.Position;
		Width = (double)screen.Bounds.Width / screen.Scaling;
		Height = (double)screen.Bounds.Height / screen.Scaling;
		Background = Brush.Parse("#40000000");
		TransparencyLevelHint = new _003C_003Ez__ReadOnlySingleElementList<WindowTransparencyLevel>(WindowTransparencyLevel.Transparent);
		Cursor = new Cursor(StandardCursorType.Cross);
		_canvas.Children.Add(_selection);
		Border border = new Border
		{
			Background = Brush.Parse("#EE181A20"),
			CornerRadius = new CornerRadius(8.0),
			Padding = new Thickness(18.0, 12.0),
			Child = new TextBlock
			{
				Text = hintText,
				Foreground = Brushes.White,
				FontSize = 14.0
			}
		};
		Canvas.SetLeft(border, 24.0);
		Canvas.SetTop(border, 24.0);
		_canvas.Children.Add(border);
		Content = _canvas;
		PointerPressed += (object? _, PointerPressedEventArgs e) =>
		{
			if (e.GetCurrentPoint(healthRegionPicker).Properties.IsLeftButtonPressed)
			{
				healthRegionPicker._start = e.GetPosition(healthRegionPicker);
				e.Pointer.Capture(healthRegionPicker);
				healthRegionPicker._selection.IsVisible = true;
				healthRegionPicker.Update(healthRegionPicker._start.Value);
			}
		};
		PointerMoved += (object? _, PointerEventArgs e) =>
		{
			if (healthRegionPicker._start.HasValue)
			{
				healthRegionPicker.Update(e.GetPosition(healthRegionPicker));
			}
		};
		PointerReleased += (object? _, PointerReleasedEventArgs e) =>
		{
			if (healthRegionPicker._start.HasValue)
			{
				PixelPoint pixelPoint = healthRegionPicker.PointToScreen(healthRegionPicker._start.Value);
				PixelPoint pixelPoint2 = healthRegionPicker.PointToScreen(e.GetPosition(healthRegionPicker));
				e.Pointer.Capture(null);
				healthRegionPicker._start = null;
				HealthRegion healthRegion = new HealthRegion(Math.Min(pixelPoint.X, pixelPoint2.X), Math.Min(pixelPoint.Y, pixelPoint2.Y), Math.Abs(pixelPoint.X - pixelPoint2.X), Math.Abs(pixelPoint.Y - pixelPoint2.Y));
				if (healthRegion.Width >= 30 && healthRegion.Height >= 4 && healthRegion.Width <= 4096 && healthRegion.Height <= maxHeight)
				{
					healthRegionPicker._finish(healthRegion);
				}
				else
				{
					healthRegionPicker._selection.IsVisible = false;
				}
			}
		};
		KeyDown += (object? _, KeyEventArgs e) =>
		{
			if (e.Key == Key.Escape)
			{
				e.Handled = true;
				healthRegionPicker._finish(null);
			}
		};
	}

	private void Update(Point point)
	{
		Point value = _start.Value;
		Canvas.SetLeft(_selection, Math.Min(value.X, point.X));
		Canvas.SetTop(_selection, Math.Min(value.Y, point.Y));
		_selection.Width = Math.Abs(value.X - point.X);
		_selection.Height = Math.Abs(value.Y - point.Y);
	}

	public static Task<HealthRegion?> PickAsync(Window owner, string hintText = "Select the whole health bar, including the percentage and HEALTH text. Esc cancels.", int maxHeight = 300)
	{
		TaskCompletionSource<HealthRegion?> result = new TaskCompletionSource<HealthRegion>(TaskCreationOptions.RunContinuationsAsynchronously);
		List<HealthRegionPicker> windows = new List<HealthRegionPicker>();
		foreach (Screen item in owner.Screens.All)
		{
			windows.Add(new HealthRegionPicker(item, Finish, hintText, maxHeight));
		}
		if (windows.Count == 0)
		{
			return Task.FromResult<HealthRegion>(null);
		}
		foreach (HealthRegionPicker item2 in windows)
		{
			item2.Closed += (object? _, EventArgs _) =>
			{
				Finish(null);
			};
			item2.Show();
		}
		return result.Task;
		void Finish(HealthRegion? region)
		{
			if (!result.TrySetResult(region))
			{
				return;
			}
			foreach (HealthRegionPicker item3 in windows)
			{
				item3.Close();
			}
		}
	}
}
