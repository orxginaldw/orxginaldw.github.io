using System;
using System.Globalization;
using Avalonia.Data.Converters;
using LucideAvalonia.Enum;

namespace Merostrap.UI.Elements.Macros;

public sealed class MacroCategoryIconConverter : IValueConverter
{
	public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
	{
		return (value as string) switch
		{
			"Combat" => LucideIconNames.Swords, 
			"Mantras" => LucideIconNames.Sparkles, 
			"Inventory" => LucideIconNames.Backpack, 
			"Training" => LucideIconNames.Dumbbell, 
			"Utility" => LucideIconNames.Wrench, 
			"Chat" => LucideIconNames.MessageCircle, 
			"Health" => LucideIconNames.Heart, 
			"Parry Bar" => LucideIconNames.Shield, 
			"Settings" => LucideIconNames.Settings, 
			_ => LucideIconNames.LayoutGrid, 
		};
	}

	public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
	{
		throw new NotSupportedException();
	}
}
