using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Controls.Presenters;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using Avalonia.Platform;
using Avalonia.Styling;
using Avalonia.Threading;
using Avalonia.VisualTree;
using CompiledAvaloniaXaml;

namespace Merostrap.UI.Elements.Macros;

public class MacroColourDialog : Window
{
	[CompilerGenerated]
	private class XamlClosure_27
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroColourDialog> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((AvaloniaObject)obj).Bind((AvaloniaProperty)Border.BackgroundProperty, new TemplateBinding(TemplatedControl.BackgroundProperty).ProvideValue());
			((AvaloniaObject)obj).Bind((AvaloniaProperty)Border.BorderBrushProperty, new TemplateBinding(TemplatedControl.BorderBrushProperty).ProvideValue());
			((AvaloniaObject)obj).SetValue(Border.BorderThicknessProperty, new Thickness(1.0, 1.0, 1.0, 1.0), BindingPriority.Template);
			((AvaloniaObject)obj).SetValue(Border.CornerRadiusProperty, new CornerRadius(5.0, 5.0, 5.0, 5.0), BindingPriority.Template);
			((AvaloniaObject)obj).SetValue(Decorator.PaddingProperty, new Thickness(9.0, 5.0, 9.0, 5.0), BindingPriority.Template);
			ScrollViewer scrollViewer2;
			ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
			((ISupportInitialize)scrollViewer).BeginInit();
			((Decorator)obj).Child = scrollViewer;
			scrollViewer2.Name = "PART_ScrollViewer";
			object element = scrollViewer2;
			context.AvaloniaNameScope.Register("PART_ScrollViewer", element);
			scrollViewer2.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Hidden, BindingPriority.Template);
			scrollViewer2.SetValue(ScrollViewer.VerticalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled, BindingPriority.Template);
			TextPresenter textPresenter2;
			TextPresenter textPresenter = (textPresenter2 = new TextPresenter());
			((ISupportInitialize)textPresenter).BeginInit();
			scrollViewer2.Content = textPresenter;
			textPresenter2.Name = "PART_TextPresenter";
			element = textPresenter2;
			context.AvaloniaNameScope.Register("PART_TextPresenter", element);
			textPresenter2.Bind(TextPresenter.TextProperty, new TemplateBinding(TextBox.TextProperty)
			{
				Mode = BindingMode.TwoWay
			}.ProvideValue());
			textPresenter2.Bind(TextPresenter.CaretIndexProperty, new TemplateBinding(TextBox.CaretIndexProperty).ProvideValue());
			textPresenter2.Bind(TextPresenter.SelectionStartProperty, new TemplateBinding(TextBox.SelectionStartProperty).ProvideValue());
			textPresenter2.Bind(TextPresenter.SelectionEndProperty, new TemplateBinding(TextBox.SelectionEndProperty).ProvideValue());
			textPresenter2.SetValue(TextPresenter.SelectionBrushProperty, new ImmutableSolidColorBrush(4286831791u), BindingPriority.Template);
			textPresenter2.SetValue(TextPresenter.CaretBrushProperty, new ImmutableSolidColorBrush(4293848818u), BindingPriority.Template);
			textPresenter2.SetValue(Layoutable.VerticalAlignmentProperty, VerticalAlignment.Center, BindingPriority.Template);
			((ISupportInitialize)textPresenter2).EndInit();
			((ISupportInitialize)scrollViewer2).EndInit();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<MacroColourDialog> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroColourDialog> context = new XamlIlContext.Context<MacroColourDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FMacros_002FMacroColourDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Macros/MacroColourDialog.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (MacroColourDialog)service;
				}
			}
			return context;
		}

		public static object Build_2(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroColourDialog> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((AvaloniaObject)obj).Bind((AvaloniaProperty)Border.BackgroundProperty, new TemplateBinding(TemplatedControl.BackgroundProperty).ProvideValue());
			((AvaloniaObject)obj).SetValue(Border.CornerRadiusProperty, new CornerRadius(6.0, 6.0, 6.0, 6.0), BindingPriority.Template);
			((AvaloniaObject)obj).SetValue(Decorator.PaddingProperty, new Thickness(12.0, 0.0, 12.0, 0.0), BindingPriority.Template);
			ContentPresenter contentPresenter2;
			ContentPresenter contentPresenter = (contentPresenter2 = new ContentPresenter());
			((ISupportInitialize)contentPresenter).BeginInit();
			((Decorator)obj).Child = contentPresenter;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_7(contentPresenter2, BindingPriority.Template, new TemplateBinding(ContentControl.ContentProperty).ProvideValue());
			contentPresenter2.SetValue(Layoutable.VerticalAlignmentProperty, VerticalAlignment.Center, BindingPriority.Template);
			contentPresenter2.SetValue(Layoutable.HorizontalAlignmentProperty, HorizontalAlignment.Center, BindingPriority.Template);
			((ISupportInitialize)contentPresenter2).EndInit();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_3(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroColourDialog> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((AvaloniaObject)obj).SetValue(Border.CornerRadiusProperty, new CornerRadius(6.0, 6.0, 6.0, 6.0), BindingPriority.Template);
			((AvaloniaObject)obj).Bind((AvaloniaProperty)Border.BackgroundProperty, new TemplateBinding(TemplatedControl.BackgroundProperty).ProvideValue());
			((ISupportInitialize)obj).EndInit();
			return obj;
		}
	}

	private bool updating;

	private bool editingHex;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal MacroColourPlane Plane;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal MacroColourPlane HueStrip;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Border Preview;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBox Hex;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBlock Error;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button Apply;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public MacroColourDialog()
	{
		InitializeComponent();
		Win32Properties.AddWindowStylesCallback(this, (uint style, uint extended) => (style: style, exStyle: extended | 0x8000080));
		Win32Properties.AddWndProcHookCallback(this, delegate(nint h, uint message, nint w, nint l, ref bool handled)
		{
			if (message == 33 && !editingHex)
			{
				handled = true;
				return new IntPtr(3);
			}
			return IntPtr.Zero;
		});
		AddHandler(InputElement.PointerPressedEvent, (object? _, PointerPressedEventArgs e) =>
		{
			bool hexEditing = e.Source is Visual visual && (visual == Hex || visual.GetVisualAncestors().Contains(Hex));
			SetHexEditing(hexEditing);
		}, RoutingStrategies.Tunnel, handledEventsToo: true);
		Hex.LostFocus += (object? _, FocusChangedEventArgs _) =>
		{
			Avalonia.Threading.Dispatcher.UIThread.Post(() =>
			{
				SetHexEditing(value: false);
			});
		};
		Hex.KeyDown += (object? _, KeyEventArgs e) =>
		{
			if (e.Key == Key.Return)
			{
				e.Handled = true;
				Apply.Focus();
				SetHexEditing(value: false);
			}
		};
		Deactivated += (object? _, EventArgs _) =>
		{
			editingHex = false;
			ConfigureActivation();
		};
		Opened += (object? _, EventArgs _) =>
		{
			Screen screen = Screens.ScreenFromPoint(Position) ?? Screens.Primary;
			if ((object)screen != null)
			{
				PixelRect workingArea = screen.WorkingArea;
				Position = new PixelPoint(Math.Clamp(Position.X, workingArea.X, Math.Max(workingArea.X, workingArea.Right - (int)Math.Ceiling(Width * screen.Scaling))), Math.Clamp(Position.Y, workingArea.Y, Math.Max(workingArea.Y, workingArea.Bottom - (int)Math.Ceiling(Height * screen.Scaling))));
			}
			ConfigureActivation();
		};
		Plane.Changed += Sync;
		HueStrip.Changed += () =>
		{
			Plane.Hue = HueStrip.Hue;
			Plane.InvalidateVisual();
			Sync();
		};
		SetColour(Colors.White);
	}

	public MacroColourDialog(string hex)
		: this()
	{
		if (Color.TryParse(hex, out var color))
		{
			SetColour(color);
		}
	}

	public async Task<string?> ShowPickerAsync(Window owner)
	{
		try
		{
			return await ShowDialog<string>(owner);
		}
		finally
		{
			if (owner is MacroWindow macroWindow)
			{
				macroWindow.RestoreGameFocus();
			}
		}
	}

	private void SetHexEditing(bool value)
	{
		if (editingHex != value)
		{
			editingHex = value;
			ConfigureActivation();
			if (value)
			{
				Activate();
			}
			else if (Owner is MacroWindow macroWindow)
			{
				macroWindow.RestoreGameFocus();
			}
		}
	}

	private void ConfigureActivation()
	{
		if (!OperatingSystem.IsWindows())
		{
			return;
		}
		nint? num = TryGetPlatformHandle()?.Handle;
		if (num.HasValue)
		{
			nint valueOrDefault = num.GetValueOrDefault();
			if (valueOrDefault != IntPtr.Zero)
			{
				int windowLong = GetWindowLong(valueOrDefault, -20);
				SetWindowLong(valueOrDefault, -20, editingHex ? (windowLong & -134217729) : (windowLong | 0x8000080));
			}
		}
	}

	[DllImport("user32.dll")]
	private static extern int GetWindowLong(nint window, int index);

	[DllImport("user32.dll")]
	private static extern int SetWindowLong(nint window, int index, int value);

	private void SetColour(Color c)
	{
		double num = (double)(int)c.R / 255.0;
		double num2 = (double)(int)c.G / 255.0;
		double num3 = (double)(int)c.B / 255.0;
		double num4 = Math.Max(num, Math.Max(num2, num3));
		double num5 = Math.Min(num, Math.Min(num2, num3));
		double num6 = num4 - num5;
		double num7;
		if (num6 == 0.0)
		{
			num7 = Plane.Hue;
		}
		else if (num4 == num)
		{
			num7 = 60.0 * ((num2 - num3) / num6 % 6.0);
		}
		else
		{
			num7 = ((num4 == num2) ? (60.0 * ((num3 - num) / num6 + 2.0)) : (60.0 * ((num - num2) / num6 + 4.0)));
		}
		MacroColourPlane plane = Plane;
		double hue = (HueStrip.Hue = (num7 + 360.0) % 360.0);
		plane.Hue = hue;
		Plane.Saturation = ((num4 == 0.0) ? 0.0 : (num6 / num4));
		Plane.Value = num4;
		Plane.InvalidateVisual();
		HueStrip.InvalidateVisual();
		Sync();
	}

	private void Sync()
	{
		Color color = MacroColourPlane.FromHsv(Plane.Hue, Plane.Saturation, Plane.Value);
		updating = true;
		Hex.Text = $"#{color.R:X2}{color.G:X2}{color.B:X2}";
		updating = false;
		Preview.Background = new SolidColorBrush(color);
		Error.IsVisible = false;
		Apply.IsEnabled = true;
	}

	private void HexChanged(object? sender, TextChangedEventArgs e)
	{
		if (!updating && Plane != null && Apply != null)
		{
			string text = Hex.Text ?? "";
			bool flag = text.Length == 7 && text[0] == '#' && Color.TryParse(text, out var _);
			Error.IsVisible = !flag;
			Apply.IsEnabled = flag;
			if (flag)
			{
				SetColour(Color.Parse(text));
			}
		}
	}

	private void DragPressed(object? sender, PointerPressedEventArgs e)
	{
		if (!(e.Source is Button) && e.GetCurrentPoint(this).Properties.IsLeftButtonPressed)
		{
			BeginMoveDrag(e);
		}
	}

	private void CancelClicked(object? sender, RoutedEventArgs e)
	{
		Close(null);
	}

	private void ApplyClicked(object? sender, RoutedEventArgs e)
	{
		if (Apply.IsEnabled)
		{
			Close(Hex.Text);
		}
	}

	protected override void OnKeyDown(KeyEventArgs e)
	{
		base.OnKeyDown(e);
		if (e.Key == Key.Escape)
		{
			Close(null);
			e.Handled = true;
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		Plane = nameScope?.Find<MacroColourPlane>("Plane");
		HueStrip = nameScope?.Find<MacroColourPlane>("HueStrip");
		Preview = nameScope?.Find<Border>("Preview");
		Hex = nameScope?.Find<TextBox>("Hex");
		Error = nameScope?.Find<TextBlock>("Error");
		Apply = nameScope?.Find<Button>("Apply");
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, MacroColourDialog P_1)
	{
		XamlIlContext.Context<MacroColourDialog> context = new XamlIlContext.Context<MacroColourDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FMacros_002FMacroColourDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Macros/MacroColourDialog.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		P_1.Width = 360.0;
		P_1.Height = 405.0;
		P_1.CanResize = false;
		P_1.WindowDecorations = WindowDecorations.None;
		P_1.Topmost = true;
		P_1.ShowInTaskbar = false;
		P_1.ShowActivated = false;
		P_1.TransparencyLevelHint = new WindowTransparencyLevel[1] { WindowTransparencyLevel.Transparent };
		P_1.TransparencyBackgroundFallback = new ImmutableSolidColorBrush(16777215u);
		P_1.Background = new ImmutableSolidColorBrush(16777215u);
		P_1.WindowStartupLocation = WindowStartupLocation.CenterOwner;
		P_1.Title = "Choose colour";
		Styles styles = P_1.Styles;
		Style style = new Style();
		style.Selector = ((Selector?)null).OfType(typeof(TextBox));
		Setter setter = new Setter();
		setter.Property = TemplatedControl.TemplateProperty;
		setter.Value = new ControlTemplate
		{
			Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_27.Build_1), context)
		};
		style.Add(setter);
		styles.Add(style);
		Styles styles2 = P_1.Styles;
		Style style2 = new Style();
		style2.Selector = ((Selector?)null).OfType(typeof(Button));
		Setter setter2 = new Setter();
		setter2.Property = InputElement.CursorProperty;
		setter2.Value = new Cursor(StandardCursorType.Hand);
		style2.Add(setter2);
		Setter setter3 = new Setter();
		setter3.Property = Layoutable.HeightProperty;
		setter3.Value = 32.0;
		style2.Add(setter3);
		Setter setter4 = new Setter();
		setter4.Property = TemplatedControl.BackgroundProperty;
		setter4.Value = new ImmutableSolidColorBrush(4281677113u);
		style2.Add(setter4);
		Setter setter5 = new Setter();
		setter5.Property = TemplatedControl.ForegroundProperty;
		setter5.Value = new ImmutableSolidColorBrush(4294111988u);
		style2.Add(setter5);
		Setter setter6 = new Setter();
		setter6.Property = TemplatedControl.TemplateProperty;
		setter6.Value = new ControlTemplate
		{
			Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_27.Build_2), context)
		};
		style2.Add(setter6);
		styles2.Add(style2);
		Styles styles3 = P_1.Styles;
		Style style3 = new Style();
		style3.Selector = ((Selector?)null).OfType(typeof(Button)).Class(":pointerover");
		Setter setter7 = new Setter();
		setter7.Property = Visual.OpacityProperty;
		setter7.Value = 0.8;
		style3.Add(setter7);
		styles3.Add(style3);
		Styles styles4 = P_1.Styles;
		Style style4 = new Style();
		style4.Selector = ((Selector?)null).OfType(typeof(Button)).Class("traffic");
		Setter setter8 = new Setter();
		setter8.Property = Layoutable.WidthProperty;
		setter8.Value = 12.0;
		style4.Add(setter8);
		Setter setter9 = new Setter();
		setter9.Property = Layoutable.HeightProperty;
		setter9.Value = 12.0;
		style4.Add(setter9);
		Setter setter10 = new Setter();
		setter10.Property = TemplatedControl.TemplateProperty;
		setter10.Value = new ControlTemplate
		{
			Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_27.Build_3), context)
		};
		style4.Add(setter10);
		styles4.Add(style4);
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		P_1.Content = border;
		border2.Background = new ImmutableSolidColorBrush(4281742905u);
		border2.BorderBrush = new ImmutableSolidColorBrush(4283782491u);
		border2.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		border2.CornerRadius = new CornerRadius(12.0, 12.0, 12.0, 12.0);
		border2.Padding = new Thickness(12.0, 12.0, 12.0, 12.0);
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		border2.Child = grid;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(28.0, GridUnitType.Pixel)));
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid2.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid2.Children;
		Grid grid4;
		Grid grid3 = (grid4 = new Grid());
		((ISupportInitialize)grid3).BeginInit();
		children.Add(grid3);
		grid4.AddHandler(InputElement.PointerPressedEvent, context.RootObject.DragPressed);
		Avalonia.Controls.Controls children2 = grid4.Children;
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		children2.Add(stackPanel);
		stackPanel2.Orientation = Orientation.Horizontal;
		stackPanel2.Spacing = 9.0;
		stackPanel2.VerticalAlignment = VerticalAlignment.Top;
		stackPanel2.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
		Avalonia.Controls.Controls children3 = stackPanel2.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children3.Add(button);
		button2.Classes.Add("traffic");
		button2.Background = new ImmutableSolidColorBrush(4294926167u);
		button2.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.CancelClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		AutomationProperties.SetName(button2, "Close colour picker");
		((ISupportInitialize)button2).EndInit();
		Avalonia.Controls.Controls children4 = stackPanel2.Children;
		Border border4;
		Border border3 = (border4 = new Border());
		((ISupportInitialize)border3).BeginInit();
		children4.Add(border3);
		border4.Width = 12.0;
		border4.Height = 12.0;
		border4.CornerRadius = new CornerRadius(6.0, 6.0, 6.0, 6.0);
		border4.Background = new ImmutableSolidColorBrush(4294884398u);
		((ISupportInitialize)border4).EndInit();
		Avalonia.Controls.Controls children5 = stackPanel2.Children;
		Border border6;
		Border border5 = (border6 = new Border());
		((ISupportInitialize)border5).BeginInit();
		children5.Add(border5);
		border6.Width = 12.0;
		border6.Height = 12.0;
		border6.CornerRadius = new CornerRadius(6.0, 6.0, 6.0, 6.0);
		border6.Background = new ImmutableSolidColorBrush(4280862784u);
		((ISupportInitialize)border6).EndInit();
		((ISupportInitialize)stackPanel2).EndInit();
		Avalonia.Controls.Controls children6 = grid4.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children6.Add(textBlock);
		textBlock2.Text = "Colour";
		textBlock2.Foreground = new ImmutableSolidColorBrush(4292664545u);
		textBlock2.FontSize = 12.0;
		textBlock2.HorizontalAlignment = HorizontalAlignment.Center;
		((ISupportInitialize)textBlock2).EndInit();
		((ISupportInitialize)grid4).EndInit();
		Avalonia.Controls.Controls children7 = grid2.Children;
		Border border8;
		Border border7 = (border8 = new Border());
		((ISupportInitialize)border7).BeginInit();
		children7.Add(border7);
		Grid.SetRow(border8, 1);
		border8.Background = new ImmutableSolidColorBrush(4280295459u);
		border8.BorderBrush = new ImmutableSolidColorBrush(4283190354u);
		border8.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		border8.CornerRadius = new CornerRadius(8.0, 8.0, 8.0, 8.0);
		border8.Padding = new Thickness(16.0, 16.0, 16.0, 16.0);
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		border8.Child = grid6;
		RowDefinitions rowDefinitions2 = new RowDefinitions();
		rowDefinitions2.Capacity = 5;
		rowDefinitions2.Add(new RowDefinition(new GridLength(180.0, GridUnitType.Pixel)));
		rowDefinitions2.Add(new RowDefinition(new GridLength(28.0, GridUnitType.Pixel)));
		rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions2.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid7.RowDefinitions = rowDefinitions2;
		grid7.RowSpacing = 12.0;
		Avalonia.Controls.Controls children8 = grid7.Children;
		MacroColourPlane macroColourPlane2;
		MacroColourPlane macroColourPlane = (macroColourPlane2 = new MacroColourPlane());
		((ISupportInitialize)macroColourPlane).BeginInit();
		children8.Add(macroColourPlane);
		macroColourPlane2.Name = "Plane";
		object element = macroColourPlane2;
		context.AvaloniaNameScope.Register("Plane", element);
		AutomationProperties.SetName(macroColourPlane2, "Saturation and brightness");
		((ISupportInitialize)macroColourPlane2).EndInit();
		Avalonia.Controls.Controls children9 = grid7.Children;
		MacroColourPlane macroColourPlane4;
		MacroColourPlane macroColourPlane3 = (macroColourPlane4 = new MacroColourPlane());
		((ISupportInitialize)macroColourPlane3).BeginInit();
		children9.Add(macroColourPlane3);
		macroColourPlane4.Name = "HueStrip";
		element = macroColourPlane4;
		context.AvaloniaNameScope.Register("HueStrip", element);
		Grid.SetRow(macroColourPlane4, 1);
		macroColourPlane4.IsHue = true;
		macroColourPlane4.Height = 16.0;
		AutomationProperties.SetName(macroColourPlane4, "Hue");
		((ISupportInitialize)macroColourPlane4).EndInit();
		Avalonia.Controls.Controls children10 = grid7.Children;
		Grid grid9;
		Grid grid8 = (grid9 = new Grid());
		((ISupportInitialize)grid8).BeginInit();
		children10.Add(grid8);
		Grid.SetRow(grid9, 2);
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 2;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(32.0, GridUnitType.Pixel)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid9.ColumnDefinitions = columnDefinitions;
		grid9.ColumnSpacing = 10.0;
		Avalonia.Controls.Controls children11 = grid9.Children;
		Border border10;
		Border border9 = (border10 = new Border());
		((ISupportInitialize)border9).BeginInit();
		children11.Add(border9);
		border10.Name = "Preview";
		element = border10;
		context.AvaloniaNameScope.Register("Preview", element);
		border10.Width = 32.0;
		border10.Height = 32.0;
		border10.CornerRadius = new CornerRadius(5.0, 5.0, 5.0, 5.0);
		((ISupportInitialize)border10).EndInit();
		Avalonia.Controls.Controls children12 = grid9.Children;
		TextBox textBox2;
		TextBox textBox = (textBox2 = new TextBox());
		((ISupportInitialize)textBox).BeginInit();
		children12.Add(textBox);
		textBox2.Name = "Hex";
		element = textBox2;
		context.AvaloniaNameScope.Register("Hex", element);
		Grid.SetColumn(textBox2, 1);
		textBox2.Height = 32.0;
		textBox2.MinHeight = 0.0;
		textBox2.Background = new ImmutableSolidColorBrush(4280887597u);
		textBox2.Foreground = new ImmutableSolidColorBrush(4293848818u);
		textBox2.BorderBrush = new ImmutableSolidColorBrush(4283190354u);
		textBox2.CornerRadius = new CornerRadius(5.0, 5.0, 5.0, 5.0);
		textBox2.Padding = new Thickness(9.0, 5.0, 9.0, 5.0);
		textBox2.AddHandler(TextBox.TextChangedEvent, context.RootObject.HexChanged);
		AutomationProperties.SetName(textBox2, "Hex colour");
		((ISupportInitialize)textBox2).EndInit();
		((ISupportInitialize)grid9).EndInit();
		Avalonia.Controls.Controls children13 = grid7.Children;
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		children13.Add(textBlock3);
		textBlock4.Name = "Error";
		element = textBlock4;
		context.AvaloniaNameScope.Register("Error", element);
		Grid.SetRow(textBlock4, 3);
		textBlock4.Text = "Enter a hex colour such as #83DCAF";
		textBlock4.Foreground = new ImmutableSolidColorBrush(4293954186u);
		textBlock4.FontSize = 11.0;
		textBlock4.IsVisible = false;
		((ISupportInitialize)textBlock4).EndInit();
		Avalonia.Controls.Controls children14 = grid7.Children;
		Button button5;
		Button button4 = (button5 = new Button());
		((ISupportInitialize)button4).BeginInit();
		children14.Add(button4);
		button5.Name = "Apply";
		element = button5;
		context.AvaloniaNameScope.Register("Apply", element);
		Grid.SetRow(button5, 4);
		button5.HorizontalAlignment = HorizontalAlignment.Stretch;
		button5.VerticalAlignment = VerticalAlignment.Bottom;
		button5.Content = "Apply colour";
		button5.Background = new ImmutableSolidColorBrush(4286831791u);
		button5.Foreground = new ImmutableSolidColorBrush(4279771933u);
		button5.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.ApplyClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		((ISupportInitialize)button5).EndInit();
		((ISupportInitialize)grid7).EndInit();
		((ISupportInitialize)border8).EndInit();
		((ISupportInitialize)grid2).EndInit();
		((ISupportInitialize)border2).EndInit();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(MacroColourDialog P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
