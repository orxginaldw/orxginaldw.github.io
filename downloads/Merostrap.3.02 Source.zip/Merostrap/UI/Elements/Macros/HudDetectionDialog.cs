using System;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Platform;
using Avalonia.Threading;

namespace Merostrap.UI.Elements.Macros;

public sealed class HudDetectionDialog : Window
{
	public HudDetectionDialog()
	{
		Topmost = true;
		ShowInTaskbar = false;
		ShowActivated = false;
		WindowStartupLocation = WindowStartupLocation.CenterOwner;
		Win32Properties.AddWindowStylesCallback(this, (uint style, uint extended) => (style: style, exStyle: (extended | 0x8000080) & 0xFFFBFFFFu));
		Win32Properties.AddWndProcHookCallback(this, delegate(nint h, uint message, nint w, nint l, ref bool handled)
		{
			if (message == 33)
			{
				handled = true;
				return new IntPtr(3);
			}
			return IntPtr.Zero;
		});
		Opened += (object? _, EventArgs _) =>
		{
			Avalonia.Threading.Dispatcher.UIThread.Post(() =>
			{
				Screen screen = Screens.ScreenFromPoint(Position) ?? Screens.Primary;
				if ((object)screen != null)
				{
					PixelRect workingArea = screen.WorkingArea;
					int num = (int)Math.Ceiling(Bounds.Width * screen.Scaling);
					int num2 = (int)Math.Ceiling(Bounds.Height * screen.Scaling) + 40;
					Position = new PixelPoint(Math.Clamp(Position.X, workingArea.X, Math.Max(workingArea.X, workingArea.Right - num)), Math.Clamp(Position.Y, workingArea.Y, Math.Max(workingArea.Y, workingArea.Bottom - num2)));
				}
			});
		};
	}
}
