using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;
using AnimatedImage.Avalonia;
using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Controls.Shapes;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using Avalonia.Platform;
using Avalonia.Styling;
using Avalonia.Threading;
using CompiledAvaloniaXaml;
using Merostrap.Macros;

namespace Merostrap.UI.Elements.Macros;

public class ParryBarOverlay : Window
{
	private static ParryBarOverlay? _visibleOverlay;

	private Mutex? _visibilityMutex;

	private readonly ParryBarController _model;

	private bool _positionReady;

	private readonly DispatcherTimer _save = new DispatcherTimer
	{
		Interval = TimeSpan.FromMilliseconds(300L)
	};

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Rectangle CooldownFill;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Border ImageReveal;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Image ParryImage;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public bool CanDrag => true;

	public bool TryShow()
	{
		Avalonia.Threading.Dispatcher.UIThread.VerifyAccess();
		if (IsVisible)
		{
			return true;
		}
		if (_visibleOverlay != null)
		{
			return false;
		}
		Mutex mutex = new Mutex(initiallyOwned: false, "Local\\Merostrap.ParryBarOverlay");
		bool flag;
		try
		{
			flag = mutex.WaitOne(0);
		}
		catch (AbandonedMutexException)
		{
			flag = true;
		}
		if (!flag)
		{
			mutex.Dispose();
			return false;
		}
		_visibilityMutex = mutex;
		_visibleOverlay = this;
		try
		{
			Show();
			return true;
		}
		catch
		{
			ReleaseVisibility();
			throw;
		}
	}

	private void ReleaseVisibility()
	{
		if (_visibilityMutex != null)
		{
			_visibilityMutex.ReleaseMutex();
			_visibilityMutex.Dispose();
			_visibilityMutex = null;
			if (_visibleOverlay == this)
			{
				_visibleOverlay = null;
			}
		}
	}

	public ParryBarOverlay()
		: this(MacroWorkspace.Current.ParryBar)
	{
	}

	public ParryBarOverlay(ParryBarController model)
	{
		ParryBarOverlay parryBarOverlay = this;
		_model = model;
		InitializeComponent();
		DataContext = model;
		Win32Properties.AddWindowStylesCallback(this, (uint style, uint extended) => (style: (style & 0xFF30FFFFu) | 0x80000000u, exStyle: extended));
		_model.PropertyChanged += ImageChanged;
		_save.Tick += (object? _, EventArgs _) =>
		{
			parryBarOverlay.FlushPosition();
		};
		Opened += (object? _, EventArgs _) =>
		{
			PixelPoint pixelPoint = new PixelPoint(model.X ?? 24, model.Y ?? 200);
			Screen screen = parryBarOverlay.Screens.ScreenFromPoint(pixelPoint) ?? parryBarOverlay.Screens.Primary;
			if ((object)screen != null)
			{
				PixelRect workingArea = screen.WorkingArea;
				pixelPoint = new PixelPoint(Math.Clamp(pixelPoint.X, workingArea.X, Math.Max(workingArea.X, workingArea.Right - (int)(parryBarOverlay.Width * screen.Scaling))), Math.Clamp(pixelPoint.Y, workingArea.Y, Math.Max(workingArea.Y, workingArea.Bottom - (int)(80.0 * screen.Scaling))));
			}
			parryBarOverlay.Position = pixelPoint;
			parryBarOverlay._positionReady = true;
			if (OperatingSystem.IsWindows())
			{
				nint? num = parryBarOverlay.TryGetPlatformHandle()?.Handle;
				if (num.HasValue)
				{
					nint valueOrDefault = num.GetValueOrDefault();
					if (valueOrDefault != IntPtr.Zero)
					{
						SetWindowDisplayAffinity(valueOrDefault, 17u);
					}
				}
			}
		};
		PositionChanged += (object? _, PixelPointEventArgs _) =>
		{
			if (parryBarOverlay._positionReady)
			{
				parryBarOverlay._save.Stop();
				parryBarOverlay._save.Start();
			}
		};
		Closing += (object? _, WindowClosingEventArgs _) =>
		{
			if (parryBarOverlay.IsVisible)
			{
				parryBarOverlay.FlushPosition();
			}
			parryBarOverlay._save.Stop();
			parryBarOverlay._positionReady = false;
		};
		Closed += (object? _, EventArgs _) =>
		{
			parryBarOverlay.ReleaseVisibility();
			parryBarOverlay._model.PropertyChanged -= parryBarOverlay.ImageChanged;
			ImageBehavior.SetAnimatedSource(parryBarOverlay.ParryImage, null);
		};
	}

	private void ImageChanged(object? sender, PropertyChangedEventArgs e)
	{
		if (e.PropertyName == "AnimatedImagePath")
		{
			UpdateAnimation();
		}
	}

	private void UpdateAnimation()
	{
		if (ParryImage == null || _model == null)
		{
			return;
		}
		ImageBehavior.SetAnimatedSource(ParryImage, null);
		ParryImage.Source = _model.BarImage;
		if (IsVisible)
		{
			string animatedImagePath = _model.AnimatedImagePath;
			if (animatedImagePath != null)
			{
				ImageBehavior.SetAnimatedSource(ParryImage, new AnimatedImageSourceUri(new Uri(animatedImagePath, UriKind.Absolute)));
				ImageBehavior.SetRepeatBehavior(ParryImage, RepeatBehavior.Forever);
			}
		}
	}

	private void FlushPosition()
	{
		_save.Stop();
		if (_positionReady)
		{
			_model.SavePosition(Position.X, Position.Y);
		}
	}

	protected override void OnPropertyChanged(AvaloniaPropertyChangedEventArgs change)
	{
		base.OnPropertyChanged(change);
		if (change.Property == Visual.IsVisibleProperty && !IsVisible)
		{
			ReleaseVisibility();
		}
		if (change.Property == Visual.IsVisibleProperty && !IsVisible && _positionReady)
		{
			FlushPosition();
		}
		if (change.Property == Visual.IsVisibleProperty)
		{
			UpdateAnimation();
		}
	}

	private void DragPressed(object? sender, PointerPressedEventArgs e)
	{
		if (CanDrag && e.GetCurrentPoint(this).Properties.IsLeftButtonPressed)
		{
			BeginMoveDrag(e);
		}
	}

	[DllImport("user32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool SetWindowDisplayAffinity(nint window, uint affinity);

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		CooldownFill = nameScope?.Find<Rectangle>("CooldownFill");
		ImageReveal = nameScope?.Find<Border>("ImageReveal");
		ParryImage = nameScope?.Find<Image>("ParryImage");
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, ParryBarOverlay P_1)
	{
		XamlIlContext.Context<ParryBarOverlay> context = new XamlIlContext.Context<ParryBarOverlay>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FMacros_002FParryBarOverlay_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Macros/ParryBarOverlay.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Title = "Merostrap parry bar";
		StyledProperty<double> widthProperty = Layoutable.WidthProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EParryBarController_002CMerostrap_002EBarWidth_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Layoutable.WidthProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		P_1.Bind(widthProperty, binding);
		StyledProperty<double> heightProperty = Layoutable.HeightProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EParryBarController_002CMerostrap_002EBarHeight_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Layoutable.HeightProperty;
		CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		P_1.Bind(heightProperty, binding2);
		StyledProperty<double> minHeightProperty = Layoutable.MinHeightProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EParryBarController_002CMerostrap_002EBarHeight_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Layoutable.MinHeightProperty;
		CompiledBinding binding3 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		P_1.Bind(minHeightProperty, binding3);
		StyledProperty<double> maxHeightProperty = Layoutable.MaxHeightProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EParryBarController_002CMerostrap_002EBarHeight_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Layoutable.MaxHeightProperty;
		CompiledBinding binding4 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		P_1.Bind(maxHeightProperty, binding4);
		P_1.CanResize = false;
		P_1.WindowDecorations = WindowDecorations.None;
		P_1.Topmost = true;
		P_1.ShowInTaskbar = false;
		P_1.ShowActivated = false;
		P_1.Background = new ImmutableSolidColorBrush(16777215u);
		P_1.TransparencyLevelHint = new WindowTransparencyLevel[1] { WindowTransparencyLevel.Transparent };
		P_1.RequestedThemeVariant = ThemeVariant.Dark;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		P_1.Content = border;
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Border border5 = border4;
		border5.AddHandler(InputElement.PointerPressedEvent, context.RootObject.DragPressed);
		border5.Background = new ImmutableSolidColorBrush(4280296994u);
		border5.BorderBrush = new ImmutableSolidColorBrush(4283463018u);
		border5.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		border5.CornerRadius = new CornerRadius(0.0, 0.0, 0.0, 0.0);
		StyledProperty<double> heightProperty2 = Layoutable.HeightProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EParryBarController_002CMerostrap_002EBarHeight_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Layoutable.HeightProperty;
		CompiledBinding binding5 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(heightProperty2, binding5);
		border5.ClipToBounds = true;
		AutomationProperties.SetName(border5, "Parry cooldown");
		AttachedProperty<string?> helpTextProperty = AutomationProperties.HelpTextProperty;
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EParryBarController_002CMerostrap_002EStatus_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = AutomationProperties.HelpTextProperty;
		CompiledBinding binding6 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(helpTextProperty, binding6);
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		border5.Child = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Avalonia.Controls.Controls children = grid4.Children;
		Rectangle rectangle2;
		Rectangle rectangle = (rectangle2 = new Rectangle());
		((ISupportInitialize)rectangle).BeginInit();
		children.Add(rectangle);
		Rectangle rectangle4;
		Rectangle rectangle3 = (rectangle4 = rectangle2);
		context.PushParent(rectangle4);
		rectangle4.Name = "CooldownFill";
		object element = rectangle4;
		context.AvaloniaNameScope.Register("CooldownFill", element);
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Merostrap_002EMacros_002EParryBarController_002CMerostrap_002EHasImage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding7 = compiledBindingExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		rectangle4.Bind(isVisibleProperty, binding7);
		StyledProperty<IBrush?> fillProperty = Shape.FillProperty;
		CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EParryBarController_002CMerostrap_002EFillBrush_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Shape.FillProperty;
		CompiledBinding binding8 = compiledBindingExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		rectangle4.Bind(fillProperty, binding8);
		rectangle4.RenderTransformOrigin = new RelativePoint(0.0, 0.5, RelativeUnit.Relative);
		ScaleTransform scaleTransform;
		ScaleTransform renderTransform = (scaleTransform = new ScaleTransform());
		context.PushParent(scaleTransform);
		StyledProperty<double> scaleXProperty = ScaleTransform.ScaleXProperty;
		CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EParryBarController_002CMerostrap_002EDisplayFillRatio_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ScaleTransform.ScaleXProperty;
		CompiledBinding binding9 = compiledBindingExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		scaleTransform.Bind(scaleXProperty, binding9);
		context.PopParent();
		rectangle4.RenderTransform = renderTransform;
		context.PopParent();
		((ISupportInitialize)rectangle3).EndInit();
		Avalonia.Controls.Controls children2 = grid4.Children;
		Border border7;
		Border border6 = (border7 = new Border());
		((ISupportInitialize)border6).BeginInit();
		children2.Add(border6);
		Border border8 = (border4 = border7);
		context.PushParent(border4);
		Border border9 = border4;
		border9.Name = "ImageReveal";
		element = border9;
		context.AvaloniaNameScope.Register("ImageReveal", element);
		StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EParryBarController_002CMerostrap_002EHasImage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding10 = compiledBindingExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border9.Bind(isVisibleProperty2, binding10);
		StyledProperty<double> widthProperty2 = Layoutable.WidthProperty;
		CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EParryBarController_002CMerostrap_002EDisplayImageFillWidth_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Layoutable.WidthProperty;
		CompiledBinding binding11 = compiledBindingExtension11.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border9.Bind(widthProperty2, binding11);
		border9.HorizontalAlignment = HorizontalAlignment.Left;
		border9.ClipToBounds = true;
		Image image2;
		Image image = (image2 = new Image());
		((ISupportInitialize)image).BeginInit();
		border9.Child = image;
		Image image4;
		Image image3 = (image4 = image2);
		context.PushParent(image4);
		image4.Name = "ParryImage";
		element = image4;
		context.AvaloniaNameScope.Register("ParryImage", element);
		StyledProperty<IImage?> sourceProperty = Image.SourceProperty;
		CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EParryBarController_002CMerostrap_002EBarImage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Image.SourceProperty;
		CompiledBinding binding12 = compiledBindingExtension12.ProvideValue(context);
		context.ProvideTargetProperty = null;
		image4.Bind(sourceProperty, binding12);
		StyledProperty<double> widthProperty3 = Layoutable.WidthProperty;
		CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EParryBarController_002CMerostrap_002EImageWidth_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Layoutable.WidthProperty;
		CompiledBinding binding13 = compiledBindingExtension13.ProvideValue(context);
		context.ProvideTargetProperty = null;
		image4.Bind(widthProperty3, binding13);
		StyledProperty<double> heightProperty3 = Layoutable.HeightProperty;
		CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EParryBarController_002CMerostrap_002EImageHeight_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Layoutable.HeightProperty;
		CompiledBinding binding14 = compiledBindingExtension14.ProvideValue(context);
		context.ProvideTargetProperty = null;
		image4.Bind(heightProperty3, binding14);
		image4.HorizontalAlignment = HorizontalAlignment.Left;
		image4.Stretch = Stretch.Fill;
		context.PopParent();
		((ISupportInitialize)image3).EndInit();
		context.PopParent();
		((ISupportInitialize)border8).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(ParryBarOverlay P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
