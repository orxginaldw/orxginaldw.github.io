using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Input;
using Avalonia;
using Avalonia.Animation;
using Avalonia.Animation.Easings;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Controls.Presenters;
using Avalonia.Controls.Primitives;
using Avalonia.Controls.Shapes;
using Avalonia.Controls.Templates;
using Avalonia.Data;
using Avalonia.Data.Converters;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using Avalonia.Platform;
using Avalonia.Platform.Storage;
using Avalonia.Styling;
using Avalonia.Threading;
using Avalonia.VisualTree;
using CompiledAvaloniaXaml;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.Macros;
using Merostrap.Macros.Health;

namespace Merostrap.UI.Elements.Macros;

public class MacroWindow : Window
{
	private struct NativeRect
	{
		public int Left;

		public int Top;

		public int Right;

		public int Bottom;
	}

	[CompilerGenerated]
	private class XamlClosure_29
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroWindow> context = CreateContext(P_0);
			return new MacroCategoryIconConverter();
		}

		public static XamlIlContext.Context<MacroWindow> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroWindow> context = new XamlIlContext.Context<MacroWindow>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FMacros_002FMacroWindow_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Macros/MacroWindow.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (MacroWindow)service;
				}
			}
			return context;
		}

		public static object Build_2(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroWindow> context = CreateContext(P_0);
			return new MacroCategoryArtworkConverter();
		}

		public static object Build_3(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroWindow> context = CreateContext(P_0);
			context.IntermediateRoot = new Grid();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Grid grid = (Grid)obj;
			context.PushParent(grid);
			Avalonia.Controls.Controls children = grid.Children;
			ContentPresenter contentPresenter2;
			ContentPresenter contentPresenter = (contentPresenter2 = new ContentPresenter());
			((ISupportInitialize)contentPresenter).BeginInit();
			children.Add(contentPresenter);
			contentPresenter2.Name = "PART_ContentPresenter";
			object element = contentPresenter2;
			context.AvaloniaNameScope.Register("PART_ContentPresenter", element);
			XamlDynamicSetters._003C_003EXamlDynamicSetter_7(contentPresenter2, BindingPriority.Template, new TemplateBinding(ContentControl.ContentProperty).ProvideValue());
			contentPresenter2.Bind(ContentPresenter.ContentTemplateProperty, new TemplateBinding(ContentControl.ContentTemplateProperty).ProvideValue());
			contentPresenter2.SetValue(ContentPresenter.HorizontalContentAlignmentProperty, HorizontalAlignment.Stretch, BindingPriority.Template);
			contentPresenter2.SetValue(ContentPresenter.VerticalContentAlignmentProperty, VerticalAlignment.Stretch, BindingPriority.Template);
			((ISupportInitialize)contentPresenter2).EndInit();
			Avalonia.Controls.Controls children2 = grid.Children;
			StackPanel stackPanel2;
			StackPanel stackPanel = (stackPanel2 = new StackPanel());
			((ISupportInitialize)stackPanel).BeginInit();
			children2.Add(stackPanel);
			StackPanel stackPanel4;
			StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
			context.PushParent(stackPanel4);
			stackPanel4.SetValue(StackPanel.OrientationProperty, Orientation.Horizontal, BindingPriority.Template);
			stackPanel4.SetValue(Layoutable.HorizontalAlignmentProperty, HorizontalAlignment.Right, BindingPriority.Template);
			stackPanel4.SetValue(Layoutable.VerticalAlignmentProperty, VerticalAlignment.Center, BindingPriority.Template);
			stackPanel4.SetValue(Layoutable.MarginProperty, new Thickness(0.0, 0.0, 4.0, 0.0), BindingPriority.Template);
			stackPanel4.SetValue(StackPanel.SpacingProperty, 2.0, BindingPriority.Template);
			stackPanel4.Bind(Visual.IsVisibleProperty, new TemplateBinding(ButtonSpinner.ShowButtonSpinnerProperty).ProvideValue());
			Avalonia.Controls.Controls children3 = stackPanel4.Children;
			RepeatButton repeatButton2;
			RepeatButton repeatButton = (repeatButton2 = new RepeatButton());
			((ISupportInitialize)repeatButton).BeginInit();
			children3.Add(repeatButton);
			RepeatButton repeatButton4;
			RepeatButton repeatButton3 = (repeatButton4 = repeatButton2);
			context.PushParent(repeatButton4);
			RepeatButton repeatButton5 = repeatButton4;
			repeatButton5.Name = "PART_DecreaseButton";
			element = repeatButton5;
			context.AvaloniaNameScope.Register("PART_DecreaseButton", element);
			repeatButton5.SetValue(Layoutable.WidthProperty, 22.0, BindingPriority.Template);
			repeatButton5.SetValue(Layoutable.HeightProperty, 24.0, BindingPriority.Template);
			repeatButton5.SetValue(Layoutable.MinWidthProperty, 0.0, BindingPriority.Template);
			repeatButton5.SetValue(Layoutable.MinHeightProperty, 0.0, BindingPriority.Template);
			repeatButton5.SetValue(TemplatedControl.PaddingProperty, new Thickness(0.0, 0.0, 0.0, 0.0), BindingPriority.Template);
			repeatButton5.SetValue(AutomationProperties.NameProperty, "Decrease value", BindingPriority.Template);
			Lucide lucide2;
			Lucide lucide = (lucide2 = new Lucide());
			((ISupportInitialize)lucide).BeginInit();
			repeatButton5.Content = lucide;
			Lucide lucide4;
			Lucide lucide3 = (lucide4 = lucide2);
			context.PushParent(lucide4);
			Lucide lucide5 = lucide4;
			lucide5.SetValue(Lucide.IconProperty, LucideIconNames.Minus, BindingPriority.Template);
			lucide5.SetValue(Layoutable.WidthProperty, 12.0, BindingPriority.Template);
			lucide5.SetValue(Layoutable.HeightProperty, 12.0, BindingPriority.Template);
			StyledProperty<IBrush?> strokeBrushProperty = Lucide.StrokeBrushProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("MacroMuted");
			context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
			BindingBase binding = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			lucide5.Bind(strokeBrushProperty, binding);
			context.PopParent();
			((ISupportInitialize)lucide3).EndInit();
			context.PopParent();
			((ISupportInitialize)repeatButton3).EndInit();
			Avalonia.Controls.Controls children4 = stackPanel4.Children;
			RepeatButton repeatButton7;
			RepeatButton repeatButton6 = (repeatButton7 = new RepeatButton());
			((ISupportInitialize)repeatButton6).BeginInit();
			children4.Add(repeatButton6);
			RepeatButton repeatButton8 = (repeatButton4 = repeatButton7);
			context.PushParent(repeatButton4);
			RepeatButton repeatButton9 = repeatButton4;
			repeatButton9.Name = "PART_IncreaseButton";
			element = repeatButton9;
			context.AvaloniaNameScope.Register("PART_IncreaseButton", element);
			repeatButton9.SetValue(Layoutable.WidthProperty, 22.0, BindingPriority.Template);
			repeatButton9.SetValue(Layoutable.HeightProperty, 24.0, BindingPriority.Template);
			repeatButton9.SetValue(Layoutable.MinWidthProperty, 0.0, BindingPriority.Template);
			repeatButton9.SetValue(Layoutable.MinHeightProperty, 0.0, BindingPriority.Template);
			repeatButton9.SetValue(TemplatedControl.PaddingProperty, new Thickness(0.0, 0.0, 0.0, 0.0), BindingPriority.Template);
			repeatButton9.SetValue(AutomationProperties.NameProperty, "Increase value", BindingPriority.Template);
			Lucide lucide7;
			Lucide lucide6 = (lucide7 = new Lucide());
			((ISupportInitialize)lucide6).BeginInit();
			repeatButton9.Content = lucide6;
			Lucide lucide8 = (lucide4 = lucide7);
			context.PushParent(lucide4);
			Lucide lucide9 = lucide4;
			lucide9.SetValue(Lucide.IconProperty, LucideIconNames.Plus, BindingPriority.Template);
			lucide9.SetValue(Layoutable.WidthProperty, 12.0, BindingPriority.Template);
			lucide9.SetValue(Layoutable.HeightProperty, 12.0, BindingPriority.Template);
			StyledProperty<IBrush?> strokeBrushProperty2 = Lucide.StrokeBrushProperty;
			DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("MacroMuted");
			context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
			BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			lucide9.Bind(strokeBrushProperty2, binding2);
			context.PopParent();
			((ISupportInitialize)lucide8).EndInit();
			context.PopParent();
			((ISupportInitialize)repeatButton8).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_4(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroWindow> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Border border = (Border)obj;
			context.PushParent(border);
			border.Name = "MacNumberButton";
			object element = border;
			context.AvaloniaNameScope.Register("MacNumberButton", element);
			StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("MacroInput");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border.Bind(backgroundProperty, binding);
			border.SetValue(Border.CornerRadiusProperty, new CornerRadius(4.0, 4.0, 4.0, 4.0), BindingPriority.Template);
			ContentPresenter contentPresenter2;
			ContentPresenter contentPresenter = (contentPresenter2 = new ContentPresenter());
			((ISupportInitialize)contentPresenter).BeginInit();
			border.Child = contentPresenter;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_7(contentPresenter2, BindingPriority.Template, new TemplateBinding(ContentControl.ContentProperty).ProvideValue());
			contentPresenter2.SetValue(ContentPresenter.HorizontalContentAlignmentProperty, HorizontalAlignment.Center, BindingPriority.Template);
			contentPresenter2.SetValue(ContentPresenter.VerticalContentAlignmentProperty, VerticalAlignment.Center, BindingPriority.Template);
			((ISupportInitialize)contentPresenter2).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_5(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroWindow> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((StyledElement)obj).Name = "MacButtonSurface";
			object element = obj;
			context.AvaloniaNameScope.Register("MacButtonSurface", element);
			((AvaloniaObject)obj).Bind((AvaloniaProperty)Border.BackgroundProperty, new TemplateBinding(TemplatedControl.BackgroundProperty).ProvideValue());
			((AvaloniaObject)obj).Bind((AvaloniaProperty)Border.BorderBrushProperty, new TemplateBinding(TemplatedControl.BorderBrushProperty).ProvideValue());
			((AvaloniaObject)obj).Bind((AvaloniaProperty)Border.BorderThicknessProperty, new TemplateBinding(TemplatedControl.BorderThicknessProperty).ProvideValue());
			((AvaloniaObject)obj).Bind((AvaloniaProperty)Border.CornerRadiusProperty, new TemplateBinding(TemplatedControl.CornerRadiusProperty).ProvideValue());
			((AvaloniaObject)obj).Bind((AvaloniaProperty)Decorator.PaddingProperty, new TemplateBinding(TemplatedControl.PaddingProperty).ProvideValue());
			ContentPresenter contentPresenter2;
			ContentPresenter contentPresenter = (contentPresenter2 = new ContentPresenter());
			((ISupportInitialize)contentPresenter).BeginInit();
			((Decorator)obj).Child = contentPresenter;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_7(contentPresenter2, BindingPriority.Template, new TemplateBinding(ContentControl.ContentProperty).ProvideValue());
			contentPresenter2.Bind(ContentPresenter.ContentTemplateProperty, new TemplateBinding(ContentControl.ContentTemplateProperty).ProvideValue());
			contentPresenter2.Bind(ContentPresenter.HorizontalContentAlignmentProperty, new TemplateBinding(ContentControl.HorizontalContentAlignmentProperty).ProvideValue());
			contentPresenter2.SetValue(ContentPresenter.VerticalContentAlignmentProperty, VerticalAlignment.Center, BindingPriority.Template);
			contentPresenter2.SetValue(ContentPresenter.RecognizesAccessKeyProperty, value: true, BindingPriority.Template);
			((ISupportInitialize)contentPresenter2).EndInit();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_6(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroWindow> context = CreateContext(P_0);
			context.IntermediateRoot = new Grid();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Grid grid = (Grid)obj;
			context.PushParent(grid);
			grid.SetValue(Panel.BackgroundProperty, new ImmutableSolidColorBrush(16777215u), BindingPriority.Template);
			grid.SetValue(Layoutable.HeightProperty, 30.0, BindingPriority.Template);
			grid.SetValue(Layoutable.WidthProperty, 40.0, BindingPriority.Template);
			Avalonia.Controls.Controls children = grid.Children;
			Border border2;
			Border border = (border2 = new Border());
			((ISupportInitialize)border).BeginInit();
			children.Add(border);
			Border border4;
			Border border3 = (border4 = border2);
			context.PushParent(border4);
			Border border5 = border4;
			border5.Name = "MacSwitchTrack";
			object element = border5;
			context.AvaloniaNameScope.Register("MacSwitchTrack", element);
			border5.SetValue(Layoutable.HeightProperty, 22.0, BindingPriority.Template);
			border5.SetValue(Border.CornerRadiusProperty, new CornerRadius(11.0, 11.0, 11.0, 11.0), BindingPriority.Template);
			StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("MacroBorder");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border5.Bind(backgroundProperty, binding);
			context.PopParent();
			((ISupportInitialize)border3).EndInit();
			Avalonia.Controls.Controls children2 = grid.Children;
			Canvas canvas2;
			Canvas canvas = (canvas2 = new Canvas());
			((ISupportInitialize)canvas).BeginInit();
			children2.Add(canvas);
			canvas2.Name = "PART_SwitchKnob";
			element = canvas2;
			context.AvaloniaNameScope.Register("PART_SwitchKnob", element);
			canvas2.SetValue(Layoutable.WidthProperty, 20.0, BindingPriority.Template);
			canvas2.SetValue(Layoutable.HeightProperty, 20.0, BindingPriority.Template);
			canvas2.SetValue(Layoutable.HorizontalAlignmentProperty, HorizontalAlignment.Left, BindingPriority.Template);
			canvas2.SetValue(Visual.IsVisibleProperty, value: false, BindingPriority.Template);
			Avalonia.Controls.Controls children3 = canvas2.Children;
			Grid grid3;
			Grid grid2 = (grid3 = new Grid());
			((ISupportInitialize)grid2).BeginInit();
			children3.Add(grid2);
			grid3.Name = "PART_MovingKnobs";
			element = grid3;
			context.AvaloniaNameScope.Register("PART_MovingKnobs", element);
			grid3.SetValue(Layoutable.WidthProperty, 20.0, BindingPriority.Template);
			grid3.SetValue(Layoutable.HeightProperty, 20.0, BindingPriority.Template);
			((ISupportInitialize)grid3).EndInit();
			((ISupportInitialize)canvas2).EndInit();
			Avalonia.Controls.Controls children4 = grid.Children;
			Border border7;
			Border border6 = (border7 = new Border());
			((ISupportInitialize)border6).BeginInit();
			children4.Add(border6);
			Border border8 = (border4 = border7);
			context.PushParent(border4);
			Border border9 = border4;
			border9.Name = "MacSwitchThumb";
			element = border9;
			context.AvaloniaNameScope.Register("MacSwitchThumb", element);
			border9.SetValue(Visual.RenderTransformProperty, (ITransform)new TransformConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "translate(0px, 0px)"), BindingPriority.Template);
			border9.SetValue(Layoutable.WidthProperty, 18.0, BindingPriority.Template);
			border9.SetValue(Layoutable.HeightProperty, 18.0, BindingPriority.Template);
			border9.SetValue(Border.CornerRadiusProperty, new CornerRadius(9.0, 9.0, 9.0, 9.0), BindingPriority.Template);
			border9.SetValue(Border.BackgroundProperty, new ImmutableSolidColorBrush(4294309367u), BindingPriority.Template);
			border9.SetValue(Layoutable.HorizontalAlignmentProperty, HorizontalAlignment.Left, BindingPriority.Template);
			border9.SetValue(Layoutable.VerticalAlignmentProperty, VerticalAlignment.Center, BindingPriority.Template);
			border9.SetValue(Layoutable.MarginProperty, new Thickness(3.0, 0.0, 0.0, 0.0), BindingPriority.Template);
			StyledProperty<Transitions?> transitionsProperty = Animatable.TransitionsProperty;
			Transitions transitions = new Transitions();
			TransformOperationsTransition transformOperationsTransition = new TransformOperationsTransition();
			transformOperationsTransition.Property = Visual.RenderTransformProperty;
			transformOperationsTransition.Duration = TimeSpan.FromTicks(2000000L);
			transformOperationsTransition.Easing = Easing.Parse("CubicEaseOut");
			transitions.Add(transformOperationsTransition);
			border9.SetValue(transitionsProperty, transitions, BindingPriority.Template);
			context.PopParent();
			((ISupportInitialize)border8).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_7(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroWindow> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((AvaloniaObject)obj).Bind((AvaloniaProperty)Border.BackgroundProperty, new TemplateBinding(TemplatedControl.BackgroundProperty).ProvideValue());
			((AvaloniaObject)obj).SetValue(Border.CornerRadiusProperty, new CornerRadius(5.0, 5.0, 5.0, 5.0), BindingPriority.Template);
			ContentPresenter contentPresenter2;
			ContentPresenter contentPresenter = (contentPresenter2 = new ContentPresenter());
			((ISupportInitialize)contentPresenter).BeginInit();
			((Decorator)obj).Child = contentPresenter;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_7(contentPresenter2, BindingPriority.Template, new TemplateBinding(ContentControl.ContentProperty).ProvideValue());
			contentPresenter2.SetValue(ContentPresenter.HorizontalContentAlignmentProperty, HorizontalAlignment.Stretch, BindingPriority.Template);
			contentPresenter2.SetValue(ContentPresenter.VerticalContentAlignmentProperty, VerticalAlignment.Center, BindingPriority.Template);
			((ISupportInitialize)contentPresenter2).EndInit();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_8(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroWindow> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((AvaloniaObject)obj).Bind((AvaloniaProperty)Border.BackgroundProperty, new TemplateBinding(TemplatedControl.BackgroundProperty).ProvideValue());
			((AvaloniaObject)obj).Bind((AvaloniaProperty)Border.BorderBrushProperty, new TemplateBinding(TemplatedControl.BorderBrushProperty).ProvideValue());
			((AvaloniaObject)obj).Bind((AvaloniaProperty)Border.BorderThicknessProperty, new TemplateBinding(TemplatedControl.BorderThicknessProperty).ProvideValue());
			((AvaloniaObject)obj).Bind((AvaloniaProperty)Border.CornerRadiusProperty, new TemplateBinding(TemplatedControl.CornerRadiusProperty).ProvideValue());
			((AvaloniaObject)obj).Bind((AvaloniaProperty)Decorator.PaddingProperty, new TemplateBinding(TemplatedControl.PaddingProperty).ProvideValue());
			ContentPresenter contentPresenter2;
			ContentPresenter contentPresenter = (contentPresenter2 = new ContentPresenter());
			((ISupportInitialize)contentPresenter).BeginInit();
			((Decorator)obj).Child = contentPresenter;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_7(contentPresenter2, BindingPriority.Template, new TemplateBinding(ContentControl.ContentProperty).ProvideValue());
			contentPresenter2.Bind(ContentPresenter.ContentTemplateProperty, new TemplateBinding(ContentControl.ContentTemplateProperty).ProvideValue());
			contentPresenter2.SetValue(Layoutable.VerticalAlignmentProperty, VerticalAlignment.Center, BindingPriority.Template);
			((ISupportInitialize)contentPresenter2).EndInit();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_9(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroWindow> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((AvaloniaObject)obj).SetValue(Border.BackgroundProperty, (IBrush)new ImmutableSolidColorBrush(16777215u), BindingPriority.Template);
			ContentPresenter contentPresenter2;
			ContentPresenter contentPresenter = (contentPresenter2 = new ContentPresenter());
			((ISupportInitialize)contentPresenter).BeginInit();
			((Decorator)obj).Child = contentPresenter;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_7(contentPresenter2, BindingPriority.Template, new TemplateBinding(ContentControl.ContentProperty).ProvideValue());
			contentPresenter2.SetValue(ContentPresenter.HorizontalContentAlignmentProperty, HorizontalAlignment.Center, BindingPriority.Template);
			contentPresenter2.SetValue(ContentPresenter.VerticalContentAlignmentProperty, VerticalAlignment.Center, BindingPriority.Template);
			((ISupportInitialize)contentPresenter2).EndInit();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_10(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroWindow> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Border border = (Border)obj;
			context.PushParent(border);
			border.SetValue(Border.BackgroundProperty, new ImmutableSolidColorBrush(16777215u), BindingPriority.Template);
			border.Bind(Decorator.PaddingProperty, new TemplateBinding(TemplatedControl.PaddingProperty).ProvideValue());
			ScrollViewer scrollViewer2;
			ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
			((ISupportInitialize)scrollViewer).BeginInit();
			border.Child = scrollViewer;
			ScrollViewer scrollViewer4;
			ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
			context.PushParent(scrollViewer4);
			scrollViewer4.Name = "PART_ScrollViewer";
			object element = scrollViewer4;
			context.AvaloniaNameScope.Register("PART_ScrollViewer", element);
			scrollViewer4.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Hidden, BindingPriority.Template);
			scrollViewer4.SetValue(ScrollViewer.VerticalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled, BindingPriority.Template);
			Panel panel2;
			Panel panel = (panel2 = new Panel());
			((ISupportInitialize)panel).BeginInit();
			scrollViewer4.Content = panel;
			Panel panel4;
			Panel panel3 = (panel4 = panel2);
			context.PushParent(panel4);
			Avalonia.Controls.Controls children = panel4.Children;
			TextBlock textBlock2;
			TextBlock textBlock = (textBlock2 = new TextBlock());
			((ISupportInitialize)textBlock).BeginInit();
			children.Add(textBlock);
			TextBlock textBlock4;
			TextBlock textBlock3 = (textBlock4 = textBlock2);
			context.PushParent(textBlock4);
			textBlock4.Bind(TextBlock.TextProperty, new TemplateBinding(TextBox.PlaceholderTextProperty).ProvideValue());
			StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("MacroMuted");
			context.ProvideTargetProperty = TextBlock.ForegroundProperty;
			BindingBase binding = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock4.Bind(foregroundProperty, binding);
			textBlock4.SetValue(Layoutable.VerticalAlignmentProperty, VerticalAlignment.Center, BindingPriority.Template);
			StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().TemplatedParent().Property(TextBox.TextProperty, PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor).Build())
			{
				Converter = StringConverters.IsNullOrEmpty
			};
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding2 = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock4.Bind(isVisibleProperty, binding2);
			context.PopParent();
			((ISupportInitialize)textBlock3).EndInit();
			Avalonia.Controls.Controls children2 = panel4.Children;
			TextPresenter textPresenter2;
			TextPresenter textPresenter = (textPresenter2 = new TextPresenter());
			((ISupportInitialize)textPresenter).BeginInit();
			children2.Add(textPresenter);
			textPresenter2.Name = "PART_TextPresenter";
			element = textPresenter2;
			context.AvaloniaNameScope.Register("PART_TextPresenter", element);
			textPresenter2.Bind(TextPresenter.TextProperty, new TemplateBinding(TextBox.TextProperty)
			{
				Mode = BindingMode.TwoWay
			}.ProvideValue());
			textPresenter2.Bind(TextPresenter.CaretIndexProperty, new TemplateBinding(TextBox.CaretIndexProperty).ProvideValue());
			textPresenter2.Bind(TextPresenter.SelectionStartProperty, new TemplateBinding(TextBox.SelectionStartProperty).ProvideValue());
			textPresenter2.Bind(TextPresenter.SelectionEndProperty, new TemplateBinding(TextBox.SelectionEndProperty).ProvideValue());
			textPresenter2.Bind(TextPresenter.SelectionBrushProperty, new TemplateBinding(TextBox.SelectionBrushProperty).ProvideValue());
			textPresenter2.Bind(TextPresenter.SelectionForegroundBrushProperty, new TemplateBinding(TextBox.SelectionForegroundBrushProperty).ProvideValue());
			textPresenter2.Bind(TextPresenter.CaretBrushProperty, new TemplateBinding(TextBox.CaretBrushProperty).ProvideValue());
			textPresenter2.SetValue(TextPresenter.TextWrappingProperty, TextWrapping.NoWrap, BindingPriority.Template);
			textPresenter2.SetValue(Layoutable.VerticalAlignmentProperty, VerticalAlignment.Center, BindingPriority.Template);
			((ISupportInitialize)textPresenter2).EndInit();
			context.PopParent();
			((ISupportInitialize)panel3).EndInit();
			context.PopParent();
			((ISupportInitialize)scrollViewer3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_11(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroWindow> context = CreateContext(P_0);
			context.IntermediateRoot = new Grid();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Grid grid = (Grid)obj;
			context.PushParent(grid);
			Grid grid2 = grid;
			Avalonia.Controls.Controls children = grid2.Children;
			Border border2;
			Border border = (border2 = new Border());
			((ISupportInitialize)border).BeginInit();
			children.Add(border);
			Border border4;
			Border border3 = (border4 = border2);
			context.PushParent(border4);
			Border border5 = border4;
			border5.Name = "MacDropdownSurface";
			object element = border5;
			context.AvaloniaNameScope.Register("MacDropdownSurface", element);
			border5.Bind(Border.BackgroundProperty, new TemplateBinding(TemplatedControl.BackgroundProperty).ProvideValue());
			border5.Bind(Border.BorderBrushProperty, new TemplateBinding(TemplatedControl.BorderBrushProperty).ProvideValue());
			border5.Bind(Border.BorderThicknessProperty, new TemplateBinding(TemplatedControl.BorderThicknessProperty).ProvideValue());
			border5.Bind(Decorator.PaddingProperty, new TemplateBinding(TemplatedControl.PaddingProperty).ProvideValue());
			Grid grid4;
			Grid grid3 = (grid4 = new Grid());
			((ISupportInitialize)grid3).BeginInit();
			border5.Child = grid3;
			Grid grid5 = (grid = grid4);
			context.PushParent(grid);
			Grid grid6 = grid;
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 2;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(24.0, GridUnitType.Pixel)));
			grid6.ColumnDefinitions = columnDefinitions;
			Avalonia.Controls.Controls children2 = grid6.Children;
			ContentPresenter contentPresenter2;
			ContentPresenter contentPresenter = (contentPresenter2 = new ContentPresenter());
			((ISupportInitialize)contentPresenter).BeginInit();
			children2.Add(contentPresenter);
			XamlDynamicSetters._003C_003EXamlDynamicSetter_7(contentPresenter2, BindingPriority.Template, new TemplateBinding(ComboBox.SelectionBoxItemProperty).ProvideValue());
			contentPresenter2.Bind(ContentPresenter.ContentTemplateProperty, new TemplateBinding(ComboBox.SelectionBoxItemTemplateProperty).ProvideValue());
			contentPresenter2.SetValue(ContentPresenter.VerticalContentAlignmentProperty, VerticalAlignment.Center, BindingPriority.Template);
			contentPresenter2.SetValue(ContentPresenter.HorizontalContentAlignmentProperty, HorizontalAlignment.Left, BindingPriority.Template);
			((ISupportInitialize)contentPresenter2).EndInit();
			Avalonia.Controls.Controls children3 = grid6.Children;
			Lucide lucide2;
			Lucide lucide = (lucide2 = new Lucide());
			((ISupportInitialize)lucide).BeginInit();
			children3.Add(lucide);
			Lucide lucide4;
			Lucide lucide3 = (lucide4 = lucide2);
			context.PushParent(lucide4);
			lucide4.Name = "MacDropdownArrow";
			element = lucide4;
			context.AvaloniaNameScope.Register("MacDropdownArrow", element);
			lucide4.SetValue(Grid.ColumnProperty, 1, BindingPriority.Template);
			lucide4.SetValue(Lucide.IconProperty, LucideIconNames.ChevronDown, BindingPriority.Template);
			lucide4.SetValue(Layoutable.WidthProperty, 13.0, BindingPriority.Template);
			lucide4.SetValue(Layoutable.HeightProperty, 13.0, BindingPriority.Template);
			StyledProperty<IBrush?> strokeBrushProperty = Lucide.StrokeBrushProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("MacroMuted");
			context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
			BindingBase binding = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			lucide4.Bind(strokeBrushProperty, binding);
			lucide4.SetValue(Layoutable.VerticalAlignmentProperty, VerticalAlignment.Center, BindingPriority.Template);
			lucide4.SetValue(Layoutable.HorizontalAlignmentProperty, HorizontalAlignment.Right, BindingPriority.Template);
			context.PopParent();
			((ISupportInitialize)lucide3).EndInit();
			context.PopParent();
			((ISupportInitialize)grid5).EndInit();
			context.PopParent();
			((ISupportInitialize)border3).EndInit();
			Avalonia.Controls.Controls children4 = grid2.Children;
			Popup popup2;
			Popup popup = (popup2 = new Popup());
			((ISupportInitialize)popup).BeginInit();
			children4.Add(popup);
			Popup popup4;
			Popup popup3 = (popup4 = popup2);
			context.PushParent(popup4);
			popup4.Closed += context.RootObject.DropdownClosed;
			popup4.Opened += context.RootObject.DropdownOpened;
			popup4.Name = "PART_Popup";
			element = popup4;
			context.AvaloniaNameScope.Register("PART_Popup", element);
			popup4.Bind(Popup.IsOpenProperty, new TemplateBinding(ComboBox.IsDropDownOpenProperty)
			{
				Mode = BindingMode.TwoWay
			}.ProvideValue());
			ResolveByNameExtension resolveByNameExtension = new ResolveByNameExtension("MacDropdownSurface");
			context.ProvideTargetProperty = Popup.PlacementTargetProperty;
			object? obj2 = resolveByNameExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_12(popup4, BindingPriority.Template, obj2);
			popup4.SetValue(Popup.PlacementProperty, PlacementMode.Bottom, BindingPriority.Template);
			popup4.SetValue(Popup.VerticalOffsetProperty, 4.0, BindingPriority.Template);
			popup4.SetValue(Popup.IsLightDismissEnabledProperty, value: true, BindingPriority.Template);
			StyledProperty<double> minWidthProperty = Layoutable.MinWidthProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().TemplatedParent().Property(Visual.BoundsProperty, PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor).Property(XamlIlHelpers.Avalonia_002ERect_002CAvalonia_002EBase_002EWidth_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)
				.Build());
			context.ProvideTargetProperty = Layoutable.MinWidthProperty;
			CompiledBinding binding2 = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			popup4.Bind(minWidthProperty, binding2);
			popup4.Bind(Layoutable.MaxHeightProperty, new TemplateBinding(ComboBox.MaxDropDownHeightProperty).ProvideValue());
			popup4.SetValue(Popup.WindowManagerAddShadowHintProperty, value: false, BindingPriority.Template);
			Border border7;
			Border border6 = (border7 = new Border());
			((ISupportInitialize)border6).BeginInit();
			popup4.Child = border6;
			Border border8 = (border4 = border7);
			context.PushParent(border4);
			Border border9 = border4;
			border9.Name = "MacDropdownMenu";
			element = border9;
			context.AvaloniaNameScope.Register("MacDropdownMenu", element);
			StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("MacroTextField");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding3 = dynamicResourceExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border9.Bind(backgroundProperty, binding3);
			StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
			DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("MacroBorder");
			context.ProvideTargetProperty = Border.BorderBrushProperty;
			BindingBase binding4 = dynamicResourceExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border9.Bind(borderBrushProperty, binding4);
			border9.SetValue(Border.BorderThicknessProperty, new Thickness(1.0, 1.0, 1.0, 1.0), BindingPriority.Template);
			border9.SetValue(Decorator.PaddingProperty, new Thickness(4.0, 4.0, 4.0, 4.0), BindingPriority.Template);
			ScrollViewer scrollViewer2;
			ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
			((ISupportInitialize)scrollViewer).BeginInit();
			border9.Child = scrollViewer;
			scrollViewer2.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled, BindingPriority.Template);
			scrollViewer2.SetValue(ScrollViewer.VerticalScrollBarVisibilityProperty, ScrollBarVisibility.Auto, BindingPriority.Template);
			ItemsPresenter itemsPresenter2;
			ItemsPresenter itemsPresenter = (itemsPresenter2 = new ItemsPresenter());
			((ISupportInitialize)itemsPresenter).BeginInit();
			scrollViewer2.Content = itemsPresenter;
			itemsPresenter2.Name = "PART_ItemsPresenter";
			element = itemsPresenter2;
			context.AvaloniaNameScope.Register("PART_ItemsPresenter", element);
			itemsPresenter2.Bind(ItemsPresenter.ItemsPanelProperty, new TemplateBinding(ItemsControl.ItemsPanelProperty).ProvideValue());
			((ISupportInitialize)itemsPresenter2).EndInit();
			((ISupportInitialize)scrollViewer2).EndInit();
			context.PopParent();
			((ISupportInitialize)border8).EndInit();
			context.PopParent();
			((ISupportInitialize)popup3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_12(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroWindow> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Border border = (Border)obj;
			context.PushParent(border);
			border.Name = "MacDropdownItem";
			object element = border;
			context.AvaloniaNameScope.Register("MacDropdownItem", element);
			border.Bind(Border.BackgroundProperty, new TemplateBinding(TemplatedControl.BackgroundProperty).ProvideValue());
			border.Bind(Decorator.PaddingProperty, new TemplateBinding(TemplatedControl.PaddingProperty).ProvideValue());
			Grid grid2;
			Grid grid = (grid2 = new Grid());
			((ISupportInitialize)grid).BeginInit();
			border.Child = grid;
			Grid grid4;
			Grid grid3 = (grid4 = grid2);
			context.PushParent(grid4);
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 2;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(22.0, GridUnitType.Pixel)));
			grid4.ColumnDefinitions = columnDefinitions;
			Avalonia.Controls.Controls children = grid4.Children;
			ContentPresenter contentPresenter2;
			ContentPresenter contentPresenter = (contentPresenter2 = new ContentPresenter());
			((ISupportInitialize)contentPresenter).BeginInit();
			children.Add(contentPresenter);
			XamlDynamicSetters._003C_003EXamlDynamicSetter_7(contentPresenter2, BindingPriority.Template, new TemplateBinding(ContentControl.ContentProperty).ProvideValue());
			contentPresenter2.Bind(ContentPresenter.ContentTemplateProperty, new TemplateBinding(ContentControl.ContentTemplateProperty).ProvideValue());
			contentPresenter2.SetValue(Layoutable.VerticalAlignmentProperty, VerticalAlignment.Center, BindingPriority.Template);
			((ISupportInitialize)contentPresenter2).EndInit();
			Avalonia.Controls.Controls children2 = grid4.Children;
			Lucide lucide2;
			Lucide lucide = (lucide2 = new Lucide());
			((ISupportInitialize)lucide).BeginInit();
			children2.Add(lucide);
			Lucide lucide4;
			Lucide lucide3 = (lucide4 = lucide2);
			context.PushParent(lucide4);
			lucide4.Name = "SelectedMark";
			element = lucide4;
			context.AvaloniaNameScope.Register("SelectedMark", element);
			lucide4.SetValue(Grid.ColumnProperty, 1, BindingPriority.Template);
			lucide4.SetValue(Lucide.IconProperty, LucideIconNames.Check, BindingPriority.Template);
			lucide4.SetValue(Layoutable.WidthProperty, 13.0, BindingPriority.Template);
			lucide4.SetValue(Layoutable.HeightProperty, 13.0, BindingPriority.Template);
			StyledProperty<IBrush?> strokeBrushProperty = Lucide.StrokeBrushProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("MacroAccent");
			context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
			BindingBase binding = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			lucide4.Bind(strokeBrushProperty, binding);
			lucide4.SetValue(Visual.IsVisibleProperty, value: false, BindingPriority.Template);
			lucide4.SetValue(Layoutable.VerticalAlignmentProperty, VerticalAlignment.Center, BindingPriority.Template);
			context.PopParent();
			((ISupportInitialize)lucide3).EndInit();
			context.PopParent();
			((ISupportInitialize)grid3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public unsafe static object Build_13(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroWindow> context = CreateContext(P_0);
			context.IntermediateRoot = new Grid();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Grid grid = (Grid)obj;
			context.PushParent(grid);
			grid.SetValue(Panel.BackgroundProperty, new ImmutableSolidColorBrush(16777215u), BindingPriority.Template);
			grid.SetValue(Layoutable.MarginProperty, new Thickness(0.0, 6.0, 0.0, 6.0), BindingPriority.Template);
			Avalonia.Controls.Controls children = grid.Children;
			Track track2;
			Track track = (track2 = new Track());
			((ISupportInitialize)track).BeginInit();
			children.Add(track);
			Track track4;
			Track track3 = (track4 = track2);
			context.PushParent(track4);
			track4.Name = "PART_Track";
			object element = track4;
			context.AvaloniaNameScope.Register("PART_Track", element);
			track4.Bind(Track.MinimumProperty, new TemplateBinding(RangeBase.MinimumProperty).ProvideValue());
			track4.Bind(Track.MaximumProperty, new TemplateBinding(RangeBase.MaximumProperty).ProvideValue());
			track4.Bind(Track.ValueProperty, new TemplateBinding(RangeBase.ValueProperty)
			{
				Mode = BindingMode.TwoWay
			}.ProvideValue());
			track4.Bind(Track.ViewportSizeProperty, new TemplateBinding(ScrollBar.ViewportSizeProperty).ProvideValue());
			track4.SetValue(Track.OrientationProperty, Orientation.Vertical, BindingPriority.Template);
			track4.SetValue(Track.IsDirectionReversedProperty, value: true, BindingPriority.Template);
			StyledProperty<Button?> decreaseButtonProperty = Track.DecreaseButtonProperty;
			RepeatButton repeatButton2;
			RepeatButton repeatButton = (repeatButton2 = new RepeatButton());
			((ISupportInitialize)repeatButton).BeginInit();
			track4.SetValue(decreaseButtonProperty, repeatButton, BindingPriority.Template);
			repeatButton2.SetValue(InputElement.FocusableProperty, value: false, BindingPriority.Template);
			repeatButton2.SetValue(TemplatedControl.BackgroundProperty, new ImmutableSolidColorBrush(16777215u), BindingPriority.Template);
			repeatButton2.SetValue(TemplatedControl.TemplateProperty, new ControlTemplate
			{
				Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&Build_14), context)
			}, BindingPriority.Template);
			((ISupportInitialize)repeatButton2).EndInit();
			StyledProperty<Thumb?> thumbProperty = Track.ThumbProperty;
			Thumb thumb2;
			Thumb thumb = (thumb2 = new Thumb());
			((ISupportInitialize)thumb).BeginInit();
			track4.SetValue(thumbProperty, thumb, BindingPriority.Template);
			Thumb thumb4;
			Thumb thumb3 = (thumb4 = thumb2);
			context.PushParent(thumb4);
			thumb4.SetValue(Layoutable.MinHeightProperty, 24.0, BindingPriority.Template);
			StyledProperty<IControlTemplate?> templateProperty = TemplatedControl.TemplateProperty;
			ControlTemplate controlTemplate;
			ControlTemplate value = (controlTemplate = new ControlTemplate());
			context.PushParent(controlTemplate);
			controlTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&Build_15), context);
			context.PopParent();
			thumb4.SetValue(templateProperty, value, BindingPriority.Template);
			context.PopParent();
			((ISupportInitialize)thumb3).EndInit();
			StyledProperty<Button?> increaseButtonProperty = Track.IncreaseButtonProperty;
			RepeatButton repeatButton4;
			RepeatButton repeatButton3 = (repeatButton4 = new RepeatButton());
			((ISupportInitialize)repeatButton3).BeginInit();
			track4.SetValue(increaseButtonProperty, repeatButton3, BindingPriority.Template);
			repeatButton4.SetValue(InputElement.FocusableProperty, value: false, BindingPriority.Template);
			repeatButton4.SetValue(TemplatedControl.BackgroundProperty, new ImmutableSolidColorBrush(16777215u), BindingPriority.Template);
			repeatButton4.SetValue(TemplatedControl.TemplateProperty, new ControlTemplate
			{
				Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&Build_16), context)
			}, BindingPriority.Template);
			((ISupportInitialize)repeatButton4).EndInit();
			context.PopParent();
			((ISupportInitialize)track3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_14(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroWindow> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((AvaloniaObject)obj).SetValue(Border.BackgroundProperty, (IBrush)new ImmutableSolidColorBrush(16777215u), BindingPriority.Template);
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_15(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroWindow> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Border border = (Border)obj;
			context.PushParent(border);
			border.Name = "CleanScrollThumb";
			object element = border;
			context.AvaloniaNameScope.Register("CleanScrollThumb", element);
			border.SetValue(Layoutable.WidthProperty, 4.0, BindingPriority.Template);
			border.SetValue(Layoutable.HorizontalAlignmentProperty, HorizontalAlignment.Center, BindingPriority.Template);
			StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("MacroSubtle");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border.Bind(backgroundProperty, binding);
			border.SetValue(Border.CornerRadiusProperty, new CornerRadius(2.0, 2.0, 2.0, 2.0), BindingPriority.Template);
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_16(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroWindow> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((AvaloniaObject)obj).SetValue(Border.BackgroundProperty, (IBrush)new ImmutableSolidColorBrush(16777215u), BindingPriority.Template);
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_17(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroWindow> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Border border = (Border)obj;
			context.PushParent(border);
			border.Name = "MacroTickTarget";
			object element = border;
			context.AvaloniaNameScope.Register("MacroTickTarget", element);
			border.SetValue(Layoutable.WidthProperty, 18.0, BindingPriority.Template);
			border.SetValue(Layoutable.HeightProperty, 18.0, BindingPriority.Template);
			border.SetValue(Border.CornerRadiusProperty, new CornerRadius(3.0, 3.0, 3.0, 3.0), BindingPriority.Template);
			StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("MacroBorder");
			context.ProvideTargetProperty = Border.BorderBrushProperty;
			BindingBase binding = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border.Bind(borderBrushProperty, binding);
			border.SetValue(Border.BorderThicknessProperty, new Thickness(1.0, 1.0, 1.0, 1.0), BindingPriority.Template);
			border.SetValue(Border.BackgroundProperty, new ImmutableSolidColorBrush(16777215u), BindingPriority.Template);
			Lucide lucide2;
			Lucide lucide = (lucide2 = new Lucide());
			((ISupportInitialize)lucide).BeginInit();
			border.Child = lucide;
			Lucide lucide4;
			Lucide lucide3 = (lucide4 = lucide2);
			context.PushParent(lucide4);
			lucide4.Name = "MacroCheckMark";
			element = lucide4;
			context.AvaloniaNameScope.Register("MacroCheckMark", element);
			lucide4.SetValue(Lucide.IconProperty, LucideIconNames.Check, BindingPriority.Template);
			lucide4.SetValue(Layoutable.WidthProperty, 14.0, BindingPriority.Template);
			lucide4.SetValue(Layoutable.HeightProperty, 14.0, BindingPriority.Template);
			StyledProperty<IBrush?> strokeBrushProperty = Lucide.StrokeBrushProperty;
			DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("MacroAccent");
			context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
			BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			lucide4.Bind(strokeBrushProperty, binding2);
			lucide4.SetValue(Visual.OpacityProperty, 0.0, BindingPriority.Template);
			context.PopParent();
			((ISupportInitialize)lucide3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_18(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroWindow> context = CreateContext(P_0);
			context.IntermediateRoot = new Grid();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Grid grid = (Grid)obj;
			context.PushParent(grid);
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 2;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(24.0, GridUnitType.Pixel)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid.ColumnDefinitions = columnDefinitions;
			Avalonia.Controls.Controls children = grid.Children;
			Border border2;
			Border border = (border2 = new Border());
			((ISupportInitialize)border).BeginInit();
			children.Add(border);
			Border border4;
			Border border3 = (border4 = border2);
			context.PushParent(border4);
			border4.Width = 20.0;
			border4.Height = 20.0;
			border4.VerticalAlignment = VerticalAlignment.Center;
			border4.HorizontalAlignment = HorizontalAlignment.Left;
			StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("MacroMuted");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border4.Bind(backgroundProperty, binding);
			StyledProperty<IBrush?> opacityMaskProperty = Visual.OpacityMaskProperty;
			CompiledBindingExtension compiledBindingExtension2;
			CompiledBindingExtension compiledBindingExtension = (compiledBindingExtension2 = new CompiledBindingExtension());
			context.PushParent(compiledBindingExtension2);
			CompiledBindingExtension compiledBindingExtension3 = compiledBindingExtension2;
			StaticResourceExtension staticResourceExtension = new StaticResourceExtension("CategoryArtwork");
			context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EData_002ECompiledBinding_002CAvalonia_002EBase_002EConverter_0021Property();
			object? obj2 = staticResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			compiledBindingExtension3.Converter = (IValueConverter)obj2;
			context.PopParent();
			context.ProvideTargetProperty = Visual.OpacityMaskProperty;
			CompiledBinding binding2 = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border4.Bind(opacityMaskProperty, binding2);
			StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension4 = (compiledBindingExtension2 = new CompiledBindingExtension());
			context.PushParent(compiledBindingExtension2);
			CompiledBindingExtension compiledBindingExtension5 = compiledBindingExtension2;
			StaticResourceExtension staticResourceExtension2 = new StaticResourceExtension("CategoryArtwork");
			context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EData_002ECompiledBinding_002CAvalonia_002EBase_002EConverter_0021Property();
			object? obj3 = staticResourceExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			compiledBindingExtension5.Converter = (IValueConverter)obj3;
			compiledBindingExtension5.ConverterParameter = "visible";
			context.PopParent();
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding3 = compiledBindingExtension4.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border4.Bind(isVisibleProperty, binding3);
			context.PopParent();
			((ISupportInitialize)border3).EndInit();
			Avalonia.Controls.Controls children2 = grid.Children;
			Lucide lucide2;
			Lucide lucide = (lucide2 = new Lucide());
			((ISupportInitialize)lucide).BeginInit();
			children2.Add(lucide);
			Lucide lucide4;
			Lucide lucide3 = (lucide4 = lucide2);
			context.PushParent(lucide4);
			StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension6 = (compiledBindingExtension2 = new CompiledBindingExtension());
			context.PushParent(compiledBindingExtension2);
			CompiledBindingExtension compiledBindingExtension7 = compiledBindingExtension2;
			StaticResourceExtension staticResourceExtension3 = new StaticResourceExtension("CategoryArtwork");
			context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EData_002ECompiledBinding_002CAvalonia_002EBase_002EConverter_0021Property();
			object? obj4 = staticResourceExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			compiledBindingExtension7.Converter = (IValueConverter)obj4;
			compiledBindingExtension7.ConverterParameter = "fallback";
			context.PopParent();
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding4 = compiledBindingExtension6.ProvideValue(context);
			context.ProvideTargetProperty = null;
			lucide4.Bind(isVisibleProperty2, binding4);
			StyledProperty<LucideIconNames> iconProperty = Lucide.IconProperty;
			CompiledBindingExtension compiledBindingExtension8 = (compiledBindingExtension2 = new CompiledBindingExtension());
			context.PushParent(compiledBindingExtension2);
			CompiledBindingExtension compiledBindingExtension9 = compiledBindingExtension2;
			StaticResourceExtension staticResourceExtension4 = new StaticResourceExtension("CategoryIcon");
			context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EData_002ECompiledBinding_002CAvalonia_002EBase_002EConverter_0021Property();
			object? obj5 = staticResourceExtension4.ProvideValue(context);
			context.ProvideTargetProperty = null;
			compiledBindingExtension9.Converter = (IValueConverter)obj5;
			context.PopParent();
			context.ProvideTargetProperty = Lucide.IconProperty;
			CompiledBinding binding5 = compiledBindingExtension8.ProvideValue(context);
			context.ProvideTargetProperty = null;
			lucide4.Bind(iconProperty, binding5);
			lucide4.Width = 15.0;
			lucide4.Height = 15.0;
			StyledProperty<IBrush?> strokeBrushProperty = Lucide.StrokeBrushProperty;
			DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("MacroMuted");
			context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
			BindingBase binding6 = dynamicResourceExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			lucide4.Bind(strokeBrushProperty, binding6);
			lucide4.VerticalAlignment = VerticalAlignment.Center;
			context.PopParent();
			((ISupportInitialize)lucide3).EndInit();
			Avalonia.Controls.Controls children3 = grid.Children;
			TextBlock textBlock2;
			TextBlock textBlock = (textBlock2 = new TextBlock());
			((ISupportInitialize)textBlock).BeginInit();
			children3.Add(textBlock);
			TextBlock textBlock4;
			TextBlock textBlock3 = (textBlock4 = textBlock2);
			context.PushParent(textBlock4);
			Grid.SetColumn(textBlock4, 1);
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension();
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding7 = compiledBindingExtension10.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock4.Bind(textProperty, binding7);
			textBlock4.VerticalAlignment = VerticalAlignment.Center;
			context.PopParent();
			((ISupportInitialize)textBlock3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_19(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroWindow> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Border border = (Border)obj;
			context.PushParent(border);
			border.Bind(Border.BackgroundProperty, new TemplateBinding(TemplatedControl.BackgroundProperty).ProvideValue());
			border.Bind(Decorator.PaddingProperty, new TemplateBinding(TemplatedControl.PaddingProperty).ProvideValue());
			ScrollViewer scrollViewer2;
			ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
			((ISupportInitialize)scrollViewer).BeginInit();
			border.Child = scrollViewer;
			ScrollViewer scrollViewer4;
			ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
			context.PushParent(scrollViewer4);
			scrollViewer4.Name = "PART_ScrollViewer";
			object element = scrollViewer4;
			context.AvaloniaNameScope.Register("PART_ScrollViewer", element);
			scrollViewer4.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Hidden, BindingPriority.Template);
			scrollViewer4.SetValue(ScrollViewer.VerticalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled, BindingPriority.Template);
			TextPresenter textPresenter2;
			TextPresenter textPresenter = (textPresenter2 = new TextPresenter());
			((ISupportInitialize)textPresenter).BeginInit();
			scrollViewer4.Content = textPresenter;
			TextPresenter textPresenter4;
			TextPresenter textPresenter3 = (textPresenter4 = textPresenter2);
			context.PushParent(textPresenter4);
			textPresenter4.Name = "PART_TextPresenter";
			element = textPresenter4;
			context.AvaloniaNameScope.Register("PART_TextPresenter", element);
			textPresenter4.Bind(TextPresenter.TextProperty, new TemplateBinding(TextBox.TextProperty)
			{
				Mode = BindingMode.TwoWay
			}.ProvideValue());
			textPresenter4.Bind(TextPresenter.CaretIndexProperty, new TemplateBinding(TextBox.CaretIndexProperty).ProvideValue());
			textPresenter4.Bind(TextPresenter.SelectionStartProperty, new TemplateBinding(TextBox.SelectionStartProperty).ProvideValue());
			textPresenter4.Bind(TextPresenter.SelectionEndProperty, new TemplateBinding(TextBox.SelectionEndProperty).ProvideValue());
			StyledProperty<IBrush?> selectionBrushProperty = TextPresenter.SelectionBrushProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("MacroAccent");
			context.ProvideTargetProperty = TextPresenter.SelectionBrushProperty;
			BindingBase binding = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textPresenter4.Bind(selectionBrushProperty, binding);
			StyledProperty<IBrush?> caretBrushProperty = TextPresenter.CaretBrushProperty;
			DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("MacroText");
			context.ProvideTargetProperty = TextPresenter.CaretBrushProperty;
			BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textPresenter4.Bind(caretBrushProperty, binding2);
			textPresenter4.SetValue(Layoutable.VerticalAlignmentProperty, VerticalAlignment.Center, BindingPriority.Template);
			context.PopParent();
			((ISupportInitialize)textPresenter3).EndInit();
			context.PopParent();
			((ISupportInitialize)scrollViewer3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public unsafe static object Build_20(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroWindow> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Border border = (Border)obj;
			context.PushParent(border);
			border.Classes.Add("macro-row");
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroRow_002CMerostrap_002EEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = "class:enabled";
			CompiledBinding compiledBinding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			BindingBase source = compiledBinding;
			border.BindClass("enabled", source, null);
			Grid grid2;
			Grid grid = (grid2 = new Grid());
			((ISupportInitialize)grid).BeginInit();
			border.Child = grid;
			Grid grid4;
			Grid grid3 = (grid4 = grid2);
			context.PushParent(grid4);
			Grid grid5 = grid4;
			RowDefinitions rowDefinitions = new RowDefinitions();
			rowDefinitions.Capacity = 2;
			rowDefinitions.Add(new RowDefinition(new GridLength(48.0, GridUnitType.Pixel)));
			rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid5.RowDefinitions = rowDefinitions;
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 2;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid5.ColumnDefinitions = columnDefinitions;
			grid5.Margin = new Thickness(12.0, 0.0, 12.0, 0.0);
			Avalonia.Controls.Controls children = grid5.Children;
			ToggleButton toggleButton2;
			ToggleButton toggleButton = (toggleButton2 = new ToggleButton());
			((ISupportInitialize)toggleButton).BeginInit();
			children.Add(toggleButton);
			ToggleButton toggleButton4;
			ToggleButton toggleButton3 = (toggleButton4 = toggleButton2);
			context.PushParent(toggleButton4);
			Grid.SetColumn(toggleButton4, 0);
			toggleButton4.Classes.Add("disclosure");
			toggleButton4.HorizontalAlignment = HorizontalAlignment.Stretch;
			StyledProperty<bool> isEnabledProperty = InputElement.IsEnabledProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroRow_002CMerostrap_002ESupported_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = InputElement.IsEnabledProperty;
			CompiledBinding binding = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			toggleButton4.Bind(isEnabledProperty, binding);
			StyledProperty<bool?> isCheckedProperty = ToggleButton.IsCheckedProperty;
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroRow_002CMerostrap_002EEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
			{
				Mode = BindingMode.TwoWay
			};
			context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
			CompiledBinding binding2 = compiledBindingExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			toggleButton4.Bind(isCheckedProperty, binding2);
			AttachedProperty<string?> nameProperty = AutomationProperties.NameProperty;
			CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroRow_002CMerostrap_002EName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = AutomationProperties.NameProperty;
			CompiledBinding binding3 = compiledBindingExtension4.ProvideValue(context);
			context.ProvideTargetProperty = null;
			toggleButton4.Bind(nameProperty, binding3);
			CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroRow_002CMerostrap_002EDescription_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = ToolTip.TipProperty;
			CompiledBinding compiledBinding2 = compiledBindingExtension5.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_11((ToolTip)(object)toggleButton4, compiledBinding2);
			Grid grid7;
			Grid grid6 = (grid7 = new Grid());
			((ISupportInitialize)grid6).BeginInit();
			toggleButton4.Content = grid6;
			Grid grid8 = (grid4 = grid7);
			context.PushParent(grid4);
			Grid grid9 = grid4;
			ColumnDefinitions columnDefinitions2 = new ColumnDefinitions();
			columnDefinitions2.Capacity = 2;
			columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions2.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid9.ColumnDefinitions = columnDefinitions2;
			Avalonia.Controls.Controls children2 = grid9.Children;
			TextBlock textBlock2;
			TextBlock textBlock = (textBlock2 = new TextBlock());
			((ISupportInitialize)textBlock).BeginInit();
			children2.Add(textBlock);
			TextBlock textBlock4;
			TextBlock textBlock3 = (textBlock4 = textBlock2);
			context.PushParent(textBlock4);
			TextBlock textBlock5 = textBlock4;
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroRow_002CMerostrap_002EName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding4 = compiledBindingExtension6.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock5.Bind(textProperty, binding4);
			textBlock5.FontSize = 13.0;
			textBlock5.VerticalAlignment = VerticalAlignment.Center;
			textBlock5.TextTrimming = TextTrimming.CharacterEllipsis;
			context.PopParent();
			((ISupportInitialize)textBlock3).EndInit();
			Avalonia.Controls.Controls children3 = grid9.Children;
			TextBlock textBlock7;
			TextBlock textBlock6 = (textBlock7 = new TextBlock());
			((ISupportInitialize)textBlock6).BeginInit();
			children3.Add(textBlock6);
			TextBlock textBlock8 = (textBlock4 = textBlock7);
			context.PushParent(textBlock4);
			TextBlock textBlock9 = textBlock4;
			Grid.SetColumn(textBlock9, 1);
			textBlock9.Text = "Unavailable";
			StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroRow_002CMerostrap_002EUnavailable_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding5 = compiledBindingExtension7.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock9.Bind(isVisibleProperty, binding5);
			textBlock9.FontSize = 11.0;
			textBlock9.Foreground = new ImmutableSolidColorBrush(4288977028u);
			textBlock9.VerticalAlignment = VerticalAlignment.Center;
			CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroRow_002CMerostrap_002ESupportNote_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = ToolTip.TipProperty;
			CompiledBinding compiledBinding3 = compiledBindingExtension8.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_11((ToolTip)(object)textBlock9, compiledBinding3);
			textBlock9.Margin = new Thickness(8.0, 0.0, 8.0, 0.0);
			context.PopParent();
			((ISupportInitialize)textBlock8).EndInit();
			context.PopParent();
			((ISupportInitialize)grid8).EndInit();
			context.PopParent();
			((ISupportInitialize)toggleButton3).EndInit();
			Avalonia.Controls.Controls children4 = grid5.Children;
			StackPanel stackPanel2;
			StackPanel stackPanel = (stackPanel2 = new StackPanel());
			((ISupportInitialize)stackPanel).BeginInit();
			children4.Add(stackPanel);
			StackPanel stackPanel4;
			StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
			context.PushParent(stackPanel4);
			StackPanel stackPanel5 = stackPanel4;
			Grid.SetColumn(stackPanel5, 1);
			stackPanel5.Orientation = Orientation.Horizontal;
			stackPanel5.Spacing = 10.0;
			stackPanel5.Margin = new Thickness(12.0, 0.0, 0.0, 0.0);
			stackPanel5.VerticalAlignment = VerticalAlignment.Center;
			Avalonia.Controls.Controls children5 = stackPanel5.Children;
			KeybindButton keybindButton2;
			KeybindButton keybindButton = (keybindButton2 = new KeybindButton());
			((ISupportInitialize)keybindButton).BeginInit();
			children5.Add(keybindButton);
			KeybindButton keybindButton4;
			KeybindButton keybindButton3 = (keybindButton4 = keybindButton2);
			context.PushParent(keybindButton4);
			StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroRow_002CMerostrap_002EHasHeaderKey_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding6 = compiledBindingExtension9.ProvideValue(context);
			context.ProvideTargetProperty = null;
			keybindButton4.Bind(isVisibleProperty2, binding6);
			StyledProperty<string> valueProperty = KeybindButton.ValueProperty;
			CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroRow_002CMerostrap_002EHeaderKeyValue_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
			{
				Mode = BindingMode.TwoWay
			};
			context.ProvideTargetProperty = KeybindButton.ValueProperty;
			CompiledBinding binding7 = compiledBindingExtension10.ProvideValue(context);
			context.ProvideTargetProperty = null;
			keybindButton4.Bind(valueProperty, binding7);
			StyledProperty<bool> isEnabledProperty2 = InputElement.IsEnabledProperty;
			CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroRow_002CMerostrap_002ESupported_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = InputElement.IsEnabledProperty;
			CompiledBinding binding8 = compiledBindingExtension11.ProvideValue(context);
			context.ProvideTargetProperty = null;
			keybindButton4.Bind(isEnabledProperty2, binding8);
			keybindButton4.CornerRadius = new CornerRadius(0.0, 0.0, 0.0, 0.0);
			AttachedProperty<string?> nameProperty2 = AutomationProperties.NameProperty;
			CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroRow_002CMerostrap_002EName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = AutomationProperties.NameProperty;
			CompiledBinding binding9 = compiledBindingExtension12.ProvideValue(context);
			context.ProvideTargetProperty = null;
			keybindButton4.Bind(nameProperty2, binding9);
			context.PopParent();
			((ISupportInitialize)keybindButton3).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel3).EndInit();
			Avalonia.Controls.Controls children6 = grid5.Children;
			StackPanel stackPanel7;
			StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
			((ISupportInitialize)stackPanel6).BeginInit();
			children6.Add(stackPanel6);
			StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
			context.PushParent(stackPanel4);
			StackPanel stackPanel9 = stackPanel4;
			Grid.SetRow(stackPanel9, 1);
			Grid.SetColumnSpan(stackPanel9, 2);
			StyledProperty<bool> isVisibleProperty3 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroRow_002CMerostrap_002EShowDetails_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding10 = compiledBindingExtension13.ProvideValue(context);
			context.ProvideTargetProperty = null;
			stackPanel9.Bind(isVisibleProperty3, binding10);
			stackPanel9.Margin = new Thickness(0.0, 0.0, 0.0, 14.0);
			Avalonia.Controls.Controls children7 = stackPanel9.Children;
			StackPanel stackPanel11;
			StackPanel stackPanel10 = (stackPanel11 = new StackPanel());
			((ISupportInitialize)stackPanel10).BeginInit();
			children7.Add(stackPanel10);
			StackPanel stackPanel12 = (stackPanel4 = stackPanel11);
			context.PushParent(stackPanel4);
			StackPanel stackPanel13 = stackPanel4;
			StyledProperty<bool> isVisibleProperty4 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroRow_002CMerostrap_002EIsRitual_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding11 = compiledBindingExtension14.ProvideValue(context);
			context.ProvideTargetProperty = null;
			stackPanel13.Bind(isVisibleProperty4, binding11);
			stackPanel13.Spacing = 8.0;
			stackPanel13.Margin = new Thickness(0.0, 4.0, 0.0, 12.0);
			Avalonia.Controls.Controls children8 = stackPanel13.Children;
			TextBlock textBlock11;
			TextBlock textBlock10 = (textBlock11 = new TextBlock());
			((ISupportInitialize)textBlock10).BeginInit();
			children8.Add(textBlock10);
			TextBlock textBlock12 = (textBlock4 = textBlock11);
			context.PushParent(textBlock4);
			TextBlock textBlock13 = textBlock4;
			StyledProperty<string?> textProperty2 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension15 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroRow_002CMerostrap_002ERitualAreaLabel_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding12 = compiledBindingExtension15.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock13.Bind(textProperty2, binding12);
			StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("MacroMuted");
			context.ProvideTargetProperty = TextBlock.ForegroundProperty;
			BindingBase binding13 = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock13.Bind(foregroundProperty, binding13);
			textBlock13.FontSize = 12.0;
			context.PopParent();
			((ISupportInitialize)textBlock12).EndInit();
			Avalonia.Controls.Controls children9 = stackPanel13.Children;
			StackPanel stackPanel15;
			StackPanel stackPanel14 = (stackPanel15 = new StackPanel());
			((ISupportInitialize)stackPanel14).BeginInit();
			children9.Add(stackPanel14);
			stackPanel15.Orientation = Orientation.Horizontal;
			stackPanel15.Spacing = 8.0;
			Avalonia.Controls.Controls children10 = stackPanel15.Children;
			Button button2;
			Button button = (button2 = new Button());
			((ISupportInitialize)button).BeginInit();
			children10.Add(button);
			button2.Content = "Auto-detect";
			button2.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.DetectRitualClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
			AutomationProperties.SetName(button2, "Auto-detect ritual prompt");
			((ISupportInitialize)button2).EndInit();
			Avalonia.Controls.Controls children11 = stackPanel15.Children;
			Button button5;
			Button button4 = (button5 = new Button());
			((ISupportInitialize)button4).BeginInit();
			children11.Add(button4);
			button5.Content = "Select area";
			button5.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.SelectRitualClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
			AutomationProperties.SetName(button5, "Select ritual prompt area");
			((ISupportInitialize)button5).EndInit();
			((ISupportInitialize)stackPanel15).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel12).EndInit();
			Avalonia.Controls.Controls children12 = stackPanel9.Children;
			ItemsControl itemsControl2;
			ItemsControl itemsControl = (itemsControl2 = new ItemsControl());
			((ISupportInitialize)itemsControl).BeginInit();
			children12.Add(itemsControl);
			ItemsControl itemsControl4;
			ItemsControl itemsControl3 = (itemsControl4 = itemsControl2);
			context.PushParent(itemsControl4);
			StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
			CompiledBindingExtension compiledBindingExtension16 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroRow_002CMerostrap_002EDetailFields_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
			CompiledBinding binding14 = compiledBindingExtension16.ProvideValue(context);
			context.ProvideTargetProperty = null;
			itemsControl4.Bind(itemsSourceProperty, binding14);
			DataTemplate dataTemplate;
			DataTemplate itemTemplate = (dataTemplate = new DataTemplate());
			context.PushParent(dataTemplate);
			dataTemplate.DataType = typeof(MacroFieldRow);
			dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&Build_21), context);
			context.PopParent();
			itemsControl4.ItemTemplate = itemTemplate;
			context.PopParent();
			((ISupportInitialize)itemsControl3).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel8).EndInit();
			context.PopParent();
			((ISupportInitialize)grid3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_21(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroWindow> context = CreateContext(P_0);
			context.IntermediateRoot = new Grid();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Grid grid = (Grid)obj;
			context.PushParent(grid);
			StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002EIsShown_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			grid.Bind(isVisibleProperty, binding);
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 2;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(160.0, GridUnitType.Pixel)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid.ColumnDefinitions = columnDefinitions;
			grid.Margin = new Thickness(0.0, 4.0, 0.0, 4.0);
			grid.MinHeight = 32.0;
			Avalonia.Controls.Controls children = grid.Children;
			TextBlock textBlock2;
			TextBlock textBlock = (textBlock2 = new TextBlock());
			((ISupportInitialize)textBlock).BeginInit();
			children.Add(textBlock);
			TextBlock textBlock4;
			TextBlock textBlock3 = (textBlock4 = textBlock2);
			context.PushParent(textBlock4);
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002ELabel_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock4.Bind(textProperty, binding2);
			textBlock4.FontSize = 12.0;
			StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("MacroMuted");
			context.ProvideTargetProperty = TextBlock.ForegroundProperty;
			BindingBase binding3 = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock4.Bind(foregroundProperty, binding3);
			textBlock4.VerticalAlignment = VerticalAlignment.Center;
			textBlock4.TextWrapping = TextWrapping.Wrap;
			textBlock4.Margin = new Thickness(0.0, 0.0, 16.0, 0.0);
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002EHelp_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = ToolTip.TipProperty;
			CompiledBinding compiledBinding = compiledBindingExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_11((ToolTip)(object)textBlock4, compiledBinding);
			context.PopParent();
			((ISupportInitialize)textBlock3).EndInit();
			Avalonia.Controls.Controls children2 = grid.Children;
			TextBox textBox2;
			TextBox textBox = (textBox2 = new TextBox());
			((ISupportInitialize)textBox).BeginInit();
			children2.Add(textBox);
			TextBox textBox4;
			TextBox textBox3 = (textBox4 = textBox2);
			context.PushParent(textBox4);
			Grid.SetColumn(textBox4, 1);
			StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002EIsText_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding4 = compiledBindingExtension4.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBox4.Bind(isVisibleProperty2, binding4);
			StyledProperty<char> passwordCharProperty = TextBox.PasswordCharProperty;
			CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002ESecretMask_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBox.PasswordCharProperty;
			CompiledBinding binding5 = compiledBindingExtension5.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBox4.Bind(passwordCharProperty, binding5);
			StyledProperty<string?> textProperty2 = TextBox.TextProperty;
			CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002EValue_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
			{
				Mode = BindingMode.TwoWay
			};
			context.ProvideTargetProperty = TextBox.TextProperty;
			CompiledBinding binding6 = compiledBindingExtension6.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBox4.Bind(textProperty2, binding6);
			AttachedProperty<string?> nameProperty = AutomationProperties.NameProperty;
			CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002ELabel_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = AutomationProperties.NameProperty;
			CompiledBinding binding7 = compiledBindingExtension7.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBox4.Bind(nameProperty, binding7);
			CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002EHelp_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = ToolTip.TipProperty;
			CompiledBinding compiledBinding2 = compiledBindingExtension8.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_11((ToolTip)(object)textBox4, compiledBinding2);
			context.PopParent();
			((ISupportInitialize)textBox3).EndInit();
			Avalonia.Controls.Controls children3 = grid.Children;
			Button button2;
			Button button = (button2 = new Button());
			((ISupportInitialize)button).BeginInit();
			children3.Add(button);
			Button button4;
			Button button3 = (button4 = button2);
			context.PushParent(button4);
			Button button5 = button4;
			Grid.SetColumn(button5, 1);
			StyledProperty<bool> isVisibleProperty3 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002EIsPoint_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding8 = compiledBindingExtension9.ProvideValue(context);
			context.ProvideTargetProperty = null;
			button5.Bind(isVisibleProperty3, binding8);
			CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002EPickLabel_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = ContentControl.ContentProperty;
			CompiledBinding compiledBinding3 = compiledBindingExtension10.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_4(button5, compiledBinding3);
			button5.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.PickPointClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
			button5.HorizontalAlignment = HorizontalAlignment.Left;
			AttachedProperty<string?> nameProperty2 = AutomationProperties.NameProperty;
			CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002ELabel_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = AutomationProperties.NameProperty;
			CompiledBinding binding9 = compiledBindingExtension11.ProvideValue(context);
			context.ProvideTargetProperty = null;
			button5.Bind(nameProperty2, binding9);
			context.PopParent();
			((ISupportInitialize)button3).EndInit();
			Avalonia.Controls.Controls children4 = grid.Children;
			Button button7;
			Button button6 = (button7 = new Button());
			((ISupportInitialize)button6).BeginInit();
			children4.Add(button6);
			Button button8 = (button4 = button7);
			context.PushParent(button4);
			Button button9 = button4;
			Grid.SetColumn(button9, 1);
			StyledProperty<bool> isVisibleProperty4 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002EIsPath_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding10 = compiledBindingExtension12.ProvideValue(context);
			context.ProvideTargetProperty = null;
			button9.Bind(isVisibleProperty4, binding10);
			CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002EPickLabel_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = ContentControl.ContentProperty;
			CompiledBinding compiledBinding4 = compiledBindingExtension13.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_4(button9, compiledBinding4);
			button9.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.PickPathClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
			button9.HorizontalAlignment = HorizontalAlignment.Left;
			button9.MaxWidth = 280.0;
			CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002EValue_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = ToolTip.TipProperty;
			CompiledBinding compiledBinding5 = compiledBindingExtension14.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_11((ToolTip)(object)button9, compiledBinding5);
			AttachedProperty<string?> nameProperty3 = AutomationProperties.NameProperty;
			CompiledBindingExtension compiledBindingExtension15 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002ELabel_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = AutomationProperties.NameProperty;
			CompiledBinding binding11 = compiledBindingExtension15.ProvideValue(context);
			context.ProvideTargetProperty = null;
			button9.Bind(nameProperty3, binding11);
			context.PopParent();
			((ISupportInitialize)button8).EndInit();
			Avalonia.Controls.Controls children5 = grid.Children;
			ComboBox comboBox2;
			ComboBox comboBox = (comboBox2 = new ComboBox());
			((ISupportInitialize)comboBox).BeginInit();
			children5.Add(comboBox);
			ComboBox comboBox4;
			ComboBox comboBox3 = (comboBox4 = comboBox2);
			context.PushParent(comboBox4);
			Grid.SetColumn(comboBox4, 1);
			StyledProperty<bool> isVisibleProperty5 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension16 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002EIsChoice_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding12 = compiledBindingExtension16.ProvideValue(context);
			context.ProvideTargetProperty = null;
			comboBox4.Bind(isVisibleProperty5, binding12);
			comboBox4.AddHandler(InputElement.PointerPressedEvent, context.RootObject.FieldChoicePressed);
			StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
			CompiledBindingExtension compiledBindingExtension17 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002EChoices_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
			CompiledBinding binding13 = compiledBindingExtension17.ProvideValue(context);
			context.ProvideTargetProperty = null;
			comboBox4.Bind(itemsSourceProperty, binding13);
			DirectProperty<SelectingItemsControl, int> selectedIndexProperty = SelectingItemsControl.SelectedIndexProperty;
			CompiledBindingExtension compiledBindingExtension18 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002EChoiceIndex_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
			{
				Mode = BindingMode.TwoWay
			};
			context.ProvideTargetProperty = SelectingItemsControl.SelectedIndexProperty;
			CompiledBinding binding14 = compiledBindingExtension18.ProvideValue(context);
			context.ProvideTargetProperty = null;
			comboBox4.Bind(selectedIndexProperty, binding14);
			comboBox4.HorizontalAlignment = HorizontalAlignment.Left;
			comboBox4.MinWidth = 150.0;
			AttachedProperty<string?> nameProperty4 = AutomationProperties.NameProperty;
			CompiledBindingExtension compiledBindingExtension19 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002ELabel_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = AutomationProperties.NameProperty;
			CompiledBinding binding15 = compiledBindingExtension19.ProvideValue(context);
			context.ProvideTargetProperty = null;
			comboBox4.Bind(nameProperty4, binding15);
			context.PopParent();
			((ISupportInitialize)comboBox3).EndInit();
			Avalonia.Controls.Controls children6 = grid.Children;
			KeybindButton keybindButton2;
			KeybindButton keybindButton = (keybindButton2 = new KeybindButton());
			((ISupportInitialize)keybindButton).BeginInit();
			children6.Add(keybindButton);
			KeybindButton keybindButton4;
			KeybindButton keybindButton3 = (keybindButton4 = keybindButton2);
			context.PushParent(keybindButton4);
			Grid.SetColumn(keybindButton4, 1);
			StyledProperty<bool> isVisibleProperty6 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension20 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002EIsKeybind_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding16 = compiledBindingExtension20.ProvideValue(context);
			context.ProvideTargetProperty = null;
			keybindButton4.Bind(isVisibleProperty6, binding16);
			StyledProperty<string> valueProperty = KeybindButton.ValueProperty;
			CompiledBindingExtension compiledBindingExtension21 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002EValue_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
			{
				Mode = BindingMode.TwoWay
			};
			context.ProvideTargetProperty = KeybindButton.ValueProperty;
			CompiledBinding binding17 = compiledBindingExtension21.ProvideValue(context);
			context.ProvideTargetProperty = null;
			keybindButton4.Bind(valueProperty, binding17);
			StyledProperty<bool> allowMainMouseButtonsProperty = KeybindButton.AllowMainMouseButtonsProperty;
			CompiledBindingExtension compiledBindingExtension22 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002EAllowsMainMouse_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = KeybindButton.AllowMainMouseButtonsProperty;
			CompiledBinding binding18 = compiledBindingExtension22.ProvideValue(context);
			context.ProvideTargetProperty = null;
			keybindButton4.Bind(allowMainMouseButtonsProperty, binding18);
			AttachedProperty<string?> nameProperty5 = AutomationProperties.NameProperty;
			CompiledBindingExtension compiledBindingExtension23 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002ELabel_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = AutomationProperties.NameProperty;
			CompiledBinding binding19 = compiledBindingExtension23.ProvideValue(context);
			context.ProvideTargetProperty = null;
			keybindButton4.Bind(nameProperty5, binding19);
			context.PopParent();
			((ISupportInitialize)keybindButton3).EndInit();
			Avalonia.Controls.Controls children7 = grid.Children;
			CheckBox checkBox2;
			CheckBox checkBox = (checkBox2 = new CheckBox());
			((ISupportInitialize)checkBox).BeginInit();
			children7.Add(checkBox);
			CheckBox checkBox4;
			CheckBox checkBox3 = (checkBox4 = checkBox2);
			context.PushParent(checkBox4);
			checkBox4.Classes.Add("macro-enable");
			Grid.SetColumn(checkBox4, 1);
			StyledProperty<bool> isVisibleProperty7 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension24 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002EIsBoolean_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding20 = compiledBindingExtension24.ProvideValue(context);
			context.ProvideTargetProperty = null;
			checkBox4.Bind(isVisibleProperty7, binding20);
			StyledProperty<bool?> isCheckedProperty = ToggleButton.IsCheckedProperty;
			CompiledBindingExtension compiledBindingExtension25 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002EBooleanValue_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
			{
				Mode = BindingMode.TwoWay
			};
			context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
			CompiledBinding binding21 = compiledBindingExtension25.ProvideValue(context);
			context.ProvideTargetProperty = null;
			checkBox4.Bind(isCheckedProperty, binding21);
			AttachedProperty<string?> nameProperty6 = AutomationProperties.NameProperty;
			CompiledBindingExtension compiledBindingExtension26 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002ELabel_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = AutomationProperties.NameProperty;
			CompiledBinding binding22 = compiledBindingExtension26.ProvideValue(context);
			context.ProvideTargetProperty = null;
			checkBox4.Bind(nameProperty6, binding22);
			CompiledBindingExtension compiledBindingExtension27 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroFieldRow_002CMerostrap_002EHelp_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = ToolTip.TipProperty;
			CompiledBinding compiledBinding6 = compiledBindingExtension27.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_11((ToolTip)(object)checkBox4, compiledBinding6);
			context.PopParent();
			((ISupportInitialize)checkBox3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}
	}

	private readonly MacroWorkspace _workspace;

	private bool _positionReady;

	private bool _keyboardEditing;

	private readonly DispatcherTimer _savePosition = new DispatcherTimer
	{
		Interval = TimeSpan.FromMilliseconds(300L)
	};

	private readonly DispatcherTimer _animation = new DispatcherTimer
	{
		Interval = TimeSpan.FromMilliseconds(16L)
	};

	private long _lastAnimationTick;

	private double _animationElapsed;

	private double _animationDuration;

	private double _fromScale;

	private bool _reducedAnimation;

	private nint _returnWindow;

	private Size? _compactSize;

	private readonly DispatcherTimer _searchAnimation = new DispatcherTimer
	{
		Interval = TimeSpan.FromMilliseconds(16L)
	};

	private double _searchTargetWidth;

	private long _searchLastTick;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Border GuiSurface;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button CloseButton;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button MinimizeButton;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button ExpandButton;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Border SearchSurface;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBox SearchBox;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal ToggleButton SearchToggle;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Border SidebarFrame;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal ListBox CategoryList;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Border ContentFrame;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal StackPanel SettingsPanel;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal KeybindButton GuiKeybindPicker;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal ComboBox ThemePicker;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal ComboBox PresetSelector;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBox PresetNameBox;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal ToggleButton RenameToggle;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal ToggleSwitch OverlayVisibilityToggle;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button ResetOverlayPositionButton;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal ScrollViewer MacroListScroll;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Border MacroListFrame;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal ItemsControl MacroListItems;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal StackPanel HallowtidePlaceholder;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public bool IsPanelOpen { get; private set; }

	public MacroWindow()
		: this(MacroWorkspace.Current)
	{
	}

	public MacroWindow(MacroWorkspace workspace)
	{
		MacroWindow macroWindow = this;
		_workspace = workspace;
		InitializeComponent();
		DataContext = workspace;
		Win32Properties.AddWindowStylesCallback(this, (uint style, uint extended) => (style: style, exStyle: extended | 0x8000080));
		Win32Properties.AddWndProcHookCallback(this, delegate(nint handle, uint message, nint wParam, nint lParam, ref bool handled)
		{
			if (message == 33 && !macroWindow._keyboardEditing)
			{
				handled = true;
				return new IntPtr(3);
			}
			return IntPtr.Zero;
		});
		Deactivated += (object? _, EventArgs _) =>
		{
			macroWindow._keyboardEditing = false;
			macroWindow.ConfigureOverlayWindow();
		};
		AddHandler(InputElement.PointerPressedEvent, (object? _, PointerPressedEventArgs e) =>
		{
			if (e.Source is Visual visual && (visual is TextBox || visual.GetVisualAncestors().OfType<TextBox>().Any()))
			{
				macroWindow.BeginKeyboardEditing();
			}
		}, RoutingStrategies.Tunnel, handledEventsToo: true);
		AddHandler(InputElement.GotFocusEvent, (object? _, FocusChangedEventArgs e) =>
		{
			if (e.Source is TextBox)
			{
				macroWindow.BeginKeyboardEditing();
			}
		}, RoutingStrategies.Bubble, handledEventsToo: true);
		AddHandler(InputElement.LostFocusEvent, (object? _, FocusChangedEventArgs _) =>
		{
			Avalonia.Threading.Dispatcher.UIThread.Post(() =>
			{
				if (!(macroWindow.FocusManager?.GetFocusedElement() is TextBox) && !KeybindButton.SuppressShortcuts)
				{
					macroWindow.EndKeyboardEditing();
				}
			});
		}, RoutingStrategies.Bubble, handledEventsToo: true);
		PresetNameBox.KeyDown += (object? _, KeyEventArgs e) =>
		{
			Key key = e.Key;
			if ((key == Key.Return || key == Key.Escape) ? true : false)
			{
				e.Handled = true;
				macroWindow.RenameToggle.IsChecked = false;
				macroWindow.EndKeyboardEditing();
			}
		};
		_savePosition.Tick += (object? _, EventArgs _) =>
		{
			macroWindow.FlushPosition();
		};
		PositionChanged += (object? _, PixelPointEventArgs _) =>
		{
			if (macroWindow._positionReady && macroWindow.WindowState == WindowState.Normal)
			{
				macroWindow._savePosition.Stop();
				macroWindow._savePosition.Start();
			}
		};
		MacroTheme.Apply(this, workspace.GuiTheme);
		workspace.PropertyChanged += ThemeChanged;
		_animation.Tick += (object? _, EventArgs _) =>
		{
			macroWindow.TickAnimation();
		};
		_searchAnimation.Tick += (object? _, EventArgs _) =>
		{
			macroWindow.TickSearchAnimation();
		};
		Opened += (object? _, EventArgs _) =>
		{
			macroWindow.RestorePosition();
			macroWindow.ConfigureOverlayWindow();
		};
		SizeChanged += (object? _, SizeChangedEventArgs _) =>
		{
			macroWindow.ClipNativeFrame();
		};
		Closing += (object? _, WindowClosingEventArgs _) =>
		{
			if (macroWindow.IsVisible)
			{
				macroWindow.FlushPosition();
			}
			macroWindow._positionReady = false;
			macroWindow._savePosition.Stop();
		};
		Closed += (object? _, EventArgs _) =>
		{
			macroWindow.IsPanelOpen = false;
			macroWindow._animation.Stop();
			macroWindow._searchAnimation.Stop();
			workspace.PropertyChanged -= macroWindow.ThemeChanged;
		};
	}

	private void RenamePresetClicked(object? sender, RoutedEventArgs e)
	{
		if (RenameToggle.IsChecked != true)
		{
			EndKeyboardEditing();
			return;
		}
		Avalonia.Threading.Dispatcher.UIThread.Post(() =>
		{
			if (IsVisible && RenameToggle.IsChecked == true)
			{
				BeginKeyboardEditing();
				PresetNameBox.Focus();
				PresetNameBox.SelectAll();
			}
		}, DispatcherPriority.Loaded);
	}

	internal void BeginKeyboardEditing()
	{
		if (!_keyboardEditing)
		{
			_keyboardEditing = true;
			ConfigureOverlayWindow();
			Activate();
		}
	}

	internal void EndKeyboardEditing()
	{
		if (_keyboardEditing)
		{
			_keyboardEditing = false;
			ConfigureOverlayWindow();
			RestoreGameFocus();
		}
	}

	private void RestorePosition()
	{
		int? guiX = _workspace.GuiX;
		if (guiX.HasValue)
		{
			int valueOrDefault = guiX.GetValueOrDefault();
			guiX = _workspace.GuiY;
			if (guiX.HasValue)
			{
				int valueOrDefault2 = guiX.GetValueOrDefault();
				PixelPoint pixelPoint = new PixelPoint(valueOrDefault, valueOrDefault2);
				Screen screen = Screens.ScreenFromPoint(pixelPoint) ?? Screens.Primary;
				if ((object)screen != null)
				{
					PixelRect workingArea = screen.WorkingArea;
					pixelPoint = new PixelPoint(Math.Clamp(valueOrDefault, workingArea.X, Math.Max(workingArea.X, workingArea.Right - (int)Math.Ceiling(Width * screen.Scaling))), Math.Clamp(valueOrDefault2, workingArea.Y, Math.Max(workingArea.Y, workingArea.Bottom - (int)Math.Ceiling(Height * screen.Scaling))));
				}
				Position = pixelPoint;
			}
		}
		_positionReady = true;
	}

	private void FlushPosition()
	{
		_savePosition.Stop();
		if (_positionReady && WindowState == WindowState.Normal)
		{
			_workspace.SaveGuiPosition(Position.X, Position.Y);
		}
	}

	protected override void OnPropertyChanged(AvaloniaPropertyChangedEventArgs change)
	{
		base.OnPropertyChanged(change);
		if (change.Property == Visual.IsVisibleProperty && !IsVisible && _positionReady)
		{
			FlushPosition();
			EndKeyboardEditing();
		}
	}

	private void SetDropdownArrow(object? sender, bool open)
	{
		if (sender is Popup { TemplatedParent: ComboBox templatedParent })
		{
			Control control = templatedParent.GetVisualDescendants().OfType<Control>().FirstOrDefault((Control c) => c.Name == "MacDropdownArrow");
			if (control != null)
			{
				control.RenderTransformOrigin = RelativePoint.Center;
				control.RenderTransform = new RotateTransform(open ? 180 : 0);
			}
		}
	}

	private void DropdownClosed(object? sender, EventArgs e)
	{
		SetDropdownArrow(sender, open: false);
	}

	private void DropdownOpened(object? sender, EventArgs e)
	{
		SetDropdownArrow(sender, open: true);
		Popup popup = sender as Popup;
		if (popup == null || !(popup.Child is Border border))
		{
			return;
		}
		bool reduced = App.Settings.Prop.DisableAnimations || App.Settings.Prop.Performance.UseReducedAnimations;
		ScaleTransform transform = new ScaleTransform(1.0, reduced ? 0.96 : 0.88);
		border.RenderTransformOrigin = new RelativePoint(0.5, 0.0, RelativeUnit.Relative);
		border.RenderTransform = transform;
		long start = Environment.TickCount64;
		DispatcherTimer timer = new DispatcherTimer
		{
			Interval = TimeSpan.FromMilliseconds(16L)
		};
		timer.Tick += (object? _, EventArgs _) =>
		{
			if (!popup.IsOpen || !IsVisible)
			{
				timer.Stop();
				transform.ScaleY = 1.0;
			}
			else
			{
				double num = Math.Clamp((double)(Environment.TickCount64 - start) / 180.0, 0.0, 1.0);
				transform.ScaleY = 1.0 - (reduced ? 0.04 : 0.12) * Math.Pow(1.0 - num, 3.0);
				if (num >= 1.0)
				{
					timer.Stop();
					transform.ScaleY = 1.0;
				}
			}
		};
		timer.Start();
	}

	private void ThemeChanged(object? sender, PropertyChangedEventArgs e)
	{
		if (e.PropertyName == "GuiTheme" && sender is MacroWorkspace macroWorkspace)
		{
			MacroTheme.Apply(this, macroWorkspace.GuiTheme);
		}
	}

	public void ShowPanel(bool activate = false)
	{
		if (OperatingSystem.IsWindows())
		{
			nint num = WindowsHealthCapture.ForegroundRobloxWindow();
			if (num != IntPtr.Zero)
			{
				_returnWindow = num;
			}
		}
		if (_returnWindow != IntPtr.Zero)
		{
			activate = false;
		}
		bool flag = !IsPanelOpen;
		IsPanelOpen = true;
		ShowActivated = activate;
		if (flag && !IsVisible)
		{
			_reducedAnimation = App.Settings.Prop.DisableAnimations || App.Settings.Prop.Performance.UseReducedAnimations;
			GuiSurface.Opacity = 1.0;
			((ScaleTransform)GuiSurface.RenderTransform).ScaleX = (_reducedAnimation ? 0.94 : 0.88);
			((ScaleTransform)GuiSurface.RenderTransform).ScaleY = (_reducedAnimation ? 0.94 : 0.88);
		}
		Show();
		ConfigureOverlayWindow();
		if (activate)
		{
			Activate();
		}
		if (flag)
		{
			AnimatePanel(opening: true);
		}
		if (!activate)
		{
			RestoreGameFocus();
		}
	}

	public void HidePanel()
	{
		if (IsPanelOpen)
		{
			IsPanelOpen = false;
			AnimatePanel(opening: false);
		}
	}

	private void AnimatePanel(bool opening)
	{
		_animation.Stop();
		_fromScale = ((ScaleTransform)GuiSurface.RenderTransform).ScaleX;
		_lastAnimationTick = Environment.TickCount64;
		_animationElapsed = 0.0;
		_reducedAnimation = App.Settings.Prop.DisableAnimations || App.Settings.Prop.Performance.UseReducedAnimations;
		_animationDuration = ((!_reducedAnimation) ? (opening ? 180 : 120) : (opening ? 180 : 140));
		_animation.Start();
	}

	private void TickAnimation()
	{
		long tickCount = Environment.TickCount64;
		_animationElapsed += Math.Clamp(tickCount - _lastAnimationTick, 0L, 32L);
		_lastAnimationTick = tickCount;
		double num = Math.Clamp(_animationElapsed / _animationDuration, 0.0, 1.0);
		double num2 = (_reducedAnimation ? (num * num * (3.0 - 2.0 * num)) : (1.0 - Math.Pow(1.0 - num, 3.0)));
		double num3;
		if (IsPanelOpen)
		{
			num3 = 1.0;
		}
		else
		{
			num3 = (_reducedAnimation ? 0.94 : 0.88);
		}
		double num4 = _fromScale + (num3 - _fromScale) * num2;
		((ScaleTransform)GuiSurface.RenderTransform).ScaleX = num4;
		((ScaleTransform)GuiSurface.RenderTransform).ScaleY = num4;
		if (num >= 1.0)
		{
			FinishAnimation();
		}
	}

	private void FinishAnimation()
	{
		_animation.Stop();
		if (!IsPanelOpen)
		{
			bool isActive = IsActive;
			Hide();
			if (isActive)
			{
				RestoreGameFocus();
			}
		}
		GuiSurface.Opacity = 1.0;
		((ScaleTransform)GuiSurface.RenderTransform).ScaleX = 1.0;
		((ScaleTransform)GuiSurface.RenderTransform).ScaleY = 1.0;
	}

	internal void RestoreGameFocus()
	{
		if (!OperatingSystem.IsWindows() || _returnWindow == IntPtr.Zero)
		{
			return;
		}
		GetWindowThreadProcessId(_returnWindow, out var processId);
		try
		{
			using Process process = Process.GetProcessById((int)processId);
			string processName = process.ProcessName;
			if ((processName == "RobloxPlayerBeta" || processName == "RobloxPlayer") ? true : false)
			{
				SetForegroundWindow(_returnWindow);
			}
		}
		catch (ArgumentException)
		{
		}
	}

	private void ConfigureOverlayWindow()
	{
		if (!OperatingSystem.IsWindows())
		{
			return;
		}
		nint? num = TryGetPlatformHandle()?.Handle;
		if (!num.HasValue)
		{
			return;
		}
		nint valueOrDefault = num.GetValueOrDefault();
		if (valueOrDefault != IntPtr.Zero)
		{
			long num2 = ((IntPtr.Size == 8) ? ((IntPtr)GetWindowLongPtr(valueOrDefault, -20)).ToInt64() : GetWindowLong(valueOrDefault, -20));
			num2 = (num2 | 0x80) & -262145;
			num2 = (_keyboardEditing ? (num2 & -134217729) : (num2 | 0x8000000));
			if (IntPtr.Size == 8)
			{
				SetWindowLongPtr(valueOrDefault, -20, new IntPtr(num2));
			}
			else
			{
				SetWindowLong(valueOrDefault, -20, (int)num2);
			}
			SetWindowPos(valueOrDefault, IntPtr.Zero, 0, 0, 0, 0, 55u);
			ClipNativeFrame();
		}
	}

	private void ClipNativeFrame()
	{
		if (!OperatingSystem.IsWindows())
		{
			return;
		}
		nint? num = TryGetPlatformHandle()?.Handle;
		if (!num.HasValue)
		{
			return;
		}
		nint valueOrDefault = num.GetValueOrDefault();
		if (valueOrDefault != IntPtr.Zero && GetWindowRect(valueOrDefault, out var rect))
		{
			int num2 = (int)Math.Round(2.0 * RenderScaling);
			int num3 = (int)Math.Round(24.0 * RenderScaling);
			nint num4 = CreateRoundRectRgn(num2, num2, rect.Right - rect.Left - num2 + 1, rect.Bottom - rect.Top - num2 + 1, num3, num3);
			if (num4 != IntPtr.Zero && SetWindowRgn(valueOrDefault, num4, redraw: true) == 0)
			{
				DeleteObject(num4);
			}
		}
	}

	[DllImport("user32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool GetWindowRect(nint window, out NativeRect rect);

	[DllImport("gdi32.dll")]
	private static extern nint CreateRoundRectRgn(int left, int top, int right, int bottom, int ellipseWidth, int ellipseHeight);

	[DllImport("user32.dll")]
	private static extern int SetWindowRgn(nint window, nint region, [MarshalAs(UnmanagedType.Bool)] bool redraw);

	[DllImport("gdi32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool DeleteObject(nint handle);

	[DllImport("user32.dll", EntryPoint = "GetWindowLongPtrW")]
	private static extern nint GetWindowLongPtr(nint window, int index);

	[DllImport("user32.dll", EntryPoint = "SetWindowLongPtrW")]
	private static extern nint SetWindowLongPtr(nint window, int index, nint value);

	[DllImport("user32.dll", EntryPoint = "GetWindowLongW")]
	private static extern int GetWindowLong(nint window, int index);

	[DllImport("user32.dll", EntryPoint = "SetWindowLongW")]
	private static extern int SetWindowLong(nint window, int index, int value);

	[DllImport("user32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool SetWindowPos(nint window, nint after, int x, int y, int width, int height, uint flags);

	[DllImport("user32.dll")]
	private static extern uint GetWindowThreadProcessId(nint window, out uint processId);

	[DllImport("user32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool SetForegroundWindow(nint window);

	private async void PickPathClicked(object? sender, RoutedEventArgs e)
	{
		if (!(sender is Button button))
		{
			return;
		}
		object dataContext = button.DataContext;
		if (!(dataContext is MacroFieldRow field))
		{
			return;
		}
		using ((DataContext as MacroWorkspace)?.PauseForSettingsEdit())
		{
			_ = 1;
			try
			{
				if (field.Key == "basepath")
				{
					IReadOnlyList<IStorageFolder> readOnlyList = await StorageProvider.OpenFolderPickerAsync(new FolderPickerOpenOptions
					{
						Title = "Select ritual template folder",
						AllowMultiple = false
					});
					if (readOnlyList.Count > 0)
					{
						string text = readOnlyList[0].TryGetLocalPath();
						if (text != null)
						{
							field.Value = text;
						}
					}
					return;
				}
				IReadOnlyList<IStorageFile> readOnlyList2 = await StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
				{
					Title = "Select message file",
					AllowMultiple = false,
					FileTypeFilter = new _003C_003Ez__ReadOnlySingleElementList<FilePickerFileType>(new FilePickerFileType("Text files")
					{
						Patterns = new _003C_003Ez__ReadOnlySingleElementList<string>("*.txt")
					})
				});
				if (readOnlyList2.Count > 0)
				{
					string text2 = readOnlyList2[0].TryGetLocalPath();
					if (text2 != null)
					{
						field.Value = text2;
					}
				}
			}
			catch (Exception ex)
			{
				if (DataContext is MacroWorkspace macroWorkspace)
				{
					macroWorkspace.ReportError("Could not select path: " + ex.Message);
				}
			}
			finally
			{
				ShowPanel();
			}
		}
	}

	private async void PickPointClicked(object? sender, RoutedEventArgs e)
	{
		if (!(sender is Button button))
		{
			return;
		}
		object dataContext = button.DataContext;
		if (!(dataContext is MacroFieldRow field))
		{
			return;
		}
		using ((DataContext as MacroWorkspace)?.PauseForSettingsEdit())
		{
			Hide();
			try
			{
				PixelPoint? pixelPoint = await MacroPointPicker.PickAsync(this, field.Label);
				if (pixelPoint.HasValue)
				{
					PixelPoint valueOrDefault = pixelPoint.GetValueOrDefault();
					field.Value = $"{valueOrDefault.X} {valueOrDefault.Y}";
				}
			}
			catch (Exception ex)
			{
				if (DataContext is MacroWorkspace macroWorkspace)
				{
					macroWorkspace.ReportError("Could not pin point: " + ex.Message);
				}
			}
			finally
			{
				ShowPanel();
			}
		}
	}

	private void TitlePressed(object? sender, PointerPressedEventArgs e)
	{
		if (e.GetCurrentPoint(this).Properties.IsLeftButtonPressed)
		{
			BeginMoveDrag(e);
		}
	}

	private async void DetectRitualClicked(object? sender, RoutedEventArgs e)
	{
		await PickRitual(sender, automatic: true);
	}

	private async void SelectRitualClicked(object? sender, RoutedEventArgs e)
	{
		await PickRitual(sender, automatic: false);
	}

	private async Task PickRitual(object? sender, bool automatic)
	{
		if (!(sender is Button button))
		{
			return;
		}
		object dataContext = button.DataContext;
		if (!(dataContext is MacroRow { IsRitual: not false } row))
		{
			return;
		}
		dataContext = DataContext;
		if (!(dataContext is MacroWorkspace workspace))
		{
			return;
		}
		using (workspace.PauseForSettingsEdit())
		{
			_ = 1;
			try
			{
				HealthRegion healthRegion;
				if (automatic)
				{
					healthRegion = await RitualAutoDetection.PickAsync(this);
				}
				else
				{
					Hide();
					healthRegion = await HealthRegionPicker.PickAsync(this, "Drag around the entire outlined ritual frame, including all four edges. Exclude the title. Esc cancels.");
				}
				if ((object)healthRegion != null)
				{
					row.SetRitualArea(healthRegion);
				}
			}
			catch (Exception ex)
			{
				workspace.ReportError("Could not select ritual prompt: " + ex.Message);
			}
			finally
			{
				ShowPanel();
			}
		}
	}

	private void FieldChoicePressed(object? sender, PointerPressedEventArgs e)
	{
		if (sender is ComboBox { DataContext: MacroFieldRow dataContext })
		{
			dataContext.RefreshChoices();
		}
	}

	private void CloseClicked(object? sender, RoutedEventArgs e)
	{
		HidePanel();
	}

	private void SearchToggleClicked(object? sender, RoutedEventArgs e)
	{
		_searchAnimation.Stop();
		_searchTargetWidth = ((SearchToggle.IsChecked == true) ? 220 : 0);
		_searchLastTick = Environment.TickCount64;
		if (_searchTargetWidth > 0.0)
		{
			SearchBox.Width = 220.0;
			SearchBox.IsVisible = true;
			SearchSurface.Background = (IBrush)Resources["MacroTextField"];
			SearchBox.Focus();
		}
		SearchSurface.Width = _searchTargetWidth + 30.0;
		if (_searchTargetWidth == 0.0 && DataContext is MacroWorkspace macroWorkspace)
		{
			macroWorkspace.Search = "";
		}
		_searchAnimation.Start();
	}

	private void TickSearchAnimation()
	{
		if (Environment.TickCount64 - _searchLastTick >= 260)
		{
			_searchAnimation.Stop();
			if (_searchTargetWidth == 0.0)
			{
				SearchBox.IsVisible = false;
				SearchBox.Width = 0.0;
				SearchSurface.Background = Brushes.Transparent;
			}
		}
	}

	private void SearchKeyDown(object? sender, KeyEventArgs e)
	{
		if (e.Key == Key.Escape)
		{
			SearchToggle.IsChecked = false;
			SearchToggleClicked(SearchToggle, new RoutedEventArgs());
			SearchToggle.Focus();
			e.Handled = true;
		}
	}

	private void ExpandClicked(object? sender, RoutedEventArgs e)
	{
		Size? compactSize = _compactSize;
		if (compactSize.HasValue)
		{
			Size valueOrDefault = compactSize.GetValueOrDefault();
			Width = valueOrDefault.Width;
			Height = valueOrDefault.Height;
			_compactSize = null;
		}
		else
		{
			_compactSize = new Size(Width, Height);
			Width = 920.0;
			Height = 640.0;
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		GuiSurface = nameScope?.Find<Border>("GuiSurface");
		CloseButton = nameScope?.Find<Button>("CloseButton");
		MinimizeButton = nameScope?.Find<Button>("MinimizeButton");
		ExpandButton = nameScope?.Find<Button>("ExpandButton");
		SearchSurface = nameScope?.Find<Border>("SearchSurface");
		SearchBox = nameScope?.Find<TextBox>("SearchBox");
		SearchToggle = nameScope?.Find<ToggleButton>("SearchToggle");
		SidebarFrame = nameScope?.Find<Border>("SidebarFrame");
		CategoryList = nameScope?.Find<ListBox>("CategoryList");
		ContentFrame = nameScope?.Find<Border>("ContentFrame");
		SettingsPanel = nameScope?.Find<StackPanel>("SettingsPanel");
		GuiKeybindPicker = nameScope?.Find<KeybindButton>("GuiKeybindPicker");
		ThemePicker = nameScope?.Find<ComboBox>("ThemePicker");
		PresetSelector = nameScope?.Find<ComboBox>("PresetSelector");
		PresetNameBox = nameScope?.Find<TextBox>("PresetNameBox");
		RenameToggle = nameScope?.Find<ToggleButton>("RenameToggle");
		OverlayVisibilityToggle = nameScope?.Find<ToggleSwitch>("OverlayVisibilityToggle");
		ResetOverlayPositionButton = nameScope?.Find<Button>("ResetOverlayPositionButton");
		MacroListScroll = nameScope?.Find<ScrollViewer>("MacroListScroll");
		MacroListFrame = nameScope?.Find<Border>("MacroListFrame");
		MacroListItems = nameScope?.Find<ItemsControl>("MacroListItems");
		HallowtidePlaceholder = nameScope?.Find<StackPanel>("HallowtidePlaceholder");
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, MacroWindow P_1)
	{
		XamlIlContext.Context<MacroWindow> context = new XamlIlContext.Context<MacroWindow>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FMacros_002FMacroWindow_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Macros/MacroWindow.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		if (P_1.Resources is ResourceDictionary resourceDictionary)
		{
			resourceDictionary.EnsureCapacity(resourceDictionary.Count + 2);
		}
		P_1.Title = "Merostrap · Macros";
		P_1.Width = 760.0;
		P_1.Height = 540.0;
		P_1.MinWidth = 680.0;
		P_1.MinHeight = 440.0;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		P_1.WindowDecorations = WindowDecorations.None;
		P_1.CanResize = false;
		P_1.ShowInTaskbar = false;
		P_1.ShowActivated = false;
		P_1.Topmost = true;
		P_1.TransparencyLevelHint = new WindowTransparencyLevel[1] { WindowTransparencyLevel.Transparent };
		P_1.TransparencyBackgroundFallback = new ImmutableSolidColorBrush(16777215u);
		P_1.Background = new ImmutableSolidColorBrush(16777215u);
		StyledProperty<IBrush?> foregroundProperty = TemplatedControl.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("MacroText");
		context.ProvideTargetProperty = TemplatedControl.ForegroundProperty;
		BindingBase binding = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		P_1.Bind(foregroundProperty, binding);
		P_1.RequestedThemeVariant = ThemeVariant.Dark;
		((ResourceDictionary)P_1.Resources).AddDeferred((object)"CategoryIcon", XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<object>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_29.Build_1), context));
		((ResourceDictionary)P_1.Resources).AddDeferred((object)"CategoryArtwork", XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<object>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_29.Build_2), context));
		Styles styles = P_1.Styles;
		Style style;
		Style item = (style = new Style());
		context.PushParent(style);
		Style style2 = style;
		style2.Selector = ((Selector?)null).OfType(typeof(NumericUpDown));
		Setter setter2;
		Setter setter = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter3 = setter2;
		setter3.Property = TemplatedControl.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("MacroTextField");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter3.Value = value;
		context.PopParent();
		style2.Add(setter);
		Setter setter4 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter5 = setter2;
		setter5.Property = TemplatedControl.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("MacroText");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value2 = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter5.Value = value2;
		context.PopParent();
		style2.Add(setter4);
		Setter setter6 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter7 = setter2;
		setter7.Property = TemplatedControl.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("MacroBorder");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value3 = dynamicResourceExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter7.Value = value3;
		context.PopParent();
		style2.Add(setter6);
		Setter setter8 = new Setter();
		setter8.Property = TemplatedControl.BorderThicknessProperty;
		setter8.Value = new Thickness(1.0, 1.0, 1.0, 1.0);
		style2.Add(setter8);
		Setter setter9 = new Setter();
		setter9.Property = TemplatedControl.CornerRadiusProperty;
		setter9.Value = new CornerRadius(7.0, 7.0, 7.0, 7.0);
		style2.Add(setter9);
		Setter setter10 = new Setter();
		setter10.Property = TemplatedControl.PaddingProperty;
		setter10.Value = new Thickness(10.0, 5.0, 10.0, 5.0);
		style2.Add(setter10);
		context.PopParent();
		styles.Add(item);
		Styles styles2 = P_1.Styles;
		Style item2 = (style = new Style());
		context.PushParent(style);
		Style style3 = style;
		style3.Selector = ((Selector?)null).OfType(typeof(NumericUpDown)).Template().OfType(typeof(ButtonSpinner));
		Setter setter11 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter12 = setter2;
		setter12.Property = TemplatedControl.TemplateProperty;
		ControlTemplate controlTemplate;
		ControlTemplate value4 = (controlTemplate = new ControlTemplate());
		context.PushParent(controlTemplate);
		controlTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_29.Build_3), context);
		context.PopParent();
		setter12.Value = value4;
		context.PopParent();
		style3.Add(setter11);
		context.PopParent();
		styles2.Add(item2);
		Styles styles3 = P_1.Styles;
		Style item3 = (style = new Style());
		context.PushParent(style);
		Style style4 = style;
		style4.Selector = ((Selector?)null).OfType(typeof(NumericUpDown)).Template().OfType(typeof(ButtonSpinner))
			.Template()
			.OfType(typeof(RepeatButton));
		Setter setter13 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter14 = setter2;
		setter14.Property = TemplatedControl.TemplateProperty;
		ControlTemplate value5 = (controlTemplate = new ControlTemplate());
		context.PushParent(controlTemplate);
		controlTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_29.Build_4), context);
		context.PopParent();
		setter14.Value = value5;
		context.PopParent();
		style4.Add(setter13);
		context.PopParent();
		styles3.Add(item3);
		Styles styles4 = P_1.Styles;
		Style item4 = (style = new Style());
		context.PushParent(style);
		Style style5 = style;
		style5.Selector = ((Selector?)null).OfType(typeof(NumericUpDown)).Template().OfType(typeof(ButtonSpinner))
			.Template()
			.OfType(typeof(RepeatButton))
			.Class(":pointerover")
			.Template()
			.OfType(typeof(Border))
			.Name("MacNumberButton");
		Setter setter15 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter16 = setter2;
		setter16.Property = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension5 = new DynamicResourceExtension("MacroSelection");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value6 = dynamicResourceExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter16.Value = value6;
		context.PopParent();
		style5.Add(setter15);
		context.PopParent();
		styles4.Add(item4);
		Styles styles5 = P_1.Styles;
		Style item5 = (style = new Style());
		context.PushParent(style);
		Style style6 = style;
		style6.Selector = ((Selector?)null).OfType(typeof(NumericUpDown)).Template().OfType(typeof(ButtonSpinner))
			.Template()
			.OfType(typeof(RepeatButton))
			.Class(":pressed")
			.Template()
			.OfType(typeof(Border))
			.Name("MacNumberButton");
		Setter setter17 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter18 = setter2;
		setter18.Property = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension6 = new DynamicResourceExtension("MacroInterior");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value7 = dynamicResourceExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter18.Value = value7;
		context.PopParent();
		style6.Add(setter17);
		context.PopParent();
		styles5.Add(item5);
		Styles styles6 = P_1.Styles;
		Style style7 = new Style();
		style7.Selector = ((Selector?)null).OfType(typeof(NumericUpDown)).Template().OfType(typeof(ButtonSpinner))
			.Template()
			.OfType(typeof(RepeatButton))
			.Class(":disabled");
		Setter setter19 = new Setter();
		setter19.Property = Visual.OpacityProperty;
		setter19.Value = 0.4;
		style7.Add(setter19);
		styles6.Add(style7);
		Styles styles7 = P_1.Styles;
		Style item6 = (style = new Style());
		context.PushParent(style);
		Style style8 = style;
		style8.Selector = ((Selector?)null).OfType(typeof(Button));
		Setter setter20 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter21 = setter2;
		setter21.Property = TemplatedControl.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension7 = new DynamicResourceExtension("MacroInput");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value8 = dynamicResourceExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter21.Value = value8;
		context.PopParent();
		style8.Add(setter20);
		Setter setter22 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter23 = setter2;
		setter23.Property = TemplatedControl.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension8 = new DynamicResourceExtension("MacroText");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value9 = dynamicResourceExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter23.Value = value9;
		context.PopParent();
		style8.Add(setter22);
		Setter setter24 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter25 = setter2;
		setter25.Property = TemplatedControl.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension9 = new DynamicResourceExtension("MacroBorder");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value10 = dynamicResourceExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter25.Value = value10;
		context.PopParent();
		style8.Add(setter24);
		Setter setter26 = new Setter();
		setter26.Property = TemplatedControl.BorderThicknessProperty;
		setter26.Value = new Thickness(1.0, 1.0, 1.0, 1.0);
		style8.Add(setter26);
		Setter setter27 = new Setter();
		setter27.Property = TemplatedControl.CornerRadiusProperty;
		setter27.Value = new CornerRadius(7.0, 7.0, 7.0, 7.0);
		style8.Add(setter27);
		Setter setter28 = new Setter();
		setter28.Property = Layoutable.MinHeightProperty;
		setter28.Value = 32.0;
		style8.Add(setter28);
		Setter setter29 = new Setter();
		setter29.Property = TemplatedControl.PaddingProperty;
		setter29.Value = new Thickness(12.0, 5.0, 12.0, 5.0);
		style8.Add(setter29);
		Setter setter30 = new Setter();
		setter30.Property = TemplatedControl.TemplateProperty;
		setter30.Value = new ControlTemplate
		{
			Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_29.Build_5), context)
		};
		style8.Add(setter30);
		context.PopParent();
		styles7.Add(item6);
		Styles styles8 = P_1.Styles;
		Style item7 = (style = new Style());
		context.PushParent(style);
		Style style9 = style;
		style9.Selector = ((Selector?)null).OfType(typeof(Button)).Class(":pointerover").Template()
			.OfType(typeof(Border))
			.Name("MacButtonSurface");
		Setter setter31 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter32 = setter2;
		setter32.Property = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension10 = new DynamicResourceExtension("MacroSelection");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value11 = dynamicResourceExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter32.Value = value11;
		context.PopParent();
		style9.Add(setter31);
		Setter setter33 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter34 = setter2;
		setter34.Property = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension11 = new DynamicResourceExtension("MacroAccent");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value12 = dynamicResourceExtension11.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter34.Value = value12;
		context.PopParent();
		style9.Add(setter33);
		context.PopParent();
		styles8.Add(item7);
		Styles styles9 = P_1.Styles;
		Style item8 = (style = new Style());
		context.PushParent(style);
		Style style10 = style;
		style10.Selector = ((Selector?)null).OfType(typeof(Button)).Class(":pressed").Template()
			.OfType(typeof(Border))
			.Name("MacButtonSurface");
		Setter setter35 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter36 = setter2;
		setter36.Property = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension12 = new DynamicResourceExtension("MacroInterior");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value13 = dynamicResourceExtension12.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter36.Value = value13;
		context.PopParent();
		style10.Add(setter35);
		context.PopParent();
		styles9.Add(item8);
		Styles styles10 = P_1.Styles;
		Style item9 = (style = new Style());
		context.PushParent(style);
		Style style11 = style;
		style11.Selector = ((Selector?)null).OfType(typeof(Button)).Class(":focus-visible").Template()
			.OfType(typeof(Border))
			.Name("MacButtonSurface");
		Setter setter37 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter38 = setter2;
		setter38.Property = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension13 = new DynamicResourceExtension("MacroAccent");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value14 = dynamicResourceExtension13.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter38.Value = value14;
		context.PopParent();
		style11.Add(setter37);
		context.PopParent();
		styles10.Add(item9);
		Styles styles11 = P_1.Styles;
		Style style12 = new Style();
		style12.Selector = ((Selector?)null).OfType(typeof(Button)).Class(":disabled");
		Setter setter39 = new Setter();
		setter39.Property = Visual.OpacityProperty;
		setter39.Value = 0.45;
		style12.Add(setter39);
		styles11.Add(style12);
		Styles styles12 = P_1.Styles;
		Style item10 = (style = new Style());
		context.PushParent(style);
		Style style13 = style;
		style13.Selector = ((Selector?)null).OfType(typeof(ToggleSwitch));
		Setter setter40 = new Setter();
		setter40.Property = Layoutable.MinWidthProperty;
		setter40.Value = 0.0;
		style13.Add(setter40);
		Setter setter41 = new Setter();
		setter41.Property = Layoutable.WidthProperty;
		setter41.Value = 40.0;
		style13.Add(setter41);
		Setter setter42 = new Setter();
		setter42.Property = Layoutable.HeightProperty;
		setter42.Value = 30.0;
		style13.Add(setter42);
		Setter setter43 = new Setter();
		setter43.Property = InputElement.CursorProperty;
		setter43.Value = new Cursor(StandardCursorType.Hand);
		style13.Add(setter43);
		Setter setter44 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter45 = setter2;
		setter45.Property = TemplatedControl.TemplateProperty;
		ControlTemplate value15 = (controlTemplate = new ControlTemplate());
		context.PushParent(controlTemplate);
		controlTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_29.Build_6), context);
		context.PopParent();
		setter45.Value = value15;
		context.PopParent();
		style13.Add(setter44);
		context.PopParent();
		styles12.Add(item10);
		Styles styles13 = P_1.Styles;
		Style item11 = (style = new Style());
		context.PushParent(style);
		Style style14 = style;
		style14.Selector = ((Selector?)null).OfType(typeof(ToggleSwitch)).Class(":checked").Template()
			.OfType(typeof(Border))
			.Name("MacSwitchThumb");
		Setter setter46 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter47 = setter2;
		setter47.Property = Visual.RenderTransformProperty;
		setter47.Value = (ITransform)new TransformConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "translate(16px, 0px)");
		context.PopParent();
		style14.Add(setter46);
		context.PopParent();
		styles13.Add(item11);
		Styles styles14 = P_1.Styles;
		Style item12 = (style = new Style());
		context.PushParent(style);
		Style style15 = style;
		style15.Selector = ((Selector?)null).OfType(typeof(ToggleSwitch)).Class(":checked").Template()
			.OfType(typeof(Border))
			.Name("MacSwitchTrack");
		Setter setter48 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter49 = setter2;
		setter49.Property = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension14 = new DynamicResourceExtension("MacroAccent");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value16 = dynamicResourceExtension14.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter49.Value = value16;
		context.PopParent();
		style15.Add(setter48);
		context.PopParent();
		styles14.Add(item12);
		Styles styles15 = P_1.Styles;
		Style item13 = (style = new Style());
		context.PushParent(style);
		Style style16 = style;
		style16.Selector = ((Selector?)null).OfType(typeof(ToggleSwitch)).Class(":focus-visible").Template()
			.OfType(typeof(Border))
			.Name("MacSwitchTrack");
		Setter setter50 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter51 = setter2;
		setter51.Property = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension15 = new DynamicResourceExtension("MacroText");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value17 = dynamicResourceExtension15.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter51.Value = value17;
		context.PopParent();
		style16.Add(setter50);
		Setter setter52 = new Setter();
		setter52.Property = Border.BorderThicknessProperty;
		setter52.Value = new Thickness(1.0, 1.0, 1.0, 1.0);
		style16.Add(setter52);
		context.PopParent();
		styles15.Add(item13);
		Styles styles16 = P_1.Styles;
		Style style17 = new Style();
		style17.Selector = ((Selector?)null).OfType(typeof(ToggleSwitch)).Class(":pointerover").Template()
			.OfType(typeof(Border))
			.Name("MacSwitchThumb");
		Setter setter53 = new Setter();
		setter53.Property = Border.BackgroundProperty;
		setter53.Value = new ImmutableSolidColorBrush(uint.MaxValue);
		style17.Add(setter53);
		styles16.Add(style17);
		Styles styles17 = P_1.Styles;
		Style style18 = new Style();
		style18.Selector = ((Selector?)null).OfType(typeof(ToggleSwitch)).Class(":disabled");
		Setter setter54 = new Setter();
		setter54.Property = Visual.OpacityProperty;
		setter54.Value = 0.4;
		style18.Add(setter54);
		styles17.Add(style18);
		Styles styles18 = P_1.Styles;
		Style item14 = (style = new Style());
		context.PushParent(style);
		Style style19 = style;
		style19.Selector = ((Selector?)null).OfType(typeof(TextBox));
		Setter setter55 = new Setter();
		setter55.Property = TemplatedControl.BorderThicknessProperty;
		setter55.Value = new Thickness(1.0, 1.0, 1.0, 1.0);
		style19.Add(setter55);
		Setter setter56 = new Setter();
		setter56.Property = Layoutable.MinHeightProperty;
		setter56.Value = 32.0;
		style19.Add(setter56);
		Setter setter57 = new Setter();
		setter57.Property = TemplatedControl.PaddingProperty;
		setter57.Value = new Thickness(10.0, 5.0, 10.0, 5.0);
		style19.Add(setter57);
		Setter setter58 = new Setter();
		setter58.Property = TextBox.VerticalContentAlignmentProperty;
		setter58.Value = VerticalAlignment.Center;
		style19.Add(setter58);
		Setter setter59 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter60 = setter2;
		setter60.Property = TemplatedControl.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension16 = new DynamicResourceExtension("MacroText");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value18 = dynamicResourceExtension16.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter60.Value = value18;
		context.PopParent();
		style19.Add(setter59);
		Setter setter61 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter62 = setter2;
		setter62.Property = TextBox.CaretBrushProperty;
		DynamicResourceExtension dynamicResourceExtension17 = new DynamicResourceExtension("MacroAccent");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value19 = dynamicResourceExtension17.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter62.Value = value19;
		context.PopParent();
		style19.Add(setter61);
		Setter setter63 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter64 = setter2;
		setter64.Property = TextBox.SelectionBrushProperty;
		DynamicResourceExtension dynamicResourceExtension18 = new DynamicResourceExtension("MacroSelection");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value20 = dynamicResourceExtension18.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter64.Value = value20;
		context.PopParent();
		style19.Add(setter63);
		context.PopParent();
		styles18.Add(item14);
		Styles styles19 = P_1.Styles;
		Style item15 = (style = new Style());
		context.PushParent(style);
		Style style20 = style;
		style20.Selector = ((Selector?)null).OfType(typeof(TextBox)).Template().OfType(typeof(Border))
			.Name("PART_BorderElement");
		Setter setter65 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter66 = setter2;
		setter66.Property = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension19 = new DynamicResourceExtension("MacroTextField");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value21 = dynamicResourceExtension19.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter66.Value = value21;
		context.PopParent();
		style20.Add(setter65);
		Setter setter67 = new Setter();
		setter67.Property = Border.BorderThicknessProperty;
		setter67.Value = new Thickness(1.0, 1.0, 1.0, 1.0);
		style20.Add(setter67);
		Setter setter68 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter69 = setter2;
		setter69.Property = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension20 = new DynamicResourceExtension("MacroBorder");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value22 = dynamicResourceExtension20.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter69.Value = value22;
		context.PopParent();
		style20.Add(setter68);
		Setter setter70 = new Setter();
		setter70.Property = Border.CornerRadiusProperty;
		setter70.Value = new CornerRadius(7.0, 7.0, 7.0, 7.0);
		style20.Add(setter70);
		context.PopParent();
		styles19.Add(item15);
		Styles styles20 = P_1.Styles;
		Style item16 = (style = new Style());
		context.PushParent(style);
		Style style21 = style;
		style21.Selector = ((Selector?)null).OfType(typeof(TextBox)).Class(":pointerover").Template()
			.OfType(typeof(Border))
			.Name("PART_BorderElement");
		Setter setter71 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter72 = setter2;
		setter72.Property = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension21 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value23 = dynamicResourceExtension21.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter72.Value = value23;
		context.PopParent();
		style21.Add(setter71);
		context.PopParent();
		styles20.Add(item16);
		Styles styles21 = P_1.Styles;
		Style item17 = (style = new Style());
		context.PushParent(style);
		Style style22 = style;
		style22.Selector = ((Selector?)null).OfType(typeof(TextBox)).Class(":focus").Template()
			.OfType(typeof(Border))
			.Name("PART_BorderElement");
		Setter setter73 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter74 = setter2;
		setter74.Property = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension22 = new DynamicResourceExtension("MacroAccent");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value24 = dynamicResourceExtension22.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter74.Value = value24;
		context.PopParent();
		style22.Add(setter73);
		Setter setter75 = new Setter();
		setter75.Property = Border.BorderThicknessProperty;
		setter75.Value = new Thickness(1.0, 1.0, 1.0, 1.0);
		style22.Add(setter75);
		Setter setter76 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter77 = setter2;
		setter77.Property = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension23 = new DynamicResourceExtension("MacroTextField");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value25 = dynamicResourceExtension23.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter77.Value = value25;
		context.PopParent();
		style22.Add(setter76);
		context.PopParent();
		styles21.Add(item17);
		Styles styles22 = P_1.Styles;
		Style item18 = (style = new Style());
		context.PushParent(style);
		Style style23 = style;
		style23.Selector = ((Selector?)null).OfType(typeof(Border)).Class("settings-card");
		Setter setter78 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter79 = setter2;
		setter79.Property = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension24 = new DynamicResourceExtension("MacroSurface");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value26 = dynamicResourceExtension24.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter79.Value = value26;
		context.PopParent();
		style23.Add(setter78);
		Setter setter80 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter81 = setter2;
		setter81.Property = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension25 = new DynamicResourceExtension("MacroBorder");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value27 = dynamicResourceExtension25.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter81.Value = value27;
		context.PopParent();
		style23.Add(setter80);
		Setter setter82 = new Setter();
		setter82.Property = Border.BorderThicknessProperty;
		setter82.Value = new Thickness(0.0, 0.0, 0.0, 1.0);
		style23.Add(setter82);
		Setter setter83 = new Setter();
		setter83.Property = Border.CornerRadiusProperty;
		setter83.Value = new CornerRadius(0.0, 0.0, 0.0, 0.0);
		style23.Add(setter83);
		Setter setter84 = new Setter();
		setter84.Property = Decorator.PaddingProperty;
		setter84.Value = new Thickness(12.0, 7.0, 12.0, 7.0);
		style23.Add(setter84);
		Setter setter85 = new Setter();
		setter85.Property = Layoutable.MinHeightProperty;
		setter85.Value = 48.0;
		style23.Add(setter85);
		context.PopParent();
		styles22.Add(item18);
		Styles styles23 = P_1.Styles;
		Style style24 = new Style();
		style24.Selector = ((Selector?)null).OfType(typeof(Button)).Class("chrome-dot");
		Setter setter86 = new Setter();
		setter86.Property = Layoutable.WidthProperty;
		setter86.Value = 24.0;
		style24.Add(setter86);
		Setter setter87 = new Setter();
		setter87.Property = Layoutable.HeightProperty;
		setter87.Value = 28.0;
		style24.Add(setter87);
		Setter setter88 = new Setter();
		setter88.Property = Layoutable.MinWidthProperty;
		setter88.Value = 0.0;
		style24.Add(setter88);
		Setter setter89 = new Setter();
		setter89.Property = Layoutable.MinHeightProperty;
		setter89.Value = 0.0;
		style24.Add(setter89);
		Setter setter90 = new Setter();
		setter90.Property = TemplatedControl.PaddingProperty;
		setter90.Value = new Thickness(0.0, 0.0, 0.0, 0.0);
		style24.Add(setter90);
		Setter setter91 = new Setter();
		setter91.Property = TemplatedControl.BackgroundProperty;
		setter91.Value = new ImmutableSolidColorBrush(16777215u);
		style24.Add(setter91);
		Setter setter92 = new Setter();
		setter92.Property = TemplatedControl.BorderThicknessProperty;
		setter92.Value = new Thickness(0.0, 0.0, 0.0, 0.0);
		style24.Add(setter92);
		Setter setter93 = new Setter();
		setter93.Property = TemplatedControl.CornerRadiusProperty;
		setter93.Value = new CornerRadius(12.0, 12.0, 12.0, 12.0);
		style24.Add(setter93);
		styles23.Add(style24);
		Styles styles24 = P_1.Styles;
		Style style25 = new Style();
		style25.Selector = ((Selector?)null).OfType(typeof(Button)).Class("chrome-dot").Class(":pointerover")
			.Template()
			.OfType(typeof(ContentPresenter));
		Setter setter94 = new Setter();
		setter94.Property = ContentPresenter.BackgroundProperty;
		setter94.Value = new ImmutableSolidColorBrush(16777215u);
		style25.Add(setter94);
		styles24.Add(style25);
		Styles styles25 = P_1.Styles;
		Style style26 = new Style();
		style26.Selector = ((Selector?)null).OfType(typeof(TextBlock)).Class("chrome-glyph");
		Setter setter95 = new Setter();
		setter95.Property = Visual.OpacityProperty;
		setter95.Value = 0.0;
		style26.Add(setter95);
		styles25.Add(style26);
		Styles styles26 = P_1.Styles;
		Style style27 = new Style();
		style27.Selector = ((Selector?)null).OfType(typeof(Button)).Class("chrome-dot").Class(":pointerover")
			.Descendant()
			.OfType(typeof(TextBlock))
			.Class("chrome-glyph");
		Setter setter96 = new Setter();
		setter96.Property = Visual.OpacityProperty;
		setter96.Value = 1.0;
		style27.Add(setter96);
		styles26.Add(style27);
		Styles styles27 = P_1.Styles;
		Style item19 = (style = new Style());
		context.PushParent(style);
		Style style28 = style;
		style28.Selector = ((Selector?)null).OfType(typeof(TextBox));
		Setter setter97 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter98 = setter2;
		setter98.Property = TemplatedControl.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension26 = new DynamicResourceExtension("MacroInput");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value28 = dynamicResourceExtension26.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter98.Value = value28;
		context.PopParent();
		style28.Add(setter97);
		Setter setter99 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter100 = setter2;
		setter100.Property = TemplatedControl.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension27 = new DynamicResourceExtension("MacroBorder");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value29 = dynamicResourceExtension27.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter100.Value = value29;
		context.PopParent();
		style28.Add(setter99);
		Setter setter101 = new Setter();
		setter101.Property = TemplatedControl.CornerRadiusProperty;
		setter101.Value = new CornerRadius(6.0, 6.0, 6.0, 6.0);
		style28.Add(setter101);
		context.PopParent();
		styles27.Add(item19);
		Styles styles28 = P_1.Styles;
		Style item20 = (style = new Style());
		context.PushParent(style);
		Style style29 = style;
		style29.Selector = ((Selector?)null).OfType(typeof(ComboBox));
		Setter setter102 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter103 = setter2;
		setter103.Property = TemplatedControl.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension28 = new DynamicResourceExtension("MacroInput");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value30 = dynamicResourceExtension28.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter103.Value = value30;
		context.PopParent();
		style29.Add(setter102);
		Setter setter104 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter105 = setter2;
		setter105.Property = TemplatedControl.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension29 = new DynamicResourceExtension("MacroBorder");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value31 = dynamicResourceExtension29.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter105.Value = value31;
		context.PopParent();
		style29.Add(setter104);
		Setter setter106 = new Setter();
		setter106.Property = TemplatedControl.CornerRadiusProperty;
		setter106.Value = new CornerRadius(6.0, 6.0, 6.0, 6.0);
		style29.Add(setter106);
		context.PopParent();
		styles28.Add(item20);
		Styles styles29 = P_1.Styles;
		Style style30 = new Style();
		style30.Selector = ((Selector?)null).OfType(typeof(ToggleButton)).Class("disclosure");
		Setter setter107 = new Setter();
		setter107.Property = InputElement.CursorProperty;
		setter107.Value = new Cursor(StandardCursorType.Hand);
		style30.Add(setter107);
		Setter setter108 = new Setter();
		setter108.Property = TemplatedControl.BackgroundProperty;
		setter108.Value = new ImmutableSolidColorBrush(16777215u);
		style30.Add(setter108);
		Setter setter109 = new Setter();
		setter109.Property = TemplatedControl.BorderThicknessProperty;
		setter109.Value = new Thickness(0.0, 0.0, 0.0, 0.0);
		style30.Add(setter109);
		Setter setter110 = new Setter();
		setter110.Property = TemplatedControl.PaddingProperty;
		setter110.Value = new Thickness(0.0, 0.0, 0.0, 0.0);
		style30.Add(setter110);
		Setter setter111 = new Setter();
		setter111.Property = ContentControl.HorizontalContentAlignmentProperty;
		setter111.Value = HorizontalAlignment.Stretch;
		style30.Add(setter111);
		Setter setter112 = new Setter();
		setter112.Property = TemplatedControl.TemplateProperty;
		setter112.Value = new ControlTemplate
		{
			Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_29.Build_7), context)
		};
		style30.Add(setter112);
		styles29.Add(style30);
		Styles styles30 = P_1.Styles;
		Style item21 = (style = new Style());
		context.PushParent(style);
		Style style31 = style;
		style31.Selector = ((Selector?)null).OfType(typeof(ToggleButton)).Class("disclosure").Class(":pointerover");
		Setter setter113 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter114 = setter2;
		setter114.Property = TemplatedControl.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension30 = new DynamicResourceExtension("MacroInput");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value32 = dynamicResourceExtension30.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter114.Value = value32;
		context.PopParent();
		style31.Add(setter113);
		context.PopParent();
		styles30.Add(item21);
		Styles styles31 = P_1.Styles;
		Style style32 = new Style();
		style32.Selector = ((Selector?)null).OfType(typeof(ListBoxItem));
		Setter setter115 = new Setter();
		setter115.Property = TemplatedControl.PaddingProperty;
		setter115.Value = new Thickness(10.0, 7.0, 10.0, 7.0);
		style32.Add(setter115);
		Setter setter116 = new Setter();
		setter116.Property = Layoutable.MarginProperty;
		setter116.Value = new Thickness(0.0, 2.0, 0.0, 2.0);
		style32.Add(setter116);
		Setter setter117 = new Setter();
		setter117.Property = Layoutable.MinHeightProperty;
		setter117.Value = 34.0;
		style32.Add(setter117);
		Setter setter118 = new Setter();
		setter118.Property = TemplatedControl.CornerRadiusProperty;
		setter118.Value = new CornerRadius(5.0, 5.0, 5.0, 5.0);
		style32.Add(setter118);
		Setter setter119 = new Setter();
		setter119.Property = TemplatedControl.BorderThicknessProperty;
		setter119.Value = new Thickness(1.0, 1.0, 1.0, 1.0);
		style32.Add(setter119);
		Setter setter120 = new Setter();
		setter120.Property = TemplatedControl.BorderBrushProperty;
		setter120.Value = new ImmutableSolidColorBrush(16777215u);
		style32.Add(setter120);
		Setter setter121 = new Setter();
		setter121.Property = TemplatedControl.BackgroundProperty;
		setter121.Value = new ImmutableSolidColorBrush(16777215u);
		style32.Add(setter121);
		Setter setter122 = new Setter();
		setter122.Property = TemplatedControl.TemplateProperty;
		setter122.Value = new ControlTemplate
		{
			Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_29.Build_8), context)
		};
		style32.Add(setter122);
		styles31.Add(style32);
		Styles styles32 = P_1.Styles;
		Style item22 = (style = new Style());
		context.PushParent(style);
		Style style33 = style;
		style33.Selector = ((Selector?)null).OfType(typeof(ListBoxItem)).Class(":pointerover");
		Setter setter123 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter124 = setter2;
		setter124.Property = TemplatedControl.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension31 = new DynamicResourceExtension("MacroSurface");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value33 = dynamicResourceExtension31.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter124.Value = value33;
		context.PopParent();
		style33.Add(setter123);
		Setter setter125 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter126 = setter2;
		setter126.Property = TemplatedControl.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension32 = new DynamicResourceExtension("MacroBorder");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value34 = dynamicResourceExtension32.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter126.Value = value34;
		context.PopParent();
		style33.Add(setter125);
		context.PopParent();
		styles32.Add(item22);
		Styles styles33 = P_1.Styles;
		Style item23 = (style = new Style());
		context.PushParent(style);
		Style style34 = style;
		style34.Selector = ((Selector?)null).OfType(typeof(ListBoxItem)).Class(":selected");
		Setter setter127 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter128 = setter2;
		setter128.Property = TemplatedControl.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension33 = new DynamicResourceExtension("MacroSelection");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value35 = dynamicResourceExtension33.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter128.Value = value35;
		context.PopParent();
		style34.Add(setter127);
		Setter setter129 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter130 = setter2;
		setter130.Property = TemplatedControl.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension34 = new DynamicResourceExtension("MacroAccent");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value36 = dynamicResourceExtension34.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter130.Value = value36;
		context.PopParent();
		style34.Add(setter129);
		context.PopParent();
		styles33.Add(item23);
		Styles styles34 = P_1.Styles;
		Style style35 = new Style();
		style35.Selector = ((Selector?)null).OfType(typeof(ToggleButton)).Name("SearchToggle");
		Setter setter131 = new Setter();
		setter131.Property = TemplatedControl.TemplateProperty;
		setter131.Value = new ControlTemplate
		{
			Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_29.Build_9), context)
		};
		style35.Add(setter131);
		styles34.Add(style35);
		Styles styles35 = P_1.Styles;
		Style style36 = new Style();
		style36.Selector = ((Selector?)null).OfType(typeof(TextBox)).Name("SearchBox").Template()
			.OfType(typeof(Border))
			.Name("PART_BorderElement");
		Setter setter132 = new Setter();
		setter132.Property = Border.BackgroundProperty;
		setter132.Value = new ImmutableSolidColorBrush(16777215u);
		style36.Add(setter132);
		Setter setter133 = new Setter();
		setter133.Property = Border.BorderThicknessProperty;
		setter133.Value = new Thickness(0.0, 0.0, 0.0, 0.0);
		style36.Add(setter133);
		styles35.Add(style36);
		Styles styles36 = P_1.Styles;
		Style style37 = new Style();
		style37.Selector = ((Selector?)null).OfType(typeof(TextBox)).Name("SearchBox").Class(":focus")
			.Template()
			.OfType(typeof(Border))
			.Name("PART_BorderElement");
		Setter setter134 = new Setter();
		setter134.Property = Border.BackgroundProperty;
		setter134.Value = new ImmutableSolidColorBrush(16777215u);
		style37.Add(setter134);
		Setter setter135 = new Setter();
		setter135.Property = Border.BorderThicknessProperty;
		setter135.Value = new Thickness(0.0, 0.0, 0.0, 0.0);
		style37.Add(setter135);
		styles36.Add(style37);
		Styles styles37 = P_1.Styles;
		Style item24 = (style = new Style());
		context.PushParent(style);
		Style style38 = style;
		style38.Selector = ((Selector?)null).OfType(typeof(TextBox)).Name("SearchBox");
		Setter setter136 = new Setter();
		setter136.Property = TemplatedControl.BackgroundProperty;
		setter136.Value = new ImmutableSolidColorBrush(16777215u);
		style38.Add(setter136);
		Setter setter137 = new Setter();
		setter137.Property = TemplatedControl.BorderThicknessProperty;
		setter137.Value = new Thickness(0.0, 0.0, 0.0, 0.0);
		style38.Add(setter137);
		Setter setter138 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter139 = setter2;
		setter139.Property = TemplatedControl.TemplateProperty;
		ControlTemplate value37 = (controlTemplate = new ControlTemplate());
		context.PushParent(controlTemplate);
		controlTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_29.Build_10), context);
		context.PopParent();
		setter139.Value = value37;
		context.PopParent();
		style38.Add(setter138);
		context.PopParent();
		styles37.Add(item24);
		Styles styles38 = P_1.Styles;
		Style item25 = (style = new Style());
		context.PushParent(style);
		Style style39 = style;
		style39.Selector = ((Selector?)null).OfType(typeof(ComboBox));
		Setter setter140 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter141 = setter2;
		setter141.Property = TemplatedControl.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension35 = new DynamicResourceExtension("MacroTextField");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value38 = dynamicResourceExtension35.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter141.Value = value38;
		context.PopParent();
		style39.Add(setter140);
		Setter setter142 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter143 = setter2;
		setter143.Property = TemplatedControl.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension36 = new DynamicResourceExtension("MacroText");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value39 = dynamicResourceExtension36.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter143.Value = value39;
		context.PopParent();
		style39.Add(setter142);
		Setter setter144 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter145 = setter2;
		setter145.Property = TemplatedControl.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension37 = new DynamicResourceExtension("MacroBorder");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value40 = dynamicResourceExtension37.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter145.Value = value40;
		context.PopParent();
		style39.Add(setter144);
		Setter setter146 = new Setter();
		setter146.Property = TemplatedControl.BorderThicknessProperty;
		setter146.Value = new Thickness(1.0, 1.0, 1.0, 1.0);
		style39.Add(setter146);
		Setter setter147 = new Setter();
		setter147.Property = TemplatedControl.CornerRadiusProperty;
		setter147.Value = new CornerRadius(0.0, 0.0, 0.0, 0.0);
		style39.Add(setter147);
		Setter setter148 = new Setter();
		setter148.Property = Layoutable.MinHeightProperty;
		setter148.Value = 32.0;
		style39.Add(setter148);
		Setter setter149 = new Setter();
		setter149.Property = TemplatedControl.PaddingProperty;
		setter149.Value = new Thickness(10.0, 5.0, 10.0, 5.0);
		style39.Add(setter149);
		Setter setter150 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter151 = setter2;
		setter151.Property = TemplatedControl.TemplateProperty;
		ControlTemplate value41 = (controlTemplate = new ControlTemplate());
		context.PushParent(controlTemplate);
		controlTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_29.Build_11), context);
		context.PopParent();
		setter151.Value = value41;
		context.PopParent();
		style39.Add(setter150);
		context.PopParent();
		styles38.Add(item25);
		Styles styles39 = P_1.Styles;
		Style item26 = (style = new Style());
		context.PushParent(style);
		Style style40 = style;
		style40.Selector = ((Selector?)null).OfType(typeof(ComboBox)).Class(":pointerover").Template()
			.OfType(typeof(Border))
			.Name("MacDropdownSurface");
		Setter setter152 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter153 = setter2;
		setter153.Property = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension38 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value42 = dynamicResourceExtension38.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter153.Value = value42;
		context.PopParent();
		style40.Add(setter152);
		context.PopParent();
		styles39.Add(item26);
		Styles styles40 = P_1.Styles;
		Style item27 = (style = new Style());
		context.PushParent(style);
		Style style41 = style;
		style41.Selector = ((Selector?)null).OfType(typeof(ComboBox)).Class(":focus-visible").Template()
			.OfType(typeof(Border))
			.Name("MacDropdownSurface");
		Setter setter154 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter155 = setter2;
		setter155.Property = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension39 = new DynamicResourceExtension("MacroAccent");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value43 = dynamicResourceExtension39.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter155.Value = value43;
		context.PopParent();
		style41.Add(setter154);
		context.PopParent();
		styles40.Add(item27);
		Styles styles41 = P_1.Styles;
		Style style42 = new Style();
		style42.Selector = ((Selector?)null).OfType(typeof(ComboBox)).Name("PresetSelector").Template()
			.OfType(typeof(ContentPresenter));
		Setter setter156 = new Setter();
		setter156.Property = Layoutable.MarginProperty;
		setter156.Value = new Thickness(0.0, 0.0, 28.0, 0.0);
		style42.Add(setter156);
		styles41.Add(style42);
		Styles styles42 = P_1.Styles;
		Style style43 = new Style();
		style43.Selector = ((Selector?)null).OfType(typeof(ComboBox)).Class(":disabled");
		Setter setter157 = new Setter();
		setter157.Property = Visual.OpacityProperty;
		setter157.Value = 0.4;
		style43.Add(setter157);
		styles42.Add(style43);
		Styles styles43 = P_1.Styles;
		Style item28 = (style = new Style());
		context.PushParent(style);
		Style style44 = style;
		style44.Selector = ((Selector?)null).OfType(typeof(ComboBoxItem));
		Setter setter158 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter159 = setter2;
		setter159.Property = TemplatedControl.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension40 = new DynamicResourceExtension("MacroText");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value44 = dynamicResourceExtension40.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter159.Value = value44;
		context.PopParent();
		style44.Add(setter158);
		Setter setter160 = new Setter();
		setter160.Property = TemplatedControl.BackgroundProperty;
		setter160.Value = new ImmutableSolidColorBrush(16777215u);
		style44.Add(setter160);
		Setter setter161 = new Setter();
		setter161.Property = TemplatedControl.PaddingProperty;
		setter161.Value = new Thickness(10.0, 7.0, 10.0, 7.0);
		style44.Add(setter161);
		Setter setter162 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter163 = setter2;
		setter163.Property = TemplatedControl.TemplateProperty;
		ControlTemplate value45 = (controlTemplate = new ControlTemplate());
		context.PushParent(controlTemplate);
		controlTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_29.Build_12), context);
		context.PopParent();
		setter163.Value = value45;
		context.PopParent();
		style44.Add(setter162);
		context.PopParent();
		styles43.Add(item28);
		Styles styles44 = P_1.Styles;
		Style item29 = (style = new Style());
		context.PushParent(style);
		Style style45 = style;
		style45.Selector = ((Selector?)null).OfType(typeof(ComboBoxItem)).Class(":pointerover").Template()
			.OfType(typeof(Border))
			.Name("MacDropdownItem");
		Setter setter164 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter165 = setter2;
		setter165.Property = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension41 = new DynamicResourceExtension("MacroSurface");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value46 = dynamicResourceExtension41.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter165.Value = value46;
		context.PopParent();
		style45.Add(setter164);
		context.PopParent();
		styles44.Add(item29);
		Styles styles45 = P_1.Styles;
		Style item30 = (style = new Style());
		context.PushParent(style);
		Style style46 = style;
		style46.Selector = ((Selector?)null).OfType(typeof(ComboBoxItem)).Class(":selected").Template()
			.OfType(typeof(Border))
			.Name("MacDropdownItem");
		Setter setter166 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter167 = setter2;
		setter167.Property = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension42 = new DynamicResourceExtension("MacroSelection");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value47 = dynamicResourceExtension42.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter167.Value = value47;
		context.PopParent();
		style46.Add(setter166);
		context.PopParent();
		styles45.Add(item30);
		Styles styles46 = P_1.Styles;
		Style style47 = new Style();
		style47.Selector = ((Selector?)null).OfType(typeof(ComboBoxItem)).Class(":selected").Template()
			.OfType(typeof(Lucide))
			.Name("SelectedMark");
		Setter setter168 = new Setter();
		setter168.Property = Visual.IsVisibleProperty;
		setter168.Value = true;
		style47.Add(setter168);
		styles46.Add(style47);
		Styles styles47 = P_1.Styles;
		Style style48 = new Style();
		style48.Selector = ((Selector?)null).OfType(typeof(Border)).Name("ContentFrame");
		Setter setter169 = new Setter();
		setter169.Property = Decorator.PaddingProperty;
		setter169.Value = new Thickness(14.0, 12.0, 14.0, 12.0);
		style48.Add(setter169);
		styles47.Add(style48);
		Styles styles48 = P_1.Styles;
		Style style49 = new Style();
		style49.Selector = ((Selector?)null).OfType(typeof(Border)).Name("ContentFrame").Class("macro-page");
		Setter setter170 = new Setter();
		setter170.Property = Decorator.PaddingProperty;
		setter170.Value = new Thickness(14.0, 0.0, 14.0, 0.0);
		style49.Add(setter170);
		styles48.Add(style49);
		Styles styles49 = P_1.Styles;
		Style item31 = (style = new Style());
		context.PushParent(style);
		Style style50 = style;
		style50.Selector = ((Selector?)null).OfType(typeof(ScrollViewer)).Name("MacroListScroll").Template()
			.OfType(typeof(ScrollBar))
			.Class(":vertical");
		Setter setter171 = new Setter();
		setter171.Property = Layoutable.WidthProperty;
		setter171.Value = 12.0;
		style50.Add(setter171);
		Setter setter172 = new Setter();
		setter172.Property = TemplatedControl.BackgroundProperty;
		setter172.Value = new ImmutableSolidColorBrush(16777215u);
		style50.Add(setter172);
		Setter setter173 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter174 = setter2;
		setter174.Property = TemplatedControl.TemplateProperty;
		ControlTemplate value48 = (controlTemplate = new ControlTemplate());
		context.PushParent(controlTemplate);
		controlTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_29.Build_13), context);
		context.PopParent();
		setter174.Value = value48;
		context.PopParent();
		style50.Add(setter173);
		context.PopParent();
		styles49.Add(item31);
		Styles styles50 = P_1.Styles;
		Style item32 = (style = new Style());
		context.PushParent(style);
		Style style51 = style;
		style51.Selector = ((Selector?)null).OfType(typeof(CheckBox)).Class("macro-enable");
		Setter setter175 = new Setter();
		setter175.Property = Layoutable.WidthProperty;
		setter175.Value = 22.0;
		style51.Add(setter175);
		Setter setter176 = new Setter();
		setter176.Property = Layoutable.MinWidthProperty;
		setter176.Value = 0.0;
		style51.Add(setter176);
		Setter setter177 = new Setter();
		setter177.Property = Layoutable.HeightProperty;
		setter177.Value = 32.0;
		style51.Add(setter177);
		Setter setter178 = new Setter();
		setter178.Property = Layoutable.MinHeightProperty;
		setter178.Value = 0.0;
		style51.Add(setter178);
		Setter setter179 = new Setter();
		setter179.Property = InputElement.CursorProperty;
		setter179.Value = new Cursor(StandardCursorType.Hand);
		style51.Add(setter179);
		Setter setter180 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter181 = setter2;
		setter181.Property = TemplatedControl.TemplateProperty;
		ControlTemplate value49 = (controlTemplate = new ControlTemplate());
		context.PushParent(controlTemplate);
		controlTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_29.Build_17), context);
		context.PopParent();
		setter181.Value = value49;
		context.PopParent();
		style51.Add(setter180);
		context.PopParent();
		styles50.Add(item32);
		Styles styles51 = P_1.Styles;
		Style item33 = (style = new Style());
		context.PushParent(style);
		Style style52 = style;
		style52.Selector = ((Selector?)null).OfType(typeof(CheckBox)).Class("macro-enable").Class(":checked")
			.Template()
			.OfType(typeof(Border))
			.Name("MacroTickTarget");
		Setter setter182 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter183 = setter2;
		setter183.Property = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension43 = new DynamicResourceExtension("MacroAccent");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value50 = dynamicResourceExtension43.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter183.Value = value50;
		context.PopParent();
		style52.Add(setter182);
		context.PopParent();
		styles51.Add(item33);
		Styles styles52 = P_1.Styles;
		Style item34 = (style = new Style());
		context.PushParent(style);
		Style style53 = style;
		style53.Selector = ((Selector?)null).OfType(typeof(CheckBox)).Class("macro-enable").Class(":pointerover")
			.Template()
			.OfType(typeof(Border))
			.Name("MacroTickTarget");
		Setter setter184 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter185 = setter2;
		setter185.Property = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension44 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value51 = dynamicResourceExtension44.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter185.Value = value51;
		context.PopParent();
		style53.Add(setter184);
		context.PopParent();
		styles52.Add(item34);
		Styles styles53 = P_1.Styles;
		Style item35 = (style = new Style());
		context.PushParent(style);
		Style style54 = style;
		style54.Selector = ((Selector?)null).OfType(typeof(CheckBox)).Class("macro-enable").Class(":focus-visible")
			.Template()
			.OfType(typeof(Border))
			.Name("MacroTickTarget");
		Setter setter186 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter187 = setter2;
		setter187.Property = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension45 = new DynamicResourceExtension("MacroAccent");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value52 = dynamicResourceExtension45.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter187.Value = value52;
		context.PopParent();
		style54.Add(setter186);
		context.PopParent();
		styles53.Add(item35);
		Styles styles54 = P_1.Styles;
		Style style55 = new Style();
		style55.Selector = ((Selector?)null).OfType(typeof(CheckBox)).Class("macro-enable").Class(":checked")
			.Template()
			.OfType(typeof(Lucide))
			.Name("MacroCheckMark");
		Setter setter188 = new Setter();
		setter188.Property = Visual.OpacityProperty;
		setter188.Value = 1.0;
		style55.Add(setter188);
		styles54.Add(style55);
		Styles styles55 = P_1.Styles;
		Style style56 = new Style();
		style56.Selector = ((Selector?)null).OfType(typeof(CheckBox)).Class("macro-enable").Not(((Selector?)null).Class(":checked"))
			.Class(":pointerover")
			.Template()
			.OfType(typeof(Lucide))
			.Name("MacroCheckMark");
		Setter setter189 = new Setter();
		setter189.Property = Visual.OpacityProperty;
		setter189.Value = 0.35;
		style56.Add(setter189);
		styles55.Add(style56);
		Styles styles56 = P_1.Styles;
		Style style57 = new Style();
		style57.Selector = ((Selector?)null).OfType(typeof(CheckBox)).Class("macro-enable").Not(((Selector?)null).Class(":checked"))
			.Class(":focus-visible")
			.Template()
			.OfType(typeof(Lucide))
			.Name("MacroCheckMark");
		Setter setter190 = new Setter();
		setter190.Property = Visual.OpacityProperty;
		setter190.Value = 0.35;
		style57.Add(setter190);
		styles56.Add(style57);
		Styles styles57 = P_1.Styles;
		Style style58 = new Style();
		style58.Selector = ((Selector?)null).OfType(typeof(CheckBox)).Class("macro-enable").Class(":disabled");
		Setter setter191 = new Setter();
		setter191.Property = Visual.OpacityProperty;
		setter191.Value = 0.4;
		style58.Add(setter191);
		styles57.Add(style58);
		Styles styles58 = P_1.Styles;
		Style item36 = (style = new Style());
		context.PushParent(style);
		Style style59 = style;
		style59.Selector = ((Selector?)null).OfType(typeof(Border)).Class("macro-row");
		Setter setter192 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter193 = setter2;
		setter193.Property = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension46 = new DynamicResourceExtension("MacroSurface");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value53 = dynamicResourceExtension46.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter193.Value = value53;
		context.PopParent();
		style59.Add(setter192);
		Setter setter194 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter195 = setter2;
		setter195.Property = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension47 = new DynamicResourceExtension("MacroBorder");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value54 = dynamicResourceExtension47.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter195.Value = value54;
		context.PopParent();
		style59.Add(setter194);
		Setter setter196 = new Setter();
		setter196.Property = Border.BorderThicknessProperty;
		setter196.Value = new Thickness(0.0, 0.0, 0.0, 1.0);
		style59.Add(setter196);
		context.PopParent();
		styles58.Add(item36);
		Styles styles59 = P_1.Styles;
		Style style60 = new Style();
		style60.Selector = ((Selector?)null).OfType(typeof(Border)).Class("macro-row").Class("enabled");
		Setter setter197 = new Setter();
		setter197.Property = Border.BorderBrushProperty;
		setter197.Value = new ImmutableSolidColorBrush(4286831791u);
		style60.Add(setter197);
		Setter setter198 = new Setter();
		setter198.Property = Border.BorderThicknessProperty;
		setter198.Value = new Thickness(1.0, 1.0, 1.0, 1.0);
		style60.Add(setter198);
		styles59.Add(style60);
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		P_1.Content = border;
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Border border5 = border4;
		border5.Name = "GuiSurface";
		object element = border5;
		context.AvaloniaNameScope.Register("GuiSurface", element);
		border5.Margin = new Thickness(2.0, 2.0, 2.0, 2.0);
		border5.Padding = new Thickness(1.0, 1.0, 1.0, 1.0);
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension48 = new DynamicResourceExtension("MacroBackground");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding2 = dynamicResourceExtension48.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(backgroundProperty, binding2);
		StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension49 = new DynamicResourceExtension("MacroFrame");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding3 = dynamicResourceExtension49.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(borderBrushProperty, binding3);
		border5.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		border5.CornerRadius = new CornerRadius(12.0, 12.0, 12.0, 12.0);
		border5.ClipToBounds = true;
		border5.RenderTransformOrigin = new RelativePoint(0.5, 0.5, RelativeUnit.Relative);
		ScaleTransform scaleTransform = new ScaleTransform();
		scaleTransform.ScaleX = 1.0;
		scaleTransform.ScaleY = 1.0;
		border5.RenderTransform = scaleTransform;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		border5.Child = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(48.0, GridUnitType.Pixel)));
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid5.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid5.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children.Add(grid6);
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		Grid.SetRow(grid9, 0);
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 3;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(86.0, GridUnitType.Pixel)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(86.0, GridUnitType.Pixel)));
		grid9.ColumnDefinitions = columnDefinitions;
		grid9.Margin = new Thickness(14.0, 0.0, 14.0, 0.0);
		Avalonia.Controls.Controls children2 = grid9.Children;
		Border border7;
		Border border6 = (border7 = new Border());
		((ISupportInitialize)border6).BeginInit();
		children2.Add(border6);
		Grid.SetColumnSpan(border7, 3);
		border7.AddHandler(InputElement.PointerPressedEvent, context.RootObject.TitlePressed);
		border7.Background = new ImmutableSolidColorBrush(16777215u);
		((ISupportInitialize)border7).EndInit();
		Avalonia.Controls.Controls children3 = grid9.Children;
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		children3.Add(stackPanel);
		stackPanel2.Orientation = Orientation.Horizontal;
		stackPanel2.Spacing = 2.0;
		stackPanel2.VerticalAlignment = VerticalAlignment.Center;
		Avalonia.Controls.Controls children4 = stackPanel2.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children4.Add(button);
		button2.Name = "CloseButton";
		element = button2;
		context.AvaloniaNameScope.Register("CloseButton", element);
		button2.Classes.Add("chrome-dot");
		button2.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.CloseClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		AutomationProperties.SetName(button2, "Hide macro GUI");
		ToolTip.SetTip(button2, "Hide GUI");
		Grid grid11;
		Grid grid10 = (grid11 = new Grid());
		((ISupportInitialize)grid10).BeginInit();
		button2.Content = grid10;
		Avalonia.Controls.Controls children5 = grid11.Children;
		Ellipse ellipse2;
		Ellipse ellipse = (ellipse2 = new Ellipse());
		((ISupportInitialize)ellipse).BeginInit();
		children5.Add(ellipse);
		ellipse2.Width = 13.0;
		ellipse2.Height = 13.0;
		ellipse2.Fill = new ImmutableSolidColorBrush(4294926167u);
		((ISupportInitialize)ellipse2).EndInit();
		Avalonia.Controls.Controls children6 = grid11.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children6.Add(textBlock);
		textBlock2.Classes.Add("chrome-glyph");
		textBlock2.Text = "×";
		textBlock2.FontSize = 13.0;
		textBlock2.Foreground = new ImmutableSolidColorBrush(4283573796u);
		textBlock2.HorizontalAlignment = HorizontalAlignment.Center;
		textBlock2.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)textBlock2).EndInit();
		((ISupportInitialize)grid11).EndInit();
		((ISupportInitialize)button2).EndInit();
		Avalonia.Controls.Controls children7 = stackPanel2.Children;
		Button button5;
		Button button4 = (button5 = new Button());
		((ISupportInitialize)button4).BeginInit();
		children7.Add(button4);
		button5.Name = "MinimizeButton";
		element = button5;
		context.AvaloniaNameScope.Register("MinimizeButton", element);
		button5.Classes.Add("chrome-dot");
		button5.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.CloseClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		AutomationProperties.SetName(button5, "Return to game");
		ToolTip.SetTip(button5, "Return to game");
		Grid grid13;
		Grid grid12 = (grid13 = new Grid());
		((ISupportInitialize)grid12).BeginInit();
		button5.Content = grid12;
		Avalonia.Controls.Controls children8 = grid13.Children;
		Ellipse ellipse4;
		Ellipse ellipse3 = (ellipse4 = new Ellipse());
		((ISupportInitialize)ellipse3).BeginInit();
		children8.Add(ellipse3);
		ellipse4.Width = 13.0;
		ellipse4.Height = 13.0;
		ellipse4.Fill = new ImmutableSolidColorBrush(4294884398u);
		((ISupportInitialize)ellipse4).EndInit();
		Avalonia.Controls.Controls children9 = grid13.Children;
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		children9.Add(textBlock3);
		textBlock4.Classes.Add("chrome-glyph");
		textBlock4.Text = "−";
		textBlock4.FontSize = 13.0;
		textBlock4.Foreground = new ImmutableSolidColorBrush(4284171032u);
		textBlock4.HorizontalAlignment = HorizontalAlignment.Center;
		textBlock4.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)textBlock4).EndInit();
		((ISupportInitialize)grid13).EndInit();
		((ISupportInitialize)button5).EndInit();
		Avalonia.Controls.Controls children10 = stackPanel2.Children;
		Button button7;
		Button button6 = (button7 = new Button());
		((ISupportInitialize)button6).BeginInit();
		children10.Add(button6);
		button7.Name = "ExpandButton";
		element = button7;
		context.AvaloniaNameScope.Register("ExpandButton", element);
		button7.Classes.Add("chrome-dot");
		button7.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.ExpandClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		AutomationProperties.SetName(button7, "Expand or restore macro GUI");
		ToolTip.SetTip(button7, "Expand or restore");
		Grid grid15;
		Grid grid14 = (grid15 = new Grid());
		((ISupportInitialize)grid14).BeginInit();
		button7.Content = grid14;
		Avalonia.Controls.Controls children11 = grid15.Children;
		Ellipse ellipse6;
		Ellipse ellipse5 = (ellipse6 = new Ellipse());
		((ISupportInitialize)ellipse5).BeginInit();
		children11.Add(ellipse5);
		ellipse6.Width = 13.0;
		ellipse6.Height = 13.0;
		ellipse6.Fill = new ImmutableSolidColorBrush(4280862784u);
		((ISupportInitialize)ellipse6).EndInit();
		Avalonia.Controls.Controls children12 = grid15.Children;
		TextBlock textBlock6;
		TextBlock textBlock5 = (textBlock6 = new TextBlock());
		((ISupportInitialize)textBlock5).BeginInit();
		children12.Add(textBlock5);
		textBlock6.Classes.Add("chrome-glyph");
		textBlock6.Text = "+";
		textBlock6.FontSize = 12.0;
		textBlock6.Foreground = new ImmutableSolidColorBrush(4279785251u);
		textBlock6.HorizontalAlignment = HorizontalAlignment.Center;
		textBlock6.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)textBlock6).EndInit();
		((ISupportInitialize)grid15).EndInit();
		((ISupportInitialize)button7).EndInit();
		((ISupportInitialize)stackPanel2).EndInit();
		Avalonia.Controls.Controls children13 = grid9.Children;
		Border border9;
		Border border8 = (border9 = new Border());
		((ISupportInitialize)border8).BeginInit();
		children13.Add(border8);
		Border border10 = (border4 = border9);
		context.PushParent(border4);
		Border border11 = border4;
		border11.Name = "SearchSurface";
		element = border11;
		context.AvaloniaNameScope.Register("SearchSurface", element);
		Grid.SetColumn(border11, 1);
		Grid.SetColumnSpan(border11, 2);
		border11.Width = 30.0;
		border11.Height = 32.0;
		border11.HorizontalAlignment = HorizontalAlignment.Right;
		border11.VerticalAlignment = VerticalAlignment.Center;
		border11.CornerRadius = new CornerRadius(8.0, 8.0, 8.0, 8.0);
		border11.ClipToBounds = true;
		border11.Background = new ImmutableSolidColorBrush(16777215u);
		border11.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
		Transitions transitions = new Transitions();
		DoubleTransition doubleTransition = new DoubleTransition();
		doubleTransition.Property = Layoutable.WidthProperty;
		doubleTransition.Duration = TimeSpan.FromTicks(2400000L);
		doubleTransition.Easing = Easing.Parse("CubicEaseOut");
		transitions.Add(doubleTransition);
		border11.Transitions = transitions;
		Grid grid17;
		Grid grid16 = (grid17 = new Grid());
		((ISupportInitialize)grid16).BeginInit();
		border11.Child = grid16;
		Grid grid18 = (grid4 = grid17);
		context.PushParent(grid4);
		Grid grid19 = grid4;
		grid19.Width = 250.0;
		ColumnDefinitions columnDefinitions2 = new ColumnDefinitions();
		columnDefinitions2.Capacity = 2;
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(220.0, GridUnitType.Pixel)));
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(30.0, GridUnitType.Pixel)));
		grid19.ColumnDefinitions = columnDefinitions2;
		grid19.HorizontalAlignment = HorizontalAlignment.Right;
		Avalonia.Controls.Controls children14 = grid19.Children;
		TextBox textBox2;
		TextBox textBox = (textBox2 = new TextBox());
		((ISupportInitialize)textBox).BeginInit();
		children14.Add(textBox);
		TextBox textBox4;
		TextBox textBox3 = (textBox4 = textBox2);
		context.PushParent(textBox4);
		TextBox textBox5 = textBox4;
		textBox5.Name = "SearchBox";
		element = textBox5;
		context.AvaloniaNameScope.Register("SearchBox", element);
		StyledProperty<string?> textProperty = TextBox.TextProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002ESearch_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = TextBox.TextProperty;
		CompiledBinding binding4 = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBox5.Bind(textProperty, binding4);
		textBox5.IsVisible = false;
		textBox5.Width = 0.0;
		textBox5.Height = 30.0;
		textBox5.MinHeight = 0.0;
		textBox5.MinWidth = 0.0;
		textBox5.Padding = new Thickness(10.0, 0.0, 10.0, 0.0);
		textBox5.VerticalContentAlignment = VerticalAlignment.Center;
		textBox5.PlaceholderText = "Search macros";
		textBox5.FontSize = 12.0;
		textBox5.AddHandler(InputElement.KeyDownEvent, context.RootObject.SearchKeyDown);
		AutomationProperties.SetName(textBox5, "Search macros");
		context.PopParent();
		((ISupportInitialize)textBox3).EndInit();
		Avalonia.Controls.Controls children15 = grid19.Children;
		ToggleButton toggleButton2;
		ToggleButton toggleButton = (toggleButton2 = new ToggleButton());
		((ISupportInitialize)toggleButton).BeginInit();
		children15.Add(toggleButton);
		ToggleButton toggleButton4;
		ToggleButton toggleButton3 = (toggleButton4 = toggleButton2);
		context.PushParent(toggleButton4);
		ToggleButton toggleButton5 = toggleButton4;
		toggleButton5.Name = "SearchToggle";
		element = toggleButton5;
		context.AvaloniaNameScope.Register("SearchToggle", element);
		Grid.SetColumn(toggleButton5, 1);
		toggleButton5.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.SearchToggleClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		toggleButton5.Width = 30.0;
		toggleButton5.Height = 30.0;
		toggleButton5.MinWidth = 0.0;
		toggleButton5.MinHeight = 0.0;
		toggleButton5.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
		toggleButton5.Background = new ImmutableSolidColorBrush(16777215u);
		toggleButton5.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
		AutomationProperties.SetName(toggleButton5, "Expand or collapse macro search");
		ToolTip.SetTip(toggleButton5, "Search macros");
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		toggleButton5.Content = lucide;
		Lucide lucide4;
		Lucide lucide3 = (lucide4 = lucide2);
		context.PushParent(lucide4);
		Lucide lucide5 = lucide4;
		lucide5.Icon = LucideIconNames.Search;
		lucide5.Width = 15.0;
		lucide5.Height = 15.0;
		StyledProperty<IBrush?> strokeBrushProperty = Lucide.StrokeBrushProperty;
		DynamicResourceExtension dynamicResourceExtension50 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
		BindingBase binding5 = dynamicResourceExtension50.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide5.Bind(strokeBrushProperty, binding5);
		context.PopParent();
		((ISupportInitialize)lucide3).EndInit();
		context.PopParent();
		((ISupportInitialize)toggleButton3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid18).EndInit();
		context.PopParent();
		((ISupportInitialize)border10).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		Avalonia.Controls.Controls children16 = grid5.Children;
		Grid grid21;
		Grid grid20 = (grid21 = new Grid());
		((ISupportInitialize)grid20).BeginInit();
		children16.Add(grid20);
		Grid grid22 = (grid4 = grid21);
		context.PushParent(grid4);
		Grid grid23 = grid4;
		Grid.SetRow(grid23, 1);
		ColumnDefinitions columnDefinitions3 = new ColumnDefinitions();
		columnDefinitions3.Capacity = 3;
		columnDefinitions3.Add(new ColumnDefinition(new GridLength(142.0, GridUnitType.Pixel)));
		columnDefinitions3.Add(new ColumnDefinition(new GridLength(12.0, GridUnitType.Pixel)));
		columnDefinitions3.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid23.ColumnDefinitions = columnDefinitions3;
		grid23.Margin = new Thickness(12.0, 0.0, 12.0, 12.0);
		Avalonia.Controls.Controls children17 = grid23.Children;
		Border border13;
		Border border12 = (border13 = new Border());
		((ISupportInitialize)border12).BeginInit();
		children17.Add(border12);
		Border border14 = (border4 = border13);
		context.PushParent(border4);
		Border border15 = border4;
		border15.Name = "SidebarFrame";
		element = border15;
		context.AvaloniaNameScope.Register("SidebarFrame", element);
		StyledProperty<IBrush?> backgroundProperty2 = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension51 = new DynamicResourceExtension("MacroHeader");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding6 = dynamicResourceExtension51.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border15.Bind(backgroundProperty2, binding6);
		StyledProperty<IBrush?> borderBrushProperty2 = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension52 = new DynamicResourceExtension("MacroBorder");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding7 = dynamicResourceExtension52.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border15.Bind(borderBrushProperty2, binding7);
		border15.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		border15.CornerRadius = new CornerRadius(6.0, 6.0, 6.0, 6.0);
		border15.Padding = new Thickness(6.0, 6.0, 6.0, 6.0);
		ListBox listBox2;
		ListBox listBox = (listBox2 = new ListBox());
		((ISupportInitialize)listBox).BeginInit();
		border15.Child = listBox;
		ListBox listBox4;
		ListBox listBox3 = (listBox4 = listBox2);
		context.PushParent(listBox4);
		listBox4.Name = "CategoryList";
		element = listBox4;
		context.AvaloniaNameScope.Register("CategoryList", element);
		StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002ECategories_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding8 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		listBox4.Bind(itemsSourceProperty, binding8);
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002ESelectedCategory_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = SelectingItemsControl.SelectedItemProperty;
		CompiledBinding compiledBinding = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_10(listBox4, compiledBinding);
		listBox4.Background = new ImmutableSolidColorBrush(16777215u);
		listBox4.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
		listBox4.FontSize = 12.0;
		AutomationProperties.SetName(listBox4, "Macro categories");
		DataTemplate dataTemplate;
		DataTemplate itemTemplate = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		DataTemplate dataTemplate2 = dataTemplate;
		dataTemplate2.DataType = typeof(string);
		dataTemplate2.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_29.Build_18), context);
		context.PopParent();
		listBox4.ItemTemplate = itemTemplate;
		context.PopParent();
		((ISupportInitialize)listBox3).EndInit();
		context.PopParent();
		((ISupportInitialize)border14).EndInit();
		Avalonia.Controls.Controls children18 = grid23.Children;
		Border border17;
		Border border16 = (border17 = new Border());
		((ISupportInitialize)border16).BeginInit();
		children18.Add(border16);
		Border border18 = (border4 = border17);
		context.PushParent(border4);
		Border border19 = border4;
		border19.Name = "ContentFrame";
		element = border19;
		context.AvaloniaNameScope.Register("ContentFrame", element);
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EIsMacroPage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = "class:macro-page";
		CompiledBinding compiledBinding2 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		BindingBase source = compiledBinding2;
		border19.BindClass("macro-page", source, null);
		Grid.SetColumn(border19, 2);
		StyledProperty<IBrush?> backgroundProperty3 = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension53 = new DynamicResourceExtension("MacroInterior");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding9 = dynamicResourceExtension53.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border19.Bind(backgroundProperty3, binding9);
		StyledProperty<IBrush?> borderBrushProperty3 = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension54 = new DynamicResourceExtension("MacroBorder");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding10 = dynamicResourceExtension54.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border19.Bind(borderBrushProperty3, binding10);
		border19.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		border19.CornerRadius = new CornerRadius(8.0, 8.0, 8.0, 8.0);
		Grid grid25;
		Grid grid24 = (grid25 = new Grid());
		((ISupportInitialize)grid24).BeginInit();
		border19.Child = grid24;
		Grid grid26 = (grid4 = grid25);
		context.PushParent(grid4);
		Avalonia.Controls.Controls children19 = grid4.Children;
		Grid grid28;
		Grid grid27 = (grid28 = new Grid());
		((ISupportInitialize)grid27).BeginInit();
		children19.Add(grid27);
		Grid grid29 = (grid4 = grid28);
		context.PushParent(grid4);
		Grid grid30 = grid4;
		Avalonia.Controls.Controls children20 = grid30.Children;
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		children20.Add(scrollViewer);
		ScrollViewer scrollViewer4;
		ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
		context.PushParent(scrollViewer4);
		ScrollViewer scrollViewer5 = scrollViewer4;
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EIsSettingsPage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding11 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		scrollViewer5.Bind(isVisibleProperty, binding11);
		scrollViewer5.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
		scrollViewer5.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
		Border border21;
		Border border20 = (border21 = new Border());
		((ISupportInitialize)border20).BeginInit();
		scrollViewer5.Content = border20;
		Border border22 = (border4 = border21);
		context.PushParent(border4);
		Border border23 = border4;
		StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EIsSettingsPage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding12 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border23.Bind(isVisibleProperty2, binding12);
		StyledProperty<IBrush?> backgroundProperty4 = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension55 = new DynamicResourceExtension("MacroSurface");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding13 = dynamicResourceExtension55.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border23.Bind(backgroundProperty4, binding13);
		StyledProperty<IBrush?> borderBrushProperty4 = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension56 = new DynamicResourceExtension("MacroBorder");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding14 = dynamicResourceExtension56.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border23.Bind(borderBrushProperty4, binding14);
		border23.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		border23.CornerRadius = new CornerRadius(0.0, 0.0, 0.0, 0.0);
		border23.ClipToBounds = true;
		border23.Margin = new Thickness(2.0, 0.0, 2.0, 0.0);
		border23.VerticalAlignment = VerticalAlignment.Top;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = new StackPanel());
		((ISupportInitialize)stackPanel3).BeginInit();
		border23.Child = stackPanel3;
		StackPanel stackPanel6;
		StackPanel stackPanel5 = (stackPanel6 = stackPanel4);
		context.PushParent(stackPanel6);
		StackPanel stackPanel7 = stackPanel6;
		stackPanel7.Name = "SettingsPanel";
		element = stackPanel7;
		context.AvaloniaNameScope.Register("SettingsPanel", element);
		StyledProperty<bool> isVisibleProperty3 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EIsSettingsPage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding15 = compiledBindingExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		stackPanel7.Bind(isVisibleProperty3, binding15);
		stackPanel7.Spacing = 0.0;
		Avalonia.Controls.Controls children21 = stackPanel7.Children;
		Border border25;
		Border border24 = (border25 = new Border());
		((ISupportInitialize)border24).BeginInit();
		children21.Add(border24);
		Border border26 = (border4 = border25);
		context.PushParent(border4);
		Border border27 = border4;
		border27.Classes.Add("settings-card");
		Grid grid32;
		Grid grid31 = (grid32 = new Grid());
		((ISupportInitialize)grid31).BeginInit();
		border27.Child = grid31;
		Grid grid33 = (grid4 = grid32);
		context.PushParent(grid4);
		Grid grid34 = grid4;
		ColumnDefinitions columnDefinitions4 = new ColumnDefinitions();
		columnDefinitions4.Capacity = 3;
		columnDefinitions4.Add(new ColumnDefinition(new GridLength(28.0, GridUnitType.Pixel)));
		columnDefinitions4.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions4.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid34.ColumnDefinitions = columnDefinitions4;
		grid34.Height = 34.0;
		Avalonia.Controls.Controls children22 = grid34.Children;
		Lucide lucide7;
		Lucide lucide6 = (lucide7 = new Lucide());
		((ISupportInitialize)lucide6).BeginInit();
		children22.Add(lucide6);
		Lucide lucide8 = (lucide4 = lucide7);
		context.PushParent(lucide4);
		Lucide lucide9 = lucide4;
		lucide9.Icon = LucideIconNames.Keyboard;
		lucide9.Width = 18.0;
		lucide9.Height = 18.0;
		StyledProperty<IBrush?> strokeBrushProperty2 = Lucide.StrokeBrushProperty;
		DynamicResourceExtension dynamicResourceExtension57 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
		BindingBase binding16 = dynamicResourceExtension57.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide9.Bind(strokeBrushProperty2, binding16);
		lucide9.VerticalAlignment = VerticalAlignment.Center;
		context.PopParent();
		((ISupportInitialize)lucide8).EndInit();
		Avalonia.Controls.Controls children23 = grid34.Children;
		TextBlock textBlock8;
		TextBlock textBlock7 = (textBlock8 = new TextBlock());
		((ISupportInitialize)textBlock7).BeginInit();
		children23.Add(textBlock7);
		Grid.SetColumn(textBlock8, 1);
		textBlock8.Text = "GUI keybind";
		textBlock8.VerticalAlignment = VerticalAlignment.Center;
		textBlock8.FontSize = 13.0;
		((ISupportInitialize)textBlock8).EndInit();
		Avalonia.Controls.Controls children24 = grid34.Children;
		KeybindButton keybindButton2;
		KeybindButton keybindButton = (keybindButton2 = new KeybindButton());
		((ISupportInitialize)keybindButton).BeginInit();
		children24.Add(keybindButton);
		KeybindButton keybindButton4;
		KeybindButton keybindButton3 = (keybindButton4 = keybindButton2);
		context.PushParent(keybindButton4);
		keybindButton4.Name = "GuiKeybindPicker";
		element = keybindButton4;
		context.AvaloniaNameScope.Register("GuiKeybindPicker", element);
		Grid.SetColumn(keybindButton4, 2);
		keybindButton4.Height = 32.0;
		keybindButton4.HorizontalAlignment = HorizontalAlignment.Right;
		StyledProperty<string> valueProperty = KeybindButton.ValueProperty;
		CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EGuiKeybind_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = KeybindButton.ValueProperty;
		CompiledBinding binding17 = compiledBindingExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		keybindButton4.Bind(valueProperty, binding17);
		AutomationProperties.SetName(keybindButton4, "Show or hide macro GUI hotkey");
		context.PopParent();
		((ISupportInitialize)keybindButton3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid33).EndInit();
		context.PopParent();
		((ISupportInitialize)border26).EndInit();
		Avalonia.Controls.Controls children25 = stackPanel7.Children;
		Border border29;
		Border border28 = (border29 = new Border());
		((ISupportInitialize)border28).BeginInit();
		children25.Add(border28);
		Border border30 = (border4 = border29);
		context.PushParent(border4);
		Border border31 = border4;
		border31.Classes.Add("settings-card");
		Grid grid36;
		Grid grid35 = (grid36 = new Grid());
		((ISupportInitialize)grid35).BeginInit();
		border31.Child = grid35;
		Grid grid37 = (grid4 = grid36);
		context.PushParent(grid4);
		Grid grid38 = grid4;
		ColumnDefinitions columnDefinitions5 = new ColumnDefinitions();
		columnDefinitions5.Capacity = 3;
		columnDefinitions5.Add(new ColumnDefinition(new GridLength(28.0, GridUnitType.Pixel)));
		columnDefinitions5.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions5.Add(new ColumnDefinition(new GridLength(190.0, GridUnitType.Pixel)));
		grid38.ColumnDefinitions = columnDefinitions5;
		grid38.Height = 34.0;
		Avalonia.Controls.Controls children26 = grid38.Children;
		Lucide lucide11;
		Lucide lucide10 = (lucide11 = new Lucide());
		((ISupportInitialize)lucide10).BeginInit();
		children26.Add(lucide10);
		Lucide lucide12 = (lucide4 = lucide11);
		context.PushParent(lucide4);
		Lucide lucide13 = lucide4;
		lucide13.Icon = LucideIconNames.Palette;
		lucide13.Width = 18.0;
		lucide13.Height = 18.0;
		StyledProperty<IBrush?> strokeBrushProperty3 = Lucide.StrokeBrushProperty;
		DynamicResourceExtension dynamicResourceExtension58 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
		BindingBase binding18 = dynamicResourceExtension58.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide13.Bind(strokeBrushProperty3, binding18);
		lucide13.VerticalAlignment = VerticalAlignment.Center;
		context.PopParent();
		((ISupportInitialize)lucide12).EndInit();
		Avalonia.Controls.Controls children27 = grid38.Children;
		TextBlock textBlock10;
		TextBlock textBlock9 = (textBlock10 = new TextBlock());
		((ISupportInitialize)textBlock9).BeginInit();
		children27.Add(textBlock9);
		Grid.SetColumn(textBlock10, 1);
		textBlock10.Text = "Theme";
		textBlock10.VerticalAlignment = VerticalAlignment.Center;
		textBlock10.FontSize = 13.0;
		((ISupportInitialize)textBlock10).EndInit();
		Avalonia.Controls.Controls children28 = grid38.Children;
		ComboBox comboBox2;
		ComboBox comboBox = (comboBox2 = new ComboBox());
		((ISupportInitialize)comboBox).BeginInit();
		children28.Add(comboBox);
		ComboBox comboBox4;
		ComboBox comboBox3 = (comboBox4 = comboBox2);
		context.PushParent(comboBox4);
		ComboBox comboBox5 = comboBox4;
		comboBox5.Name = "ThemePicker";
		element = comboBox5;
		context.AvaloniaNameScope.Register("ThemePicker", element);
		Grid.SetColumn(comboBox5, 2);
		StyledProperty<IEnumerable?> itemsSourceProperty2 = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EGuiThemes_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding19 = compiledBindingExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		comboBox5.Bind(itemsSourceProperty2, binding19);
		CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EGuiTheme_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = SelectingItemsControl.SelectedItemProperty;
		CompiledBinding compiledBinding3 = compiledBindingExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_10(comboBox5, compiledBinding3);
		comboBox5.Height = 34.0;
		comboBox5.HorizontalAlignment = HorizontalAlignment.Stretch;
		AutomationProperties.SetName(comboBox5, "Macro GUI theme");
		context.PopParent();
		((ISupportInitialize)comboBox3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid37).EndInit();
		context.PopParent();
		((ISupportInitialize)border30).EndInit();
		Avalonia.Controls.Controls children29 = stackPanel7.Children;
		Border border33;
		Border border32 = (border33 = new Border());
		((ISupportInitialize)border32).BeginInit();
		children29.Add(border32);
		Border border34 = (border4 = border33);
		context.PushParent(border4);
		Border border35 = border4;
		border35.Classes.Add("settings-card");
		StackPanel stackPanel9;
		StackPanel stackPanel8 = (stackPanel9 = new StackPanel());
		((ISupportInitialize)stackPanel8).BeginInit();
		border35.Child = stackPanel8;
		StackPanel stackPanel10 = (stackPanel6 = stackPanel9);
		context.PushParent(stackPanel6);
		StackPanel stackPanel11 = stackPanel6;
		stackPanel11.Spacing = 12.0;
		Avalonia.Controls.Controls children30 = stackPanel11.Children;
		Grid grid40;
		Grid grid39 = (grid40 = new Grid());
		((ISupportInitialize)grid39).BeginInit();
		children30.Add(grid39);
		Grid grid41 = (grid4 = grid40);
		context.PushParent(grid4);
		Grid grid42 = grid4;
		ColumnDefinitions columnDefinitions6 = new ColumnDefinitions();
		columnDefinitions6.Capacity = 3;
		columnDefinitions6.Add(new ColumnDefinition(new GridLength(28.0, GridUnitType.Pixel)));
		columnDefinitions6.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions6.Add(new ColumnDefinition(new GridLength(190.0, GridUnitType.Pixel)));
		grid42.ColumnDefinitions = columnDefinitions6;
		grid42.Height = 34.0;
		Avalonia.Controls.Controls children31 = grid42.Children;
		Lucide lucide15;
		Lucide lucide14 = (lucide15 = new Lucide());
		((ISupportInitialize)lucide14).BeginInit();
		children31.Add(lucide14);
		Lucide lucide16 = (lucide4 = lucide15);
		context.PushParent(lucide4);
		Lucide lucide17 = lucide4;
		lucide17.Icon = LucideIconNames.Layers;
		lucide17.Width = 18.0;
		lucide17.Height = 18.0;
		StyledProperty<IBrush?> strokeBrushProperty4 = Lucide.StrokeBrushProperty;
		DynamicResourceExtension dynamicResourceExtension59 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
		BindingBase binding20 = dynamicResourceExtension59.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide17.Bind(strokeBrushProperty4, binding20);
		lucide17.VerticalAlignment = VerticalAlignment.Center;
		context.PopParent();
		((ISupportInitialize)lucide16).EndInit();
		Avalonia.Controls.Controls children32 = grid42.Children;
		TextBlock textBlock12;
		TextBlock textBlock11 = (textBlock12 = new TextBlock());
		((ISupportInitialize)textBlock11).BeginInit();
		children32.Add(textBlock11);
		Grid.SetColumn(textBlock12, 1);
		textBlock12.Text = "Preset";
		textBlock12.VerticalAlignment = VerticalAlignment.Center;
		textBlock12.FontSize = 13.0;
		((ISupportInitialize)textBlock12).EndInit();
		Avalonia.Controls.Controls children33 = grid42.Children;
		Border border37;
		Border border36 = (border37 = new Border());
		((ISupportInitialize)border36).BeginInit();
		children33.Add(border36);
		Border border38 = (border4 = border37);
		context.PushParent(border4);
		Border border39 = border4;
		Grid.SetColumn(border39, 2);
		StyledProperty<IBrush?> backgroundProperty5 = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension60 = new DynamicResourceExtension("MacroTextField");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding21 = dynamicResourceExtension60.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border39.Bind(backgroundProperty5, binding21);
		StyledProperty<IBrush?> borderBrushProperty5 = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension61 = new DynamicResourceExtension("MacroBorder");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding22 = dynamicResourceExtension61.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border39.Bind(borderBrushProperty5, binding22);
		border39.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		Grid grid44;
		Grid grid43 = (grid44 = new Grid());
		((ISupportInitialize)grid43).BeginInit();
		border39.Child = grid43;
		Grid grid45 = (grid4 = grid44);
		context.PushParent(grid4);
		Grid grid46 = grid4;
		ColumnDefinitions columnDefinitions7 = new ColumnDefinitions();
		columnDefinitions7.Capacity = 3;
		columnDefinitions7.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions7.Add(new ColumnDefinition(new GridLength(28.0, GridUnitType.Pixel)));
		columnDefinitions7.Add(new ColumnDefinition(new GridLength(28.0, GridUnitType.Pixel)));
		grid46.ColumnDefinitions = columnDefinitions7;
		Avalonia.Controls.Controls children34 = grid46.Children;
		ComboBox comboBox7;
		ComboBox comboBox6 = (comboBox7 = new ComboBox());
		((ISupportInitialize)comboBox6).BeginInit();
		children34.Add(comboBox6);
		ComboBox comboBox8 = (comboBox4 = comboBox7);
		context.PushParent(comboBox4);
		ComboBox comboBox9 = comboBox4;
		comboBox9.Name = "PresetSelector";
		element = comboBox9;
		context.AvaloniaNameScope.Register("PresetSelector", element);
		Grid.SetColumnSpan(comboBox9, 3);
		Grid.SetColumn(comboBox9, 0);
		StyledProperty<IEnumerable?> itemsSourceProperty3 = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EProfiles_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding23 = compiledBindingExtension11.ProvideValue(context);
		context.ProvideTargetProperty = null;
		comboBox9.Bind(itemsSourceProperty3, binding23);
		DirectProperty<SelectingItemsControl, int> selectedIndexProperty = SelectingItemsControl.SelectedIndexProperty;
		CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002ESelectedProfileIndex_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = SelectingItemsControl.SelectedIndexProperty;
		CompiledBinding binding24 = compiledBindingExtension12.ProvideValue(context);
		context.ProvideTargetProperty = null;
		comboBox9.Bind(selectedIndexProperty, binding24);
		comboBox9.Height = 32.0;
		comboBox9.Background = new ImmutableSolidColorBrush(16777215u);
		comboBox9.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
		comboBox9.HorizontalAlignment = HorizontalAlignment.Stretch;
		comboBox9.FontSize = 12.0;
		AutomationProperties.SetName(comboBox9, "Active preset");
		context.PopParent();
		((ISupportInitialize)comboBox8).EndInit();
		Avalonia.Controls.Controls children35 = grid46.Children;
		TextBox textBox7;
		TextBox textBox6 = (textBox7 = new TextBox());
		((ISupportInitialize)textBox6).BeginInit();
		children35.Add(textBox6);
		TextBox textBox8 = (textBox4 = textBox7);
		context.PushParent(textBox4);
		TextBox textBox9 = textBox4;
		textBox9.Name = "PresetNameBox";
		element = textBox9;
		context.AvaloniaNameScope.Register("PresetNameBox", element);
		Grid.SetColumn(textBox9, 0);
		StyledProperty<bool> isVisibleProperty4 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().ElementName(context.AvaloniaNameScope, "RenameToggle").Property(ToggleButton.IsCheckedProperty, PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding25 = compiledBindingExtension13.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBox9.Bind(isVisibleProperty4, binding25);
		StyledProperty<string?> textProperty2 = TextBox.TextProperty;
		CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EPresetName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = TextBox.TextProperty;
		CompiledBinding binding26 = compiledBindingExtension14.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBox9.Bind(textProperty2, binding26);
		textBox9.Height = 32.0;
		textBox9.MinHeight = 0.0;
		StyledProperty<IBrush?> backgroundProperty6 = TemplatedControl.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension62 = new DynamicResourceExtension("MacroTextField");
		context.ProvideTargetProperty = TemplatedControl.BackgroundProperty;
		BindingBase binding27 = dynamicResourceExtension62.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBox9.Bind(backgroundProperty6, binding27);
		textBox9.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
		textBox9.CornerRadius = new CornerRadius(0.0, 0.0, 0.0, 0.0);
		textBox9.Padding = new Thickness(10.0, 5.0, 10.0, 5.0);
		textBox9.FontSize = 12.0;
		textBox9.MaxLength = 48;
		AutomationProperties.SetName(textBox9, "Preset name");
		ControlTemplate template = (controlTemplate = new ControlTemplate());
		context.PushParent(controlTemplate);
		controlTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_29.Build_19), context);
		context.PopParent();
		textBox9.Template = template;
		context.PopParent();
		((ISupportInitialize)textBox8).EndInit();
		Avalonia.Controls.Controls children36 = grid46.Children;
		ToggleButton toggleButton7;
		ToggleButton toggleButton6 = (toggleButton7 = new ToggleButton());
		((ISupportInitialize)toggleButton6).BeginInit();
		children36.Add(toggleButton6);
		ToggleButton toggleButton8 = (toggleButton4 = toggleButton7);
		context.PushParent(toggleButton4);
		ToggleButton toggleButton9 = toggleButton4;
		toggleButton9.Classes.Add("disclosure");
		toggleButton9.Name = "RenameToggle";
		element = toggleButton9;
		context.AvaloniaNameScope.Register("RenameToggle", element);
		toggleButton9.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.RenamePresetClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		Grid.SetColumn(toggleButton9, 1);
		toggleButton9.Width = 24.0;
		toggleButton9.Height = 28.0;
		toggleButton9.MinWidth = 0.0;
		toggleButton9.MinHeight = 0.0;
		toggleButton9.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
		toggleButton9.Background = new ImmutableSolidColorBrush(16777215u);
		toggleButton9.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
		ToolTip.SetTip(toggleButton9, "Rename preset");
		AutomationProperties.SetName(toggleButton9, "Rename preset");
		Lucide lucide19;
		Lucide lucide18 = (lucide19 = new Lucide());
		((ISupportInitialize)lucide18).BeginInit();
		toggleButton9.Content = lucide18;
		Lucide lucide20 = (lucide4 = lucide19);
		context.PushParent(lucide4);
		Lucide lucide21 = lucide4;
		lucide21.Icon = LucideIconNames.Pencil;
		lucide21.Width = 14.0;
		lucide21.Height = 14.0;
		StyledProperty<IBrush?> strokeBrushProperty5 = Lucide.StrokeBrushProperty;
		DynamicResourceExtension dynamicResourceExtension63 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
		BindingBase binding28 = dynamicResourceExtension63.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide21.Bind(strokeBrushProperty5, binding28);
		context.PopParent();
		((ISupportInitialize)lucide20).EndInit();
		context.PopParent();
		((ISupportInitialize)toggleButton8).EndInit();
		context.PopParent();
		((ISupportInitialize)grid45).EndInit();
		context.PopParent();
		((ISupportInitialize)border38).EndInit();
		context.PopParent();
		((ISupportInitialize)grid41).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel10).EndInit();
		context.PopParent();
		((ISupportInitialize)border34).EndInit();
		Avalonia.Controls.Controls children37 = stackPanel7.Children;
		Border border41;
		Border border40 = (border41 = new Border());
		((ISupportInitialize)border40).BeginInit();
		children37.Add(border40);
		Border border42 = (border4 = border41);
		context.PushParent(border4);
		Border border43 = border4;
		border43.Classes.Add("settings-card");
		Grid grid48;
		Grid grid47 = (grid48 = new Grid());
		((ISupportInitialize)grid47).BeginInit();
		border43.Child = grid47;
		Grid grid49 = (grid4 = grid48);
		context.PushParent(grid4);
		Grid grid50 = grid4;
		ColumnDefinitions columnDefinitions8 = new ColumnDefinitions();
		columnDefinitions8.Capacity = 3;
		columnDefinitions8.Add(new ColumnDefinition(new GridLength(28.0, GridUnitType.Pixel)));
		columnDefinitions8.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions8.Add(new ColumnDefinition(new GridLength(190.0, GridUnitType.Pixel)));
		grid50.ColumnDefinitions = columnDefinitions8;
		grid50.Height = 34.0;
		Avalonia.Controls.Controls children38 = grid50.Children;
		Lucide lucide23;
		Lucide lucide22 = (lucide23 = new Lucide());
		((ISupportInitialize)lucide22).BeginInit();
		children38.Add(lucide22);
		Lucide lucide24 = (lucide4 = lucide23);
		context.PushParent(lucide4);
		Lucide lucide25 = lucide4;
		lucide25.Icon = LucideIconNames.PanelsTopLeft;
		lucide25.Width = 18.0;
		lucide25.Height = 18.0;
		StyledProperty<IBrush?> strokeBrushProperty6 = Lucide.StrokeBrushProperty;
		DynamicResourceExtension dynamicResourceExtension64 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
		BindingBase binding29 = dynamicResourceExtension64.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide25.Bind(strokeBrushProperty6, binding29);
		lucide25.VerticalAlignment = VerticalAlignment.Center;
		context.PopParent();
		((ISupportInitialize)lucide24).EndInit();
		Avalonia.Controls.Controls children39 = grid50.Children;
		TextBlock textBlock14;
		TextBlock textBlock13 = (textBlock14 = new TextBlock());
		((ISupportInitialize)textBlock13).BeginInit();
		children39.Add(textBlock13);
		Grid.SetColumn(textBlock14, 1);
		textBlock14.Text = "Floating overlay";
		textBlock14.VerticalAlignment = VerticalAlignment.Center;
		textBlock14.FontSize = 13.0;
		((ISupportInitialize)textBlock14).EndInit();
		Avalonia.Controls.Controls children40 = grid50.Children;
		ToggleSwitch toggleSwitch2;
		ToggleSwitch toggleSwitch = (toggleSwitch2 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch).BeginInit();
		children40.Add(toggleSwitch);
		ToggleSwitch toggleSwitch4;
		ToggleSwitch toggleSwitch3 = (toggleSwitch4 = toggleSwitch2);
		context.PushParent(toggleSwitch4);
		toggleSwitch4.Name = "OverlayVisibilityToggle";
		element = toggleSwitch4;
		context.AvaloniaNameScope.Register("OverlayVisibilityToggle", element);
		Grid.SetColumn(toggleSwitch4, 2);
		StyledProperty<bool?> isCheckedProperty = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension15 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EOverlayVisible_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding30 = compiledBindingExtension15.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch4.Bind(isCheckedProperty, binding30);
		toggleSwitch4.Width = 40.0;
		toggleSwitch4.MinWidth = 0.0;
		toggleSwitch4.HorizontalAlignment = HorizontalAlignment.Right;
		toggleSwitch4.VerticalAlignment = VerticalAlignment.Center;
		toggleSwitch4.OnContent = "";
		toggleSwitch4.OffContent = "";
		AutomationProperties.SetName(toggleSwitch4, "Show Deepwoken macro overlay");
		context.PopParent();
		((ISupportInitialize)toggleSwitch3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid49).EndInit();
		context.PopParent();
		((ISupportInitialize)border42).EndInit();
		Avalonia.Controls.Controls children41 = stackPanel7.Children;
		Border border45;
		Border border44 = (border45 = new Border());
		((ISupportInitialize)border44).BeginInit();
		children41.Add(border44);
		Border border46 = (border4 = border45);
		context.PushParent(border4);
		Border border47 = border4;
		border47.Classes.Add("settings-card");
		Grid grid52;
		Grid grid51 = (grid52 = new Grid());
		((ISupportInitialize)grid51).BeginInit();
		border47.Child = grid51;
		Grid grid53 = (grid4 = grid52);
		context.PushParent(grid4);
		Grid grid54 = grid4;
		ColumnDefinitions columnDefinitions9 = new ColumnDefinitions();
		columnDefinitions9.Capacity = 3;
		columnDefinitions9.Add(new ColumnDefinition(new GridLength(28.0, GridUnitType.Pixel)));
		columnDefinitions9.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions9.Add(new ColumnDefinition(new GridLength(190.0, GridUnitType.Pixel)));
		grid54.ColumnDefinitions = columnDefinitions9;
		grid54.Height = 34.0;
		Avalonia.Controls.Controls children42 = grid54.Children;
		Lucide lucide27;
		Lucide lucide26 = (lucide27 = new Lucide());
		((ISupportInitialize)lucide26).BeginInit();
		children42.Add(lucide26);
		Lucide lucide28 = (lucide4 = lucide27);
		context.PushParent(lucide4);
		Lucide lucide29 = lucide4;
		lucide29.Icon = LucideIconNames.RotateCcw;
		lucide29.Width = 18.0;
		lucide29.Height = 18.0;
		StyledProperty<IBrush?> strokeBrushProperty7 = Lucide.StrokeBrushProperty;
		DynamicResourceExtension dynamicResourceExtension65 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
		BindingBase binding31 = dynamicResourceExtension65.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide29.Bind(strokeBrushProperty7, binding31);
		lucide29.VerticalAlignment = VerticalAlignment.Center;
		context.PopParent();
		((ISupportInitialize)lucide28).EndInit();
		Avalonia.Controls.Controls children43 = grid54.Children;
		TextBlock textBlock16;
		TextBlock textBlock15 = (textBlock16 = new TextBlock());
		((ISupportInitialize)textBlock15).BeginInit();
		children43.Add(textBlock15);
		Grid.SetColumn(textBlock16, 1);
		textBlock16.Text = "Overlay position";
		textBlock16.VerticalAlignment = VerticalAlignment.Center;
		textBlock16.FontSize = 13.0;
		((ISupportInitialize)textBlock16).EndInit();
		Avalonia.Controls.Controls children44 = grid54.Children;
		Button button9;
		Button button8 = (button9 = new Button());
		((ISupportInitialize)button8).BeginInit();
		children44.Add(button8);
		Button button3;
		Button button10 = (button3 = button9);
		context.PushParent(button3);
		Button button11 = button3;
		button11.Name = "ResetOverlayPositionButton";
		element = button11;
		context.AvaloniaNameScope.Register("ResetOverlayPositionButton", element);
		Grid.SetColumn(button11, 2);
		button11.Content = "Reset position";
		StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension16 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EResetPositionCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding32 = compiledBindingExtension16.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button11.Bind(commandProperty, binding32);
		button11.Height = 34.0;
		button11.HorizontalAlignment = HorizontalAlignment.Stretch;
		context.PopParent();
		((ISupportInitialize)button10).EndInit();
		context.PopParent();
		((ISupportInitialize)grid53).EndInit();
		context.PopParent();
		((ISupportInitialize)border46).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel5).EndInit();
		context.PopParent();
		((ISupportInitialize)border22).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer3).EndInit();
		Avalonia.Controls.Controls children45 = grid30.Children;
		ScrollViewer scrollViewer7;
		ScrollViewer scrollViewer6 = (scrollViewer7 = new ScrollViewer());
		((ISupportInitialize)scrollViewer6).BeginInit();
		children45.Add(scrollViewer6);
		ScrollViewer scrollViewer8 = (scrollViewer4 = scrollViewer7);
		context.PushParent(scrollViewer4);
		ScrollViewer scrollViewer9 = scrollViewer4;
		scrollViewer9.Name = "MacroListScroll";
		element = scrollViewer9;
		context.AvaloniaNameScope.Register("MacroListScroll", element);
		scrollViewer9.Margin = new Thickness(0.0, 0.0, -12.0, 0.0);
		StyledProperty<bool> isVisibleProperty5 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension17 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EIsMacroPage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding33 = compiledBindingExtension17.ProvideValue(context);
		context.ProvideTargetProperty = null;
		scrollViewer9.Bind(isVisibleProperty5, binding33);
		scrollViewer9.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
		scrollViewer9.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
		Border border49;
		Border border48 = (border49 = new Border());
		((ISupportInitialize)border48).BeginInit();
		scrollViewer9.Content = border48;
		Border border50 = (border4 = border49);
		context.PushParent(border4);
		Border border51 = border4;
		border51.Name = "MacroListFrame";
		element = border51;
		context.AvaloniaNameScope.Register("MacroListFrame", element);
		StyledProperty<IBrush?> backgroundProperty7 = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension66 = new DynamicResourceExtension("MacroSurface");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding34 = dynamicResourceExtension66.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border51.Bind(backgroundProperty7, binding34);
		StyledProperty<IBrush?> borderBrushProperty6 = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension67 = new DynamicResourceExtension("MacroBorder");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding35 = dynamicResourceExtension67.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border51.Bind(borderBrushProperty6, binding35);
		border51.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		border51.CornerRadius = new CornerRadius(0.0, 0.0, 0.0, 0.0);
		border51.ClipToBounds = true;
		border51.Margin = new Thickness(2.0, 12.0, 14.0, 12.0);
		border51.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
		StackPanel stackPanel13;
		StackPanel stackPanel12 = (stackPanel13 = new StackPanel());
		((ISupportInitialize)stackPanel12).BeginInit();
		border51.Child = stackPanel12;
		StackPanel stackPanel14 = (stackPanel6 = stackPanel13);
		context.PushParent(stackPanel6);
		StackPanel stackPanel15 = stackPanel6;
		Avalonia.Controls.Controls children46 = stackPanel15.Children;
		Border border53;
		Border border52 = (border53 = new Border());
		((ISupportInitialize)border52).BeginInit();
		children46.Add(border52);
		Border border54 = (border4 = border53);
		context.PushParent(border4);
		Border border55 = border4;
		StyledProperty<bool> isVisibleProperty6 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension18 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EIsSilentheartPage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding36 = compiledBindingExtension18.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border55.Bind(isVisibleProperty6, binding36);
		FlowStateOverlayPanel flowStateOverlayPanel2;
		FlowStateOverlayPanel flowStateOverlayPanel = (flowStateOverlayPanel2 = new FlowStateOverlayPanel());
		((ISupportInitialize)flowStateOverlayPanel).BeginInit();
		border55.Child = flowStateOverlayPanel;
		FlowStateOverlayPanel flowStateOverlayPanel4;
		FlowStateOverlayPanel flowStateOverlayPanel3 = (flowStateOverlayPanel4 = flowStateOverlayPanel2);
		context.PushParent(flowStateOverlayPanel4);
		CompiledBindingExtension compiledBindingExtension19 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EFlowStateOverlay_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = StyledElement.DataContextProperty;
		CompiledBinding compiledBinding4 = compiledBindingExtension19.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_13(flowStateOverlayPanel4, compiledBinding4);
		context.PopParent();
		((ISupportInitialize)flowStateOverlayPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)border54).EndInit();
		Avalonia.Controls.Controls children47 = stackPanel15.Children;
		ItemsControl itemsControl2;
		ItemsControl itemsControl = (itemsControl2 = new ItemsControl());
		((ISupportInitialize)itemsControl).BeginInit();
		children47.Add(itemsControl);
		ItemsControl itemsControl4;
		ItemsControl itemsControl3 = (itemsControl4 = itemsControl2);
		context.PushParent(itemsControl4);
		itemsControl4.Name = "MacroListItems";
		element = itemsControl4;
		context.AvaloniaNameScope.Register("MacroListItems", element);
		StyledProperty<IEnumerable?> itemsSourceProperty4 = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension20 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EVisibleMacros_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding37 = compiledBindingExtension20.ProvideValue(context);
		context.ProvideTargetProperty = null;
		itemsControl4.Bind(itemsSourceProperty4, binding37);
		DataTemplate itemTemplate2 = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		DataTemplate dataTemplate3 = dataTemplate;
		dataTemplate3.DataType = typeof(MacroRow);
		dataTemplate3.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_29.Build_20), context);
		context.PopParent();
		itemsControl4.ItemTemplate = itemTemplate2;
		context.PopParent();
		((ISupportInitialize)itemsControl3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel14).EndInit();
		context.PopParent();
		((ISupportInitialize)border50).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer8).EndInit();
		Avalonia.Controls.Controls children48 = grid30.Children;
		ScrollViewer scrollViewer11;
		ScrollViewer scrollViewer10 = (scrollViewer11 = new ScrollViewer());
		((ISupportInitialize)scrollViewer10).BeginInit();
		children48.Add(scrollViewer10);
		ScrollViewer scrollViewer12 = (scrollViewer4 = scrollViewer11);
		context.PushParent(scrollViewer4);
		ScrollViewer scrollViewer13 = scrollViewer4;
		StyledProperty<bool> isVisibleProperty7 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension21 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EIsHealthPage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding38 = compiledBindingExtension21.ProvideValue(context);
		context.ProvideTargetProperty = null;
		scrollViewer13.Bind(isVisibleProperty7, binding38);
		HealthPanel healthPanel2;
		HealthPanel healthPanel = (healthPanel2 = new HealthPanel());
		((ISupportInitialize)healthPanel).BeginInit();
		scrollViewer13.Content = healthPanel;
		HealthPanel healthPanel4;
		HealthPanel healthPanel3 = (healthPanel4 = healthPanel2);
		context.PushParent(healthPanel4);
		CompiledBindingExtension compiledBindingExtension22 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EHealth_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = StyledElement.DataContextProperty;
		CompiledBinding compiledBinding5 = compiledBindingExtension22.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_13(healthPanel4, compiledBinding5);
		context.PopParent();
		((ISupportInitialize)healthPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer12).EndInit();
		Avalonia.Controls.Controls children49 = grid30.Children;
		ScrollViewer scrollViewer15;
		ScrollViewer scrollViewer14 = (scrollViewer15 = new ScrollViewer());
		((ISupportInitialize)scrollViewer14).BeginInit();
		children49.Add(scrollViewer14);
		ScrollViewer scrollViewer16 = (scrollViewer4 = scrollViewer15);
		context.PushParent(scrollViewer4);
		ScrollViewer scrollViewer17 = scrollViewer4;
		StyledProperty<bool> isVisibleProperty8 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension23 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EIsParryPage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding39 = compiledBindingExtension23.ProvideValue(context);
		context.ProvideTargetProperty = null;
		scrollViewer17.Bind(isVisibleProperty8, binding39);
		ParryBarPanel parryBarPanel2;
		ParryBarPanel parryBarPanel = (parryBarPanel2 = new ParryBarPanel());
		((ISupportInitialize)parryBarPanel).BeginInit();
		scrollViewer17.Content = parryBarPanel;
		ParryBarPanel parryBarPanel4;
		ParryBarPanel parryBarPanel3 = (parryBarPanel4 = parryBarPanel2);
		context.PushParent(parryBarPanel4);
		CompiledBindingExtension compiledBindingExtension24 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EParryBar_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = StyledElement.DataContextProperty;
		CompiledBinding compiledBinding6 = compiledBindingExtension24.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_13(parryBarPanel4, compiledBinding6);
		context.PopParent();
		((ISupportInitialize)parryBarPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer16).EndInit();
		Avalonia.Controls.Controls children50 = grid30.Children;
		StackPanel stackPanel17;
		StackPanel stackPanel16 = (stackPanel17 = new StackPanel());
		((ISupportInitialize)stackPanel16).BeginInit();
		children50.Add(stackPanel16);
		StackPanel stackPanel18 = (stackPanel6 = stackPanel17);
		context.PushParent(stackPanel6);
		StackPanel stackPanel19 = stackPanel6;
		stackPanel19.Name = "HallowtidePlaceholder";
		element = stackPanel19;
		context.AvaloniaNameScope.Register("HallowtidePlaceholder", element);
		StyledProperty<bool> isVisibleProperty9 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension25 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EIsHallowtidePage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding40 = compiledBindingExtension25.ProvideValue(context);
		context.ProvideTargetProperty = null;
		stackPanel19.Bind(isVisibleProperty9, binding40);
		stackPanel19.HorizontalAlignment = HorizontalAlignment.Center;
		stackPanel19.VerticalAlignment = VerticalAlignment.Center;
		stackPanel19.Spacing = 18.0;
		Avalonia.Controls.Controls children51 = stackPanel19.Children;
		Border border57;
		Border border56 = (border57 = new Border());
		((ISupportInitialize)border56).BeginInit();
		children51.Add(border56);
		Border border58 = (border4 = border57);
		context.PushParent(border4);
		Border border59 = border4;
		border59.Width = 72.0;
		border59.Height = 72.0;
		StyledProperty<IBrush?> backgroundProperty8 = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension68 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding41 = dynamicResourceExtension68.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border59.Bind(backgroundProperty8, binding41);
		border59.Opacity = 0.8;
		StyledProperty<IBrush?> opacityMaskProperty = Visual.OpacityMaskProperty;
		CompiledBindingExtension compiledBindingExtension27;
		CompiledBindingExtension compiledBindingExtension26 = (compiledBindingExtension27 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002ESelectedCategory_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build()));
		context.PushParent(compiledBindingExtension27);
		StaticResourceExtension staticResourceExtension = new StaticResourceExtension("CategoryArtwork");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EData_002ECompiledBinding_002CAvalonia_002EBase_002EConverter_0021Property();
		object? obj = staticResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		compiledBindingExtension27.Converter = (IValueConverter)obj;
		context.PopParent();
		context.ProvideTargetProperty = Visual.OpacityMaskProperty;
		CompiledBinding binding42 = compiledBindingExtension26.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border59.Bind(opacityMaskProperty, binding42);
		context.PopParent();
		((ISupportInitialize)border58).EndInit();
		Avalonia.Controls.Controls children52 = stackPanel19.Children;
		TextBlock textBlock18;
		TextBlock textBlock17 = (textBlock18 = new TextBlock());
		((ISupportInitialize)textBlock17).BeginInit();
		children52.Add(textBlock17);
		TextBlock textBlock20;
		TextBlock textBlock19 = (textBlock20 = textBlock18);
		context.PushParent(textBlock20);
		textBlock20.Text = "Coming soon";
		textBlock20.FontSize = 15.0;
		StyledProperty<IBrush?> foregroundProperty2 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension69 = new DynamicResourceExtension("MacroMuted");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding43 = dynamicResourceExtension69.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock20.Bind(foregroundProperty2, binding43);
		textBlock20.HorizontalAlignment = HorizontalAlignment.Center;
		context.PopParent();
		((ISupportInitialize)textBlock19).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel18).EndInit();
		Avalonia.Controls.Controls children53 = grid30.Children;
		StackPanel stackPanel21;
		StackPanel stackPanel20 = (stackPanel21 = new StackPanel());
		((ISupportInitialize)stackPanel20).BeginInit();
		children53.Add(stackPanel20);
		StackPanel stackPanel22 = (stackPanel6 = stackPanel21);
		context.PushParent(stackPanel6);
		StackPanel stackPanel23 = stackPanel6;
		StyledProperty<bool> isVisibleProperty10 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension28 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EIsEmpty_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding44 = compiledBindingExtension28.ProvideValue(context);
		context.ProvideTargetProperty = null;
		stackPanel23.Bind(isVisibleProperty10, binding44);
		stackPanel23.HorizontalAlignment = HorizontalAlignment.Center;
		stackPanel23.VerticalAlignment = VerticalAlignment.Center;
		stackPanel23.Spacing = 8.0;
		Avalonia.Controls.Controls children54 = stackPanel23.Children;
		TextBlock textBlock22;
		TextBlock textBlock21 = (textBlock22 = new TextBlock());
		((ISupportInitialize)textBlock21).BeginInit();
		children54.Add(textBlock21);
		textBlock22.Text = "No macros found";
		textBlock22.FontSize = 17.0;
		textBlock22.HorizontalAlignment = HorizontalAlignment.Center;
		((ISupportInitialize)textBlock22).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel22).EndInit();
		context.PopParent();
		((ISupportInitialize)grid29).EndInit();
		context.PopParent();
		((ISupportInitialize)grid26).EndInit();
		context.PopParent();
		((ISupportInitialize)border18).EndInit();
		context.PopParent();
		((ISupportInitialize)grid22).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(MacroWindow P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
