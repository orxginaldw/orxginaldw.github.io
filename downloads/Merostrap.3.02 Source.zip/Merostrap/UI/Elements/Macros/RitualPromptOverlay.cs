using System;
using System.Runtime.InteropServices;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Media;
using Merostrap.Macros;
using Merostrap.Macros.Health;

namespace Merostrap.UI.Elements.Macros;

public sealed class RitualPromptOverlay : Window
{
	private readonly Border _outline = new Border
	{
		BorderThickness = new Thickness(2.0),
		CornerRadius = new CornerRadius(4.0),
		Background = Brushes.Transparent
	};

	public RitualPromptOverlay()
	{
		WindowDecorations = WindowDecorations.None;
		CanResize = false;
		ShowActivated = false;
		ShowInTaskbar = false;
		Topmost = true;
		Background = Brushes.Transparent;
		TransparencyBackgroundFallback = Brushes.Transparent;
		TransparencyLevelHint = new _003C_003Ez__ReadOnlySingleElementList<WindowTransparencyLevel>(WindowTransparencyLevel.Transparent);
		Content = _outline;
		Win32Properties.AddWindowStylesCallback(this, (uint style, uint extended) => (style: (style & 0xFF30FFFFu) | 0x80000000u, exStyle: extended | 0x80000A0));
		Opened += (object? _, EventArgs _) =>
		{
			if (OperatingSystem.IsWindows())
			{
				nint? num = TryGetPlatformHandle()?.Handle;
				if (num.HasValue)
				{
					nint valueOrDefault = num.GetValueOrDefault();
					if (valueOrDefault != IntPtr.Zero)
					{
						SetWindowDisplayAffinity(valueOrDefault, 17u);
					}
				}
			}
		};
	}

	public void Update(RitualPromptHighlight prompt)
	{
		HealthRegion area = prompt.Area;
		int width = area.Width;
		bool flag = ((width < 1 || width > 512) ? true : false);
		bool flag2 = flag;
		if (!flag2)
		{
			int height = area.Height;
			bool flag3 = ((height < 1 || height > 128) ? true : false);
			flag2 = flag3;
		}
		if (flag2)
		{
			Hide();
			return;
		}
		PixelPoint pixelPoint = new PixelPoint(area.X - 6, area.Y - 6);
		double num = Screens.ScreenFromPoint(pixelPoint)?.Scaling ?? 1.0;
		Width = (double)(area.Width + 12) / num;
		Height = (double)(area.Height + 12) / num;
		_outline.BorderBrush = new SolidColorBrush(Color.Parse(prompt.Sent ? "#80DBAE" : "#FF5D66"));
		Position = pixelPoint;
		Show();
		Position = pixelPoint;
	}

	[DllImport("user32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool SetWindowDisplayAffinity(nint window, uint affinity);
}
