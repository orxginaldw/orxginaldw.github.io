using System;
using System.Globalization;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Media;
using Merostrap.Macros;

namespace Merostrap.UI.Elements.Macros;

public sealed class KeybindButton : Button
{
	private static long _ignoreShortcutsUntil;

	private static KeybindButton? _recorder;

	private TopLevel? _captureRoot;

	private double _captureMinWidth;

	private IDisposable? _editSession;

	public static readonly StyledProperty<string> ValueProperty = AvaloniaProperty.Register<KeybindButton, string>("Value", "", inherits: false, BindingMode.TwoWay);

	public static readonly StyledProperty<bool> AllowMainMouseButtonsProperty = AvaloniaProperty.Register<KeybindButton, bool>("AllowMainMouseButtons", defaultValue: false);

	public static bool SuppressShortcuts
	{
		get
		{
			KeybindButton? recorder = _recorder;
			if (recorder == null || !recorder.IsListening)
			{
				return Environment.TickCount64 < _ignoreShortcutsUntil;
			}
			return true;
		}
	}

	public string Value
	{
		get
		{
			return GetValue(ValueProperty);
		}
		set
		{
			SetValue(ValueProperty, value);
		}
	}

	public bool AllowMainMouseButtons
	{
		get
		{
			return GetValue(AllowMainMouseButtonsProperty);
		}
		set
		{
			SetValue(AllowMainMouseButtonsProperty, value);
		}
	}

	public bool IsListening { get; private set; }

	protected override Type StyleKeyOverride => typeof(Button);

	public KeybindButton()
	{
		MinWidth = 40.0;
		Height = 32.0;
		Padding = new Thickness(12.0, 0.0);
		HorizontalAlignment = HorizontalAlignment.Left;
		HorizontalContentAlignment = HorizontalAlignment.Center;
		FontFamily = new FontFamily("Cascadia Mono, Consolas, monospace");
		FontSize = 12.0;
		CornerRadius = new CornerRadius(6.0);
		Background = Brush.Parse("#1B1D24");
		BorderBrush = Brush.Parse("#3C404D");
		BorderThickness = new Thickness(1.0);
		ToolTip.SetTip(this, "Click, then press a keyboard key or side mouse button anywhere in this window. Numpad keys are separate. Esc cancels. Right-click to clear.");
		AddHandler(InputElement.KeyDownEvent, CaptureKey, RoutingStrategies.Tunnel);
		MenuItem menuItem = new MenuItem
		{
			Header = "Clear key"
		};
		menuItem.Click += (object? _, RoutedEventArgs _) =>
		{
			EndCapture();
			SetCurrentValue(ValueProperty, "");
		};
		ContextMenu = new Avalonia.Controls.ContextMenu
		{
			ItemsSource = new MenuItem[1] { menuItem }
		};
		UpdateCaption();
	}

	public void BeginCapture()
	{
		_recorder?.EndCapture();
		_recorder = this;
		_captureMinWidth = MinWidth;
		SetCurrentValue(Layoutable.MinWidthProperty, Math.Max(MinWidth, Bounds.Width));
		IsListening = true;
		_captureRoot = TopLevel.GetTopLevel(this);
		if (_captureRoot is MacroWindow macroWindow)
		{
			macroWindow.BeginKeyboardEditing();
		}
		_editSession = (_captureRoot?.DataContext as MacroWorkspace)?.PauseForSettingsEdit();
		_captureRoot?.AddHandler(InputElement.PointerPressedEvent, CaptureMouse, RoutingStrategies.Tunnel, handledEventsToo: true);
		_captureRoot?.AddHandler(InputElement.PointerMovedEvent, CaptureMouse, RoutingStrategies.Tunnel, handledEventsToo: true);
		Focus();
		UpdateCaption();
	}

	private void EndCapture()
	{
		MacroWindow obj = _captureRoot as MacroWindow;
		_captureRoot?.RemoveHandler(InputElement.PointerPressedEvent, CaptureMouse);
		_captureRoot?.RemoveHandler(InputElement.PointerMovedEvent, CaptureMouse);
		_captureRoot = null;
		if (IsListening)
		{
			SetCurrentValue(Layoutable.MinWidthProperty, _captureMinWidth);
		}
		IsListening = false;
		if (_recorder == this)
		{
			_recorder = null;
		}
		UpdateCaption();
		IDisposable? editSession = _editSession;
		_editSession = null;
		editSession?.Dispose();
		obj?.EndKeyboardEditing();
	}

	protected override void OnClick()
	{
		base.OnClick();
		BeginCapture();
	}

	protected override void OnLostFocus(FocusChangedEventArgs e)
	{
		EndCapture();
		base.OnLostFocus(e);
	}

	protected override void OnDetachedFromVisualTree(VisualTreeAttachmentEventArgs e)
	{
		EndCapture();
		base.OnDetachedFromVisualTree(e);
	}

	protected override void OnAttachedToVisualTree(VisualTreeAttachmentEventArgs e)
	{
		base.OnAttachedToVisualTree(e);
		if (TopLevel.GetTopLevel(this) is MacroWindow)
		{
			Bind(TemplatedControl.BackgroundProperty, new DynamicResourceExtension("MacroInput"));
			UpdateCaption();
		}
	}

	protected override void OnPropertyChanged(AvaloniaPropertyChangedEventArgs change)
	{
		base.OnPropertyChanged(change);
		if (change.Property == ValueProperty)
		{
			UpdateCaption();
		}
	}

	private void UpdateCaption()
	{
		KeybindButton keybindButton = this;
		object? content;
		if (IsListening)
		{
			content = "…";
		}
		else
		{
			content = (string.IsNullOrWhiteSpace(Value) ? "Not set" : Value.ToUpperInvariant());
		}
		keybindButton.Content = content;
		if (TopLevel.GetTopLevel(this) is MacroWindow)
		{
			Bind(TemplatedControl.BorderBrushProperty, new DynamicResourceExtension(IsListening ? "MacroAccent" : "MacroBorder"));
		}
		else
		{
			BorderBrush = Brush.Parse(IsListening ? "#B8A8FF" : "#3C404D");
		}
	}

	private void CaptureKey(object? sender, KeyEventArgs e)
	{
		if (!IsListening)
		{
			return;
		}
		_ignoreShortcutsUntil = Environment.TickCount64 + 500;
		e.Handled = true;
		if (e.Key == Key.Escape)
		{
			EndCapture();
			return;
		}
		string text = KeyName(e.Key, e.PhysicalKey);
		if (text != null)
		{
			SetCurrentValue(ValueProperty, text);
			EndCapture();
		}
	}

	private void CaptureMouse(object? sender, PointerEventArgs e)
	{
		if (!IsListening)
		{
			return;
		}
		string text;
		switch (e.GetCurrentPoint(this).Properties.PointerUpdateKind)
		{
		case PointerUpdateKind.XButton1Pressed:
			text = "mouse4";
			break;
		case PointerUpdateKind.XButton2Pressed:
			text = "mouse5";
			break;
		case PointerUpdateKind.LeftButtonPressed:
			if (AllowMainMouseButtons)
			{
				text = "mouse1";
				break;
			}
			goto default;
		case PointerUpdateKind.RightButtonPressed:
			if (AllowMainMouseButtons)
			{
				text = "mouse2";
				break;
			}
			goto default;
		case PointerUpdateKind.MiddleButtonPressed:
			if (AllowMainMouseButtons)
			{
				text = "mouse3";
				break;
			}
			goto default;
		default:
			text = null;
			break;
		}
		string text2 = text;
		if (text2 != null)
		{
			e.Handled = true;
			_ignoreShortcutsUntil = Environment.TickCount64 + 500;
			e.Pointer.Capture(null);
			SetCurrentValue(ValueProperty, text2);
			EndCapture();
		}
	}

	private static string? KeyName(Key key, PhysicalKey physical)
	{
		if (physical >= PhysicalKey.NumPad0 && physical <= PhysicalKey.NumPad9)
		{
			return "numpad" + ((int)(physical - 85)).ToString(CultureInfo.InvariantCulture);
		}
		string text = physical switch
		{
			PhysicalKey.NumPadAdd => "numpad add", 
			PhysicalKey.NumPadSubtract => "numpad subtract", 
			PhysicalKey.NumPadMultiply => "numpad multiply", 
			PhysicalKey.NumPadDivide => "numpad divide", 
			PhysicalKey.NumPadDecimal => "numpad decimal", 
			PhysicalKey.NumPadEnter => "numpad enter", 
			_ => null, 
		};
		if (text != null)
		{
			return text;
		}
		if (key >= Key.A && key <= Key.Z)
		{
			return ((char)(97 + key - 44)).ToString();
		}
		if (key >= Key.D0 && key <= Key.D9)
		{
			return ((int)(key - 34)).ToString(CultureInfo.InvariantCulture);
		}
		if (key >= Key.NumPad0 && key <= Key.NumPad9)
		{
			return "numpad" + ((int)(key - 74)).ToString(CultureInfo.InvariantCulture);
		}
		if (key >= Key.F1 && key <= Key.F24)
		{
			return "f" + ((int)(key - 90 + 1)).ToString(CultureInfo.InvariantCulture);
		}
		switch (key)
		{
		case Key.Back:
			return "backspace";
		case Key.Tab:
			return "tab";
		case Key.Return:
			return "enter";
		case Key.Space:
			return "space";
		case Key.LeftCtrl:
		case Key.RightCtrl:
			return "ctrl";
		case Key.LeftShift:
		case Key.RightShift:
			return "shift";
		case Key.LeftAlt:
		case Key.RightAlt:
			return "alt";
		case Key.CapsLock:
			return "caps lock";
		case Key.Up:
			return "up";
		case Key.Down:
			return "down";
		case Key.Left:
			return "left";
		case Key.Right:
			return "right";
		case Key.Home:
			return "home";
		case Key.End:
			return "end";
		case Key.PageUp:
			return "page up";
		case Key.PageDown:
			return "page down";
		case Key.Insert:
			return "insert";
		case Key.Delete:
			return "delete";
		case Key.OemTilde:
			return "`";
		case Key.Add:
			return "numpad add";
		case Key.Subtract:
			return "numpad subtract";
		case Key.Multiply:
			return "numpad multiply";
		case Key.Divide:
			return "numpad divide";
		case Key.Decimal:
			return "numpad decimal";
		case Key.OemMinus:
			return "-";
		case Key.OemPlus:
			return "=";
		case Key.OemOpenBrackets:
			return "[";
		case Key.OemCloseBrackets:
			return "]";
		case Key.OemPipe:
		case Key.OemBackslash:
			return "\\";
		case Key.OemSemicolon:
			return ";";
		case Key.OemQuotes:
			return "'";
		case Key.OemComma:
			return ",";
		case Key.OemPeriod:
			return ".";
		case Key.OemQuestion:
			return "/";
		default:
			return null;
		}
	}
}
