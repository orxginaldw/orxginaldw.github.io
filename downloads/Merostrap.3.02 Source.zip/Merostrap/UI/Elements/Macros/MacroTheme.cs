using Avalonia.Media;

namespace Merostrap.UI.Elements.Macros;

internal static class MacroTheme
{
	public static void Apply(MacroWindow window, string name)
	{
		string[] array = name switch
		{
			"Midnight" => new string[10] { "#363639", "#303033", "#2D2D30", "#343438", "#4C4C52", "#F2F2F5", "#BDBDC6", "#AAAAB4", "#84B8FF", "#343D4A" }, 
			"Crimson" => new string[10] { "#363639", "#303033", "#2D2D30", "#343438", "#4C4C52", "#F2F2F5", "#BDBDC6", "#AAAAB4", "#E7475D", "#473039" }, 
			"Evergreen" => new string[10] { "#363639", "#303033", "#2D2D30", "#343438", "#4C4C52", "#F2F2F5", "#BDBDC6", "#AAAAB4", "#83DCAF", "#344239" }, 
			"Amethyst" => new string[10] { "#363639", "#303033", "#2D2D30", "#343438", "#4C4C52", "#F2F2F5", "#BDBDC6", "#AAAAB4", "#C5A0FF", "#413A4A" }, 
			_ => new string[10] { "#111216", "#15161B", "#191B21", "#1B1D24", "#353640", "#ECECF1", "#A8ACBA", "#969CAA", "#B8A8FF", "#363047" }, 
		};
		string[] array2 = new string[10] { "MacroBackground", "MacroHeader", "MacroSurface", "MacroInput", "MacroBorder", "MacroText", "MacroMuted", "MacroSubtle", "MacroAccent", "MacroSelection" };
		for (int i = 0; i < array2.Length; i++)
		{
			window.Resources[array2[i]] = Brush.Parse(array[i]);
		}
		window.Resources["MacroTextField"] = Brush.Parse("#29292D");
		window.Resources["MacroFrame"] = Brush.Parse((name != "Obsidian") ? "#55555B" : array[4]);
		window.Resources["MacroInterior"] = Brush.Parse((name != "Obsidian") ? "#202023" : array[1]);
		window.Resources["SystemAccentColor"] = Color.Parse(array[8]);
		window.Resources["SystemControlHighlightAccentBrush"] = Brush.Parse(array[8]);
		window.Resources["ToggleSwitchFillOn"] = Brush.Parse(array[8]);
		string[] array3 = new string[7] { "AccentFillColorDefaultBrush", "AccentFillColorSecondaryBrush", "AccentTextFillColorPrimaryBrush", "ComboBoxItemPillFillBrush", "ToggleSwitchFillOnPointerOver", "ToggleSwitchFillOnPressed", "TextControlBorderBrushFocused" };
		foreach (string key in array3)
		{
			window.Resources[key] = Brush.Parse(array[8]);
		}
		array3 = new string[3] { "ListViewItemBackgroundSelected", "ListViewItemBackgroundSelectedPointerOver", "ListViewItemBackgroundSelectedPressed" };
		foreach (string key2 in array3)
		{
			window.Resources[key2] = Brush.Parse(array[9]);
		}
	}
}
