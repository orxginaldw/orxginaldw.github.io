using System;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Media;

namespace Merostrap.UI.Elements.Macros;

public sealed class MacroColourPlane : Control
{
	public double Hue { get; set; }

	public double Saturation { get; set; } = 1.0;

	public double Value { get; set; } = 1.0;

	public bool IsHue { get; set; }

	public event Action? Changed;

	public MacroColourPlane()
	{
		Focusable = true;
		Cursor = new Cursor(StandardCursorType.Cross);
	}

	public static Color FromHsv(double h, double s, double v)
	{
		double num = v * s;
		double num2 = num * (1.0 - Math.Abs(h / 60.0 % 2.0 - 1.0));
		double num3 = v - num;
		var (num4, num5, num6) = ((h < 60.0) ? (num, num2, 0.0) : ((h < 120.0) ? (num2, num, 0.0) : ((h < 180.0) ? (0.0, num, num2) : ((h < 240.0) ? (0.0, num2, num) : ((!(h < 300.0)) ? (num, 0.0, num2) : (num2, 0.0, num))))));
		return Color.FromRgb((byte)Math.Round((num4 + num3) * 255.0), (byte)Math.Round((num5 + num3) * 255.0), (byte)Math.Round((num6 + num3) * 255.0));
	}

	public override void Render(DrawingContext context)
	{
		Rect rect = new Rect(Bounds.Size);
		LinearGradientBrush linearGradientBrush = new LinearGradientBrush
		{
			StartPoint = new RelativePoint(0.0, 0.0, RelativeUnit.Relative),
			EndPoint = new RelativePoint(1.0, 0.0, RelativeUnit.Relative)
		};
		if (IsHue)
		{
			for (int i = 0; i <= 6; i++)
			{
				linearGradientBrush.GradientStops.Add(new GradientStop(FromHsv(i * 60 % 360, 1.0, 1.0), (double)i / 6.0));
			}
			context.FillRectangle(linearGradientBrush, rect, 5f);
			Point center = new Point(Math.Clamp(Hue / 360.0 * Bounds.Width, 6.0, Bounds.Width - 6.0), Bounds.Height / 2.0);
			context.DrawEllipse(Brushes.White, new Pen(Brushes.Black, 2.0), center, 5.0, 5.0);
			return;
		}
		linearGradientBrush.GradientStops.Add(new GradientStop(Colors.White, 0.0));
		linearGradientBrush.GradientStops.Add(new GradientStop(FromHsv(Hue, 1.0, 1.0), 1.0));
		context.FillRectangle(linearGradientBrush, rect, 7f);
		LinearGradientBrush brush = new LinearGradientBrush
		{
			StartPoint = new RelativePoint(0.0, 0.0, RelativeUnit.Relative),
			EndPoint = new RelativePoint(0.0, 1.0, RelativeUnit.Relative),
			GradientStops = new GradientStops
			{
				new GradientStop(Colors.Transparent, 0.0),
				new GradientStop(Colors.Black, 1.0)
			}
		};
		context.FillRectangle(brush, rect, 7f);
		Point center2 = new Point(Math.Clamp(Saturation * Bounds.Width, 6.0, Bounds.Width - 6.0), Math.Clamp((1.0 - Value) * Bounds.Height, 6.0, Bounds.Height - 6.0));
		context.DrawEllipse(null, new Pen(Brushes.Black, 4.0), center2, 5.0, 5.0);
		context.DrawEllipse(null, new Pen(Brushes.White, 2.0), center2, 5.0, 5.0);
	}

	private void Update(Point p)
	{
		if (IsHue)
		{
			Hue = Math.Clamp(p.X / Bounds.Width, 0.0, 0.999999) * 360.0;
		}
		else
		{
			Saturation = Math.Clamp(p.X / Bounds.Width, 0.0, 1.0);
			Value = 1.0 - Math.Clamp(p.Y / Bounds.Height, 0.0, 1.0);
		}
		InvalidateVisual();
		Changed?.Invoke();
	}

	protected override void OnPointerPressed(PointerPressedEventArgs e)
	{
		base.OnPointerPressed(e);
		if (e.GetCurrentPoint(this).Properties.IsLeftButtonPressed)
		{
			Focus();
			e.Pointer.Capture(this);
			Update(e.GetPosition(this));
			e.Handled = true;
		}
	}

	protected override void OnPointerMoved(PointerEventArgs e)
	{
		base.OnPointerMoved(e);
		if (e.Pointer.Captured == this)
		{
			Update(e.GetPosition(this));
		}
	}

	protected override void OnPointerReleased(PointerReleasedEventArgs e)
	{
		base.OnPointerReleased(e);
		e.Pointer.Capture(null);
	}

	protected override void OnKeyDown(KeyEventArgs e)
	{
		double num = (e.KeyModifiers.HasFlag(KeyModifiers.Shift) ? 0.1 : 0.01);
		Key key = e.Key;
		if ((uint)(key - 23) > 3u)
		{
			return;
		}
		if (IsHue)
		{
			double hue = Hue;
			key = e.Key;
			bool flag = ((key == Key.Left || key == Key.Down) ? true : false);
			Hue = (hue + (double)((!flag) ? 1 : (-1)) * num * 360.0 + 360.0) % 360.0;
		}
		else
		{
			key = e.Key;
			if ((key == Key.Left || key == Key.Right) ? true : false)
			{
				Saturation = Math.Clamp(Saturation + ((e.Key == Key.Left) ? (0.0 - num) : num), 0.0, 1.0);
			}
			else
			{
				Value = Math.Clamp(Value + ((e.Key == Key.Down) ? (0.0 - num) : num), 0.0, 1.0);
			}
		}
		InvalidateVisual();
		Changed?.Invoke();
		e.Handled = true;
	}
}
