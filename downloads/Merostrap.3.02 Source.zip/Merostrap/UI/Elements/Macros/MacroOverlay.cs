using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using Avalonia.Platform;
using Avalonia.Styling;
using Avalonia.Threading;
using CompiledAvaloniaXaml;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.Macros;

namespace Merostrap.UI.Elements.Macros;

public class MacroOverlay : Window
{
	[CompilerGenerated]
	private class XamlClosure_28
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroOverlay> context = CreateContext(P_0);
			context.IntermediateRoot = new Grid();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Grid grid = (Grid)obj;
			context.PushParent(grid);
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 2;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid.ColumnDefinitions = columnDefinitions;
			grid.Margin = new Thickness(6.0, 3.0, 6.0, 3.0);
			Avalonia.Controls.Controls children = grid.Children;
			TextBlock textBlock2;
			TextBlock textBlock = (textBlock2 = new TextBlock());
			((ISupportInitialize)textBlock).BeginInit();
			children.Add(textBlock);
			TextBlock textBlock4;
			TextBlock textBlock3 = (textBlock4 = textBlock2);
			context.PushParent(textBlock4);
			TextBlock textBlock5 = textBlock4;
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroBindingSummary_002CMerostrap_002EName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock5.Bind(textProperty, binding);
			textBlock5.FontSize = 12.0;
			textBlock5.VerticalAlignment = VerticalAlignment.Center;
			textBlock5.TextTrimming = TextTrimming.CharacterEllipsis;
			textBlock5.Margin = new Thickness(0.0, 0.0, 12.0, 0.0);
			context.PopParent();
			((ISupportInitialize)textBlock3).EndInit();
			Avalonia.Controls.Controls children2 = grid.Children;
			Border border2;
			Border border = (border2 = new Border());
			((ISupportInitialize)border).BeginInit();
			children2.Add(border);
			Border border4;
			Border border3 = (border4 = border2);
			context.PushParent(border4);
			Grid.SetColumn(border4, 1);
			border4.Background = new ImmutableSolidColorBrush(620756991u);
			border4.CornerRadius = new CornerRadius(2.0, 2.0, 2.0, 2.0);
			border4.Padding = new Thickness(6.0, 3.0, 6.0, 3.0);
			TextBlock textBlock7;
			TextBlock textBlock6 = (textBlock7 = new TextBlock());
			((ISupportInitialize)textBlock6).BeginInit();
			border4.Child = textBlock6;
			TextBlock textBlock8 = (textBlock4 = textBlock7);
			context.PushParent(textBlock4);
			TextBlock textBlock9 = textBlock4;
			StyledProperty<string?> textProperty2 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroBindingSummary_002CMerostrap_002EKeys_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock9.Bind(textProperty2, binding2);
			textBlock9.FontSize = 11.0;
			context.PopParent();
			((ISupportInitialize)textBlock8).EndInit();
			context.PopParent();
			((ISupportInitialize)border3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<MacroOverlay> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<MacroOverlay> context = new XamlIlContext.Context<MacroOverlay>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FMacros_002FMacroOverlay_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Macros/MacroOverlay.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (MacroOverlay)service;
				}
			}
			return context;
		}
	}

	private readonly MacroWorkspace _workspace;

	private bool _positionReady;

	private readonly DispatcherTimer _savePosition = new DispatcherTimer
	{
		Interval = TimeSpan.FromMilliseconds(300L)
	};

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Grid OverlayControls;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Border DragArea;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button LockButton;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button HideButton;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public bool CanDrag => !_workspace.OverlayLocked;

	public MacroOverlay()
		: this(MacroWorkspace.Current)
	{
	}

	public MacroOverlay(MacroWorkspace workspace)
	{
		MacroOverlay macroOverlay = this;
		_workspace = workspace;
		InitializeComponent();
		DataContext = workspace;
		_savePosition.Tick += (object? _, EventArgs _) =>
		{
			macroOverlay._savePosition.Stop();
			workspace.SaveOverlayPosition(macroOverlay.Position.X, macroOverlay.Position.Y);
		};
		Opened += (object? _, EventArgs _) =>
		{
			macroOverlay.ResetPosition();
			macroOverlay._positionReady = true;
		};
		PositionChanged += (object? _, PixelPointEventArgs _) =>
		{
			if (macroOverlay._positionReady)
			{
				macroOverlay._savePosition.Stop();
				macroOverlay._savePosition.Start();
			}
		};
		Closing += (object? _, WindowClosingEventArgs _) =>
		{
			macroOverlay._savePosition.Stop();
			if (macroOverlay._positionReady && macroOverlay.IsVisible)
			{
				workspace.SaveOverlayPosition(macroOverlay.Position.X, macroOverlay.Position.Y);
			}
			macroOverlay._positionReady = false;
		};
	}

	public void ResetPosition()
	{
		PixelPoint pixelPoint = new PixelPoint(_workspace.OverlayX ?? 24, _workspace.OverlayY ?? 80);
		Screen screen = Screens.ScreenFromPoint(pixelPoint) ?? Screens.Primary;
		if ((object)screen != null)
		{
			PixelRect workingArea = screen.WorkingArea;
			int num = (int)Math.Ceiling(Width * screen.Scaling);
			int num2 = (int)Math.Ceiling(Bounds.Height * screen.Scaling);
			pixelPoint = new PixelPoint(Math.Clamp(pixelPoint.X, workingArea.X, Math.Max(workingArea.X, workingArea.Right - num)), Math.Clamp(pixelPoint.Y, workingArea.Y, Math.Max(workingArea.Y, workingArea.Bottom - num2)));
		}
		Position = pixelPoint;
	}

	protected override void OnPropertyChanged(AvaloniaPropertyChangedEventArgs change)
	{
		base.OnPropertyChanged(change);
		if (change.Property == Visual.IsVisibleProperty && !IsVisible && _positionReady)
		{
			_savePosition.Stop();
			_workspace.SaveOverlayPosition(Position.X, Position.Y);
		}
	}

	private void DragPressed(object? sender, PointerPressedEventArgs e)
	{
		if (CanDrag && e.GetCurrentPoint(this).Properties.IsLeftButtonPressed)
		{
			BeginMoveDrag(e);
		}
	}

	private void HideClicked(object? sender, RoutedEventArgs e)
	{
		_workspace.OverlayVisible = false;
		Hide();
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		OverlayControls = nameScope?.Find<Grid>("OverlayControls");
		DragArea = nameScope?.Find<Border>("DragArea");
		LockButton = nameScope?.Find<Button>("LockButton");
		HideButton = nameScope?.Find<Button>("HideButton");
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, MacroOverlay P_1)
	{
		XamlIlContext.Context<MacroOverlay> context = new XamlIlContext.Context<MacroOverlay>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FMacros_002FMacroOverlay_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Macros/MacroOverlay.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Title = "Merostrap macro overlay";
		P_1.Width = 320.0;
		P_1.SizeToContent = SizeToContent.Height;
		P_1.MaxHeight = 500.0;
		P_1.CanResize = false;
		P_1.WindowDecorations = WindowDecorations.None;
		P_1.Topmost = true;
		P_1.ShowInTaskbar = false;
		P_1.ShowActivated = false;
		P_1.Background = new ImmutableSolidColorBrush(16777215u);
		P_1.TransparencyBackgroundFallback = new ImmutableSolidColorBrush(16777215u);
		P_1.TransparencyLevelHint = new WindowTransparencyLevel[1] { WindowTransparencyLevel.Transparent };
		P_1.Foreground = new ImmutableSolidColorBrush(4293717233u);
		P_1.RequestedThemeVariant = ThemeVariant.Dark;
		Styles styles = P_1.Styles;
		Style style = new Style();
		style.Selector = ((Selector?)null).OfType(typeof(Grid)).Class("overlayControls");
		Setter setter = new Setter();
		setter.Property = Visual.IsVisibleProperty;
		setter.Value = false;
		style.Add(setter);
		styles.Add(style);
		Styles styles2 = P_1.Styles;
		Style style2 = new Style();
		style2.Selector = ((Selector?)null).OfType(typeof(Window)).Class(":pointerover").Descendant()
			.OfType(typeof(Grid))
			.Class("overlayControls");
		Setter setter2 = new Setter();
		setter2.Property = Visual.IsVisibleProperty;
		setter2.Value = true;
		style2.Add(setter2);
		styles2.Add(style2);
		Styles styles3 = P_1.Styles;
		Style style3 = new Style();
		style3.Selector = ((Selector?)null).OfType(typeof(Button));
		Setter setter3 = new Setter();
		setter3.Property = Layoutable.WidthProperty;
		setter3.Value = 28.0;
		style3.Add(setter3);
		Setter setter4 = new Setter();
		setter4.Property = Layoutable.HeightProperty;
		setter4.Value = 28.0;
		style3.Add(setter4);
		Setter setter5 = new Setter();
		setter5.Property = TemplatedControl.PaddingProperty;
		setter5.Value = new Thickness(0.0, 0.0, 0.0, 0.0);
		style3.Add(setter5);
		Setter setter6 = new Setter();
		setter6.Property = TemplatedControl.BackgroundProperty;
		setter6.Value = new ImmutableSolidColorBrush(16777215u);
		style3.Add(setter6);
		Setter setter7 = new Setter();
		setter7.Property = TemplatedControl.BorderThicknessProperty;
		setter7.Value = new Thickness(0.0, 0.0, 0.0, 0.0);
		style3.Add(setter7);
		styles3.Add(style3);
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		P_1.Content = border;
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Border border5 = border4;
		border5.Background = new ImmutableSolidColorBrush(3087007744u);
		border5.BorderBrush = new ImmutableSolidColorBrush(822083583u);
		border5.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		border5.CornerRadius = new CornerRadius(0.0, 0.0, 0.0, 0.0);
		border5.Padding = new Thickness(8.0, 5.0, 8.0, 5.0);
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		border5.Child = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid5.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid5.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children.Add(grid6);
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		grid9.Name = "OverlayControls";
		object element = grid9;
		context.AvaloniaNameScope.Register("OverlayControls", element);
		grid9.Classes.Add("overlayControls");
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 2;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid9.ColumnDefinitions = columnDefinitions;
		Avalonia.Controls.Controls children2 = grid9.Children;
		Border border7;
		Border border6 = (border7 = new Border());
		((ISupportInitialize)border6).BeginInit();
		children2.Add(border6);
		Border border8 = (border4 = border7);
		context.PushParent(border4);
		Border border9 = border4;
		border9.Name = "DragArea";
		element = border9;
		context.AvaloniaNameScope.Register("DragArea", element);
		border9.Background = new ImmutableSolidColorBrush(16777215u);
		border9.AddHandler(InputElement.PointerPressedEvent, context.RootObject.DragPressed);
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		border9.Child = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		StackPanel stackPanel5 = stackPanel4;
		stackPanel5.Orientation = Orientation.Horizontal;
		stackPanel5.Spacing = 10.0;
		stackPanel5.VerticalAlignment = VerticalAlignment.Center;
		stackPanel5.Margin = new Thickness(8.0, 0.0, 8.0, 0.0);
		Avalonia.Controls.Controls children3 = stackPanel5.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children3.Add(textBlock);
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = textBlock2);
		context.PushParent(textBlock4);
		TextBlock textBlock5 = textBlock4;
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EHealth_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EMacros_002EHealthAutomation_002CMerostrap_002EEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock5.Bind(isVisibleProperty, binding);
		StyledProperty<string?> textProperty = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EHealth_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EMacros_002EHealthAutomation_002CMerostrap_002EReading_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock5.Bind(textProperty, binding2);
		textBlock5.FontSize = 10.0;
		textBlock5.Foreground = new ImmutableSolidColorBrush(4291995001u);
		ToolTip.SetTip(textBlock5, "Health");
		context.PopParent();
		((ISupportInitialize)textBlock3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)border8).EndInit();
		Avalonia.Controls.Controls children4 = grid9.Children;
		StackPanel stackPanel7;
		StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
		((ISupportInitialize)stackPanel6).BeginInit();
		children4.Add(stackPanel6);
		StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
		context.PushParent(stackPanel4);
		StackPanel stackPanel9 = stackPanel4;
		Grid.SetColumn(stackPanel9, 1);
		stackPanel9.Orientation = Orientation.Horizontal;
		stackPanel9.VerticalAlignment = VerticalAlignment.Center;
		stackPanel9.Spacing = 2.0;
		Avalonia.Controls.Controls children5 = stackPanel9.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children5.Add(button);
		Button button4;
		Button button3 = (button4 = button2);
		context.PushParent(button4);
		button4.Name = "LockButton";
		element = button4;
		context.AvaloniaNameScope.Register("LockButton", element);
		StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EToggleLockCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding3 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button4.Bind(commandProperty, binding3);
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002ELockLabel_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ToolTip.TipProperty;
		CompiledBinding compiledBinding = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_11((ToolTip)(object)button4, compiledBinding);
		AttachedProperty<string?> nameProperty = AutomationProperties.NameProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002ELockLabel_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = AutomationProperties.NameProperty;
		CompiledBinding binding4 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button4.Bind(nameProperty, binding4);
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		button4.Content = lucide;
		Lucide lucide4;
		Lucide lucide3 = (lucide4 = lucide2);
		context.PushParent(lucide4);
		StyledProperty<LucideIconNames> iconProperty = Lucide.IconProperty;
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002ELockIcon_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Lucide.IconProperty;
		CompiledBinding binding5 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide4.Bind(iconProperty, binding5);
		lucide4.Width = 15.0;
		lucide4.Height = 15.0;
		lucide4.StrokeBrush = new ImmutableSolidColorBrush(4291213055u);
		context.PopParent();
		((ISupportInitialize)lucide3).EndInit();
		context.PopParent();
		((ISupportInitialize)button3).EndInit();
		Avalonia.Controls.Controls children6 = stackPanel9.Children;
		Button button6;
		Button button5 = (button6 = new Button());
		((ISupportInitialize)button5).BeginInit();
		children6.Add(button5);
		button6.Name = "HideButton";
		element = button6;
		context.AvaloniaNameScope.Register("HideButton", element);
		button6.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.HideClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		ToolTip.SetTip(button6, "Hide overlay");
		AutomationProperties.SetName(button6, "Hide overlay");
		Lucide lucide6;
		Lucide lucide5 = (lucide6 = new Lucide());
		((ISupportInitialize)lucide5).BeginInit();
		button6.Content = lucide5;
		lucide6.Icon = LucideIconNames.X;
		lucide6.Width = 11.0;
		lucide6.Height = 11.0;
		((ISupportInitialize)lucide6).EndInit();
		((ISupportInitialize)button6).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel8).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		Avalonia.Controls.Controls children7 = grid5.Children;
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		children7.Add(scrollViewer);
		ScrollViewer scrollViewer4;
		ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
		context.PushParent(scrollViewer4);
		Grid.SetRow(scrollViewer4, 1);
		scrollViewer4.MaxHeight = 420.0;
		scrollViewer4.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
		scrollViewer4.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
		StackPanel stackPanel11;
		StackPanel stackPanel10 = (stackPanel11 = new StackPanel());
		((ISupportInitialize)stackPanel10).BeginInit();
		scrollViewer4.Content = stackPanel10;
		StackPanel stackPanel12 = (stackPanel4 = stackPanel11);
		context.PushParent(stackPanel4);
		StackPanel stackPanel13 = stackPanel4;
		Avalonia.Controls.Controls children8 = stackPanel13.Children;
		TextBlock textBlock7;
		TextBlock textBlock6 = (textBlock7 = new TextBlock());
		((ISupportInitialize)textBlock6).BeginInit();
		children8.Add(textBlock6);
		TextBlock textBlock8 = (textBlock4 = textBlock7);
		context.PushParent(textBlock4);
		TextBlock textBlock9 = textBlock4;
		textBlock9.Text = "No keybinds enabled";
		StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002ENoOverlayBindings_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding6 = compiledBindingExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock9.Bind(isVisibleProperty2, binding6);
		textBlock9.Foreground = new ImmutableSolidColorBrush(4288060586u);
		textBlock9.FontSize = 12.0;
		textBlock9.Margin = new Thickness(8.0, 6.0, 8.0, 6.0);
		context.PopParent();
		((ISupportInitialize)textBlock8).EndInit();
		Avalonia.Controls.Controls children9 = stackPanel13.Children;
		ItemsControl itemsControl2;
		ItemsControl itemsControl = (itemsControl2 = new ItemsControl());
		((ISupportInitialize)itemsControl).BeginInit();
		children9.Add(itemsControl);
		ItemsControl itemsControl4;
		ItemsControl itemsControl3 = (itemsControl4 = itemsControl2);
		context.PushParent(itemsControl4);
		StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EOverlayBindings_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding7 = compiledBindingExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		itemsControl4.Bind(itemsSourceProperty, binding7);
		DataTemplate dataTemplate;
		DataTemplate itemTemplate = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.DataType = typeof(MacroBindingSummary);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_28.Build_1), context);
		context.PopParent();
		itemsControl4.ItemTemplate = itemTemplate;
		context.PopParent();
		((ISupportInitialize)itemsControl3).EndInit();
		Avalonia.Controls.Controls children10 = stackPanel13.Children;
		TextBlock textBlock11;
		TextBlock textBlock10 = (textBlock11 = new TextBlock());
		((ISupportInitialize)textBlock10).BeginInit();
		children10.Add(textBlock10);
		TextBlock textBlock12 = (textBlock4 = textBlock11);
		context.PushParent(textBlock4);
		TextBlock textBlock13 = textBlock4;
		StyledProperty<string?> textProperty2 = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EHealth_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EMacros_002EHealthAutomation_002CMerostrap_002EDeafenStatus_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding8 = compiledBindingExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock13.Bind(textProperty2, binding8);
		StyledProperty<bool> isVisibleProperty3 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EMacros_002EMacroWorkspace_002CMerostrap_002EHealth_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EMacros_002EHealthAutomation_002CMerostrap_002EShowDeafenStatus_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding9 = compiledBindingExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock13.Bind(isVisibleProperty3, binding9);
		textBlock13.Foreground = new ImmutableSolidColorBrush(4291213055u);
		textBlock13.FontSize = 11.0;
		textBlock13.Margin = new Thickness(8.0, 2.0, 8.0, 5.0);
		context.PopParent();
		((ISupportInitialize)textBlock12).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel12).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(MacroOverlay P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
