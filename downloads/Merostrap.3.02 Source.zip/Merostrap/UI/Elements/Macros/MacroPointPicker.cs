using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Platform;

namespace Merostrap.UI.Elements.Macros;

public sealed class MacroPointPicker : Window
{
	private MacroPointPicker(Screen screen, string label, Action<PixelPoint?> finish)
	{
		MacroPointPicker macroPointPicker = this;
		WindowDecorations = WindowDecorations.None;
		Topmost = true;
		ShowInTaskbar = false;
		CanResize = false;
		Position = screen.Bounds.Position;
		Width = (double)screen.Bounds.Width / screen.Scaling;
		Height = (double)screen.Bounds.Height / screen.Scaling;
		Background = Brush.Parse("#20000000");
		TransparencyLevelHint = new _003C_003Ez__ReadOnlySingleElementList<WindowTransparencyLevel>(WindowTransparencyLevel.Transparent);
		Cursor = new Cursor(StandardCursorType.Cross);
		Content = new Border
		{
			HorizontalAlignment = HorizontalAlignment.Center,
			VerticalAlignment = VerticalAlignment.Top,
			Margin = new Thickness(16.0),
			Padding = new Thickness(16.0, 10.0),
			CornerRadius = new CornerRadius(6.0),
			Background = Brush.Parse("#EE181A20"),
			IsHitTestVisible = false,
			Child = new TextBlock
			{
				Text = "Click to pin " + label.ToLowerInvariant() + " · Esc cancels",
				Foreground = Brushes.White
			}
		};
		PointerReleased += (object? _, PointerReleasedEventArgs e) =>
		{
			if (e.InitialPressMouseButton == MouseButton.Left)
			{
				finish(macroPointPicker.PointToScreen(e.GetPosition(macroPointPicker)));
			}
		};
		KeyDown += (object? _, KeyEventArgs e) =>
		{
			if (e.Key == Key.Escape)
			{
				e.Handled = true;
				finish(null);
			}
		};
	}

	public static Task<PixelPoint?> PickAsync(Window owner, string label)
	{
		TaskCompletionSource<PixelPoint?> result = new TaskCompletionSource<PixelPoint?>(TaskCreationOptions.RunContinuationsAsynchronously);
		List<MacroPointPicker> windows = new List<MacroPointPicker>();
		try
		{
			foreach (Screen item in owner.Screens.All)
			{
				windows.Add(new MacroPointPicker(item, label, Finish));
			}
			if (windows.Count == 0)
			{
				Finish(null);
			}
			foreach (MacroPointPicker item2 in windows)
			{
				item2.Closed += (object? _, EventArgs _) =>
				{
					Finish(null);
				};
				item2.Show();
			}
		}
		catch
		{
			Finish(null);
			throw;
		}
		return result.Task;
		void Finish(PixelPoint? point)
		{
			if (!result.TrySetResult(point))
			{
				return;
			}
			foreach (MacroPointPicker item3 in windows)
			{
				item3.Close();
			}
		}
	}
}
