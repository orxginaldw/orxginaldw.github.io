using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AnimatedImage.Avalonia;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Controls.Presenters;
using Avalonia.Data;
using Avalonia.Markup.Xaml;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Platform;
using Avalonia.Styling;
using FluentAvalonia.Styling;
using Merostrap.Enums;
using Merostrap.Extensions;
using Merostrap.Models;
using Merostrap.UI.Utility;

namespace Merostrap.UI.Elements.Base;

internal abstract class AvaloniaWindow : Window
{
	private static IStyle? _activeColorStyle;

	private static ResourceDictionary? _activeThemeDictionary;

	private static IBrush? _currentBackgroundBrush;

	private static Bitmap? _currentBackgroundBitmap;

	private static string? _currentBitmapPath;

	private static string? _currentAnimatedImagePath;

	private static bool _currentIsAnimatedGif;

	private static Stretch _currentImageStretch;

	private static double _currentImageOpacity;

	private static readonly string[] AnimatedImageExtensions;

	private readonly Panel? _backgroundHost;

	private readonly Image? _backgroundImage;

	private readonly Border? _backgroundBorder;

	private readonly ContentPresenter? _contentHost;

	protected virtual bool ApplyTopPadding => true;

	static AvaloniaWindow()
	{
		_currentImageStretch = Stretch.UniformToFill;
		_currentImageOpacity = 1.0;
		AnimatedImageExtensions = new string[1] { ".gif" };
		StyledProperty<object?> contentProperty = ContentControl.ContentProperty;
		Func<AvaloniaObject, object, object> coerce = CoerceContent;
		contentProperty.OverrideMetadata<AvaloniaWindow>(new StyledPropertyMetadata<object>(default, BindingMode.Default, coerce));
	}

	private static object? CoerceContent(AvaloniaObject sender, object? value)
	{
		if (!(sender is AvaloniaWindow { _backgroundHost: not null } avaloniaWindow))
		{
			return value;
		}
		if (value == avaloniaWindow._backgroundHost)
		{
			return value;
		}
		ContentPresenter? contentHost = avaloniaWindow._contentHost;
		if (contentHost != null)
		{
			contentHost.Content = value;
		}
		return avaloniaWindow._backgroundHost;
	}

	public AvaloniaWindow()
	{
		Icon = new WindowIcon(AssetLoader.Open(new Uri("avares://Merostrap/Resources/Brand/Merostrap.ico")));
		Panel panel = (Panel)AvaloniaXamlLoader.Load(new Uri("avares://Merostrap/UI/Elements/Base/BackgroundPanel.axaml"));
		_backgroundBorder = panel.Find<Border>("PART_BackgroundBorder");
		_backgroundImage = panel.Find<Image>("PART_BackgroundImage");
		_contentHost = panel.Find<ContentPresenter>("PART_ContentHost");
		_backgroundHost = panel;
		if (_backgroundImage != null)
		{
			RenderOptions.SetBitmapInterpolationMode(_backgroundImage, BitmapInterpolationMode.HighQuality);
		}
		ApplyWindowBackground();
		WindowDecorations = WindowDecorations.Full;
		ExtendClientAreaToDecorationsHint = true;
		ExtendClientAreaTitleBarHeightHint = -1.0;
		MacOSTitleBar.SetIsThick(this, value: true);
		TextOptions.SetTextRenderingMode(this, TextRenderingMode.Antialias);
		if (ApplyTopPadding)
		{
			ContentPresenter? contentHost = _contentHost;
			if (contentHost != null)
			{
				contentHost.Margin = new Thickness(0.0, 32.0, 0.0, 0.0);
			}
		}
		ApplyTheme();
	}

	private void ApplyWindowBackground()
	{
		if (_backgroundHost == null || _backgroundImage == null || _backgroundBorder == null)
		{
			return;
		}
		bool num = _currentIsAnimatedGif || _currentBackgroundBitmap != null;
		_backgroundHost.Background = null;
		if (num)
		{
			_backgroundBorder.Background = null;
			_backgroundImage.IsVisible = true;
			_backgroundImage.Stretch = _currentImageStretch;
			_backgroundImage.Opacity = _currentImageOpacity;
			if (_currentIsAnimatedGif && _currentAnimatedImagePath != null)
			{
				Uri uri = new Uri(_currentAnimatedImagePath, UriKind.Absolute);
				ImageBehavior.SetAnimatedSource(_backgroundImage, new AnimatedImageSourceUri(uri));
				ImageBehavior.SetRepeatBehavior(_backgroundImage, RepeatBehavior.Forever);
				return;
			}
			if ((object)ImageBehavior.GetAnimatedSource(_backgroundImage) != null)
			{
				ImageBehavior.SetAnimatedSource(_backgroundImage, null);
			}
			_backgroundImage.Source = _currentBackgroundBitmap;
		}
		else
		{
			_backgroundImage.IsVisible = false;
			_backgroundImage.Source = null;
			if ((object)ImageBehavior.GetAnimatedSource(_backgroundImage) != null)
			{
				ImageBehavior.SetAnimatedSource(_backgroundImage, null);
			}
			_backgroundBorder.Background = _currentBackgroundBrush;
		}
	}

	public static void ApplyTheme()
	{
		if (Application.Current == null)
		{
			return;
		}
		Theme final = App.Settings.Prop.Theme.GetFinal();
		string text = Enum.GetName(final) ?? "Dark";
		Application.Current.RequestedThemeVariant = ((final == Merostrap.Enums.Theme.Light) ? ThemeVariant.Light : ThemeVariant.Dark);
		FluentAvaloniaTheme fluentAvaloniaTheme = Application.Current.Styles.OfType<FluentAvaloniaTheme>().FirstOrDefault();
		if (fluentAvaloniaTheme != null)
		{
			fluentAvaloniaTheme.PreferSystemTheme = false;
			fluentAvaloniaTheme.PreferUserAccentColor = true;
		}
		if (_activeThemeDictionary != null)
		{
			Application.Current.Resources.MergedDictionaries.Remove(_activeThemeDictionary);
			_activeThemeDictionary = null;
		}
		if (_activeColorStyle != null)
		{
			Application.Current.Styles.Remove(_activeColorStyle);
			_activeColorStyle = null;
		}
		IBrush brush = null;
		Bitmap currentBackgroundBitmap = null;
		string currentAnimatedImagePath = null;
		bool flag = false;
		Stretch currentImageStretch = Stretch.UniformToFill;
		double currentImageOpacity = 1.0;
		if (final != Merostrap.Enums.Theme.Custom)
		{
			try
			{
				if (AvaloniaXamlLoader.Load(new Uri("avares://Merostrap/UI/AppThemes/ResourceDictionarys/" + text + ".axaml")) is ResourceDictionary resourceDictionary)
				{
					_activeThemeDictionary = resourceDictionary;
					Application.Current.Resources.MergedDictionaries.Add(resourceDictionary);
					if (resourceDictionary.TryGetValue("ApplicationBackgroundColor", out object value))
					{
						brush = value as IBrush;
					}
				}
				if (AvaloniaXamlLoader.Load(new Uri("avares://Merostrap/UI/AppThemes/Styles/" + text + ".axaml")) is Styles styles)
				{
					_activeColorStyle = styles;
					Application.Current.Styles.Insert(1, styles);
				}
			}
			catch (Exception ex)
			{
				App.Logger.Error("Theme/Style loading error for " + text + ": " + ex.Message);
			}
		}
		else
		{
			ResourceDictionary item = (_activeThemeDictionary = new ResourceDictionary { ["NotificationBackgroundColor"] = new SolidColorBrush(Color.Parse("#2D2D2D")) });
			Application.Current.Resources.MergedDictionaries.Add(item);
			if (App.Settings.Prop.BackgroundType == BackgroundMode.Gradient)
			{
				Avalonia.Media.GradientStops gradientStops = new Avalonia.Media.GradientStops();
				foreach (Merostrap.Models.GradientStops customGradientStop in App.Settings.Prop.CustomGradientStops)
				{
					if (Color.TryParse(customGradientStop.Color, out var color))
					{
						gradientStops.Add(new GradientStop(color, customGradientStop.Offset));
					}
				}
				double num = App.Settings.Prop.GradientAngle ?? 45.0;
				double num2 = Math.PI / 180.0 * (num - 90.0);
				RelativePoint startPoint = new RelativePoint(0.5 - Math.Cos(num2) * 0.5, 0.5 - Math.Sin(num2) * 0.5, RelativeUnit.Relative);
				RelativePoint endPoint = new RelativePoint(0.5 + Math.Cos(num2) * 0.5, 0.5 + Math.Sin(num2) * 0.5, RelativeUnit.Relative);
				brush = new LinearGradientBrush
				{
					GradientStops = gradientStops,
					StartPoint = startPoint,
					EndPoint = endPoint
				};
			}
			else if (App.Settings.Prop.BackgroundType == BackgroundMode.Image)
			{
				string text2 = App.Settings.Prop.BackgroundImagePath ?? string.Empty;
				if (!string.IsNullOrEmpty(text2) && File.Exists(text2))
				{
					try
					{
						string extension = Path.GetExtension(text2);
						flag = AnimatedImageExtensions.Contains(extension, StringComparer.OrdinalIgnoreCase);
						if (flag)
						{
							currentAnimatedImagePath = text2;
						}
						else
						{
							currentBackgroundBitmap = ((text2 == _currentBitmapPath && _currentBackgroundBitmap != null) ? _currentBackgroundBitmap : new Bitmap(text2));
							_currentBitmapPath = text2;
						}
						currentImageStretch = (Stretch)App.Settings.Prop.BackgroundStretch;
						currentImageOpacity = App.Settings.Prop.BackgroundOpacity;
					}
					catch (Exception ex2)
					{
						App.Logger.Error("Image load error: " + ex2.Message);
					}
				}
				else
				{
					_currentBitmapPath = null;
				}
			}
		}
		_currentBackgroundBrush = brush ?? Brushes.Transparent;
		_currentBackgroundBitmap = currentBackgroundBitmap;
		_currentAnimatedImagePath = currentAnimatedImagePath;
		_currentIsAnimatedGif = flag;
		_currentImageStretch = currentImageStretch;
		_currentImageOpacity = currentImageOpacity;
		if (Application.Current.ApplicationLifetime is IClassicDesktopStyleApplicationLifetime classicDesktopStyleApplicationLifetime)
		{
			foreach (Window window in classicDesktopStyleApplicationLifetime.Windows)
			{
				if (window is AvaloniaWindow avaloniaWindow)
				{
					avaloniaWindow.ApplyWindowBackground();
				}
			}
		}
		UpdateBackdropForAllWindows();
	}

	public static void UpdateBackdropForAllWindows()
	{
		if (!(Application.Current?.ApplicationLifetime is IClassicDesktopStyleApplicationLifetime classicDesktopStyleApplicationLifetime))
		{
			return;
		}
		WindowsBackdrops selectedBackdrop = App.Settings.Prop.SelectedBackdrop;
		foreach (Window window2 in classicDesktopStyleApplicationLifetime.Windows)
		{
			if (selectedBackdrop != WindowsBackdrops.None)
			{
				Window window = window2;
				window.TransparencyLevelHint = selectedBackdrop switch
				{
					WindowsBackdrops.Acrylic => (IReadOnlyList<WindowTransparencyLevel>)new _003C_003Ez__ReadOnlyArray<WindowTransparencyLevel>(new WindowTransparencyLevel[2]
					{
						WindowTransparencyLevel.AcrylicBlur,
						WindowTransparencyLevel.None
					}), 
					WindowsBackdrops.Mica => new _003C_003Ez__ReadOnlyArray<WindowTransparencyLevel>(new WindowTransparencyLevel[2]
					{
						WindowTransparencyLevel.Mica,
						WindowTransparencyLevel.None
					}), 
					_ => new _003C_003Ez__ReadOnlySingleElementList<WindowTransparencyLevel>(WindowTransparencyLevel.None), 
				};
				window2.Background = Brushes.Transparent;
			}
			else
			{
				window2.TransparencyLevelHint = new _003C_003Ez__ReadOnlySingleElementList<WindowTransparencyLevel>(WindowTransparencyLevel.None);
			}
		}
	}

	protected override void OnOpened(EventArgs e)
	{
		base.OnOpened(e);
		ApplyWindowBackground();
		UpdateBackdropForAllWindows();
		Locale.ApplyLocaleToWindow(this);
	}

	protected override void OnClosed(EventArgs e)
	{
		base.OnClosed(e);
		if (_backgroundImage != null && (object)ImageBehavior.GetAnimatedSource(_backgroundImage) != null)
		{
			ImageBehavior.SetAnimatedSource(_backgroundImage, null);
		}
	}
}
