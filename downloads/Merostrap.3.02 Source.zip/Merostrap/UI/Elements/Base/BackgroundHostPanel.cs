using Avalonia;
using Avalonia.Controls;

namespace Merostrap.UI.Elements.Base;

internal class BackgroundHostPanel : Panel
{
	protected override Size MeasureOverride(Size availableSize)
	{
		Size result = default;
		foreach (Control child in Children)
		{
			child.Measure(availableSize);
			if (child.Name == "PART_ContentHost")
			{
				result = child.DesiredSize;
			}
		}
		return result;
	}

	protected override Size ArrangeOverride(Size finalSize)
	{
		foreach (Control child in Children)
		{
			child.Arrange(new Rect(finalSize));
		}
		return finalSize;
	}
}
