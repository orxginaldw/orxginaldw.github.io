using System;
using Avalonia.Controls;
using Avalonia.Media;
using Avalonia.Threading;
using Merostrap.Enums.BootstrapperDialogs;
using Merostrap.UI.Utility;
using Merostrap.UI.ViewModels.Bootstrapper;

namespace Merostrap.UI.Elements.Bootstrapper.Base;

internal class AvaloniaDialogBase : Window, IBootstrapperDialog
{
	public const int TaskbarProgressMaximum = 100;

	protected bool IsClosing;

	public Merostrap.Bootstrapper? Bootstrapper { get; set; }

	protected virtual string BackingMessage { get; set; } = "Please wait...";

	protected virtual int BackingProgressValue { get; set; }

	protected virtual int BackingProgressMaximum { get; set; }

	protected virtual bool BackingCancelEnabled { get; set; }

	protected virtual bool BackingProgressIndeterminate { get; set; }

	protected virtual double BackingTaskbarProgressValue { get; set; }

	protected virtual TaskbarItemProgressState BackingTaskbarProgressState { get; set; }

	public virtual string Message
	{
		get
		{
			return BackingMessage;
		}
		set
		{
			RunOnUI(() =>
			{
				BackingMessage = value;
			});
		}
	}

	public virtual string CancelButtonText
	{
		get
		{
			return ((BootstrapperDialogViewModel)DataContext).CancelButtonText;
		}
		set
		{
			RunOnUI(() =>
			{
				((BootstrapperDialogViewModel)DataContext).CancelButtonText = value;
			});
		}
	}

	public virtual int ProgressMaximum
	{
		get
		{
			return BackingProgressMaximum;
		}
		set
		{
			RunOnUI(() =>
			{
				BackingProgressMaximum = value;
			});
		}
	}

	public virtual int ProgressValue
	{
		get
		{
			return BackingProgressValue;
		}
		set
		{
			RunOnUI(() =>
			{
				BackingProgressValue = value;
			});
		}
	}

	public virtual bool CancelEnabled
	{
		get
		{
			return BackingCancelEnabled;
		}
		set
		{
			RunOnUI(() =>
			{
				BackingCancelEnabled = value;
			});
		}
	}

	public virtual bool ProgressIndeterminate
	{
		get
		{
			return BackingProgressIndeterminate;
		}
		set
		{
			RunOnUI(() =>
			{
				BackingProgressIndeterminate = value;
			});
		}
	}

	public virtual TaskbarItemProgressState TaskbarProgressState
	{
		get
		{
			return BackingTaskbarProgressState;
		}
		set
		{
			RunOnUI(() =>
			{
				BackingTaskbarProgressState = value;
				ApplyTaskbarState();
			});
		}
	}

	public virtual double TaskbarProgressValue
	{
		get
		{
			return BackingTaskbarProgressValue;
		}
		set
		{
			RunOnUI(() =>
			{
				BackingTaskbarProgressValue = value;
				ApplyTaskbarState();
			});
		}
	}

	public AvaloniaDialogBase()
	{
		WindowStartupLocation = WindowStartupLocation.CenterScreen;
		CanResize = false;
		WindowDecorations = WindowDecorations.None;
		TextOptions.SetTextRenderingMode(this, TextRenderingMode.Antialias);
		Closing += Dialog_Closing;
	}

	private void ApplyTaskbarState()
	{
		if (!OperatingSystem.IsWindows())
		{
			return;
		}
		nint num = TryGetPlatformHandle()?.Handle ?? IntPtr.Zero;
		if (num == IntPtr.Zero)
		{
			return;
		}
		try
		{
			TaskbarProgress.SetProgressState(num, BackingTaskbarProgressState);
			if (BackingTaskbarProgressState == TaskbarItemProgressState.Normal)
			{
				int progressValue = (int)Math.Clamp(BackingTaskbarProgressValue * 1000.0, 0.0, 1000.0);
				TaskbarProgress.SetProgressValue(num, progressValue, 1000);
			}
		}
		catch (Exception ex)
		{
			App.Logger.Error("Unhandled taskbar error: " + ex.Message);
		}
	}

	protected static void RunOnUI(Action action)
	{
		if (Avalonia.Threading.Dispatcher.UIThread.CheckAccess())
		{
			action();
		}
		else
		{
			Avalonia.Threading.Dispatcher.UIThread.Post(action);
		}
	}

	public void SetupDialog()
	{
		Title = App.Settings.Prop.BootstrapperTitle;
		if (Locale.RightToLeft)
		{
			FlowDirection = FlowDirection.RightToLeft;
		}
	}

	public void ButtonCancel_Click(object? sender, EventArgs e)
	{
		Close();
	}

	private void Dialog_Closing(object? sender, WindowClosingEventArgs e)
	{
		if (!IsClosing)
		{
			Bootstrapper?.Cancel();
		}
	}

	public void ShowBootstrapper()
	{
		Show();
	}

	public virtual void CloseBootstrapper()
	{
		RunOnUI(() =>
		{
			IsClosing = true;
			Close();
		});
	}

	public virtual void ShowSuccess(string message, Action? callback)
	{
		BaseFunctions.ShowSuccess(message, callback);
	}
}
