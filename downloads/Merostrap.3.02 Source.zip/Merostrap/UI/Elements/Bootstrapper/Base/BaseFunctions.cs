using System;

namespace Merostrap.UI.Elements.Bootstrapper.Base;

internal static class BaseFunctions
{
	public static async void ShowSuccess(string message, Action? callback)
	{
		await Frontend.ShowMessageBox(message);
		callback?.Invoke();
		App.Terminate();
	}
}
