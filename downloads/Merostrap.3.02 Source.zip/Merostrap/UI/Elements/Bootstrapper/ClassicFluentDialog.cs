using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using CompiledAvaloniaXaml;
using Merostrap.Extensions;
using Merostrap.UI.Elements.Bootstrapper.Base;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.ViewModels.Bootstrapper;

namespace Merostrap.UI.Elements.Bootstrapper;

internal class ClassicFluentDialog : AvaloniaDialogBase
{
	private readonly ClassicFluentDialogViewModel _viewModel;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public override string Message
	{
		get
		{
			return _viewModel.Message;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.OnPropertyChanged("Message");
			});
		}
	}

	public override int ProgressMaximum
	{
		get
		{
			return _viewModel.ProgressMaximum;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.ProgressMaximum = value;
				_viewModel.OnPropertyChanged("ProgressMaximum");
			});
		}
	}

	public override int ProgressValue
	{
		get
		{
			return _viewModel.ProgressValue;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.ProgressValue = value;
				_viewModel.OnPropertyChanged("ProgressValue");
			});
		}
	}

	public override bool CancelEnabled
	{
		get
		{
			return _viewModel.CancelEnabled;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.CancelEnabled = value;
				_viewModel.OnPropertyChanged("CancelEnabled");
				_viewModel.OnPropertyChanged("CancelButtonVisible");
			});
		}
	}

	public override bool ProgressIndeterminate
	{
		get
		{
			return _viewModel.ProgressIndeterminate;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.ProgressIndeterminate = value;
				_viewModel.OnPropertyChanged("ProgressIndeterminate");
			});
		}
	}

	public ClassicFluentDialog()
	{
		InitializeComponent();
		_viewModel = new ClassicFluentDialogViewModel(this);
		DataContext = _viewModel;
		SetupDialog();
		if (App.Settings.Prop.BootstrapperIcon.GetIcon()?.GetImageSource() is Bitmap bitmap)
		{
			Icon = new WindowIcon(bitmap);
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, ClassicFluentDialog P_1)
	{
		XamlIlContext.Context<ClassicFluentDialog> context = new XamlIlContext.Context<ClassicFluentDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FBootstrapper_002FClassicFluentDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Bootstrapper/ClassicFluentDialog.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Width = 420.0;
		P_1.Height = 190.0;
		P_1.CanResize = false;
		P_1.Title = "Merostrap";
		P_1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		P_1.ExtendClientAreaToDecorationsHint = true;
		P_1.ExtendClientAreaTitleBarHeightHint = -1.0;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 3;
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid5.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid5.Children;
		TitleBar titleBar2;
		TitleBar titleBar = (titleBar2 = new TitleBar());
		((ISupportInitialize)titleBar).BeginInit();
		children.Add(titleBar);
		TitleBar titleBar4;
		TitleBar titleBar3 = (titleBar4 = titleBar2);
		context.PushParent(titleBar4);
		Grid.SetRow(titleBar4, 0);
		StyledProperty<IImage?> iconProperty = TitleBar.IconProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002EIcon_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TitleBar.IconProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		titleBar4.Bind(iconProperty, binding);
		titleBar4.Title = "Merostrap";
		titleBar4.ShowMinimize = false;
		titleBar4.ShowMaximize = false;
		titleBar4.ShowClose = false;
		context.PopParent();
		((ISupportInitialize)titleBar3).EndInit();
		Avalonia.Controls.Controls children2 = grid5.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children2.Add(grid6);
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		Grid.SetRow(grid9, 1);
		grid9.Margin = new Thickness(16.0, 0.0, 16.0, 0.0);
		grid9.VerticalAlignment = VerticalAlignment.Center;
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 2;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid9.ColumnDefinitions = columnDefinitions;
		Avalonia.Controls.Controls children3 = grid9.Children;
		Image image2;
		Image image = (image2 = new Image());
		((ISupportInitialize)image).BeginInit();
		children3.Add(image);
		Image image4;
		Image image3 = (image4 = image2);
		context.PushParent(image4);
		Grid.SetColumn(image4, 0);
		image4.Width = 48.0;
		image4.Height = 48.0;
		image4.VerticalAlignment = VerticalAlignment.Top;
		StyledProperty<IImage?> sourceProperty = Image.SourceProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002EIcon_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Image.SourceProperty;
		CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		image4.Bind(sourceProperty, binding2);
		RenderOptions.SetBitmapInterpolationMode(image4, BitmapInterpolationMode.HighQuality);
		context.PopParent();
		((ISupportInitialize)image3).EndInit();
		Avalonia.Controls.Controls children4 = grid9.Children;
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		children4.Add(stackPanel);
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		Grid.SetColumn(stackPanel4, 1);
		stackPanel4.Margin = new Thickness(16.0, 0.0, 0.0, 0.0);
		Avalonia.Controls.Controls children5 = stackPanel4.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children5.Add(textBlock);
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = textBlock2);
		context.PushParent(textBlock4);
		textBlock4.FontSize = 20.0;
		StyledProperty<string?> textProperty = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002EMessage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding3 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock4.Bind(textProperty, binding3);
		textBlock4.TextWrapping = TextWrapping.Wrap;
		StaticResourceExtension staticResourceExtension = new StaticResourceExtension("BodyTextBlockStyle");
		context.ProvideTargetProperty = StyledElement.ThemeProperty;
		object? obj = staticResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_3(textBlock4, obj);
		context.PopParent();
		((ISupportInitialize)textBlock3).EndInit();
		Avalonia.Controls.Controls children6 = stackPanel4.Children;
		ProgressBar progressBar2;
		ProgressBar progressBar = (progressBar2 = new ProgressBar());
		((ISupportInitialize)progressBar).BeginInit();
		children6.Add(progressBar);
		ProgressBar progressBar4;
		ProgressBar progressBar3 = (progressBar4 = progressBar2);
		context.PushParent(progressBar4);
		progressBar4.Margin = new Thickness(0.0, 16.0, 0.0, 0.0);
		StyledProperty<bool> isIndeterminateProperty = ProgressBar.IsIndeterminateProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002EProgressIndeterminate_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ProgressBar.IsIndeterminateProperty;
		CompiledBinding binding4 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		progressBar4.Bind(isIndeterminateProperty, binding4);
		StyledProperty<double> maximumProperty = RangeBase.MaximumProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002EProgressMaximum_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = RangeBase.MaximumProperty;
		CompiledBinding binding5 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		progressBar4.Bind(maximumProperty, binding5);
		StyledProperty<double> valueProperty = RangeBase.ValueProperty;
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002EProgressValue_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = RangeBase.ValueProperty;
		CompiledBinding binding6 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		progressBar4.Bind(valueProperty, binding6);
		context.PopParent();
		((ISupportInitialize)progressBar3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		Avalonia.Controls.Controls children7 = grid5.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children7.Add(border);
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Grid.SetRow(border4, 2);
		border4.Padding = new Thickness(15.0, 15.0, 15.0, 15.0);
		SolidColorBrush solidColorBrush;
		SolidColorBrush background = (solidColorBrush = new SolidColorBrush());
		context.PushParent(solidColorBrush);
		StyledProperty<Color> colorProperty = SolidColorBrush.ColorProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("SolidBackgroundFillColorSecondary");
		context.ProvideTargetProperty = SolidColorBrush.ColorProperty;
		BindingBase binding7 = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		solidColorBrush.Bind(colorProperty, binding7);
		StyledProperty<double> opacityProperty = Brush.OpacityProperty;
		CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EClassicFluentDialogViewModel_002CMerostrap_002EFooterOpacity_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Brush.OpacityProperty;
		CompiledBinding binding8 = compiledBindingExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		solidColorBrush.Bind(opacityProperty, binding8);
		context.PopParent();
		border4.Background = background;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		border4.Child = button;
		Button button4;
		Button button3 = (button4 = button2);
		context.PushParent(button4);
		CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002ECancelButtonText_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ContentControl.ContentProperty;
		CompiledBinding compiledBinding = compiledBindingExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_4(button4, compiledBinding);
		button4.Width = 120.0;
		button4.HorizontalAlignment = HorizontalAlignment.Right;
		StyledProperty<bool> isEnabledProperty = InputElement.IsEnabledProperty;
		CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002ECancelEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = InputElement.IsEnabledProperty;
		CompiledBinding binding9 = compiledBindingExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button4.Bind(isEnabledProperty, binding9);
		StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002ECancelInstallCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding10 = compiledBindingExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button4.Bind(commandProperty, binding10);
		context.PopParent();
		((ISupportInitialize)button3).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(ClassicFluentDialog P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
