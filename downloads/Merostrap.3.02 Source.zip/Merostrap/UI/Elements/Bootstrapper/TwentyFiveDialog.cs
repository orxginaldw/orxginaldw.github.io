using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.Converters;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Media.Immutable;
using CompiledAvaloniaXaml;
using Merostrap.Extensions;
using Merostrap.UI.Elements.Bootstrapper.Base;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.ViewModels.Bootstrapper;

namespace Merostrap.UI.Elements.Bootstrapper;

internal class TwentyFiveDialog : AvaloniaDialogBase
{
	private readonly TwentyFiveDialogViewModel _viewModel;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public override string Message
	{
		get
		{
			return _viewModel.Message;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.Message = value;
				_viewModel.OnPropertyChanged("Message");
			});
		}
	}

	public override int ProgressMaximum
	{
		get
		{
			return _viewModel.ProgressMaximum;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.ProgressMaximum = value;
				_viewModel.OnPropertyChanged("ProgressMaximum");
			});
		}
	}

	public override int ProgressValue
	{
		get
		{
			return _viewModel.ProgressValue;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.ProgressValue = value;
				_viewModel.OnPropertyChanged("ProgressValue");
			});
		}
	}

	public override bool CancelEnabled
	{
		get
		{
			return _viewModel.CancelEnabled;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.CancelEnabled = value;
				_viewModel.OnPropertyChanged("CancelEnabled");
			});
		}
	}

	public override bool ProgressIndeterminate
	{
		get
		{
			return _viewModel.ProgressIndeterminate;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.ProgressIndeterminate = value;
				_viewModel.OnPropertyChanged("ProgressIndeterminate");
			});
		}
	}

	public TwentyFiveDialog()
	{
		_viewModel = new TwentyFiveDialogViewModel(this);
		DataContext = _viewModel;
		InitializeComponent();
		SetupDialog();
		if (App.Settings.Prop.BootstrapperIcon.GetIcon()?.GetImageSource() is Bitmap bitmap)
		{
			Icon = new WindowIcon(bitmap);
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, TwentyFiveDialog P_1)
	{
		XamlIlContext.Context<TwentyFiveDialog> context = new XamlIlContext.Context<TwentyFiveDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FBootstrapper_002FTwentyFiveDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Bootstrapper/TwentyFiveDialog.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Width = 576.0;
		P_1.Height = 482.0;
		P_1.CanResize = false;
		P_1.Title = "Merostrap";
		P_1.WindowDecorations = WindowDecorations.None;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		P_1.ExtendClientAreaToDecorationsHint = true;
		P_1.Background = new ImmutableSolidColorBrush(4278190080u);
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		Avalonia.Controls.Controls children = grid5.Children;
		TitleBar titleBar2;
		TitleBar titleBar = (titleBar2 = new TitleBar());
		((ISupportInitialize)titleBar).BeginInit();
		children.Add(titleBar);
		titleBar2.VerticalAlignment = VerticalAlignment.Top;
		titleBar2.Title = "";
		titleBar2.Icon = null;
		titleBar2.ShowClose = false;
		titleBar2.ShowMaximize = false;
		titleBar2.ShowMinimize = false;
		((ISupportInitialize)titleBar2).EndInit();
		Avalonia.Controls.Controls children2 = grid5.Children;
		Image image2;
		Image image = (image2 = new Image());
		((ISupportInitialize)image).BeginInit();
		children2.Add(image);
		Image image4;
		Image image3 = (image4 = image2);
		context.PushParent(image4);
		Image image5 = image4;
		image5.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "avares://Merostrap/Resources/BootstrapperStyles/TwentyFiveDialog/PlayerLogo.png");
		image5.Height = 254.0;
		image5.Width = 254.0;
		image5.HorizontalAlignment = HorizontalAlignment.Center;
		image5.VerticalAlignment = VerticalAlignment.Top;
		image5.Margin = new Thickness(0.0, 60.0, 0.0, 0.0);
		context.PopParent();
		((ISupportInitialize)image3).EndInit();
		Avalonia.Controls.Controls children3 = grid5.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children3.Add(grid6);
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		grid9.VerticalAlignment = VerticalAlignment.Bottom;
		grid9.Background = new ImmutableSolidColorBrush(4279835167u);
		grid9.Height = 91.0;
		Avalonia.Controls.Controls children4 = grid9.Children;
		ProgressBar progressBar2;
		ProgressBar progressBar = (progressBar2 = new ProgressBar());
		((ISupportInitialize)progressBar).BeginInit();
		children4.Add(progressBar);
		ProgressBar progressBar4;
		ProgressBar progressBar3 = (progressBar4 = progressBar2);
		context.PushParent(progressBar4);
		progressBar4.VerticalAlignment = VerticalAlignment.Top;
		progressBar4.Height = 6.0;
		progressBar4.Foreground = new ImmutableSolidColorBrush(uint.MaxValue);
		progressBar4.Background = new ImmutableSolidColorBrush(16777215u);
		progressBar4.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
		StyledProperty<bool> isIndeterminateProperty = ProgressBar.IsIndeterminateProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002EProgressIndeterminate_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ProgressBar.IsIndeterminateProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		progressBar4.Bind(isIndeterminateProperty, binding);
		StyledProperty<double> maximumProperty = RangeBase.MaximumProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002EProgressMaximum_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = RangeBase.MaximumProperty;
		CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		progressBar4.Bind(maximumProperty, binding2);
		StyledProperty<double> valueProperty = RangeBase.ValueProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002EProgressValue_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = RangeBase.ValueProperty;
		CompiledBinding binding3 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		progressBar4.Bind(valueProperty, binding3);
		context.PopParent();
		((ISupportInitialize)progressBar3).EndInit();
		Avalonia.Controls.Controls children5 = grid9.Children;
		Image image7;
		Image image6 = (image7 = new Image());
		((ISupportInitialize)image6).BeginInit();
		children5.Add(image6);
		Image image8 = (image4 = image7);
		context.PushParent(image4);
		Image image9 = image4;
		image9.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "avares://Merostrap/Resources/BootstrapperStyles/TwentyFiveDialog/Roblox.png");
		image9.Height = 32.0;
		image9.Width = 103.0;
		image9.HorizontalAlignment = HorizontalAlignment.Left;
		image9.VerticalAlignment = VerticalAlignment.Center;
		image9.Margin = new Thickness(30.0, 0.0, 0.0, 0.0);
		context.PopParent();
		((ISupportInitialize)image8).EndInit();
		Avalonia.Controls.Controls children6 = grid9.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children6.Add(button);
		Button button4;
		Button button3 = (button4 = button2);
		context.PushParent(button4);
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002ECancelButtonText_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ContentControl.ContentProperty;
		CompiledBinding compiledBinding = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_4(button4, compiledBinding);
		button4.HorizontalAlignment = HorizontalAlignment.Right;
		button4.VerticalAlignment = VerticalAlignment.Center;
		button4.Margin = new Thickness(0.0, 0.0, 32.0, 0.0);
		button4.Width = 64.0;
		button4.Height = 38.0;
		button4.CornerRadius = new CornerRadius(0.0, 0.0, 0.0, 0.0);
		StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002ECancelInstallCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding4 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button4.Bind(commandProperty, binding4);
		StyledProperty<bool> isEnabledProperty = InputElement.IsEnabledProperty;
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002ECancelEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = InputElement.IsEnabledProperty;
		CompiledBinding binding5 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button4.Bind(isEnabledProperty, binding5);
		context.PopParent();
		((ISupportInitialize)button3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(TwentyFiveDialog P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
