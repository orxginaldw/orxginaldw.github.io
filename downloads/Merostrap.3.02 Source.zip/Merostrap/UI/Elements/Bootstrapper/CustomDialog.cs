using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Xml.Linq;
using AnimatedImage.Avalonia;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Controls.Shapes;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Fonts;
using Avalonia.Media.Imaging;
using Avalonia.Styling;
using CompiledAvaloniaXaml;
using FluentAvalonia.UI.Controls;
using Merostrap.Enums;
using Merostrap.Exceptions;
using Merostrap.Extensions;
using Merostrap.Resources;
using Merostrap.UI.Elements.Bootstrapper.Base;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.Utility;
using Merostrap.UI.ViewModels.Bootstrapper;
using Merostrap.Utility;

namespace Merostrap.UI.Elements.Bootstrapper;

internal class CustomDialog : AvaloniaDialogBase
{
	private class DummyControl : Control
	{
	}

	private delegate object HandleXmlElementDelegate(CustomDialog dialog, XElement xmlElement);

	private struct GetImageSourceDataResult
	{
		public bool IsIcon = false;

		public string? Path = null;

		public GetImageSourceDataResult()
		{
		}
	}

	private readonly record struct LoadedFont(string Name, string Reference);

	private readonly BootstrapperDialogViewModel _viewModel;

	private const int Version = 1;

	private const int MaxElements = 150;

	private bool _initialised;

	private readonly List<string> UsedNames = new List<string>();

	private static readonly Dictionary<string, HandleXmlElementDelegate> _elementHandlerMap = new Dictionary<string, HandleXmlElementDelegate>
	{
		["BloxstrapCustomBootstrapper"] = HandleXmlElement_BloxstrapCustomBootstrapper_Fake,
		["TitleBar"] = HandleXmlElement_TitleBar,
		["Button"] = HandleXmlElement_Button,
		["ProgressBar"] = HandleXmlElement_ProgressBar,
		["ProgressRing"] = HandleXmlElement_ProgressRing,
		["TextBlock"] = HandleXmlElement_TextBlock,
		["MarkdownTextBlock"] = HandleXmlElement_MarkdownTextBlock,
		["Image"] = HandleXmlElement_Image,
		["Grid"] = HandleXmlElement_Grid,
		["StackPanel"] = HandleXmlElement_StackPanel,
		["Border"] = HandleXmlElement_Border,
		["SolidColorBrush"] = HandleXmlElement_SolidColorBrush,
		["ImageBrush"] = HandleXmlElement_ImageBrush,
		["LinearGradientBrush"] = HandleXmlElement_LinearGradientBrush,
		["GradientStop"] = HandleXmlElement_GradientStop,
		["ScaleTransform"] = HandleXmlElement_ScaleTransform,
		["SkewTransform"] = HandleXmlElement_SkewTransform,
		["RotateTransform"] = HandleXmlElement_RotateTransform,
		["TranslateTransform"] = HandleXmlElement_TranslateTransform,
		["DropShadowEffect"] = HandleXmlElement_DropShadowEffect,
		["BlurEffect"] = HandleXmlElement_BlurEffect,
		["Ellipse"] = HandleXmlElement_Ellipse,
		["Line"] = HandleXmlElement_Line,
		["Rectangle"] = HandleXmlElement_Rectangle,
		["RowDefinition"] = HandleXmlElement_RowDefinition,
		["ColumnDefinition"] = HandleXmlElement_ColumnDefinition
	};

	private readonly List<Image> _animatedImages = new List<Image>();

	private static readonly string[] _fontFileExtensions = new string[3] { ".ttf", ".otf", ".ttc" };

	private static readonly Dictionary<string, LoadedFont?> _customFontCache = new Dictionary<string, LoadedFont?>(StringComparer.OrdinalIgnoreCase);

	private static readonly Lock _customFontLock = new Lock();

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TitleBar RootTitleBar;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Grid ElementGrid;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public override string Message
	{
		get
		{
			return _viewModel.Message;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.Message = value;
				_viewModel.OnPropertyChanged("Message");
			});
		}
	}

	public override int ProgressMaximum
	{
		get
		{
			return _viewModel.ProgressMaximum;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.ProgressMaximum = value;
				_viewModel.OnPropertyChanged("ProgressMaximum");
			});
		}
	}

	public override int ProgressValue
	{
		get
		{
			return _viewModel.ProgressValue;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.ProgressValue = value;
				_viewModel.OnPropertyChanged("ProgressValue");
			});
		}
	}

	public override bool CancelEnabled
	{
		get
		{
			return _viewModel.CancelEnabled;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.CancelEnabled = value;
				_viewModel.OnPropertyChanged("CancelEnabled");
				_viewModel.OnPropertyChanged("CancelButtonVisible");
			});
		}
	}

	public override bool ProgressIndeterminate
	{
		get
		{
			return _viewModel.ProgressIndeterminate;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.ProgressIndeterminate = value;
				_viewModel.OnPropertyChanged("ProgressIndeterminate");
			});
		}
	}

	private string ThemeDir { get; set; } = "";

	public CustomDialog()
	{
		InitializeComponent();
		_viewModel = new BootstrapperDialogViewModel(this);
		DataContext = _viewModel;
		SetupDialog();
		Bitmap icon = App.Settings.Prop.BootstrapperIcon.GetIcon();
		Icon = ((icon == null) ? null : new WindowIcon(icon));
		Loaded += (object? s, RoutedEventArgs e) =>
		{
			RootTitleBar.PointerPressed += (object? sender, PointerPressedEventArgs args) =>
			{
				BeginMoveDrag(args);
				args.Handled = true;
			};
		};
		Closing += CustomDialog_Closing;
	}

	private void CustomDialog_Closing(object? sender, WindowClosingEventArgs e)
	{
		foreach (Image animatedImage in _animatedImages)
		{
			if (animatedImage.GetValue(ImageBehavior.AnimatedSourceProperty) is AnimatedImageSourceStream { StreamSource: MemoryStream streamSource })
			{
				streamSource.Dispose();
			}
			animatedImage.ClearValue(ImageBehavior.AnimatedSourceProperty);
		}
		_animatedImages.Clear();
	}

	private static T? ConvertValue<T>(string input) where T : struct
	{
		try
		{
			return (T?)TypeDescriptor.GetConverter(typeof(T))?.ConvertFromInvariantString(input);
		}
		catch (NotSupportedException)
		{
			return null;
		}
	}

	private static Thickness? GetThicknessFromXElement(XElement xmlElement, string attributeName)
	{
		string text = xmlElement.Attribute(attributeName)?.Value;
		if (string.IsNullOrEmpty(text))
		{
			return null;
		}
		try
		{
			return Thickness.Parse(text);
		}
		catch (Exception innerException)
		{
			throw new CustomThemeException(innerException, "CustomTheme.Errors.ElementAttributeConversionError", xmlElement.Name, attributeName, "Could not parse '" + text + "' as Thickness");
		}
	}

	private static Color? GetColorFromXElement(XElement xmlElement, string attributeName)
	{
		string text = xmlElement.Attribute(attributeName)?.Value;
		if (string.IsNullOrEmpty(text))
		{
			return null;
		}
		try
		{
			return Color.Parse(text);
		}
		catch (Exception innerException)
		{
			throw new CustomThemeException(innerException, "CustomTheme.Errors.ElementAttributeConversionError", xmlElement.Name, attributeName, "Could not parse '" + text + "' as Color");
		}
	}

	private static Point? GetPointFromXElement(XElement xmlElement, string attributeName)
	{
		string text = xmlElement.Attribute(attributeName)?.Value;
		if (string.IsNullOrEmpty(text))
		{
			return null;
		}
		try
		{
			return Point.Parse(text);
		}
		catch (Exception innerException)
		{
			throw new CustomThemeException(innerException, "CustomTheme.Errors.ElementAttributeConversionError", xmlElement.Name, attributeName, "Could not parse '" + text + "' as Point");
		}
	}

	private static CornerRadius? GetCornerRadiusFromXElement(XElement xmlElement, string attributeName)
	{
		string text = xmlElement.Attribute(attributeName)?.Value;
		if (string.IsNullOrEmpty(text))
		{
			return null;
		}
		try
		{
			return CornerRadius.Parse(text);
		}
		catch (Exception innerException)
		{
			throw new CustomThemeException(innerException, "CustomTheme.Errors.ElementAttributeConversionError", xmlElement.Name, attributeName, "Could not parse '" + text + "' as CornerRadius");
		}
	}

	private static GridLength? GetGridLengthFromXElement(XElement xmlElement, string attributeName)
	{
		string text = xmlElement.Attribute(attributeName)?.Value;
		if (string.IsNullOrEmpty(text))
		{
			return null;
		}
		try
		{
			return GridLength.Parse(text);
		}
		catch (Exception innerException)
		{
			throw new CustomThemeException(innerException, "CustomTheme.Errors.ElementAttributeConversionError", xmlElement.Name, attributeName, "Could not parse '" + text + "' as GridLength");
		}
	}

	private static object? GetBrushFromXElement(XElement element, string attributeName)
	{
		string text = element.Attribute(attributeName)?.Value;
		if (string.IsNullOrEmpty(text))
		{
			return null;
		}
		if (text.StartsWith('{') && text.EndsWith('}'))
		{
			string text2 = text;
			return text2.Substring(1, text2.Length - 1 - 1);
		}
		try
		{
			return Brush.Parse(text);
		}
		catch (Exception ex)
		{
			throw new CustomThemeException(ex, "CustomTheme.Errors.ElementAttributeConversionError", element.Name, attributeName, ex.Message);
		}
	}

	private static T HandleXml<T>(CustomDialog dialog, XElement xmlElement) where T : class
	{
		if (!_elementHandlerMap.ContainsKey(xmlElement.Name.ToString()))
		{
			throw new CustomThemeException("CustomTheme.Errors.UnknownElement", xmlElement.Name);
		}
		object obj = _elementHandlerMap[xmlElement.Name.ToString()](dialog, xmlElement);
		if (!(obj is T))
		{
			throw new CustomThemeException("CustomTheme.Errors.ElementInvalidChild", xmlElement.Parent.Name, xmlElement.Name);
		}
		return (T)obj;
	}

	private static void AddXml(CustomDialog dialog, XElement xmlElement)
	{
		if (!xmlElement.Name.ToString().Contains('.', StringComparison.Ordinal))
		{
			Control control = HandleXml<Control>(dialog, xmlElement);
			if (!(control is DummyControl))
			{
				dialog.ElementGrid.Children.Add(control);
			}
		}
	}

	private static void AssertThemeVersion(string? versionStr)
	{
		if (string.IsNullOrEmpty(versionStr))
		{
			throw new CustomThemeException("CustomTheme.Errors.VersionNotSet", "BloxstrapCustomBootstrapper");
		}
		if (!uint.TryParse(versionStr, out var result))
		{
			throw new CustomThemeException("CustomTheme.Errors.VersionNotNumber", "BloxstrapCustomBootstrapper");
		}
		switch (result)
		{
		case 0u:
			throw new CustomThemeException("CustomTheme.Errors.VersionNotSupported", "BloxstrapCustomBootstrapper", result);
		default:
			throw new CustomThemeException("CustomTheme.Errors.VersionNotRecognised", "BloxstrapCustomBootstrapper", result);
		case 1u:
			break;
		}
	}

	private void HandleXmlBase(XElement xml)
	{
		if (_initialised)
		{
			throw new CustomThemeException("CustomTheme.Errors.DialogAlreadyInitialised");
		}
		if (xml.Name != "BloxstrapCustomBootstrapper")
		{
			throw new CustomThemeException("CustomTheme.Errors.InvalidRoot", "BloxstrapCustomBootstrapper");
		}
		AssertThemeVersion(xml.Attribute("Version")?.Value);
		if (xml.Descendants().Count() > 150)
		{
			throw new CustomThemeException("CustomTheme.Errors.TooManyElements", 150, xml.Descendants().Count());
		}
		_initialised = true;
		HandleXmlElement_BloxstrapCustomBootstrapper(this, xml);
		foreach (XElement item in xml.Elements())
		{
			AddXml(this, item);
		}
	}

	public void ApplyCustomTheme(string name, string contents)
	{
		ThemeDir = System.IO.Path.Combine(Paths.CustomThemes, name);
		string s = ThemeXamlConverter.ConvertThemeXaml(contents);
		XElement xml;
		try
		{
			using MemoryStream stream = new MemoryStream(Encoding.UTF8.GetBytes(s));
			xml = XElement.Load(stream);
		}
		catch (Exception ex)
		{
			throw new CustomThemeException(ex, "CustomTheme.Errors.XMLParseFailed", ex.Message);
		}
		HandleXmlBase(xml);
	}

	public void ApplyCustomTheme(string name)
	{
		string text = System.IO.Path.Combine(Paths.CustomThemes, name, "Theme.xml");
		if (!File.Exists(text))
		{
			throw new CustomThemeException("CustomTheme.Errors.FileNotFound", text);
		}
		ApplyCustomTheme(name, File.ReadAllText(text));
	}

	private static ScaleTransform HandleXmlElement_ScaleTransform(CustomDialog dialog, XElement xmlElement)
	{
		return new ScaleTransform
		{
			ScaleX = ParseXmlAttribute(xmlElement, "ScaleX", 1.0),
			ScaleY = ParseXmlAttribute(xmlElement, "ScaleY", 1.0)
		};
	}

	private static SkewTransform HandleXmlElement_SkewTransform(CustomDialog dialog, XElement xmlElement)
	{
		return new SkewTransform
		{
			AngleX = ParseXmlAttribute(xmlElement, "AngleX", 0.0),
			AngleY = ParseXmlAttribute(xmlElement, "AngleY", 0.0)
		};
	}

	private static RotateTransform HandleXmlElement_RotateTransform(CustomDialog dialog, XElement xmlElement)
	{
		return new RotateTransform
		{
			Angle = ParseXmlAttribute(xmlElement, "Angle", 0.0)
		};
	}

	private static TranslateTransform HandleXmlElement_TranslateTransform(CustomDialog dialog, XElement xmlElement)
	{
		return new TranslateTransform
		{
			X = ParseXmlAttribute(xmlElement, "X", 0.0),
			Y = ParseXmlAttribute(xmlElement, "Y", 0.0)
		};
	}

	private static BlurEffect HandleXmlElement_BlurEffect(CustomDialog dialog, XElement xmlElement)
	{
		return new BlurEffect
		{
			Radius = ParseXmlAttribute(xmlElement, "Radius", 5.0)
		};
	}

	private static object HandleXmlElement_DropShadowEffect(CustomDialog dialog, XElement xmlElement)
	{
		double blur = ParseXmlAttribute(xmlElement, "BlurRadius", 5.0);
		double num = ParseXmlAttribute(xmlElement, "Direction", 315.0);
		double num2 = ParseXmlAttribute(xmlElement, "Opacity", 1.0);
		double num3 = ParseXmlAttribute(xmlElement, "ShadowDepth", 5.0);
		double num4 = num * (Math.PI / 180.0);
		double offsetX = num3 * Math.Cos(num4);
		double offsetY = (0.0 - num3) * Math.Sin(num4);
		Color? colorFromXElement = GetColorFromXElement(xmlElement, "Color");
		Color color;
		if (colorFromXElement.HasValue)
		{
			Color valueOrDefault = colorFromXElement.GetValueOrDefault();
			color = valueOrDefault;
		}
		else
		{
			color = Colors.Black;
		}
		Color color2 = color;
		Color color3 = Color.FromArgb((byte)(num2 * 255.0), color2.R, color2.G, color2.B);
		return new BoxShadows(new BoxShadow
		{
			OffsetX = offsetX,
			OffsetY = offsetY,
			Blur = blur,
			Spread = 0.0,
			Color = color3
		});
	}

	private static void HandleXml_Brush(Brush brush, XElement xmlElement)
	{
		brush.Opacity = ParseXmlAttribute(xmlElement, "Opacity", 1.0);
	}

	private static SolidColorBrush HandleXmlElement_SolidColorBrush(CustomDialog dialog, XElement xmlElement)
	{
		SolidColorBrush solidColorBrush = new SolidColorBrush();
		HandleXml_Brush(solidColorBrush, xmlElement);
		if (GetColorFromXElement(xmlElement, "Color") is Color color)
		{
			solidColorBrush.Color = color;
		}
		return solidColorBrush;
	}

	private static ImageBrush HandleXmlElement_ImageBrush(CustomDialog dialog, XElement xmlElement)
	{
		ImageBrush imageBrush = new ImageBrush();
		HandleXml_Brush(imageBrush, xmlElement);
		imageBrush.AlignmentX = ParseXmlAttribute(xmlElement, "AlignmentX", AlignmentX.Center);
		imageBrush.AlignmentY = ParseXmlAttribute(xmlElement, "AlignmentY", AlignmentY.Center);
		imageBrush.Stretch = ParseXmlAttribute(xmlElement, "Stretch", Stretch.Fill);
		imageBrush.TileMode = ParseXmlAttribute(xmlElement, "TileMode", TileMode.None);
		GetImageSourceDataResult imageSourceData = GetImageSourceData(dialog, "ImageSource", xmlElement);
		if (imageSourceData.IsIcon)
		{
			Binding binding = new Binding("Icon")
			{
				Mode = BindingMode.OneWay
			};
			imageBrush.Bind(ImageBrush.SourceProperty, binding);
		}
		else if (imageSourceData.Path != null)
		{
			Bitmap source;
			try
			{
				source = new Bitmap(imageSourceData.Path);
			}
			catch (Exception ex)
			{
				throw new CustomThemeException(ex, "CustomTheme.Errors.ElementTypeCreationFailed", "Image", "Bitmap", ex.Message);
			}
			imageBrush.Source = source;
		}
		return imageBrush;
	}

	private static GradientStop HandleXmlElement_GradientStop(CustomDialog dialog, XElement xmlElement)
	{
		GradientStop gradientStop = new GradientStop();
		if (GetColorFromXElement(xmlElement, "Color") is Color color)
		{
			gradientStop.Color = color;
		}
		gradientStop.Offset = ParseXmlAttribute(xmlElement, "Offset", 0.0);
		return gradientStop;
	}

	private static LinearGradientBrush HandleXmlElement_LinearGradientBrush(CustomDialog dialog, XElement xmlElement)
	{
		LinearGradientBrush linearGradientBrush = new LinearGradientBrush();
		string text = xmlElement.Attribute("StartPoint")?.Value;
		if (text != null)
		{
			linearGradientBrush.StartPoint = ParseRelativePoint(text);
		}
		string text2 = xmlElement.Attribute("EndPoint")?.Value;
		if (text2 != null)
		{
			linearGradientBrush.EndPoint = ParseRelativePoint(text2);
		}
		foreach (XElement item in xmlElement.Elements())
		{
			if (item.Name.LocalName == "GradientStop")
			{
				string text3 = item.Attribute("Color")?.Value;
				string text4 = item.Attribute("Offset")?.Value;
				if (text3 != null && text4 != null)
				{
					Color color = Color.Parse(text3);
					double offset = double.Parse(text4, CultureInfo.InvariantCulture);
					linearGradientBrush.GradientStops.Add(new GradientStop(color, offset));
				}
			}
		}
		return linearGradientBrush;
		static RelativePoint ParseRelativePoint(string value)
		{
			string[] array = value.Split(',');
			double x = double.Parse(array[0], CultureInfo.InvariantCulture);
			double y = double.Parse(array[1], CultureInfo.InvariantCulture);
			return new RelativePoint(x, y, RelativeUnit.Relative);
		}
	}

	private static void ApplyBrush_UIElement(CustomDialog dialog, AvaloniaObject uiElement, string name, AvaloniaProperty dependencyProperty, XElement xmlElement)
	{
		object brushFromXElement = GetBrushFromXElement(xmlElement, name);
		if (brushFromXElement is IBrush value)
		{
			uiElement.SetValue(dependencyProperty, value);
			return;
		}
		if (brushFromXElement is string key)
		{
			uiElement.Bind(dependencyProperty, dialog.GetResourceObservable(key));
			return;
		}
		XElement xElement = xmlElement.Element($"{xmlElement.Name}.{name}");
		if (xElement != null)
		{
			XElement xElement2 = xElement.Elements().FirstOrDefault();
			if (xElement2 == null)
			{
				throw new CustomThemeException("CustomTheme.Errors.ElementAttributeMissingChild", xmlElement.Name, name);
			}
			IBrush value2 = HandleXml<IBrush>(dialog, xElement2);
			uiElement.SetValue(dependencyProperty, value2);
		}
	}

	private static void HandleXmlElement_Shape(CustomDialog dialog, Shape shape, XElement xmlElement)
	{
		HandleXmlElement_FrameworkElement(dialog, shape, xmlElement);
		ApplyBrush_UIElement(dialog, shape, "Fill", Shape.FillProperty, xmlElement);
		ApplyBrush_UIElement(dialog, shape, "Stroke", Shape.StrokeProperty, xmlElement);
		shape.Stretch = ParseXmlAttribute(xmlElement, "Stretch", Stretch.Fill);
		shape.StrokeDashOffset = ParseXmlAttribute(xmlElement, "StrokeDashOffset", 0.0);
		shape.StrokeLineCap = ParseXmlAttribute(xmlElement, "StrokeLineCap", PenLineCap.Flat);
		shape.StrokeMiterLimit = ParseXmlAttribute(xmlElement, "StrokeMiterLimit", 10.0);
		shape.StrokeThickness = ParseXmlAttribute(xmlElement, "StrokeThickness", 1.0);
	}

	private static Ellipse HandleXmlElement_Ellipse(CustomDialog dialog, XElement xmlElement)
	{
		Ellipse ellipse = new Ellipse();
		HandleXmlElement_Shape(dialog, ellipse, xmlElement);
		return ellipse;
	}

	private static Line HandleXmlElement_Line(CustomDialog dialog, XElement xmlElement)
	{
		Line line = new Line();
		HandleXmlElement_Shape(dialog, line, xmlElement);
		double x = ParseXmlAttribute(xmlElement, "X1", 0.0);
		double y = ParseXmlAttribute(xmlElement, "Y1", 0.0);
		double x2 = ParseXmlAttribute(xmlElement, "X2", 0.0);
		double y2 = ParseXmlAttribute(xmlElement, "Y2", 0.0);
		line.StartPoint = new Point(x, y);
		line.EndPoint = new Point(x2, y2);
		return line;
	}

	private static Rectangle HandleXmlElement_Rectangle(CustomDialog dialog, XElement xmlElement)
	{
		Rectangle rectangle = new Rectangle();
		HandleXmlElement_Shape(dialog, rectangle, xmlElement);
		rectangle.RadiusX = ParseXmlAttribute(xmlElement, "RadiusX", 0.0);
		rectangle.RadiusY = ParseXmlAttribute(xmlElement, "RadiusY", 0.0);
		return rectangle;
	}

	private static void HandleXmlElement_FrameworkElement(CustomDialog dialog, Control uiElement, XElement xmlElement)
	{
		string text = xmlElement.Attribute("Name")?.Value;
		if (text != null)
		{
			if (dialog.UsedNames.Contains(text))
			{
				throw new InvalidOperationException($"{xmlElement.Name} has duplicate name {text}");
			}
			dialog.UsedNames.Add(text);
			if (string.IsNullOrEmpty(uiElement.Name))
			{
				uiElement.Name = text;
			}
		}
		uiElement.IsEnabled = ParseXmlAttribute(xmlElement, "IsEnabled", defaultValue: true);
		uiElement.Height = ParseXmlAttribute(xmlElement, "Height", double.NaN);
		uiElement.Width = ParseXmlAttribute(xmlElement, "Width", double.NaN);
		uiElement.Margin = GetThicknessFromXElement(xmlElement, "Margin") ?? new Thickness(0.0);
		uiElement.HorizontalAlignment = ParseXmlAttribute(xmlElement, "HorizontalAlignment", HorizontalAlignment.Left);
		uiElement.VerticalAlignment = ParseXmlAttribute(xmlElement, "VerticalAlignment", VerticalAlignment.Top);
		uiElement.Opacity = ParseXmlAttribute(xmlElement, "Opacity", 1.0);
		ApplyBrush_UIElement(dialog, uiElement, "OpacityMask", Visual.OpacityMaskProperty, xmlElement);
		if (GetPointFromXElement(xmlElement, "RenderTransformOrigin") is RelativePoint renderTransformOrigin)
		{
			uiElement.RenderTransformOrigin = renderTransformOrigin;
		}
		uiElement.ZIndex = ParseXmlAttributeClamped(xmlElement, "ZIndex", 0, 0, 1000);
		Grid.SetRow(uiElement, ParseXmlAttribute(xmlElement, "Grid.Row", 0));
		Grid.SetRowSpan(uiElement, ParseXmlAttribute(xmlElement, "Grid.RowSpan", 1));
		Grid.SetColumn(uiElement, ParseXmlAttribute(xmlElement, "Grid.Column", 0));
		Grid.SetColumnSpan(uiElement, ParseXmlAttribute(xmlElement, "Grid.ColumnSpan", 1));
		ApplyTransformations_Control(dialog, uiElement, xmlElement);
		ApplyEffects_Control(dialog, uiElement, xmlElement);
		string text2 = xmlElement.Attribute("Visibility")?.Value;
		if (!string.IsNullOrEmpty(text2))
		{
			switch (text2.ToUpperInvariant())
			{
			case "COLLAPSED":
				uiElement.IsVisible = false;
				break;
			case "HIDDEN":
				uiElement.IsVisible = true;
				uiElement.Opacity = 0.0;
				uiElement.IsHitTestVisible = false;
				break;
			default:
				uiElement.IsVisible = true;
				break;
			}
		}
	}

	private static void HandleXmlElement_Control(CustomDialog dialog, Control uiElement, XElement xmlElement)
	{
		HandleXmlElement_FrameworkElement(dialog, uiElement, xmlElement);
		if (uiElement is TemplatedControl templatedControl)
		{
			templatedControl.Padding = GetThicknessFromXElement(xmlElement, "Padding").GetValueOrDefault();
			templatedControl.BorderThickness = GetThicknessFromXElement(xmlElement, "BorderThickness").GetValueOrDefault();
			ApplyBrush_UIElement(dialog, templatedControl, "Foreground", TemplatedControl.ForegroundProperty, xmlElement);
			ApplyBrush_UIElement(dialog, templatedControl, "Background", TemplatedControl.BackgroundProperty, xmlElement);
			ApplyBrush_UIElement(dialog, templatedControl, "BorderBrush", TemplatedControl.BorderBrushProperty, xmlElement);
			ApplyFontFamily(dialog, templatedControl, xmlElement);
			double? num = ParseXmlAttributeNullable<double>(xmlElement, "FontSize");
			if (num.HasValue)
			{
				double valueOrDefault = num.GetValueOrDefault();
				templatedControl.FontSize = valueOrDefault;
			}
			templatedControl.FontWeight = GetFontWeightFromXElement(xmlElement);
			templatedControl.FontStyle = GetFontStyleFromXElement(xmlElement);
		}
	}

	private static DummyControl HandleXmlElement_BloxstrapCustomBootstrapper(CustomDialog dialog, XElement xmlElement)
	{
		xmlElement.SetAttributeValue("Visibility", "Collapsed");
		xmlElement.SetAttributeValue("IsEnabled", "True");
		HandleXmlElement_Control(dialog, dialog, xmlElement);
		dialog.Opacity = 1.0;
		dialog.ElementGrid.RenderTransform = dialog.RenderTransform;
		dialog.RenderTransform = null;
		WindowsBackdrops windowsBackdrops = ParseXmlAttribute(xmlElement, "WindowBackdropType", WindowsBackdrops.None);
		List<WindowTransparencyLevel> list = new List<WindowTransparencyLevel>();
		switch (windowsBackdrops)
		{
		case WindowsBackdrops.Mica:
			list.Add(WindowTransparencyLevel.Mica);
			list.Add(WindowTransparencyLevel.AcrylicBlur);
			list.Add(WindowTransparencyLevel.Blur);
			break;
		case WindowsBackdrops.Acrylic:
			list.Add(WindowTransparencyLevel.AcrylicBlur);
			list.Add(WindowTransparencyLevel.Blur);
			list.Add(WindowTransparencyLevel.Mica);
			break;
		default:
			list.Add(WindowTransparencyLevel.None);
			break;
		}
		dialog.TransparencyLevelHint = list;
		bool flag = dialog.ActualThemeVariant == ThemeVariant.Light;
		if (windowsBackdrops != WindowsBackdrops.None)
		{
			byte b = windowsBackdrops switch
			{
				WindowsBackdrops.Mica => (byte)200, 
				WindowsBackdrops.Acrylic => (byte)128, 
				_ => (byte)180, 
			};
			if (dialog.Background != null && dialog.Background != Brushes.Transparent)
			{
				if (dialog.Background is SolidColorBrush { Color: var color })
				{
					Color color2 = Color.FromArgb(b, color.R, color.G, color.B);
					dialog.Background = new SolidColorBrush(color2);
				}
				else if (dialog.Background is ImageBrush imageBrush)
				{
					imageBrush.Opacity = (double)(int)b / 255.0;
				}
				else if (dialog.Background is LinearGradientBrush linearGradientBrush)
				{
					linearGradientBrush.Opacity = (double)(int)b / 255.0;
				}
				else if (dialog.Background is RadialGradientBrush radialGradientBrush)
				{
					radialGradientBrush.Opacity = (double)(int)b / 255.0;
				}
			}
			else
			{
				Color color3 = (flag ? Color.FromArgb(b, 225, 225, 225) : Color.FromArgb(b, 30, 30, 30));
				dialog.Background = new SolidColorBrush(color3);
			}
		}
		Theme theme = ParseXmlAttribute(xmlElement, "Theme", Merostrap.Enums.Theme.Default);
		if (theme == Merostrap.Enums.Theme.Default)
		{
			theme = App.Settings.Prop.Theme;
		}
		Theme final = theme.GetFinal();
		dialog.RequestedThemeVariant = ((final == Merostrap.Enums.Theme.Light) ? ThemeVariant.Light : ThemeVariant.Dark);
		dialog.ElementGrid.Margin = dialog.Margin;
		dialog.Margin = new Thickness(0.0, 0.0, 0.0, 0.0);
		dialog.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
		string title = xmlElement.Attribute("Title")?.Value?.ToString() ?? "Merostrap";
		dialog.Title = title;
		if (ParseXmlAttribute(xmlElement, "IgnoreTitleBarInset", defaultValue: false))
		{
			Grid.SetRow(dialog.ElementGrid, 0);
			Grid.SetRowSpan(dialog.ElementGrid, 2);
		}
		return new DummyControl();
	}

	private static Control HandleXmlElement_BloxstrapCustomBootstrapper_Fake(CustomDialog dialog, XElement xmlElement)
	{
		throw new InvalidOperationException($"{xmlElement.Parent.Name} cannot have a child of {xmlElement.Name}");
	}

	private static DummyControl HandleXmlElement_TitleBar(CustomDialog dialog, XElement xmlElement)
	{
		xmlElement.SetAttributeValue("Name", "TitleBar");
		xmlElement.SetAttributeValue("IsEnabled", "True");
		HandleXmlElement_Control(dialog, dialog.RootTitleBar, xmlElement);
		dialog.RootTitleBar.RenderTransform = null;
		dialog.RootTitleBar.ZIndex = 1001;
		dialog.RootTitleBar.Height = 32.0;
		dialog.RootTitleBar.Width = double.NaN;
		dialog.RootTitleBar.HorizontalAlignment = HorizontalAlignment.Stretch;
		dialog.RootTitleBar.Margin = new Thickness(0.0, 0.0, 0.0, 0.0);
		dialog.RootTitleBar.ShowMinimize = ParseXmlAttribute(xmlElement, "ShowMinimize", defaultValue: true);
		dialog.RootTitleBar.ShowMaximize = ParseXmlAttribute(xmlElement, "ShowMaximize", defaultValue: false);
		dialog.RootTitleBar.ShowClose = ParseXmlAttribute(xmlElement, "ShowClose", defaultValue: true);
		string title = xmlElement.Attribute("Title")?.Value ?? "Merostrap";
		dialog.RootTitleBar.Title = title;
		if (OperatingSystem.IsMacOS())
		{
			dialog.WindowDecorations = WindowDecorations.Full;
			dialog.ExtendClientAreaToDecorationsHint = true;
			dialog.RootTitleBar.IsVisible = false;
			dialog.Title = title;
			Grid.SetRow(dialog.ElementGrid, 0);
			Grid.SetRowSpan(dialog.ElementGrid, 2);
		}
		return new DummyControl();
	}

	private static Button HandleXmlElement_Button(CustomDialog dialog, XElement xmlElement)
	{
		Button button = new Button();
		HandleXmlElement_Control(dialog, button, xmlElement);
		button.Content = GetContentFromXElement(dialog, xmlElement);
		if (xmlElement.Attribute("Name")?.Value == "CancelButton")
		{
			Binding binding = new Binding("CancelEnabled")
			{
				Mode = BindingMode.TwoWay
			};
			button.Bind(InputElement.IsEnabledProperty, binding);
			Binding binding2 = new Binding("CancelInstallCommand");
			button.Bind(Button.CommandProperty, binding2);
		}
		return button;
	}

	private static void HandleXmlElement_RangeBase(CustomDialog dialog, RangeBase rangeBase, XElement xmlElement)
	{
		HandleXmlElement_Control(dialog, rangeBase, xmlElement);
		rangeBase.Value = ParseXmlAttribute(xmlElement, "Value", 0.0);
		rangeBase.Maximum = ParseXmlAttribute(xmlElement, "Maximum", 100.0);
	}

	private static ProgressBar HandleXmlElement_ProgressBar(CustomDialog dialog, XElement xmlElement)
	{
		ProgressBar progressBar = new ProgressBar();
		HandleXmlElement_RangeBase(dialog, progressBar, xmlElement);
		progressBar.IsIndeterminate = ParseXmlAttribute(xmlElement, "IsIndeterminate", defaultValue: false);
		ProgressBarHelper.SetCornerRadius(progressBar, GetCornerRadiusFromXElement(xmlElement, "CornerRadius").GetValueOrDefault());
		ProgressBarHelper.SetIndicatorCornerRadius(progressBar, GetCornerRadiusFromXElement(xmlElement, "IndicatorCornerRadius").GetValueOrDefault());
		if (xmlElement.Attribute("Name")?.Value == "PrimaryProgressBar")
		{
			Binding binding = new Binding("ProgressIndeterminate")
			{
				Mode = BindingMode.OneWay
			};
			progressBar.Bind(ProgressBar.IsIndeterminateProperty, binding);
			Binding binding2 = new Binding("ProgressMaximum")
			{
				Mode = BindingMode.OneWay
			};
			progressBar.Bind(RangeBase.MaximumProperty, binding2);
			Binding binding3 = new Binding("ProgressValue")
			{
				Mode = BindingMode.OneWay
			};
			progressBar.Bind(RangeBase.ValueProperty, binding3);
		}
		return progressBar;
	}

	private static FAProgressRing HandleXmlElement_ProgressRing(CustomDialog dialog, XElement xmlElement)
	{
		FAProgressRing fAProgressRing = new FAProgressRing();
		HandleXmlElement_RangeBase(dialog, fAProgressRing, xmlElement);
		fAProgressRing.IsIndeterminate = ParseXmlAttribute(xmlElement, "IsIndeterminate", defaultValue: false);
		if (xmlElement.Attribute("Name")?.Value == "PrimaryProgressRing")
		{
			Binding binding = new Binding("ProgressIndeterminate")
			{
				Mode = BindingMode.OneWay
			};
			fAProgressRing.Bind(FAProgressRing.IsIndeterminateProperty, binding);
			Binding binding2 = new Binding("ProgressMaximum")
			{
				Mode = BindingMode.OneWay
			};
			fAProgressRing.Bind(RangeBase.MaximumProperty, binding2);
			Binding binding3 = new Binding("ProgressValue")
			{
				Mode = BindingMode.OneWay
			};
			fAProgressRing.Bind(RangeBase.ValueProperty, binding3);
		}
		return fAProgressRing;
	}

	private static void HandleXmlElement_TextBlock_Base(CustomDialog dialog, TextBlock textBlock, XElement xmlElement)
	{
		HandleXmlElement_FrameworkElement(dialog, textBlock, xmlElement);
		ApplyBrush_UIElement(dialog, textBlock, "Foreground", TextBlock.ForegroundProperty, xmlElement);
		ApplyBrush_UIElement(dialog, textBlock, "Background", TextBlock.BackgroundProperty, xmlElement);
		double? num = ParseXmlAttributeNullable<double>(xmlElement, "FontSize");
		if (num.HasValue)
		{
			double valueOrDefault = num.GetValueOrDefault();
			textBlock.FontSize = valueOrDefault;
		}
		textBlock.FontWeight = GetFontWeightFromXElement(xmlElement);
		textBlock.FontStyle = GetFontStyleFromXElement(xmlElement);
		textBlock.LineHeight = ParseXmlAttribute(xmlElement, "LineHeight", double.NaN);
		textBlock.TextAlignment = ParseXmlAttribute(xmlElement, "TextAlignment", TextAlignment.Center);
		textBlock.TextTrimming = ParseXmlAttribute(xmlElement, "TextTrimming", TextTrimming.None);
		textBlock.TextWrapping = ParseXmlAttribute(xmlElement, "TextWrapping", TextWrapping.NoWrap);
		TextDecorationCollection textDecorationsFromXElement = GetTextDecorationsFromXElement(xmlElement);
		if (textDecorationsFromXElement != null)
		{
			textBlock.TextDecorations = textDecorationsFromXElement;
		}
		ApplyFontFamily(dialog, textBlock, xmlElement);
		textBlock.Padding = GetThicknessFromXElement(xmlElement, "Padding").GetValueOrDefault();
	}

	private static TextBlock HandleXmlElement_TextBlock(CustomDialog dialog, XElement xmlElement)
	{
		TextBlock textBlock = new TextBlock();
		HandleXmlElement_TextBlock_Base(dialog, textBlock, xmlElement);
		textBlock.Text = GetTranslatedText(xmlElement.Attribute("Text")?.Value);
		if (xmlElement.Attribute("Name")?.Value == "StatusText")
		{
			Binding binding = new Binding("Message")
			{
				Mode = BindingMode.OneWay
			};
			textBlock.Bind(TextBlock.TextProperty, binding);
		}
		return textBlock;
	}

	private static MarkdownTextBlock HandleXmlElement_MarkdownTextBlock(CustomDialog dialog, XElement xmlElement)
	{
		MarkdownTextBlock markdownTextBlock = new MarkdownTextBlock();
		HandleXmlElement_TextBlock_Base(dialog, markdownTextBlock, xmlElement);
		string translatedText = GetTranslatedText(xmlElement.Attribute("Text")?.Value);
		if (translatedText != null)
		{
			markdownTextBlock.MarkdownText = translatedText;
		}
		return markdownTextBlock;
	}

	private static Image HandleXmlElement_Image(CustomDialog dialog, XElement xmlElement)
	{
		Image image = new Image();
		HandleXmlElement_FrameworkElement(dialog, image, xmlElement);
		image.Stretch = ParseXmlAttribute(xmlElement, "Stretch", Stretch.Uniform);
		image.StretchDirection = ParseXmlAttribute(xmlElement, "StretchDirection", StretchDirection.Both);
		BitmapInterpolationMode value = ParseXmlAttribute(xmlElement, "BitmapInterpolationMode", BitmapInterpolationMode.HighQuality);
		RenderOptions.SetBitmapInterpolationMode(image, value);
		GetImageSourceDataResult imageSourceData = GetImageSourceData(dialog, "Source", xmlElement);
		if (imageSourceData.IsIcon)
		{
			image.Bind(Image.SourceProperty, new Binding("Icon"));
		}
		else if (imageSourceData.Path != null)
		{
			if (ParseXmlAttribute(xmlElement, "IsAnimated", defaultValue: false))
			{
				MemoryStream stream = new MemoryStream(File.ReadAllBytes(imageSourceData.Path));
				image.SetValue(ImageBehavior.AnimatedSourceProperty, new AnimatedImageSourceStream(stream));
				dialog._animatedImages.Add(image);
			}
			else
			{
				image.Source = new Bitmap(imageSourceData.Path);
			}
		}
		return image;
	}

	private static RowDefinition HandleXmlElement_RowDefinition(CustomDialog dialog, XElement xmlElement)
	{
		RowDefinition rowDefinition = new RowDefinition();
		GridLength? gridLengthFromXElement = GetGridLengthFromXElement(xmlElement, "Height");
		if (gridLengthFromXElement.HasValue)
		{
			rowDefinition.Height = gridLengthFromXElement.Value;
		}
		rowDefinition.MinHeight = ParseXmlAttribute(xmlElement, "MinHeight", 0.0);
		rowDefinition.MaxHeight = ParseXmlAttribute(xmlElement, "MaxHeight", double.PositiveInfinity);
		return rowDefinition;
	}

	private static ColumnDefinition HandleXmlElement_ColumnDefinition(CustomDialog dialog, XElement xmlElement)
	{
		ColumnDefinition columnDefinition = new ColumnDefinition();
		GridLength? gridLengthFromXElement = GetGridLengthFromXElement(xmlElement, "Width");
		if (gridLengthFromXElement.HasValue)
		{
			columnDefinition.Width = gridLengthFromXElement.Value;
		}
		columnDefinition.MinWidth = ParseXmlAttribute(xmlElement, "MinWidth", 0.0);
		columnDefinition.MaxWidth = ParseXmlAttribute(xmlElement, "MaxWidth", double.PositiveInfinity);
		return columnDefinition;
	}

	private static void HandleXmlElement_Grid_RowDefinitions(Grid grid, CustomDialog dialog, XElement xmlElement)
	{
		foreach (XElement item2 in xmlElement.Elements())
		{
			RowDefinition item = HandleXml<RowDefinition>(dialog, item2);
			grid.RowDefinitions.Add(item);
		}
	}

	private static void HandleXmlElement_Grid_ColumnDefinitions(Grid grid, CustomDialog dialog, XElement xmlElement)
	{
		foreach (XElement item2 in xmlElement.Elements())
		{
			ColumnDefinition item = HandleXml<ColumnDefinition>(dialog, item2);
			grid.ColumnDefinitions.Add(item);
		}
	}

	private static Grid HandleXmlElement_Grid(CustomDialog dialog, XElement xmlElement)
	{
		Grid grid = new Grid();
		HandleXmlElement_FrameworkElement(dialog, grid, xmlElement);
		bool flag = false;
		bool flag2 = false;
		foreach (XElement item2 in xmlElement.Elements())
		{
			if (item2.Name == "Grid.RowDefinitions")
			{
				if (flag)
				{
					throw new CustomThemeException("CustomTheme.Errors.ElementAttributeMultipleDefinitions", "Grid", "RowDefinitions");
				}
				flag = true;
				HandleXmlElement_Grid_RowDefinitions(grid, dialog, item2);
			}
			else if (item2.Name == "Grid.ColumnDefinitions")
			{
				if (flag2)
				{
					throw new CustomThemeException("CustomTheme.Errors.ElementAttributeMultipleDefinitions", "Grid", "ColumnDefinitions");
				}
				flag2 = true;
				HandleXmlElement_Grid_ColumnDefinitions(grid, dialog, item2);
			}
			else if (!item2.Name.ToString().StartsWith("Grid.", StringComparison.Ordinal))
			{
				Control item = HandleXml<Control>(dialog, item2);
				grid.Children.Add(item);
			}
		}
		return grid;
	}

	private static StackPanel HandleXmlElement_StackPanel(CustomDialog dialog, XElement xmlElement)
	{
		StackPanel stackPanel = new StackPanel();
		HandleXmlElement_FrameworkElement(dialog, stackPanel, xmlElement);
		stackPanel.Orientation = ParseXmlAttribute(xmlElement, "Orientation", Orientation.Vertical);
		foreach (XElement item2 in xmlElement.Elements())
		{
			Control item = HandleXml<Control>(dialog, item2);
			stackPanel.Children.Add(item);
		}
		return stackPanel;
	}

	private static Border HandleXmlElement_Border(CustomDialog dialog, XElement xmlElement)
	{
		Border border = new Border();
		HandleXmlElement_FrameworkElement(dialog, border, xmlElement);
		border.Padding = GetThicknessFromXElement(xmlElement, "Padding").GetValueOrDefault();
		border.BorderThickness = GetThicknessFromXElement(xmlElement, "BorderThickness").GetValueOrDefault();
		border.CornerRadius = GetCornerRadiusFromXElement(xmlElement, "CornerRadius").GetValueOrDefault();
		ApplyBrush_UIElement(dialog, border, "Background", Border.BackgroundProperty, xmlElement);
		ApplyBrush_UIElement(dialog, border, "BorderBrush", Border.BorderBrushProperty, xmlElement);
		XElement xElement = (from e in xmlElement.Elements()
			where !e.Name.LocalName.Contains('.', StringComparison.Ordinal)
			select e).ToList().FirstOrDefault();
		if (xElement != null)
		{
			border.Child = HandleXml<Control>(dialog, xElement);
		}
		return border;
	}

	private static T ParseXmlAttribute<T>(XElement element, string attributeName, T defaultValue)
	{
		XAttribute xAttribute = element.Attribute(attributeName);
		if (xAttribute == null || string.IsNullOrWhiteSpace(xAttribute.Value))
		{
			return defaultValue;
		}
		try
		{
			if (typeof(T) == typeof(bool))
			{
				return (T)(object)bool.Parse(xAttribute.Value);
			}
			TypeConverter converter = TypeDescriptor.GetConverter(typeof(T));
			if (converter != null && converter.CanConvertFrom(typeof(string)))
			{
				return (T)converter.ConvertFromInvariantString(xAttribute.Value);
			}
			return (T)Convert.ChangeType(xAttribute.Value, typeof(T), CultureInfo.InvariantCulture);
		}
		catch
		{
			return defaultValue;
		}
	}

	private static T? ParseXmlAttributeNullable<T>(XElement element, string attributeName) where T : struct
	{
		XAttribute xAttribute = element.Attribute(attributeName);
		if (xAttribute == null)
		{
			return null;
		}
		return ConvertValue<T>(xAttribute.Value);
	}

	private static void ValidateXmlElement(string elementName, string attributeName, double value, double? min = null, double? max = null)
	{
		if (min.HasValue && value < min)
		{
			throw new CustomThemeException("CustomTheme.Errors.ElementAttributeMustBeLargerThanMin", elementName, attributeName, min);
		}
		if (max.HasValue && value > max)
		{
			throw new CustomThemeException("CustomTheme.Errors.ElementAttributeMustBeSmallerThanMax", elementName, attributeName, max);
		}
	}

	private static int ParseXmlAttributeClamped(XElement element, string attributeName, int defaultValue = 0, int? min = null, int? max = null)
	{
		int num = ParseXmlAttribute(element, attributeName, defaultValue);
		ValidateXmlElement(element.Name.ToString(), attributeName, num, min.HasValue ? new double?(min.Value) : ((double?)null), max.HasValue ? new double?(max.Value) : ((double?)null));
		return num;
	}

	private static FontWeight GetFontWeightFromXElement(XElement element)
	{
		string text = element.Attribute("FontWeight")?.Value ?? "Normal";
		switch (text.ToUpperInvariant())
		{
		case "THIN":
			return FontWeight.Thin;
		case "EXTRALIGHT":
		case "ULTRALIGHT":
			return FontWeight.ExtraLight;
		case "LIGHT":
			return FontWeight.Light;
		case "NORMAL":
		case "REGULAR":
			return FontWeight.Normal;
		case "MEDIUM":
			return FontWeight.Medium;
		case "DEMIBOLD":
		case "SEMIBOLD":
			return FontWeight.DemiBold;
		case "BOLD":
			return FontWeight.Bold;
		case "EXTRABOLD":
		case "ULTRABOLD":
			return FontWeight.ExtraBold;
		case "BLACK":
		case "HEAVY":
			return FontWeight.Black;
		case "EXTRABLACK":
		case "ULTRABLACK":
			return FontWeight.ExtraBlack;
		default:
			throw new CustomThemeException("CustomTheme.Errors.UnknownEnumValue", element.Name, "FontWeight", text);
		}
	}

	private static FontStyle GetFontStyleFromXElement(XElement element)
	{
		string text = element.Attribute("FontStyle")?.Value ?? "Normal";
		return text.ToUpperInvariant() switch
		{
			"NORMAL" => FontStyle.Normal, 
			"ITALIC" => FontStyle.Italic, 
			"OBLIQUE" => FontStyle.Oblique, 
			_ => throw new CustomThemeException("CustomTheme.Errors.UnknownEnumValue", element.Name, "FontStyle", text), 
		};
	}

	private static TextDecorationCollection? GetTextDecorationsFromXElement(XElement element)
	{
		string text = element.Attribute("TextDecorations")?.Value;
		if (string.IsNullOrEmpty(text))
		{
			return null;
		}
		return text.ToUpperInvariant() switch
		{
			"UNDERLINE" => TextDecorations.Underline, 
			"STRIKETHROUGH" => TextDecorations.Strikethrough, 
			"OVERLINE" => TextDecorations.Overline, 
			"BASELINE" => TextDecorations.Baseline, 
			_ => throw new CustomThemeException("CustomTheme.Errors.UnknownEnumValue", element.Name, "TextDecorations", text), 
		};
	}

	private static string? GetTranslatedText(string? text)
	{
		if (text == null || !text.StartsWith('{') || !text.EndsWith('}'))
		{
			return text;
		}
		string text2 = text.Substring(1, text.Length - 1 - 1);
		if (text2 == "Version")
		{
			return App.Version;
		}
		return Strings.ResourceManager.GetString(text2, CultureInfo.CurrentCulture) ?? text2;
	}

	private static string? GetFullPath(CustomDialog dialog, string? sourcePath)
	{
		if (sourcePath == null)
		{
			return null;
		}
		if (sourcePath.StartsWith("file://", StringComparison.Ordinal))
		{
			string text = sourcePath.Substring("file://".Length);
			if (text.StartsWith('/'))
			{
				text = text.Substring(1);
			}
			text = Environment.ExpandEnvironmentVariables(text);
			if (File.Exists(text))
			{
				return text;
			}
			return System.IO.Path.GetFullPath(text);
		}
		if (sourcePath.StartsWith("theme://", StringComparison.Ordinal))
		{
			string path = sourcePath.Substring("theme://".Length);
			return System.IO.Path.GetFullPath(Environment.ExpandEnvironmentVariables(System.IO.Path.Combine(dialog.ThemeDir, path)));
		}
		string name = sourcePath.Replace('\\', System.IO.Path.DirectorySeparatorChar);
		name = Environment.ExpandEnvironmentVariables(name);
		if (System.IO.Path.IsPathRooted(name))
		{
			return name;
		}
		return System.IO.Path.GetFullPath(System.IO.Path.Combine(dialog.ThemeDir, name));
	}

	private static GetImageSourceDataResult GetImageSourceData(CustomDialog dialog, string name, XElement xmlElement)
	{
		string text = xmlElement.Attribute(name)?.Value;
		if (string.IsNullOrEmpty(text))
		{
			throw new CustomThemeException("CustomTheme.Errors.ElementAttributeMissing", xmlElement.Name, name);
		}
		GetImageSourceDataResult result;
		if (text == "{Icon}")
		{
			result = new GetImageSourceDataResult();
			result.IsIcon = true;
			return result;
		}
		text = GetFullPath(dialog, text);
		if (!File.Exists(text))
		{
			throw new CustomThemeException("CustomTheme.Errors.FileNotFound", text);
		}
		result = new GetImageSourceDataResult();
		result.Path = text;
		return result;
	}

	private static object? GetContentFromXElement(CustomDialog dialog, XElement xmlElement)
	{
		XAttribute xAttribute = xmlElement.Attribute("Content");
		XElement xElement = xmlElement.Element($"{xmlElement.Name}.Content");
		if (xAttribute != null && xElement != null)
		{
			throw new CustomThemeException("CustomTheme.Errors.ElementAttributeMultipleDefinitions", xmlElement.Name, "Content");
		}
		if (xAttribute != null)
		{
			return GetTranslatedText(xAttribute.Value);
		}
		if (xElement == null)
		{
			return null;
		}
		List<XElement> list = xElement.Elements().ToList();
		if (list.Count > 1)
		{
			throw new CustomThemeException("CustomTheme.Errors.ElementAttributeMultipleChildren", xmlElement.Name, "Content");
		}
		XElement xElement2 = list.FirstOrDefault();
		if (xElement2 == null)
		{
			throw new CustomThemeException("CustomTheme.Errors.ElementAttributeMissingChild", xmlElement.Name, "Content");
		}
		return HandleXml<Control>(dialog, xElement2);
	}

	private static void ApplyEffects_Control(CustomDialog dialog, Control uiElement, XElement xmlElement)
	{
		XElement xElement = xmlElement.Element($"{xmlElement.Name}.Effect");
		if (xElement == null)
		{
			return;
		}
		XElement xElement2 = xElement.Elements().FirstOrDefault();
		if (xElement2 == null)
		{
			return;
		}
		if (xElement2.Name.LocalName == "DropShadowEffect")
		{
			if (HandleXmlElement_DropShadowEffect(dialog, xElement2) is BoxShadows boxShadow && uiElement is Border border)
			{
				border.BoxShadow = boxShadow;
			}
		}
		else if (xElement2.Name.LocalName == "BlurEffect")
		{
			IEffect effect = HandleXmlElement_BlurEffect(dialog, xElement2);
			if (effect != null)
			{
				uiElement.Effect = effect;
			}
		}
	}

	private static void ApplyTransformations_Control(CustomDialog dialog, Control uiElement, XElement xmlElement)
	{
		XElement xElement = xmlElement.Element($"{xmlElement.Name}.RenderTransform");
		if (xElement == null)
		{
			return;
		}
		TransformGroup transformGroup = new TransformGroup();
		foreach (XElement item in xElement.Elements())
		{
			Transform transform = HandleXml<Transform>(dialog, item);
			if (transform != null)
			{
				transformGroup.Children.Add(transform);
			}
		}
		uiElement.RenderTransform = transformGroup;
	}

	private static LoadedFont? LoadSingleFontFile(string path)
	{
		using (_customFontLock.EnterScope())
		{
			if (_customFontCache.TryGetValue(path, out var value))
			{
				return value;
			}
			LoadedFont? loadedFont = null;
			try
			{
				string text = "fonts:merostrap-" + FastHash.FromString(path);
				EmbeddedFontCollection embeddedFontCollection = new EmbeddedFontCollection(new Uri(text, UriKind.Absolute), new Uri(path, UriKind.Absolute));
				FontManager.Current.AddFontCollection(embeddedFontCollection);
				string text2 = embeddedFontCollection.Select((FontFamily f) => f.Name).FirstOrDefault();
				if (text2 != null)
				{
					loadedFont = new LoadedFont(text2, text + "#" + text2);
				}
			}
			catch
			{
				loadedFont = null;
			}
			_customFontCache[path] = loadedFont;
			return loadedFont;
		}
	}

	private static string? FindFontFamilyInDirectory(string directory, string familyName)
	{
		string text = familyName.ToUpperInvariant();
		string[] fontFileExtensions = _fontFileExtensions;
		foreach (string text2 in fontFileExtensions)
		{
			string path = System.IO.Path.Combine(directory, text + text2);
			if (File.Exists(path))
			{
				return LoadSingleFontFile(path)?.Reference;
			}
		}
		fontFileExtensions = _fontFileExtensions;
		foreach (string text3 in fontFileExtensions)
		{
			string[] files;
			try
			{
				files = Directory.GetFiles(directory, "*" + text3, SearchOption.TopDirectoryOnly);
			}
			catch
			{
				continue;
			}
			string[] array = files;
			for (int j = 0; j < array.Length; j++)
			{
				LoadedFont? loadedFont = LoadSingleFontFile(array[j]);
				if (loadedFont.HasValue)
				{
					LoadedFont valueOrDefault = loadedFont.GetValueOrDefault();
					if (valueOrDefault.Name.Equals(familyName, StringComparison.OrdinalIgnoreCase))
					{
						return valueOrDefault.Reference;
					}
				}
			}
		}
		return null;
	}

	private static bool LooksLikePathSegment(string segment)
	{
		int num = segment.LastIndexOf('#');
		string text = ((num >= 0) ? segment.Substring(0, num) : segment);
		if (text.Length == 0)
		{
			return false;
		}
		if (text.StartsWith("theme://", StringComparison.OrdinalIgnoreCase) || text.StartsWith("file://", StringComparison.OrdinalIgnoreCase))
		{
			return true;
		}
		if (text.IndexOfAny(new char[2] { '/', '\\' }) >= 0)
		{
			return true;
		}
		string extension = System.IO.Path.GetExtension(text);
		if (!extension.Equals(".TTF", StringComparison.OrdinalIgnoreCase) && !extension.Equals(".OTF", StringComparison.OrdinalIgnoreCase))
		{
			return extension.Equals(".TTC", StringComparison.OrdinalIgnoreCase);
		}
		return true;
	}

	private static string? ResolveFontFileSegment(CustomDialog dialog, string segment)
	{
		int num = segment.LastIndexOf('#');
		string sourcePath = ((num >= 0) ? segment.Substring(0, num) : segment);
		string text = ((num >= 0) ? segment.Substring(num + 1).Trim() : null);
		if (string.IsNullOrEmpty(text))
		{
			text = null;
		}
		string text2;
		try
		{
			text2 = GetFullPath(dialog, sourcePath);
		}
		catch
		{
			text2 = null;
		}
		if (string.IsNullOrEmpty(text2))
		{
			return null;
		}
		if (File.Exists(text2))
		{
			return LoadSingleFontFile(text2)?.Reference;
		}
		if (text != null && Directory.Exists(text2))
		{
			return FindFontFamilyInDirectory(text2, text);
		}
		return null;
	}

	private static string? ResolveFontFamilySegment(CustomDialog dialog, string rawSegment)
	{
		string text = rawSegment.Trim();
		if (text.Length == 0)
		{
			return null;
		}
		if (LooksLikePathSegment(text))
		{
			return ResolveFontFileSegment(dialog, text);
		}
		if (!text.StartsWith('#'))
		{
			return text;
		}
		return text.Substring(1).Trim();
	}

	private static void ApplyFontFamily(CustomDialog dialog, object target, XElement xmlElement)
	{
		string text = xmlElement.Attribute("FontFamily")?.Value;
		if (string.IsNullOrWhiteSpace(text))
		{
			return;
		}
		FontFamily fontFamily;
		try
		{
			List<string> list = (from segment in text.Split(',')
				select ResolveFontFamilySegment(dialog, segment) into segment
				where !string.IsNullOrEmpty(segment)
				select segment).ToList();
			fontFamily = ((list.Count > 0) ? new FontFamily(string.Join(", ", list)) : null);
		}
		catch
		{
			fontFamily = null;
		}
		if (fontFamily == null)
		{
			return;
		}
		if (!(target is TemplatedControl templatedControl))
		{
			if (target is TextBlock textBlock)
			{
				textBlock.FontFamily = fontFamily;
			}
		}
		else
		{
			templatedControl.FontFamily = fontFamily;
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		RootTitleBar = nameScope?.Find<TitleBar>("RootTitleBar");
		ElementGrid = nameScope?.Find<Grid>("ElementGrid");
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, CustomDialog P_1)
	{
		XamlIlContext.Context<CustomDialog> context = new XamlIlContext.Context<CustomDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FBootstrapper_002FCustomDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Bootstrapper/CustomDialog.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		P_1.Title = "Merostrap";
		P_1.Width = 800.0;
		P_1.Height = 450.0;
		P_1.MinWidth = 150.0;
		P_1.MinHeight = 150.0;
		P_1.MaxWidth = 3000.0;
		P_1.MaxHeight = 3000.0;
		P_1.CanResize = false;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid2.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid2.Children;
		TitleBar titleBar2;
		TitleBar titleBar = (titleBar2 = new TitleBar());
		((ISupportInitialize)titleBar).BeginInit();
		children.Add(titleBar);
		titleBar2.Name = "RootTitleBar";
		object element = titleBar2;
		context.AvaloniaNameScope.Register("RootTitleBar", element);
		titleBar2.Title = "Merostrap";
		Grid.SetRow(titleBar2, 0);
		titleBar2.ZIndex = 1001;
		titleBar2.ShowClose = false;
		titleBar2.ShowMaximize = false;
		titleBar2.ShowMinimize = false;
		((ISupportInitialize)titleBar2).EndInit();
		Avalonia.Controls.Controls children2 = grid2.Children;
		Grid grid4;
		Grid grid3 = (grid4 = new Grid());
		((ISupportInitialize)grid3).BeginInit();
		children2.Add(grid3);
		grid4.Name = "ElementGrid";
		element = grid4;
		context.AvaloniaNameScope.Register("ElementGrid", element);
		Grid.SetRow(grid4, 1);
		((ISupportInitialize)grid4).EndInit();
		((ISupportInitialize)grid2).EndInit();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(CustomDialog P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
