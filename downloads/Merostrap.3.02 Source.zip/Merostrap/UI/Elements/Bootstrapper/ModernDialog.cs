using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Controls.Shapes;
using Avalonia.Data;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Media.Immutable;
using CompiledAvaloniaXaml;
using Merostrap.Enums;
using Merostrap.Extensions;
using Merostrap.UI.Elements.Bootstrapper.Base;
using Merostrap.UI.ViewModels.Bootstrapper;
using Merostrap.Utility;

namespace Merostrap.UI.Elements.Bootstrapper;

internal class ModernDialog : AvaloniaDialogBase
{
	private readonly ModernDialogViewModel _viewModel;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public override string Message
	{
		get
		{
			return _viewModel.Message;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.Message = value;
				_viewModel.OnPropertyChanged("Message");
			});
		}
	}

	public override int ProgressMaximum
	{
		get
		{
			return _viewModel.ProgressMaximum;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.ProgressMaximum = value;
				_viewModel.OnPropertyChanged("ProgressMaximum");
			});
		}
	}

	public override int ProgressValue
	{
		get
		{
			return _viewModel.ProgressValue;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.ProgressValue = value;
				_viewModel.OnPropertyChanged("ProgressValue");
			});
		}
	}

	public override bool CancelEnabled
	{
		get
		{
			return _viewModel.CancelEnabled;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.CancelEnabled = value;
				_viewModel.OnPropertyChanged("CancelEnabled");
				_viewModel.OnPropertyChanged("CancelButtonVisible");
			});
		}
	}

	public override bool ProgressIndeterminate
	{
		get
		{
			return _viewModel.ProgressIndeterminate;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.ProgressIndeterminate = value;
				_viewModel.OnPropertyChanged("ProgressIndeterminate");
			});
		}
	}

	public ModernDialog()
	{
		InitializeComponent();
		_viewModel = new ModernDialogViewModel(this, Versioning.GetRobloxVersionStr(Bootstrapper?.IsStudioLaunch ?? false));
		DataContext = _viewModel;
		SetupDialog();
		if (App.Settings.Prop.BootstrapperIcon.GetIcon()?.GetImageSource() is Bitmap bitmap)
		{
			Icon = new WindowIcon(bitmap);
		}
		ApplyModernStyles();
	}

	private void ApplyModernStyles()
	{
		if (App.Settings.Prop.Theme.GetFinal() == Merostrap.Enums.Theme.Light)
		{
			_viewModel.DialogBorder = new Thickness(1.0);
			_viewModel.Background = new SolidColorBrush(Color.FromRgb(242, 244, 245));
			_viewModel.Foreground = new SolidColorBrush(Color.FromRgb(57, 59, 61));
			_viewModel.IconColor = new SolidColorBrush(Color.FromRgb(57, 59, 61));
			_viewModel.ProgressBarBackground = new SolidColorBrush(Color.FromRgb(189, 190, 190));
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, ModernDialog P_1)
	{
		XamlIlContext.Context<ModernDialog> context = new XamlIlContext.Context<ModernDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FBootstrapper_002FModernDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Bootstrapper/ModernDialog.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Width = 600.0;
		P_1.Height = 400.0;
		P_1.CanResize = false;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		P_1.Title = "Merostrap";
		P_1.ExtendClientAreaToDecorationsHint = true;
		P_1.Background = new ImmutableSolidColorBrush(16777215u);
		P_1.TransparencyLevelHint = new WindowTransparencyLevel[1] { WindowTransparencyLevel.Transparent };
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		P_1.Content = border;
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		border4.CornerRadius = new CornerRadius(10.0, 10.0, 10.0, 10.0);
		border4.BorderBrush = new ImmutableSolidColorBrush(859388733u);
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EModernDialogViewModel_002CMerostrap_002EBackground_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Border.BackgroundProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border4.Bind(backgroundProperty, binding);
		StyledProperty<Thickness> borderThicknessProperty = Border.BorderThicknessProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EModernDialogViewModel_002CMerostrap_002EDialogBorder_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Border.BorderThicknessProperty;
		CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border4.Bind(borderThicknessProperty, binding2);
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		border4.Child = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		Avalonia.Controls.Controls children = grid5.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children.Add(button);
		Button button4;
		Button button3 = (button4 = button2);
		context.PushParent(button4);
		button4.Margin = new Thickness(15.0, 15.0, 15.0, 15.0);
		button4.VerticalAlignment = VerticalAlignment.Top;
		button4.HorizontalAlignment = HorizontalAlignment.Right;
		button4.Width = 20.0;
		button4.Height = 20.0;
		button4.Padding = new Thickness(1.0, 1.0, 1.0, 1.0);
		button4.Background = new ImmutableSolidColorBrush(16777215u);
		button4.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002ECancelButtonVisible_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding3 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button4.Bind(isVisibleProperty, binding3);
		StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002ECancelInstallCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding4 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button4.Bind(commandProperty, binding4);
		Path path2;
		Path path = (path2 = new Path());
		((ISupportInitialize)path).BeginInit();
		button4.Content = path;
		Path path4;
		Path path3 = (path4 = path2);
		context.PushParent(path4);
		Path path5 = path4;
		StyledProperty<IBrush?> fillProperty = Shape.FillProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EModernDialogViewModel_002CMerostrap_002EIconColor_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Shape.FillProperty;
		CompiledBinding binding5 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		path5.Bind(fillProperty, binding5);
		path5.Stretch = Stretch.Uniform;
		path5.Data = Geometry.Parse("m 6.7507011 2.1168752 c -1.0144874 0 -2.0291944 0.3884677 -2.8065471 1.1658203 -1.5547052 1.5547053 -1.5547052 4.0583888 10e-8 5.6130941 L 28.499761 33.45088 3.9441541 58.006487 c -1.5547058 1.554706 -1.5547051 4.057873 0 5.612578 1.554705 1.554705 4.0583891 1.554705 5.6130942 0 l 24.5550907 -24.55509 24.555607 24.55509 c 1.554705 1.554705 4.057871 1.554705 5.612577 0 1.554705 -1.554706 1.554705 -4.057872 0 -5.612577 L 39.725433 33.450881 64.280523 8.89579 c 1.554706 -1.5547058 1.554705 -4.0583892 0 -5.6130942 -1.554705 -1.5547051 -4.057872 -1.5547058 -5.612578 -7e-7 L 34.112338 27.838303 9.5572482 3.2826955 C 8.7798955 2.5053428 7.7651883 2.1168752 6.7507011 2.1168752 Z");
		context.PopParent();
		((ISupportInitialize)path3).EndInit();
		context.PopParent();
		((ISupportInitialize)button3).EndInit();
		Avalonia.Controls.Controls children2 = grid5.Children;
		Path path7;
		Path path6 = (path7 = new Path());
		((ISupportInitialize)path6).BeginInit();
		children2.Add(path6);
		Path path8 = (path4 = path7);
		context.PushParent(path4);
		Path path9 = path4;
		StyledProperty<IBrush?> fillProperty2 = Shape.FillProperty;
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EModernDialogViewModel_002CMerostrap_002EIconColor_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Shape.FillProperty;
		CompiledBinding binding6 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		path9.Bind(fillProperty2, binding6);
		path9.Width = 300.0;
		path9.Height = 56.0;
		path9.Stretch = Stretch.Uniform;
		path9.Data = Geometry.Parse("M38.5796 38.4043L47.7906 55.2626H30.6999L22.9226 40.8556H15.5546V55.2626H0V4.19308H28.4486C40.2169 4.19308 47.6883 10.7246 47.6883 22.4706C47.6883 30.0289 44.209 35.4433 38.5796 38.4043ZM15.5546 17.4658V27.5775H26.6066C29.8813 27.5775 31.9279 25.6369 31.9279 22.4706C31.9279 19.3043 29.8813 17.4658 26.6066 17.4658H15.5546ZM97.2175 59.0374L50.656 46.4743L63.1406 0L86.4214 6.28155L109.702 12.5631L97.2175 59.0374ZM88.4169 24.8198L75.4206 21.2449L71.9413 34.2166L84.9376 37.7925L88.4169 24.8198ZM163.019 40.8556C163.019 50.661 156.777 55.2626 147.055 55.2626H116.56V4.19308H146.032C155.753 4.19308 161.995 9.19789 161.995 17.9818C161.995 23.4973 159.949 27.1754 156.06 29.7289C160.461 31.6631 163.019 35.5455 163.019 40.8556ZM131.705 16.4498V24.008H141.83C144.593 24.008 146.231 22.7824 146.231 20.1268C146.231 17.6754 144.593 16.4498 141.83 16.4498H131.705ZM131.705 43.0059H143.064C145.725 43.0059 147.265 41.576 147.265 39.1235C147.265 36.469 145.73 35.2433 143.064 35.2433H131.705V43.0059ZM170.694 4.19308H186.246V40.1417H208.555V55.2626H170.692L170.694 4.19308ZM265.762 29.7289C265.762 34.9812 264.202 40.1156 261.278 44.4827C258.355 48.8498 254.199 52.2536 249.338 54.2636C244.476 56.2736 239.126 56.7995 233.965 55.7748C228.804 54.7501 224.063 52.2209 220.342 48.5069C216.621 44.793 214.087 40.0611 213.06 34.9098C212.034 29.7584 212.561 24.4188 214.574 19.5663C216.588 14.7138 219.998 10.5663 224.374 7.64828C228.749 4.73025 233.893 3.17276 239.156 3.17276C242.651 3.16582 246.114 3.8478 249.345 5.17958C252.575 6.51135 255.511 8.46672 257.983 10.9335C260.455 13.4003 262.415 16.3299 263.75 19.5544C265.085 22.7788 265.769 26.2346 265.762 29.7235V29.7289ZM250.208 29.7289C250.208 23.3952 245.193 18.3904 239.156 18.3904C233.118 18.3904 228.103 23.3952 228.103 29.7289C228.103 36.0626 233.118 41.0663 239.156 41.0663C245.193 41.0663 250.208 36.0551 250.208 29.7235V29.7289ZM303.216 28.9107L320 55.2626H301.472L292.267 40.2428L282.75 55.2626H263.92L281.419 29.5225L265.353 4.19308H283.875L292.369 17.9818L300.556 4.19308H318.976L303.216 28.9107Z");
		context.PopParent();
		((ISupportInitialize)path8).EndInit();
		Avalonia.Controls.Controls children3 = grid5.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children3.Add(grid6);
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		grid9.Margin = new Thickness(0.0, 0.0, 0.0, 29.0);
		grid9.VerticalAlignment = VerticalAlignment.Bottom;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid9.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children4 = grid9.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children4.Add(textBlock);
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = textBlock2);
		context.PushParent(textBlock4);
		Grid.SetRow(textBlock4, 0);
		textBlock4.Margin = new Thickness(0.0, 0.0, 0.0, 23.0);
		textBlock4.TextAlignment = TextAlignment.Center;
		StyledProperty<string?> textProperty = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002EMessage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding7 = compiledBindingExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock4.Bind(textProperty, binding7);
		StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
		CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EModernDialogViewModel_002CMerostrap_002EForeground_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		CompiledBinding binding8 = compiledBindingExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock4.Bind(foregroundProperty, binding8);
		StaticResourceExtension staticResourceExtension = new StaticResourceExtension("Rubik");
		context.ProvideTargetProperty = TextBlock.FontFamilyProperty;
		object? obj = staticResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_2(textBlock4, obj);
		textBlock4.FontSize = 17.0;
		textBlock4.FontWeight = FontWeight.Light;
		textBlock4.RenderTransform = new ScaleTransform
		{
			ScaleY = 0.9
		};
		context.PopParent();
		((ISupportInitialize)textBlock3).EndInit();
		Avalonia.Controls.Controls children5 = grid9.Children;
		ProgressBar progressBar2;
		ProgressBar progressBar = (progressBar2 = new ProgressBar());
		((ISupportInitialize)progressBar).BeginInit();
		children5.Add(progressBar);
		ProgressBar progressBar4;
		ProgressBar progressBar3 = (progressBar4 = progressBar2);
		context.PushParent(progressBar4);
		Grid.SetRow(progressBar4, 1);
		progressBar4.Width = 480.0;
		progressBar4.Height = 12.0;
		StyledProperty<IBrush?> foregroundProperty2 = TemplatedControl.ForegroundProperty;
		CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EModernDialogViewModel_002CMerostrap_002EForeground_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TemplatedControl.ForegroundProperty;
		CompiledBinding binding9 = compiledBindingExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		progressBar4.Bind(foregroundProperty2, binding9);
		StyledProperty<IBrush?> backgroundProperty2 = TemplatedControl.BackgroundProperty;
		CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EModernDialogViewModel_002CMerostrap_002EProgressBarBackground_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TemplatedControl.BackgroundProperty;
		CompiledBinding binding10 = compiledBindingExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		progressBar4.Bind(backgroundProperty2, binding10);
		progressBar4.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
		StyledProperty<bool> isIndeterminateProperty = ProgressBar.IsIndeterminateProperty;
		CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002EProgressIndeterminate_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ProgressBar.IsIndeterminateProperty;
		CompiledBinding binding11 = compiledBindingExtension11.ProvideValue(context);
		context.ProvideTargetProperty = null;
		progressBar4.Bind(isIndeterminateProperty, binding11);
		StyledProperty<double> maximumProperty = RangeBase.MaximumProperty;
		CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002EProgressMaximum_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = RangeBase.MaximumProperty;
		CompiledBinding binding12 = compiledBindingExtension12.ProvideValue(context);
		context.ProvideTargetProperty = null;
		progressBar4.Bind(maximumProperty, binding12);
		StyledProperty<double> valueProperty = RangeBase.ValueProperty;
		CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002EProgressValue_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = RangeBase.ValueProperty;
		CompiledBinding binding13 = compiledBindingExtension13.ProvideValue(context);
		context.ProvideTargetProperty = null;
		progressBar4.Bind(valueProperty, binding13);
		context.PopParent();
		((ISupportInitialize)progressBar3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(ModernDialog P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
