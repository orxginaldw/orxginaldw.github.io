using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.Converters;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Media.Immutable;
using Avalonia.Platform;
using CompiledAvaloniaXaml;
using Merostrap.UI.Elements.Bootstrapper.Base;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.ViewModels.Bootstrapper;

namespace Merostrap.UI.Elements.Bootstrapper;

internal class FluentDialog : AvaloniaDialogBase
{
	private readonly FluentDialogViewModel? _viewModel;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public override string Message
	{
		get
		{
			return _viewModel.Message;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.Message = value;
				_viewModel.OnPropertyChanged("Message");
			});
		}
	}

	public override int ProgressMaximum
	{
		get
		{
			return _viewModel.ProgressMaximum;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.ProgressMaximum = value;
				_viewModel.OnPropertyChanged("ProgressMaximum");
			});
		}
	}

	public override int ProgressValue
	{
		get
		{
			return _viewModel.ProgressValue;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.ProgressValue = value;
				_viewModel.OnPropertyChanged("ProgressValue");
			});
		}
	}

	public override bool CancelEnabled
	{
		get
		{
			return _viewModel.CancelEnabled;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.CancelEnabled = value;
				_viewModel.OnPropertyChanged("CancelEnabled");
				_viewModel.OnPropertyChanged("CancelButtonVisible");
			});
		}
	}

	public override bool ProgressIndeterminate
	{
		get
		{
			return _viewModel.ProgressIndeterminate;
		}
		set
		{
			AvaloniaDialogBase.RunOnUI(() =>
			{
				_viewModel.ProgressIndeterminate = value;
				_viewModel.OnPropertyChanged("ProgressIndeterminate");
			});
		}
	}

	public FluentDialog()
	{
		InitializeComponent();
	}

	public FluentDialog(bool aero)
		: this()
	{
		_viewModel = new FluentDialogViewModel(this, aero);
		DataContext = _viewModel;
		SetupDialog();
		Icon = new WindowIcon(AssetLoader.Open(new Uri("avares://Merostrap/Resources/Brand/Merostrap.ico")));
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, FluentDialog P_1)
	{
		XamlIlContext.Context<FluentDialog> context = new XamlIlContext.Context<FluentDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FBootstrapper_002FFluentDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Bootstrapper/FluentDialog.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Width = 500.0;
		P_1.Height = 280.0;
		P_1.MinHeight = 0.0;
		P_1.CanResize = false;
		P_1.Title = "Merostrap";
		P_1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		P_1.ExtendClientAreaToDecorationsHint = true;
		StyledProperty<IReadOnlyList<WindowTransparencyLevel>> transparencyLevelHintProperty = TopLevel.TransparencyLevelHintProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EFluentDialogViewModel_002CMerostrap_002EWindowBackdropType_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TopLevel.TransparencyLevelHintProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		P_1.Bind(transparencyLevelHintProperty, binding);
		StyledProperty<IBrush?> backgroundProperty = TemplatedControl.BackgroundProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EFluentDialogViewModel_002CMerostrap_002EBackgroundColourBrush_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TemplatedControl.BackgroundProperty;
		CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		P_1.Bind(backgroundProperty, binding2);
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Avalonia.Controls.Controls children = grid4.Children;
		TitleBar titleBar2;
		TitleBar titleBar = (titleBar2 = new TitleBar());
		((ISupportInitialize)titleBar).BeginInit();
		children.Add(titleBar);
		titleBar2.VerticalAlignment = VerticalAlignment.Top;
		titleBar2.ShowClose = false;
		titleBar2.Title = "";
		titleBar2.Icon = null;
		titleBar2.ShowMaximize = false;
		titleBar2.ShowMinimize = false;
		((ISupportInitialize)titleBar2).EndInit();
		Avalonia.Controls.Controls children2 = grid4.Children;
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		children2.Add(stackPanel);
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		Avalonia.Controls.Controls children3 = stackPanel4.Children;
		Image image2;
		Image image = (image2 = new Image());
		((ISupportInitialize)image).BeginInit();
		children3.Add(image);
		Image image4;
		Image image3 = (image4 = image2);
		context.PushParent(image4);
		image4.Width = 80.0;
		image4.Height = 80.0;
		image4.Margin = new Thickness(0.0, 45.0, 0.0, 0.0);
		image4.HorizontalAlignment = HorizontalAlignment.Center;
		image4.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "avares://Merostrap/Resources/Brand/Merostrap.png");
		RenderOptions.SetBitmapInterpolationMode(image4, BitmapInterpolationMode.HighQuality);
		context.PopParent();
		((ISupportInitialize)image3).EndInit();
		Avalonia.Controls.Controls children4 = stackPanel4.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children4.Add(textBlock);
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = textBlock2);
		context.PushParent(textBlock4);
		textBlock4.Margin = new Thickness(0.0, 50.0, 0.0, 0.0);
		textBlock4.HorizontalAlignment = HorizontalAlignment.Center;
		textBlock4.TextAlignment = TextAlignment.Center;
		textBlock4.FontSize = 18.0;
		textBlock4.TextTrimming = TextTrimming.CharacterEllipsis;
		StyledProperty<string?> textProperty = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002EMessage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding3 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock4.Bind(textProperty, binding3);
		context.PopParent();
		((ISupportInitialize)textBlock3).EndInit();
		Avalonia.Controls.Controls children5 = stackPanel4.Children;
		ProgressBar progressBar2;
		ProgressBar progressBar = (progressBar2 = new ProgressBar());
		((ISupportInitialize)progressBar).BeginInit();
		children5.Add(progressBar);
		ProgressBar progressBar4;
		ProgressBar progressBar3 = (progressBar4 = progressBar2);
		context.PushParent(progressBar4);
		progressBar4.Foreground = new ImmutableSolidColorBrush(4290979397u);
		progressBar4.Width = 450.0;
		progressBar4.Height = 10.0;
		progressBar4.Margin = new Thickness(0.0, 10.0, 0.0, 15.0);
		progressBar4.CornerRadius = new CornerRadius(50.0, 50.0, 50.0, 50.0);
		StyledProperty<bool> isIndeterminateProperty = ProgressBar.IsIndeterminateProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002EProgressIndeterminate_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ProgressBar.IsIndeterminateProperty;
		CompiledBinding binding4 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		progressBar4.Bind(isIndeterminateProperty, binding4);
		StyledProperty<double> maximumProperty = RangeBase.MaximumProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002EProgressMaximum_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = RangeBase.MaximumProperty;
		CompiledBinding binding5 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		progressBar4.Bind(maximumProperty, binding5);
		StyledProperty<double> valueProperty = RangeBase.ValueProperty;
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002EProgressValue_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = RangeBase.ValueProperty;
		CompiledBinding binding6 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		progressBar4.Bind(valueProperty, binding6);
		context.PopParent();
		((ISupportInitialize)progressBar3).EndInit();
		Avalonia.Controls.Controls children6 = stackPanel4.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children6.Add(button);
		Button button4;
		Button button3 = (button4 = button2);
		context.PushParent(button4);
		button4.Width = 120.0;
		button4.Height = 30.0;
		button4.HorizontalAlignment = HorizontalAlignment.Center;
		StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002ECancelInstallCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding7 = compiledBindingExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button4.Bind(commandProperty, binding7);
		CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002ECancelButtonText_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ContentControl.ContentProperty;
		CompiledBinding compiledBinding = compiledBindingExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_4(button4, compiledBinding);
		button4.FontSize = 14.0;
		StyledProperty<bool> isEnabledProperty = InputElement.IsEnabledProperty;
		CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EBootstrapper_002EBootstrapperDialogViewModel_002CMerostrap_002ECancelEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = InputElement.IsEnabledProperty;
		CompiledBinding binding8 = compiledBindingExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button4.Bind(isEnabledProperty, binding8);
		context.PopParent();
		((ISupportInitialize)button3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(FluentDialog P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
