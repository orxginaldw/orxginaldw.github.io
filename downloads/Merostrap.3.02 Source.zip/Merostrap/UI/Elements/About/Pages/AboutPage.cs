using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Data;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using CompiledAvaloniaXaml;
using Merostrap.UI.ViewModels.About;

namespace Merostrap.UI.Elements.About.Pages;

internal class AboutPage : UserControl
{
	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public AboutPage()
	{
		InitializeComponent();
		DataContext = new AboutViewModel();
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, AboutPage P_1)
	{
		XamlIlContext.Context<AboutPage> context = new XamlIlContext.Context<AboutPage>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FAbout_002FPages_002FAboutPage_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/About/Pages/AboutPage.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		P_1.Content = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		stackPanel4.Margin = new Thickness(24.0, 24.0, 24.0, 24.0);
		stackPanel4.Spacing = 8.0;
		Avalonia.Controls.Controls children = stackPanel4.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children.Add(textBlock);
		textBlock2.Text = "Merostrap";
		textBlock2.FontSize = 24.0;
		textBlock2.FontWeight = FontWeight.DemiBold;
		((ISupportInitialize)textBlock2).EndInit();
		Avalonia.Controls.Controls children2 = stackPanel4.Children;
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		children2.Add(textBlock3);
		TextBlock textBlock6;
		TextBlock textBlock5 = (textBlock6 = textBlock4);
		context.PushParent(textBlock6);
		StyledProperty<string?> textProperty = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EAbout_002EAboutViewModel_002CMerostrap_002EVersion_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock6.Bind(textProperty, binding);
		context.PopParent();
		((ISupportInitialize)textBlock5).EndInit();
		Avalonia.Controls.Controls children3 = stackPanel4.Children;
		TextBlock textBlock8;
		TextBlock textBlock7 = (textBlock8 = new TextBlock());
		((ISupportInitialize)textBlock7).BeginInit();
		children3.Add(textBlock7);
		textBlock8.Margin = new Thickness(0.0, 16.0, 0.0, 0.0);
		textBlock8.Text = "Built on Froststrap. Thanks to its developers and contributors.";
		textBlock8.TextWrapping = TextWrapping.Wrap;
		((ISupportInitialize)textBlock8).EndInit();
		Avalonia.Controls.Controls children4 = stackPanel4.Children;
		HyperlinkButton hyperlinkButton2;
		HyperlinkButton hyperlinkButton = (hyperlinkButton2 = new HyperlinkButton());
		((ISupportInitialize)hyperlinkButton).BeginInit();
		children4.Add(hyperlinkButton);
		hyperlinkButton2.Content = "Froststrap on GitHub";
		hyperlinkButton2.NavigateUri = new Uri("https://github.com/Froststrap/Froststrap", UriKind.RelativeOrAbsolute);
		hyperlinkButton2.HorizontalAlignment = HorizontalAlignment.Left;
		((ISupportInitialize)hyperlinkButton2).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(AboutPage P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
