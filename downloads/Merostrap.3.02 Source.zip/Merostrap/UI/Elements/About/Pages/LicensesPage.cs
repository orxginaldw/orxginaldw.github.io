using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using CompiledAvaloniaXaml;
using LucideAvalonia.Enum;
using Merostrap.Resources;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.ViewModels;

namespace Merostrap.UI.Elements.About.Pages;

internal class LicensesPage : UserControl
{
	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public LicensesPage()
	{
		InitializeComponent();
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, LicensesPage P_1)
	{
		XamlIlContext.Context<LicensesPage> context = new XamlIlContext.Context<LicensesPage>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FAbout_002FPages_002FLicensesPage_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/About/Pages/LicensesPage.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		P_1.Content = scrollViewer;
		scrollViewer2.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		scrollViewer2.Content = stackPanel;
		stackPanel2.Margin = new Thickness(14.0, 14.0, 14.0, 14.0);
		Avalonia.Controls.Controls children = stackPanel2.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children.Add(textBlock);
		textBlock2.Margin = new Thickness(0.0, 0.0, 0.0, 16.0);
		textBlock2.FontSize = 24.0;
		textBlock2.FontWeight = FontWeight.Bold;
		textBlock2.Text = Strings.About_Licenses_Title;
		((ISupportInitialize)textBlock2).EndInit();
		Avalonia.Controls.Controls children2 = stackPanel2.Children;
		UniformGrid uniformGrid2;
		UniformGrid uniformGrid = (uniformGrid2 = new UniformGrid());
		((ISupportInitialize)uniformGrid).BeginInit();
		children2.Add(uniformGrid);
		uniformGrid2.Columns = 3;
		Avalonia.Controls.Controls children3 = uniformGrid2.Children;
		CardAction cardAction2;
		CardAction cardAction = (cardAction2 = new CardAction());
		((ISupportInitialize)cardAction).BeginInit();
		children3.Add(cardAction);
		cardAction2.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
		cardAction2.Icon = LucideIconNames.Copyright;
		cardAction2.Header = "Bloxstrap";
		cardAction2.Description = Strings.Menu_About_Licenses_MIT;
		cardAction2.Command = GlobalViewModel.OpenWebpageCommand;
		cardAction2.CommandParameter = "https://github.com/bloxstraplabs/bloxstrap";
		((ISupportInitialize)cardAction2).EndInit();
		Avalonia.Controls.Controls children4 = uniformGrid2.Children;
		CardAction cardAction4;
		CardAction cardAction3 = (cardAction4 = new CardAction());
		((ISupportInitialize)cardAction3).BeginInit();
		children4.Add(cardAction3);
		cardAction4.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
		cardAction4.Icon = LucideIconNames.Copyright;
		cardAction4.Header = "Fishstrap";
		cardAction4.Description = Strings.Menu_About_Licenses_MIT;
		cardAction4.Command = GlobalViewModel.OpenWebpageCommand;
		cardAction4.CommandParameter = "https://github.com/Fishstrap/Fishstrap";
		((ISupportInitialize)cardAction4).EndInit();
		Avalonia.Controls.Controls children5 = uniformGrid2.Children;
		CardAction cardAction6;
		CardAction cardAction5 = (cardAction6 = new CardAction());
		((ISupportInitialize)cardAction5).BeginInit();
		children5.Add(cardAction5);
		cardAction6.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
		cardAction6.Icon = LucideIconNames.Copyright;
		cardAction6.Header = "AppleBlox";
		cardAction6.Description = "GPL-3.0";
		cardAction6.Command = GlobalViewModel.OpenWebpageCommand;
		cardAction6.CommandParameter = "https://github.com/AppleBlox/appleblox";
		((ISupportInitialize)cardAction6).EndInit();
		Avalonia.Controls.Controls children6 = uniformGrid2.Children;
		CardAction cardAction8;
		CardAction cardAction7 = (cardAction8 = new CardAction());
		((ISupportInitialize)cardAction7).BeginInit();
		children6.Add(cardAction7);
		cardAction8.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
		cardAction8.Icon = LucideIconNames.Copyright;
		cardAction8.Header = "Sober/Vinegar";
		cardAction8.Description = "GPL-3.0";
		cardAction8.Command = GlobalViewModel.OpenWebpageCommand;
		cardAction8.CommandParameter = "https://github.com/vinegarhq/vinegar";
		((ISupportInitialize)cardAction8).EndInit();
		Avalonia.Controls.Controls children7 = uniformGrid2.Children;
		CardAction cardAction10;
		CardAction cardAction9 = (cardAction10 = new CardAction());
		((ISupportInitialize)cardAction9).BeginInit();
		children7.Add(cardAction9);
		cardAction10.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
		cardAction10.Icon = LucideIconNames.Copyright;
		cardAction10.Header = "Avalonia";
		cardAction10.Description = Strings.Menu_About_Licenses_MIT;
		cardAction10.Command = GlobalViewModel.OpenWebpageCommand;
		cardAction10.CommandParameter = "https://github.com/AvaloniaUI/Avalonia";
		((ISupportInitialize)cardAction10).EndInit();
		Avalonia.Controls.Controls children8 = uniformGrid2.Children;
		CardAction cardAction12;
		CardAction cardAction11 = (cardAction12 = new CardAction());
		((ISupportInitialize)cardAction11).BeginInit();
		children8.Add(cardAction11);
		cardAction12.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
		cardAction12.Icon = LucideIconNames.Copyright;
		cardAction12.Header = "AnimatedImage";
		cardAction12.Description = Strings.Menu_About_Licenses_Apache;
		cardAction12.Command = GlobalViewModel.OpenWebpageCommand;
		cardAction12.CommandParameter = "https://github.com/whistyun/AnimatedImage";
		((ISupportInitialize)cardAction12).EndInit();
		Avalonia.Controls.Controls children9 = uniformGrid2.Children;
		CardAction cardAction14;
		CardAction cardAction13 = (cardAction14 = new CardAction());
		((ISupportInitialize)cardAction13).BeginInit();
		children9.Add(cardAction13);
		cardAction14.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
		cardAction14.Icon = LucideIconNames.Copyright;
		cardAction14.Header = "Avalonia Edit";
		cardAction14.Description = Strings.Menu_About_Licenses_MIT;
		cardAction14.Command = GlobalViewModel.OpenWebpageCommand;
		cardAction14.CommandParameter = "https://github.com/AvaloniaUI/AvaloniaEdit";
		((ISupportInitialize)cardAction14).EndInit();
		Avalonia.Controls.Controls children10 = uniformGrid2.Children;
		CardAction cardAction16;
		CardAction cardAction15 = (cardAction16 = new CardAction());
		((ISupportInitialize)cardAction15).BeginInit();
		children10.Add(cardAction15);
		cardAction16.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
		cardAction16.Icon = LucideIconNames.Copyright;
		cardAction16.Header = "Fluent Avalonia";
		cardAction16.Description = Strings.Menu_About_Licenses_MIT;
		cardAction16.Command = GlobalViewModel.OpenWebpageCommand;
		cardAction16.CommandParameter = "https://github.com/amwx/FluentAvalonia";
		((ISupportInitialize)cardAction16).EndInit();
		Avalonia.Controls.Controls children11 = uniformGrid2.Children;
		CardAction cardAction18;
		CardAction cardAction17 = (cardAction18 = new CardAction());
		((ISupportInitialize)cardAction17).BeginInit();
		children11.Add(cardAction17);
		cardAction18.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
		cardAction18.Icon = LucideIconNames.Copyright;
		cardAction18.Header = "LucideAvalonia";
		cardAction18.Description = Strings.Menu_About_Licenses_MIT;
		cardAction18.Command = GlobalViewModel.OpenWebpageCommand;
		cardAction18.CommandParameter = "https://github.com/MarwanFr/LucideAvaloniaUI";
		((ISupportInitialize)cardAction18).EndInit();
		Avalonia.Controls.Controls children12 = uniformGrid2.Children;
		CardAction cardAction20;
		CardAction cardAction19 = (cardAction20 = new CardAction());
		((ISupportInitialize)cardAction19).BeginInit();
		children12.Add(cardAction19);
		cardAction20.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
		cardAction20.Icon = LucideIconNames.Copyright;
		cardAction20.Header = "Pixi ColorPicker";
		cardAction20.Description = Strings.Menu_About_Licenses_MIT;
		cardAction20.Command = GlobalViewModel.OpenWebpageCommand;
		cardAction20.CommandParameter = "https://github.com/PixiEditor/ColorPicker";
		((ISupportInitialize)cardAction20).EndInit();
		Avalonia.Controls.Controls children13 = uniformGrid2.Children;
		CardAction cardAction22;
		CardAction cardAction21 = (cardAction22 = new CardAction());
		((ISupportInitialize)cardAction21).BeginInit();
		children13.Add(cardAction21);
		cardAction22.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
		cardAction22.Icon = LucideIconNames.Copyright;
		cardAction22.Header = "CommunityToolKit MVVM";
		cardAction22.Description = Strings.Menu_About_Licenses_MIT;
		cardAction22.Command = GlobalViewModel.OpenWebpageCommand;
		cardAction22.CommandParameter = "https://github.com/CommunityToolkit/dotnet";
		((ISupportInitialize)cardAction22).EndInit();
		Avalonia.Controls.Controls children14 = uniformGrid2.Children;
		CardAction cardAction24;
		CardAction cardAction23 = (cardAction24 = new CardAction());
		((ISupportInitialize)cardAction23).BeginInit();
		children14.Add(cardAction23);
		cardAction24.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
		cardAction24.Icon = LucideIconNames.Copyright;
		cardAction24.Header = "Discord Rich Presence";
		cardAction24.Description = Strings.Menu_About_Licenses_MIT;
		cardAction24.Command = GlobalViewModel.OpenWebpageCommand;
		cardAction24.CommandParameter = "https://github.com/Lachee/discord-rpc-csharp";
		((ISupportInitialize)cardAction24).EndInit();
		Avalonia.Controls.Controls children15 = uniformGrid2.Children;
		CardAction cardAction26;
		CardAction cardAction25 = (cardAction26 = new CardAction());
		((ISupportInitialize)cardAction25).BeginInit();
		children15.Add(cardAction25);
		cardAction26.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
		cardAction26.Icon = LucideIconNames.Copyright;
		cardAction26.Header = "MarkDig";
		cardAction26.Description = "BSD 2-Clause License";
		cardAction26.Command = GlobalViewModel.OpenWebpageCommand;
		cardAction26.CommandParameter = "https://github.com/xoofx/markdig";
		((ISupportInitialize)cardAction26).EndInit();
		Avalonia.Controls.Controls children16 = uniformGrid2.Children;
		CardAction cardAction28;
		CardAction cardAction27 = (cardAction28 = new CardAction());
		((ISupportInitialize)cardAction27).BeginInit();
		children16.Add(cardAction27);
		cardAction28.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
		cardAction28.Icon = LucideIconNames.Copyright;
		cardAction28.Header = "SharpZipLib";
		cardAction28.Description = Strings.Menu_About_Licenses_MIT;
		cardAction28.Command = GlobalViewModel.OpenWebpageCommand;
		cardAction28.CommandParameter = "https://github.com/icsharpcode/SharpZipLib";
		((ISupportInitialize)cardAction28).EndInit();
		Avalonia.Controls.Controls children17 = uniformGrid2.Children;
		CardAction cardAction30;
		CardAction cardAction29 = (cardAction30 = new CardAction());
		((ISupportInitialize)cardAction29).BeginInit();
		children17.Add(cardAction29);
		cardAction30.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
		cardAction30.Icon = LucideIconNames.Copyright;
		cardAction30.Header = "Puppeteer Sharp";
		cardAction30.Description = Strings.Menu_About_Licenses_MIT;
		cardAction30.Command = GlobalViewModel.OpenWebpageCommand;
		cardAction30.CommandParameter = "https://github.com/hardkoded/puppeteer-sharp";
		((ISupportInitialize)cardAction30).EndInit();
		Avalonia.Controls.Controls children18 = uniformGrid2.Children;
		CardAction cardAction32;
		CardAction cardAction31 = (cardAction32 = new CardAction());
		((ISupportInitialize)cardAction31).BeginInit();
		children18.Add(cardAction31);
		cardAction32.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
		cardAction32.Icon = LucideIconNames.Copyright;
		cardAction32.Header = "Puppeteer Sharp Extra";
		cardAction32.Description = Strings.Menu_About_Licenses_MIT;
		cardAction32.Command = GlobalViewModel.OpenWebpageCommand;
		cardAction32.CommandParameter = "https://github.com/Overmiind/Puppeteer-sharp-extra";
		((ISupportInitialize)cardAction32).EndInit();
		Avalonia.Controls.Controls children19 = uniformGrid2.Children;
		CardAction cardAction34;
		CardAction cardAction33 = (cardAction34 = new CardAction());
		((ISupportInitialize)cardAction33).BeginInit();
		children19.Add(cardAction33);
		cardAction34.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
		cardAction34.Icon = LucideIconNames.Copyright;
		cardAction34.Header = "NLog";
		cardAction34.Description = "BSD 3-Clause License";
		cardAction34.Command = GlobalViewModel.OpenWebpageCommand;
		cardAction34.CommandParameter = "https://github.com/NLog/NLog";
		((ISupportInitialize)cardAction34).EndInit();
		Avalonia.Controls.Controls children20 = uniformGrid2.Children;
		CardAction cardAction36;
		CardAction cardAction35 = (cardAction36 = new CardAction());
		((ISupportInitialize)cardAction35).BeginInit();
		children20.Add(cardAction35);
		cardAction36.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
		cardAction36.Icon = LucideIconNames.Copyright;
		cardAction36.Header = "objc2";
		cardAction36.Description = "Zlib OR Apache-2.0 OR MIT License";
		cardAction36.Command = GlobalViewModel.OpenWebpageCommand;
		cardAction36.CommandParameter = "https://github.com/madsmtm/objc2";
		((ISupportInitialize)cardAction36).EndInit();
		Avalonia.Controls.Controls children21 = uniformGrid2.Children;
		CardAction cardAction38;
		CardAction cardAction37 = (cardAction38 = new CardAction());
		((ISupportInitialize)cardAction37).BeginInit();
		children21.Add(cardAction37);
		cardAction38.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
		cardAction38.Icon = LucideIconNames.Copyright;
		cardAction38.Header = "zbus";
		cardAction38.Description = "MIT License";
		cardAction38.Command = GlobalViewModel.OpenWebpageCommand;
		cardAction38.CommandParameter = "https://github.com/z-galaxy/zbus";
		((ISupportInitialize)cardAction38).EndInit();
		Avalonia.Controls.Controls children22 = uniformGrid2.Children;
		CardAction cardAction40;
		CardAction cardAction39 = (cardAction40 = new CardAction());
		((ISupportInitialize)cardAction39).BeginInit();
		children22.Add(cardAction39);
		cardAction40.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
		cardAction40.Icon = LucideIconNames.Copyright;
		cardAction40.Header = "windows_rs";
		cardAction40.Description = "Apache-2.0 OR MIT License";
		cardAction40.Command = GlobalViewModel.OpenWebpageCommand;
		cardAction40.CommandParameter = "https://github.com/microsoft/windows-rs";
		((ISupportInitialize)cardAction40).EndInit();
		Avalonia.Controls.Controls children23 = uniformGrid2.Children;
		CardAction cardAction42;
		CardAction cardAction41 = (cardAction42 = new CardAction());
		((ISupportInitialize)cardAction41).BeginInit();
		children23.Add(cardAction41);
		cardAction42.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
		cardAction42.Icon = LucideIconNames.Copyright;
		cardAction42.Header = "WiX Toolset";
		cardAction42.Description = "MS-RL License";
		cardAction42.Command = GlobalViewModel.OpenWebpageCommand;
		cardAction42.CommandParameter = "https://github.com/wixtoolset/wix";
		((ISupportInitialize)cardAction42).EndInit();
		((ISupportInitialize)uniformGrid2).EndInit();
		((ISupportInitialize)stackPanel2).EndInit();
		((ISupportInitialize)scrollViewer2).EndInit();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(LicensesPage P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
