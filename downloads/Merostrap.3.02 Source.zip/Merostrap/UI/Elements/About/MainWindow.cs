using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using System.Runtime.CompilerServices;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Styling;
using CompiledAvaloniaXaml;
using FluentAvalonia.UI.Controls;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.Resources;
using Merostrap.UI.Elements.Base;
using Merostrap.UI.ViewModels.About;

namespace Merostrap.UI.Elements.About;

internal class MainWindow : AvaloniaWindow
{
	private readonly MainWindowViewModel? _viewModel;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Grid MainGrid;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal FANavigationView NavView;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TransitioningContentControl PageContentControl;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	protected override bool ApplyTopPadding => false;

	public MainWindow()
	{
		_viewModel = new MainWindowViewModel();
		DataContext = _viewModel;
		Closed += (object? _, EventArgs _) =>
		{
			App.AboutOpen = false;
		};
		InitializeComponent();
		Loaded += (object? _, RoutedEventArgs _) =>
		{
			NavView.IsPaneOpen = false;
		};
		App.FrostRPC?.SetDialog("About");
		_viewModel.PropertyChanged += OnViewModelPropertyChanged;
		_viewModel.NavigateToAboutCommand.Execute(null);
		UpdateSelectedNavigationViewItem(_viewModel.SelectedPage);
	}

	private void OnViewModelPropertyChanged(object? sender, PropertyChangedEventArgs e)
	{
		if (_viewModel != null)
		{
			if (e.PropertyName == "CurrentPage")
			{
				UpdatePageView(_viewModel.CurrentPage);
			}
			if (e.PropertyName == "SelectedPage")
			{
				UpdateSelectedNavigationViewItem(_viewModel.SelectedPage);
			}
		}
	}

	private void UpdatePageView(object? viewModel)
	{
		TransitioningContentControl transitioningContentControl = this.FindControl<TransitioningContentControl>("PageContentControl");
		if (transitioningContentControl != null && viewModel != null)
		{
			Control control = ResolveViewForViewModel(viewModel);
			if (control != null)
			{
				control.DataContext = viewModel;
				transitioningContentControl.Content = control;
			}
		}
	}

	private static Control? ResolveViewForViewModel(object viewModel)
	{
		string text = viewModel.GetType().Name.Replace("ViewModel", "", StringComparison.Ordinal);
		string[] array = new string[6]
		{
			"Merostrap.UI.Elements.About.Pages." + text + "Page",
			"Merostrap.UI.Elements.About.Pages." + text,
			"Merostrap.UI.Elements.About." + text + "Page",
			"Merostrap.UI.Elements.About." + text,
			"Merostrap.UI.Elements." + text + "Page",
			"Merostrap.UI.Elements." + text
		};
		foreach (string text2 in array)
		{
			Type type = Type.GetType(text2);
			if (type == null)
			{
				try
				{
					type = Assembly.GetExecutingAssembly().GetType(text2, throwOnError: false);
				}
				catch
				{
				}
			}
			if (!(type != null) || !typeof(Control).IsAssignableFrom(type))
			{
				continue;
			}
			try
			{
				if (Activator.CreateInstance(type) is Control result)
				{
					return result;
				}
			}
			catch (Exception ex)
			{
				App.Logger.Error("Failed to create view " + text2 + ": " + ex.Message);
			}
		}
		return null;
	}

	private void UpdateSelectedNavigationViewItem(string selectedTag)
	{
		FANavigationView fANavigationView = this.FindControl<FANavigationView>("NavView");
		if (fANavigationView == null)
		{
			return;
		}
		foreach (object menuItem in fANavigationView.MenuItems)
		{
			if (menuItem is FANavigationViewItem { Tag: string tag } fANavigationViewItem && tag == selectedTag)
			{
				fANavigationView.SelectedItem = fANavigationViewItem;
				break;
			}
		}
	}

	private void NavView_ItemInvoked(object? sender, FANavigationViewItemInvokedEventArgs e)
	{
		if (e.InvokedItemContainer is FANavigationViewItem fANavigationViewItem)
		{
			switch (fANavigationViewItem.Tag as string)
			{
			case "about":
				_viewModel?.NavigateToAboutCommand.Execute(null);
				break;
			case "licenses":
				_viewModel?.NavigateToLicensesCommand.Execute(null);
				break;
			case "onboarding":
				_viewModel?.RestartOnboardingCommand.Execute(null);
				break;
			}
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		MainGrid = nameScope?.Find<Grid>("MainGrid");
		NavView = nameScope?.Find<FANavigationView>("NavView");
		PageContentControl = nameScope?.Find<TransitioningContentControl>("PageContentControl");
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, MainWindow P_1)
	{
		XamlIlContext.Context<MainWindow> context = new XamlIlContext.Context<MainWindow>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FAbout_002FMainWindow_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/About/MainWindow.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Title = Strings.About_Title;
		P_1.MinWidth = 740.0;
		P_1.Width = 740.0;
		P_1.Height = 440.0;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		P_1.CanResize = true;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid5.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid5.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children.Add(border);
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border4.Bind(backgroundProperty, binding);
		border4.Height = 40.0;
		border4.IsHitTestVisible = false;
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		Avalonia.Controls.Controls children2 = grid5.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children2.Add(grid6);
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		Grid.SetRow(grid9, 1);
		grid9.Name = "MainGrid";
		object element = grid9;
		context.AvaloniaNameScope.Register("MainGrid", element);
		Avalonia.Controls.Controls children3 = grid9.Children;
		FANavigationView fANavigationView2;
		FANavigationView fANavigationView = (fANavigationView2 = new FANavigationView());
		((ISupportInitialize)fANavigationView).BeginInit();
		children3.Add(fANavigationView);
		FANavigationView fANavigationView4;
		FANavigationView fANavigationView3 = (fANavigationView4 = fANavigationView2);
		context.PushParent(fANavigationView4);
		fANavigationView4.Name = "NavView";
		element = fANavigationView4;
		context.AvaloniaNameScope.Register("NavView", element);
		StyledProperty<IBrush?> backgroundProperty2 = TemplatedControl.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = TemplatedControl.BackgroundProperty;
		BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		fANavigationView4.Bind(backgroundProperty2, binding2);
		fANavigationView4.PaneDisplayMode = FANavigationViewPaneDisplayMode.Left;
		fANavigationView4.IsSettingsVisible = false;
		fANavigationView4.OpenPaneLength = 160.0;
		fANavigationView4.ItemInvoked += context.RootObject.NavView_ItemInvoked;
		Styles styles = fANavigationView4.Styles;
		Style style = new Style();
		style.Selector = ((Selector?)null).OfType(typeof(FANavigationView)).Template().OfType(typeof(ScrollViewer))
			.Name("MenuItemsScrollViewer");
		Setter setter = new Setter();
		setter.Property = ScrollViewer.VerticalScrollBarVisibilityProperty;
		setter.Value = ScrollBarVisibility.Hidden;
		style.Add(setter);
		styles.Add(style);
		IList<object> menuItems = fANavigationView4.MenuItems;
		FANavigationViewItem fANavigationViewItem2;
		FANavigationViewItem fANavigationViewItem = (fANavigationViewItem2 = new FANavigationViewItem());
		((ISupportInitialize)fANavigationViewItem).BeginInit();
		menuItems.Add(fANavigationViewItem);
		fANavigationViewItem2.Tag = "about";
		fANavigationViewItem2.Content = Strings.Menu_About_Title;
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		fANavigationViewItem2.Icon = lucide;
		lucide2.Icon = LucideIconNames.CircleAlert;
		lucide2.Width = 20.0;
		lucide2.Height = 20.0;
		((ISupportInitialize)lucide2).EndInit();
		((ISupportInitialize)fANavigationViewItem2).EndInit();
		IList<object> menuItems2 = fANavigationView4.MenuItems;
		FANavigationViewItem fANavigationViewItem4;
		FANavigationViewItem fANavigationViewItem3 = (fANavigationViewItem4 = new FANavigationViewItem());
		((ISupportInitialize)fANavigationViewItem3).BeginInit();
		menuItems2.Add(fANavigationViewItem3);
		fANavigationViewItem4.Tag = "licenses";
		fANavigationViewItem4.Content = Strings.About_Licenses_Title;
		Lucide lucide4;
		Lucide lucide3 = (lucide4 = new Lucide());
		((ISupportInitialize)lucide3).BeginInit();
		fANavigationViewItem4.Icon = lucide3;
		lucide4.Icon = LucideIconNames.Copyright;
		lucide4.Width = 20.0;
		lucide4.Height = 20.0;
		((ISupportInitialize)lucide4).EndInit();
		((ISupportInitialize)fANavigationViewItem4).EndInit();
		IList<object> footerMenuItems = fANavigationView4.FooterMenuItems;
		FANavigationViewItem fANavigationViewItem6;
		FANavigationViewItem fANavigationViewItem5 = (fANavigationViewItem6 = new FANavigationViewItem());
		((ISupportInitialize)fANavigationViewItem5).BeginInit();
		footerMenuItems.Add(fANavigationViewItem5);
		fANavigationViewItem6.Tag = "onboarding";
		fANavigationViewItem6.Content = Strings.About_Onboarding_Title;
		Lucide lucide6;
		Lucide lucide5 = (lucide6 = new Lucide());
		((ISupportInitialize)lucide5).BeginInit();
		fANavigationViewItem6.Icon = lucide5;
		lucide6.Icon = LucideIconNames.Rocket;
		lucide6.Width = 20.0;
		lucide6.Height = 20.0;
		((ISupportInitialize)lucide6).EndInit();
		((ISupportInitialize)fANavigationViewItem6).EndInit();
		TransitioningContentControl transitioningContentControl2;
		TransitioningContentControl transitioningContentControl = (transitioningContentControl2 = new TransitioningContentControl());
		((ISupportInitialize)transitioningContentControl).BeginInit();
		fANavigationView4.Content = transitioningContentControl;
		TransitioningContentControl transitioningContentControl4;
		TransitioningContentControl transitioningContentControl3 = (transitioningContentControl4 = transitioningContentControl2);
		context.PushParent(transitioningContentControl4);
		transitioningContentControl4.Name = "PageContentControl";
		element = transitioningContentControl4;
		context.AvaloniaNameScope.Register("PageContentControl", element);
		transitioningContentControl4.HorizontalAlignment = HorizontalAlignment.Stretch;
		transitioningContentControl4.VerticalAlignment = VerticalAlignment.Stretch;
		StyledProperty<IBrush?> backgroundProperty3 = TemplatedControl.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("LayerFillColorDefaultBrush");
		context.ProvideTargetProperty = TemplatedControl.BackgroundProperty;
		BindingBase binding3 = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		transitioningContentControl4.Bind(backgroundProperty3, binding3);
		context.PopParent();
		((ISupportInitialize)transitioningContentControl3).EndInit();
		context.PopParent();
		((ISupportInitialize)fANavigationView3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(MainWindow P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
