using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Platform;
using CompiledAvaloniaXaml;
using Merostrap.Enums.Messagebox;
using Merostrap.Resources;
using Merostrap.UI.Elements.Base;
using Merostrap.UI.Elements.Controls;

namespace Merostrap.UI.Elements.Dialogs;

internal class ConnectivityDialog : AvaloniaWindow
{
	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Image IconImage;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBlock TitleTextBlock;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal MarkdownTextBlock DescriptionMarkdownTextBlock;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBox ErrorTextBox;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBlock VersionText;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button CloseButton;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public ConnectivityDialog()
	{
		InitializeComponent();
	}

	public ConnectivityDialog(string title, string description, MessageBoxImage image, Exception exception)
		: this()
	{
		App.FrostRPC?.SetDialog("Connectivity");
		string text = null;
		switch (image)
		{
		case MessageBoxImage.Error:
			text = "Error";
			break;
		case MessageBoxImage.Question:
			text = "Question";
			break;
		case MessageBoxImage.Warning:
			text = "Warning";
			break;
		case MessageBoxImage.Information:
			text = "Information";
			break;
		}
		if (text == null)
		{
			IconImage.IsVisible = false;
		}
		else
		{
			using Stream stream = AssetLoader.Open(new Uri("avares://Merostrap/Resources/MessageBox/" + text + ".png"));
			IconImage.Source = new Bitmap(stream);
		}
		TitleTextBlock.Text = title;
		DescriptionMarkdownTextBlock.MarkdownText = description;
		AddException(exception);
		VersionText.Text = string.Format(CultureInfo.InvariantCulture, Strings.Menu_About_Version, App.Version);
		CloseButton.Click += (object? _, RoutedEventArgs _) =>
		{
			Close();
		};
		Loaded += (object? _, RoutedEventArgs _) =>
		{
			Activate();
			Topmost = true;
			Topmost = false;
		};
	}

	private void AddException(Exception exception, bool inner = false)
	{
		StringBuilder stringBuilder = new StringBuilder();
		if (!inner)
		{
			StringBuilder stringBuilder2 = stringBuilder;
			StringBuilder stringBuilder3 = stringBuilder2;
			IFormatProvider invariantCulture = CultureInfo.InvariantCulture;
			IFormatProvider provider = invariantCulture;
			StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(2, 2, stringBuilder2, invariantCulture);
			handler.AppendFormatted(exception.GetType());
			handler.AppendLiteral(": ");
			handler.AppendFormatted(exception.Message);
			stringBuilder3.AppendLine(provider, ref handler);
		}
		else
		{
			StringBuilder stringBuilder2 = stringBuilder;
			StringBuilder stringBuilder4 = stringBuilder2;
			IFormatProvider invariantCulture = CultureInfo.InvariantCulture;
			IFormatProvider provider2 = invariantCulture;
			StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(20, 2, stringBuilder2, invariantCulture);
			handler.AppendLiteral("[Inner Exception]\n");
			handler.AppendFormatted(exception.GetType());
			handler.AppendLiteral(": ");
			handler.AppendFormatted(exception.Message);
			stringBuilder4.AppendLine(provider2, ref handler);
		}
		if (exception.StackTrace != null)
		{
			StringBuilder stringBuilder2 = stringBuilder;
			StringBuilder stringBuilder5 = stringBuilder2;
			IFormatProvider invariantCulture = CultureInfo.InvariantCulture;
			IFormatProvider provider3 = invariantCulture;
			StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(14, 1, stringBuilder2, invariantCulture);
			handler.AppendLiteral("\nStack Trace:\n");
			handler.AppendFormatted(exception.StackTrace);
			stringBuilder5.AppendLine(provider3, ref handler);
		}
		if (exception.InnerException != null)
		{
			stringBuilder.AppendLine();
			AddExceptionToBuilder(exception.InnerException, stringBuilder, inner: true);
		}
		ErrorTextBox.Text = stringBuilder.ToString();
	}

	private static void AddExceptionToBuilder(Exception exception, StringBuilder sb, bool inner = false)
	{
		if (inner)
		{
			StringBuilder stringBuilder = sb;
			StringBuilder stringBuilder2 = stringBuilder;
			IFormatProvider invariantCulture = CultureInfo.InvariantCulture;
			IFormatProvider provider = invariantCulture;
			StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(20, 2, stringBuilder, invariantCulture);
			handler.AppendLiteral("[Inner Exception]\n");
			handler.AppendFormatted(exception.GetType());
			handler.AppendLiteral(": ");
			handler.AppendFormatted(exception.Message);
			stringBuilder2.AppendLine(provider, ref handler);
		}
		else
		{
			StringBuilder stringBuilder = sb;
			StringBuilder stringBuilder3 = stringBuilder;
			IFormatProvider invariantCulture = CultureInfo.InvariantCulture;
			IFormatProvider provider2 = invariantCulture;
			StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(2, 2, stringBuilder, invariantCulture);
			handler.AppendFormatted(exception.GetType());
			handler.AppendLiteral(": ");
			handler.AppendFormatted(exception.Message);
			stringBuilder3.AppendLine(provider2, ref handler);
		}
		if (exception.StackTrace != null)
		{
			StringBuilder stringBuilder = sb;
			StringBuilder stringBuilder4 = stringBuilder;
			IFormatProvider invariantCulture = CultureInfo.InvariantCulture;
			IFormatProvider provider3 = invariantCulture;
			StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(14, 1, stringBuilder, invariantCulture);
			handler.AppendLiteral("\nStack Trace:\n");
			handler.AppendFormatted(exception.StackTrace);
			stringBuilder4.AppendLine(provider3, ref handler);
		}
		if (exception.InnerException != null)
		{
			sb.AppendLine();
			AddExceptionToBuilder(exception.InnerException, sb, inner: true);
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		IconImage = nameScope?.Find<Image>("IconImage");
		TitleTextBlock = nameScope?.Find<TextBlock>("TitleTextBlock");
		DescriptionMarkdownTextBlock = nameScope?.Find<MarkdownTextBlock>("DescriptionMarkdownTextBlock");
		ErrorTextBox = nameScope?.Find<TextBox>("ErrorTextBox");
		VersionText = nameScope?.Find<TextBlock>("VersionText");
		CloseButton = nameScope?.Find<Button>("CloseButton");
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, ConnectivityDialog P_1)
	{
		XamlIlContext.Context<ConnectivityDialog> context = new XamlIlContext.Context<ConnectivityDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FConnectivityDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/ConnectivityDialog.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Width = 480.0;
		P_1.SizeToContent = SizeToContent.Height;
		P_1.Title = Strings.Dialog_Connectivity_Title;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid5.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid5.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children.Add(grid6);
		Grid.SetRow(grid7, 0);
		grid7.Margin = new Thickness(16.0, 16.0, 16.0, 16.0);
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 2;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid7.ColumnDefinitions = columnDefinitions;
		Avalonia.Controls.Controls children2 = grid7.Children;
		Image image2;
		Image image = (image2 = new Image());
		((ISupportInitialize)image).BeginInit();
		children2.Add(image);
		image2.Name = "IconImage";
		object element = image2;
		context.AvaloniaNameScope.Register("IconImage", element);
		Grid.SetColumn(image2, 0);
		image2.Width = 32.0;
		image2.Height = 32.0;
		image2.Margin = new Thickness(0.0, 0.0, 15.0, 0.0);
		image2.VerticalAlignment = VerticalAlignment.Top;
		RenderOptions.SetBitmapInterpolationMode(image2, BitmapInterpolationMode.HighQuality);
		((ISupportInitialize)image2).EndInit();
		Avalonia.Controls.Controls children3 = grid7.Children;
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		children3.Add(stackPanel);
		Grid.SetColumn(stackPanel2, 1);
		Avalonia.Controls.Controls children4 = stackPanel2.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children4.Add(textBlock);
		textBlock2.Name = "TitleTextBlock";
		element = textBlock2;
		context.AvaloniaNameScope.Register("TitleTextBlock", element);
		textBlock2.Text = "? is unable to connect to ?";
		textBlock2.FontSize = 18.0;
		textBlock2.TextWrapping = TextWrapping.Wrap;
		((ISupportInitialize)textBlock2).EndInit();
		Avalonia.Controls.Controls children5 = stackPanel2.Children;
		MarkdownTextBlock markdownTextBlock2;
		MarkdownTextBlock markdownTextBlock = (markdownTextBlock2 = new MarkdownTextBlock());
		((ISupportInitialize)markdownTextBlock).BeginInit();
		children5.Add(markdownTextBlock);
		markdownTextBlock2.Name = "DescriptionMarkdownTextBlock";
		element = markdownTextBlock2;
		context.AvaloniaNameScope.Register("DescriptionMarkdownTextBlock", element);
		markdownTextBlock2.MarkdownText = "?";
		markdownTextBlock2.Margin = new Thickness(0.0, 16.0, 0.0, 0.0);
		markdownTextBlock2.TextWrapping = TextWrapping.Wrap;
		((ISupportInitialize)markdownTextBlock2).EndInit();
		Avalonia.Controls.Controls children6 = stackPanel2.Children;
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		children6.Add(textBlock3);
		textBlock4.Text = Strings.Dialog_Connectivity_MoreInfo;
		textBlock4.Margin = new Thickness(0.0, 16.0, 0.0, 0.0);
		textBlock4.TextWrapping = TextWrapping.Wrap;
		((ISupportInitialize)textBlock4).EndInit();
		Avalonia.Controls.Controls children7 = stackPanel2.Children;
		TextBox textBox2;
		TextBox textBox = (textBox2 = new TextBox());
		((ISupportInitialize)textBox).BeginInit();
		children7.Add(textBox);
		textBox2.Name = "ErrorTextBox";
		element = textBox2;
		context.AvaloniaNameScope.Register("ErrorTextBox", element);
		textBox2.Padding = new Thickness(8.0, 8.0, 8.0, 8.0);
		textBox2.Margin = new Thickness(0.0, 8.0, 0.0, 0.0);
		textBox2.FontFamily = new FontFamily(((IUriContext)context).BaseUri, "Courier New");
		textBox2.IsReadOnly = true;
		textBox2.AcceptsReturn = true;
		textBox2.TextWrapping = TextWrapping.Wrap;
		ScrollViewer.SetVerticalScrollBarVisibility(textBox2, ScrollBarVisibility.Auto);
		textBox2.Height = 120.0;
		((ISupportInitialize)textBox2).EndInit();
		((ISupportInitialize)stackPanel2).EndInit();
		((ISupportInitialize)grid7).EndInit();
		Avalonia.Controls.Controls children8 = grid5.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children8.Add(border);
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Grid.SetRow(border4, 1);
		border4.Padding = new Thickness(15.0, 15.0, 15.0, 15.0);
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border4.Bind(backgroundProperty, binding);
		Grid grid9;
		Grid grid8 = (grid9 = new Grid());
		((ISupportInitialize)grid8).BeginInit();
		border4.Child = grid8;
		Grid grid10 = (grid4 = grid9);
		context.PushParent(grid4);
		Grid grid11 = grid4;
		Avalonia.Controls.Controls children9 = grid11.Children;
		TextBlock textBlock6;
		TextBlock textBlock5 = (textBlock6 = new TextBlock());
		((ISupportInitialize)textBlock5).BeginInit();
		children9.Add(textBlock5);
		TextBlock textBlock8;
		TextBlock textBlock7 = (textBlock8 = textBlock6);
		context.PushParent(textBlock8);
		textBlock8.Name = "VersionText";
		element = textBlock8;
		context.AvaloniaNameScope.Register("VersionText", element);
		textBlock8.VerticalAlignment = VerticalAlignment.Center;
		textBlock8.HorizontalAlignment = HorizontalAlignment.Left;
		StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("TextFillColorTertiaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock8.Bind(foregroundProperty, binding2);
		textBlock8.FontSize = 14.0;
		context.PopParent();
		((ISupportInitialize)textBlock7).EndInit();
		Avalonia.Controls.Controls children10 = grid11.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children10.Add(button);
		button2.Name = "CloseButton";
		element = button2;
		context.AvaloniaNameScope.Register("CloseButton", element);
		button2.MinWidth = 100.0;
		button2.Content = Strings.Common_Close;
		button2.HorizontalAlignment = HorizontalAlignment.Right;
		((ISupportInitialize)button2).EndInit();
		context.PopParent();
		((ISupportInitialize)grid10).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(ConnectivityDialog P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
