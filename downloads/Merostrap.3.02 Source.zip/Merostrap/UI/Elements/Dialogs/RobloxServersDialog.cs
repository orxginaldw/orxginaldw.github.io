using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Media.Immutable;
using CompiledAvaloniaXaml;
using FluentAvalonia.UI.Controls;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.Models;
using Merostrap.Resources;
using Merostrap.UI.Elements.Base;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.ViewModels.Dialogs;

namespace Merostrap.UI.Elements.Dialogs;

internal class RobloxServersDialog : AvaloniaWindow
{
	[CompilerGenerated]
	private class XamlClosure_23
	{
		public unsafe static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<RobloxServersDialog> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Border border = (Border)obj;
			context.PushParent(border);
			Border border2 = border;
			border2.Padding = new Thickness(12.0, 12.0, 12.0, 12.0);
			border2.Margin = new Thickness(0.0, 2.0, 0.0, 2.0);
			border2.Background = new ImmutableSolidColorBrush(855638016u);
			border2.CornerRadius = new CornerRadius(8.0, 8.0, 8.0, 8.0);
			Grid grid2;
			Grid grid = (grid2 = new Grid());
			((ISupportInitialize)grid).BeginInit();
			border2.Child = grid;
			Grid grid4;
			Grid grid3 = (grid4 = grid2);
			context.PushParent(grid4);
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 4;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid4.ColumnDefinitions = columnDefinitions;
			Avalonia.Controls.Controls children = grid4.Children;
			StackPanel stackPanel2;
			StackPanel stackPanel = (stackPanel2 = new StackPanel());
			((ISupportInitialize)stackPanel).BeginInit();
			children.Add(stackPanel);
			StackPanel stackPanel4;
			StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
			context.PushParent(stackPanel4);
			StackPanel stackPanel5 = stackPanel4;
			Grid.SetColumn(stackPanel5, 0);
			stackPanel5.MinWidth = 150.0;
			stackPanel5.VerticalAlignment = VerticalAlignment.Center;
			stackPanel5.Spacing = 4.0;
			Avalonia.Controls.Controls children2 = stackPanel5.Children;
			StackPanel stackPanel7;
			StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
			((ISupportInitialize)stackPanel6).BeginInit();
			children2.Add(stackPanel6);
			StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
			context.PushParent(stackPanel4);
			StackPanel stackPanel9 = stackPanel4;
			stackPanel9.Orientation = Orientation.Horizontal;
			stackPanel9.Spacing = 8.0;
			Avalonia.Controls.Controls children3 = stackPanel9.Children;
			Lucide lucide2;
			Lucide lucide = (lucide2 = new Lucide());
			((ISupportInitialize)lucide).BeginInit();
			children3.Add(lucide);
			lucide2.Icon = LucideIconNames.Globe;
			lucide2.Height = 14.0;
			lucide2.Width = 14.0;
			((ISupportInitialize)lucide2).EndInit();
			Avalonia.Controls.Controls children4 = stackPanel9.Children;
			TextBlock textBlock2;
			TextBlock textBlock = (textBlock2 = new TextBlock());
			((ISupportInitialize)textBlock).BeginInit();
			children4.Add(textBlock);
			TextBlock textBlock4;
			TextBlock textBlock3 = (textBlock4 = textBlock2);
			context.PushParent(textBlock4);
			TextBlock textBlock5 = textBlock4;
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EServerInfo_002CMerostrap_002ERegion_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock5.Bind(textProperty, binding);
			textBlock5.FontWeight = FontWeight.DemiBold;
			textBlock5.VerticalAlignment = VerticalAlignment.Center;
			context.PopParent();
			((ISupportInitialize)textBlock3).EndInit();
			Avalonia.Controls.Controls children5 = stackPanel9.Children;
			Border border4;
			Border border3 = (border4 = new Border());
			((ISupportInitialize)border3).BeginInit();
			children5.Add(border3);
			Border border5 = (border = border4);
			context.PushParent(border);
			Border border6 = border;
			border6.Margin = new Thickness(4.0, 0.0, 0.0, 0.0);
			border6.Padding = new Thickness(5.0, 1.0, 5.0, 1.0);
			border6.CornerRadius = new CornerRadius(4.0, 4.0, 4.0, 4.0);
			StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("AccentButtonBackground");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding2 = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border6.Bind(backgroundProperty, binding2);
			StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EServerInfo_002CMerostrap_002EIsLatest_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding3 = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border6.Bind(isVisibleProperty, binding3);
			TextBlock textBlock7;
			TextBlock textBlock6 = (textBlock7 = new TextBlock());
			((ISupportInitialize)textBlock6).BeginInit();
			border6.Child = textBlock6;
			TextBlock textBlock8 = (textBlock4 = textBlock7);
			context.PushParent(textBlock4);
			TextBlock textBlock9 = textBlock4;
			textBlock9.Text = Strings.Menu_QuickPlay_Latest;
			StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
			DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("AccentButtonForeground");
			context.ProvideTargetProperty = TextBlock.ForegroundProperty;
			BindingBase binding4 = dynamicResourceExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock9.Bind(foregroundProperty, binding4);
			textBlock9.FontSize = 8.0;
			context.PopParent();
			((ISupportInitialize)textBlock8).EndInit();
			context.PopParent();
			((ISupportInitialize)border5).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel8).EndInit();
			Avalonia.Controls.Controls children6 = stackPanel5.Children;
			StackPanel stackPanel11;
			StackPanel stackPanel10 = (stackPanel11 = new StackPanel());
			((ISupportInitialize)stackPanel10).BeginInit();
			children6.Add(stackPanel10);
			StackPanel stackPanel12 = (stackPanel4 = stackPanel11);
			context.PushParent(stackPanel4);
			StackPanel stackPanel13 = stackPanel4;
			stackPanel13.Orientation = Orientation.Horizontal;
			stackPanel13.Spacing = 12.0;
			Avalonia.Controls.Controls children7 = stackPanel13.Children;
			StackPanel stackPanel15;
			StackPanel stackPanel14 = (stackPanel15 = new StackPanel());
			((ISupportInitialize)stackPanel14).BeginInit();
			children7.Add(stackPanel14);
			StackPanel stackPanel16 = (stackPanel4 = stackPanel15);
			context.PushParent(stackPanel4);
			StackPanel stackPanel17 = stackPanel4;
			stackPanel17.Orientation = Orientation.Horizontal;
			stackPanel17.Spacing = 4.0;
			StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().ElementName(context.AvaloniaNameScope, "RootDialog").Property(StyledElement.DataContextProperty, PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ERobloxServersDialogViewModel_002CMerostrap_002EIsCurrentGameApi_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)
				.Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding5 = compiledBindingExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			stackPanel17.Bind(isVisibleProperty2, binding5);
			Avalonia.Controls.Controls children8 = stackPanel17.Children;
			Lucide lucide4;
			Lucide lucide3 = (lucide4 = new Lucide());
			((ISupportInitialize)lucide3).BeginInit();
			children8.Add(lucide3);
			lucide4.Icon = LucideIconNames.Users;
			lucide4.Height = 12.0;
			lucide4.Width = 12.0;
			lucide4.Opacity = 0.5;
			((ISupportInitialize)lucide4).EndInit();
			Avalonia.Controls.Controls children9 = stackPanel17.Children;
			TextBlock textBlock11;
			TextBlock textBlock10 = (textBlock11 = new TextBlock());
			((ISupportInitialize)textBlock10).BeginInit();
			children9.Add(textBlock10);
			TextBlock textBlock12 = (textBlock4 = textBlock11);
			context.PushParent(textBlock4);
			TextBlock textBlock13 = textBlock4;
			StyledProperty<string?> textProperty2 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EServerInfo_002CMerostrap_002EPlayerCount_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding6 = compiledBindingExtension4.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock13.Bind(textProperty2, binding6);
			textBlock13.FontSize = 11.0;
			textBlock13.Opacity = 0.7;
			context.PopParent();
			((ISupportInitialize)textBlock12).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel16).EndInit();
			Avalonia.Controls.Controls children10 = stackPanel13.Children;
			StackPanel stackPanel19;
			StackPanel stackPanel18 = (stackPanel19 = new StackPanel());
			((ISupportInitialize)stackPanel18).BeginInit();
			children10.Add(stackPanel18);
			StackPanel stackPanel20 = (stackPanel4 = stackPanel19);
			context.PushParent(stackPanel4);
			StackPanel stackPanel21 = stackPanel4;
			stackPanel21.Orientation = Orientation.Horizontal;
			stackPanel21.Spacing = 4.0;
			StyledProperty<bool> isVisibleProperty3 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().ElementName(context.AvaloniaNameScope, "RootDialog").Property(StyledElement.DataContextProperty, PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ERobloxServersDialogViewModel_002CMerostrap_002EIsCurrentGameApi_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)
				.Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding7 = compiledBindingExtension5.ProvideValue(context);
			context.ProvideTargetProperty = null;
			stackPanel21.Bind(isVisibleProperty3, binding7);
			Avalonia.Controls.Controls children11 = stackPanel21.Children;
			Lucide lucide6;
			Lucide lucide5 = (lucide6 = new Lucide());
			((ISupportInitialize)lucide5).BeginInit();
			children11.Add(lucide5);
			lucide6.Icon = LucideIconNames.Timer;
			lucide6.Height = 12.0;
			lucide6.Width = 12.0;
			lucide6.Opacity = 0.5;
			((ISupportInitialize)lucide6).EndInit();
			Avalonia.Controls.Controls children12 = stackPanel21.Children;
			TextBlock textBlock15;
			TextBlock textBlock14 = (textBlock15 = new TextBlock());
			((ISupportInitialize)textBlock14).BeginInit();
			children12.Add(textBlock14);
			TextBlock textBlock16 = (textBlock4 = textBlock15);
			context.PushParent(textBlock4);
			TextBlock textBlock17 = textBlock4;
			StyledProperty<string?> textProperty3 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EServerInfo_002CMerostrap_002EUptime_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding8 = compiledBindingExtension6.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock17.Bind(textProperty3, binding8);
			textBlock17.FontSize = 11.0;
			textBlock17.Opacity = 0.7;
			context.PopParent();
			((ISupportInitialize)textBlock16).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel20).EndInit();
			Avalonia.Controls.Controls children13 = stackPanel13.Children;
			StackPanel stackPanel23;
			StackPanel stackPanel22 = (stackPanel23 = new StackPanel());
			((ISupportInitialize)stackPanel22).BeginInit();
			children13.Add(stackPanel22);
			StackPanel stackPanel24 = (stackPanel4 = stackPanel23);
			context.PushParent(stackPanel4);
			StackPanel stackPanel25 = stackPanel4;
			stackPanel25.Orientation = Orientation.Horizontal;
			stackPanel25.Spacing = 4.0;
			StyledProperty<bool> isVisibleProperty4 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().ElementName(context.AvaloniaNameScope, "RootDialog").Property(StyledElement.DataContextProperty, PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ERobloxServersDialogViewModel_002CMerostrap_002EIsTrackedGame_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)
				.Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding9 = compiledBindingExtension7.ProvideValue(context);
			context.ProvideTargetProperty = null;
			stackPanel25.Bind(isVisibleProperty4, binding9);
			Avalonia.Controls.Controls children14 = stackPanel25.Children;
			Lucide lucide8;
			Lucide lucide7 = (lucide8 = new Lucide());
			((ISupportInitialize)lucide7).BeginInit();
			children14.Add(lucide7);
			lucide8.Icon = LucideIconNames.Timer;
			lucide8.Height = 12.0;
			lucide8.Width = 12.0;
			lucide8.Opacity = 0.5;
			((ISupportInitialize)lucide8).EndInit();
			Avalonia.Controls.Controls children15 = stackPanel25.Children;
			TextBlock textBlock19;
			TextBlock textBlock18 = (textBlock19 = new TextBlock());
			((ISupportInitialize)textBlock18).BeginInit();
			children15.Add(textBlock18);
			TextBlock textBlock20 = (textBlock4 = textBlock19);
			context.PushParent(textBlock4);
			TextBlock textBlock21 = textBlock4;
			StyledProperty<string?> textProperty4 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EServerInfo_002CMerostrap_002EDurationText_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding10 = compiledBindingExtension8.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock21.Bind(textProperty4, binding10);
			textBlock21.FontSize = 11.0;
			textBlock21.Opacity = 0.6;
			context.PopParent();
			((ISupportInitialize)textBlock20).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel24).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel12).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel3).EndInit();
			Avalonia.Controls.Controls children16 = grid4.Children;
			Border border8;
			Border border7 = (border8 = new Border());
			((ISupportInitialize)border7).BeginInit();
			children16.Add(border7);
			Border border9 = (border = border8);
			context.PushParent(border);
			Border border10 = border;
			Grid.SetColumn(border10, 1);
			border10.Width = 1.0;
			border10.Margin = new Thickness(16.0, 4.0, 16.0, 4.0);
			StyledProperty<IBrush?> backgroundProperty2 = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("DividerStrokeColorDefaultBrush");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding11 = dynamicResourceExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border10.Bind(backgroundProperty2, binding11);
			StyledProperty<bool> isVisibleProperty5 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().ElementName(context.AvaloniaNameScope, "RootDialog").Property(StyledElement.DataContextProperty, PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ERobloxServersDialogViewModel_002CMerostrap_002EIsCurrentGameApi_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)
				.Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding12 = compiledBindingExtension9.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border10.Bind(isVisibleProperty5, binding12);
			context.PopParent();
			((ISupportInitialize)border9).EndInit();
			Avalonia.Controls.Controls children17 = grid4.Children;
			Border border12;
			Border border11 = (border12 = new Border());
			((ISupportInitialize)border11).BeginInit();
			children17.Add(border11);
			Border border13 = (border = border12);
			context.PushParent(border);
			Border border14 = border;
			Grid.SetColumn(border14, 2);
			border14.HorizontalAlignment = HorizontalAlignment.Left;
			border14.VerticalAlignment = VerticalAlignment.Center;
			border14.Background = new ImmutableSolidColorBrush(855638016u);
			border14.CornerRadius = new CornerRadius(22.0, 22.0, 22.0, 22.0);
			border14.Padding = new Thickness(8.0, 4.0, 8.0, 4.0);
			border14.Margin = new Thickness(4.0, 0.0, 16.0, 0.0);
			StyledProperty<bool> isVisibleProperty6 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().ElementName(context.AvaloniaNameScope, "RootDialog").Property(StyledElement.DataContextProperty, PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ERobloxServersDialogViewModel_002CMerostrap_002EIsCurrentGameApi_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)
				.Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding13 = compiledBindingExtension10.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border14.Bind(isVisibleProperty6, binding13);
			StackPanel stackPanel27;
			StackPanel stackPanel26 = (stackPanel27 = new StackPanel());
			((ISupportInitialize)stackPanel26).BeginInit();
			border14.Child = stackPanel26;
			StackPanel stackPanel28 = (stackPanel4 = stackPanel27);
			context.PushParent(stackPanel4);
			StackPanel stackPanel29 = stackPanel4;
			stackPanel29.Orientation = Orientation.Horizontal;
			Avalonia.Controls.Controls children18 = stackPanel29.Children;
			ItemsControl itemsControl2;
			ItemsControl itemsControl = (itemsControl2 = new ItemsControl());
			((ISupportInitialize)itemsControl).BeginInit();
			children18.Add(itemsControl);
			ItemsControl itemsControl4;
			ItemsControl itemsControl3 = (itemsControl4 = itemsControl2);
			context.PushParent(itemsControl4);
			StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
			CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EServerInfo_002CMerostrap_002EPlayerAvatarThumbnails_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
			CompiledBinding binding14 = compiledBindingExtension11.ProvideValue(context);
			context.ProvideTargetProperty = null;
			itemsControl4.Bind(itemsSourceProperty, binding14);
			itemsControl4.ItemsPanel = new ItemsPanelTemplate
			{
				Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&Build_2), context)
			};
			DataTemplate dataTemplate;
			DataTemplate itemTemplate = (dataTemplate = new DataTemplate());
			context.PushParent(dataTemplate);
			dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&Build_3), context);
			context.PopParent();
			itemsControl4.ItemTemplate = itemTemplate;
			context.PopParent();
			((ISupportInitialize)itemsControl3).EndInit();
			Avalonia.Controls.Controls children19 = stackPanel29.Children;
			Border border16;
			Border border15 = (border16 = new Border());
			((ISupportInitialize)border15).BeginInit();
			children19.Add(border15);
			Border border17 = (border = border16);
			context.PushParent(border);
			Border border18 = border;
			border18.Width = 32.0;
			border18.Height = 32.0;
			border18.CornerRadius = new CornerRadius(16.0, 16.0, 16.0, 16.0);
			border18.Background = new ImmutableSolidColorBrush(855638016u);
			StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
			DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("ControlStrokeColorDefaultBrush");
			context.ProvideTargetProperty = Border.BorderBrushProperty;
			BindingBase binding15 = dynamicResourceExtension4.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border18.Bind(borderBrushProperty, binding15);
			border18.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
			StyledProperty<bool> isVisibleProperty7 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EServerInfo_002CMerostrap_002EHasExtraPlayers_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding16 = compiledBindingExtension12.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border18.Bind(isVisibleProperty7, binding16);
			TextBlock textBlock23;
			TextBlock textBlock22 = (textBlock23 = new TextBlock());
			((ISupportInitialize)textBlock22).BeginInit();
			border18.Child = textBlock22;
			TextBlock textBlock24 = (textBlock4 = textBlock23);
			context.PushParent(textBlock4);
			TextBlock textBlock25 = textBlock4;
			StyledProperty<string?> textProperty5 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EServerInfo_002CMerostrap_002EExtraPlayersText_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding17 = compiledBindingExtension13.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock25.Bind(textProperty5, binding17);
			textBlock25.VerticalAlignment = VerticalAlignment.Center;
			textBlock25.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock25.FontSize = 11.0;
			textBlock25.FontWeight = FontWeight.DemiBold;
			StyledProperty<IBrush?> foregroundProperty2 = TextBlock.ForegroundProperty;
			DynamicResourceExtension dynamicResourceExtension5 = new DynamicResourceExtension("TextFillColorPrimaryBrush");
			context.ProvideTargetProperty = TextBlock.ForegroundProperty;
			BindingBase binding18 = dynamicResourceExtension5.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock25.Bind(foregroundProperty2, binding18);
			context.PopParent();
			((ISupportInitialize)textBlock24).EndInit();
			context.PopParent();
			((ISupportInitialize)border17).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel28).EndInit();
			context.PopParent();
			((ISupportInitialize)border13).EndInit();
			Avalonia.Controls.Controls children20 = grid4.Children;
			IconButton iconButton2;
			IconButton iconButton = (iconButton2 = new IconButton());
			((ISupportInitialize)iconButton).BeginInit();
			children20.Add(iconButton);
			IconButton iconButton4;
			IconButton iconButton3 = (iconButton4 = iconButton2);
			context.PushParent(iconButton4);
			Grid.SetColumn(iconButton4, 3);
			iconButton4.Classes.Add("Primary");
			iconButton4.VerticalAlignment = VerticalAlignment.Center;
			StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().ElementName(context.AvaloniaNameScope, "RootDialog").Property(StyledElement.DataContextProperty, PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ERobloxServersDialogViewModel_002CMerostrap_002ERejoinServerCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)
				.Build());
			context.ProvideTargetProperty = Button.CommandProperty;
			CompiledBinding binding19 = compiledBindingExtension14.ProvideValue(context);
			context.ProvideTargetProperty = null;
			iconButton4.Bind(commandProperty, binding19);
			CompiledBindingExtension compiledBindingExtension15 = new CompiledBindingExtension();
			context.ProvideTargetProperty = Button.CommandParameterProperty;
			CompiledBinding compiledBinding = compiledBindingExtension15.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_6(iconButton4, compiledBinding);
			iconButton4.Content = "Join";
			iconButton4.Icon = LucideIconNames.Play;
			context.PopParent();
			((ISupportInitialize)iconButton3).EndInit();
			context.PopParent();
			((ISupportInitialize)grid3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<RobloxServersDialog> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<RobloxServersDialog> context = new XamlIlContext.Context<RobloxServersDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FRobloxServersDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/RobloxServersDialog.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (RobloxServersDialog)service;
				}
			}
			return context;
		}

		public static object Build_2(IServiceProvider P_0)
		{
			XamlIlContext.Context<RobloxServersDialog> context = CreateContext(P_0);
			context.IntermediateRoot = new WrapPanel();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((AvaloniaObject)obj).SetValue(WrapPanel.OrientationProperty, Orientation.Horizontal, BindingPriority.Template);
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static object Build_3(IServiceProvider P_0)
		{
			XamlIlContext.Context<RobloxServersDialog> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Border border = (Border)obj;
			context.PushParent(border);
			border.Width = 32.0;
			border.Height = 32.0;
			border.Margin = new Thickness(0.0, 0.0, 4.0, 0.0);
			border.ClipToBounds = true;
			border.CornerRadius = new CornerRadius(16.0, 16.0, 16.0, 16.0);
			Image image2;
			Image image = (image2 = new Image());
			((ISupportInitialize)image).BeginInit();
			border.Child = image;
			Image image4;
			Image image3 = (image4 = image2);
			context.PushParent(image4);
			StyledProperty<IImage?> sourceProperty = Image.SourceProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension();
			context.ProvideTargetProperty = Image.SourceProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			image4.Bind(sourceProperty, binding);
			image4.Stretch = Stretch.UniformToFill;
			RenderOptions.SetBitmapInterpolationMode(image4, BitmapInterpolationMode.LowQuality);
			context.PopParent();
			((ISupportInitialize)image3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal AvaloniaWindow RootDialog;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	protected override bool ApplyTopPadding => false;

	public RobloxServersDialog()
	{
		InitializeComponent();
	}

	public RobloxServersDialog(RobloxServersDialogViewModel viewModel)
		: this()
	{
		DataContext = viewModel;
	}

	private void OnCloseClicked(object? sender, RoutedEventArgs e)
	{
		Close();
	}

	private void OnHeaderPointerPressed(object? sender, PointerPressedEventArgs e)
	{
		if (e.GetCurrentPoint(this).Properties.IsLeftButtonPressed)
		{
			BeginMoveDrag(e);
		}
	}

	protected override void OnClosed(EventArgs e)
	{
		base.OnClosed(e);
		(DataContext as IDisposable)?.Dispose();
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		RootDialog = this.FindNameScope()?.Find<AvaloniaWindow>("RootDialog");
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, RobloxServersDialog P_1)
	{
		XamlIlContext.Context<RobloxServersDialog> context = new XamlIlContext.Context<RobloxServersDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FRobloxServersDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/RobloxServersDialog.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Name = "RootDialog";
		context.AvaloniaNameScope.Register("RootDialog", P_1);
		StyledProperty<string?> titleProperty = Window.TitleProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ERobloxServersDialogViewModel_002CMerostrap_002EGameName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			FallbackValue = "Servers"
		};
		context.ProvideTargetProperty = Window.TitleProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		P_1.Bind(titleProperty, binding);
		P_1.Width = 900.0;
		P_1.Height = 500.0;
		P_1.MinWidth = 650.0;
		P_1.WindowDecorations = WindowDecorations.None;
		P_1.MinHeight = 400.0;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterOwner;
		P_1.CanResize = true;
		P_1.ShowInTaskbar = false;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		P_1.Content = border;
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Border border5 = border4;
		StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("CardStrokeColorDefaultBrush");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding2 = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(borderBrushProperty, binding2);
		border5.Background = new ImmutableSolidColorBrush(16777215u);
		border5.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		border5.ClipToBounds = true;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		border5.Child = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid5.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid5.Children;
		Border border7;
		Border border6 = (border7 = new Border());
		((ISupportInitialize)border6).BeginInit();
		children.Add(border6);
		Border border8 = (border4 = border7);
		context.PushParent(border4);
		Border border9 = border4;
		Grid.SetRow(border9, 0);
		border9.Background = new ImmutableSolidColorBrush(855638016u);
		border9.Padding = new Thickness(16.0, 16.0, 16.0, 16.0);
		border9.AddHandler(InputElement.PointerPressedEvent, context.RootObject.OnHeaderPointerPressed);
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		border9.Child = grid6;
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 3;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid9.ColumnDefinitions = columnDefinitions;
		Avalonia.Controls.Controls children2 = grid9.Children;
		Border border11;
		Border border10 = (border11 = new Border());
		((ISupportInitialize)border10).BeginInit();
		children2.Add(border10);
		Border border12 = (border4 = border11);
		context.PushParent(border4);
		Border border13 = border4;
		border13.CornerRadius = new CornerRadius(8.0, 8.0, 8.0, 8.0);
		border13.ClipToBounds = true;
		border13.Width = 40.0;
		border13.Height = 40.0;
		RemoteImage remoteImage2;
		RemoteImage remoteImage = (remoteImage2 = new RemoteImage());
		((ISupportInitialize)remoteImage).BeginInit();
		border13.Child = remoteImage;
		RemoteImage remoteImage4;
		RemoteImage remoteImage3 = (remoteImage4 = remoteImage2);
		context.PushParent(remoteImage4);
		StyledProperty<string?> urlProperty = RemoteImage.UrlProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ERobloxServersDialogViewModel_002CMerostrap_002EGameThumbnailUrl_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = RemoteImage.UrlProperty;
		CompiledBinding binding3 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		remoteImage4.Bind(urlProperty, binding3);
		remoteImage4.Stretch = Stretch.UniformToFill;
		RenderOptions.SetBitmapInterpolationMode(remoteImage4, BitmapInterpolationMode.LowQuality);
		context.PopParent();
		((ISupportInitialize)remoteImage3).EndInit();
		context.PopParent();
		((ISupportInitialize)border12).EndInit();
		Avalonia.Controls.Controls children3 = grid9.Children;
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		children3.Add(stackPanel);
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		StackPanel stackPanel5 = stackPanel4;
		Grid.SetColumn(stackPanel5, 1);
		stackPanel5.Margin = new Thickness(12.0, 0.0, 12.0, 0.0);
		stackPanel5.VerticalAlignment = VerticalAlignment.Center;
		Avalonia.Controls.Controls children4 = stackPanel5.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children4.Add(textBlock);
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = textBlock2);
		context.PushParent(textBlock4);
		TextBlock textBlock5 = textBlock4;
		StyledProperty<string?> textProperty = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ERobloxServersDialogViewModel_002CMerostrap_002EGameName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding4 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock5.Bind(textProperty, binding4);
		textBlock5.FontWeight = FontWeight.Bold;
		textBlock5.FontSize = 16.0;
		textBlock5.TextTrimming = TextTrimming.CharacterEllipsis;
		context.PopParent();
		((ISupportInitialize)textBlock3).EndInit();
		Avalonia.Controls.Controls children5 = stackPanel5.Children;
		TextBlock textBlock7;
		TextBlock textBlock6 = (textBlock7 = new TextBlock());
		((ISupportInitialize)textBlock6).BeginInit();
		children5.Add(textBlock6);
		TextBlock textBlock8 = (textBlock4 = textBlock7);
		context.PushParent(textBlock4);
		TextBlock textBlock9 = textBlock4;
		textBlock9.Text = Strings.Menu_QuickPlay_SessionHistory;
		textBlock9.FontSize = 12.0;
		textBlock9.Opacity = 0.6;
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ERobloxServersDialogViewModel_002CMerostrap_002EIsCurrentGameApi_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding5 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock9.Bind(isVisibleProperty, binding5);
		context.PopParent();
		((ISupportInitialize)textBlock8).EndInit();
		Avalonia.Controls.Controls children6 = stackPanel5.Children;
		TextBlock textBlock11;
		TextBlock textBlock10 = (textBlock11 = new TextBlock());
		((ISupportInitialize)textBlock10).BeginInit();
		children6.Add(textBlock10);
		TextBlock textBlock12 = (textBlock4 = textBlock11);
		context.PushParent(textBlock4);
		TextBlock textBlock13 = textBlock4;
		textBlock13.Text = Strings.Menu_QuickPlay_RobloxServers;
		textBlock13.FontSize = 12.0;
		textBlock13.Opacity = 0.6;
		StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ERobloxServersDialogViewModel_002CMerostrap_002EIsCurrentGameApi_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding6 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock13.Bind(isVisibleProperty2, binding6);
		context.PopParent();
		((ISupportInitialize)textBlock12).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		Avalonia.Controls.Controls children7 = grid9.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children7.Add(button);
		Grid.SetColumn(button2, 2);
		button2.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.OnCloseClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button2.Background = new ImmutableSolidColorBrush(16777215u);
		button2.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		button2.Content = lucide;
		lucide2.Icon = LucideIconNames.X;
		lucide2.Height = 16.0;
		lucide2.Width = 16.0;
		((ISupportInitialize)lucide2).EndInit();
		((ISupportInitialize)button2).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		context.PopParent();
		((ISupportInitialize)border8).EndInit();
		Avalonia.Controls.Controls children8 = grid5.Children;
		Grid grid11;
		Grid grid10 = (grid11 = new Grid());
		((ISupportInitialize)grid10).BeginInit();
		children8.Add(grid10);
		Grid grid12 = (grid4 = grid11);
		context.PushParent(grid4);
		Grid grid13 = grid4;
		Grid.SetRow(grid13, 1);
		Avalonia.Controls.Controls children9 = grid13.Children;
		Grid grid15;
		Grid grid14 = (grid15 = new Grid());
		((ISupportInitialize)grid14).BeginInit();
		children9.Add(grid14);
		Grid grid16 = (grid4 = grid15);
		context.PushParent(grid4);
		Grid grid17 = grid4;
		StyledProperty<bool> isVisibleProperty3 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ERobloxServersDialogViewModel_002CMerostrap_002EIsLoading_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding7 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		grid17.Bind(isVisibleProperty3, binding7);
		grid17.Background = new ImmutableSolidColorBrush(1073741824u);
		grid17.ZIndex = 1;
		Avalonia.Controls.Controls children10 = grid17.Children;
		StackPanel stackPanel7;
		StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
		((ISupportInitialize)stackPanel6).BeginInit();
		children10.Add(stackPanel6);
		StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
		context.PushParent(stackPanel4);
		StackPanel stackPanel9 = stackPanel4;
		stackPanel9.Spacing = 16.0;
		stackPanel9.HorizontalAlignment = HorizontalAlignment.Center;
		stackPanel9.VerticalAlignment = VerticalAlignment.Center;
		Avalonia.Controls.Controls children11 = stackPanel9.Children;
		FAProgressRing fAProgressRing2;
		FAProgressRing fAProgressRing = (fAProgressRing2 = new FAProgressRing());
		((ISupportInitialize)fAProgressRing).BeginInit();
		children11.Add(fAProgressRing);
		FAProgressRing fAProgressRing4;
		FAProgressRing fAProgressRing3 = (fAProgressRing4 = fAProgressRing2);
		context.PushParent(fAProgressRing4);
		StyledProperty<bool> isActiveProperty = FAProgressRing.IsActiveProperty;
		CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ERobloxServersDialogViewModel_002CMerostrap_002EIsLoading_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = FAProgressRing.IsActiveProperty;
		CompiledBinding binding8 = compiledBindingExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		fAProgressRing4.Bind(isActiveProperty, binding8);
		fAProgressRing4.Width = 40.0;
		fAProgressRing4.Height = 40.0;
		StyledProperty<IBrush?> foregroundProperty = TemplatedControl.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("SystemAccentColor");
		context.ProvideTargetProperty = TemplatedControl.ForegroundProperty;
		BindingBase binding9 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		fAProgressRing4.Bind(foregroundProperty, binding9);
		context.PopParent();
		((ISupportInitialize)fAProgressRing3).EndInit();
		Avalonia.Controls.Controls children12 = stackPanel9.Children;
		TextBlock textBlock15;
		TextBlock textBlock14 = (textBlock15 = new TextBlock());
		((ISupportInitialize)textBlock14).BeginInit();
		children12.Add(textBlock14);
		textBlock15.Text = Strings.Menu_QuickPlay_LoadingServers;
		textBlock15.FontSize = 12.0;
		textBlock15.Opacity = 0.7;
		((ISupportInitialize)textBlock15).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel8).EndInit();
		context.PopParent();
		((ISupportInitialize)grid16).EndInit();
		Avalonia.Controls.Controls children13 = grid13.Children;
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		children13.Add(scrollViewer);
		ScrollViewer scrollViewer4;
		ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
		context.PushParent(scrollViewer4);
		StyledProperty<bool> isVisibleProperty4 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ERobloxServersDialogViewModel_002CMerostrap_002EIsLoading_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding10 = compiledBindingExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		scrollViewer4.Bind(isVisibleProperty4, binding10);
		scrollViewer4.Background = new ImmutableSolidColorBrush(16777215u);
		scrollViewer4.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
		scrollViewer4.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
		ItemsControl itemsControl2;
		ItemsControl itemsControl = (itemsControl2 = new ItemsControl());
		((ISupportInitialize)itemsControl).BeginInit();
		scrollViewer4.Content = itemsControl;
		ItemsControl itemsControl4;
		ItemsControl itemsControl3 = (itemsControl4 = itemsControl2);
		context.PushParent(itemsControl4);
		StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ERobloxServersDialogViewModel_002CMerostrap_002EServers_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding11 = compiledBindingExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		itemsControl4.Bind(itemsSourceProperty, binding11);
		itemsControl4.Padding = new Thickness(10.0, 10.0, 10.0, 10.0);
		DataTemplate dataTemplate;
		DataTemplate itemTemplate = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.DataType = typeof(ServerInfo);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_23.Build_1), context);
		context.PopParent();
		itemsControl4.ItemTemplate = itemTemplate;
		context.PopParent();
		((ISupportInitialize)itemsControl3).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid12).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(RobloxServersDialog P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
