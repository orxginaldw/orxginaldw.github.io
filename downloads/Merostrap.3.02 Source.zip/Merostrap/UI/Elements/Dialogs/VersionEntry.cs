using System;
using System.ComponentModel;

namespace Merostrap.UI.Elements.Dialogs;

internal class VersionEntry : INotifyPropertyChanged
{
	private string _hash = string.Empty;

	private string _version = string.Empty;

	private string _date = string.Empty;

	private DateTime _releaseDateUtc;

	public string Hash
	{
		get
		{
			return _hash;
		}
		set
		{
			_hash = value;
			OnPropertyChanged("Hash");
		}
	}

	public string Version
	{
		get
		{
			return _version;
		}
		set
		{
			_version = value;
			OnPropertyChanged("Version");
		}
	}

	public string Date
	{
		get
		{
			return _date;
		}
		set
		{
			_date = value;
			OnPropertyChanged("Date");
		}
	}

	public DateTime ReleaseDateUtc
	{
		get
		{
			return _releaseDateUtc;
		}
		set
		{
			_releaseDateUtc = value;
			OnPropertyChanged("ReleaseDateUtc");
		}
	}

	public event PropertyChangedEventHandler? PropertyChanged;

	protected void OnPropertyChanged(string name)
	{
		PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
	}
}
