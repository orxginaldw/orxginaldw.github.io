using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Documents;
using Avalonia.Controls.Shapes;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using CompiledAvaloniaXaml;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.Resources;
using Merostrap.UI.Elements.Base;
using Merostrap.UI.ViewModels.Dialogs;

namespace Merostrap.UI.Elements.Dialogs;

internal class ManualCookieDialog : AvaloniaWindow
{
	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBox CookieTextBox;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button AddButton;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public ManualCookieDialogViewModel ViewModel { get; }

	public ManualCookieDialog()
	{
		ViewModel = new ManualCookieDialogViewModel(this);
		DataContext = ViewModel;
		InitializeComponent();
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		CookieTextBox = nameScope?.Find<TextBox>("CookieTextBox");
		AddButton = nameScope?.Find<Button>("AddButton");
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, ManualCookieDialog P_1)
	{
		XamlIlContext.Context<ManualCookieDialog> context = new XamlIlContext.Context<ManualCookieDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FManualCookieDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/ManualCookieDialog.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Width = 500.0;
		P_1.Height = 475.0;
		P_1.CanResize = true;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterOwner;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid5.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid5.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children.Add(grid6);
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		Grid.SetRow(grid9, 0);
		grid9.Margin = new Thickness(20.0, 8.0, 20.0, 16.0);
		RowDefinitions rowDefinitions2 = new RowDefinitions();
		rowDefinitions2.Capacity = 4;
		rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid9.RowDefinitions = rowDefinitions2;
		Avalonia.Controls.Controls children2 = grid9.Children;
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		children2.Add(stackPanel);
		Grid.SetRow(stackPanel2, 0);
		stackPanel2.Margin = new Thickness(0.0, 0.0, 0.0, 16.0);
		stackPanel2.Orientation = Orientation.Horizontal;
		Avalonia.Controls.Controls children3 = stackPanel2.Children;
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		children3.Add(lucide);
		lucide2.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
		lucide2.FontSize = 20.0;
		lucide2.Icon = LucideIconNames.Link2;
		((ISupportInitialize)lucide2).EndInit();
		Avalonia.Controls.Controls children4 = stackPanel2.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children4.Add(textBlock);
		textBlock2.FontSize = 18.0;
		textBlock2.FontWeight = FontWeight.DemiBold;
		textBlock2.Text = Strings.Menu_ManualLogin_Title;
		((ISupportInitialize)textBlock2).EndInit();
		((ISupportInitialize)stackPanel2).EndInit();
		Avalonia.Controls.Controls children5 = grid9.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children5.Add(border);
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Border border5 = border4;
		Grid.SetRow(border5, 2);
		border5.Margin = new Thickness(0.0, 0.0, 0.0, 12.0);
		border5.Padding = new Thickness(16.0, 12.0, 16.0, 12.0);
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(backgroundProperty, binding);
		StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("ControlElevationBorderBrush");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(borderBrushProperty, binding2);
		border5.BorderThickness = new Thickness(0.0, 1.0, 0.0, 0.0);
		border5.CornerRadius = new CornerRadius(6.0, 6.0, 6.0, 6.0);
		Grid grid11;
		Grid grid10 = (grid11 = new Grid());
		((ISupportInitialize)grid10).BeginInit();
		border5.Child = grid10;
		Grid grid12 = (grid4 = grid11);
		context.PushParent(grid4);
		Grid grid13 = grid4;
		RowDefinitions rowDefinitions3 = new RowDefinitions();
		rowDefinitions3.Capacity = 2;
		rowDefinitions3.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions3.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid13.RowDefinitions = rowDefinitions3;
		Avalonia.Controls.Controls children6 = grid13.Children;
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		children6.Add(textBlock3);
		Grid.SetRow(textBlock4, 0);
		textBlock4.Margin = new Thickness(0.0, 0.0, 0.0, 8.0);
		textBlock4.FontSize = 13.0;
		textBlock4.FontWeight = FontWeight.DemiBold;
		textBlock4.Text = Strings.Menu_ManualLogin_PasteSecurity;
		((ISupportInitialize)textBlock4).EndInit();
		Avalonia.Controls.Controls children7 = grid13.Children;
		TextBox textBox2;
		TextBox textBox = (textBox2 = new TextBox());
		((ISupportInitialize)textBox).BeginInit();
		children7.Add(textBox);
		TextBox textBox4;
		TextBox textBox3 = (textBox4 = textBox2);
		context.PushParent(textBox4);
		textBox4.Name = "CookieTextBox";
		object element = textBox4;
		context.AvaloniaNameScope.Register("CookieTextBox", element);
		Grid.SetRow(textBox4, 1);
		textBox4.Height = 65.0;
		textBox4.AcceptsReturn = true;
		textBox4.TextWrapping = TextWrapping.Wrap;
		StyledProperty<string?> textProperty = TextBox.TextProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EManualCookieDialogViewModel_002CMerostrap_002ECookieInput_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
		};
		context.ProvideTargetProperty = TextBox.TextProperty;
		CompiledBinding binding3 = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBox4.Bind(textProperty, binding3);
		textBox4.FontFamily = new FontFamily(((IUriContext)context).BaseUri, "Consolas");
		textBox4.FontSize = 12.0;
		context.PopParent();
		((ISupportInitialize)textBox3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid12).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		Avalonia.Controls.Controls children8 = grid9.Children;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = new StackPanel());
		((ISupportInitialize)stackPanel3).BeginInit();
		children8.Add(stackPanel3);
		Grid.SetRow(stackPanel4, 3);
		stackPanel4.Margin = new Thickness(8.0, 0.0, 0.0, 0.0);
		Avalonia.Controls.Controls children9 = stackPanel4.Children;
		TextBlock textBlock6;
		TextBlock textBlock5 = (textBlock6 = new TextBlock());
		((ISupportInitialize)textBlock5).BeginInit();
		children9.Add(textBlock5);
		textBlock6.Margin = new Thickness(0.0, 2.0, 0.0, 2.0);
		InlineCollection? inlines = textBlock6.Inlines;
		Run run = new Run();
		((ISupportInitialize)run).BeginInit();
		run.Text = "1.";
		run.FontWeight = FontWeight.Bold;
		((ISupportInitialize)run).EndInit();
		inlines.Add(run);
		textBlock6.Inlines.Add(" ");
		InlineCollection? inlines2 = textBlock6.Inlines;
		Run run2 = new Run();
		((ISupportInitialize)run2).BeginInit();
		run2.Text = Strings.Menu_ManualLogin_Instruction_1;
		((ISupportInitialize)run2).EndInit();
		inlines2.Add(run2);
		((ISupportInitialize)textBlock6).EndInit();
		Avalonia.Controls.Controls children10 = stackPanel4.Children;
		TextBlock textBlock8;
		TextBlock textBlock7 = (textBlock8 = new TextBlock());
		((ISupportInitialize)textBlock7).BeginInit();
		children10.Add(textBlock7);
		textBlock8.Margin = new Thickness(0.0, 2.0, 0.0, 2.0);
		InlineCollection? inlines3 = textBlock8.Inlines;
		Run run3 = new Run();
		((ISupportInitialize)run3).BeginInit();
		run3.Text = "2.";
		run3.FontWeight = FontWeight.Bold;
		((ISupportInitialize)run3).EndInit();
		inlines3.Add(run3);
		textBlock8.Inlines.Add(" ");
		InlineCollection? inlines4 = textBlock8.Inlines;
		Run run4 = new Run();
		((ISupportInitialize)run4).BeginInit();
		run4.Text = Strings.Menu_ManualLogin_Instruction_2;
		((ISupportInitialize)run4).EndInit();
		inlines4.Add(run4);
		((ISupportInitialize)textBlock8).EndInit();
		Avalonia.Controls.Controls children11 = stackPanel4.Children;
		TextBlock textBlock10;
		TextBlock textBlock9 = (textBlock10 = new TextBlock());
		((ISupportInitialize)textBlock9).BeginInit();
		children11.Add(textBlock9);
		textBlock10.Margin = new Thickness(0.0, 2.0, 0.0, 2.0);
		InlineCollection? inlines5 = textBlock10.Inlines;
		Run run5 = new Run();
		((ISupportInitialize)run5).BeginInit();
		run5.Text = "3.";
		run5.FontWeight = FontWeight.Bold;
		((ISupportInitialize)run5).EndInit();
		inlines5.Add(run5);
		textBlock10.Inlines.Add(" ");
		InlineCollection? inlines6 = textBlock10.Inlines;
		Run run6 = new Run();
		((ISupportInitialize)run6).BeginInit();
		run6.Text = Strings.Menu_ManualLogin_Instruction_3;
		((ISupportInitialize)run6).EndInit();
		inlines6.Add(run6);
		((ISupportInitialize)textBlock10).EndInit();
		Avalonia.Controls.Controls children12 = stackPanel4.Children;
		TextBlock textBlock12;
		TextBlock textBlock11 = (textBlock12 = new TextBlock());
		((ISupportInitialize)textBlock11).BeginInit();
		children12.Add(textBlock11);
		textBlock12.Margin = new Thickness(0.0, 2.0, 0.0, 2.0);
		InlineCollection? inlines7 = textBlock12.Inlines;
		Run run7 = new Run();
		((ISupportInitialize)run7).BeginInit();
		run7.Text = "4.";
		run7.FontWeight = FontWeight.Bold;
		((ISupportInitialize)run7).EndInit();
		inlines7.Add(run7);
		textBlock12.Inlines.Add(" ");
		InlineCollection? inlines8 = textBlock12.Inlines;
		Run run8 = new Run();
		((ISupportInitialize)run8).BeginInit();
		run8.Text = Strings.Menu_ManualLogin_Instruction_4;
		((ISupportInitialize)run8).EndInit();
		inlines8.Add(run8);
		((ISupportInitialize)textBlock12).EndInit();
		Avalonia.Controls.Controls children13 = stackPanel4.Children;
		TextBlock textBlock14;
		TextBlock textBlock13 = (textBlock14 = new TextBlock());
		((ISupportInitialize)textBlock13).BeginInit();
		children13.Add(textBlock13);
		textBlock14.Margin = new Thickness(0.0, 2.0, 0.0, 2.0);
		InlineCollection? inlines9 = textBlock14.Inlines;
		Run run9 = new Run();
		((ISupportInitialize)run9).BeginInit();
		run9.Text = "5.";
		run9.FontWeight = FontWeight.Bold;
		((ISupportInitialize)run9).EndInit();
		inlines9.Add(run9);
		textBlock14.Inlines.Add(" ");
		InlineCollection? inlines10 = textBlock14.Inlines;
		Run run10 = new Run();
		((ISupportInitialize)run10).BeginInit();
		run10.Text = Strings.Menu_ManualLogin_Instruction_5;
		((ISupportInitialize)run10).EndInit();
		inlines10.Add(run10);
		((ISupportInitialize)textBlock14).EndInit();
		Avalonia.Controls.Controls children14 = stackPanel4.Children;
		TextBlock textBlock16;
		TextBlock textBlock15 = (textBlock16 = new TextBlock());
		((ISupportInitialize)textBlock15).BeginInit();
		children14.Add(textBlock15);
		textBlock16.Margin = new Thickness(0.0, 2.0, 0.0, 2.0);
		InlineCollection? inlines11 = textBlock16.Inlines;
		Run run11 = new Run();
		((ISupportInitialize)run11).BeginInit();
		run11.Text = "6.";
		run11.FontWeight = FontWeight.Bold;
		((ISupportInitialize)run11).EndInit();
		inlines11.Add(run11);
		textBlock16.Inlines.Add(" ");
		InlineCollection? inlines12 = textBlock16.Inlines;
		Run run12 = new Run();
		((ISupportInitialize)run12).BeginInit();
		run12.Text = Strings.Menu_ManualLogin_Instruction_6;
		((ISupportInitialize)run12).EndInit();
		inlines12.Add(run12);
		((ISupportInitialize)textBlock16).EndInit();
		Avalonia.Controls.Controls children15 = stackPanel4.Children;
		TextBlock textBlock18;
		TextBlock textBlock17 = (textBlock18 = new TextBlock());
		((ISupportInitialize)textBlock17).BeginInit();
		children15.Add(textBlock17);
		textBlock18.Margin = new Thickness(0.0, 2.0, 0.0, 2.0);
		InlineCollection? inlines13 = textBlock18.Inlines;
		Run run13 = new Run();
		((ISupportInitialize)run13).BeginInit();
		run13.Text = "7.";
		run13.FontWeight = FontWeight.Bold;
		((ISupportInitialize)run13).EndInit();
		inlines13.Add(run13);
		textBlock18.Inlines.Add(" ");
		InlineCollection? inlines14 = textBlock18.Inlines;
		Run run14 = new Run();
		((ISupportInitialize)run14).BeginInit();
		run14.Text = Strings.Menu_ManualLogin_Instruction_7;
		((ISupportInitialize)run14).EndInit();
		inlines14.Add(run14);
		((ISupportInitialize)textBlock18).EndInit();
		((ISupportInitialize)stackPanel4).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		Avalonia.Controls.Controls children16 = grid5.Children;
		Border border7;
		Border border6 = (border7 = new Border());
		((ISupportInitialize)border6).BeginInit();
		children16.Add(border6);
		Border border8 = (border4 = border7);
		context.PushParent(border4);
		Border border9 = border4;
		Grid.SetRow(border9, 1);
		StyledProperty<IBrush?> backgroundProperty2 = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding4 = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border9.Bind(backgroundProperty2, binding4);
		StyledProperty<IBrush?> borderBrushProperty2 = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("ControlElevationBorderBrush");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding5 = dynamicResourceExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border9.Bind(borderBrushProperty2, binding5);
		border9.BorderThickness = new Thickness(0.0, 1.0, 0.0, 0.0);
		Grid grid15;
		Grid grid14 = (grid15 = new Grid());
		((ISupportInitialize)grid14).BeginInit();
		border9.Child = grid14;
		Grid grid16 = (grid4 = grid15);
		context.PushParent(grid4);
		Grid grid17 = grid4;
		grid17.Margin = new Thickness(20.0, 16.0, 20.0, 16.0);
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 3;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid17.ColumnDefinitions = columnDefinitions;
		Avalonia.Controls.Controls children17 = grid17.Children;
		Rectangle rectangle2;
		Rectangle rectangle = (rectangle2 = new Rectangle());
		((ISupportInitialize)rectangle).BeginInit();
		children17.Add(rectangle);
		Grid.SetColumn(rectangle2, 0);
		rectangle2.Fill = new ImmutableSolidColorBrush(16777215u);
		((ISupportInitialize)rectangle2).EndInit();
		Avalonia.Controls.Controls children18 = grid17.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children18.Add(button);
		Button button4;
		Button button3 = (button4 = button2);
		context.PushParent(button4);
		Button button5 = button4;
		button5.Name = "AddButton";
		element = button5;
		context.AvaloniaNameScope.Register("AddButton", element);
		Grid.SetColumn(button5, 1);
		button5.MinWidth = 100.0;
		button5.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
		button5.HorizontalAlignment = HorizontalAlignment.Right;
		StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EManualCookieDialogViewModel_002CMerostrap_002EAddAccountCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding6 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button5.Bind(commandProperty, binding6);
		button5.Content = Strings.Common_Add;
		StyledProperty<bool> isEnabledProperty = InputElement.IsEnabledProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EManualCookieDialogViewModel_002CMerostrap_002EIsAddEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = InputElement.IsEnabledProperty;
		CompiledBinding binding7 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button5.Bind(isEnabledProperty, binding7);
		context.PopParent();
		((ISupportInitialize)button3).EndInit();
		Avalonia.Controls.Controls children19 = grid17.Children;
		Button button7;
		Button button6 = (button7 = new Button());
		((ISupportInitialize)button6).BeginInit();
		children19.Add(button6);
		Button button8 = (button4 = button7);
		context.PushParent(button4);
		Button button9 = button4;
		Grid.SetColumn(button9, 2);
		button9.MinWidth = 100.0;
		button9.HorizontalAlignment = HorizontalAlignment.Right;
		StyledProperty<ICommand?> commandProperty2 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EManualCookieDialogViewModel_002CMerostrap_002ECancelCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding8 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button9.Bind(commandProperty2, binding8);
		button9.Content = Strings.Common_Cancel;
		context.PopParent();
		((ISupportInitialize)button8).EndInit();
		context.PopParent();
		((ISupportInitialize)grid16).EndInit();
		context.PopParent();
		((ISupportInitialize)border8).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(ManualCookieDialog P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
