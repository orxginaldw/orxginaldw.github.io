using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Text;
using System.Web;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Input.Platform;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.Converters;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using CompiledAvaloniaXaml;
using Merostrap.Resources;
using Merostrap.UI.Elements.Base;
using Merostrap.UI.Elements.Controls;
using Merostrap.Utility;

namespace Merostrap.UI.Elements.Dialogs;

internal class ExceptionDialog : AvaloniaWindow
{
	private const int MAX_GITHUB_URL_LENGTH = 8192;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBox ErrorTextBox;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal MarkdownTextBlock HelpMessageMarkdown;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBlock VersionText;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button CopyLogButton;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button ReportExceptionButton;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button LocateLogFileButton;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public ExceptionDialog()
	{
		InitializeComponent();
	}

	public ExceptionDialog(Exception exception)
		: this()
	{
		App.FrostRPC?.SetDialog("Exception");
		AddException(exception);
		if (!Logging.Initialized)
		{
			LocateLogFileButton.Content = Strings.Dialog_Exception_CopyLogContents;
		}
		string text = "https://github.com/";
		string arg = text + "/wiki";
		string text2 = HttpUtility.UrlEncode($"[BUG] {exception.GetType()}: {exception.Message}");
		string value = HttpUtility.UrlEncode(Logging.AsDocument);
		string issueUrl = $"{text}/issues/new?template=bug_report.yaml&title={text2}&log={value}";
		if (issueUrl.Length > 8192)
		{
			issueUrl = text + "/issues/new?template=bug_report.yaml&title=" + text2;
			if (issueUrl.Length > 8192)
			{
				issueUrl = text + "/issues/new?template=bug_report.yaml";
			}
		}
		string text3 = string.Format(CultureInfo.InvariantCulture, Strings.Dialog_Exception_Info_2, arg, issueUrl);
		if (!App.IsActionBuild)
		{
			text3 = string.Format(CultureInfo.InvariantCulture, Strings.Dialog_Exception_Info_2_Alt, arg);
		}
		HelpMessageMarkdown.MarkdownText = (string.IsNullOrEmpty("") ? "Open or copy the log file to inspect this error." : text3);
		ReportExceptionButton.IsVisible = !string.IsNullOrEmpty("");
		VersionText.Text = string.Format(CultureInfo.InvariantCulture, Strings.Menu_About_Version, App.Version);
		ReportExceptionButton.Click += (object? _, RoutedEventArgs _) =>
		{
			Threading.ShellExecute(issueUrl);
		};
		LocateLogFileButton.Click += async delegate
		{
			if (Logging.Initialized && !string.IsNullOrEmpty(Logging.FileLocation))
			{
				Threading.ShellExecute(Logging.FileLocation);
			}
			else
			{
				TopLevel topLevel = TopLevel.GetTopLevel(this);
				if (topLevel?.Clipboard != null)
				{
					await topLevel.Clipboard.SetTextAsync(Logging.AsDocument);
				}
			}
		};
		CopyLogButton.Click += async delegate
		{
			TopLevel topLevel = TopLevel.GetTopLevel(this);
			if (topLevel?.Clipboard != null)
			{
				await topLevel.Clipboard.SetTextAsync(Logging.AsDocument);
			}
		};
		Loaded += (object? _, RoutedEventArgs _) =>
		{
			Activate();
			Topmost = true;
			Topmost = false;
		};
	}

	private void AddException(Exception exception, bool inner = false)
	{
		StringBuilder stringBuilder = new StringBuilder();
		if (!inner)
		{
			StringBuilder stringBuilder2 = stringBuilder;
			StringBuilder stringBuilder3 = stringBuilder2;
			IFormatProvider invariantCulture = CultureInfo.InvariantCulture;
			IFormatProvider provider = invariantCulture;
			StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(2, 2, stringBuilder2, invariantCulture);
			handler.AppendFormatted(exception.GetType());
			handler.AppendLiteral(": ");
			handler.AppendFormatted(exception.Message);
			stringBuilder3.AppendLine(provider, ref handler);
		}
		else
		{
			StringBuilder stringBuilder2 = stringBuilder;
			StringBuilder stringBuilder4 = stringBuilder2;
			IFormatProvider invariantCulture = CultureInfo.InvariantCulture;
			IFormatProvider provider2 = invariantCulture;
			StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(20, 2, stringBuilder2, invariantCulture);
			handler.AppendLiteral("[Inner Exception]\n");
			handler.AppendFormatted(exception.GetType());
			handler.AppendLiteral(": ");
			handler.AppendFormatted(exception.Message);
			stringBuilder4.AppendLine(provider2, ref handler);
		}
		if (exception.StackTrace != null)
		{
			StringBuilder stringBuilder2 = stringBuilder;
			StringBuilder stringBuilder5 = stringBuilder2;
			IFormatProvider invariantCulture = CultureInfo.InvariantCulture;
			IFormatProvider provider3 = invariantCulture;
			StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(14, 1, stringBuilder2, invariantCulture);
			handler.AppendLiteral("\nStack Trace:\n");
			handler.AppendFormatted(exception.StackTrace);
			stringBuilder5.AppendLine(provider3, ref handler);
		}
		if (exception.InnerException != null)
		{
			stringBuilder.AppendLine();
			AddExceptionToBuilder(exception.InnerException, stringBuilder, inner: true);
		}
		ErrorTextBox.Text = stringBuilder.ToString();
	}

	private static void AddExceptionToBuilder(Exception exception, StringBuilder sb, bool inner = false)
	{
		if (inner)
		{
			StringBuilder stringBuilder = sb;
			StringBuilder stringBuilder2 = stringBuilder;
			IFormatProvider invariantCulture = CultureInfo.InvariantCulture;
			IFormatProvider provider = invariantCulture;
			StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(20, 2, stringBuilder, invariantCulture);
			handler.AppendLiteral("[Inner Exception]\n");
			handler.AppendFormatted(exception.GetType());
			handler.AppendLiteral(": ");
			handler.AppendFormatted(exception.Message);
			stringBuilder2.AppendLine(provider, ref handler);
		}
		else
		{
			StringBuilder stringBuilder = sb;
			StringBuilder stringBuilder3 = stringBuilder;
			IFormatProvider invariantCulture = CultureInfo.InvariantCulture;
			IFormatProvider provider2 = invariantCulture;
			StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(2, 2, stringBuilder, invariantCulture);
			handler.AppendFormatted(exception.GetType());
			handler.AppendLiteral(": ");
			handler.AppendFormatted(exception.Message);
			stringBuilder3.AppendLine(provider2, ref handler);
		}
		if (exception.StackTrace != null)
		{
			StringBuilder stringBuilder = sb;
			StringBuilder stringBuilder4 = stringBuilder;
			IFormatProvider invariantCulture = CultureInfo.InvariantCulture;
			IFormatProvider provider3 = invariantCulture;
			StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(14, 1, stringBuilder, invariantCulture);
			handler.AppendLiteral("\nStack Trace:\n");
			handler.AppendFormatted(exception.StackTrace);
			stringBuilder4.AppendLine(provider3, ref handler);
		}
		if (exception.InnerException != null)
		{
			sb.AppendLine();
			AddExceptionToBuilder(exception.InnerException, sb, inner: true);
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		ErrorTextBox = nameScope?.Find<TextBox>("ErrorTextBox");
		HelpMessageMarkdown = nameScope?.Find<MarkdownTextBlock>("HelpMessageMarkdown");
		VersionText = nameScope?.Find<TextBlock>("VersionText");
		CopyLogButton = nameScope?.Find<Button>("CopyLogButton");
		ReportExceptionButton = nameScope?.Find<Button>("ReportExceptionButton");
		LocateLogFileButton = nameScope?.Find<Button>("LocateLogFileButton");
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, ExceptionDialog P_1)
	{
		XamlIlContext.Context<ExceptionDialog> context = new XamlIlContext.Context<ExceptionDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FExceptionDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/ExceptionDialog.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Title = Strings.Dialog_Exception_Title;
		P_1.Width = 600.0;
		P_1.SizeToContent = SizeToContent.Height;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid5.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid5.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children.Add(grid6);
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		Grid.SetRow(grid9, 0);
		grid9.Margin = new Thickness(16.0, 16.0, 16.0, 16.0);
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 2;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid9.ColumnDefinitions = columnDefinitions;
		Avalonia.Controls.Controls children2 = grid9.Children;
		Image image2;
		Image image = (image2 = new Image());
		((ISupportInitialize)image).BeginInit();
		children2.Add(image);
		Image image4;
		Image image3 = (image4 = image2);
		context.PushParent(image4);
		Grid.SetColumn(image4, 0);
		image4.Width = 32.0;
		image4.Height = 32.0;
		image4.Margin = new Thickness(0.0, 0.0, 15.0, 0.0);
		image4.VerticalAlignment = VerticalAlignment.Top;
		image4.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "avares://Merostrap/Resources/MessageBox/Error.png");
		RenderOptions.SetBitmapInterpolationMode(image4, BitmapInterpolationMode.HighQuality);
		context.PopParent();
		((ISupportInitialize)image3).EndInit();
		Avalonia.Controls.Controls children3 = grid9.Children;
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		children3.Add(stackPanel);
		Grid.SetColumn(stackPanel2, 1);
		Avalonia.Controls.Controls children4 = stackPanel2.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children4.Add(textBlock);
		textBlock2.Text = Strings.Dialog_Exception_Info_1;
		textBlock2.FontSize = 18.0;
		textBlock2.TextWrapping = TextWrapping.Wrap;
		((ISupportInitialize)textBlock2).EndInit();
		Avalonia.Controls.Controls children5 = stackPanel2.Children;
		TextBox textBox2;
		TextBox textBox = (textBox2 = new TextBox());
		((ISupportInitialize)textBox).BeginInit();
		children5.Add(textBox);
		textBox2.Name = "ErrorTextBox";
		object element = textBox2;
		context.AvaloniaNameScope.Register("ErrorTextBox", element);
		textBox2.Padding = new Thickness(8.0, 8.0, 8.0, 8.0);
		textBox2.Margin = new Thickness(0.0, 16.0, 0.0, 0.0);
		textBox2.FontFamily = new FontFamily(((IUriContext)context).BaseUri, "Courier New");
		textBox2.IsReadOnly = true;
		textBox2.AcceptsReturn = true;
		textBox2.TextWrapping = TextWrapping.Wrap;
		ScrollViewer.SetVerticalScrollBarVisibility(textBox2, ScrollBarVisibility.Auto);
		textBox2.Height = 150.0;
		((ISupportInitialize)textBox2).EndInit();
		Avalonia.Controls.Controls children6 = stackPanel2.Children;
		MarkdownTextBlock markdownTextBlock2;
		MarkdownTextBlock markdownTextBlock = (markdownTextBlock2 = new MarkdownTextBlock());
		((ISupportInitialize)markdownTextBlock).BeginInit();
		children6.Add(markdownTextBlock);
		markdownTextBlock2.Name = "HelpMessageMarkdown";
		element = markdownTextBlock2;
		context.AvaloniaNameScope.Register("HelpMessageMarkdown", element);
		markdownTextBlock2.Margin = new Thickness(0.0, 16.0, 0.0, 0.0);
		markdownTextBlock2.TextWrapping = TextWrapping.Wrap;
		((ISupportInitialize)markdownTextBlock2).EndInit();
		((ISupportInitialize)stackPanel2).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		Avalonia.Controls.Controls children7 = grid5.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children7.Add(border);
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Grid.SetRow(border4, 1);
		border4.Padding = new Thickness(15.0, 15.0, 15.0, 15.0);
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border4.Bind(backgroundProperty, binding);
		Grid grid11;
		Grid grid10 = (grid11 = new Grid());
		((ISupportInitialize)grid10).BeginInit();
		border4.Child = grid10;
		Grid grid12 = (grid4 = grid11);
		context.PushParent(grid4);
		Grid grid13 = grid4;
		Avalonia.Controls.Controls children8 = grid13.Children;
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		children8.Add(textBlock3);
		TextBlock textBlock6;
		TextBlock textBlock5 = (textBlock6 = textBlock4);
		context.PushParent(textBlock6);
		textBlock6.Name = "VersionText";
		element = textBlock6;
		context.AvaloniaNameScope.Register("VersionText", element);
		textBlock6.VerticalAlignment = VerticalAlignment.Center;
		textBlock6.HorizontalAlignment = HorizontalAlignment.Left;
		StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("TextFillColorTertiaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock6.Bind(foregroundProperty, binding2);
		textBlock6.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
		context.PopParent();
		((ISupportInitialize)textBlock5).EndInit();
		Avalonia.Controls.Controls children9 = grid13.Children;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = new StackPanel());
		((ISupportInitialize)stackPanel3).BeginInit();
		children9.Add(stackPanel3);
		stackPanel4.Orientation = Orientation.Horizontal;
		stackPanel4.HorizontalAlignment = HorizontalAlignment.Right;
		Avalonia.Controls.Controls children10 = stackPanel4.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children10.Add(button);
		button2.Name = "CopyLogButton";
		element = button2;
		context.AvaloniaNameScope.Register("CopyLogButton", element);
		button2.Content = Strings.Dialog_Exception_CopyLog;
		((ISupportInitialize)button2).EndInit();
		Avalonia.Controls.Controls children11 = stackPanel4.Children;
		Button button4;
		Button button3 = (button4 = new Button());
		((ISupportInitialize)button3).BeginInit();
		children11.Add(button3);
		button4.Name = "ReportExceptionButton";
		element = button4;
		context.AvaloniaNameScope.Register("ReportExceptionButton", element);
		button4.Content = Strings.Dialog_Exception_Report;
		button4.Margin = new Thickness(6.0, 0.0, 0.0, 0.0);
		((ISupportInitialize)button4).EndInit();
		Avalonia.Controls.Controls children12 = stackPanel4.Children;
		Button button6;
		Button button5 = (button6 = new Button());
		((ISupportInitialize)button5).BeginInit();
		children12.Add(button5);
		button6.Name = "LocateLogFileButton";
		element = button6;
		context.AvaloniaNameScope.Register("LocateLogFileButton", element);
		button6.Content = Strings.Common_OpenLogFile;
		button6.Margin = new Thickness(6.0, 0.0, 0.0, 0.0);
		((ISupportInitialize)button6).EndInit();
		((ISupportInitialize)stackPanel4).EndInit();
		context.PopParent();
		((ISupportInitialize)grid12).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(ExceptionDialog P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
