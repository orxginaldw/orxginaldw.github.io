using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Controls.Shapes;
using Avalonia.Data;
using Avalonia.Data.Converters;
using Avalonia.Input.Platform;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using Avalonia.Threading;
using CompiledAvaloniaXaml;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.Resources;
using Merostrap.UI.Elements.Base;
using Merostrap.UI.Elements.Controls;

namespace Merostrap.UI.Elements.Dialogs;

internal class QuickSignCodeDialog : AvaloniaWindow
{
	private DispatcherTimer? _autoCloseTimer;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal MarkdownTextBlock InstructionsText;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Border CodeBox;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBox CodeTextBox;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBlock StatusText;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public bool SignInSuccessful { get; private set; }

	public QuickSignCodeDialog()
	{
		InitializeComponent();
		SignInSuccessful = false;
		StatusText.Text = Strings.Menu_QuickSignIn_Waitting;
	}

	public void StartNewSignIn(string code)
	{
		SignInSuccessful = false;
		_autoCloseTimer?.Stop();
		_autoCloseTimer = null;
		CodeTextBox.Text = code ?? string.Empty;
		CodeBox.IsVisible = true;
		StatusText.Text = Strings.Menu_QuickSignIn_Waitting;
		if (!IsVisible)
		{
			Show();
		}
		Activate();
		Focus();
	}

	public void CompleteSignIn()
	{
		SignInSuccessful = true;
		StatusText.Text = Strings.Menu_QuickSignIn_Complete;
		_autoCloseTimer = new DispatcherTimer
		{
			Interval = TimeSpan.FromSeconds(1.5)
		};
		_autoCloseTimer.Tick += (object? s, EventArgs e) =>
		{
			_autoCloseTimer?.Stop();
			Close();
		};
		_autoCloseTimer.Start();
	}

	private async void Copy_Click(object? sender, RoutedEventArgs e)
	{
		try
		{
			IClipboard clipboard = TopLevel.GetTopLevel(this)?.Clipboard;
			if (clipboard == null)
			{
				return;
			}
			await clipboard.SetTextAsync(CodeTextBox.Text);
			Task.Delay(2000).ContinueWith((Task _) =>
			{
				Avalonia.Threading.Dispatcher.UIThread.Post(() =>
				{
					StatusText.Text = Strings.Menu_QuickSignIn_Waitting;
				});
			}, TaskScheduler.Default);
		}
		catch
		{
		}
	}

	private void Close_Click(object? sender, RoutedEventArgs e)
	{
		Close();
	}

	public void UpdateStatus(string status, string? accountName = null)
	{
		Avalonia.Threading.Dispatcher.UIThread.InvokeAsync(() =>
		{
			switch (status)
			{
			case "Validated":
				CompleteSignIn();
				break;
			case "Cancelled":
				StatusText.Text = Strings.Menu_QuickSignIn_Cancelled;
				break;
			case "TimedOut":
				StatusText.Text = Strings.Menu_QuickSignIn_TimedOut;
				break;
			case "UserLinked":
				StatusText.Text = Strings.Menu_QuickSignIn_Linked;
				break;
			default:
				if (!string.IsNullOrEmpty(accountName))
				{
					StatusText.Text = status + " - " + accountName;
				}
				else if (!string.IsNullOrEmpty(status))
				{
					StatusText.Text = status;
				}
				break;
			}
		});
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		InstructionsText = nameScope?.Find<MarkdownTextBlock>("InstructionsText");
		CodeBox = nameScope?.Find<Border>("CodeBox");
		CodeTextBox = nameScope?.Find<TextBox>("CodeTextBox");
		StatusText = nameScope?.Find<TextBlock>("StatusText");
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, QuickSignCodeDialog P_1)
	{
		XamlIlContext.Context<QuickSignCodeDialog> context = new XamlIlContext.Context<QuickSignCodeDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FQuickSignCodeDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/QuickSignCodeDialog.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Title = Strings.Menu_Dialog_QuickSignIn_Title;
		P_1.Width = 450.0;
		P_1.Height = 345.0;
		P_1.MinWidth = 450.0;
		P_1.MinHeight = 345.0;
		P_1.CanResize = true;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterOwner;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid5.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid5.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children.Add(grid6);
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		Grid.SetRow(grid9, 0);
		grid9.Margin = new Thickness(20.0, 16.0, 20.0, 16.0);
		RowDefinitions rowDefinitions2 = new RowDefinitions();
		rowDefinitions2.Capacity = 5;
		rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions2.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid9.RowDefinitions = rowDefinitions2;
		Avalonia.Controls.Controls children2 = grid9.Children;
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		children2.Add(stackPanel);
		Grid.SetRow(stackPanel2, 0);
		stackPanel2.Margin = new Thickness(0.0, 0.0, 0.0, 16.0);
		stackPanel2.Orientation = Orientation.Horizontal;
		Avalonia.Controls.Controls children3 = stackPanel2.Children;
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		children3.Add(lucide);
		lucide2.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
		lucide2.FontSize = 20.0;
		lucide2.Icon = LucideIconNames.Link2;
		((ISupportInitialize)lucide2).EndInit();
		Avalonia.Controls.Controls children4 = stackPanel2.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children4.Add(textBlock);
		textBlock2.FontSize = 18.0;
		textBlock2.FontWeight = FontWeight.DemiBold;
		textBlock2.Text = Strings.Menu_Dialog_QuickSignIn_Title;
		((ISupportInitialize)textBlock2).EndInit();
		((ISupportInitialize)stackPanel2).EndInit();
		Avalonia.Controls.Controls children5 = grid9.Children;
		MarkdownTextBlock markdownTextBlock2;
		MarkdownTextBlock markdownTextBlock = (markdownTextBlock2 = new MarkdownTextBlock());
		((ISupportInitialize)markdownTextBlock).BeginInit();
		children5.Add(markdownTextBlock);
		MarkdownTextBlock markdownTextBlock4;
		MarkdownTextBlock markdownTextBlock3 = (markdownTextBlock4 = markdownTextBlock2);
		context.PushParent(markdownTextBlock4);
		markdownTextBlock4.Name = "InstructionsText";
		object element = markdownTextBlock4;
		context.AvaloniaNameScope.Register("InstructionsText", element);
		Grid.SetRow(markdownTextBlock4, 1);
		markdownTextBlock4.Margin = new Thickness(0.0, 0.0, 0.0, 12.0);
		markdownTextBlock4.FontSize = 14.0;
		StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("TextFillColorSecondaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		markdownTextBlock4.Bind(foregroundProperty, binding);
		StyledProperty<string> markdownTextProperty = MarkdownTextBlock.MarkdownTextProperty;
		CompiledBindingExtension compiledBindingExtension2;
		CompiledBindingExtension compiledBindingExtension = (compiledBindingExtension2 = new CompiledBindingExtension());
		context.PushParent(compiledBindingExtension2);
		compiledBindingExtension2.Source = Strings.Menu_QuickSignIn_Instruction;
		StaticResourceExtension staticResourceExtension = new StaticResourceExtension("StringFormatConverter");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EData_002ECompiledBinding_002CAvalonia_002EBase_002EConverter_0021Property();
		object? obj = staticResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		compiledBindingExtension2.Converter = (IValueConverter)obj;
		compiledBindingExtension2.ConverterParameter = "https://www.roblox.com/crossdevicelogin/ConfirmCode";
		context.PopParent();
		context.ProvideTargetProperty = MarkdownTextBlock.MarkdownTextProperty;
		CompiledBinding binding2 = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		markdownTextBlock4.Bind(markdownTextProperty, binding2);
		markdownTextBlock4.TextWrapping = TextWrapping.Wrap;
		markdownTextBlock4.IsVisible = true;
		context.PopParent();
		((ISupportInitialize)markdownTextBlock3).EndInit();
		Avalonia.Controls.Controls children6 = grid9.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children6.Add(border);
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Border border5 = border4;
		border5.Name = "CodeBox";
		element = border5;
		context.AvaloniaNameScope.Register("CodeBox", element);
		Grid.SetRow(border5, 2);
		border5.Margin = new Thickness(0.0, 0.0, 0.0, 16.0);
		border5.Padding = new Thickness(16.0, 12.0, 16.0, 12.0);
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("ControlFillColorSecondaryBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding3 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(backgroundProperty, binding3);
		StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("ControlElevationBorderBrush");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding4 = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(borderBrushProperty, binding4);
		border5.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		border5.CornerRadius = new CornerRadius(6.0, 6.0, 6.0, 6.0);
		border5.IsVisible = false;
		TextBox textBox2;
		TextBox textBox = (textBox2 = new TextBox());
		((ISupportInitialize)textBox).BeginInit();
		border5.Child = textBox;
		TextBox textBox4;
		TextBox textBox3 = (textBox4 = textBox2);
		context.PushParent(textBox4);
		textBox4.Name = "CodeTextBox";
		element = textBox4;
		context.AvaloniaNameScope.Register("CodeTextBox", element);
		textBox4.HorizontalAlignment = HorizontalAlignment.Stretch;
		textBox4.VerticalContentAlignment = VerticalAlignment.Center;
		textBox4.Background = new ImmutableSolidColorBrush(16777215u);
		textBox4.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
		textBox4.FontFamily = new FontFamily(((IUriContext)context).BaseUri, "Consolas");
		textBox4.FontSize = 20.0;
		textBox4.FontWeight = FontWeight.Bold;
		StyledProperty<IBrush?> foregroundProperty2 = TemplatedControl.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("TextFillColorPrimaryBrush");
		context.ProvideTargetProperty = TemplatedControl.ForegroundProperty;
		BindingBase binding5 = dynamicResourceExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBox4.Bind(foregroundProperty2, binding5);
		textBox4.IsReadOnly = true;
		textBox4.TextAlignment = TextAlignment.Center;
		textBox4.TextWrapping = TextWrapping.NoWrap;
		context.PopParent();
		((ISupportInitialize)textBox3).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		Avalonia.Controls.Controls children7 = grid9.Children;
		Border border7;
		Border border6 = (border7 = new Border());
		((ISupportInitialize)border6).BeginInit();
		children7.Add(border6);
		Border border8 = (border4 = border7);
		context.PushParent(border4);
		Border border9 = border4;
		Grid.SetRow(border9, 3);
		StyledProperty<IBrush?> backgroundProperty2 = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension5 = new DynamicResourceExtension("SystemFillColorAttentionBackgroundBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding6 = dynamicResourceExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border9.Bind(backgroundProperty2, binding6);
		StyledProperty<IBrush?> borderBrushProperty2 = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension6 = new DynamicResourceExtension("SystemFillColorAttentionBrush");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding7 = dynamicResourceExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border9.Bind(borderBrushProperty2, binding7);
		border9.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		border9.CornerRadius = new CornerRadius(6.0, 6.0, 6.0, 6.0);
		border9.Padding = new Thickness(12.0, 10.0, 12.0, 10.0);
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = new StackPanel());
		((ISupportInitialize)stackPanel3).BeginInit();
		border9.Child = stackPanel3;
		StackPanel stackPanel6;
		StackPanel stackPanel5 = (stackPanel6 = stackPanel4);
		context.PushParent(stackPanel6);
		stackPanel6.Orientation = Orientation.Horizontal;
		Avalonia.Controls.Controls children8 = stackPanel6.Children;
		Lucide lucide4;
		Lucide lucide3 = (lucide4 = new Lucide());
		((ISupportInitialize)lucide3).BeginInit();
		children8.Add(lucide3);
		Lucide lucide6;
		Lucide lucide5 = (lucide6 = lucide4);
		context.PushParent(lucide6);
		lucide6.Icon = LucideIconNames.Info;
		lucide6.FontSize = 16.0;
		lucide6.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
		StyledProperty<IBrush?> foregroundProperty3 = TemplatedControl.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension7 = new DynamicResourceExtension("SystemFillColorAttentionBrush");
		context.ProvideTargetProperty = TemplatedControl.ForegroundProperty;
		BindingBase binding8 = dynamicResourceExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide6.Bind(foregroundProperty3, binding8);
		context.PopParent();
		((ISupportInitialize)lucide5).EndInit();
		Avalonia.Controls.Controls children9 = stackPanel6.Children;
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		children9.Add(textBlock3);
		TextBlock textBlock6;
		TextBlock textBlock5 = (textBlock6 = textBlock4);
		context.PushParent(textBlock6);
		textBlock6.Name = "StatusText";
		element = textBlock6;
		context.AvaloniaNameScope.Register("StatusText", element);
		textBlock6.Text = Strings.Menu_QuickSignIn_Waitting;
		textBlock6.TextWrapping = TextWrapping.Wrap;
		textBlock6.FontSize = 13.0;
		StyledProperty<IBrush?> foregroundProperty4 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension8 = new DynamicResourceExtension("TextFillColorPrimaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding9 = dynamicResourceExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock6.Bind(foregroundProperty4, binding9);
		textBlock6.VerticalAlignment = VerticalAlignment.Center;
		context.PopParent();
		((ISupportInitialize)textBlock5).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel5).EndInit();
		context.PopParent();
		((ISupportInitialize)border8).EndInit();
		Avalonia.Controls.Controls children10 = grid9.Children;
		Rectangle rectangle2;
		Rectangle rectangle = (rectangle2 = new Rectangle());
		((ISupportInitialize)rectangle).BeginInit();
		children10.Add(rectangle);
		Grid.SetRow(rectangle2, 4);
		rectangle2.Fill = new ImmutableSolidColorBrush(16777215u);
		((ISupportInitialize)rectangle2).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		Avalonia.Controls.Controls children11 = grid5.Children;
		Border border11;
		Border border10 = (border11 = new Border());
		((ISupportInitialize)border10).BeginInit();
		children11.Add(border10);
		Border border12 = (border4 = border11);
		context.PushParent(border4);
		Border border13 = border4;
		Grid.SetRow(border13, 1);
		StyledProperty<IBrush?> backgroundProperty3 = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension9 = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding10 = dynamicResourceExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border13.Bind(backgroundProperty3, binding10);
		StyledProperty<IBrush?> borderBrushProperty3 = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension10 = new DynamicResourceExtension("ControlElevationBorderBrush");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding11 = dynamicResourceExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border13.Bind(borderBrushProperty3, binding11);
		border13.BorderThickness = new Thickness(1.0, 1.0, 0.0, 0.0);
		Grid grid11;
		Grid grid10 = (grid11 = new Grid());
		((ISupportInitialize)grid10).BeginInit();
		border13.Child = grid10;
		grid11.Margin = new Thickness(20.0, 16.0, 20.0, 16.0);
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 3;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid11.ColumnDefinitions = columnDefinitions;
		Avalonia.Controls.Controls children12 = grid11.Children;
		Rectangle rectangle4;
		Rectangle rectangle3 = (rectangle4 = new Rectangle());
		((ISupportInitialize)rectangle3).BeginInit();
		children12.Add(rectangle3);
		Grid.SetColumn(rectangle4, 0);
		rectangle4.Fill = new ImmutableSolidColorBrush(16777215u);
		((ISupportInitialize)rectangle4).EndInit();
		Avalonia.Controls.Controls children13 = grid11.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children13.Add(button);
		Grid.SetColumn(button2, 1);
		button2.MinWidth = 100.0;
		button2.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
		button2.HorizontalAlignment = HorizontalAlignment.Right;
		button2.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.Copy_Click), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button2.Content = Strings.Common_Copy;
		((ISupportInitialize)button2).EndInit();
		Avalonia.Controls.Controls children14 = grid11.Children;
		Button button5;
		Button button4 = (button5 = new Button());
		((ISupportInitialize)button4).BeginInit();
		children14.Add(button4);
		Grid.SetColumn(button5, 2);
		button5.MinWidth = 100.0;
		button5.HorizontalAlignment = HorizontalAlignment.Right;
		button5.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.Close_Click), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button5.Content = Strings.Common_Close;
		((ISupportInitialize)button5).EndInit();
		((ISupportInitialize)grid11).EndInit();
		context.PopParent();
		((ISupportInitialize)border12).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(QuickSignCodeDialog P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
