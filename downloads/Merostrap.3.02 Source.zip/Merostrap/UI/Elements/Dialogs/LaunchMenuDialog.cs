using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.Converters;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Media.Immutable;
using CompiledAvaloniaXaml;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.Enums;
using Merostrap.Resources;
using Merostrap.UI.Elements.Base;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.ViewModels.Dialogs;

namespace Merostrap.UI.Elements.Dialogs;

internal class LaunchMenuDialog : AvaloniaWindow
{
	public NextAction CloseAction;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	protected override bool ApplyTopPadding => false;

	public LaunchMenuDialog()
	{
		InitializeComponent();
		LaunchMenuViewModel launchMenuViewModel = new LaunchMenuViewModel();
		launchMenuViewModel.CloseWindowRequest += (object? _, NextAction closeAction) =>
		{
			CloseAction = closeAction;
			Close();
		};
		DataContext = launchMenuViewModel;
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, LaunchMenuDialog P_1)
	{
		XamlIlContext.Context<LaunchMenuDialog> context = new XamlIlContext.Context<LaunchMenuDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FLaunchMenuDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/LaunchMenuDialog.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Title = "Merostrap";
		P_1.Width = 440.0;
		P_1.Height = 316.0;
		P_1.MinWidth = 360.0;
		P_1.MinHeight = 300.0;
		P_1.CanResize = true;
		P_1.WindowDecorations = WindowDecorations.None;
		P_1.ExtendClientAreaToDecorationsHint = false;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		P_1.Content = border;
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("WelcomeSurface");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border4.Bind(backgroundProperty, binding);
		StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("WelcomeBorder");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border4.Bind(borderBrushProperty, binding2);
		border4.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		border4.Child = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(36.0, GridUnitType.Pixel)));
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid5.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid5.Children;
		WelcomeTitleBar welcomeTitleBar2;
		WelcomeTitleBar welcomeTitleBar = (welcomeTitleBar2 = new WelcomeTitleBar());
		((ISupportInitialize)welcomeTitleBar).BeginInit();
		children.Add(welcomeTitleBar);
		((ISupportInitialize)welcomeTitleBar2).EndInit();
		Avalonia.Controls.Controls children2 = grid5.Children;
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		children2.Add(scrollViewer);
		ScrollViewer scrollViewer4;
		ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
		context.PushParent(scrollViewer4);
		Grid.SetRow(scrollViewer4, 1);
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		scrollViewer4.Content = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		StackPanel stackPanel5 = stackPanel4;
		stackPanel5.Margin = new Thickness(28.0, 12.0, 28.0, 28.0);
		stackPanel5.Spacing = 24.0;
		stackPanel5.MaxWidth = 420.0;
		stackPanel5.VerticalAlignment = VerticalAlignment.Top;
		Avalonia.Controls.Controls children3 = stackPanel5.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children3.Add(grid6);
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 3;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid9.ColumnDefinitions = columnDefinitions;
		Avalonia.Controls.Controls children4 = grid9.Children;
		Image image2;
		Image image = (image2 = new Image());
		((ISupportInitialize)image).BeginInit();
		children4.Add(image);
		Image image4;
		Image image3 = (image4 = image2);
		context.PushParent(image4);
		image4.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "avares://Merostrap/Resources/Brand/Merostrap.png");
		image4.Width = 56.0;
		image4.Height = 56.0;
		RenderOptions.SetBitmapInterpolationMode(image4, BitmapInterpolationMode.HighQuality);
		context.PopParent();
		((ISupportInitialize)image3).EndInit();
		Avalonia.Controls.Controls children5 = grid9.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children5.Add(textBlock);
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = textBlock2);
		context.PushParent(textBlock4);
		Grid.SetColumn(textBlock4, 1);
		textBlock4.Text = "Merostrap";
		textBlock4.Margin = new Thickness(14.0, 0.0, 0.0, 0.0);
		textBlock4.FontSize = 25.0;
		textBlock4.FontWeight = FontWeight.DemiBold;
		textBlock4.VerticalAlignment = VerticalAlignment.Center;
		StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("WelcomeText");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding3 = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock4.Bind(foregroundProperty, binding3);
		context.PopParent();
		((ISupportInitialize)textBlock3).EndInit();
		Avalonia.Controls.Controls children6 = grid9.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children6.Add(button);
		Button button4;
		Button button3 = (button4 = button2);
		context.PushParent(button4);
		Button button5 = button4;
		Grid.SetColumn(button5, 2);
		button5.Classes.Add("WelcomeSecondary");
		button5.Width = 44.0;
		button5.Height = 44.0;
		button5.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
		button5.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
		button5.Background = new ImmutableSolidColorBrush(16777215u);
		button5.VerticalAlignment = VerticalAlignment.Center;
		StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ELaunchMenuViewModel_002CMerostrap_002ELaunchSettingsCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding4 = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button5.Bind(commandProperty, binding4);
		ToolTip.SetTip(button5, Strings.Common_Settings);
		AutomationProperties.SetName(button5, Strings.Common_Settings);
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		button5.Content = lucide;
		Lucide lucide4;
		Lucide lucide3 = (lucide4 = lucide2);
		context.PushParent(lucide4);
		lucide4.Icon = LucideIconNames.Settings;
		lucide4.Width = 20.0;
		lucide4.Height = 20.0;
		StyledProperty<IBrush?> strokeBrushProperty = Lucide.StrokeBrushProperty;
		DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("WelcomeMuted");
		context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
		BindingBase binding5 = dynamicResourceExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide4.Bind(strokeBrushProperty, binding5);
		context.PopParent();
		((ISupportInitialize)lucide3).EndInit();
		context.PopParent();
		((ISupportInitialize)button3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		Avalonia.Controls.Controls children7 = stackPanel5.Children;
		StackPanel stackPanel7;
		StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
		((ISupportInitialize)stackPanel6).BeginInit();
		children7.Add(stackPanel6);
		StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
		context.PushParent(stackPanel4);
		StackPanel stackPanel9 = stackPanel4;
		stackPanel9.Spacing = 12.0;
		Avalonia.Controls.Controls children8 = stackPanel9.Children;
		Button button7;
		Button button6 = (button7 = new Button());
		((ISupportInitialize)button6).BeginInit();
		children8.Add(button6);
		Button button8 = (button4 = button7);
		context.PushParent(button4);
		Button button9 = button4;
		button9.Classes.Add("WelcomePrimary");
		StyledProperty<ICommand?> commandProperty2 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ELaunchMenuViewModel_002CMerostrap_002EPlayCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding6 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button9.Bind(commandProperty2, binding6);
		button9.HorizontalAlignment = HorizontalAlignment.Stretch;
		button9.HorizontalContentAlignment = HorizontalAlignment.Left;
		button9.Height = 60.0;
		button9.IsDefault = true;
		AutomationProperties.SetName(button9, WelcomeStrings.Play);
		StackPanel stackPanel11;
		StackPanel stackPanel10 = (stackPanel11 = new StackPanel());
		((ISupportInitialize)stackPanel10).BeginInit();
		button9.Content = stackPanel10;
		stackPanel11.Orientation = Orientation.Horizontal;
		stackPanel11.Spacing = 16.0;
		Avalonia.Controls.Controls children9 = stackPanel11.Children;
		Lucide lucide6;
		Lucide lucide5 = (lucide6 = new Lucide());
		((ISupportInitialize)lucide5).BeginInit();
		children9.Add(lucide5);
		lucide6.Icon = LucideIconNames.Gamepad2;
		lucide6.Width = 24.0;
		lucide6.Height = 24.0;
		lucide6.StrokeBrush = new ImmutableSolidColorBrush(uint.MaxValue);
		((ISupportInitialize)lucide6).EndInit();
		Avalonia.Controls.Controls children10 = stackPanel11.Children;
		TextBlock textBlock6;
		TextBlock textBlock5 = (textBlock6 = new TextBlock());
		((ISupportInitialize)textBlock5).BeginInit();
		children10.Add(textBlock5);
		textBlock6.Text = WelcomeStrings.Play;
		textBlock6.FontSize = 16.0;
		textBlock6.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)textBlock6).EndInit();
		((ISupportInitialize)stackPanel11).EndInit();
		context.PopParent();
		((ISupportInitialize)button8).EndInit();
		Avalonia.Controls.Controls children11 = stackPanel9.Children;
		Button button11;
		Button button10 = (button11 = new Button());
		((ISupportInitialize)button10).BeginInit();
		children11.Add(button10);
		Button button12 = (button4 = button11);
		context.PushParent(button4);
		Button button13 = button4;
		button13.Classes.Add("WelcomeSecondary");
		StyledProperty<ICommand?> commandProperty3 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ELaunchMenuViewModel_002CMerostrap_002EStudioCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding7 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button13.Bind(commandProperty3, binding7);
		button13.HorizontalAlignment = HorizontalAlignment.Stretch;
		button13.HorizontalContentAlignment = HorizontalAlignment.Left;
		StyledProperty<IBrush?> backgroundProperty2 = TemplatedControl.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension5 = new DynamicResourceExtension("WelcomeCard");
		context.ProvideTargetProperty = TemplatedControl.BackgroundProperty;
		BindingBase binding8 = dynamicResourceExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button13.Bind(backgroundProperty2, binding8);
		StyledProperty<IBrush?> borderBrushProperty2 = TemplatedControl.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension6 = new DynamicResourceExtension("WelcomeBorder");
		context.ProvideTargetProperty = TemplatedControl.BorderBrushProperty;
		BindingBase binding9 = dynamicResourceExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button13.Bind(borderBrushProperty2, binding9);
		button13.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		button13.Padding = new Thickness(22.0, 10.0, 22.0, 10.0);
		button13.Height = 60.0;
		AutomationProperties.SetName(button13, Strings.Common_Studio);
		StackPanel stackPanel13;
		StackPanel stackPanel12 = (stackPanel13 = new StackPanel());
		((ISupportInitialize)stackPanel12).BeginInit();
		button13.Content = stackPanel12;
		stackPanel13.Orientation = Orientation.Horizontal;
		stackPanel13.Spacing = 16.0;
		Avalonia.Controls.Controls children12 = stackPanel13.Children;
		Lucide lucide8;
		Lucide lucide7 = (lucide8 = new Lucide());
		((ISupportInitialize)lucide7).BeginInit();
		children12.Add(lucide7);
		lucide8.Icon = LucideIconNames.Wrench;
		lucide8.Width = 24.0;
		lucide8.Height = 24.0;
		((ISupportInitialize)lucide8).EndInit();
		Avalonia.Controls.Controls children13 = stackPanel13.Children;
		TextBlock textBlock8;
		TextBlock textBlock7 = (textBlock8 = new TextBlock());
		((ISupportInitialize)textBlock7).BeginInit();
		children13.Add(textBlock7);
		textBlock8.Text = Strings.Common_Studio;
		textBlock8.FontSize = 16.0;
		textBlock8.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)textBlock8).EndInit();
		((ISupportInitialize)stackPanel13).EndInit();
		context.PopParent();
		((ISupportInitialize)button12).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel8).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(LaunchMenuDialog P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
