using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.Converters;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Media.Immutable;
using CompiledAvaloniaXaml;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.Resources;
using Merostrap.UI.Elements.Base;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.ViewModels.Dialogs;

namespace Merostrap.UI.Elements.Dialogs;

internal class SignInDialog : AvaloniaWindow
{
	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBox UsernameInput;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal PasswordTextBox PasswordInput;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button RevealPasswordButton;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Lucide PasswordVisibilityIcon;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	protected override bool ApplyTopPadding => false;

	public bool Authenticated { get; private set; }

	private void TogglePasswordVisibility(object? sender, RoutedEventArgs e)
	{
		PasswordInput.RevealPassword = !PasswordInput.RevealPassword;
		string value = (PasswordInput.RevealPassword ? "Hide password" : "Show password");
		ToolTip.SetTip(RevealPasswordButton, value);
		AutomationProperties.SetName(RevealPasswordButton, value);
		PasswordVisibilityIcon.Icon = (PasswordInput.RevealPassword ? LucideIconNames.EyeOff : LucideIconNames.Eye);
	}

	public SignInDialog()
	{
		InitializeComponent();
		SignInViewModel model = new SignInViewModel();
		DataContext = model;
		model.SignedIn += (object? _, EventArgs _) =>
		{
			Authenticated = true;
			Close();
		};
		Closed += (object? _, EventArgs _) =>
		{
			model.Dispose();
		};
		Opened += (object? _, EventArgs _) =>
		{
			UsernameInput.Focus();
		};
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		UsernameInput = nameScope?.Find<TextBox>("UsernameInput");
		PasswordInput = nameScope?.Find<PasswordTextBox>("PasswordInput");
		RevealPasswordButton = nameScope?.Find<Button>("RevealPasswordButton");
		PasswordVisibilityIcon = nameScope?.Find<Lucide>("PasswordVisibilityIcon");
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, SignInDialog P_1)
	{
		XamlIlContext.Context<SignInDialog> context = new XamlIlContext.Context<SignInDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FSignInDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/SignInDialog.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Title = "Merostrap";
		P_1.Width = 440.0;
		P_1.Height = 540.0;
		P_1.MinWidth = 360.0;
		P_1.MinHeight = 480.0;
		P_1.CanResize = true;
		P_1.WindowDecorations = WindowDecorations.None;
		P_1.ExtendClientAreaToDecorationsHint = false;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		P_1.Content = border;
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("WelcomeSurface");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border4.Bind(backgroundProperty, binding);
		StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("WelcomeBorder");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border4.Bind(borderBrushProperty, binding2);
		border4.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		border4.Child = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(40.0, GridUnitType.Pixel)));
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid5.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid5.Children;
		WelcomeTitleBar welcomeTitleBar2;
		WelcomeTitleBar welcomeTitleBar = (welcomeTitleBar2 = new WelcomeTitleBar());
		((ISupportInitialize)welcomeTitleBar).BeginInit();
		children.Add(welcomeTitleBar);
		((ISupportInitialize)welcomeTitleBar2).EndInit();
		Avalonia.Controls.Controls children2 = grid5.Children;
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		children2.Add(scrollViewer);
		ScrollViewer scrollViewer4;
		ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
		context.PushParent(scrollViewer4);
		Grid.SetRow(scrollViewer4, 1);
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		scrollViewer4.Content = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		StackPanel stackPanel5 = stackPanel4;
		stackPanel5.Margin = new Thickness(36.0, 12.0, 36.0, 36.0);
		stackPanel5.Spacing = 22.0;
		stackPanel5.MaxWidth = 360.0;
		stackPanel5.HorizontalAlignment = HorizontalAlignment.Stretch;
		stackPanel5.VerticalAlignment = VerticalAlignment.Center;
		Avalonia.Controls.Controls children3 = stackPanel5.Children;
		StackPanel stackPanel7;
		StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
		((ISupportInitialize)stackPanel6).BeginInit();
		children3.Add(stackPanel6);
		StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
		context.PushParent(stackPanel4);
		StackPanel stackPanel9 = stackPanel4;
		stackPanel9.Spacing = 10.0;
		stackPanel9.Margin = new Thickness(0.0, 0.0, 0.0, 4.0);
		Avalonia.Controls.Controls children4 = stackPanel9.Children;
		Image image2;
		Image image = (image2 = new Image());
		((ISupportInitialize)image).BeginInit();
		children4.Add(image);
		Image image4;
		Image image3 = (image4 = image2);
		context.PushParent(image4);
		image4.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "avares://Merostrap/Resources/Brand/Merostrap.png");
		image4.Width = 80.0;
		image4.Height = 80.0;
		RenderOptions.SetBitmapInterpolationMode(image4, BitmapInterpolationMode.HighQuality);
		context.PopParent();
		((ISupportInitialize)image3).EndInit();
		Avalonia.Controls.Controls children5 = stackPanel9.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children5.Add(textBlock);
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = textBlock2);
		context.PushParent(textBlock4);
		TextBlock textBlock5 = textBlock4;
		textBlock5.Text = "Merostrap";
		textBlock5.FontSize = 28.0;
		textBlock5.FontWeight = FontWeight.DemiBold;
		textBlock5.HorizontalAlignment = HorizontalAlignment.Center;
		StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("WelcomeText");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding3 = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock5.Bind(foregroundProperty, binding3);
		context.PopParent();
		((ISupportInitialize)textBlock3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel8).EndInit();
		Avalonia.Controls.Controls children6 = stackPanel5.Children;
		StackPanel stackPanel11;
		StackPanel stackPanel10 = (stackPanel11 = new StackPanel());
		((ISupportInitialize)stackPanel10).BeginInit();
		children6.Add(stackPanel10);
		StackPanel stackPanel12 = (stackPanel4 = stackPanel11);
		context.PushParent(stackPanel4);
		StackPanel stackPanel13 = stackPanel4;
		stackPanel13.Spacing = 16.0;
		StyledProperty<bool> isEnabledProperty = InputElement.IsEnabledProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ESignInViewModel_002CMerostrap_002ECanEdit_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = InputElement.IsEnabledProperty;
		CompiledBinding binding4 = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		stackPanel13.Bind(isEnabledProperty, binding4);
		Avalonia.Controls.Controls children7 = stackPanel13.Children;
		StackPanel stackPanel15;
		StackPanel stackPanel14 = (stackPanel15 = new StackPanel());
		((ISupportInitialize)stackPanel14).BeginInit();
		children7.Add(stackPanel14);
		StackPanel stackPanel16 = (stackPanel4 = stackPanel15);
		context.PushParent(stackPanel4);
		StackPanel stackPanel17 = stackPanel4;
		stackPanel17.Spacing = 7.0;
		Avalonia.Controls.Controls children8 = stackPanel17.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children8.Add(grid6);
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 2;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid9.ColumnDefinitions = columnDefinitions;
		grid9.ColumnSpacing = 12.0;
		grid9.Height = 20.0;
		Avalonia.Controls.Controls children9 = grid9.Children;
		TextBlock textBlock7;
		TextBlock textBlock6 = (textBlock7 = new TextBlock());
		((ISupportInitialize)textBlock6).BeginInit();
		children9.Add(textBlock6);
		TextBlock textBlock8 = (textBlock4 = textBlock7);
		context.PushParent(textBlock4);
		TextBlock textBlock9 = textBlock4;
		textBlock9.Text = WelcomeStrings.Username;
		textBlock9.VerticalAlignment = VerticalAlignment.Center;
		textBlock9.FontSize = 13.0;
		StyledProperty<IBrush?> foregroundProperty2 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("WelcomeMuted");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding5 = dynamicResourceExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock9.Bind(foregroundProperty2, binding5);
		context.PopParent();
		((ISupportInitialize)textBlock8).EndInit();
		Avalonia.Controls.Controls children10 = grid9.Children;
		TextBlock textBlock11;
		TextBlock textBlock10 = (textBlock11 = new TextBlock());
		((ISupportInitialize)textBlock10).BeginInit();
		children10.Add(textBlock10);
		TextBlock textBlock12 = (textBlock4 = textBlock11);
		context.PushParent(textBlock4);
		TextBlock textBlock13 = textBlock4;
		Grid.SetColumn(textBlock13, 1);
		StyledProperty<string?> textProperty = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ESignInViewModel_002CMerostrap_002EMessage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding6 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock13.Bind(textProperty, binding6);
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ESignInViewModel_002CMerostrap_002EHasMessage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding7 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock13.Bind(isVisibleProperty, binding7);
		textBlock13.FontSize = 11.0;
		textBlock13.VerticalAlignment = VerticalAlignment.Center;
		textBlock13.HorizontalAlignment = HorizontalAlignment.Right;
		StyledProperty<IBrush?> foregroundProperty3 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension5 = new DynamicResourceExtension("WelcomeError");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding8 = dynamicResourceExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock13.Bind(foregroundProperty3, binding8);
		textBlock13.TextTrimming = TextTrimming.CharacterEllipsis;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ESignInViewModel_002CMerostrap_002EMessage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ToolTip.TipProperty;
		CompiledBinding compiledBinding = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_11((ToolTip)(object)textBlock13, compiledBinding);
		AutomationProperties.SetLiveSetting(textBlock13, AutomationLiveSetting.Polite);
		context.PopParent();
		((ISupportInitialize)textBlock12).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		Avalonia.Controls.Controls children11 = stackPanel17.Children;
		TextBox textBox2;
		TextBox textBox = (textBox2 = new TextBox());
		((ISupportInitialize)textBox).BeginInit();
		children11.Add(textBox);
		TextBox textBox4;
		TextBox textBox3 = (textBox4 = textBox2);
		context.PushParent(textBox4);
		textBox4.Name = "UsernameInput";
		object element = textBox4;
		context.AvaloniaNameScope.Register("UsernameInput", element);
		textBox4.Classes.Add("WelcomeInput");
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ESignInViewModel_002CMerostrap_002EHasMessage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = "class:invalid";
		CompiledBinding compiledBinding2 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		BindingBase source = compiledBinding2;
		textBox4.BindClass("invalid", source, null);
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ESignInViewModel_002CMerostrap_002EMessage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ToolTip.TipProperty;
		CompiledBinding compiledBinding3 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_11((ToolTip)(object)textBox4, compiledBinding3);
		AttachedProperty<string?> helpTextProperty = AutomationProperties.HelpTextProperty;
		CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ESignInViewModel_002CMerostrap_002EMessage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = AutomationProperties.HelpTextProperty;
		CompiledBinding binding9 = compiledBindingExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBox4.Bind(helpTextProperty, binding9);
		StyledProperty<string?> textProperty2 = TextBox.TextProperty;
		CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ESignInViewModel_002CMerostrap_002EUsername_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = TextBox.TextProperty;
		CompiledBinding binding10 = compiledBindingExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBox4.Bind(textProperty2, binding10);
		textBox4.MaxLength = 32;
		AutomationProperties.SetName(textBox4, WelcomeStrings.Username);
		context.PopParent();
		((ISupportInitialize)textBox3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel16).EndInit();
		Avalonia.Controls.Controls children12 = stackPanel13.Children;
		StackPanel stackPanel19;
		StackPanel stackPanel18 = (stackPanel19 = new StackPanel());
		((ISupportInitialize)stackPanel18).BeginInit();
		children12.Add(stackPanel18);
		StackPanel stackPanel20 = (stackPanel4 = stackPanel19);
		context.PushParent(stackPanel4);
		StackPanel stackPanel21 = stackPanel4;
		stackPanel21.Spacing = 7.0;
		Avalonia.Controls.Controls children13 = stackPanel21.Children;
		Grid grid11;
		Grid grid10 = (grid11 = new Grid());
		((ISupportInitialize)grid10).BeginInit();
		children13.Add(grid10);
		Grid grid12 = (grid4 = grid11);
		context.PushParent(grid4);
		Grid grid13 = grid4;
		ColumnDefinitions columnDefinitions2 = new ColumnDefinitions();
		columnDefinitions2.Capacity = 2;
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid13.ColumnDefinitions = columnDefinitions2;
		grid13.ColumnSpacing = 12.0;
		grid13.Height = 20.0;
		Avalonia.Controls.Controls children14 = grid13.Children;
		TextBlock textBlock15;
		TextBlock textBlock14 = (textBlock15 = new TextBlock());
		((ISupportInitialize)textBlock14).BeginInit();
		children14.Add(textBlock14);
		TextBlock textBlock16 = (textBlock4 = textBlock15);
		context.PushParent(textBlock4);
		TextBlock textBlock17 = textBlock4;
		textBlock17.Text = WelcomeStrings.Password;
		textBlock17.VerticalAlignment = VerticalAlignment.Center;
		textBlock17.FontSize = 13.0;
		StyledProperty<IBrush?> foregroundProperty4 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension6 = new DynamicResourceExtension("WelcomeMuted");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding11 = dynamicResourceExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock17.Bind(foregroundProperty4, binding11);
		context.PopParent();
		((ISupportInitialize)textBlock16).EndInit();
		Avalonia.Controls.Controls children15 = grid13.Children;
		TextBlock textBlock19;
		TextBlock textBlock18 = (textBlock19 = new TextBlock());
		((ISupportInitialize)textBlock18).BeginInit();
		children15.Add(textBlock18);
		TextBlock textBlock20 = (textBlock4 = textBlock19);
		context.PushParent(textBlock4);
		TextBlock textBlock21 = textBlock4;
		Grid.SetColumn(textBlock21, 1);
		StyledProperty<string?> textProperty3 = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ESignInViewModel_002CMerostrap_002EMessage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding12 = compiledBindingExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock21.Bind(textProperty3, binding12);
		StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ESignInViewModel_002CMerostrap_002EHasMessage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding13 = compiledBindingExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock21.Bind(isVisibleProperty2, binding13);
		textBlock21.FontSize = 11.0;
		textBlock21.VerticalAlignment = VerticalAlignment.Center;
		textBlock21.HorizontalAlignment = HorizontalAlignment.Right;
		StyledProperty<IBrush?> foregroundProperty5 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension7 = new DynamicResourceExtension("WelcomeError");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding14 = dynamicResourceExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock21.Bind(foregroundProperty5, binding14);
		textBlock21.TextTrimming = TextTrimming.CharacterEllipsis;
		CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ESignInViewModel_002CMerostrap_002EMessage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ToolTip.TipProperty;
		CompiledBinding compiledBinding4 = compiledBindingExtension11.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_11((ToolTip)(object)textBlock21, compiledBinding4);
		AutomationProperties.SetLiveSetting(textBlock21, AutomationLiveSetting.Polite);
		context.PopParent();
		((ISupportInitialize)textBlock20).EndInit();
		context.PopParent();
		((ISupportInitialize)grid12).EndInit();
		Avalonia.Controls.Controls children16 = stackPanel21.Children;
		PasswordTextBox passwordTextBox2;
		PasswordTextBox passwordTextBox = (passwordTextBox2 = new PasswordTextBox());
		((ISupportInitialize)passwordTextBox).BeginInit();
		children16.Add(passwordTextBox);
		PasswordTextBox passwordTextBox4;
		PasswordTextBox passwordTextBox3 = (passwordTextBox4 = passwordTextBox2);
		context.PushParent(passwordTextBox4);
		passwordTextBox4.Name = "PasswordInput";
		element = passwordTextBox4;
		context.AvaloniaNameScope.Register("PasswordInput", element);
		passwordTextBox4.Classes.Add("WelcomeInput");
		CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ESignInViewModel_002CMerostrap_002EHasMessage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = "class:invalid";
		CompiledBinding compiledBinding5 = compiledBindingExtension12.ProvideValue(context);
		context.ProvideTargetProperty = null;
		source = compiledBinding5;
		passwordTextBox4.BindClass("invalid", source, null);
		CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ESignInViewModel_002CMerostrap_002EMessage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ToolTip.TipProperty;
		CompiledBinding compiledBinding6 = compiledBindingExtension13.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_11((ToolTip)(object)passwordTextBox4, compiledBinding6);
		AttachedProperty<string?> helpTextProperty2 = AutomationProperties.HelpTextProperty;
		CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ESignInViewModel_002CMerostrap_002EMessage_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = AutomationProperties.HelpTextProperty;
		CompiledBinding binding15 = compiledBindingExtension14.ProvideValue(context);
		context.ProvideTargetProperty = null;
		passwordTextBox4.Bind(helpTextProperty2, binding15);
		StyledProperty<string?> textProperty4 = TextBox.TextProperty;
		CompiledBindingExtension compiledBindingExtension15 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ESignInViewModel_002CMerostrap_002EPassword_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = TextBox.TextProperty;
		CompiledBinding binding16 = compiledBindingExtension15.ProvideValue(context);
		context.ProvideTargetProperty = null;
		passwordTextBox4.Bind(textProperty4, binding16);
		passwordTextBox4.PasswordChar = '●';
		passwordTextBox4.MaxLength = 128;
		AutomationProperties.SetName(passwordTextBox4, WelcomeStrings.Password);
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		passwordTextBox4.InnerRightContent = button;
		Button button4;
		Button button3 = (button4 = button2);
		context.PushParent(button4);
		Button button5 = button4;
		button5.Name = "RevealPasswordButton";
		element = button5;
		context.AvaloniaNameScope.Register("RevealPasswordButton", element);
		button5.Classes.Add("WelcomeSecondary");
		button5.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.TogglePasswordVisibility), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button5.Width = 40.0;
		button5.Height = 40.0;
		button5.MinHeight = 40.0;
		button5.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
		button5.Margin = new Thickness(0.0, 0.0, 4.0, 0.0);
		button5.VerticalAlignment = VerticalAlignment.Center;
		button5.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
		button5.Background = new ImmutableSolidColorBrush(16777215u);
		ToolTip.SetTip(button5, "Show password");
		AutomationProperties.SetName(button5, "Show password");
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		button5.Content = lucide;
		Lucide lucide4;
		Lucide lucide3 = (lucide4 = lucide2);
		context.PushParent(lucide4);
		lucide4.Name = "PasswordVisibilityIcon";
		element = lucide4;
		context.AvaloniaNameScope.Register("PasswordVisibilityIcon", element);
		lucide4.Icon = LucideIconNames.Eye;
		lucide4.Width = 18.0;
		lucide4.Height = 18.0;
		StyledProperty<IBrush?> strokeBrushProperty = Lucide.StrokeBrushProperty;
		DynamicResourceExtension dynamicResourceExtension8 = new DynamicResourceExtension("WelcomeMuted");
		context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
		BindingBase binding17 = dynamicResourceExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide4.Bind(strokeBrushProperty, binding17);
		context.PopParent();
		((ISupportInitialize)lucide3).EndInit();
		context.PopParent();
		((ISupportInitialize)button3).EndInit();
		context.PopParent();
		((ISupportInitialize)passwordTextBox3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel20).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel12).EndInit();
		Avalonia.Controls.Controls children17 = stackPanel5.Children;
		Button button7;
		Button button6 = (button7 = new Button());
		((ISupportInitialize)button6).BeginInit();
		children17.Add(button6);
		Button button8 = (button4 = button7);
		context.PushParent(button4);
		Button button9 = button4;
		button9.Classes.Add("WelcomePrimary");
		CompiledBindingExtension compiledBindingExtension16 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ESignInViewModel_002CMerostrap_002ESubmitText_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ContentControl.ContentProperty;
		CompiledBinding compiledBinding7 = compiledBindingExtension16.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_4(button9, compiledBinding7);
		StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension17 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ESignInViewModel_002CMerostrap_002ESubmitCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding18 = compiledBindingExtension17.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button9.Bind(commandProperty, binding18);
		StyledProperty<bool> isEnabledProperty2 = InputElement.IsEnabledProperty;
		CompiledBindingExtension compiledBindingExtension18 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ESignInViewModel_002CMerostrap_002ECanEdit_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = InputElement.IsEnabledProperty;
		CompiledBinding binding19 = compiledBindingExtension18.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button9.Bind(isEnabledProperty2, binding19);
		button9.IsDefault = true;
		button9.HorizontalAlignment = HorizontalAlignment.Stretch;
		button9.Height = 46.0;
		context.PopParent();
		((ISupportInitialize)button8).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(SignInDialog P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
