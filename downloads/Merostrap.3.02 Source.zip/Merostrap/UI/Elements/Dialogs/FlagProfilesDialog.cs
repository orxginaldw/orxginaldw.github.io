using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Input.Platform;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using Avalonia.Styling;
using CompiledAvaloniaXaml;
using FluentAvalonia.UI.Controls;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.Enums.Messagebox;
using Merostrap.Resources;
using Merostrap.UI.Elements.Base;
using Merostrap.UI.Elements.Controls;

namespace Merostrap.UI.Elements.Dialogs;

internal class FlagProfilesDialog : AvaloniaWindow
{
	[CompilerGenerated]
	private class XamlClosure_20
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<FlagProfilesDialog> context = CreateContext(P_0);
			context.IntermediateRoot = new UniformGrid();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((AvaloniaObject)obj).SetValue(UniformGrid.ColumnsProperty, 2, BindingPriority.Template);
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<FlagProfilesDialog> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<FlagProfilesDialog> context = new XamlIlContext.Context<FlagProfilesDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FFlagProfilesDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/FlagProfilesDialog.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (FlagProfilesDialog)service;
				}
			}
			return context;
		}
	}

	public MessageBoxResult Result = MessageBoxResult.Cancel;

	private static readonly JsonSerializerOptions _jsonOptions = new JsonSerializerOptions
	{
		WriteIndented = true
	};

	private readonly ObservableCollection<string> _placeIds = new ObservableCollection<string>();

	private string? _currentProfile;

	private bool _isUpdatingPlaceIds;

	private bool _isRemoving;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TabControl Tabs;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal ListBox LoadPresetProfile;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Grid PlaceProfileGrid;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal ComboBox PlaceProfile;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBlock PlaceProfileEmptyMessage;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal StackPanel PlaceIdsContent;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBox NewPlaceIdTextBox;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button AddPlaceButton;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal ListBox PlaceIdsListBox;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBlock PlaceIdInfoText;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBox SaveProfile;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Grid RenamePanel;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBox RenameTextBox;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal ListBox LoadProfile;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBlock LoadProfileEmptyText;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal IconButton RemovePlaceButton;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal CheckBox ClearFlags;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal IconButton DeleteButton;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button OkButton;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public FlagProfilesDialog()
	{
		InitializeComponent();
		PlaceIdsListBox.ItemsSource = _placeIds;
		LoadProfiles();
		LoadPresetProfiles();
		Tabs.SelectedIndex = 2;
		Tabs.SelectionChanged += (object? s, SelectionChangedEventArgs e) =>
		{
			OnTabSelectionChanged();
		};
		SaveProfile.TextChanged += (object? s, TextChangedEventArgs e) =>
		{
			UpdateUiState();
		};
		LoadProfile.SelectionChanged += (object? s, SelectionChangedEventArgs e) =>
		{
			UpdateUiState();
		};
		LoadPresetProfile.SelectionChanged += (object? s, SelectionChangedEventArgs e) =>
		{
			UpdateUiState();
		};
		PlaceProfile.SelectionChanged += (object? s, SelectionChangedEventArgs e) =>
		{
			UpdatePlaceIdsUiState();
		};
	}

	private void OnTabSelectionChanged()
	{
		if (Tabs.SelectedIndex == 1 && PlaceProfile.Items.Count > 0 && PlaceProfile.SelectedItem == null)
		{
			PlaceProfile.SelectedItem = PlaceProfile.Items[0];
		}
		UpdateUiState();
	}

	private void LoadProfiles()
	{
		LoadProfile.Items.Clear();
		PlaceProfile.Items.Clear();
		string savedFlagProfiles = Paths.SavedFlagProfiles;
		if (!Directory.Exists(savedFlagProfiles))
		{
			Directory.CreateDirectory(savedFlagProfiles);
		}
		string[] files = Directory.GetFiles(savedFlagProfiles);
		for (int i = 0; i < files.Length; i++)
		{
			string fileName = Path.GetFileName(files[i]);
			LoadProfile.Items.Add(fileName);
			PlaceProfile.Items.Add(fileName);
		}
		LoadProfileEmptyText.IsVisible = LoadProfile.Items.Count == 0;
		RenamePanel.IsVisible = LoadProfile.Items.Count > 0;
		RenameTextBox.Text = string.Empty;
		RenameTextBox.IsEnabled = false;
	}

	private void LoadProfile_SelectionChanged(object sender, SelectionChangedEventArgs e)
	{
		if (LoadProfile.SelectedItem is string text)
		{
			RenameTextBox.Text = text;
			RenameTextBox.IsEnabled = true;
		}
		else
		{
			RenameTextBox.Text = string.Empty;
			RenameTextBox.IsEnabled = false;
		}
		UpdateUiState();
	}

	private void LoadPresetProfile_SelectionChanged(object sender, SelectionChangedEventArgs e)
	{
		UpdateUiState();
	}

	private void PlaceProfile_SelectionChanged(object sender, SelectionChangedEventArgs e)
	{
		UpdatePlaceIdsUiState();
	}

	private void UpdatePlaceIdsUiState()
	{
		if (_isUpdatingPlaceIds)
		{
			return;
		}
		_isUpdatingPlaceIds = true;
		try
		{
			string text = (_currentProfile = PlaceProfile.SelectedItem as string);
			bool flag = PlaceProfile.Items.Count > 0;
			bool flag2 = text != null;
			PlaceProfileGrid.IsVisible = flag;
			PlaceIdsContent.IsVisible = flag2;
			PlaceProfileEmptyMessage.IsVisible = !flag || !flag2;
			if (!flag)
			{
				PlaceProfileEmptyMessage.Text = Strings.Menu_FlagProfiles_NoProfilesFound;
			}
			else if (!flag2)
			{
				PlaceProfileEmptyMessage.Text = Strings.Menu_FlagProfiles_SelectProfileFirst;
			}
			PlaceIdsListBox.SelectionChanged -= PlaceIdsListBox_SelectionChanged;
			try
			{
				if (!_isRemoving)
				{
					_placeIds.Clear();
					if (flag2 && text != null && App.Settings.Prop.ProfilePlaceIds.TryGetValue(text, out List<string> value))
					{
						foreach (string item in value)
						{
							_placeIds.Add(item);
						}
					}
				}
			}
			finally
			{
				PlaceIdsListBox.SelectionChanged += PlaceIdsListBox_SelectionChanged;
			}
			AddPlaceButton.IsEnabled = flag2;
			RemovePlaceButton.IsEnabled = false;
			PlaceIdInfoText.IsVisible = false;
		}
		finally
		{
			_isUpdatingPlaceIds = false;
		}
	}

	private void AddPlaceButton_Click(object sender, RoutedEventArgs e)
	{
		if (!(PlaceProfile.SelectedItem is string profileName))
		{
			Frontend.ShowMessageBox(Strings.Menu_FlagProfiles_SelectProfileFirst, MessageBoxImage.Warning);
			return;
		}
		string text = NewPlaceIdTextBox.Text?.Trim() ?? string.Empty;
		if (string.IsNullOrWhiteSpace(text))
		{
			Frontend.ShowMessageBox(Strings.Menu_FlagProfiles_EnterPlaceId, MessageBoxImage.Warning);
			return;
		}
		if (!Regex.IsMatch(text, "^\\d+$"))
		{
			Frontend.ShowMessageBox(Strings.Menu_FlagProfiles_PlaceIdNumeric, MessageBoxImage.Warning);
			return;
		}
		if (_placeIds.Contains(text))
		{
			Frontend.ShowMessageBox(Strings.Menu_FlagProfiles_PlaceIdExists, MessageBoxImage.Warning);
			return;
		}
		_placeIds.Add(text);
		NewPlaceIdTextBox.Text = string.Empty;
		SavePlaceIds(profileName);
	}

	private void RemovePlaceButton_Click(object sender, RoutedEventArgs e)
	{
		if (!(PlaceIdsListBox.SelectedItem is string item) || !(PlaceProfile.SelectedItem is string profileName))
		{
			return;
		}
		_isRemoving = true;
		try
		{
			_placeIds.Remove(item);
			SavePlaceIds(profileName);
		}
		finally
		{
			_isRemoving = false;
		}
	}

	private void SavePlaceIds(string profileName)
	{
		if (_placeIds.Count > 0)
		{
			App.Settings.Prop.ProfilePlaceIds[profileName] = _placeIds.ToList();
		}
		else
		{
			App.Settings.Prop.ProfilePlaceIds.Remove(profileName);
		}
		App.Settings.SaveSetting("ProfilePlaceIds");
	}

	private void PlaceIdsListBox_SelectionChanged(object? sender, SelectionChangedEventArgs e)
	{
		try
		{
			IconButton removePlaceButton = RemovePlaceButton;
			if (removePlaceButton != null)
			{
				removePlaceButton.IsEnabled = PlaceIdsListBox?.SelectedItem != null;
			}
		}
		catch
		{
		}
	}

	private void RenameButton_Click(object sender, RoutedEventArgs e)
	{
		if (!(LoadProfile.SelectedItem is string text))
		{
			Frontend.ShowMessageBox(Strings.Menu_FlagProfiles_SelectProfileRename, MessageBoxImage.Warning);
			return;
		}
		string text2 = RenameTextBox.Text?.Trim() ?? string.Empty;
		if (string.IsNullOrWhiteSpace(text2))
		{
			Frontend.ShowMessageBox(Strings.Menu_FlagProfiles_NameCannotBeEmpty, MessageBoxImage.Error);
			return;
		}
		char[] invalidFileNameChars = Path.GetInvalidFileNameChars();
		foreach (char c in invalidFileNameChars)
		{
			if (text2.Contains(c, StringComparison.Ordinal))
			{
				Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.Menu_FlagProfiles_InvalidCharacter, c), MessageBoxImage.Error);
				return;
			}
		}
		string savedFlagProfiles = Paths.SavedFlagProfiles;
		string sourceFileName = Path.Combine(savedFlagProfiles, text);
		string text3 = Path.Combine(savedFlagProfiles, text2);
		if (File.Exists(text3))
		{
			Frontend.ShowMessageBox(Strings.Menu_FlagProfiles_ProfileExists, MessageBoxImage.Error);
			return;
		}
		try
		{
			File.Move(sourceFileName, text3);
			if (App.Settings.Prop.ProfilePlaceIds.TryGetValue(text, out List<string> value))
			{
				App.Settings.Prop.ProfilePlaceIds.Remove(text);
				App.Settings.Prop.ProfilePlaceIds[text2] = value;
				App.Settings.SaveSetting("ProfilePlaceIds");
			}
			LoadProfiles();
			LoadProfile.SelectedItem = text2;
			PlaceProfile.SelectedItem = text2;
		}
		catch (Exception ex)
		{
			Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.Menu_FlagProfiles_RenameFailed, ex.Message), MessageBoxImage.Error);
		}
	}

	private void CopyButton_Click(object sender, RoutedEventArgs e)
	{
		if (!(LoadProfile.SelectedItem is string path))
		{
			Frontend.ShowMessageBox(Strings.Menu_FlagProfiles_SelectProfileCopy, MessageBoxImage.Warning);
			return;
		}
		string path2 = Path.Combine(Paths.SavedFlagProfiles, path);
		if (!File.Exists(path2))
		{
			Frontend.ShowMessageBox(Strings.Menu_FlagProfiles_ProfileNotFound, MessageBoxImage.Error);
			return;
		}
		try
		{
			Dictionary<string, object> dictionary = JsonSerializer.Deserialize<Dictionary<string, object>>(File.ReadAllText(path2));
			if (dictionary == null)
			{
				Frontend.ShowMessageBox(Strings.Menu_FlagProfiles_ParseFailed, MessageBoxImage.Error);
				return;
			}
			IOrderedEnumerable<IGrouping<string, KeyValuePair<string, object>>> orderedEnumerable = from g in dictionary.GroupBy((KeyValuePair<string, object> kvp) =>
				{
					Match match = Regex.Match(kvp.Key, "^[A-Z]+[a-z]*");
					return (!match.Success) ? "Other" : match.Value;
				})
				orderby g.Key
				select g;
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine("{");
			int count = dictionary.Count;
			int num = 0;
			int num2 = 0;
			foreach (IGrouping<string, KeyValuePair<string, object>> item in orderedEnumerable)
			{
				if (num2 > 0)
				{
					stringBuilder.AppendLine();
				}
				foreach (KeyValuePair<string, object> item2 in item.OrderByDescending((KeyValuePair<string, object> kvp) => kvp.Key.Length + (kvp.Value?.ToString()?.Length).GetValueOrDefault()))
				{
					num++;
					bool flag = num == count;
					string text = $"    \"{item2.Key}\": \"{item2.Value}\"";
					if (!flag)
					{
						text += ",";
					}
					stringBuilder.AppendLine(text);
				}
				num2++;
			}
			stringBuilder.AppendLine("}");
			(TopLevel.GetTopLevel(this)?.Clipboard)?.SetTextAsync(stringBuilder.ToString());
		}
		catch (Exception ex)
		{
			Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.Menu_FlagProfiles_CopyFailed, ex.Message), MessageBoxImage.Error);
		}
	}

	private void UpdateButton_Click(object sender, RoutedEventArgs e)
	{
		if (!(LoadProfile.SelectedItem is string text))
		{
			Frontend.ShowMessageBox(Strings.Menu_FlagProfiles_SelectProfileUpdate, MessageBoxImage.Warning);
			return;
		}
		try
		{
			Dictionary<string, object> prop = App.FastFlags.Prop;
			if (prop == null)
			{
				Frontend.ShowMessageBox(Strings.Menu_FlagProfiles_GetFlagsFailed, MessageBoxImage.Error);
				return;
			}
			string contents = JsonSerializer.Serialize(prop, _jsonOptions);
			File.WriteAllText(Path.Combine(Path.Combine(Paths.Base, Paths.SavedFlagProfiles), text), contents);
			LoadProfiles();
			LoadProfile.SelectedItem = text;
		}
		catch (Exception ex)
		{
			Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.Menu_FlagProfiles_UpdateFailed, ex.Message), MessageBoxImage.Error);
		}
	}

	private void LoadPresetProfiles()
	{
		LoadPresetProfile.Items.Clear();
		Assembly executingAssembly = Assembly.GetExecutingAssembly();
		string resourcePrefix = "Merostrap.Resources.PresetFlags.";
		foreach (string item in from r in executingAssembly.GetManifestResourceNames()
			where r.StartsWith(resourcePrefix, StringComparison.Ordinal)
			select r)
		{
			string value = item.Substring(resourcePrefix.Length);
			LoadPresetProfile.Items.Add(value);
		}
	}

	private void UpdateUiState()
	{
		if (Tabs != null && OkButton != null && DeleteButton != null)
		{
			int selectedIndex = Tabs.SelectedIndex;
			ClearFlags.IsVisible = false;
			DeleteButton.IsVisible = false;
			RemovePlaceButton.IsVisible = false;
			switch (selectedIndex)
			{
			case 0:
				OkButton.IsEnabled = LoadPresetProfile.SelectedItem != null;
				break;
			case 1:
				OkButton.IsEnabled = true;
				RemovePlaceButton.IsVisible = true;
				UpdatePlaceIdsUiState();
				RemovePlaceButton.IsEnabled = PlaceIdsListBox?.SelectedItem != null;
				break;
			case 2:
				OkButton.IsEnabled = !string.IsNullOrWhiteSpace(SaveProfile.Text);
				break;
			case 3:
			{
				bool isEnabled = LoadProfile.SelectedItem != null;
				OkButton.IsEnabled = isEnabled;
				DeleteButton.IsEnabled = isEnabled;
				ClearFlags.IsVisible = true;
				DeleteButton.IsVisible = true;
				break;
			}
			}
		}
	}

	private void OKButton_Click(object sender, RoutedEventArgs e)
	{
		switch (Tabs.SelectedIndex)
		{
		case 0:
			if (LoadPresetProfile.SelectedItem is string name2)
			{
				App.FastFlags.LoadPresetProfile(name2, true);
			}
			break;
		case 2:
			if (!string.IsNullOrWhiteSpace(SaveProfile.Text))
			{
				App.FastFlags.SaveProfile(SaveProfile.Text);
			}
			break;
		case 3:
			if (LoadProfile.SelectedItem is string name)
			{
				App.FastFlags.LoadProfile(name, ClearFlags.IsChecked == true);
			}
			break;
		}
		Result = MessageBoxResult.OK;
		Close();
	}

	private async void DeleteButton_Click(object sender, RoutedEventArgs e)
	{
		string text = LoadProfile.SelectedItem?.ToString();
		if (!string.IsNullOrEmpty(text))
		{
			App.Settings.Prop.ProfilePlaceIds.Remove(text);
			App.Settings.SaveSetting("ProfilePlaceIds");
			await FastFlagManager.DeleteProfile(text);
			LoadProfiles();
		}
	}

	private void CancelButton_Click(object? sender, RoutedEventArgs e)
	{
		Result = MessageBoxResult.Cancel;
		Close();
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		Tabs = nameScope?.Find<TabControl>("Tabs");
		LoadPresetProfile = nameScope?.Find<ListBox>("LoadPresetProfile");
		PlaceProfileGrid = nameScope?.Find<Grid>("PlaceProfileGrid");
		PlaceProfile = nameScope?.Find<ComboBox>("PlaceProfile");
		PlaceProfileEmptyMessage = nameScope?.Find<TextBlock>("PlaceProfileEmptyMessage");
		PlaceIdsContent = nameScope?.Find<StackPanel>("PlaceIdsContent");
		NewPlaceIdTextBox = nameScope?.Find<TextBox>("NewPlaceIdTextBox");
		AddPlaceButton = nameScope?.Find<Button>("AddPlaceButton");
		PlaceIdsListBox = nameScope?.Find<ListBox>("PlaceIdsListBox");
		PlaceIdInfoText = nameScope?.Find<TextBlock>("PlaceIdInfoText");
		SaveProfile = nameScope?.Find<TextBox>("SaveProfile");
		RenamePanel = nameScope?.Find<Grid>("RenamePanel");
		RenameTextBox = nameScope?.Find<TextBox>("RenameTextBox");
		LoadProfile = nameScope?.Find<ListBox>("LoadProfile");
		LoadProfileEmptyText = nameScope?.Find<TextBlock>("LoadProfileEmptyText");
		RemovePlaceButton = nameScope?.Find<IconButton>("RemovePlaceButton");
		ClearFlags = nameScope?.Find<CheckBox>("ClearFlags");
		DeleteButton = nameScope?.Find<IconButton>("DeleteButton");
		OkButton = nameScope?.Find<Button>("OkButton");
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, FlagProfilesDialog P_1)
	{
		XamlIlContext.Context<FlagProfilesDialog> context = new XamlIlContext.Context<FlagProfilesDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FFlagProfilesDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/FlagProfilesDialog.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Title = Strings.Menu_FlagProfiles_Title;
		P_1.Width = 540.0;
		P_1.SizeToContent = SizeToContent.Height;
		P_1.CanResize = false;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid5.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid5.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children.Add(border);
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Border border5 = border4;
		Grid.SetRow(border5, 0);
		border5.Margin = new Thickness(16.0, 16.0, 16.0, 16.0);
		border5.CornerRadius = new CornerRadius(8.0, 8.0, 8.0, 8.0);
		border5.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("CardStrokeColorDefaultBrush");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(borderBrushProperty, binding);
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(backgroundProperty, binding2);
		TabControl tabControl2;
		TabControl tabControl = (tabControl2 = new TabControl());
		((ISupportInitialize)tabControl).BeginInit();
		border5.Child = tabControl;
		TabControl tabControl4;
		TabControl tabControl3 = (tabControl4 = tabControl2);
		context.PushParent(tabControl4);
		tabControl4.Name = "Tabs";
		object element = tabControl4;
		context.AvaloniaNameScope.Register("Tabs", element);
		tabControl4.Background = new ImmutableSolidColorBrush(16777215u);
		tabControl4.ItemsPanel = new ItemsPanelTemplate
		{
			Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_20.Build_1), context)
		};
		Styles styles = tabControl4.Styles;
		Style style = new Style();
		style.Selector = ((Selector?)null).OfType(typeof(TabItem));
		Setter setter = new Setter();
		setter.Property = Layoutable.HorizontalAlignmentProperty;
		setter.Value = HorizontalAlignment.Stretch;
		style.Add(setter);
		Setter setter2 = new Setter();
		setter2.Property = ContentControl.HorizontalContentAlignmentProperty;
		setter2.Value = HorizontalAlignment.Center;
		style.Add(setter2);
		Setter setter3 = new Setter();
		setter3.Property = TemplatedControl.FontSizeProperty;
		setter3.Value = 18.0;
		style.Add(setter3);
		styles.Add(style);
		ItemCollection items = tabControl4.Items;
		TabItem tabItem2;
		TabItem tabItem = (tabItem2 = new TabItem());
		((ISupportInitialize)tabItem).BeginInit();
		items.Add(tabItem);
		tabItem2.Header = Strings.Common_PresetFlagLists;
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		TabItemHelper.SetIcon(tabItem2, lucide);
		lucide2.Icon = LucideIconNames.BookOpenText;
		((ISupportInitialize)lucide2).EndInit();
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		tabItem2.Content = stackPanel;
		stackPanel2.Spacing = 12.0;
		stackPanel2.Margin = new Thickness(0.0, 0.0, 0.0, 8.0);
		Avalonia.Controls.Controls children2 = stackPanel2.Children;
		ListBox listBox2;
		ListBox listBox = (listBox2 = new ListBox());
		((ISupportInitialize)listBox).BeginInit();
		children2.Add(listBox);
		listBox2.Name = "LoadPresetProfile";
		element = listBox2;
		context.AvaloniaNameScope.Register("LoadPresetProfile", element);
		listBox2.Height = 200.0;
		listBox2.AddHandler(SelectingItemsControl.SelectionChangedEvent, context.RootObject.LoadPresetProfile_SelectionChanged);
		((ISupportInitialize)listBox2).EndInit();
		((ISupportInitialize)stackPanel2).EndInit();
		((ISupportInitialize)tabItem2).EndInit();
		ItemCollection items2 = tabControl4.Items;
		TabItem tabItem4;
		TabItem tabItem3 = (tabItem4 = new TabItem());
		((ISupportInitialize)tabItem3).BeginInit();
		items2.Add(tabItem3);
		TabItem tabItem6;
		TabItem tabItem5 = (tabItem6 = tabItem4);
		context.PushParent(tabItem6);
		TabItem tabItem7 = tabItem6;
		tabItem7.Header = Strings.Menu_FlagProfiles_PlaceIdsTab;
		Lucide lucide4;
		Lucide lucide3 = (lucide4 = new Lucide());
		((ISupportInitialize)lucide3).BeginInit();
		TabItemHelper.SetIcon(tabItem7, lucide3);
		lucide4.Icon = LucideIconNames.Gamepad2;
		((ISupportInitialize)lucide4).EndInit();
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = new StackPanel());
		((ISupportInitialize)stackPanel3).BeginInit();
		tabItem7.Content = stackPanel3;
		StackPanel stackPanel6;
		StackPanel stackPanel5 = (stackPanel6 = stackPanel4);
		context.PushParent(stackPanel6);
		StackPanel stackPanel7 = stackPanel6;
		stackPanel7.Spacing = 12.0;
		stackPanel7.Margin = new Thickness(0.0, 0.0, 0.0, 8.0);
		Avalonia.Controls.Controls children3 = stackPanel7.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children3.Add(grid6);
		grid7.Name = "PlaceProfileGrid";
		element = grid7;
		context.AvaloniaNameScope.Register("PlaceProfileGrid", element);
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 2;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid7.ColumnDefinitions = columnDefinitions;
		grid7.ColumnSpacing = 8.0;
		grid7.IsVisible = false;
		Avalonia.Controls.Controls children4 = grid7.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children4.Add(textBlock);
		textBlock2.Text = Strings.Menu_FlagProfiles_SelectProfileLabel;
		textBlock2.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)textBlock2).EndInit();
		Avalonia.Controls.Controls children5 = grid7.Children;
		ComboBox comboBox2;
		ComboBox comboBox = (comboBox2 = new ComboBox());
		((ISupportInitialize)comboBox).BeginInit();
		children5.Add(comboBox);
		comboBox2.Name = "PlaceProfile";
		element = comboBox2;
		context.AvaloniaNameScope.Register("PlaceProfile", element);
		Grid.SetColumn(comboBox2, 1);
		comboBox2.HorizontalAlignment = HorizontalAlignment.Stretch;
		comboBox2.AddHandler(SelectingItemsControl.SelectionChangedEvent, context.RootObject.PlaceProfile_SelectionChanged);
		((ISupportInitialize)comboBox2).EndInit();
		((ISupportInitialize)grid7).EndInit();
		Avalonia.Controls.Controls children6 = stackPanel7.Children;
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		children6.Add(textBlock3);
		TextBlock textBlock6;
		TextBlock textBlock5 = (textBlock6 = textBlock4);
		context.PushParent(textBlock6);
		TextBlock textBlock7 = textBlock6;
		textBlock7.Name = "PlaceProfileEmptyMessage";
		element = textBlock7;
		context.AvaloniaNameScope.Register("PlaceProfileEmptyMessage", element);
		textBlock7.Text = Strings.Menu_FlagProfiles_NoProfilesFound;
		StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("SystemFillColorSecondaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding3 = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock7.Bind(foregroundProperty, binding3);
		textBlock7.FontSize = 12.0;
		textBlock7.HorizontalAlignment = HorizontalAlignment.Center;
		textBlock7.IsVisible = false;
		context.PopParent();
		((ISupportInitialize)textBlock5).EndInit();
		Avalonia.Controls.Controls children7 = stackPanel7.Children;
		StackPanel stackPanel9;
		StackPanel stackPanel8 = (stackPanel9 = new StackPanel());
		((ISupportInitialize)stackPanel8).BeginInit();
		children7.Add(stackPanel8);
		StackPanel stackPanel10 = (stackPanel6 = stackPanel9);
		context.PushParent(stackPanel6);
		StackPanel stackPanel11 = stackPanel6;
		stackPanel11.Name = "PlaceIdsContent";
		element = stackPanel11;
		context.AvaloniaNameScope.Register("PlaceIdsContent", element);
		stackPanel11.Spacing = 8.0;
		stackPanel11.IsVisible = false;
		Avalonia.Controls.Controls children8 = stackPanel11.Children;
		TextBlock textBlock9;
		TextBlock textBlock8 = (textBlock9 = new TextBlock());
		((ISupportInitialize)textBlock8).BeginInit();
		children8.Add(textBlock8);
		textBlock9.Text = Strings.Menu_FlagProfiles_AddPlaceId;
		textBlock9.FontSize = 12.0;
		textBlock9.FontWeight = FontWeight.Medium;
		((ISupportInitialize)textBlock9).EndInit();
		Avalonia.Controls.Controls children9 = stackPanel11.Children;
		Grid grid9;
		Grid grid8 = (grid9 = new Grid());
		((ISupportInitialize)grid8).BeginInit();
		children9.Add(grid8);
		ColumnDefinitions columnDefinitions2 = new ColumnDefinitions();
		columnDefinitions2.Capacity = 2;
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid9.ColumnDefinitions = columnDefinitions2;
		grid9.ColumnSpacing = 8.0;
		Avalonia.Controls.Controls children10 = grid9.Children;
		TextBox textBox2;
		TextBox textBox = (textBox2 = new TextBox());
		((ISupportInitialize)textBox).BeginInit();
		children10.Add(textBox);
		textBox2.Name = "NewPlaceIdTextBox";
		element = textBox2;
		context.AvaloniaNameScope.Register("NewPlaceIdTextBox", element);
		textBox2.PlaceholderText = Strings.Menu_FlagProfiles_PlaceIdWatermark;
		((ISupportInitialize)textBox2).EndInit();
		Avalonia.Controls.Controls children11 = grid9.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children11.Add(button);
		button2.Name = "AddPlaceButton";
		element = button2;
		context.AvaloniaNameScope.Register("AddPlaceButton", element);
		Grid.SetColumn(button2, 1);
		button2.Content = Strings.Common_Add;
		button2.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.AddPlaceButton_Click), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button2.MinWidth = 80.0;
		((ISupportInitialize)button2).EndInit();
		((ISupportInitialize)grid9).EndInit();
		Avalonia.Controls.Controls children12 = stackPanel11.Children;
		TextBlock textBlock11;
		TextBlock textBlock10 = (textBlock11 = new TextBlock());
		((ISupportInitialize)textBlock10).BeginInit();
		children12.Add(textBlock10);
		textBlock11.Text = Strings.Menu_FlagProfiles_CurrentPlaceIds;
		textBlock11.FontSize = 12.0;
		textBlock11.FontWeight = FontWeight.Medium;
		((ISupportInitialize)textBlock11).EndInit();
		Avalonia.Controls.Controls children13 = stackPanel11.Children;
		ListBox listBox5;
		ListBox listBox4 = (listBox5 = new ListBox());
		((ISupportInitialize)listBox4).BeginInit();
		children13.Add(listBox4);
		listBox5.Name = "PlaceIdsListBox";
		element = listBox5;
		context.AvaloniaNameScope.Register("PlaceIdsListBox", element);
		listBox5.Height = 120.0;
		listBox5.AddHandler(SelectingItemsControl.SelectionChangedEvent, context.RootObject.PlaceIdsListBox_SelectionChanged);
		((ISupportInitialize)listBox5).EndInit();
		Avalonia.Controls.Controls children14 = stackPanel11.Children;
		TextBlock textBlock13;
		TextBlock textBlock12 = (textBlock13 = new TextBlock());
		((ISupportInitialize)textBlock12).BeginInit();
		children14.Add(textBlock12);
		TextBlock textBlock14 = (textBlock6 = textBlock13);
		context.PushParent(textBlock6);
		TextBlock textBlock15 = textBlock6;
		textBlock15.Name = "PlaceIdInfoText";
		element = textBlock15;
		context.AvaloniaNameScope.Register("PlaceIdInfoText", element);
		textBlock15.Text = Strings.Menu_FlagProfiles_SelectProfile;
		StyledProperty<IBrush?> foregroundProperty2 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("SystemFillColorSecondaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding4 = dynamicResourceExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock15.Bind(foregroundProperty2, binding4);
		textBlock15.FontSize = 12.0;
		textBlock15.HorizontalAlignment = HorizontalAlignment.Center;
		textBlock15.IsVisible = false;
		textBlock15.Margin = new Thickness(0.0, 0.0, 0.0, -8.0);
		context.PopParent();
		((ISupportInitialize)textBlock14).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel10).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel5).EndInit();
		context.PopParent();
		((ISupportInitialize)tabItem5).EndInit();
		ItemCollection items3 = tabControl4.Items;
		TabItem tabItem9;
		TabItem tabItem8 = (tabItem9 = new TabItem());
		((ISupportInitialize)tabItem8).BeginInit();
		items3.Add(tabItem8);
		tabItem9.Header = Strings.Menu_Save;
		Lucide lucide6;
		Lucide lucide5 = (lucide6 = new Lucide());
		((ISupportInitialize)lucide5).BeginInit();
		TabItemHelper.SetIcon(tabItem9, lucide5);
		lucide6.Icon = LucideIconNames.Plus;
		((ISupportInitialize)lucide6).EndInit();
		StackPanel stackPanel13;
		StackPanel stackPanel12 = (stackPanel13 = new StackPanel());
		((ISupportInitialize)stackPanel12).BeginInit();
		tabItem9.Content = stackPanel12;
		stackPanel13.Spacing = 12.0;
		stackPanel13.Margin = new Thickness(0.0, 0.0, 0.0, 8.0);
		Avalonia.Controls.Controls children15 = stackPanel13.Children;
		TextBox textBox4;
		TextBox textBox3 = (textBox4 = new TextBox());
		((ISupportInitialize)textBox3).BeginInit();
		children15.Add(textBox3);
		textBox4.Name = "SaveProfile";
		element = textBox4;
		context.AvaloniaNameScope.Register("SaveProfile", element);
		textBox4.PlaceholderText = "Profile Name";
		((ISupportInitialize)textBox4).EndInit();
		((ISupportInitialize)stackPanel13).EndInit();
		((ISupportInitialize)tabItem9).EndInit();
		ItemCollection items4 = tabControl4.Items;
		TabItem tabItem11;
		TabItem tabItem10 = (tabItem11 = new TabItem());
		((ISupportInitialize)tabItem10).BeginInit();
		items4.Add(tabItem10);
		TabItem tabItem12 = (tabItem6 = tabItem11);
		context.PushParent(tabItem6);
		TabItem tabItem13 = tabItem6;
		tabItem13.Header = Strings.Menu_Load;
		Lucide lucide8;
		Lucide lucide7 = (lucide8 = new Lucide());
		((ISupportInitialize)lucide7).BeginInit();
		TabItemHelper.SetIcon(tabItem13, lucide7);
		lucide8.Icon = LucideIconNames.List;
		((ISupportInitialize)lucide8).EndInit();
		StackPanel stackPanel15;
		StackPanel stackPanel14 = (stackPanel15 = new StackPanel());
		((ISupportInitialize)stackPanel14).BeginInit();
		tabItem13.Content = stackPanel14;
		StackPanel stackPanel16 = (stackPanel6 = stackPanel15);
		context.PushParent(stackPanel6);
		StackPanel stackPanel17 = stackPanel6;
		stackPanel17.Spacing = 12.0;
		stackPanel17.Margin = new Thickness(0.0, 0.0, 0.0, 8.0);
		Avalonia.Controls.Controls children16 = stackPanel17.Children;
		StackPanel stackPanel19;
		StackPanel stackPanel18 = (stackPanel19 = new StackPanel());
		((ISupportInitialize)stackPanel18).BeginInit();
		children16.Add(stackPanel18);
		StackPanel stackPanel20 = (stackPanel6 = stackPanel19);
		context.PushParent(stackPanel6);
		StackPanel stackPanel21 = stackPanel6;
		stackPanel21.Spacing = 12.0;
		Avalonia.Controls.Controls children17 = stackPanel21.Children;
		Grid grid11;
		Grid grid10 = (grid11 = new Grid());
		((ISupportInitialize)grid10).BeginInit();
		children17.Add(grid10);
		grid11.Name = "RenamePanel";
		element = grid11;
		context.AvaloniaNameScope.Register("RenamePanel", element);
		ColumnDefinitions columnDefinitions3 = new ColumnDefinitions();
		columnDefinitions3.Capacity = 4;
		columnDefinitions3.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions3.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions3.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions3.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid11.ColumnDefinitions = columnDefinitions3;
		grid11.ColumnSpacing = 8.0;
		Avalonia.Controls.Controls children18 = grid11.Children;
		TextBox textBox6;
		TextBox textBox5 = (textBox6 = new TextBox());
		((ISupportInitialize)textBox5).BeginInit();
		children18.Add(textBox5);
		Grid.SetColumn(textBox6, 0);
		textBox6.Name = "RenameTextBox";
		element = textBox6;
		context.AvaloniaNameScope.Register("RenameTextBox", element);
		textBox6.PlaceholderText = "Rename Profile";
		((ISupportInitialize)textBox6).EndInit();
		Avalonia.Controls.Controls children19 = grid11.Children;
		Button button5;
		Button button4 = (button5 = new Button());
		((ISupportInitialize)button4).BeginInit();
		children19.Add(button4);
		Grid.SetColumn(button5, 1);
		button5.Content = Strings.Common_Rename;
		button5.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.RenameButton_Click), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button5.MinWidth = 80.0;
		((ISupportInitialize)button5).EndInit();
		Avalonia.Controls.Controls children20 = grid11.Children;
		Button button7;
		Button button6 = (button7 = new Button());
		((ISupportInitialize)button6).BeginInit();
		children20.Add(button6);
		Grid.SetColumn(button7, 2);
		button7.Content = Strings.Common_Copy;
		button7.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.CopyButton_Click), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button7.MinWidth = 80.0;
		((ISupportInitialize)button7).EndInit();
		Avalonia.Controls.Controls children21 = grid11.Children;
		Button button9;
		Button button8 = (button9 = new Button());
		((ISupportInitialize)button8).BeginInit();
		children21.Add(button8);
		Grid.SetColumn(button9, 3);
		button9.Content = Strings.Common_Update;
		button9.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.UpdateButton_Click), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button9.MinWidth = 80.0;
		((ISupportInitialize)button9).EndInit();
		((ISupportInitialize)grid11).EndInit();
		Avalonia.Controls.Controls children22 = stackPanel21.Children;
		Grid grid13;
		Grid grid12 = (grid13 = new Grid());
		((ISupportInitialize)grid12).BeginInit();
		children22.Add(grid12);
		Grid grid14 = (grid4 = grid13);
		context.PushParent(grid4);
		Grid grid15 = grid4;
		Avalonia.Controls.Controls children23 = grid15.Children;
		ListBox listBox7;
		ListBox listBox6 = (listBox7 = new ListBox());
		((ISupportInitialize)listBox6).BeginInit();
		children23.Add(listBox6);
		listBox7.Name = "LoadProfile";
		element = listBox7;
		context.AvaloniaNameScope.Register("LoadProfile", element);
		listBox7.Height = 200.0;
		listBox7.AddHandler(SelectingItemsControl.SelectionChangedEvent, context.RootObject.LoadProfile_SelectionChanged);
		((ISupportInitialize)listBox7).EndInit();
		Avalonia.Controls.Controls children24 = grid15.Children;
		TextBlock textBlock17;
		TextBlock textBlock16 = (textBlock17 = new TextBlock());
		((ISupportInitialize)textBlock16).BeginInit();
		children24.Add(textBlock16);
		TextBlock textBlock18 = (textBlock6 = textBlock17);
		context.PushParent(textBlock6);
		TextBlock textBlock19 = textBlock6;
		textBlock19.Name = "LoadProfileEmptyText";
		element = textBlock19;
		context.AvaloniaNameScope.Register("LoadProfileEmptyText", element);
		textBlock19.Text = Strings.Menu_FlagProfiles_NoProfileFound;
		StyledProperty<IBrush?> foregroundProperty3 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension5 = new DynamicResourceExtension("SystemFillColorSecondaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding5 = dynamicResourceExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock19.Bind(foregroundProperty3, binding5);
		textBlock19.HorizontalAlignment = HorizontalAlignment.Center;
		textBlock19.VerticalAlignment = VerticalAlignment.Center;
		textBlock19.IsVisible = false;
		context.PopParent();
		((ISupportInitialize)textBlock18).EndInit();
		context.PopParent();
		((ISupportInitialize)grid14).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel20).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel16).EndInit();
		context.PopParent();
		((ISupportInitialize)tabItem12).EndInit();
		context.PopParent();
		((ISupportInitialize)tabControl3).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		Avalonia.Controls.Controls children25 = grid5.Children;
		Border border7;
		Border border6 = (border7 = new Border());
		((ISupportInitialize)border6).BeginInit();
		children25.Add(border6);
		Border border8 = (border4 = border7);
		context.PushParent(border4);
		Border border9 = border4;
		Grid.SetRow(border9, 1);
		border9.Padding = new Thickness(15.0, 15.0, 15.0, 15.0);
		StyledProperty<IBrush?> backgroundProperty2 = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension6 = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding6 = dynamicResourceExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border9.Bind(backgroundProperty2, binding6);
		Grid grid17;
		Grid grid16 = (grid17 = new Grid());
		((ISupportInitialize)grid16).BeginInit();
		border9.Child = grid16;
		ColumnDefinitions columnDefinitions4 = new ColumnDefinitions();
		columnDefinitions4.Capacity = 2;
		columnDefinitions4.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions4.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid17.ColumnDefinitions = columnDefinitions4;
		grid17.ColumnSpacing = 12.0;
		Avalonia.Controls.Controls children26 = grid17.Children;
		IconButton iconButton2;
		IconButton iconButton = (iconButton2 = new IconButton());
		((ISupportInitialize)iconButton).BeginInit();
		children26.Add(iconButton);
		iconButton2.Name = "RemovePlaceButton";
		element = iconButton2;
		context.AvaloniaNameScope.Register("RemovePlaceButton", element);
		Grid.SetColumn(iconButton2, 0);
		iconButton2.Classes.Add("Danger");
		iconButton2.Icon = LucideIconNames.Trash2;
		iconButton2.Content = Strings.Menu_FlagProfiles_RemoveSelected;
		iconButton2.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.RemovePlaceButton_Click), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		iconButton2.IsEnabled = false;
		iconButton2.IsVisible = false;
		iconButton2.HorizontalAlignment = HorizontalAlignment.Left;
		((ISupportInitialize)iconButton2).EndInit();
		Avalonia.Controls.Controls children27 = grid17.Children;
		CheckBox checkBox2;
		CheckBox checkBox = (checkBox2 = new CheckBox());
		((ISupportInitialize)checkBox).BeginInit();
		children27.Add(checkBox);
		checkBox2.Name = "ClearFlags";
		element = checkBox2;
		context.AvaloniaNameScope.Register("ClearFlags", element);
		Grid.SetColumn(checkBox2, 0);
		checkBox2.HorizontalAlignment = HorizontalAlignment.Left;
		checkBox2.VerticalAlignment = VerticalAlignment.Center;
		checkBox2.Content = Strings.Menu_FlagProfiles_ClearFlags;
		checkBox2.IsVisible = false;
		((ISupportInitialize)checkBox2).EndInit();
		Avalonia.Controls.Controls children28 = grid17.Children;
		StackPanel stackPanel23;
		StackPanel stackPanel22 = (stackPanel23 = new StackPanel());
		((ISupportInitialize)stackPanel22).BeginInit();
		children28.Add(stackPanel22);
		Grid.SetColumn(stackPanel23, 1);
		stackPanel23.Orientation = Orientation.Horizontal;
		stackPanel23.Spacing = 12.0;
		stackPanel23.HorizontalAlignment = HorizontalAlignment.Right;
		Avalonia.Controls.Controls children29 = stackPanel23.Children;
		IconButton iconButton5;
		IconButton iconButton4 = (iconButton5 = new IconButton());
		((ISupportInitialize)iconButton4).BeginInit();
		children29.Add(iconButton4);
		iconButton5.Name = "DeleteButton";
		element = iconButton5;
		context.AvaloniaNameScope.Register("DeleteButton", element);
		iconButton5.Icon = LucideIconNames.Trash2;
		iconButton5.Classes.Add("Danger");
		iconButton5.Content = Strings.Menu_FlagProfiles_DeleteSelected;
		iconButton5.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.DeleteButton_Click), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		iconButton5.IsVisible = false;
		((ISupportInitialize)iconButton5).EndInit();
		Avalonia.Controls.Controls children30 = stackPanel23.Children;
		Button button11;
		Button button10 = (button11 = new Button());
		((ISupportInitialize)button10).BeginInit();
		children30.Add(button10);
		button11.Name = "OkButton";
		element = button11;
		context.AvaloniaNameScope.Register("OkButton", element);
		button11.Content = Strings.Common_OK;
		button11.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.OKButton_Click), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button11.Width = 100.0;
		button11.IsEnabled = false;
		((ISupportInitialize)button11).EndInit();
		Avalonia.Controls.Controls children31 = stackPanel23.Children;
		Button button13;
		Button button12 = (button13 = new Button());
		((ISupportInitialize)button12).BeginInit();
		children31.Add(button12);
		button13.Content = Strings.Common_Cancel;
		button13.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.CancelButton_Click), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button13.Width = 100.0;
		((ISupportInitialize)button13).EndInit();
		((ISupportInitialize)stackPanel23).EndInit();
		((ISupportInitialize)grid17).EndInit();
		context.PopParent();
		((ISupportInitialize)border8).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(FlagProfilesDialog P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
