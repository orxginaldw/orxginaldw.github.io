using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Data.Converters;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Platform.Storage;
using Avalonia.Styling;
using CompiledAvaloniaXaml;
using FluentAvalonia.UI.Controls;
using ICSharpCode.SharpZipLib.Zip;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.Enums;
using Merostrap.Extensions;
using Merostrap.Resources;
using Merostrap.UI.Elements.Base;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.ViewModels.Dialogs;
using Merostrap.Utility;

namespace Merostrap.UI.Elements.Dialogs;

internal class AddCustomThemeDialog : AvaloniaWindow
{
	[CompilerGenerated]
	private class XamlClosure_17
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<AddCustomThemeDialog> context = CreateContext(P_0);
			context.IntermediateRoot = new UniformGrid();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((AvaloniaObject)obj).SetValue(UniformGrid.ColumnsProperty, 2, BindingPriority.Template);
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<AddCustomThemeDialog> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<AddCustomThemeDialog> context = new XamlIlContext.Context<AddCustomThemeDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FAddCustomThemeDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/AddCustomThemeDialog.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (AddCustomThemeDialog)service;
				}
			}
			return context;
		}

		public static object Build_2(IServiceProvider P_0)
		{
			XamlIlContext.Context<AddCustomThemeDialog> context = CreateContext(P_0);
			context.IntermediateRoot = new TextBlock();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			TextBlock textBlock = (TextBlock)obj;
			context.PushParent(textBlock);
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension2;
			CompiledBindingExtension compiledBindingExtension = (compiledBindingExtension2 = new CompiledBindingExtension());
			context.PushParent(compiledBindingExtension2);
			StaticResourceExtension staticResourceExtension = new StaticResourceExtension("EnumNameConverter");
			context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EData_002ECompiledBinding_002CAvalonia_002EBase_002EConverter_0021Property();
			object? obj2 = staticResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			compiledBindingExtension2.Converter = (IValueConverter)obj2;
			context.PopParent();
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock.Bind(textProperty, binding);
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}
	}

	private const int CreateNewTabId = 0;

	private readonly AddCustomThemeViewModel _viewModel;

	private static readonly FilePickerFileType ZipFileType = new FilePickerFileType(Strings.FileTypes_ZipArchive)
	{
		Patterns = new _003C_003Ez__ReadOnlySingleElementList<string>("*.zip")
	};

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TabControl Tabs;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public bool Created { get; private set; }

	public string ThemeName { get; private set; } = "";

	public bool OpenEditor { get; private set; }

	public AddCustomThemeDialog()
	{
		InitializeComponent();
		_viewModel = new AddCustomThemeViewModel
		{
			Name = GenerateRandomName()
		};
		DataContext = _viewModel;
	}

	private static string GetThemePath(string name)
	{
		return Path.Combine(Paths.CustomThemes, name, "Theme.xml");
	}

	private static string GenerateRandomName()
	{
		int num = Directory.GetDirectories(Paths.CustomThemes).Length + 1;
		string text = string.Format(CultureInfo.CurrentCulture, Strings.CustomTheme_DefaultName, num);
		if (File.Exists(GetThemePath(text)))
		{
			text = string.Format(CultureInfo.CurrentCulture, Strings.CustomTheme_DefaultName, $"{num}-{RandomNumberGenerator.GetInt32(1, 100000)}");
		}
		return text;
	}

	private static string GetUniqueName(string name)
	{
		if (!File.Exists(GetThemePath(name)))
		{
			return name;
		}
		for (int i = 1; i <= 100; i++)
		{
			string text = $"{name}_{i}";
			if (!File.Exists(GetThemePath(text)))
			{
				return text;
			}
		}
		return $"{name}_{RandomNumberGenerator.GetInt32(101, 1000000)}";
	}

	private static async Task CreateCustomTheme(string name, CustomThemeTemplate template)
	{
		string text = Path.Combine(Paths.CustomThemes, name);
		if (Directory.Exists(text))
		{
			Directory.Delete(text, recursive: true);
		}
		Directory.CreateDirectory(text);
		string themeFilePath = Path.Combine(text, "Theme.xml");
		await File.WriteAllTextAsync(themeFilePath, await template.GetFileContents());
	}

	private bool ValidateCreateNew()
	{
		_viewModel.NameError = "";
		if (string.IsNullOrEmpty(_viewModel.Name))
		{
			_viewModel.NameError = Strings.CustomTheme_Add_Errors_NameEmpty;
			App.Logger.Error("Name is empty");
			return false;
		}
		PathValidator.ValidationResult validationResult = PathValidator.IsFileNameValid(_viewModel.Name);
		if (validationResult != PathValidator.ValidationResult.Ok)
		{
			AddCustomThemeViewModel viewModel = _viewModel;
			viewModel.NameError = validationResult switch
			{
				PathValidator.ValidationResult.IllegalCharacter => Strings.CustomTheme_Add_Errors_NameIllegalCharacters, 
				PathValidator.ValidationResult.ReservedFileName => Strings.CustomTheme_Add_Errors_NameReserved, 
				_ => Strings.CustomTheme_Add_Errors_Unknown, 
			};
			return false;
		}
		if (File.Exists(GetThemePath(_viewModel.Name)))
		{
			_viewModel.NameError = Strings.CustomTheme_Add_Errors_NameTaken;
			App.Logger.Error("Theme name already exists");
			return false;
		}
		App.Logger.Info("Validation passed for theme: " + _viewModel.Name);
		return true;
	}

	private static bool ValidateImport(AddCustomThemeViewModel viewModel)
	{
		viewModel.FileError = "";
		if (string.IsNullOrEmpty(viewModel.FilePath) || !viewModel.FilePath.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
		{
			viewModel.FileError = Strings.CustomTheme_Add_Errors_FileNotZip;
			return false;
		}
		try
		{
			using ZipArchive zipArchive = System.IO.Compression.ZipFile.OpenRead(viewModel.FilePath);
			if (!zipArchive.Entries.Any((ZipArchiveEntry entry) => Path.GetFileName(entry.FullName).Equals("Theme.xml", StringComparison.OrdinalIgnoreCase)))
			{
				viewModel.FileError = Strings.CustomTheme_Add_Errors_ZipMissingThemeFile;
				return false;
			}
			return true;
		}
		catch (Exception argument)
		{
			App.Logger.Error("Unhandled exception:", argument);
			viewModel.FileError = Strings.CustomTheme_Add_Errors_ZipInvalidData;
			return false;
		}
	}

	private async void OnOkButtonClicked(object sender, RoutedEventArgs e)
	{
		if (_viewModel.SelectedTab == 0)
		{
			if (ValidateCreateNew())
			{
				await CreateCustomTheme(_viewModel.Name, _viewModel.Template);
				Created = true;
				ThemeName = _viewModel.Name;
				OpenEditor = true;
				Close();
			}
		}
		else if (ValidateImport(_viewModel))
		{
			await Import();
		}
	}

	private async Task Import()
	{
		string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(_viewModel.FilePath);
		string name = GetUniqueName(fileNameWithoutExtension);
		string finalDir = Path.Combine(Paths.CustomThemes, name);
		string staging = Path.Combine(Path.GetTempPath(), "theme-import-" + Guid.NewGuid().ToString("N"));
		try
		{
			Directory.CreateDirectory(staging);
			Directory.CreateDirectory(finalDir);
			await Task.Run(() =>
			{
				new FastZip().ExtractZip(_viewModel.FilePath, staging, null);
				string[] fileSystemEntries = Directory.GetFileSystemEntries(staging);
				if (fileSystemEntries.Length == 1 && Directory.Exists(fileSystemEntries[0]))
				{
					Directory.Delete(finalDir, recursive: true);
					MoveDirectory(fileSystemEntries[0], finalDir);
				}
				else
				{
					string[] array = fileSystemEntries;
					foreach (string text in array)
					{
						string text2 = Path.Combine(finalDir, Path.GetFileName(text));
						if (Directory.Exists(text))
						{
							MoveDirectory(text, text2);
						}
						else
						{
							File.Copy(text, text2, overwrite: true);
						}
					}
				}
			});
			Created = true;
			ThemeName = name;
			OpenEditor = false;
			Close();
		}
		catch (Exception argument)
		{
			App.Logger.Error("Unhandled exception:", argument);
			_viewModel.FileError = Strings.CustomTheme_Add_Errors_Unknown;
		}
		finally
		{
			if (Directory.Exists(staging))
			{
				Directory.Delete(staging, recursive: true);
			}
		}
	}

	private async void OnImportButtonClicked(object sender, RoutedEventArgs e)
	{
		TopLevel topLevel = TopLevel.GetTopLevel(this);
		if (topLevel != null)
		{
			IReadOnlyList<IStorageFile> readOnlyList = await topLevel.StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
			{
				Title = Strings.Common_ImportFromFile,
				FileTypeFilter = new _003C_003Ez__ReadOnlySingleElementList<FilePickerFileType>(ZipFileType),
				AllowMultiple = false
			});
			if (readOnlyList.Count > 0)
			{
				_viewModel.FilePath = readOnlyList[0].Path.LocalPath;
			}
		}
	}

	private void OnCancelButtonClicked(object sender, RoutedEventArgs e)
	{
		Close();
	}

	private static void MoveDirectory(string source, string dest)
	{
		if (AreOnSameVolume(source, dest))
		{
			try
			{
				Directory.Move(source, dest);
				return;
			}
			catch (IOException)
			{
			}
		}
		CopyDirectory(source, dest);
		Directory.Delete(source, recursive: true);
	}

	private static bool AreOnSameVolume(string path1, string path2)
	{
		return string.Equals(Path.GetPathRoot(path1), Path.GetPathRoot(path2), StringComparison.OrdinalIgnoreCase);
	}

	private static void CopyDirectory(string source, string dest)
	{
		Directory.CreateDirectory(dest);
		string[] files = Directory.GetFiles(source);
		foreach (string text in files)
		{
			File.Copy(text, Path.Combine(dest, Path.GetFileName(text)), overwrite: true);
		}
		files = Directory.GetDirectories(source);
		foreach (string text2 in files)
		{
			CopyDirectory(text2, Path.Combine(dest, Path.GetFileName(text2)));
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		Tabs = this.FindNameScope()?.Find<TabControl>("Tabs");
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, AddCustomThemeDialog P_1)
	{
		XamlIlContext.Context<AddCustomThemeDialog> context = new XamlIlContext.Context<AddCustomThemeDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FAddCustomThemeDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/AddCustomThemeDialog.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Title = Strings.AddCustomTheme_Title;
		P_1.Width = 480.0;
		P_1.CanResize = false;
		P_1.SizeToContent = SizeToContent.Height;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid5.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid5.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children.Add(border);
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Border border5 = border4;
		Grid.SetRow(border5, 0);
		border5.Margin = new Thickness(16.0, 16.0, 16.0, 16.0);
		border5.CornerRadius = new CornerRadius(8.0, 8.0, 8.0, 8.0);
		border5.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("CardStrokeColorDefaultBrush");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(borderBrushProperty, binding);
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(backgroundProperty, binding2);
		TabControl tabControl2;
		TabControl tabControl = (tabControl2 = new TabControl());
		((ISupportInitialize)tabControl).BeginInit();
		border5.Child = tabControl;
		TabControl tabControl4;
		TabControl tabControl3 = (tabControl4 = tabControl2);
		context.PushParent(tabControl4);
		tabControl4.Name = "Tabs";
		object element = tabControl4;
		context.AvaloniaNameScope.Register("Tabs", element);
		DirectProperty<SelectingItemsControl, int> selectedIndexProperty = SelectingItemsControl.SelectedIndexProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EAddCustomThemeViewModel_002CMerostrap_002ESelectedTab_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = SelectingItemsControl.SelectedIndexProperty;
		CompiledBinding binding3 = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		tabControl4.Bind(selectedIndexProperty, binding3);
		tabControl4.ItemsPanel = new ItemsPanelTemplate
		{
			Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_17.Build_1), context)
		};
		Styles styles = tabControl4.Styles;
		Style style = new Style();
		style.Selector = ((Selector?)null).OfType(typeof(TabItem));
		Setter setter = new Setter();
		setter.Property = Layoutable.HorizontalAlignmentProperty;
		setter.Value = HorizontalAlignment.Stretch;
		style.Add(setter);
		Setter setter2 = new Setter();
		setter2.Property = ContentControl.HorizontalContentAlignmentProperty;
		setter2.Value = HorizontalAlignment.Center;
		style.Add(setter2);
		Setter setter3 = new Setter();
		setter3.Property = TemplatedControl.FontSizeProperty;
		setter3.Value = 18.0;
		style.Add(setter3);
		styles.Add(style);
		ItemCollection items = tabControl4.Items;
		TabItem tabItem2;
		TabItem tabItem = (tabItem2 = new TabItem());
		((ISupportInitialize)tabItem).BeginInit();
		items.Add(tabItem);
		TabItem tabItem4;
		TabItem tabItem3 = (tabItem4 = tabItem2);
		context.PushParent(tabItem4);
		TabItem tabItem5 = tabItem4;
		tabItem5.Header = Strings.Common_CreateNew;
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		TabItemHelper.SetIcon(tabItem5, lucide);
		lucide2.Icon = LucideIconNames.Plus;
		((ISupportInitialize)lucide2).EndInit();
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		tabItem5.Content = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		StackPanel stackPanel5 = stackPanel4;
		stackPanel5.Spacing = 12.0;
		stackPanel5.Margin = new Thickness(0.0, 0.0, 0.0, 8.0);
		Avalonia.Controls.Controls children2 = stackPanel5.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children2.Add(grid6);
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 2;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(75.0, GridUnitType.Pixel)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid9.ColumnDefinitions = columnDefinitions;
		RowDefinitions rowDefinitions2 = new RowDefinitions();
		rowDefinitions2.Capacity = 2;
		rowDefinitions2.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid9.RowDefinitions = rowDefinitions2;
		grid9.ColumnSpacing = 12.0;
		Avalonia.Controls.Controls children3 = grid9.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children3.Add(textBlock);
		textBlock2.Text = Strings.Common_Name;
		textBlock2.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)textBlock2).EndInit();
		Avalonia.Controls.Controls children4 = grid9.Children;
		TextBox textBox2;
		TextBox textBox = (textBox2 = new TextBox());
		((ISupportInitialize)textBox).BeginInit();
		children4.Add(textBox);
		TextBox textBox4;
		TextBox textBox3 = (textBox4 = textBox2);
		context.PushParent(textBox4);
		Grid.SetColumn(textBox4, 1);
		StyledProperty<string?> textProperty = TextBox.TextProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EAddCustomThemeViewModel_002CMerostrap_002EName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBox.TextProperty;
		CompiledBinding binding4 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBox4.Bind(textProperty, binding4);
		textBox4.PlaceholderText = "Enter theme name";
		context.PopParent();
		((ISupportInitialize)textBox3).EndInit();
		Avalonia.Controls.Controls children5 = grid9.Children;
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		children5.Add(textBlock3);
		TextBlock textBlock6;
		TextBlock textBlock5 = (textBlock6 = textBlock4);
		context.PushParent(textBlock6);
		TextBlock textBlock7 = textBlock6;
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EAddCustomThemeViewModel_002CMerostrap_002EHasNameError_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding5 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock7.Bind(isVisibleProperty, binding5);
		StyledProperty<string?> textProperty2 = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EAddCustomThemeViewModel_002CMerostrap_002ENameError_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding6 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock7.Bind(textProperty2, binding6);
		Grid.SetRow(textBlock7, 1);
		Grid.SetColumn(textBlock7, 1);
		StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("SystemFillColorCriticalBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding7 = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock7.Bind(foregroundProperty, binding7);
		textBlock7.FontSize = 12.0;
		textBlock7.HorizontalAlignment = HorizontalAlignment.Left;
		context.PopParent();
		((ISupportInitialize)textBlock5).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		Avalonia.Controls.Controls children6 = stackPanel5.Children;
		Grid grid11;
		Grid grid10 = (grid11 = new Grid());
		((ISupportInitialize)grid10).BeginInit();
		children6.Add(grid10);
		Grid grid12 = (grid4 = grid11);
		context.PushParent(grid4);
		Grid grid13 = grid4;
		ColumnDefinitions columnDefinitions2 = new ColumnDefinitions();
		columnDefinitions2.Capacity = 2;
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(75.0, GridUnitType.Pixel)));
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid13.ColumnDefinitions = columnDefinitions2;
		grid13.ColumnSpacing = 12.0;
		Avalonia.Controls.Controls children7 = grid13.Children;
		TextBlock textBlock9;
		TextBlock textBlock8 = (textBlock9 = new TextBlock());
		((ISupportInitialize)textBlock8).BeginInit();
		children7.Add(textBlock8);
		textBlock9.Text = Strings.Common_Template;
		textBlock9.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)textBlock9).EndInit();
		Avalonia.Controls.Controls children8 = grid13.Children;
		ComboBox comboBox2;
		ComboBox comboBox = (comboBox2 = new ComboBox());
		((ISupportInitialize)comboBox).BeginInit();
		children8.Add(comboBox);
		ComboBox comboBox4;
		ComboBox comboBox3 = (comboBox4 = comboBox2);
		context.PushParent(comboBox4);
		Grid.SetColumn(comboBox4, 1);
		comboBox4.HorizontalAlignment = HorizontalAlignment.Stretch;
		StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EAddCustomThemeViewModel_002CMerostrap_002ETemplates_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding8 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		comboBox4.Bind(itemsSourceProperty, binding8);
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EAddCustomThemeViewModel_002CMerostrap_002ETemplate_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = SelectingItemsControl.SelectedItemProperty;
		CompiledBinding compiledBinding = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_10(comboBox4, compiledBinding);
		DataTemplate dataTemplate;
		DataTemplate itemTemplate = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_17.Build_2), context);
		context.PopParent();
		comboBox4.ItemTemplate = itemTemplate;
		context.PopParent();
		((ISupportInitialize)comboBox3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid12).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)tabItem3).EndInit();
		ItemCollection items2 = tabControl4.Items;
		TabItem tabItem7;
		TabItem tabItem6 = (tabItem7 = new TabItem());
		((ISupportInitialize)tabItem6).BeginInit();
		items2.Add(tabItem6);
		TabItem tabItem8 = (tabItem4 = tabItem7);
		context.PushParent(tabItem4);
		TabItem tabItem9 = tabItem4;
		tabItem9.Header = Strings.Common_Import;
		Lucide lucide4;
		Lucide lucide3 = (lucide4 = new Lucide());
		((ISupportInitialize)lucide3).BeginInit();
		TabItemHelper.SetIcon(tabItem9, lucide3);
		lucide4.Icon = LucideIconNames.FolderDown;
		((ISupportInitialize)lucide4).EndInit();
		StackPanel stackPanel7;
		StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
		((ISupportInitialize)stackPanel6).BeginInit();
		tabItem9.Content = stackPanel6;
		StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
		context.PushParent(stackPanel4);
		StackPanel stackPanel9 = stackPanel4;
		stackPanel9.Spacing = 12.0;
		stackPanel9.Margin = new Thickness(0.0, 0.0, 0.0, 8.0);
		Avalonia.Controls.Controls children9 = stackPanel9.Children;
		TextBlock textBlock11;
		TextBlock textBlock10 = (textBlock11 = new TextBlock());
		((ISupportInitialize)textBlock10).BeginInit();
		children9.Add(textBlock10);
		TextBlock textBlock12 = (textBlock6 = textBlock11);
		context.PushParent(textBlock6);
		TextBlock textBlock13 = textBlock6;
		StyledProperty<string?> textProperty3 = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EAddCustomThemeViewModel_002CMerostrap_002EFilePath_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding9 = compiledBindingExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock13.Bind(textProperty3, binding9);
		StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EAddCustomThemeViewModel_002CMerostrap_002EHasFilePath_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding10 = compiledBindingExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock13.Bind(isVisibleProperty2, binding10);
		textBlock13.TextAlignment = TextAlignment.Center;
		textBlock13.TextWrapping = TextWrapping.Wrap;
		context.PopParent();
		((ISupportInitialize)textBlock12).EndInit();
		Avalonia.Controls.Controls children10 = stackPanel9.Children;
		IconButton iconButton2;
		IconButton iconButton = (iconButton2 = new IconButton());
		((ISupportInitialize)iconButton).BeginInit();
		children10.Add(iconButton);
		iconButton2.Content = Strings.Common_ImportFromFile;
		iconButton2.Icon = LucideIconNames.FolderArchive;
		iconButton2.HorizontalAlignment = HorizontalAlignment.Stretch;
		iconButton2.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.OnImportButtonClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		((ISupportInitialize)iconButton2).EndInit();
		Avalonia.Controls.Controls children11 = stackPanel9.Children;
		TextBlock textBlock15;
		TextBlock textBlock14 = (textBlock15 = new TextBlock());
		((ISupportInitialize)textBlock14).BeginInit();
		children11.Add(textBlock14);
		TextBlock textBlock16 = (textBlock6 = textBlock15);
		context.PushParent(textBlock6);
		TextBlock textBlock17 = textBlock6;
		StyledProperty<bool> isVisibleProperty3 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EAddCustomThemeViewModel_002CMerostrap_002EHasFileError_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding11 = compiledBindingExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock17.Bind(isVisibleProperty3, binding11);
		StyledProperty<string?> textProperty4 = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EAddCustomThemeViewModel_002CMerostrap_002EFileError_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding12 = compiledBindingExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock17.Bind(textProperty4, binding12);
		StyledProperty<IBrush?> foregroundProperty2 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("SystemFillColorCriticalBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding13 = dynamicResourceExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock17.Bind(foregroundProperty2, binding13);
		textBlock17.TextAlignment = TextAlignment.Center;
		context.PopParent();
		((ISupportInitialize)textBlock16).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel8).EndInit();
		context.PopParent();
		((ISupportInitialize)tabItem8).EndInit();
		context.PopParent();
		((ISupportInitialize)tabControl3).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		Avalonia.Controls.Controls children12 = grid5.Children;
		Border border7;
		Border border6 = (border7 = new Border());
		((ISupportInitialize)border6).BeginInit();
		children12.Add(border6);
		Border border8 = (border4 = border7);
		context.PushParent(border4);
		Border border9 = border4;
		Grid.SetRow(border9, 1);
		border9.Padding = new Thickness(15.0, 15.0, 15.0, 15.0);
		StyledProperty<IBrush?> backgroundProperty2 = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension5 = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding14 = dynamicResourceExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border9.Bind(backgroundProperty2, binding14);
		StackPanel stackPanel11;
		StackPanel stackPanel10 = (stackPanel11 = new StackPanel());
		((ISupportInitialize)stackPanel10).BeginInit();
		border9.Child = stackPanel10;
		stackPanel11.Orientation = Orientation.Horizontal;
		stackPanel11.HorizontalAlignment = HorizontalAlignment.Right;
		stackPanel11.Spacing = 12.0;
		Avalonia.Controls.Controls children13 = stackPanel11.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children13.Add(button);
		button2.Content = Strings.Common_OK;
		button2.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.OnOkButtonClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button2.Width = 100.0;
		((ISupportInitialize)button2).EndInit();
		Avalonia.Controls.Controls children14 = stackPanel11.Children;
		Button button5;
		Button button4 = (button5 = new Button());
		((ISupportInitialize)button4).BeginInit();
		children14.Add(button4);
		button5.Content = Strings.Common_Cancel;
		button5.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.OnCancelButtonClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button5.Width = 100.0;
		((ISupportInitialize)button5).EndInit();
		((ISupportInitialize)stackPanel11).EndInit();
		context.PopParent();
		((ISupportInitialize)border8).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(AddCustomThemeDialog P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
