using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Documents;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Media.Immutable;
using CompiledAvaloniaXaml;
using FluentAvalonia.UI.Controls;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.Resources;
using Merostrap.UI.Elements.Base;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.ViewModels.Dialogs;

namespace Merostrap.UI.Elements.Dialogs;

internal class PrivateServerJoinDialog : AvaloniaWindow
{
	[CompilerGenerated]
	private class XamlClosure_21
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<PrivateServerJoinDialog> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Border border = (Border)obj;
			context.PushParent(border);
			Border border2 = border;
			border2.Margin = new Thickness(0.0, 0.0, 0.0, 8.0);
			border2.Padding = new Thickness(10.0, 10.0, 10.0, 10.0);
			border2.Background = new ImmutableSolidColorBrush(855638016u);
			border2.CornerRadius = new CornerRadius(6.0, 6.0, 6.0, 6.0);
			Grid grid2;
			Grid grid = (grid2 = new Grid());
			((ISupportInitialize)grid).BeginInit();
			border2.Child = grid;
			Grid grid4;
			Grid grid3 = (grid4 = grid2);
			context.PushParent(grid4);
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 3;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(48.0, GridUnitType.Pixel)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
			grid4.ColumnDefinitions = columnDefinitions;
			Avalonia.Controls.Controls children = grid4.Children;
			Border border4;
			Border border3 = (border4 = new Border());
			((ISupportInitialize)border3).BeginInit();
			children.Add(border3);
			Border border5 = (border = border4);
			context.PushParent(border);
			Border border6 = border;
			Grid.SetColumn(border6, 0);
			border6.Width = 40.0;
			border6.Height = 40.0;
			border6.CornerRadius = new CornerRadius(20.0, 20.0, 20.0, 20.0);
			border6.ClipToBounds = true;
			border6.Background = new ImmutableSolidColorBrush(855638016u);
			RemoteImage remoteImage2;
			RemoteImage remoteImage = (remoteImage2 = new RemoteImage());
			((ISupportInitialize)remoteImage).BeginInit();
			border6.Child = remoteImage;
			RemoteImage remoteImage4;
			RemoteImage remoteImage3 = (remoteImage4 = remoteImage2);
			context.PushParent(remoteImage4);
			StyledProperty<string?> urlProperty = RemoteImage.UrlProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EPrivateServerInfo_002CMerostrap_002EOwnerAvatarUrl_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = RemoteImage.UrlProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			remoteImage4.Bind(urlProperty, binding);
			remoteImage4.Stretch = Stretch.UniformToFill;
			RenderOptions.SetBitmapInterpolationMode(remoteImage4, BitmapInterpolationMode.LowQuality);
			context.PopParent();
			((ISupportInitialize)remoteImage3).EndInit();
			context.PopParent();
			((ISupportInitialize)border5).EndInit();
			Avalonia.Controls.Controls children2 = grid4.Children;
			StackPanel stackPanel2;
			StackPanel stackPanel = (stackPanel2 = new StackPanel());
			((ISupportInitialize)stackPanel).BeginInit();
			children2.Add(stackPanel);
			StackPanel stackPanel4;
			StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
			context.PushParent(stackPanel4);
			Grid.SetColumn(stackPanel4, 1);
			stackPanel4.Margin = new Thickness(8.0, 0.0, 8.0, 0.0);
			Avalonia.Controls.Controls children3 = stackPanel4.Children;
			TextBlock textBlock2;
			TextBlock textBlock = (textBlock2 = new TextBlock());
			((ISupportInitialize)textBlock).BeginInit();
			children3.Add(textBlock);
			TextBlock textBlock4;
			TextBlock textBlock3 = (textBlock4 = textBlock2);
			context.PushParent(textBlock4);
			TextBlock textBlock5 = textBlock4;
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EPrivateServerInfo_002CMerostrap_002EName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock5.Bind(textProperty, binding2);
			textBlock5.FontWeight = FontWeight.DemiBold;
			textBlock5.TextTrimming = TextTrimming.CharacterEllipsis;
			context.PopParent();
			((ISupportInitialize)textBlock3).EndInit();
			Avalonia.Controls.Controls children4 = stackPanel4.Children;
			TextBlock textBlock7;
			TextBlock textBlock6 = (textBlock7 = new TextBlock());
			((ISupportInitialize)textBlock6).BeginInit();
			children4.Add(textBlock6);
			TextBlock textBlock8 = (textBlock4 = textBlock7);
			context.PushParent(textBlock4);
			TextBlock textBlock9 = textBlock4;
			StyledProperty<string?> textProperty2 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EPrivateServerInfo_002CMerostrap_002EOwnerName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding3 = compiledBindingExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock9.Bind(textProperty2, binding3);
			textBlock9.FontSize = 11.0;
			textBlock9.Opacity = 0.6;
			context.PopParent();
			((ISupportInitialize)textBlock8).EndInit();
			Avalonia.Controls.Controls children5 = stackPanel4.Children;
			TextBlock textBlock11;
			TextBlock textBlock10 = (textBlock11 = new TextBlock());
			((ISupportInitialize)textBlock10).BeginInit();
			children5.Add(textBlock10);
			TextBlock textBlock12 = (textBlock4 = textBlock11);
			context.PushParent(textBlock4);
			TextBlock textBlock13 = textBlock4;
			textBlock13.Margin = new Thickness(0.0, 4.0, 0.0, 0.0);
			textBlock13.FontSize = 11.0;
			InlineCollection? inlines = textBlock13.Inlines;
			Run run = new Run();
			((ISupportInitialize)run).BeginInit();
			Run run2 = run;
			context.PushParent(run2);
			Run run3 = run2;
			StyledProperty<string?> textProperty3 = Run.TextProperty;
			CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EPrivateServerInfo_002CMerostrap_002ECurrentPlayers_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Run.TextProperty;
			CompiledBinding binding4 = compiledBindingExtension4.ProvideValue(context);
			context.ProvideTargetProperty = null;
			run3.Bind(textProperty3, binding4);
			context.PopParent();
			((ISupportInitialize)run).EndInit();
			inlines.Add(run);
			textBlock13.Inlines.Add(" ");
			InlineCollection? inlines2 = textBlock13.Inlines;
			Run run4 = new Run();
			((ISupportInitialize)run4).BeginInit();
			run4.Text = "/";
			((ISupportInitialize)run4).EndInit();
			inlines2.Add(run4);
			textBlock13.Inlines.Add(" ");
			InlineCollection? inlines3 = textBlock13.Inlines;
			Run run5 = new Run();
			((ISupportInitialize)run5).BeginInit();
			run2 = run5;
			context.PushParent(run2);
			Run run6 = run2;
			StyledProperty<string?> textProperty4 = Run.TextProperty;
			CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EPrivateServerInfo_002CMerostrap_002EMaxPlayers_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Run.TextProperty;
			CompiledBinding binding5 = compiledBindingExtension5.ProvideValue(context);
			context.ProvideTargetProperty = null;
			run6.Bind(textProperty4, binding5);
			context.PopParent();
			((ISupportInitialize)run5).EndInit();
			inlines3.Add(run5);
			textBlock13.Inlines.Add(" ");
			InlineCollection? inlines4 = textBlock13.Inlines;
			Run run7 = new Run();
			((ISupportInitialize)run7).BeginInit();
			run7.Text = " ";
			((ISupportInitialize)run7).EndInit();
			inlines4.Add(run7);
			textBlock13.Inlines.Add(" ");
			InlineCollection? inlines5 = textBlock13.Inlines;
			Run run8 = new Run();
			((ISupportInitialize)run8).BeginInit();
			run8.Text = Strings.Menu_QuickPlay_Players;
			((ISupportInitialize)run8).EndInit();
			inlines5.Add(run8);
			context.PopParent();
			((ISupportInitialize)textBlock12).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel3).EndInit();
			Avalonia.Controls.Controls children6 = grid4.Children;
			IconButton iconButton2;
			IconButton iconButton = (iconButton2 = new IconButton());
			((ISupportInitialize)iconButton).BeginInit();
			children6.Add(iconButton);
			IconButton iconButton4;
			IconButton iconButton3 = (iconButton4 = iconButton2);
			context.PushParent(iconButton4);
			Grid.SetColumn(iconButton4, 2);
			iconButton4.VerticalAlignment = VerticalAlignment.Center;
			iconButton4.Content = "Join";
			iconButton4.Icon = LucideIconNames.Play;
			StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().ElementName(context.AvaloniaNameScope, "RootDialog").Property(StyledElement.DataContextProperty, PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EPrivateServerJoinDialogViewModel_002CMerostrap_002EJoinPrivateServerCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)
				.Build());
			context.ProvideTargetProperty = Button.CommandProperty;
			CompiledBinding binding6 = compiledBindingExtension6.ProvideValue(context);
			context.ProvideTargetProperty = null;
			iconButton4.Bind(commandProperty, binding6);
			CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EPrivateServerInfo_002CMerostrap_002EAccessCode_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Button.CommandParameterProperty;
			CompiledBinding compiledBinding = compiledBindingExtension7.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_6(iconButton4, compiledBinding);
			iconButton4.Classes.Add("Primary");
			context.PopParent();
			((ISupportInitialize)iconButton3).EndInit();
			context.PopParent();
			((ISupportInitialize)grid3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<PrivateServerJoinDialog> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<PrivateServerJoinDialog> context = new XamlIlContext.Context<PrivateServerJoinDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FPrivateServerJoinDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/PrivateServerJoinDialog.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (PrivateServerJoinDialog)service;
				}
			}
			return context;
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal AvaloniaWindow RootDialog;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	protected override bool ApplyTopPadding => false;

	public PrivateServerJoinDialog()
	{
		InitializeComponent();
	}

	public PrivateServerJoinDialog(PrivateServerJoinDialogViewModel viewModel)
		: this()
	{
		DataContext = viewModel;
	}

	private void OnCloseClicked(object? sender, RoutedEventArgs e)
	{
		Close();
	}

	private void OnHeaderPointerPressed(object? sender, PointerPressedEventArgs e)
	{
		if (e.GetCurrentPoint(this).Properties.IsLeftButtonPressed)
		{
			BeginMoveDrag(e);
		}
	}

	protected override void OnClosed(EventArgs e)
	{
		base.OnClosed(e);
		(DataContext as IDisposable)?.Dispose();
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		RootDialog = this.FindNameScope()?.Find<AvaloniaWindow>("RootDialog");
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, PrivateServerJoinDialog P_1)
	{
		XamlIlContext.Context<PrivateServerJoinDialog> context = new XamlIlContext.Context<PrivateServerJoinDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FPrivateServerJoinDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/PrivateServerJoinDialog.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Name = "RootDialog";
		context.AvaloniaNameScope.Register("RootDialog", P_1);
		P_1.Title = Strings.Menu_QuickPlay_PrivateServers;
		P_1.Width = 600.0;
		P_1.Height = 500.0;
		P_1.MinWidth = 450.0;
		P_1.MinHeight = 350.0;
		P_1.WindowDecorations = WindowDecorations.None;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterOwner;
		P_1.CanResize = true;
		P_1.ShowInTaskbar = false;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		P_1.Content = border;
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("CardStrokeColorDefaultBrush");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border4.Bind(borderBrushProperty, binding);
		border4.Background = new ImmutableSolidColorBrush(16777215u);
		border4.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		border4.ClipToBounds = true;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		border4.Child = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid5.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid5.Children;
		Border border6;
		Border border5 = (border6 = new Border());
		((ISupportInitialize)border5).BeginInit();
		children.Add(border5);
		Grid.SetRow(border6, 0);
		border6.Background = new ImmutableSolidColorBrush(855638016u);
		border6.Padding = new Thickness(16.0, 16.0, 16.0, 16.0);
		border6.AddHandler(InputElement.PointerPressedEvent, context.RootObject.OnHeaderPointerPressed);
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		border6.Child = grid6;
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 2;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid7.ColumnDefinitions = columnDefinitions;
		Avalonia.Controls.Controls children2 = grid7.Children;
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		children2.Add(stackPanel);
		stackPanel2.Orientation = Orientation.Horizontal;
		stackPanel2.Spacing = 10.0;
		Avalonia.Controls.Controls children3 = stackPanel2.Children;
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		children3.Add(lucide);
		lucide2.Icon = LucideIconNames.LockKeyholeOpen;
		lucide2.Height = 18.0;
		lucide2.Width = 18.0;
		((ISupportInitialize)lucide2).EndInit();
		Avalonia.Controls.Controls children4 = stackPanel2.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children4.Add(textBlock);
		textBlock2.Text = Strings.Menu_QuickPlay_PrivateServers;
		textBlock2.FontWeight = FontWeight.Bold;
		textBlock2.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)textBlock2).EndInit();
		((ISupportInitialize)stackPanel2).EndInit();
		Avalonia.Controls.Controls children5 = grid7.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children5.Add(button);
		Grid.SetColumn(button2, 1);
		button2.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.OnCloseClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button2.Background = new ImmutableSolidColorBrush(16777215u);
		button2.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
		Lucide lucide4;
		Lucide lucide3 = (lucide4 = new Lucide());
		((ISupportInitialize)lucide3).BeginInit();
		button2.Content = lucide3;
		lucide4.Icon = LucideIconNames.X;
		lucide4.Height = 16.0;
		lucide4.Width = 16.0;
		((ISupportInitialize)lucide4).EndInit();
		((ISupportInitialize)button2).EndInit();
		((ISupportInitialize)grid7).EndInit();
		((ISupportInitialize)border6).EndInit();
		Avalonia.Controls.Controls children6 = grid5.Children;
		Grid grid9;
		Grid grid8 = (grid9 = new Grid());
		((ISupportInitialize)grid8).BeginInit();
		children6.Add(grid8);
		Grid grid10 = (grid4 = grid9);
		context.PushParent(grid4);
		Grid grid11 = grid4;
		Grid.SetRow(grid11, 1);
		Avalonia.Controls.Controls children7 = grid11.Children;
		Grid grid13;
		Grid grid12 = (grid13 = new Grid());
		((ISupportInitialize)grid12).BeginInit();
		children7.Add(grid12);
		Grid grid14 = (grid4 = grid13);
		context.PushParent(grid4);
		Grid grid15 = grid4;
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EPrivateServerJoinDialogViewModel_002CMerostrap_002EIsLoading_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding2 = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		grid15.Bind(isVisibleProperty, binding2);
		Avalonia.Controls.Controls children8 = grid15.Children;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = new StackPanel());
		((ISupportInitialize)stackPanel3).BeginInit();
		children8.Add(stackPanel3);
		StackPanel stackPanel6;
		StackPanel stackPanel5 = (stackPanel6 = stackPanel4);
		context.PushParent(stackPanel6);
		StackPanel stackPanel7 = stackPanel6;
		stackPanel7.Spacing = 16.0;
		stackPanel7.HorizontalAlignment = HorizontalAlignment.Center;
		stackPanel7.VerticalAlignment = VerticalAlignment.Center;
		Avalonia.Controls.Controls children9 = stackPanel7.Children;
		FAProgressRing fAProgressRing2;
		FAProgressRing fAProgressRing = (fAProgressRing2 = new FAProgressRing());
		((ISupportInitialize)fAProgressRing).BeginInit();
		children9.Add(fAProgressRing);
		FAProgressRing fAProgressRing4;
		FAProgressRing fAProgressRing3 = (fAProgressRing4 = fAProgressRing2);
		context.PushParent(fAProgressRing4);
		StyledProperty<bool> isActiveProperty = FAProgressRing.IsActiveProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EPrivateServerJoinDialogViewModel_002CMerostrap_002EIsLoading_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = FAProgressRing.IsActiveProperty;
		CompiledBinding binding3 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		fAProgressRing4.Bind(isActiveProperty, binding3);
		fAProgressRing4.Width = 40.0;
		fAProgressRing4.Height = 40.0;
		StyledProperty<IBrush?> foregroundProperty = TemplatedControl.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("SystemAccentColor");
		context.ProvideTargetProperty = TemplatedControl.ForegroundProperty;
		BindingBase binding4 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		fAProgressRing4.Bind(foregroundProperty, binding4);
		context.PopParent();
		((ISupportInitialize)fAProgressRing3).EndInit();
		Avalonia.Controls.Controls children10 = stackPanel7.Children;
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		children10.Add(textBlock3);
		textBlock4.Text = Strings.Menu_QuickPlay_LoadingPrivateServers;
		textBlock4.FontSize = 12.0;
		textBlock4.Opacity = 0.7;
		((ISupportInitialize)textBlock4).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel5).EndInit();
		context.PopParent();
		((ISupportInitialize)grid14).EndInit();
		Avalonia.Controls.Controls children11 = grid11.Children;
		Grid grid17;
		Grid grid16 = (grid17 = new Grid());
		((ISupportInitialize)grid16).BeginInit();
		children11.Add(grid16);
		Grid grid18 = (grid4 = grid17);
		context.PushParent(grid4);
		Grid grid19 = grid4;
		StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EPrivateServerJoinDialogViewModel_002CMerostrap_002EIsLoading_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding5 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		grid19.Bind(isVisibleProperty2, binding5);
		Avalonia.Controls.Controls children12 = grid19.Children;
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		children12.Add(scrollViewer);
		ScrollViewer scrollViewer4;
		ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
		context.PushParent(scrollViewer4);
		StyledProperty<bool> isVisibleProperty3 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EPrivateServerJoinDialogViewModel_002CMerostrap_002EIsEmpty_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding6 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		scrollViewer4.Bind(isVisibleProperty3, binding6);
		scrollViewer4.Background = new ImmutableSolidColorBrush(16777215u);
		scrollViewer4.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
		scrollViewer4.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
		ItemsControl itemsControl2;
		ItemsControl itemsControl = (itemsControl2 = new ItemsControl());
		((ISupportInitialize)itemsControl).BeginInit();
		scrollViewer4.Content = itemsControl;
		ItemsControl itemsControl4;
		ItemsControl itemsControl3 = (itemsControl4 = itemsControl2);
		context.PushParent(itemsControl4);
		StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EPrivateServerJoinDialogViewModel_002CMerostrap_002EServers_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding7 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		itemsControl4.Bind(itemsSourceProperty, binding7);
		itemsControl4.Padding = new Thickness(10.0, 10.0, 10.0, 10.0);
		DataTemplate dataTemplate;
		DataTemplate itemTemplate = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.DataType = typeof(PrivateServerInfo);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_21.Build_1), context);
		context.PopParent();
		itemsControl4.ItemTemplate = itemTemplate;
		context.PopParent();
		((ISupportInitialize)itemsControl3).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer3).EndInit();
		Avalonia.Controls.Controls children13 = grid19.Children;
		StackPanel stackPanel9;
		StackPanel stackPanel8 = (stackPanel9 = new StackPanel());
		((ISupportInitialize)stackPanel8).BeginInit();
		children13.Add(stackPanel8);
		StackPanel stackPanel10 = (stackPanel6 = stackPanel9);
		context.PushParent(stackPanel6);
		StackPanel stackPanel11 = stackPanel6;
		StyledProperty<bool> isVisibleProperty4 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002EPrivateServerJoinDialogViewModel_002CMerostrap_002EIsEmpty_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding8 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		stackPanel11.Bind(isVisibleProperty4, binding8);
		stackPanel11.HorizontalAlignment = HorizontalAlignment.Center;
		stackPanel11.VerticalAlignment = VerticalAlignment.Center;
		stackPanel11.Spacing = 8.0;
		Avalonia.Controls.Controls children14 = stackPanel11.Children;
		Lucide lucide6;
		Lucide lucide5 = (lucide6 = new Lucide());
		((ISupportInitialize)lucide5).BeginInit();
		children14.Add(lucide5);
		lucide6.Icon = LucideIconNames.LockKeyhole;
		lucide6.Height = 36.0;
		lucide6.Width = 36.0;
		lucide6.Opacity = 0.5;
		((ISupportInitialize)lucide6).EndInit();
		Avalonia.Controls.Controls children15 = stackPanel11.Children;
		TextBlock textBlock6;
		TextBlock textBlock5 = (textBlock6 = new TextBlock());
		((ISupportInitialize)textBlock5).BeginInit();
		children15.Add(textBlock5);
		textBlock6.Text = Strings.Menu_QuickPlay_NoPrivateServersFound;
		textBlock6.FontSize = 13.0;
		textBlock6.Opacity = 0.7;
		((ISupportInitialize)textBlock6).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel10).EndInit();
		context.PopParent();
		((ISupportInitialize)grid18).EndInit();
		context.PopParent();
		((ISupportInitialize)grid10).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(PrivateServerJoinDialog P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
