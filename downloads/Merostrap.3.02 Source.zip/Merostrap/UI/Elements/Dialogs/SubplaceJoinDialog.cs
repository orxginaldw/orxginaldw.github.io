using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Media.Immutable;
using CompiledAvaloniaXaml;
using FluentAvalonia.UI.Controls;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.Models;
using Merostrap.Resources;
using Merostrap.UI.Elements.Base;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.ViewModels.Dialogs;

namespace Merostrap.UI.Elements.Dialogs;

internal class SubplaceJoinDialog : AvaloniaWindow
{
	[CompilerGenerated]
	private class XamlClosure_24
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<SubplaceJoinDialog> context = CreateContext(P_0);
			context.IntermediateRoot = new WrapPanel();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((AvaloniaObject)obj).SetValue(WrapPanel.OrientationProperty, Orientation.Horizontal, BindingPriority.Template);
			((AvaloniaObject)obj).SetValue(Layoutable.HorizontalAlignmentProperty, HorizontalAlignment.Center, BindingPriority.Template);
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<SubplaceJoinDialog> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<SubplaceJoinDialog> context = new XamlIlContext.Context<SubplaceJoinDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FSubplaceJoinDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/SubplaceJoinDialog.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (SubplaceJoinDialog)service;
				}
			}
			return context;
		}

		public static object Build_2(IServiceProvider P_0)
		{
			XamlIlContext.Context<SubplaceJoinDialog> context = CreateContext(P_0);
			context.IntermediateRoot = new Card();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Card card = (Card)obj;
			context.PushParent(card);
			card.Width = 150.0;
			card.Margin = new Thickness(5.0, 5.0, 5.0, 5.0);
			card.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
			card.CornerRadius = new CornerRadius(8.0, 8.0, 8.0, 8.0);
			card.ClipToBounds = true;
			StackPanel stackPanel2;
			StackPanel stackPanel = (stackPanel2 = new StackPanel());
			((ISupportInitialize)stackPanel).BeginInit();
			card.Content = stackPanel;
			StackPanel stackPanel4;
			StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
			context.PushParent(stackPanel4);
			StackPanel stackPanel5 = stackPanel4;
			Avalonia.Controls.Controls children = stackPanel5.Children;
			Border border2;
			Border border = (border2 = new Border());
			((ISupportInitialize)border).BeginInit();
			children.Add(border);
			Border border4;
			Border border3 = (border4 = border2);
			context.PushParent(border4);
			border4.CornerRadius = new CornerRadius(12.0, 12.0, 0.0, 0.0);
			border4.ClipToBounds = true;
			RemoteImage remoteImage2;
			RemoteImage remoteImage = (remoteImage2 = new RemoteImage());
			((ISupportInitialize)remoteImage).BeginInit();
			border4.Child = remoteImage;
			RemoteImage remoteImage4;
			RemoteImage remoteImage3 = (remoteImage4 = remoteImage2);
			context.PushParent(remoteImage4);
			StyledProperty<string?> urlProperty = RemoteImage.UrlProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EPlaceInfo_002CMerostrap_002EThumbnailUrl_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = RemoteImage.UrlProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			remoteImage4.Bind(urlProperty, binding);
			remoteImage4.Height = 150.0;
			remoteImage4.Width = 150.0;
			remoteImage4.Stretch = Stretch.UniformToFill;
			RenderOptions.SetBitmapInterpolationMode(remoteImage4, BitmapInterpolationMode.LowQuality);
			context.PopParent();
			((ISupportInitialize)remoteImage3).EndInit();
			context.PopParent();
			((ISupportInitialize)border3).EndInit();
			Avalonia.Controls.Controls children2 = stackPanel5.Children;
			StackPanel stackPanel7;
			StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
			((ISupportInitialize)stackPanel6).BeginInit();
			children2.Add(stackPanel6);
			StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
			context.PushParent(stackPanel4);
			StackPanel stackPanel9 = stackPanel4;
			stackPanel9.Spacing = 4.0;
			Avalonia.Controls.Controls children3 = stackPanel9.Children;
			TextBlock textBlock2;
			TextBlock textBlock = (textBlock2 = new TextBlock());
			((ISupportInitialize)textBlock).BeginInit();
			children3.Add(textBlock);
			TextBlock textBlock4;
			TextBlock textBlock3 = (textBlock4 = textBlock2);
			context.PushParent(textBlock4);
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EPlaceInfo_002CMerostrap_002EName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock4.Bind(textProperty, binding2);
			textBlock4.FontSize = 12.0;
			textBlock4.FontWeight = FontWeight.Medium;
			textBlock4.Margin = new Thickness(0.0, 4.0, 0.0, 0.0);
			textBlock4.TextTrimming = TextTrimming.CharacterEllipsis;
			textBlock4.HorizontalAlignment = HorizontalAlignment.Center;
			context.PopParent();
			((ISupportInitialize)textBlock3).EndInit();
			Avalonia.Controls.Controls children4 = stackPanel9.Children;
			IconButton iconButton2;
			IconButton iconButton = (iconButton2 = new IconButton());
			((ISupportInitialize)iconButton).BeginInit();
			children4.Add(iconButton);
			IconButton iconButton4;
			IconButton iconButton3 = (iconButton4 = iconButton2);
			context.PushParent(iconButton4);
			StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().ElementName(context.AvaloniaNameScope, "RootDialog").Property(StyledElement.DataContextProperty, PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ESubplaceJoinDialogViewModel_002CMerostrap_002EJoinSubplaceCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)
				.Build());
			context.ProvideTargetProperty = Button.CommandProperty;
			CompiledBinding binding3 = compiledBindingExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			iconButton4.Bind(commandProperty, binding3);
			CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension();
			context.ProvideTargetProperty = Button.CommandParameterProperty;
			CompiledBinding compiledBinding = compiledBindingExtension4.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_6(iconButton4, compiledBinding);
			iconButton4.VerticalAlignment = VerticalAlignment.Bottom;
			iconButton4.HorizontalAlignment = HorizontalAlignment.Stretch;
			iconButton4.Margin = new Thickness(4.0, 0.0, 4.0, 4.0);
			iconButton4.Classes.Add("Primary");
			iconButton4.Icon = LucideIconNames.Play;
			context.PopParent();
			((ISupportInitialize)iconButton3).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel8).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal AvaloniaWindow RootDialog;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	protected override bool ApplyTopPadding => false;

	public SubplaceJoinDialog()
	{
		InitializeComponent();
	}

	public SubplaceJoinDialog(SubplaceJoinDialogViewModel viewModel)
		: this()
	{
		DataContext = viewModel;
	}

	private void OnCloseClicked(object? sender, RoutedEventArgs e)
	{
		Close();
	}

	private void OnHeaderPointerPressed(object? sender, PointerPressedEventArgs e)
	{
		if (e.GetCurrentPoint(this).Properties.IsLeftButtonPressed)
		{
			BeginMoveDrag(e);
		}
	}

	protected override void OnClosed(EventArgs e)
	{
		base.OnClosed(e);
		(DataContext as IDisposable)?.Dispose();
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		RootDialog = this.FindNameScope()?.Find<AvaloniaWindow>("RootDialog");
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, SubplaceJoinDialog P_1)
	{
		XamlIlContext.Context<SubplaceJoinDialog> context = new XamlIlContext.Context<SubplaceJoinDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FSubplaceJoinDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/SubplaceJoinDialog.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Name = "RootDialog";
		context.AvaloniaNameScope.Register("RootDialog", P_1);
		P_1.Title = Strings.Menu_QuickPlay_AvailableSubplaces;
		P_1.Width = 700.0;
		P_1.Height = 550.0;
		P_1.MinWidth = 500.0;
		P_1.MinHeight = 400.0;
		P_1.WindowDecorations = WindowDecorations.None;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterOwner;
		P_1.CanResize = true;
		P_1.ShowInTaskbar = false;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		P_1.Content = border;
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("CardStrokeColorDefaultBrush");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border4.Bind(borderBrushProperty, binding);
		border4.Background = new ImmutableSolidColorBrush(16777215u);
		border4.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		border4.ClipToBounds = true;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		border4.Child = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid5.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid5.Children;
		Border border6;
		Border border5 = (border6 = new Border());
		((ISupportInitialize)border5).BeginInit();
		children.Add(border5);
		Grid.SetRow(border6, 0);
		border6.Background = new ImmutableSolidColorBrush(855638016u);
		border6.Padding = new Thickness(16.0, 16.0, 16.0, 16.0);
		border6.AddHandler(InputElement.PointerPressedEvent, context.RootObject.OnHeaderPointerPressed);
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		border6.Child = grid6;
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 2;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid7.ColumnDefinitions = columnDefinitions;
		Avalonia.Controls.Controls children2 = grid7.Children;
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		children2.Add(stackPanel);
		stackPanel2.Orientation = Orientation.Horizontal;
		stackPanel2.Spacing = 10.0;
		Avalonia.Controls.Controls children3 = stackPanel2.Children;
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		children3.Add(lucide);
		lucide2.Icon = LucideIconNames.Layers;
		lucide2.Height = 18.0;
		lucide2.Width = 18.0;
		((ISupportInitialize)lucide2).EndInit();
		Avalonia.Controls.Controls children4 = stackPanel2.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children4.Add(textBlock);
		textBlock2.Text = Strings.Menu_QuickPlay_AvailableSubplaces;
		textBlock2.FontWeight = FontWeight.Bold;
		textBlock2.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)textBlock2).EndInit();
		((ISupportInitialize)stackPanel2).EndInit();
		Avalonia.Controls.Controls children5 = grid7.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children5.Add(button);
		Grid.SetColumn(button2, 1);
		button2.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.OnCloseClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button2.Background = new ImmutableSolidColorBrush(16777215u);
		button2.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
		Lucide lucide4;
		Lucide lucide3 = (lucide4 = new Lucide());
		((ISupportInitialize)lucide3).BeginInit();
		button2.Content = lucide3;
		lucide4.Icon = LucideIconNames.X;
		lucide4.Height = 16.0;
		lucide4.Width = 16.0;
		((ISupportInitialize)lucide4).EndInit();
		((ISupportInitialize)button2).EndInit();
		((ISupportInitialize)grid7).EndInit();
		((ISupportInitialize)border6).EndInit();
		Avalonia.Controls.Controls children6 = grid5.Children;
		Grid grid9;
		Grid grid8 = (grid9 = new Grid());
		((ISupportInitialize)grid8).BeginInit();
		children6.Add(grid8);
		Grid grid10 = (grid4 = grid9);
		context.PushParent(grid4);
		Grid grid11 = grid4;
		Grid.SetRow(grid11, 1);
		Avalonia.Controls.Controls children7 = grid11.Children;
		Grid grid13;
		Grid grid12 = (grid13 = new Grid());
		((ISupportInitialize)grid12).BeginInit();
		children7.Add(grid12);
		Grid grid14 = (grid4 = grid13);
		context.PushParent(grid4);
		Grid grid15 = grid4;
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ESubplaceJoinDialogViewModel_002CMerostrap_002EIsLoading_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding2 = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		grid15.Bind(isVisibleProperty, binding2);
		Avalonia.Controls.Controls children8 = grid15.Children;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = new StackPanel());
		((ISupportInitialize)stackPanel3).BeginInit();
		children8.Add(stackPanel3);
		StackPanel stackPanel6;
		StackPanel stackPanel5 = (stackPanel6 = stackPanel4);
		context.PushParent(stackPanel6);
		stackPanel6.Spacing = 16.0;
		stackPanel6.HorizontalAlignment = HorizontalAlignment.Center;
		stackPanel6.VerticalAlignment = VerticalAlignment.Center;
		Avalonia.Controls.Controls children9 = stackPanel6.Children;
		FAProgressRing fAProgressRing2;
		FAProgressRing fAProgressRing = (fAProgressRing2 = new FAProgressRing());
		((ISupportInitialize)fAProgressRing).BeginInit();
		children9.Add(fAProgressRing);
		FAProgressRing fAProgressRing4;
		FAProgressRing fAProgressRing3 = (fAProgressRing4 = fAProgressRing2);
		context.PushParent(fAProgressRing4);
		StyledProperty<bool> isActiveProperty = FAProgressRing.IsActiveProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ESubplaceJoinDialogViewModel_002CMerostrap_002EIsLoading_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = FAProgressRing.IsActiveProperty;
		CompiledBinding binding3 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		fAProgressRing4.Bind(isActiveProperty, binding3);
		fAProgressRing4.Width = 40.0;
		fAProgressRing4.Height = 40.0;
		StyledProperty<IBrush?> foregroundProperty = TemplatedControl.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("SystemAccentColor");
		context.ProvideTargetProperty = TemplatedControl.ForegroundProperty;
		BindingBase binding4 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		fAProgressRing4.Bind(foregroundProperty, binding4);
		context.PopParent();
		((ISupportInitialize)fAProgressRing3).EndInit();
		Avalonia.Controls.Controls children10 = stackPanel6.Children;
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		children10.Add(textBlock3);
		textBlock4.Text = Strings.Menu_QuickPlay_LoadingSubplaces;
		textBlock4.FontSize = 12.0;
		textBlock4.Opacity = 0.7;
		((ISupportInitialize)textBlock4).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel5).EndInit();
		context.PopParent();
		((ISupportInitialize)grid14).EndInit();
		Avalonia.Controls.Controls children11 = grid11.Children;
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		children11.Add(scrollViewer);
		ScrollViewer scrollViewer4;
		ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
		context.PushParent(scrollViewer4);
		StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ESubplaceJoinDialogViewModel_002CMerostrap_002EIsLoading_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding5 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		scrollViewer4.Bind(isVisibleProperty2, binding5);
		scrollViewer4.Background = new ImmutableSolidColorBrush(16777215u);
		scrollViewer4.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
		scrollViewer4.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
		ItemsControl itemsControl2;
		ItemsControl itemsControl = (itemsControl2 = new ItemsControl());
		((ISupportInitialize)itemsControl).BeginInit();
		scrollViewer4.Content = itemsControl;
		ItemsControl itemsControl4;
		ItemsControl itemsControl3 = (itemsControl4 = itemsControl2);
		context.PushParent(itemsControl4);
		StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ESubplaceJoinDialogViewModel_002CMerostrap_002ESubplaces_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding6 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		itemsControl4.Bind(itemsSourceProperty, binding6);
		itemsControl4.Padding = new Thickness(10.0, 10.0, 10.0, 10.0);
		itemsControl4.ItemsPanel = new ItemsPanelTemplate
		{
			Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_24.Build_1), context)
		};
		DataTemplate dataTemplate;
		DataTemplate itemTemplate = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.DataType = typeof(PlaceInfo);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_24.Build_2), context);
		context.PopParent();
		itemsControl4.ItemTemplate = itemTemplate;
		context.PopParent();
		((ISupportInitialize)itemsControl3).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid10).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(SubplaceJoinDialog P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
