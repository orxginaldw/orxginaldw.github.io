using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Data;
using Avalonia.Input.Platform;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using CompiledAvaloniaXaml;
using Merostrap.Enums;
using Merostrap.UI.Elements.Base;

namespace Merostrap.UI.Elements.Dialogs;

internal class VersionOverrideDialog : AvaloniaWindow
{
	private readonly LaunchMode _launchMode;

	private readonly ObservableCollection<VersionEntry> _versions = new ObservableCollection<VersionEntry>();

	private bool _isLoading;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal DataGrid VersionsDataGrid;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button CopyHashButton;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button RefreshButton;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button CloseButton;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public ObservableCollection<VersionEntry> Versions => _versions;

	public VersionOverrideDialog()
	{
		InitializeComponent();
		DataContext = this;
	}

	public VersionOverrideDialog(LaunchMode mode)
		: this()
	{
		_launchMode = mode;
		VersionsDataGrid.SelectionChanged += (object? s, SelectionChangedEventArgs e) =>
		{
			CopyHashButton.IsEnabled = VersionsDataGrid.SelectedItem != null;
		};
		CopyHashButton.Click += CopyHashButton_Click;
		RefreshButton.Click += RefreshButton_Click;
		CloseButton.Click += (object? s, RoutedEventArgs e) =>
		{
			Close();
		};
		LoadVersionsAsync();
	}

	private async Task LoadVersionsAsync()
	{
		if (_isLoading)
		{
			return;
		}
		_isLoading = true;
		RefreshButton.IsEnabled = false;
		try
		{
			_versions.Clear();
			string uriString = (OperatingSystem.IsMacOS() ? "https://setup-rbxcdn.github.io/mac/DeployHistory.txt" : "https://setup-rbxcdn.github.io/DeployHistory.txt");
			List<VersionEntry> source = ParseDeployHistory(binaryType: (!OperatingSystem.IsMacOS()) ? ((_launchMode == LaunchMode.Player) ? "WindowsPlayer" : "Studio") : ((_launchMode == LaunchMode.Player) ? "Client" : "Studio"), content: await App.HttpClient.GetStringAsync(new Uri(uriString)));
			DateTime oneYearAgo = DateTime.UtcNow.AddYears(-1);
			foreach (VersionEntry item in (from e in source
				where e.ReleaseDateUtc >= oneYearAgo && !string.IsNullOrEmpty(e.Hash)
				orderby e.ReleaseDateUtc descending
				select e).DistinctBy((VersionEntry e) => e.Hash).ToList())
			{
				_versions.Add(item);
			}
		}
		catch (Exception ex)
		{
			App.Logger.Error("Failed to load deploy history: " + ex.Message);
		}
		finally
		{
			_isLoading = false;
			RefreshButton.IsEnabled = true;
		}
	}

	private static List<VersionEntry> ParseDeployHistory(string content, string binaryType)
	{
		List<VersionEntry> list = new List<VersionEntry>();
		foreach (Match item2 in new Regex("New\\s+" + binaryType + "(?:64)?\\s+version-(?<hash>[a-f0-9]+|hidden)\\s+at\\s+(?<date>[^,]+),\\s+file\\s+version:\\s+(?<fileVer>[^,]+(?:,\\s*[0-9]+)*)", RegexOptions.IgnoreCase | RegexOptions.Compiled).Matches(content))
		{
			string value = item2.Groups["hash"].Value;
			if (value.Equals("hidden", StringComparison.OrdinalIgnoreCase))
			{
				continue;
			}
			string s = item2.Groups["date"].Value.Trim();
			string text = item2.Groups["fileVer"].Value.Trim();
			if (DateTime.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.None, out var result))
			{
				DateTime releaseDateUtc = DateTime.SpecifyKind(result, DateTimeKind.Local).ToUniversalTime();
				List<string> values = (from text2 in text.Split(',', StringSplitOptions.RemoveEmptyEntries)
					select text2.Trim()).ToList();
				string version = string.Join(".", values);
				VersionEntry item = new VersionEntry
				{
					Hash = value,
					Version = version,
					Date = result.ToString("yyyy-MM-dd hh:mm tt", CultureInfo.InvariantCulture),
					ReleaseDateUtc = releaseDateUtc
				};
				list.Add(item);
			}
		}
		return list;
	}

	private async void CopyHashButton_Click(object? sender, EventArgs e)
	{
		if (VersionsDataGrid.SelectedItem is VersionEntry versionEntry)
		{
			IClipboard clipboard = TopLevel.GetTopLevel(this)?.Clipboard;
			if (clipboard != null)
			{
				await clipboard.SetTextAsync("version-" + versionEntry.Hash);
			}
		}
	}

	private async void RefreshButton_Click(object? sender, EventArgs e)
	{
		await LoadVersionsAsync();
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		VersionsDataGrid = nameScope?.Find<DataGrid>("VersionsDataGrid");
		CopyHashButton = nameScope?.Find<Button>("CopyHashButton");
		RefreshButton = nameScope?.Find<Button>("RefreshButton");
		CloseButton = nameScope?.Find<Button>("CloseButton");
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, VersionOverrideDialog P_1)
	{
		XamlIlContext.Context<VersionOverrideDialog> context = new XamlIlContext.Context<VersionOverrideDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FVersionOverrideDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/VersionOverrideDialog.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Title = "Available Version";
		P_1.Width = 750.0;
		P_1.Height = 500.0;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid5.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid5.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children.Add(grid6);
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		Grid.SetRow(grid9, 0);
		grid9.Margin = new Thickness(16.0, 16.0, 16.0, 16.0);
		Avalonia.Controls.Controls children2 = grid9.Children;
		DataGrid dataGrid2;
		DataGrid dataGrid = (dataGrid2 = new DataGrid());
		((ISupportInitialize)dataGrid).BeginInit();
		children2.Add(dataGrid);
		DataGrid dataGrid4;
		DataGrid dataGrid3 = (dataGrid4 = dataGrid2);
		context.PushParent(dataGrid4);
		dataGrid4.Name = "VersionsDataGrid";
		object element = dataGrid4;
		context.AvaloniaNameScope.Register("VersionsDataGrid", element);
		StyledProperty<IEnumerable> itemsSourceProperty = DataGrid.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EElements_002EDialogs_002EVersionOverrideDialog_002CMerostrap_002EVersions_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = DataGrid.ItemsSourceProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		dataGrid4.Bind(itemsSourceProperty, binding);
		dataGrid4.AutoGenerateColumns = false;
		dataGrid4.CanUserReorderColumns = false;
		dataGrid4.CanUserResizeColumns = false;
		dataGrid4.CanUserSortColumns = true;
		dataGrid4.IsReadOnly = true;
		dataGrid4.SelectionMode = DataGridSelectionMode.Single;
		dataGrid4.RowHeight = 40.0;
		ObservableCollection<DataGridColumn> columns = dataGrid4.Columns;
		DataGridTextColumn dataGridTextColumn;
		DataGridTextColumn item = (dataGridTextColumn = new DataGridTextColumn());
		context.PushParent(dataGridTextColumn);
		DataGridTextColumn dataGridTextColumn2 = dataGridTextColumn;
		dataGridTextColumn2.Header = "Version";
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EElements_002EDialogs_002EVersionEntry_002CMerostrap_002EVersion_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EControls_002EDataGridBoundColumn_002CAvalonia_002EControls_002EDataGrid_002EBinding_0021Property();
		CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		dataGridTextColumn2.Binding = binding2;
		dataGridTextColumn2.Width = (DataGridLength)new DataGridLengthConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "150");
		context.PopParent();
		columns.Add(item);
		ObservableCollection<DataGridColumn> columns2 = dataGrid4.Columns;
		DataGridTextColumn item2 = (dataGridTextColumn = new DataGridTextColumn());
		context.PushParent(dataGridTextColumn);
		DataGridTextColumn dataGridTextColumn3 = dataGridTextColumn;
		dataGridTextColumn3.Header = "Hash";
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EElements_002EDialogs_002EVersionEntry_002CMerostrap_002EHash_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EControls_002EDataGridBoundColumn_002CAvalonia_002EControls_002EDataGrid_002EBinding_0021Property();
		CompiledBinding binding3 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		dataGridTextColumn3.Binding = binding3;
		dataGridTextColumn3.Width = (DataGridLength)new DataGridLengthConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "4*");
		context.PopParent();
		columns2.Add(item2);
		ObservableCollection<DataGridColumn> columns3 = dataGrid4.Columns;
		DataGridTextColumn item3 = (dataGridTextColumn = new DataGridTextColumn());
		context.PushParent(dataGridTextColumn);
		DataGridTextColumn dataGridTextColumn4 = dataGridTextColumn;
		dataGridTextColumn4.Header = "Release Date";
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EElements_002EDialogs_002EVersionEntry_002CMerostrap_002EDate_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EControls_002EDataGridBoundColumn_002CAvalonia_002EControls_002EDataGrid_002EBinding_0021Property();
		CompiledBinding binding4 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		dataGridTextColumn4.Binding = binding4;
		dataGridTextColumn4.Width = (DataGridLength)new DataGridLengthConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "200");
		context.PopParent();
		columns3.Add(item3);
		context.PopParent();
		((ISupportInitialize)dataGrid3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		Avalonia.Controls.Controls children3 = grid5.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children3.Add(border);
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Grid.SetRow(border4, 1);
		border4.Padding = new Thickness(15.0, 15.0, 15.0, 15.0);
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding5 = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border4.Bind(backgroundProperty, binding5);
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		border4.Child = stackPanel;
		stackPanel2.Orientation = Orientation.Horizontal;
		stackPanel2.HorizontalAlignment = HorizontalAlignment.Right;
		stackPanel2.Spacing = 6.0;
		Avalonia.Controls.Controls children4 = stackPanel2.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children4.Add(button);
		button2.Name = "CopyHashButton";
		element = button2;
		context.AvaloniaNameScope.Register("CopyHashButton", element);
		button2.Content = "Copy Version Hash";
		button2.IsEnabled = false;
		((ISupportInitialize)button2).EndInit();
		Avalonia.Controls.Controls children5 = stackPanel2.Children;
		Button button4;
		Button button3 = (button4 = new Button());
		((ISupportInitialize)button3).BeginInit();
		children5.Add(button3);
		button4.Name = "RefreshButton";
		element = button4;
		context.AvaloniaNameScope.Register("RefreshButton", element);
		button4.Content = "Refetch";
		((ISupportInitialize)button4).EndInit();
		Avalonia.Controls.Controls children6 = stackPanel2.Children;
		Button button6;
		Button button5 = (button6 = new Button());
		((ISupportInitialize)button5).BeginInit();
		children6.Add(button5);
		button6.Name = "CloseButton";
		element = button6;
		context.AvaloniaNameScope.Register("CloseButton", element);
		button6.Content = "Close";
		((ISupportInitialize)button6).EndInit();
		((ISupportInitialize)stackPanel2).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(VersionOverrideDialog P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
