using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Runtime.CompilerServices;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Data;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Platform;
using CompiledAvaloniaXaml;
using Merostrap.Enums.Messagebox;
using Merostrap.Resources;
using Merostrap.UI.Elements.Base;
using Merostrap.UI.Elements.Controls;

namespace Merostrap.UI.Elements.Dialogs;

internal class FluentMessageBox : AvaloniaWindow
{
	public MessageBoxResult Result;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Image IconImage;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal MarkdownTextBlock MessageMarkdownTextBlock;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button ButtonOne;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button ButtonTwo;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button ButtonThree;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public FluentMessageBox()
	{
		InitializeComponent();
	}

	public FluentMessageBox(string message, MessageBoxImage image, MessageBoxButton buttons)
		: this()
	{
		string text = null;
		switch (image)
		{
		case MessageBoxImage.Error:
			text = "Error";
			break;
		case MessageBoxImage.Question:
			text = "Question";
			break;
		case MessageBoxImage.Warning:
			text = "Warning";
			break;
		case MessageBoxImage.Information:
			text = "Information";
			break;
		}
		if (text == null)
		{
			IconImage.IsVisible = false;
		}
		else
		{
			using Stream stream = AssetLoader.Open(new Uri("avares://Merostrap/Resources/MessageBox/" + text + ".png"));
			IconImage.Source = new Bitmap(stream);
		}
		Title = "Merostrap";
		MessageMarkdownTextBlock.MarkdownText = message;
		ButtonOne.IsVisible = false;
		ButtonTwo.IsVisible = false;
		ButtonThree.IsVisible = false;
		switch (buttons)
		{
		case MessageBoxButton.YesNo:
			SetButton(ButtonOne, MessageBoxResult.Yes);
			SetButton(ButtonTwo, MessageBoxResult.No);
			break;
		case MessageBoxButton.YesNoCancel:
			SetButton(ButtonOne, MessageBoxResult.Yes);
			SetButton(ButtonTwo, MessageBoxResult.No);
			SetButton(ButtonThree, MessageBoxResult.Cancel);
			break;
		case MessageBoxButton.OKCancel:
			SetButton(ButtonOne, MessageBoxResult.OK);
			SetButton(ButtonTwo, MessageBoxResult.Cancel);
			break;
		default:
			SetButton(ButtonOne, MessageBoxResult.OK);
			break;
		}
		if (ButtonThree.IsVisible)
		{
			Width = 356.0;
		}
		else if (ButtonTwo.IsVisible)
		{
			Width = 245.0;
		}
		double num = 180.0;
		if (image != MessageBoxImage.None)
		{
			num += 50.0;
		}
		num += (double)message.Length * 0.6;
		if (num > MaxWidth)
		{
			Width = MaxWidth;
		}
		else if (num > Width)
		{
			Width = num;
		}
		if (Application.Current?.ApplicationLifetime is IClassicDesktopStyleApplicationLifetime classicDesktopStyleApplicationLifetime)
		{
			classicDesktopStyleApplicationLifetime.ShutdownMode = ShutdownMode.OnExplicitShutdown;
		}
	}

	private static string GetTextForResult(MessageBoxResult result)
	{
		return result switch
		{
			MessageBoxResult.OK => Strings.Common_OK, 
			MessageBoxResult.Cancel => Strings.Common_Cancel, 
			MessageBoxResult.Yes => Strings.Common_Yes, 
			MessageBoxResult.No => Strings.Common_No, 
			_ => result.ToString(), 
		};
	}

	public void SetButton(Button button, MessageBoxResult result)
	{
		button.IsVisible = true;
		button.Content = GetTextForResult(result);
		button.Click += (object? _, RoutedEventArgs _) =>
		{
			Result = result;
			Close();
		};
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		IconImage = nameScope?.Find<Image>("IconImage");
		MessageMarkdownTextBlock = nameScope?.Find<MarkdownTextBlock>("MessageMarkdownTextBlock");
		ButtonOne = nameScope?.Find<Button>("ButtonOne");
		ButtonTwo = nameScope?.Find<Button>("ButtonTwo");
		ButtonThree = nameScope?.Find<Button>("ButtonThree");
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, FluentMessageBox P_1)
	{
		XamlIlContext.Context<FluentMessageBox> context = new XamlIlContext.Context<FluentMessageBox>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FFluentMessageBox_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/FluentMessageBox.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Title = "Merostrap";
		P_1.Width = 320.0;
		P_1.MaxWidth = 480.0;
		P_1.SizeToContent = SizeToContent.WidthAndHeight;
		P_1.CanResize = false;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid5.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid5.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children.Add(grid6);
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		Grid.SetRow(grid9, 0);
		grid9.Margin = new Thickness(20.0, 20.0, 20.0, 20.0);
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 2;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid9.ColumnDefinitions = columnDefinitions;
		Avalonia.Controls.Controls children2 = grid9.Children;
		Image image2;
		Image image = (image2 = new Image());
		((ISupportInitialize)image).BeginInit();
		children2.Add(image);
		image2.Name = "IconImage";
		object element = image2;
		context.AvaloniaNameScope.Register("IconImage", element);
		Grid.SetColumn(image2, 0);
		image2.Width = 32.0;
		image2.Height = 32.0;
		image2.Margin = new Thickness(0.0, 0.0, 15.0, 0.0);
		image2.VerticalAlignment = VerticalAlignment.Top;
		((ISupportInitialize)image2).EndInit();
		Avalonia.Controls.Controls children3 = grid9.Children;
		MarkdownTextBlock markdownTextBlock2;
		MarkdownTextBlock markdownTextBlock = (markdownTextBlock2 = new MarkdownTextBlock());
		((ISupportInitialize)markdownTextBlock).BeginInit();
		children3.Add(markdownTextBlock);
		MarkdownTextBlock markdownTextBlock4;
		MarkdownTextBlock markdownTextBlock3 = (markdownTextBlock4 = markdownTextBlock2);
		context.PushParent(markdownTextBlock4);
		markdownTextBlock4.Name = "MessageMarkdownTextBlock";
		element = markdownTextBlock4;
		context.AvaloniaNameScope.Register("MessageMarkdownTextBlock", element);
		Grid.SetColumn(markdownTextBlock4, 1);
		markdownTextBlock4.VerticalAlignment = VerticalAlignment.Center;
		markdownTextBlock4.TextWrapping = TextWrapping.Wrap;
		StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("TextFillColorPrimaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		markdownTextBlock4.Bind(foregroundProperty, binding);
		context.PopParent();
		((ISupportInitialize)markdownTextBlock3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		Avalonia.Controls.Controls children4 = grid5.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children4.Add(border);
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Grid.SetRow(border4, 1);
		border4.Padding = new Thickness(15.0, 15.0, 15.0, 15.0);
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border4.Bind(backgroundProperty, binding2);
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		border4.Child = stackPanel;
		stackPanel2.Orientation = Orientation.Horizontal;
		stackPanel2.HorizontalAlignment = HorizontalAlignment.Right;
		Avalonia.Controls.Controls children5 = stackPanel2.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children5.Add(button);
		button2.Name = "ButtonOne";
		element = button2;
		context.AvaloniaNameScope.Register("ButtonOne", element);
		button2.MinWidth = 80.0;
		button2.Content = "Button 1";
		button2.IsVisible = false;
		((ISupportInitialize)button2).EndInit();
		Avalonia.Controls.Controls children6 = stackPanel2.Children;
		Button button4;
		Button button3 = (button4 = new Button());
		((ISupportInitialize)button3).BeginInit();
		children6.Add(button3);
		button4.Name = "ButtonTwo";
		element = button4;
		context.AvaloniaNameScope.Register("ButtonTwo", element);
		button4.MinWidth = 80.0;
		button4.Margin = new Thickness(12.0, 0.0, 0.0, 0.0);
		button4.Content = "Button 2";
		button4.IsVisible = false;
		((ISupportInitialize)button4).EndInit();
		Avalonia.Controls.Controls children7 = stackPanel2.Children;
		Button button6;
		Button button5 = (button6 = new Button());
		((ISupportInitialize)button5).BeginInit();
		children7.Add(button5);
		button6.Name = "ButtonThree";
		element = button6;
		context.AvaloniaNameScope.Register("ButtonThree", element);
		button6.MinWidth = 80.0;
		button6.Margin = new Thickness(12.0, 0.0, 0.0, 0.0);
		button6.Content = "Button 3";
		button6.IsVisible = false;
		((ISupportInitialize)button6).EndInit();
		((ISupportInitialize)stackPanel2).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(FluentMessageBox P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
