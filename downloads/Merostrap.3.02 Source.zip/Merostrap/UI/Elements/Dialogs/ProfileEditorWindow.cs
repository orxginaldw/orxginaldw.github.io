using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using CompiledAvaloniaXaml;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.UI.ViewModels.Settings;

namespace Merostrap.UI.Elements.Dialogs;

internal class ProfileEditorWindow : Window
{
	[CompilerGenerated]
	private class XamlClosure_22
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<ProfileEditorWindow> context = CreateContext(P_0);
			context.IntermediateRoot = new Grid();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Grid grid = (Grid)obj;
			context.PushParent(grid);
			Grid grid2 = grid;
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 3;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(40.0, GridUnitType.Pixel)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(12.0, GridUnitType.Pixel)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid2.ColumnDefinitions = columnDefinitions;
			grid2.Margin = new Thickness(4.0, 6.0, 4.0, 6.0);
			Avalonia.Controls.Controls children = grid2.Children;
			Border border2;
			Border border = (border2 = new Border());
			((ISupportInitialize)border).BeginInit();
			children.Add(border);
			Border border4;
			Border border3 = (border4 = border2);
			context.PushParent(border4);
			border4.Width = 40.0;
			border4.Height = 40.0;
			border4.CornerRadius = new CornerRadius(5.0, 5.0, 5.0, 5.0);
			border4.ClipToBounds = true;
			Grid grid4;
			Grid grid3 = (grid4 = new Grid());
			((ISupportInitialize)grid3).BeginInit();
			border4.Child = grid3;
			Grid grid5 = (grid = grid4);
			context.PushParent(grid);
			Grid grid6 = grid;
			Avalonia.Controls.Controls children2 = grid6.Children;
			Lucide lucide2;
			Lucide lucide = (lucide2 = new Lucide());
			((ISupportInitialize)lucide).BeginInit();
			children2.Add(lucide);
			Lucide lucide4;
			Lucide lucide3 = (lucide4 = lucide2);
			context.PushParent(lucide4);
			lucide4.Icon = LucideIconNames.Gamepad2;
			StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileGameChoice_002CMerostrap_002EHasIcon_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			lucide4.Bind(isVisibleProperty, binding);
			lucide4.Width = 22.0;
			lucide4.Height = 22.0;
			context.PopParent();
			((ISupportInitialize)lucide3).EndInit();
			Avalonia.Controls.Controls children3 = grid6.Children;
			Image image2;
			Image image = (image2 = new Image());
			((ISupportInitialize)image).BeginInit();
			children3.Add(image);
			Image image4;
			Image image3 = (image4 = image2);
			context.PushParent(image4);
			StyledProperty<IImage?> sourceProperty = Image.SourceProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileGameChoice_002CMerostrap_002EIcon_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Image.SourceProperty;
			CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			image4.Bind(sourceProperty, binding2);
			StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileGameChoice_002CMerostrap_002EHasIcon_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding3 = compiledBindingExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			image4.Bind(isVisibleProperty2, binding3);
			image4.Stretch = Stretch.UniformToFill;
			context.PopParent();
			((ISupportInitialize)image3).EndInit();
			context.PopParent();
			((ISupportInitialize)grid5).EndInit();
			context.PopParent();
			((ISupportInitialize)border3).EndInit();
			Avalonia.Controls.Controls children4 = grid2.Children;
			StackPanel stackPanel2;
			StackPanel stackPanel = (stackPanel2 = new StackPanel());
			((ISupportInitialize)stackPanel).BeginInit();
			children4.Add(stackPanel);
			StackPanel stackPanel4;
			StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
			context.PushParent(stackPanel4);
			Grid.SetColumn(stackPanel4, 2);
			stackPanel4.VerticalAlignment = VerticalAlignment.Center;
			stackPanel4.Spacing = 3.0;
			Avalonia.Controls.Controls children5 = stackPanel4.Children;
			TextBlock textBlock2;
			TextBlock textBlock = (textBlock2 = new TextBlock());
			((ISupportInitialize)textBlock).BeginInit();
			children5.Add(textBlock);
			TextBlock textBlock4;
			TextBlock textBlock3 = (textBlock4 = textBlock2);
			context.PushParent(textBlock4);
			TextBlock textBlock5 = textBlock4;
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileGameChoice_002CMerostrap_002EName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding4 = compiledBindingExtension4.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock5.Bind(textProperty, binding4);
			textBlock5.TextTrimming = TextTrimming.CharacterEllipsis;
			textBlock5.FontWeight = FontWeight.DemiBold;
			context.PopParent();
			((ISupportInitialize)textBlock3).EndInit();
			Avalonia.Controls.Controls children6 = stackPanel4.Children;
			TextBlock textBlock7;
			TextBlock textBlock6 = (textBlock7 = new TextBlock());
			((ISupportInitialize)textBlock6).BeginInit();
			children6.Add(textBlock6);
			TextBlock textBlock8 = (textBlock4 = textBlock7);
			context.PushParent(textBlock4);
			TextBlock textBlock9 = textBlock4;
			StyledProperty<string?> textProperty2 = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileGameChoice_002CMerostrap_002EDetail_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding5 = compiledBindingExtension5.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock9.Bind(textProperty2, binding5);
			textBlock9.FontSize = 11.0;
			StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("TextFillColorSecondaryBrush");
			context.ProvideTargetProperty = TextBlock.ForegroundProperty;
			BindingBase binding6 = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock9.Bind(foregroundProperty, binding6);
			context.PopParent();
			((ISupportInitialize)textBlock8).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<ProfileEditorWindow> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<ProfileEditorWindow> context = new XamlIlContext.Context<ProfileEditorWindow>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FProfileEditorWindow_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/ProfileEditorWindow.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (ProfileEditorWindow)service;
				}
			}
			return context;
		}
	}

	private readonly ProfileEditorViewModel _model;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBox ProfileNameInput;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBox GameSearchInput;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal ListBox GameResults;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button SaveProfileButton;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public ProfileEditorWindow(ProfileEditorViewModel model)
	{
		ProfileEditorWindow control = this;
		_model = model;
		InitializeComponent();
		DataContext = model;
		Opened += (object? _, EventArgs _) =>
		{
			control.FindControl<TextBox>("ProfileNameInput").Focus();
		};
		Closed += (object? _, EventArgs _) =>
		{
			model.Dispose();
		};
	}

	private void SaveClicked(object? sender, RoutedEventArgs e)
	{
		if (_model.Save())
		{
			Close(true);
		}
	}

	private void CancelClicked(object? sender, RoutedEventArgs e)
	{
		Close(false);
	}

	private void GameSelected(object? sender, SelectionChangedEventArgs e)
	{
		if (sender is ListBox { SelectedItem: ProfileGameChoice selectedItem } listBox)
		{
			_model.SelectedGame = selectedItem;
			listBox.SelectedItem = null;
		}
	}

	private void SearchKeyDown(object? sender, KeyEventArgs e)
	{
		if (e.Key == Key.Return && _model.SearchCommand.CanExecute(null))
		{
			_model.SearchCommand.Execute(null);
			e.Handled = true;
		}
	}

	protected override void OnKeyDown(KeyEventArgs e)
	{
		base.OnKeyDown(e);
		if (e.Key == Key.Escape)
		{
			Close(false);
			e.Handled = true;
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		ProfileNameInput = nameScope?.Find<TextBox>("ProfileNameInput");
		GameSearchInput = nameScope?.Find<TextBox>("GameSearchInput");
		GameResults = nameScope?.Find<ListBox>("GameResults");
		SaveProfileButton = nameScope?.Find<Button>("SaveProfileButton");
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, ProfileEditorWindow P_1)
	{
		XamlIlContext.Context<ProfileEditorWindow> context = new XamlIlContext.Context<ProfileEditorWindow>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FProfileEditorWindow_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/ProfileEditorWindow.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		StyledProperty<string?> titleProperty = Window.TitleProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileEditorViewModel_002CMerostrap_002ETitle_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Window.TitleProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		P_1.Bind(titleProperty, binding);
		P_1.Width = 560.0;
		P_1.Height = 650.0;
		P_1.CanResize = false;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterOwner;
		StyledProperty<IBrush?> backgroundProperty = TemplatedControl.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("SolidBackgroundFillColorBaseBrush");
		context.ProvideTargetProperty = TemplatedControl.BackgroundProperty;
		BindingBase binding2 = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		P_1.Bind(backgroundProperty, binding2);
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid5.RowDefinitions = rowDefinitions;
		grid5.Margin = new Thickness(24.0, 24.0, 24.0, 24.0);
		Avalonia.Controls.Controls children = grid5.Children;
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		children.Add(scrollViewer);
		ScrollViewer scrollViewer4;
		ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
		context.PushParent(scrollViewer4);
		scrollViewer4.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		scrollViewer4.Content = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		StackPanel stackPanel5 = stackPanel4;
		stackPanel5.Spacing = 16.0;
		Avalonia.Controls.Controls children2 = stackPanel5.Children;
		StackPanel stackPanel7;
		StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
		((ISupportInitialize)stackPanel6).BeginInit();
		children2.Add(stackPanel6);
		StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
		context.PushParent(stackPanel4);
		StackPanel stackPanel9 = stackPanel4;
		stackPanel9.Spacing = 6.0;
		Avalonia.Controls.Controls children3 = stackPanel9.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children3.Add(textBlock);
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = textBlock2);
		context.PushParent(textBlock4);
		TextBlock textBlock5 = textBlock4;
		StyledProperty<string?> textProperty = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileEditorViewModel_002CMerostrap_002ETitle_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding3 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock5.Bind(textProperty, binding3);
		textBlock5.FontSize = 24.0;
		textBlock5.FontWeight = FontWeight.DemiBold;
		context.PopParent();
		((ISupportInitialize)textBlock3).EndInit();
		Avalonia.Controls.Controls children4 = stackPanel9.Children;
		TextBlock textBlock7;
		TextBlock textBlock6 = (textBlock7 = new TextBlock());
		((ISupportInitialize)textBlock6).BeginInit();
		children4.Add(textBlock6);
		TextBlock textBlock8 = (textBlock4 = textBlock7);
		context.PushParent(textBlock4);
		TextBlock textBlock9 = textBlock4;
		StyledProperty<string?> textProperty2 = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileEditorViewModel_002CMerostrap_002EDescription_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding4 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock9.Bind(textProperty2, binding4);
		textBlock9.TextWrapping = TextWrapping.Wrap;
		StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("TextFillColorSecondaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding5 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock9.Bind(foregroundProperty, binding5);
		context.PopParent();
		((ISupportInitialize)textBlock8).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel8).EndInit();
		Avalonia.Controls.Controls children5 = stackPanel5.Children;
		StackPanel stackPanel11;
		StackPanel stackPanel10 = (stackPanel11 = new StackPanel());
		((ISupportInitialize)stackPanel10).BeginInit();
		children5.Add(stackPanel10);
		StackPanel stackPanel12 = (stackPanel4 = stackPanel11);
		context.PushParent(stackPanel4);
		StackPanel stackPanel13 = stackPanel4;
		stackPanel13.Spacing = 6.0;
		Avalonia.Controls.Controls children6 = stackPanel13.Children;
		TextBlock textBlock11;
		TextBlock textBlock10 = (textBlock11 = new TextBlock());
		((ISupportInitialize)textBlock10).BeginInit();
		children6.Add(textBlock10);
		textBlock11.Text = "Profile name";
		textBlock11.FontWeight = FontWeight.DemiBold;
		((ISupportInitialize)textBlock11).EndInit();
		Avalonia.Controls.Controls children7 = stackPanel13.Children;
		TextBox textBox2;
		TextBox textBox = (textBox2 = new TextBox());
		((ISupportInitialize)textBox).BeginInit();
		children7.Add(textBox);
		TextBox textBox4;
		TextBox textBox3 = (textBox4 = textBox2);
		context.PushParent(textBox4);
		TextBox textBox5 = textBox4;
		textBox5.Name = "ProfileNameInput";
		object element = textBox5;
		context.AvaloniaNameScope.Register("ProfileNameInput", element);
		StyledProperty<string?> textProperty3 = TextBox.TextProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileEditorViewModel_002CMerostrap_002EName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = TextBox.TextProperty;
		CompiledBinding binding6 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBox5.Bind(textProperty3, binding6);
		textBox5.MaxLength = 48;
		textBox5.PlaceholderText = "e.g. Deepwoken PvP";
		AutomationProperties.SetName(textBox5, "Profile name");
		context.PopParent();
		((ISupportInitialize)textBox3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel12).EndInit();
		Avalonia.Controls.Controls children8 = stackPanel5.Children;
		StackPanel stackPanel15;
		StackPanel stackPanel14 = (stackPanel15 = new StackPanel());
		((ISupportInitialize)stackPanel14).BeginInit();
		children8.Add(stackPanel14);
		StackPanel stackPanel16 = (stackPanel4 = stackPanel15);
		context.PushParent(stackPanel4);
		StackPanel stackPanel17 = stackPanel4;
		stackPanel17.Spacing = 8.0;
		Avalonia.Controls.Controls children9 = stackPanel17.Children;
		TextBlock textBlock13;
		TextBlock textBlock12 = (textBlock13 = new TextBlock());
		((ISupportInitialize)textBlock12).BeginInit();
		children9.Add(textBlock12);
		textBlock13.Text = "Game (optional)";
		textBlock13.FontWeight = FontWeight.DemiBold;
		((ISupportInitialize)textBlock13).EndInit();
		Avalonia.Controls.Controls children10 = stackPanel17.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children10.Add(border);
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Border border5 = border4;
		StyledProperty<IBrush?> backgroundProperty2 = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding7 = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(backgroundProperty2, binding7);
		border5.CornerRadius = new CornerRadius(8.0, 8.0, 8.0, 8.0);
		border5.Padding = new Thickness(12.0, 12.0, 12.0, 12.0);
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		border5.Child = grid6;
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 4;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(44.0, GridUnitType.Pixel)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(12.0, GridUnitType.Pixel)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid9.ColumnDefinitions = columnDefinitions;
		Avalonia.Controls.Controls children11 = grid9.Children;
		Border border7;
		Border border6 = (border7 = new Border());
		((ISupportInitialize)border6).BeginInit();
		children11.Add(border6);
		Border border8 = (border4 = border7);
		context.PushParent(border4);
		Border border9 = border4;
		border9.Width = 44.0;
		border9.Height = 44.0;
		border9.CornerRadius = new CornerRadius(6.0, 6.0, 6.0, 6.0);
		border9.ClipToBounds = true;
		Grid grid11;
		Grid grid10 = (grid11 = new Grid());
		((ISupportInitialize)grid10).BeginInit();
		border9.Child = grid10;
		Grid grid12 = (grid4 = grid11);
		context.PushParent(grid4);
		Grid grid13 = grid4;
		Avalonia.Controls.Controls children12 = grid13.Children;
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		children12.Add(lucide);
		Lucide lucide4;
		Lucide lucide3 = (lucide4 = lucide2);
		context.PushParent(lucide4);
		lucide4.Icon = LucideIconNames.Gamepad2;
		lucide4.Width = 24.0;
		lucide4.Height = 24.0;
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileEditorViewModel_002CMerostrap_002EHasSelectedIcon_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding8 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide4.Bind(isVisibleProperty, binding8);
		context.PopParent();
		((ISupportInitialize)lucide3).EndInit();
		Avalonia.Controls.Controls children13 = grid13.Children;
		Image image2;
		Image image = (image2 = new Image());
		((ISupportInitialize)image).BeginInit();
		children13.Add(image);
		Image image4;
		Image image3 = (image4 = image2);
		context.PushParent(image4);
		StyledProperty<IImage?> sourceProperty = Image.SourceProperty;
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileEditorViewModel_002CMerostrap_002ESelectedIcon_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Image.SourceProperty;
		CompiledBinding binding9 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		image4.Bind(sourceProperty, binding9);
		StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileEditorViewModel_002CMerostrap_002EHasSelectedIcon_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding10 = compiledBindingExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		image4.Bind(isVisibleProperty2, binding10);
		image4.Stretch = Stretch.UniformToFill;
		context.PopParent();
		((ISupportInitialize)image3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid12).EndInit();
		context.PopParent();
		((ISupportInitialize)border8).EndInit();
		Avalonia.Controls.Controls children14 = grid9.Children;
		StackPanel stackPanel19;
		StackPanel stackPanel18 = (stackPanel19 = new StackPanel());
		((ISupportInitialize)stackPanel18).BeginInit();
		children14.Add(stackPanel18);
		StackPanel stackPanel20 = (stackPanel4 = stackPanel19);
		context.PushParent(stackPanel4);
		StackPanel stackPanel21 = stackPanel4;
		Grid.SetColumn(stackPanel21, 2);
		stackPanel21.VerticalAlignment = VerticalAlignment.Center;
		stackPanel21.Spacing = 3.0;
		Avalonia.Controls.Controls children15 = stackPanel21.Children;
		TextBlock textBlock15;
		TextBlock textBlock14 = (textBlock15 = new TextBlock());
		((ISupportInitialize)textBlock14).BeginInit();
		children15.Add(textBlock14);
		TextBlock textBlock16 = (textBlock4 = textBlock15);
		context.PushParent(textBlock4);
		TextBlock textBlock17 = textBlock4;
		StyledProperty<string?> textProperty4 = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileEditorViewModel_002CMerostrap_002ESelectedGameName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding11 = compiledBindingExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock17.Bind(textProperty4, binding11);
		textBlock17.FontWeight = FontWeight.DemiBold;
		textBlock17.TextTrimming = TextTrimming.CharacterEllipsis;
		context.PopParent();
		((ISupportInitialize)textBlock16).EndInit();
		Avalonia.Controls.Controls children16 = stackPanel21.Children;
		TextBlock textBlock19;
		TextBlock textBlock18 = (textBlock19 = new TextBlock());
		((ISupportInitialize)textBlock18).BeginInit();
		children16.Add(textBlock18);
		TextBlock textBlock20 = (textBlock4 = textBlock19);
		context.PushParent(textBlock4);
		TextBlock textBlock21 = textBlock4;
		textBlock21.Text = "Apply this profile manually when you need it.";
		textBlock21.FontSize = 12.0;
		textBlock21.TextWrapping = TextWrapping.Wrap;
		StyledProperty<IBrush?> foregroundProperty2 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("TextFillColorSecondaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding12 = dynamicResourceExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock21.Bind(foregroundProperty2, binding12);
		context.PopParent();
		((ISupportInitialize)textBlock20).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel20).EndInit();
		Avalonia.Controls.Controls children17 = grid9.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children17.Add(button);
		Button button4;
		Button button3 = (button4 = button2);
		context.PushParent(button4);
		Button button5 = button4;
		Grid.SetColumn(button5, 3);
		StyledProperty<bool> isVisibleProperty3 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileEditorViewModel_002CMerostrap_002EHasGame_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding13 = compiledBindingExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button5.Bind(isVisibleProperty3, binding13);
		StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileEditorViewModel_002CMerostrap_002EClearGameCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding14 = compiledBindingExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button5.Bind(commandProperty, binding14);
		button5.Width = 32.0;
		button5.Height = 32.0;
		button5.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
		ToolTip.SetTip(button5, "Use as a General profile");
		AutomationProperties.SetName(button5, "Remove linked game");
		Lucide lucide6;
		Lucide lucide5 = (lucide6 = new Lucide());
		((ISupportInitialize)lucide5).BeginInit();
		button5.Content = lucide5;
		lucide6.Icon = LucideIconNames.X;
		lucide6.Width = 14.0;
		lucide6.Height = 14.0;
		((ISupportInitialize)lucide6).EndInit();
		context.PopParent();
		((ISupportInitialize)button3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		Avalonia.Controls.Controls children18 = stackPanel17.Children;
		Grid grid15;
		Grid grid14 = (grid15 = new Grid());
		((ISupportInitialize)grid14).BeginInit();
		children18.Add(grid14);
		Grid grid16 = (grid4 = grid15);
		context.PushParent(grid4);
		Grid grid17 = grid4;
		ColumnDefinitions columnDefinitions2 = new ColumnDefinitions();
		columnDefinitions2.Capacity = 3;
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(8.0, GridUnitType.Pixel)));
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid17.ColumnDefinitions = columnDefinitions2;
		Avalonia.Controls.Controls children19 = grid17.Children;
		TextBox textBox7;
		TextBox textBox6 = (textBox7 = new TextBox());
		((ISupportInitialize)textBox6).BeginInit();
		children19.Add(textBox6);
		TextBox textBox8 = (textBox4 = textBox7);
		context.PushParent(textBox4);
		TextBox textBox9 = textBox4;
		textBox9.Name = "GameSearchInput";
		element = textBox9;
		context.AvaloniaNameScope.Register("GameSearchInput", element);
		StyledProperty<string?> textProperty5 = TextBox.TextProperty;
		CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileEditorViewModel_002CMerostrap_002EQuery_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = TextBox.TextProperty;
		CompiledBinding binding15 = compiledBindingExtension11.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBox9.Bind(textProperty5, binding15);
		textBox9.PlaceholderText = "Search Roblox games";
		textBox9.AddHandler(InputElement.KeyDownEvent, context.RootObject.SearchKeyDown);
		AutomationProperties.SetName(textBox9, "Search Roblox games");
		context.PopParent();
		((ISupportInitialize)textBox8).EndInit();
		Avalonia.Controls.Controls children20 = grid17.Children;
		Button button7;
		Button button6 = (button7 = new Button());
		((ISupportInitialize)button6).BeginInit();
		children20.Add(button6);
		Button button8 = (button4 = button7);
		context.PushParent(button4);
		Button button9 = button4;
		Grid.SetColumn(button9, 2);
		button9.Content = "Search";
		StyledProperty<ICommand?> commandProperty2 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileEditorViewModel_002CMerostrap_002ESearchCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding16 = compiledBindingExtension12.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button9.Bind(commandProperty2, binding16);
		context.PopParent();
		((ISupportInitialize)button8).EndInit();
		context.PopParent();
		((ISupportInitialize)grid16).EndInit();
		Avalonia.Controls.Controls children21 = stackPanel17.Children;
		ProgressBar progressBar2;
		ProgressBar progressBar = (progressBar2 = new ProgressBar());
		((ISupportInitialize)progressBar).BeginInit();
		children21.Add(progressBar);
		ProgressBar progressBar4;
		ProgressBar progressBar3 = (progressBar4 = progressBar2);
		context.PushParent(progressBar4);
		StyledProperty<bool> isVisibleProperty4 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileEditorViewModel_002CMerostrap_002EIsSearching_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding17 = compiledBindingExtension13.ProvideValue(context);
		context.ProvideTargetProperty = null;
		progressBar4.Bind(isVisibleProperty4, binding17);
		progressBar4.IsIndeterminate = true;
		progressBar4.Height = 3.0;
		context.PopParent();
		((ISupportInitialize)progressBar3).EndInit();
		Avalonia.Controls.Controls children22 = stackPanel17.Children;
		TextBlock textBlock23;
		TextBlock textBlock22 = (textBlock23 = new TextBlock());
		((ISupportInitialize)textBlock22).BeginInit();
		children22.Add(textBlock22);
		TextBlock textBlock24 = (textBlock4 = textBlock23);
		context.PushParent(textBlock4);
		TextBlock textBlock25 = textBlock4;
		StyledProperty<string?> textProperty6 = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileEditorViewModel_002CMerostrap_002ESearchStatus_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding18 = compiledBindingExtension14.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock25.Bind(textProperty6, binding18);
		textBlock25.TextWrapping = TextWrapping.Wrap;
		textBlock25.FontSize = 12.0;
		StyledProperty<IBrush?> foregroundProperty3 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension5 = new DynamicResourceExtension("TextFillColorSecondaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding19 = dynamicResourceExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock25.Bind(foregroundProperty3, binding19);
		context.PopParent();
		((ISupportInitialize)textBlock24).EndInit();
		Avalonia.Controls.Controls children23 = stackPanel17.Children;
		ListBox listBox2;
		ListBox listBox = (listBox2 = new ListBox());
		((ISupportInitialize)listBox).BeginInit();
		children23.Add(listBox);
		ListBox listBox4;
		ListBox listBox3 = (listBox4 = listBox2);
		context.PushParent(listBox4);
		listBox4.Name = "GameResults";
		element = listBox4;
		context.AvaloniaNameScope.Register("GameResults", element);
		StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension15 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileEditorViewModel_002CMerostrap_002EResults_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding20 = compiledBindingExtension15.ProvideValue(context);
		context.ProvideTargetProperty = null;
		listBox4.Bind(itemsSourceProperty, binding20);
		listBox4.AddHandler(SelectingItemsControl.SelectionChangedEvent, context.RootObject.GameSelected);
		listBox4.MaxHeight = 190.0;
		listBox4.Background = new ImmutableSolidColorBrush(16777215u);
		listBox4.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
		AutomationProperties.SetName(listBox4, "Game search results");
		DataTemplate dataTemplate;
		DataTemplate itemTemplate = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.DataType = typeof(ProfileGameChoice);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_22.Build_1), context);
		context.PopParent();
		listBox4.ItemTemplate = itemTemplate;
		context.PopParent();
		((ISupportInitialize)listBox3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel16).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer3).EndInit();
		Avalonia.Controls.Controls children24 = grid5.Children;
		StackPanel stackPanel23;
		StackPanel stackPanel22 = (stackPanel23 = new StackPanel());
		((ISupportInitialize)stackPanel22).BeginInit();
		children24.Add(stackPanel22);
		StackPanel stackPanel24 = (stackPanel4 = stackPanel23);
		context.PushParent(stackPanel4);
		StackPanel stackPanel25 = stackPanel4;
		Grid.SetRow(stackPanel25, 1);
		stackPanel25.Spacing = 12.0;
		stackPanel25.Margin = new Thickness(0.0, 16.0, 0.0, 0.0);
		Avalonia.Controls.Controls children25 = stackPanel25.Children;
		TextBlock textBlock27;
		TextBlock textBlock26 = (textBlock27 = new TextBlock());
		((ISupportInitialize)textBlock26).BeginInit();
		children25.Add(textBlock26);
		TextBlock textBlock28 = (textBlock4 = textBlock27);
		context.PushParent(textBlock4);
		TextBlock textBlock29 = textBlock4;
		StyledProperty<string?> textProperty7 = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension16 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileEditorViewModel_002CMerostrap_002EError_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding21 = compiledBindingExtension16.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock29.Bind(textProperty7, binding21);
		textBlock29.TextWrapping = TextWrapping.Wrap;
		StyledProperty<IBrush?> foregroundProperty4 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension6 = new DynamicResourceExtension("SystemFillColorCriticalBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding22 = dynamicResourceExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock29.Bind(foregroundProperty4, binding22);
		context.PopParent();
		((ISupportInitialize)textBlock28).EndInit();
		Avalonia.Controls.Controls children26 = stackPanel25.Children;
		StackPanel stackPanel27;
		StackPanel stackPanel26 = (stackPanel27 = new StackPanel());
		((ISupportInitialize)stackPanel26).BeginInit();
		children26.Add(stackPanel26);
		StackPanel stackPanel28 = (stackPanel4 = stackPanel27);
		context.PushParent(stackPanel4);
		StackPanel stackPanel29 = stackPanel4;
		stackPanel29.Orientation = Orientation.Horizontal;
		stackPanel29.Spacing = 8.0;
		stackPanel29.HorizontalAlignment = HorizontalAlignment.Right;
		Avalonia.Controls.Controls children27 = stackPanel29.Children;
		Button button11;
		Button button10 = (button11 = new Button());
		((ISupportInitialize)button10).BeginInit();
		children27.Add(button10);
		button11.Content = "Cancel";
		button11.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.CancelClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button11.MinWidth = 90.0;
		((ISupportInitialize)button11).EndInit();
		Avalonia.Controls.Controls children28 = stackPanel29.Children;
		Button button13;
		Button button12 = (button13 = new Button());
		((ISupportInitialize)button12).BeginInit();
		children28.Add(button12);
		Button button14 = (button4 = button13);
		context.PushParent(button4);
		Button button15 = button4;
		button15.Name = "SaveProfileButton";
		element = button15;
		context.AvaloniaNameScope.Register("SaveProfileButton", element);
		CompiledBindingExtension compiledBindingExtension17 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESettings_002EProfileEditorViewModel_002CMerostrap_002ESaveLabel_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ContentControl.ContentProperty;
		CompiledBinding compiledBinding = compiledBindingExtension17.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_4(button15, compiledBinding);
		button15.Classes.Add("accent");
		button15.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.SaveClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button15.MinWidth = 120.0;
		context.PopParent();
		((ISupportInitialize)button14).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel28).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel24).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(ProfileEditorWindow P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
