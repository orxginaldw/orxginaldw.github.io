using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Data;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using ColorPicker;
using ColorPicker.Models;
using CompiledAvaloniaXaml;
using Merostrap.Resources;
using Merostrap.UI.Elements.Base;

namespace Merostrap.UI.Elements.Dialogs;

internal class ColorPickerDialog : AvaloniaWindow
{
	private bool _isUpdating;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal SquarePicker Part_SquarePicker;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBox Part_HexBox;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public ColorPickerDialog()
	{
		InitializeComponent();
		Part_SquarePicker.ColorChanged += Part_SquarePicker_ColorChanged;
	}

	public ColorPickerDialog(string initialHex)
		: this()
	{
		if (!string.IsNullOrEmpty(initialHex) && Color.TryParse(initialHex, out var color))
		{
			UpdatePickerFromColor(color);
			Part_HexBox.Text = initialHex.ToUpperInvariant();
		}
	}

	private void Part_SquarePicker_ColorChanged(object? sender, EventArgs e)
	{
		if (!_isUpdating)
		{
			_isUpdating = true;
			NotifyableColor color = Part_SquarePicker.Color;
			string text = $"#{(byte)color.RGB_R:X2}{(byte)color.RGB_G:X2}{(byte)color.RGB_B:X2}";
			Part_HexBox.Text = text;
			_isUpdating = false;
		}
	}

	private void Part_HexBox_TextChanged(object? sender, TextChangedEventArgs e)
	{
		if (!_isUpdating && Part_HexBox != null && Part_SquarePicker != null && !string.IsNullOrWhiteSpace(Part_HexBox.Text) && Color.TryParse(Part_HexBox.Text, out var color))
		{
			_isUpdating = true;
			UpdatePickerFromColor(color);
			_isUpdating = false;
		}
	}

	private void UpdatePickerFromColor(Color color)
	{
		NotifyableColor color2 = Part_SquarePicker.Color;
		color2.A = (int)color.A;
		color2.RGB_R = (int)color.R;
		color2.RGB_G = (int)color.G;
		color2.RGB_B = (int)color.B;
	}

	private void OnConfirm_Click(object? sender, RoutedEventArgs e)
	{
		NotifyableColor color = Part_SquarePicker.Color;
		string dialogResult = $"#{(byte)color.RGB_R:X2}{(byte)color.RGB_G:X2}{(byte)color.RGB_B:X2}";
		Close(dialogResult);
	}

	private void OnCancel_Click(object? sender, RoutedEventArgs e)
	{
		Close(null);
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		Part_SquarePicker = nameScope?.Find<SquarePicker>("Part_SquarePicker");
		Part_HexBox = nameScope?.Find<TextBox>("Part_HexBox");
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, ColorPickerDialog P_1)
	{
		XamlIlContext.Context<ColorPickerDialog> context = new XamlIlContext.Context<ColorPickerDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FColorPickerDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/ColorPickerDialog.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Title = Strings.Common_ColorPicker;
		P_1.Width = 400.0;
		P_1.Height = 450.0;
		P_1.CanResize = true;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterOwner;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid4.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid4.Children;
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		children.Add(stackPanel);
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		StackPanel stackPanel5 = stackPanel4;
		Grid.SetRow(stackPanel5, 0);
		stackPanel5.Margin = new Thickness(20.0, 20.0, 20.0, 20.0);
		stackPanel5.Spacing = 20.0;
		Avalonia.Controls.Controls children2 = stackPanel5.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children2.Add(border);
		border2.CornerRadius = new CornerRadius(4.0, 4.0, 4.0, 4.0);
		border2.ClipToBounds = true;
		SquarePicker squarePicker2;
		SquarePicker squarePicker = (squarePicker2 = new SquarePicker());
		((ISupportInitialize)squarePicker).BeginInit();
		border2.Child = squarePicker;
		squarePicker2.Name = "Part_SquarePicker";
		object element = squarePicker2;
		context.AvaloniaNameScope.Register("Part_SquarePicker", element);
		squarePicker2.Height = 220.0;
		squarePicker2.HorizontalAlignment = HorizontalAlignment.Stretch;
		((ISupportInitialize)squarePicker2).EndInit();
		((ISupportInitialize)border2).EndInit();
		Avalonia.Controls.Controls children3 = stackPanel5.Children;
		StackPanel stackPanel7;
		StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
		((ISupportInitialize)stackPanel6).BeginInit();
		children3.Add(stackPanel6);
		StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
		context.PushParent(stackPanel4);
		StackPanel stackPanel9 = stackPanel4;
		stackPanel9.Spacing = 8.0;
		Avalonia.Controls.Controls children4 = stackPanel9.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children4.Add(textBlock);
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = textBlock2);
		context.PushParent(textBlock4);
		textBlock4.Text = Strings.Common_HexCode;
		textBlock4.FontSize = 12.0;
		textBlock4.FontWeight = FontWeight.DemiBold;
		StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("TextFillColorSecondaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock4.Bind(foregroundProperty, binding);
		context.PopParent();
		((ISupportInitialize)textBlock3).EndInit();
		Avalonia.Controls.Controls children5 = stackPanel9.Children;
		TextBox textBox2;
		TextBox textBox = (textBox2 = new TextBox());
		((ISupportInitialize)textBox).BeginInit();
		children5.Add(textBox);
		textBox2.Name = "Part_HexBox";
		element = textBox2;
		context.AvaloniaNameScope.Register("Part_HexBox", element);
		textBox2.PlaceholderText = "#RRGGBB";
		textBox2.VerticalContentAlignment = VerticalAlignment.Center;
		textBox2.AddHandler(TextBox.TextChangedEvent, context.RootObject.Part_HexBox_TextChanged);
		((ISupportInitialize)textBox2).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel8).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		Avalonia.Controls.Controls children6 = grid4.Children;
		Border border4;
		Border border3 = (border4 = new Border());
		((ISupportInitialize)border3).BeginInit();
		children6.Add(border3);
		Border border6;
		Border border5 = (border6 = border4);
		context.PushParent(border6);
		Grid.SetRow(border6, 1);
		border6.Padding = new Thickness(15.0, 15.0, 15.0, 15.0);
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border6.Bind(backgroundProperty, binding2);
		StackPanel stackPanel11;
		StackPanel stackPanel10 = (stackPanel11 = new StackPanel());
		((ISupportInitialize)stackPanel10).BeginInit();
		border6.Child = stackPanel10;
		stackPanel11.Orientation = Orientation.Horizontal;
		stackPanel11.HorizontalAlignment = HorizontalAlignment.Right;
		stackPanel11.Spacing = 12.0;
		Avalonia.Controls.Controls children7 = stackPanel11.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children7.Add(button);
		button2.Content = Strings.Common_Confirm;
		button2.Width = 100.0;
		button2.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.OnConfirm_Click), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button2.Classes.Add("accent");
		((ISupportInitialize)button2).EndInit();
		Avalonia.Controls.Controls children8 = stackPanel11.Children;
		Button button5;
		Button button4 = (button5 = new Button());
		((ISupportInitialize)button4).BeginInit();
		children8.Add(button4);
		button5.Content = Strings.Common_Cancel;
		button5.Width = 100.0;
		button5.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.OnCancel_Click), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		((ISupportInitialize)button5).EndInit();
		((ISupportInitialize)stackPanel11).EndInit();
		context.PopParent();
		((ISupportInitialize)border5).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(ColorPickerDialog P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
