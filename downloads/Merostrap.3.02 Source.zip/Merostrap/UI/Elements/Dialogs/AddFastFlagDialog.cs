using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Runtime.CompilerServices;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Platform.Storage;
using Avalonia.Styling;
using CompiledAvaloniaXaml;
using FluentAvalonia.UI.Controls;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.Enums.Messagebox;
using Merostrap.Resources;
using Merostrap.UI.Elements.Base;
using Merostrap.UI.Elements.Controls;

namespace Merostrap.UI.Elements.Dialogs;

internal class AddFastFlagDialog : AvaloniaWindow
{
	[CompilerGenerated]
	private class XamlClosure_18
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<AddFastFlagDialog> context = CreateContext(P_0);
			context.IntermediateRoot = new UniformGrid();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((AvaloniaObject)obj).SetValue(UniformGrid.ColumnsProperty, 2, BindingPriority.Template);
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<AddFastFlagDialog> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<AddFastFlagDialog> context = new XamlIlContext.Context<AddFastFlagDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FAddFastFlagDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/AddFastFlagDialog.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (AddFastFlagDialog)service;
				}
			}
			return context;
		}
	}

	public MessageBoxResult Result = MessageBoxResult.Cancel;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TabControl Tabs;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBox FlagNameTextBox;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBox FlagValueTextBox;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBox JsonTextBox;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button OkButton;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public AddFastFlagDialog()
	{
		InitializeComponent();
		Tabs.SelectionChanged += (object? s, SelectionChangedEventArgs e) =>
		{
			UpdateUiState();
		};
		FlagNameTextBox.TextChanged += (object? s, TextChangedEventArgs e) =>
		{
			UpdateUiState();
		};
		JsonTextBox.TextChanged += (object? s, TextChangedEventArgs e) =>
		{
			UpdateUiState();
		};
	}

	private void UpdateUiState()
	{
		if (Tabs != null && OkButton != null)
		{
			bool isEnabled = false;
			if (Tabs.SelectedIndex == 0)
			{
				isEnabled = !string.IsNullOrWhiteSpace(FlagNameTextBox.Text);
			}
			else if (Tabs.SelectedIndex == 1)
			{
				isEnabled = !string.IsNullOrWhiteSpace(JsonTextBox.Text);
			}
			OkButton.IsEnabled = isEnabled;
		}
	}

	private void OKButton_Click(object sender, RoutedEventArgs e)
	{
		Result = MessageBoxResult.OK;
		Close();
	}

	private void CancelButton_Click(object sender, RoutedEventArgs e)
	{
		Result = MessageBoxResult.Cancel;
		Close();
	}

	private async void ImportButton_Click(object sender, RoutedEventArgs e)
	{
		TopLevel topLevel = TopLevel.GetTopLevel(this);
		if (topLevel == null)
		{
			return;
		}
		FilePickerOpenOptions filePickerOpenOptions = new FilePickerOpenOptions();
		filePickerOpenOptions.Title = "Import Flags";
		filePickerOpenOptions.AllowMultiple = false;
		filePickerOpenOptions.FileTypeFilter = new _003C_003Ez__ReadOnlyArray<FilePickerFileType>(new FilePickerFileType[3]
		{
			new FilePickerFileType("Configuration Files")
			{
				Patterns = new _003C_003Ez__ReadOnlyArray<string>(new string[2] { "*.json", "*.txt" })
			},
			new FilePickerFileType("JSON Files")
			{
				Patterns = new _003C_003Ez__ReadOnlySingleElementList<string>("*.json")
			},
			new FilePickerFileType("Text Files")
			{
				Patterns = new _003C_003Ez__ReadOnlySingleElementList<string>("*.txt")
			}
		});
		FilePickerOpenOptions options = filePickerOpenOptions;
		IReadOnlyList<IStorageFile> readOnlyList = await topLevel.StorageProvider.OpenFilePickerAsync(options);
		if (readOnlyList.Count <= 0)
		{
			return;
		}
		await using Stream stream = await readOnlyList[0].OpenReadAsync();
		using StreamReader reader = new StreamReader(stream);
		TextBox jsonTextBox = JsonTextBox;
		jsonTextBox.Text = await reader.ReadToEndAsync();
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		Tabs = nameScope?.Find<TabControl>("Tabs");
		FlagNameTextBox = nameScope?.Find<TextBox>("FlagNameTextBox");
		FlagValueTextBox = nameScope?.Find<TextBox>("FlagValueTextBox");
		JsonTextBox = nameScope?.Find<TextBox>("JsonTextBox");
		OkButton = nameScope?.Find<Button>("OkButton");
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, AddFastFlagDialog P_1)
	{
		XamlIlContext.Context<AddFastFlagDialog> context = new XamlIlContext.Context<AddFastFlagDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FAddFastFlagDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/AddFastFlagDialog.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Title = Strings.Dialog_AddFastFlag_Title;
		P_1.Width = 480.0;
		P_1.SizeToContent = SizeToContent.Height;
		P_1.CanResize = false;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid4.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid4.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children.Add(border);
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Border border5 = border4;
		Grid.SetRow(border5, 0);
		border5.Margin = new Thickness(16.0, 16.0, 16.0, 16.0);
		border5.CornerRadius = new CornerRadius(8.0, 8.0, 8.0, 8.0);
		border5.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("CardStrokeColorDefaultBrush");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(borderBrushProperty, binding);
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(backgroundProperty, binding2);
		TabControl tabControl2;
		TabControl tabControl = (tabControl2 = new TabControl());
		((ISupportInitialize)tabControl).BeginInit();
		border5.Child = tabControl;
		tabControl2.Name = "Tabs";
		object element = tabControl2;
		context.AvaloniaNameScope.Register("Tabs", element);
		tabControl2.ItemsPanel = new ItemsPanelTemplate
		{
			Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_18.Build_1), context)
		};
		Styles styles = tabControl2.Styles;
		Style style = new Style();
		style.Selector = ((Selector?)null).OfType(typeof(TabItem));
		Setter setter = new Setter();
		setter.Property = Layoutable.HorizontalAlignmentProperty;
		setter.Value = HorizontalAlignment.Stretch;
		style.Add(setter);
		Setter setter2 = new Setter();
		setter2.Property = ContentControl.HorizontalContentAlignmentProperty;
		setter2.Value = HorizontalAlignment.Center;
		style.Add(setter2);
		Setter setter3 = new Setter();
		setter3.Property = TemplatedControl.FontSizeProperty;
		setter3.Value = 18.0;
		style.Add(setter3);
		styles.Add(style);
		ItemCollection items = tabControl2.Items;
		TabItem tabItem2;
		TabItem tabItem = (tabItem2 = new TabItem());
		((ISupportInitialize)tabItem).BeginInit();
		items.Add(tabItem);
		tabItem2.Header = Strings.Common_AddSingle;
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		TabItemHelper.SetIcon(tabItem2, lucide);
		lucide2.Icon = LucideIconNames.Plus;
		((ISupportInitialize)lucide2).EndInit();
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		tabItem2.Content = stackPanel;
		stackPanel2.Spacing = 12.0;
		stackPanel2.Margin = new Thickness(0.0, 0.0, 0.0, 8.0);
		Avalonia.Controls.Controls children2 = stackPanel2.Children;
		Grid grid6;
		Grid grid5 = (grid6 = new Grid());
		((ISupportInitialize)grid5).BeginInit();
		children2.Add(grid5);
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 2;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(75.0, GridUnitType.Pixel)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid6.ColumnDefinitions = columnDefinitions;
		RowDefinitions rowDefinitions2 = new RowDefinitions();
		rowDefinitions2.Capacity = 1;
		rowDefinitions2.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid6.RowDefinitions = rowDefinitions2;
		grid6.ColumnSpacing = 12.0;
		Avalonia.Controls.Controls children3 = grid6.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children3.Add(textBlock);
		Grid.SetColumn(textBlock2, 0);
		textBlock2.VerticalAlignment = VerticalAlignment.Center;
		textBlock2.Text = Strings.Common_Name;
		((ISupportInitialize)textBlock2).EndInit();
		Avalonia.Controls.Controls children4 = grid6.Children;
		TextBox textBox2;
		TextBox textBox = (textBox2 = new TextBox());
		((ISupportInitialize)textBox).BeginInit();
		children4.Add(textBox);
		Grid.SetColumn(textBox2, 1);
		textBox2.Name = "FlagNameTextBox";
		element = textBox2;
		context.AvaloniaNameScope.Register("FlagNameTextBox", element);
		textBox2.PlaceholderText = "FFlagExample";
		((ISupportInitialize)textBox2).EndInit();
		((ISupportInitialize)grid6).EndInit();
		Avalonia.Controls.Controls children5 = stackPanel2.Children;
		Grid grid8;
		Grid grid7 = (grid8 = new Grid());
		((ISupportInitialize)grid7).BeginInit();
		children5.Add(grid7);
		ColumnDefinitions columnDefinitions2 = new ColumnDefinitions();
		columnDefinitions2.Capacity = 2;
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(75.0, GridUnitType.Pixel)));
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid8.ColumnDefinitions = columnDefinitions2;
		grid8.ColumnSpacing = 12.0;
		Avalonia.Controls.Controls children6 = grid8.Children;
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		children6.Add(textBlock3);
		Grid.SetColumn(textBlock4, 0);
		textBlock4.VerticalAlignment = VerticalAlignment.Center;
		textBlock4.Text = Strings.Common_Value;
		((ISupportInitialize)textBlock4).EndInit();
		Avalonia.Controls.Controls children7 = grid8.Children;
		TextBox textBox4;
		TextBox textBox3 = (textBox4 = new TextBox());
		((ISupportInitialize)textBox3).BeginInit();
		children7.Add(textBox3);
		Grid.SetColumn(textBox4, 1);
		textBox4.Name = "FlagValueTextBox";
		element = textBox4;
		context.AvaloniaNameScope.Register("FlagValueTextBox", element);
		textBox4.PlaceholderText = "True";
		((ISupportInitialize)textBox4).EndInit();
		((ISupportInitialize)grid8).EndInit();
		((ISupportInitialize)stackPanel2).EndInit();
		((ISupportInitialize)tabItem2).EndInit();
		ItemCollection items2 = tabControl2.Items;
		TabItem tabItem4;
		TabItem tabItem3 = (tabItem4 = new TabItem());
		((ISupportInitialize)tabItem3).BeginInit();
		items2.Add(tabItem3);
		tabItem4.Header = Strings.Common_ImportJson;
		Lucide lucide4;
		Lucide lucide3 = (lucide4 = new Lucide());
		((ISupportInitialize)lucide3).BeginInit();
		TabItemHelper.SetIcon(tabItem4, lucide3);
		lucide4.Icon = LucideIconNames.FileBraces;
		((ISupportInitialize)lucide4).EndInit();
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = new StackPanel());
		((ISupportInitialize)stackPanel3).BeginInit();
		tabItem4.Content = stackPanel3;
		stackPanel4.Spacing = 12.0;
		stackPanel4.Margin = new Thickness(0.0, 0.0, 0.0, 8.0);
		Avalonia.Controls.Controls children8 = stackPanel4.Children;
		TextBox textBox6;
		TextBox textBox5 = (textBox6 = new TextBox());
		((ISupportInitialize)textBox5).BeginInit();
		children8.Add(textBox5);
		textBox6.Name = "JsonTextBox";
		element = textBox6;
		context.AvaloniaNameScope.Register("JsonTextBox", element);
		textBox6.AcceptsReturn = true;
		textBox6.AcceptsTab = true;
		textBox6.MinHeight = 120.0;
		textBox6.MaxHeight = 300.0;
		textBox6.TextWrapping = TextWrapping.Wrap;
		textBox6.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
		textBox6.VerticalContentAlignment = VerticalAlignment.Center;
		textBox6.PlaceholderText = "{\n    \"FFlagDebugDisplayFPS\": \"True\"\n}";
		((ISupportInitialize)textBox6).EndInit();
		Avalonia.Controls.Controls children9 = stackPanel4.Children;
		IconButton iconButton2;
		IconButton iconButton = (iconButton2 = new IconButton());
		((ISupportInitialize)iconButton).BeginInit();
		children9.Add(iconButton);
		iconButton2.Content = Strings.Common_ImportFromFile;
		iconButton2.Icon = LucideIconNames.FileText;
		iconButton2.HorizontalAlignment = HorizontalAlignment.Stretch;
		iconButton2.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.ImportButton_Click), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		((ISupportInitialize)iconButton2).EndInit();
		((ISupportInitialize)stackPanel4).EndInit();
		((ISupportInitialize)tabItem4).EndInit();
		((ISupportInitialize)tabControl2).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		Avalonia.Controls.Controls children10 = grid4.Children;
		Border border7;
		Border border6 = (border7 = new Border());
		((ISupportInitialize)border6).BeginInit();
		children10.Add(border6);
		Border border8 = (border4 = border7);
		context.PushParent(border4);
		Border border9 = border4;
		Grid.SetRow(border9, 1);
		border9.Padding = new Thickness(15.0, 15.0, 15.0, 15.0);
		StyledProperty<IBrush?> backgroundProperty2 = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding3 = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border9.Bind(backgroundProperty2, binding3);
		StackPanel stackPanel6;
		StackPanel stackPanel5 = (stackPanel6 = new StackPanel());
		((ISupportInitialize)stackPanel5).BeginInit();
		border9.Child = stackPanel5;
		stackPanel6.Orientation = Orientation.Horizontal;
		stackPanel6.HorizontalAlignment = HorizontalAlignment.Right;
		stackPanel6.Spacing = 12.0;
		Avalonia.Controls.Controls children11 = stackPanel6.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children11.Add(button);
		button2.Name = "OkButton";
		element = button2;
		context.AvaloniaNameScope.Register("OkButton", element);
		button2.Content = Strings.Common_OK;
		button2.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.OKButton_Click), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button2.Width = 100.0;
		button2.IsEnabled = false;
		((ISupportInitialize)button2).EndInit();
		Avalonia.Controls.Controls children12 = stackPanel6.Children;
		Button button5;
		Button button4 = (button5 = new Button());
		((ISupportInitialize)button4).BeginInit();
		children12.Add(button4);
		button5.Content = Strings.Common_Cancel;
		button5.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.CancelButton_Click), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		button5.Width = 100.0;
		((ISupportInitialize)button5).EndInit();
		((ISupportInitialize)stackPanel6).EndInit();
		context.PopParent();
		((ISupportInitialize)border8).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(AddFastFlagDialog P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
