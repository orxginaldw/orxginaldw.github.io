using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Controls.Shapes;
using Avalonia.Data;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using CompiledAvaloniaXaml;
using FluentAvalonia.UI.Controls;
using LucideAvalonia.Enum;
using Merostrap.Models;
using Merostrap.Models.APIs.Config;
using Merostrap.Resources;
using Merostrap.UI.Elements.Base;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.ViewModels.Dialogs;

namespace Merostrap.UI.Elements.Dialogs;

internal class CommunityModInfoDialog : AvaloniaWindow
{
	[CompilerGenerated]
	private class XamlClosure_19
	{
		public static object? Build_1(IServiceProvider? P_0)
		{
			XamlIlContext.Context<CommunityModInfoDialog> context = CreateContext(P_0);
			context.IntermediateRoot = new WrapPanel();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			((AvaloniaObject)obj).SetValue(Layoutable.HorizontalAlignmentProperty, HorizontalAlignment.Center, BindingPriority.Template);
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<CommunityModInfoDialog?>? CreateContext(IServiceProvider? P_0)
		{
			XamlIlContext.Context<CommunityModInfoDialog> context = new XamlIlContext.Context<CommunityModInfoDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FCommunityModInfoDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/CommunityModInfoDialog.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (CommunityModInfoDialog)service;
				}
			}
			return context;
		}

		public static object? Build_2(IServiceProvider? P_0)
		{
			XamlIlContext.Context<CommunityModInfoDialog> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Border border = (Border)obj;
			context.PushParent(border);
			border.Width = 42.0;
			border.Height = 42.0;
			border.Margin = new Thickness(4.0, 4.0, 4.0, 4.0);
			border.Padding = new Thickness(4.0, 4.0, 4.0, 4.0);
			border.CornerRadius = new CornerRadius(6.0, 6.0, 6.0, 6.0);
			StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("ControlFillColorSecondaryBrush");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border.Bind(backgroundProperty, binding);
			Viewbox viewbox2;
			Viewbox viewbox = (viewbox2 = new Viewbox());
			((ISupportInitialize)viewbox).BeginInit();
			border.Child = viewbox;
			Viewbox viewbox4;
			Viewbox viewbox3 = (viewbox4 = viewbox2);
			context.PushParent(viewbox4);
			Path path2;
			Path path = (path2 = new Path());
			((ISupportInitialize)path).BeginInit();
			viewbox4.Child = path;
			Path path4;
			Path path3 = (path4 = path2);
			context.PushParent(path4);
			StyledProperty<Geometry?> dataProperty = Path.DataProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EGlyphItem_002CMerostrap_002EData_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Path.DataProperty;
			CompiledBinding binding2 = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			path4.Bind(dataProperty, binding2);
			StyledProperty<IBrush?> fillProperty = Shape.FillProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EModels_002EGlyphItem_002CMerostrap_002EBrush_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Shape.FillProperty;
			CompiledBinding binding3 = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			path4.Bind(fillProperty, binding3);
			context.PopParent();
			((ISupportInitialize)path3).EndInit();
			context.PopParent();
			((ISupportInitialize)viewbox3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}
	}

	[CompilerGenerated]
	private static Action<object?>? _0021XamlIlPopulateOverride;

	public CommunityModInfoViewModel? ViewModel { get; }

	public CommunityModInfoDialog()
	{
		InitializeComponent();
	}

	public CommunityModInfoDialog(CommunityMod mod)
		: this()
	{
		ViewModel = new CommunityModInfoViewModel(mod, this);
		DataContext = ViewModel;
		ViewModel.Initialize();
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider? P_0, CommunityModInfoDialog? P_1)
	{
		XamlIlContext.Context<CommunityModInfoDialog> context = new XamlIlContext.Context<CommunityModInfoDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FDialogs_002FCommunityModInfoDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Dialogs/CommunityModInfoDialog.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Title = Strings.Menu_CommunityModInfo_Title;
		P_1.Width = 650.0;
		P_1.SizeToContent = SizeToContent.Height;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		grid4.Margin = new Thickness(16.0, 0.0, 16.0, 16.0);
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 2;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(320.0, GridUnitType.Pixel)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid4.ColumnDefinitions = columnDefinitions;
		Avalonia.Controls.Controls children = grid4.Children;
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		children.Add(stackPanel);
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		StackPanel stackPanel5 = stackPanel4;
		Grid.SetColumn(stackPanel5, 0);
		stackPanel5.Margin = new Thickness(0.0, 0.0, 16.0, 0.0);
		stackPanel5.Spacing = 12.0;
		Avalonia.Controls.Controls children2 = stackPanel5.Children;
		Card card2;
		Card card = (card2 = new Card());
		((ISupportInitialize)card).BeginInit();
		children2.Add(card);
		Card card4;
		Card card3 = (card4 = card2);
		context.PushParent(card4);
		Card card5 = card4;
		card5.Height = 180.0;
		card5.ClipToBounds = true;
		Panel panel2;
		Panel panel = (panel2 = new Panel());
		((ISupportInitialize)panel).BeginInit();
		card5.Content = panel;
		Panel panel4;
		Panel panel3 = (panel4 = panel2);
		context.PushParent(panel4);
		Avalonia.Controls.Controls children3 = panel4.Children;
		RemoteImage remoteImage2;
		RemoteImage remoteImage = (remoteImage2 = new RemoteImage());
		((ISupportInitialize)remoteImage).BeginInit();
		children3.Add(remoteImage);
		RemoteImage remoteImage4;
		RemoteImage remoteImage3 = (remoteImage4 = remoteImage2);
		context.PushParent(remoteImage4);
		StyledProperty<string?> urlProperty = RemoteImage.UrlProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ECommunityModInfoViewModel_002CMerostrap_002EMod_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EModels_002EAPIs_002EConfig_002ECommunityMod_002CMerostrap_002EThumbnailUrl_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = RemoteImage.UrlProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		remoteImage4.Bind(urlProperty, binding);
		remoteImage4.Stretch = Stretch.UniformToFill;
		RenderOptions.SetBitmapInterpolationMode(remoteImage4, BitmapInterpolationMode.HighQuality);
		context.PopParent();
		((ISupportInitialize)remoteImage3).EndInit();
		context.PopParent();
		((ISupportInitialize)panel3).EndInit();
		context.PopParent();
		((ISupportInitialize)card3).EndInit();
		Avalonia.Controls.Controls children4 = stackPanel5.Children;
		Card card7;
		Card card6 = (card7 = new Card());
		((ISupportInitialize)card6).BeginInit();
		children4.Add(card6);
		Card card8 = (card4 = card7);
		context.PushParent(card4);
		Card card9 = card4;
		card9.Padding = new Thickness(12.0, 12.0, 12.0, 12.0);
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ECommunityModInfoViewModel_002CMerostrap_002EMod_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EModels_002EAPIs_002EConfig_002ECommunityMod_002CMerostrap_002EIsColorMod_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		card9.Bind(isVisibleProperty, binding2);
		StackPanel stackPanel7;
		StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
		((ISupportInitialize)stackPanel6).BeginInit();
		card9.Content = stackPanel6;
		StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
		context.PushParent(stackPanel4);
		StackPanel stackPanel9 = stackPanel4;
		stackPanel9.Spacing = 8.0;
		Avalonia.Controls.Controls children5 = stackPanel9.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children5.Add(textBlock);
		textBlock2.Text = Strings.Common_GlyphPreview;
		textBlock2.Margin = new Thickness(4.0, 0.0, 0.0, 0.0);
		textBlock2.FontSize = 12.0;
		textBlock2.FontWeight = FontWeight.DemiBold;
		((ISupportInitialize)textBlock2).EndInit();
		Avalonia.Controls.Controls children6 = stackPanel9.Children;
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		children6.Add(scrollViewer);
		ScrollViewer scrollViewer4;
		ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
		context.PushParent(scrollViewer4);
		scrollViewer4.MaxHeight = 160.0;
		scrollViewer4.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
		Panel panel6;
		Panel panel5 = (panel6 = new Panel());
		((ISupportInitialize)panel5).BeginInit();
		scrollViewer4.Content = panel5;
		Panel panel7 = (panel4 = panel6);
		context.PushParent(panel4);
		Panel panel8 = panel4;
		Avalonia.Controls.Controls children7 = panel8.Children;
		ItemsControl itemsControl2;
		ItemsControl itemsControl = (itemsControl2 = new ItemsControl());
		((ISupportInitialize)itemsControl).BeginInit();
		children7.Add(itemsControl);
		ItemsControl itemsControl4;
		ItemsControl itemsControl3 = (itemsControl4 = itemsControl2);
		context.PushParent(itemsControl4);
		StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ECommunityModInfoViewModel_002CMerostrap_002EGlyphItems_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding3 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		itemsControl4.Bind(itemsSourceProperty, binding3);
		itemsControl4.ItemsPanel = new ItemsPanelTemplate
		{
			Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider?, object?>)(&XamlClosure_19.Build_1), context)
		};
		DataTemplate dataTemplate;
		DataTemplate itemTemplate = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.DataType = typeof(GlyphItem);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider?, object?>)(&XamlClosure_19.Build_2), context);
		context.PopParent();
		itemsControl4.ItemTemplate = itemTemplate;
		context.PopParent();
		((ISupportInitialize)itemsControl3).EndInit();
		Avalonia.Controls.Controls children8 = panel8.Children;
		FAProgressRing fAProgressRing2;
		FAProgressRing fAProgressRing = (fAProgressRing2 = new FAProgressRing());
		((ISupportInitialize)fAProgressRing).BeginInit();
		children8.Add(fAProgressRing);
		FAProgressRing fAProgressRing4;
		FAProgressRing fAProgressRing3 = (fAProgressRing4 = fAProgressRing2);
		context.PushParent(fAProgressRing4);
		fAProgressRing4.IsIndeterminate = true;
		StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ECommunityModInfoViewModel_002CMerostrap_002EIsLoadingGlyphs_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding4 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		fAProgressRing4.Bind(isVisibleProperty2, binding4);
		fAProgressRing4.Width = 24.0;
		fAProgressRing4.Height = 24.0;
		context.PopParent();
		((ISupportInitialize)fAProgressRing3).EndInit();
		context.PopParent();
		((ISupportInitialize)panel7).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel8).EndInit();
		context.PopParent();
		((ISupportInitialize)card8).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		Avalonia.Controls.Controls children9 = grid4.Children;
		Card card11;
		Card card10 = (card11 = new Card());
		((ISupportInitialize)card10).BeginInit();
		children9.Add(card10);
		Card card12 = (card4 = card11);
		context.PushParent(card4);
		Card card13 = card4;
		Grid.SetColumn(card13, 2);
		card13.VerticalAlignment = VerticalAlignment.Stretch;
		DockPanel dockPanel2;
		DockPanel dockPanel = (dockPanel2 = new DockPanel());
		((ISupportInitialize)dockPanel).BeginInit();
		card13.Content = dockPanel;
		DockPanel dockPanel4;
		DockPanel dockPanel3 = (dockPanel4 = dockPanel2);
		context.PushParent(dockPanel4);
		dockPanel4.LastChildFill = true;
		dockPanel4.Margin = new Thickness(16.0, 16.0, 16.0, 16.0);
		Avalonia.Controls.Controls children10 = dockPanel4.Children;
		StackPanel stackPanel11;
		StackPanel stackPanel10 = (stackPanel11 = new StackPanel());
		((ISupportInitialize)stackPanel10).BeginInit();
		children10.Add(stackPanel10);
		StackPanel stackPanel12 = (stackPanel4 = stackPanel11);
		context.PushParent(stackPanel4);
		StackPanel stackPanel13 = stackPanel4;
		DockPanel.SetDock(stackPanel13, Dock.Bottom);
		stackPanel13.Spacing = 8.0;
		stackPanel13.Margin = new Thickness(0.0, 16.0, 0.0, 0.0);
		Avalonia.Controls.Controls children11 = stackPanel13.Children;
		ProgressBar progressBar2;
		ProgressBar progressBar = (progressBar2 = new ProgressBar());
		((ISupportInitialize)progressBar).BeginInit();
		children11.Add(progressBar);
		ProgressBar progressBar4;
		ProgressBar progressBar3 = (progressBar4 = progressBar2);
		context.PushParent(progressBar4);
		StyledProperty<double> valueProperty = RangeBase.ValueProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ECommunityModInfoViewModel_002CMerostrap_002EMod_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EModels_002EAPIs_002EConfig_002ECommunityMod_002CMerostrap_002EDownloadProgress_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = RangeBase.ValueProperty;
		CompiledBinding binding5 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		progressBar4.Bind(valueProperty, binding5);
		progressBar4.Height = 4.0;
		StyledProperty<bool> isVisibleProperty3 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ECommunityModInfoViewModel_002CMerostrap_002EMod_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EModels_002EAPIs_002EConfig_002ECommunityMod_002CMerostrap_002EIsDownloading_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding6 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		progressBar4.Bind(isVisibleProperty3, binding6);
		context.PopParent();
		((ISupportInitialize)progressBar3).EndInit();
		Avalonia.Controls.Controls children12 = stackPanel13.Children;
		IconButton iconButton2;
		IconButton iconButton = (iconButton2 = new IconButton());
		((ISupportInitialize)iconButton).BeginInit();
		children12.Add(iconButton);
		IconButton iconButton4;
		IconButton iconButton3 = (iconButton4 = iconButton2);
		context.PushParent(iconButton4);
		iconButton4.Content = "Download";
		iconButton4.Icon = LucideIconNames.Download;
		iconButton4.Classes.Add("Primary");
		iconButton4.HorizontalAlignment = HorizontalAlignment.Stretch;
		iconButton4.Height = 40.0;
		StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ECommunityModInfoViewModel_002CMerostrap_002EMod_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EModels_002EAPIs_002EConfig_002ECommunityMod_002CMerostrap_002EDownloadCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding7 = compiledBindingExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		iconButton4.Bind(commandProperty, binding7);
		CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ECommunityModInfoViewModel_002CMerostrap_002EMod_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandParameterProperty;
		CompiledBinding compiledBinding = compiledBindingExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_6(iconButton4, compiledBinding);
		context.PopParent();
		((ISupportInitialize)iconButton3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel12).EndInit();
		Avalonia.Controls.Controls children13 = dockPanel4.Children;
		StackPanel stackPanel15;
		StackPanel stackPanel14 = (stackPanel15 = new StackPanel());
		((ISupportInitialize)stackPanel14).BeginInit();
		children13.Add(stackPanel14);
		StackPanel stackPanel16 = (stackPanel4 = stackPanel15);
		context.PushParent(stackPanel4);
		StackPanel stackPanel17 = stackPanel4;
		stackPanel17.Spacing = 4.0;
		Avalonia.Controls.Controls children14 = stackPanel17.Children;
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		children14.Add(textBlock3);
		TextBlock textBlock6;
		TextBlock textBlock5 = (textBlock6 = textBlock4);
		context.PushParent(textBlock6);
		TextBlock textBlock7 = textBlock6;
		StyledProperty<string?> textProperty = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ECommunityModInfoViewModel_002CMerostrap_002EMod_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EModels_002EAPIs_002EConfig_002ECommunityMod_002CMerostrap_002EName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding8 = compiledBindingExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock7.Bind(textProperty, binding8);
		textBlock7.FontSize = 24.0;
		textBlock7.FontWeight = FontWeight.Bold;
		textBlock7.TextWrapping = TextWrapping.Wrap;
		context.PopParent();
		((ISupportInitialize)textBlock5).EndInit();
		Avalonia.Controls.Controls children15 = stackPanel17.Children;
		TextBlock textBlock9;
		TextBlock textBlock8 = (textBlock9 = new TextBlock());
		((ISupportInitialize)textBlock8).BeginInit();
		children15.Add(textBlock8);
		TextBlock textBlock10 = (textBlock6 = textBlock9);
		context.PushParent(textBlock6);
		TextBlock textBlock11 = textBlock6;
		StyledProperty<string?> textProperty2 = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension10 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ECommunityModInfoViewModel_002CMerostrap_002EMod_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EModels_002EAPIs_002EConfig_002ECommunityMod_002CMerostrap_002EAuthor_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			StringFormat = "Created by {0}"
		};
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding9 = compiledBindingExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock11.Bind(textProperty2, binding9);
		textBlock11.FontSize = 12.0;
		StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("TextFillColorTertiaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding10 = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock11.Bind(foregroundProperty, binding10);
		context.PopParent();
		((ISupportInitialize)textBlock10).EndInit();
		Avalonia.Controls.Controls children16 = stackPanel17.Children;
		StackPanel stackPanel19;
		StackPanel stackPanel18 = (stackPanel19 = new StackPanel());
		((ISupportInitialize)stackPanel18).BeginInit();
		children16.Add(stackPanel18);
		StackPanel stackPanel20 = (stackPanel4 = stackPanel19);
		context.PushParent(stackPanel4);
		StackPanel stackPanel21 = stackPanel4;
		stackPanel21.Margin = new Thickness(0.0, 4.0, 0.0, 4.0);
		StyledProperty<bool> isVisibleProperty4 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension11 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ECommunityModInfoViewModel_002CMerostrap_002EMod_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EModels_002EAPIs_002EConfig_002ECommunityMod_002CMerostrap_002EIsColorMod_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding11 = compiledBindingExtension11.ProvideValue(context);
		context.ProvideTargetProperty = null;
		stackPanel21.Bind(isVisibleProperty4, binding11);
		Avalonia.Controls.Controls children17 = stackPanel21.Children;
		TextBlock textBlock13;
		TextBlock textBlock12 = (textBlock13 = new TextBlock());
		((ISupportInitialize)textBlock12).BeginInit();
		children17.Add(textBlock12);
		TextBlock textBlock14 = (textBlock6 = textBlock13);
		context.PushParent(textBlock6);
		TextBlock textBlock15 = textBlock6;
		StyledProperty<string?> textProperty3 = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension12 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ECommunityModInfoViewModel_002CMerostrap_002EColorDisplayText_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding12 = compiledBindingExtension12.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock15.Bind(textProperty3, binding12);
		textBlock15.FontSize = 12.0;
		StyledProperty<IBrush?> foregroundProperty2 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("TextFillColorTertiaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding13 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock15.Bind(foregroundProperty2, binding13);
		textBlock15.TextWrapping = TextWrapping.Wrap;
		context.PopParent();
		((ISupportInitialize)textBlock14).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel20).EndInit();
		Avalonia.Controls.Controls children18 = stackPanel17.Children;
		StackPanel stackPanel23;
		StackPanel stackPanel22 = (stackPanel23 = new StackPanel());
		((ISupportInitialize)stackPanel22).BeginInit();
		children18.Add(stackPanel22);
		StackPanel stackPanel24 = (stackPanel4 = stackPanel23);
		context.PushParent(stackPanel4);
		StackPanel stackPanel25 = stackPanel4;
		stackPanel25.Orientation = Orientation.Horizontal;
		stackPanel25.Spacing = 4.0;
		stackPanel25.Margin = new Thickness(0.0, 2.0, 0.0, 0.0);
		StyledProperty<bool> isVisibleProperty5 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension13 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ECommunityModInfoViewModel_002CMerostrap_002EMod_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EModels_002EAPIs_002EConfig_002ECommunityMod_002CMerostrap_002EGradientAngle_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.System_002ENullable_00601_002CSystem_002ERuntime_002EHasValue_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)
			.Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding14 = compiledBindingExtension13.ProvideValue(context);
		context.ProvideTargetProperty = null;
		stackPanel25.Bind(isVisibleProperty5, binding14);
		Avalonia.Controls.Controls children19 = stackPanel25.Children;
		TextBlock textBlock17;
		TextBlock textBlock16 = (textBlock17 = new TextBlock());
		((ISupportInitialize)textBlock16).BeginInit();
		children19.Add(textBlock16);
		TextBlock textBlock18 = (textBlock6 = textBlock17);
		context.PushParent(textBlock6);
		TextBlock textBlock19 = textBlock6;
		textBlock19.Text = Strings.Common_Angle;
		textBlock19.FontSize = 12.0;
		StyledProperty<IBrush?> foregroundProperty3 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("TextFillColorTertiaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding15 = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock19.Bind(foregroundProperty3, binding15);
		context.PopParent();
		((ISupportInitialize)textBlock18).EndInit();
		Avalonia.Controls.Controls children20 = stackPanel25.Children;
		TextBlock textBlock21;
		TextBlock textBlock20 = (textBlock21 = new TextBlock());
		((ISupportInitialize)textBlock20).BeginInit();
		children20.Add(textBlock20);
		TextBlock textBlock22 = (textBlock6 = textBlock21);
		context.PushParent(textBlock6);
		TextBlock textBlock23 = textBlock6;
		StyledProperty<string?> textProperty4 = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension14 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ECommunityModInfoViewModel_002CMerostrap_002EMod_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EModels_002EAPIs_002EConfig_002ECommunityMod_002CMerostrap_002EGradientAngle_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding16 = compiledBindingExtension14.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock23.Bind(textProperty4, binding16);
		textBlock23.FontSize = 12.0;
		StyledProperty<IBrush?> foregroundProperty4 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("TextFillColorTertiaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding17 = dynamicResourceExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock23.Bind(foregroundProperty4, binding17);
		context.PopParent();
		((ISupportInitialize)textBlock22).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel24).EndInit();
		Avalonia.Controls.Controls children21 = stackPanel17.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children21.Add(border);
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension5 = new DynamicResourceExtension("SystemAccentColor");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding18 = dynamicResourceExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border4.Bind(backgroundProperty, binding18);
		border4.CornerRadius = new CornerRadius(4.0, 4.0, 4.0, 4.0);
		border4.Padding = new Thickness(8.0, 2.0, 8.0, 2.0);
		border4.HorizontalAlignment = HorizontalAlignment.Left;
		border4.Margin = new Thickness(0.0, 8.0, 0.0, 0.0);
		TextBlock textBlock25;
		TextBlock textBlock24 = (textBlock25 = new TextBlock());
		((ISupportInitialize)textBlock24).BeginInit();
		border4.Child = textBlock24;
		TextBlock textBlock26 = (textBlock6 = textBlock25);
		context.PushParent(textBlock6);
		TextBlock textBlock27 = textBlock6;
		StyledProperty<string?> textProperty5 = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension15 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ECommunityModInfoViewModel_002CMerostrap_002EMod_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EModels_002EAPIs_002EConfig_002ECommunityMod_002CMerostrap_002EModTypeDisplay_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding19 = compiledBindingExtension15.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock27.Bind(textProperty5, binding19);
		textBlock27.FontSize = 10.0;
		textBlock27.FontWeight = FontWeight.DemiBold;
		context.PopParent();
		((ISupportInitialize)textBlock26).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		Avalonia.Controls.Controls children22 = stackPanel17.Children;
		Separator separator2;
		Separator separator = (separator2 = new Separator());
		((ISupportInitialize)separator).BeginInit();
		children22.Add(separator);
		separator2.Margin = new Thickness(0.0, 12.0, 0.0, 12.0);
		((ISupportInitialize)separator2).EndInit();
		Avalonia.Controls.Controls children23 = stackPanel17.Children;
		TextBlock textBlock29;
		TextBlock textBlock28 = (textBlock29 = new TextBlock());
		((ISupportInitialize)textBlock28).BeginInit();
		children23.Add(textBlock28);
		textBlock29.Text = Strings.Common_Description;
		textBlock29.FontWeight = FontWeight.DemiBold;
		textBlock29.Margin = new Thickness(0.0, 0.0, 0.0, 4.0);
		((ISupportInitialize)textBlock29).EndInit();
		Avalonia.Controls.Controls children24 = stackPanel17.Children;
		TextBlock textBlock31;
		TextBlock textBlock30 = (textBlock31 = new TextBlock());
		((ISupportInitialize)textBlock30).BeginInit();
		children24.Add(textBlock30);
		TextBlock textBlock32 = (textBlock6 = textBlock31);
		context.PushParent(textBlock6);
		TextBlock textBlock33 = textBlock6;
		StyledProperty<string?> textProperty6 = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension16 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EDialogs_002ECommunityModInfoViewModel_002CMerostrap_002EMod_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EModels_002EAPIs_002EConfig_002ECommunityMod_002CMerostrap_002EDescription_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding20 = compiledBindingExtension16.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock33.Bind(textProperty6, binding20);
		textBlock33.TextWrapping = TextWrapping.Wrap;
		StyledProperty<IBrush?> foregroundProperty5 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension6 = new DynamicResourceExtension("TextFillColorSecondaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding21 = dynamicResourceExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock33.Bind(foregroundProperty5, binding21);
		context.PopParent();
		((ISupportInitialize)textBlock32).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel16).EndInit();
		context.PopParent();
		((ISupportInitialize)dockPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)card12).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(CommunityModInfoDialog? P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
