using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Data.Converters;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using Avalonia.Threading;
using CompiledAvaloniaXaml;
using FluentAvalonia.UI.Controls;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.Models;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.ViewModels;

namespace Merostrap.UI.Elements;

internal class SearchDialog : UserControl
{
	[CompilerGenerated]
	private class XamlClosure_33
	{
		public unsafe static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<SearchDialog> context = CreateContext(P_0);
			context.IntermediateRoot = new Border();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Border border = (Border)obj;
			context.PushParent(border);
			Border border2 = border;
			StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("LayerFillColorDefaultBrush");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border2.Bind(backgroundProperty, binding);
			StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
			DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("ControlStrokeColorDefaultBrush");
			context.ProvideTargetProperty = Border.BorderBrushProperty;
			BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border2.Bind(borderBrushProperty, binding2);
			border2.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
			border2.CornerRadius = new CornerRadius(8.0, 8.0, 8.0, 8.0);
			border2.Margin = new Thickness(0.0, 0.0, 0.0, 8.0);
			border2.ClipToBounds = true;
			StackPanel stackPanel2;
			StackPanel stackPanel = (stackPanel2 = new StackPanel());
			((ISupportInitialize)stackPanel).BeginInit();
			border2.Child = stackPanel;
			StackPanel stackPanel4;
			StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
			context.PushParent(stackPanel4);
			StackPanel stackPanel5 = stackPanel4;
			Avalonia.Controls.Controls children = stackPanel5.Children;
			Border border4;
			Border border3 = (border4 = new Border());
			((ISupportInitialize)border3).BeginInit();
			children.Add(border3);
			Border border5 = (border = border4);
			context.PushParent(border);
			Border border6 = border;
			StyledProperty<IBrush?> backgroundProperty2 = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("ControlFillColorDefaultBrush");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding3 = dynamicResourceExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border6.Bind(backgroundProperty2, binding3);
			border6.Padding = new Thickness(14.0, 10.0, 14.0, 10.0);
			StackPanel stackPanel7;
			StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
			((ISupportInitialize)stackPanel6).BeginInit();
			border6.Child = stackPanel6;
			StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
			context.PushParent(stackPanel4);
			StackPanel stackPanel9 = stackPanel4;
			stackPanel9.Orientation = Orientation.Horizontal;
			stackPanel9.Spacing = 10.0;
			Avalonia.Controls.Controls children2 = stackPanel9.Children;
			Lucide lucide2;
			Lucide lucide = (lucide2 = new Lucide());
			((ISupportInitialize)lucide).BeginInit();
			children2.Add(lucide);
			Lucide lucide4;
			Lucide lucide3 = (lucide4 = lucide2);
			context.PushParent(lucide4);
			StyledProperty<LucideIconNames> iconProperty = Lucide.IconProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESearchResultGroup_002CMerostrap_002EIconSymbol_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Lucide.IconProperty;
			CompiledBinding binding4 = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			lucide4.Bind(iconProperty, binding4);
			lucide4.Width = 18.0;
			lucide4.Height = 18.0;
			lucide4.VerticalAlignment = VerticalAlignment.Center;
			context.PopParent();
			((ISupportInitialize)lucide3).EndInit();
			Avalonia.Controls.Controls children3 = stackPanel9.Children;
			TextBlock textBlock2;
			TextBlock textBlock = (textBlock2 = new TextBlock());
			((ISupportInitialize)textBlock).BeginInit();
			children3.Add(textBlock);
			TextBlock textBlock4;
			TextBlock textBlock3 = (textBlock4 = textBlock2);
			context.PushParent(textBlock4);
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESearchResultGroup_002CMerostrap_002EPageName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding5 = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock4.Bind(textProperty, binding5);
			textBlock4.FontWeight = FontWeight.DemiBold;
			textBlock4.FontSize = 14.0;
			textBlock4.VerticalAlignment = VerticalAlignment.Center;
			context.PopParent();
			((ISupportInitialize)textBlock3).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel8).EndInit();
			context.PopParent();
			((ISupportInitialize)border5).EndInit();
			Avalonia.Controls.Controls children4 = stackPanel5.Children;
			ItemsControl itemsControl2;
			ItemsControl itemsControl = (itemsControl2 = new ItemsControl());
			((ISupportInitialize)itemsControl).BeginInit();
			children4.Add(itemsControl);
			ItemsControl itemsControl4;
			ItemsControl itemsControl3 = (itemsControl4 = itemsControl2);
			context.PushParent(itemsControl4);
			StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESearchResultGroup_002CMerostrap_002EItems_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
			CompiledBinding binding6 = compiledBindingExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			itemsControl4.Bind(itemsSourceProperty, binding6);
			DataTemplate dataTemplate;
			DataTemplate itemTemplate = (dataTemplate = new DataTemplate());
			context.PushParent(dataTemplate);
			dataTemplate.DataType = typeof(SearchResultEntry);
			dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&Build_2), context);
			context.PopParent();
			itemsControl4.ItemTemplate = itemTemplate;
			context.PopParent();
			((ISupportInitialize)itemsControl3).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<SearchDialog> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<SearchDialog> context = new XamlIlContext.Context<SearchDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSearchDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/SearchDialog.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (SearchDialog)service;
				}
			}
			return context;
		}

		public static object Build_2(IServiceProvider P_0)
		{
			XamlIlContext.Context<SearchDialog> context = CreateContext(P_0);
			context.IntermediateRoot = new Button();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Button button = (Button)obj;
			context.PushParent(button);
			button.Classes.Add("SearchItem");
			button.HorizontalAlignment = HorizontalAlignment.Stretch;
			button.HorizontalContentAlignment = HorizontalAlignment.Stretch;
			button.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
			button.Background = new ImmutableSolidColorBrush(16777215u);
			button.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
			StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Ancestor(typeof(UserControl), 0).Property(StyledElement.DataContextProperty, PropertyInfoAccessorFactory.CreateAvaloniaPropertyAccessor).TypeCast<SearchBarViewModel>()
				.Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESearchBarViewModel_002CMerostrap_002ESearchResultSelectedCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor)
				.Build());
			context.ProvideTargetProperty = Button.CommandProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			button.Bind(commandProperty, binding);
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESearchResultEntry_002CMerostrap_002EItem_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Button.CommandParameterProperty;
			CompiledBinding compiledBinding = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			XamlDynamicSetters._003C_003EXamlDynamicSetter_6(button, compiledBinding);
			Grid grid2;
			Grid grid = (grid2 = new Grid());
			((ISupportInitialize)grid).BeginInit();
			button.Content = grid;
			Grid grid4;
			Grid grid3 = (grid4 = grid2);
			context.PushParent(grid4);
			Grid grid5 = grid4;
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 2;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(28.0, GridUnitType.Pixel)));
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid5.ColumnDefinitions = columnDefinitions;
			grid5.MinHeight = 52.0;
			Avalonia.Controls.Controls children = grid5.Children;
			Grid grid7;
			Grid grid6 = (grid7 = new Grid());
			((ISupportInitialize)grid6).BeginInit();
			children.Add(grid6);
			Grid grid8 = (grid4 = grid7);
			context.PushParent(grid4);
			Grid grid9 = grid4;
			Grid.SetColumn(grid9, 0);
			grid9.Width = 28.0;
			grid9.ClipToBounds = true;
			Avalonia.Controls.Controls children2 = grid9.Children;
			Border border2;
			Border border = (border2 = new Border());
			((ISupportInitialize)border).BeginInit();
			children2.Add(border);
			Border border4;
			Border border3 = (border4 = border2);
			context.PushParent(border4);
			Border border5 = border4;
			border5.Width = 1.0;
			border5.HorizontalAlignment = HorizontalAlignment.Right;
			border5.Margin = new Thickness(0.0, 0.0, 14.0, 0.0);
			StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("DividerStrokeColorDefaultBrush");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding2 = dynamicResourceExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border5.Bind(backgroundProperty, binding2);
			border5.VerticalAlignment = VerticalAlignment.Stretch;
			StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Not().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESearchResultEntry_002CMerostrap_002EIsLastInGroup_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding3 = compiledBindingExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border5.Bind(isVisibleProperty, binding3);
			context.PopParent();
			((ISupportInitialize)border3).EndInit();
			Avalonia.Controls.Controls children3 = grid9.Children;
			Border border7;
			Border border6 = (border7 = new Border());
			((ISupportInitialize)border6).BeginInit();
			children3.Add(border6);
			Border border8 = (border4 = border7);
			context.PushParent(border4);
			Border border9 = border4;
			border9.Width = 1.0;
			border9.HorizontalAlignment = HorizontalAlignment.Right;
			border9.Margin = new Thickness(0.0, 0.0, 14.0, 0.0);
			StyledProperty<IBrush?> backgroundProperty2 = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("DividerStrokeColorDefaultBrush");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding4 = dynamicResourceExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border9.Bind(backgroundProperty2, binding4);
			border9.VerticalAlignment = VerticalAlignment.Top;
			border9.Height = 26.0;
			StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESearchResultEntry_002CMerostrap_002EIsLastInGroup_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding5 = compiledBindingExtension4.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border9.Bind(isVisibleProperty2, binding5);
			context.PopParent();
			((ISupportInitialize)border8).EndInit();
			Avalonia.Controls.Controls children4 = grid9.Children;
			Border border11;
			Border border10 = (border11 = new Border());
			((ISupportInitialize)border10).BeginInit();
			children4.Add(border10);
			Border border12 = (border4 = border11);
			context.PushParent(border4);
			Border border13 = border4;
			border13.Height = 1.0;
			border13.Width = 14.0;
			border13.HorizontalAlignment = HorizontalAlignment.Right;
			border13.VerticalAlignment = VerticalAlignment.Top;
			border13.Margin = new Thickness(0.0, 26.0, 0.0, 0.0);
			StyledProperty<IBrush?> backgroundProperty3 = Border.BackgroundProperty;
			DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("DividerStrokeColorDefaultBrush");
			context.ProvideTargetProperty = Border.BackgroundProperty;
			BindingBase binding6 = dynamicResourceExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			border13.Bind(backgroundProperty3, binding6);
			context.PopParent();
			((ISupportInitialize)border12).EndInit();
			context.PopParent();
			((ISupportInitialize)grid8).EndInit();
			Avalonia.Controls.Controls children5 = grid5.Children;
			StackPanel stackPanel2;
			StackPanel stackPanel = (stackPanel2 = new StackPanel());
			((ISupportInitialize)stackPanel).BeginInit();
			children5.Add(stackPanel);
			StackPanel stackPanel4;
			StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
			context.PushParent(stackPanel4);
			Grid.SetColumn(stackPanel4, 1);
			stackPanel4.Margin = new Thickness(4.0, 10.0, 14.0, 10.0);
			stackPanel4.Spacing = 2.0;
			Avalonia.Controls.Controls children6 = stackPanel4.Children;
			TextBlock textBlock2;
			TextBlock textBlock = (textBlock2 = new TextBlock());
			((ISupportInitialize)textBlock).BeginInit();
			children6.Add(textBlock);
			TextBlock textBlock4;
			TextBlock textBlock3 = (textBlock4 = textBlock2);
			context.PushParent(textBlock4);
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESearchResultEntry_002CMerostrap_002EDisplayName_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding7 = compiledBindingExtension5.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock4.Bind(textProperty, binding7);
			textBlock4.FontWeight = FontWeight.DemiBold;
			textBlock4.FontSize = 13.0;
			textBlock4.TextTrimming = TextTrimming.CharacterEllipsis;
			context.PopParent();
			((ISupportInitialize)textBlock3).EndInit();
			Avalonia.Controls.Controls children7 = stackPanel4.Children;
			MarkdownTextBlock markdownTextBlock2;
			MarkdownTextBlock markdownTextBlock = (markdownTextBlock2 = new MarkdownTextBlock());
			((ISupportInitialize)markdownTextBlock).BeginInit();
			children7.Add(markdownTextBlock);
			MarkdownTextBlock markdownTextBlock4;
			MarkdownTextBlock markdownTextBlock3 = (markdownTextBlock4 = markdownTextBlock2);
			context.PushParent(markdownTextBlock4);
			StyledProperty<string> markdownTextProperty = MarkdownTextBlock.MarkdownTextProperty;
			CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESearchResultEntry_002CMerostrap_002EDescription_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = MarkdownTextBlock.MarkdownTextProperty;
			CompiledBinding binding8 = compiledBindingExtension6.ProvideValue(context);
			context.ProvideTargetProperty = null;
			markdownTextBlock4.Bind(markdownTextProperty, binding8);
			markdownTextBlock4.FontSize = 12.0;
			StyledProperty<IBrush?> foregroundProperty = TextBlock.ForegroundProperty;
			DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("TextFillColorSecondaryBrush");
			context.ProvideTargetProperty = TextBlock.ForegroundProperty;
			BindingBase binding9 = dynamicResourceExtension4.ProvideValue(context);
			context.ProvideTargetProperty = null;
			markdownTextBlock4.Bind(foregroundProperty, binding9);
			markdownTextBlock4.TextTrimming = TextTrimming.CharacterEllipsis;
			StyledProperty<bool> isVisibleProperty3 = Visual.IsVisibleProperty;
			CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESearchResultEntry_002CMerostrap_002EHasDescription_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Visual.IsVisibleProperty;
			CompiledBinding binding10 = compiledBindingExtension7.ProvideValue(context);
			context.ProvideTargetProperty = null;
			markdownTextBlock4.Bind(isVisibleProperty3, binding10);
			context.PopParent();
			((ISupportInitialize)markdownTextBlock3).EndInit();
			context.PopParent();
			((ISupportInitialize)stackPanel3).EndInit();
			context.PopParent();
			((ISupportInitialize)grid3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}
	}

	private SearchBarViewModel? _viewModel;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextBox SearchBox;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public event EventHandler? Dismissed;

	public SearchDialog()
	{
		InitializeComponent();
	}

	public SearchDialog(SearchBarViewModel viewModel)
		: this()
	{
		Subscribe(viewModel);
	}

	public void Subscribe(SearchBarViewModel viewModel)
	{
		_viewModel = viewModel;
		DataContext = viewModel;
		viewModel.SearchResultSelected += OnSearchResultSelected;
	}

	public void Unsubscribe()
	{
		if (_viewModel != null)
		{
			_viewModel.SearchResultSelected -= OnSearchResultSelected;
		}
		_viewModel = null;
	}

	public void Show()
	{
		IsVisible = true;
		Avalonia.Threading.Dispatcher.UIThread.Post(() =>
		{
			SearchBox.Focus();
		}, DispatcherPriority.Input);
	}

	public void Hide()
	{
		IsVisible = false;
		_viewModel?.Clear();
	}

	private void OnSearchResultSelected(object? sender, SearchBarItem item)
	{
		Dismissed?.Invoke(this, EventArgs.Empty);
	}

	protected override void OnKeyDown(KeyEventArgs e)
	{
		if (e.Key == Key.Escape)
		{
			Dismissed?.Invoke(this, EventArgs.Empty);
			e.Handled = true;
		}
		else
		{
			base.OnKeyDown(e);
		}
	}

	private void Overlay_PointerPressed(object? sender, PointerPressedEventArgs e)
	{
		Dismissed?.Invoke(this, EventArgs.Empty);
		e.Handled = true;
	}

	private void Header_PointerPressed(object? sender, PointerPressedEventArgs e)
	{
		e.Handled = true;
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		SearchBox = this.FindNameScope()?.Find<TextBox>("SearchBox");
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, SearchDialog P_1)
	{
		XamlIlContext.Context<SearchDialog> context = new XamlIlContext.Context<SearchDialog>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FSearchDialog_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/SearchDialog.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.IsVisible = false;
		P_1.Focusable = true;
		Panel panel2;
		Panel panel = (panel2 = new Panel());
		((ISupportInitialize)panel).BeginInit();
		P_1.Content = panel;
		Panel panel4;
		Panel panel3 = (panel4 = panel2);
		context.PushParent(panel4);
		Panel panel5 = panel4;
		Avalonia.Controls.Controls children = panel5.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children.Add(border);
		border2.Background = new ImmutableSolidColorBrush(2566914048u);
		border2.AddHandler(InputElement.PointerPressedEvent, context.RootObject.Overlay_PointerPressed);
		((ISupportInitialize)border2).EndInit();
		Avalonia.Controls.Controls children2 = panel5.Children;
		Border border5;
		Border border4 = (border5 = new Border());
		((ISupportInitialize)border4).BeginInit();
		children2.Add(border4);
		Border border3;
		Border border6 = (border3 = border5);
		context.PushParent(border3);
		Border border7 = border3;
		border7.CornerRadius = new CornerRadius(12.0, 12.0, 12.0, 12.0);
		border7.Width = 640.0;
		border7.MaxHeight = 600.0;
		border7.HorizontalAlignment = HorizontalAlignment.Center;
		border7.VerticalAlignment = VerticalAlignment.Center;
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("SolidBackgroundFillColorBaseBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border7.Bind(backgroundProperty, binding);
		StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("ControlElevationBorderBrush");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border7.Bind(borderBrushProperty, binding2);
		border7.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		border7.ClipToBounds = true;
		border7.AddHandler(InputElement.PointerPressedEvent, context.RootObject.Header_PointerPressed);
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		border7.Child = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 3;
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Pixel)));
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid4.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children3 = grid4.Children;
		Border border9;
		Border border8 = (border9 = new Border());
		((ISupportInitialize)border8).BeginInit();
		children3.Add(border8);
		Border border10 = (border3 = border9);
		context.PushParent(border3);
		Border border11 = border3;
		Grid.SetRow(border11, 0);
		border11.Padding = new Thickness(20.0, 20.0, 20.0, 16.0);
		Border border13;
		Border border12 = (border13 = new Border());
		((ISupportInitialize)border12).BeginInit();
		border11.Child = border12;
		Border border14 = (border3 = border13);
		context.PushParent(border3);
		Border border15 = border3;
		StyledProperty<IBrush?> backgroundProperty2 = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding3 = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border15.Bind(backgroundProperty2, binding3);
		StyledProperty<IBrush?> borderBrushProperty2 = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension4 = new DynamicResourceExtension("ControlStrokeColorDefaultBrush");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding4 = dynamicResourceExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border15.Bind(borderBrushProperty2, binding4);
		border15.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		border15.CornerRadius = new CornerRadius(8.0, 8.0, 8.0, 8.0);
		border15.Height = 48.0;
		Panel panel7;
		Panel panel6 = (panel7 = new Panel());
		((ISupportInitialize)panel6).BeginInit();
		border15.Child = panel6;
		Panel panel8 = (panel4 = panel7);
		context.PushParent(panel4);
		Panel panel9 = panel4;
		Avalonia.Controls.Controls children4 = panel9.Children;
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		children4.Add(lucide);
		Lucide lucide4;
		Lucide lucide3 = (lucide4 = lucide2);
		context.PushParent(lucide4);
		lucide4.Icon = LucideIconNames.Search;
		lucide4.Width = 18.0;
		lucide4.Height = 18.0;
		lucide4.HorizontalAlignment = HorizontalAlignment.Left;
		lucide4.VerticalAlignment = VerticalAlignment.Center;
		lucide4.Margin = new Thickness(16.0, 0.0, 0.0, 0.0);
		StyledProperty<IBrush?> foregroundProperty = TemplatedControl.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension5 = new DynamicResourceExtension("TextFillColorSecondaryBrush");
		context.ProvideTargetProperty = TemplatedControl.ForegroundProperty;
		BindingBase binding5 = dynamicResourceExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide4.Bind(foregroundProperty, binding5);
		lucide4.IsHitTestVisible = false;
		context.PopParent();
		((ISupportInitialize)lucide3).EndInit();
		Avalonia.Controls.Controls children5 = panel9.Children;
		TextBox textBox2;
		TextBox textBox = (textBox2 = new TextBox());
		((ISupportInitialize)textBox).BeginInit();
		children5.Add(textBox);
		TextBox textBox4;
		TextBox textBox3 = (textBox4 = textBox2);
		context.PushParent(textBox4);
		textBox4.Name = "SearchBox";
		object element = textBox4;
		context.AvaloniaNameScope.Register("SearchBox", element);
		StyledProperty<string?> textProperty = TextBox.TextProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESearchBarViewModel_002CMerostrap_002ESearchQuery_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = TextBox.TextProperty;
		CompiledBinding binding6 = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBox4.Bind(textProperty, binding6);
		textBox4.PlaceholderText = "Search across all settings...";
		textBox4.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
		textBox4.Background = new ImmutableSolidColorBrush(16777215u);
		textBox4.FontSize = 15.0;
		textBox4.Padding = new Thickness(44.0, 0.0, 44.0, 0.0);
		textBox4.VerticalContentAlignment = VerticalAlignment.Center;
		context.PopParent();
		((ISupportInitialize)textBox3).EndInit();
		Avalonia.Controls.Controls children6 = panel9.Children;
		IconButton iconButton2;
		IconButton iconButton = (iconButton2 = new IconButton());
		((ISupportInitialize)iconButton).BeginInit();
		children6.Add(iconButton);
		IconButton iconButton4;
		IconButton iconButton3 = (iconButton4 = iconButton2);
		context.PushParent(iconButton4);
		iconButton4.Icon = LucideIconNames.X;
		StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESearchBarViewModel_002CMerostrap_002EClearSearchCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding7 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		iconButton4.Bind(commandProperty, binding7);
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESearchBarViewModel_002CMerostrap_002ESearchQuery_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Converter = StringConverters.IsNotNullOrEmpty
		};
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding8 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		iconButton4.Bind(isVisibleProperty, binding8);
		iconButton4.Width = 32.0;
		iconButton4.Height = 32.0;
		iconButton4.Padding = new Thickness(0.0, 0.0, 0.0, 0.0);
		iconButton4.HorizontalAlignment = HorizontalAlignment.Right;
		iconButton4.VerticalAlignment = VerticalAlignment.Center;
		iconButton4.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
		iconButton4.Background = new ImmutableSolidColorBrush(16777215u);
		iconButton4.BorderThickness = new Thickness(0.0, 0.0, 0.0, 0.0);
		iconButton4.IconSize = 14.0;
		context.PopParent();
		((ISupportInitialize)iconButton3).EndInit();
		context.PopParent();
		((ISupportInitialize)panel8).EndInit();
		context.PopParent();
		((ISupportInitialize)border14).EndInit();
		context.PopParent();
		((ISupportInitialize)border10).EndInit();
		Avalonia.Controls.Controls children7 = grid4.Children;
		Border border17;
		Border border16 = (border17 = new Border());
		((ISupportInitialize)border16).BeginInit();
		children7.Add(border16);
		Border border18 = (border3 = border17);
		context.PushParent(border3);
		Border border19 = border3;
		Grid.SetRow(border19, 1);
		StyledProperty<IBrush?> backgroundProperty3 = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension6 = new DynamicResourceExtension("DividerStrokeColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding9 = dynamicResourceExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border19.Bind(backgroundProperty3, binding9);
		context.PopParent();
		((ISupportInitialize)border18).EndInit();
		Avalonia.Controls.Controls children8 = grid4.Children;
		Panel panel11;
		Panel panel10 = (panel11 = new Panel());
		((ISupportInitialize)panel10).BeginInit();
		children8.Add(panel10);
		Panel panel12 = (panel4 = panel11);
		context.PushParent(panel4);
		Panel panel13 = panel4;
		Grid.SetRow(panel13, 2);
		panel13.MinHeight = 320.0;
		Avalonia.Controls.Controls children9 = panel13.Children;
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		children9.Add(scrollViewer);
		ScrollViewer scrollViewer4;
		ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
		context.PushParent(scrollViewer4);
		scrollViewer4.Padding = new Thickness(12.0, 8.0, 12.0, 16.0);
		StyledProperty<bool> isVisibleProperty2 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESearchBarViewModel_002CMerostrap_002EShowResults_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding10 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		scrollViewer4.Bind(isVisibleProperty2, binding10);
		scrollViewer4.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
		scrollViewer4.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		scrollViewer4.Content = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		StackPanel stackPanel5 = stackPanel4;
		stackPanel5.Spacing = 12.0;
		Avalonia.Controls.Controls children10 = stackPanel5.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children10.Add(textBlock);
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = textBlock2);
		context.PushParent(textBlock4);
		TextBlock textBlock5 = textBlock4;
		StyledProperty<string?> textProperty2 = TextBlock.TextProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESearchBarViewModel_002CMerostrap_002EResultsCountText_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = TextBlock.TextProperty;
		CompiledBinding binding11 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock5.Bind(textProperty2, binding11);
		textBlock5.Margin = new Thickness(8.0, 4.0, 0.0, 0.0);
		textBlock5.FontSize = 12.0;
		StyledProperty<IBrush?> foregroundProperty2 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension7 = new DynamicResourceExtension("TextFillColorSecondaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding12 = dynamicResourceExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock5.Bind(foregroundProperty2, binding12);
		context.PopParent();
		((ISupportInitialize)textBlock3).EndInit();
		Avalonia.Controls.Controls children11 = stackPanel5.Children;
		ItemsControl itemsControl2;
		ItemsControl itemsControl = (itemsControl2 = new ItemsControl());
		((ISupportInitialize)itemsControl).BeginInit();
		children11.Add(itemsControl);
		ItemsControl itemsControl4;
		ItemsControl itemsControl3 = (itemsControl4 = itemsControl2);
		context.PushParent(itemsControl4);
		StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESearchBarViewModel_002CMerostrap_002EGroupedSearchResults_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding13 = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		itemsControl4.Bind(itemsSourceProperty, binding13);
		DataTemplate dataTemplate;
		DataTemplate itemTemplate = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.DataType = typeof(SearchResultGroup);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_33.Build_1), context);
		context.PopParent();
		itemsControl4.ItemTemplate = itemTemplate;
		context.PopParent();
		((ISupportInitialize)itemsControl3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer3).EndInit();
		Avalonia.Controls.Controls children12 = panel13.Children;
		StackPanel stackPanel7;
		StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
		((ISupportInitialize)stackPanel6).BeginInit();
		children12.Add(stackPanel6);
		StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
		context.PushParent(stackPanel4);
		StackPanel stackPanel9 = stackPanel4;
		stackPanel9.VerticalAlignment = VerticalAlignment.Center;
		stackPanel9.HorizontalAlignment = HorizontalAlignment.Center;
		stackPanel9.Spacing = 12.0;
		StyledProperty<bool> isVisibleProperty3 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension7 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESearchBarViewModel_002CMerostrap_002EShowEmptyState_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding14 = compiledBindingExtension7.ProvideValue(context);
		context.ProvideTargetProperty = null;
		stackPanel9.Bind(isVisibleProperty3, binding14);
		Avalonia.Controls.Controls children13 = stackPanel9.Children;
		Lucide lucide6;
		Lucide lucide5 = (lucide6 = new Lucide());
		((ISupportInitialize)lucide5).BeginInit();
		children13.Add(lucide5);
		lucide6.Icon = LucideIconNames.Search;
		lucide6.Width = 32.0;
		lucide6.Height = 32.0;
		lucide6.Opacity = 0.4;
		((ISupportInitialize)lucide6).EndInit();
		Avalonia.Controls.Controls children14 = stackPanel9.Children;
		TextBlock textBlock7;
		TextBlock textBlock6 = (textBlock7 = new TextBlock());
		((ISupportInitialize)textBlock6).BeginInit();
		children14.Add(textBlock6);
		TextBlock textBlock8 = (textBlock4 = textBlock7);
		context.PushParent(textBlock4);
		TextBlock textBlock9 = textBlock4;
		textBlock9.Text = "Start typing to search across all settings";
		textBlock9.FontSize = 14.0;
		StyledProperty<IBrush?> foregroundProperty3 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension8 = new DynamicResourceExtension("TextFillColorSecondaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding15 = dynamicResourceExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock9.Bind(foregroundProperty3, binding15);
		context.PopParent();
		((ISupportInitialize)textBlock8).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel8).EndInit();
		Avalonia.Controls.Controls children15 = panel13.Children;
		StackPanel stackPanel11;
		StackPanel stackPanel10 = (stackPanel11 = new StackPanel());
		((ISupportInitialize)stackPanel10).BeginInit();
		children15.Add(stackPanel10);
		StackPanel stackPanel12 = (stackPanel4 = stackPanel11);
		context.PushParent(stackPanel4);
		StackPanel stackPanel13 = stackPanel4;
		stackPanel13.VerticalAlignment = VerticalAlignment.Center;
		stackPanel13.HorizontalAlignment = HorizontalAlignment.Center;
		stackPanel13.Spacing = 12.0;
		StyledProperty<bool> isVisibleProperty4 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension8 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESearchBarViewModel_002CMerostrap_002EIsIndexing_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding16 = compiledBindingExtension8.ProvideValue(context);
		context.ProvideTargetProperty = null;
		stackPanel13.Bind(isVisibleProperty4, binding16);
		Avalonia.Controls.Controls children16 = stackPanel13.Children;
		FAProgressRing fAProgressRing2;
		FAProgressRing fAProgressRing = (fAProgressRing2 = new FAProgressRing());
		((ISupportInitialize)fAProgressRing).BeginInit();
		children16.Add(fAProgressRing);
		fAProgressRing2.IsIndeterminate = true;
		fAProgressRing2.Width = 32.0;
		fAProgressRing2.Height = 32.0;
		((ISupportInitialize)fAProgressRing2).EndInit();
		Avalonia.Controls.Controls children17 = stackPanel13.Children;
		TextBlock textBlock11;
		TextBlock textBlock10 = (textBlock11 = new TextBlock());
		((ISupportInitialize)textBlock10).BeginInit();
		children17.Add(textBlock10);
		TextBlock textBlock12 = (textBlock4 = textBlock11);
		context.PushParent(textBlock4);
		TextBlock textBlock13 = textBlock4;
		textBlock13.Text = "Indexing pages...";
		textBlock13.FontSize = 14.0;
		StyledProperty<IBrush?> foregroundProperty4 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension9 = new DynamicResourceExtension("TextFillColorSecondaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding17 = dynamicResourceExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock13.Bind(foregroundProperty4, binding17);
		context.PopParent();
		((ISupportInitialize)textBlock12).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel12).EndInit();
		Avalonia.Controls.Controls children18 = panel13.Children;
		StackPanel stackPanel15;
		StackPanel stackPanel14 = (stackPanel15 = new StackPanel());
		((ISupportInitialize)stackPanel14).BeginInit();
		children18.Add(stackPanel14);
		StackPanel stackPanel16 = (stackPanel4 = stackPanel15);
		context.PushParent(stackPanel4);
		StackPanel stackPanel17 = stackPanel4;
		stackPanel17.VerticalAlignment = VerticalAlignment.Center;
		stackPanel17.HorizontalAlignment = HorizontalAlignment.Center;
		stackPanel17.Spacing = 12.0;
		StyledProperty<bool> isVisibleProperty5 = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension9 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002ESearchBarViewModel_002CMerostrap_002EShowNoResults_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding18 = compiledBindingExtension9.ProvideValue(context);
		context.ProvideTargetProperty = null;
		stackPanel17.Bind(isVisibleProperty5, binding18);
		Avalonia.Controls.Controls children19 = stackPanel17.Children;
		Lucide lucide8;
		Lucide lucide7 = (lucide8 = new Lucide());
		((ISupportInitialize)lucide7).BeginInit();
		children19.Add(lucide7);
		lucide8.Icon = LucideIconNames.SearchX;
		lucide8.Width = 32.0;
		lucide8.Height = 32.0;
		lucide8.Opacity = 0.4;
		((ISupportInitialize)lucide8).EndInit();
		Avalonia.Controls.Controls children20 = stackPanel17.Children;
		TextBlock textBlock15;
		TextBlock textBlock14 = (textBlock15 = new TextBlock());
		((ISupportInitialize)textBlock14).BeginInit();
		children20.Add(textBlock14);
		TextBlock textBlock16 = (textBlock4 = textBlock15);
		context.PushParent(textBlock4);
		TextBlock textBlock17 = textBlock4;
		textBlock17.Text = "No results found";
		textBlock17.FontSize = 14.0;
		StyledProperty<IBrush?> foregroundProperty5 = TextBlock.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension10 = new DynamicResourceExtension("TextFillColorSecondaryBrush");
		context.ProvideTargetProperty = TextBlock.ForegroundProperty;
		BindingBase binding19 = dynamicResourceExtension10.ProvideValue(context);
		context.ProvideTargetProperty = null;
		textBlock17.Bind(foregroundProperty5, binding19);
		context.PopParent();
		((ISupportInitialize)textBlock16).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel16).EndInit();
		context.PopParent();
		((ISupportInitialize)panel12).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)border6).EndInit();
		context.PopParent();
		((ISupportInitialize)panel3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(SearchDialog P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
