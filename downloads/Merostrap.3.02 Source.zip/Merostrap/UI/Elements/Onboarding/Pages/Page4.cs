using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Animation;
using Avalonia.Animation.Easings;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using CompiledAvaloniaXaml;
using FluentAvalonia.UI.Controls;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.Resources;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.ViewModels.Onboarding;

namespace Merostrap.UI.Elements.Onboarding.Pages;

internal class Page4 : UserControl, IDisposable
{
	private static readonly LucideIconNames[] IconCycle = new LucideIconNames[2]
	{
		LucideIconNames.Earth,
		LucideIconNames.Network
	};

	private static readonly TimeSpan HoldDuration = TimeSpan.FromSeconds(2.5);

	private static readonly TimeSpan FadeDuration = TimeSpan.FromSeconds(0.5);

	private CancellationTokenSource? _cts;

	private bool _disposed;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Lucide HeaderIcon;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public Page4()
	{
		DataContext = new Page4ViewModel();
		InitializeComponent();
		Loaded += OnLoaded;
		Unloaded += OnUnloaded;
	}

	private void OnLoaded(object? sender, RoutedEventArgs e)
	{
		_cts = new CancellationTokenSource();
		RunIconCycleAsync(_cts.Token);
	}

	private void OnUnloaded(object? sender, RoutedEventArgs e)
	{
		Dispose();
	}

	private async Task RunIconCycleAsync(CancellationToken token)
	{
		int index = 0;
		try
		{
			while (!token.IsCancellationRequested)
			{
				await Task.Delay(HoldDuration, token);
				HeaderIcon.Opacity = 0.0;
				await Task.Delay(FadeDuration, token);
				index = (index + 1) % IconCycle.Length;
				HeaderIcon.Icon = IconCycle[index];
				HeaderIcon.Opacity = 1.0;
				await Task.Delay(FadeDuration, token);
			}
		}
		catch (TaskCanceledException)
		{
		}
	}

	public void Dispose()
	{
		Dispose(disposing: true);
		GC.SuppressFinalize(this);
	}

	protected virtual void Dispose(bool disposing)
	{
		if (!_disposed)
		{
			if (disposing && _cts != null)
			{
				_cts.Cancel();
				_cts.Dispose();
				_cts = null;
			}
			_disposed = true;
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		HeaderIcon = this.FindNameScope()?.Find<Lucide>("HeaderIcon");
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, Page4 P_1)
	{
		XamlIlContext.Context<Page4> context = new XamlIlContext.Context<Page4>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FOnboarding_002FPages_002FPage4_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Onboarding/Pages/Page4.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		P_1.Content = scrollViewer;
		ScrollViewer scrollViewer4;
		ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
		context.PushParent(scrollViewer4);
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		scrollViewer4.Content = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		StackPanel stackPanel5 = stackPanel4;
		stackPanel5.Margin = new Thickness(8.0, 8.0, 8.0, 8.0);
		Avalonia.Controls.Controls children = stackPanel5.Children;
		StackPanel stackPanel7;
		StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
		((ISupportInitialize)stackPanel6).BeginInit();
		children.Add(stackPanel6);
		StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
		context.PushParent(stackPanel4);
		StackPanel stackPanel9 = stackPanel4;
		stackPanel9.Orientation = Orientation.Vertical;
		stackPanel9.Spacing = 8.0;
		stackPanel9.HorizontalAlignment = HorizontalAlignment.Center;
		stackPanel9.Margin = new Thickness(0.0, 0.0, 0.0, 12.0);
		Avalonia.Controls.Controls children2 = stackPanel9.Children;
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		children2.Add(lucide);
		Lucide lucide4;
		Lucide lucide3 = (lucide4 = lucide2);
		context.PushParent(lucide4);
		lucide4.Name = "HeaderIcon";
		object element = lucide4;
		context.AvaloniaNameScope.Register("HeaderIcon", element);
		lucide4.Icon = LucideIconNames.Earth;
		lucide4.Width = 70.0;
		lucide4.Height = 70.0;
		lucide4.HorizontalAlignment = HorizontalAlignment.Center;
		StyledProperty<IBrush?> strokeBrushProperty = Lucide.StrokeBrushProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("TextFillColorPrimaryBrush");
		context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
		BindingBase binding = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide4.Bind(strokeBrushProperty, binding);
		lucide4.StrokeThickness = 1.5;
		Transitions transitions = new Transitions();
		DoubleTransition doubleTransition = new DoubleTransition();
		doubleTransition.Property = Visual.OpacityProperty;
		doubleTransition.Duration = TimeSpan.FromTicks(5000000L);
		doubleTransition.Easing = Easing.Parse("CubicEaseInOut");
		transitions.Add(doubleTransition);
		lucide4.Transitions = transitions;
		context.PopParent();
		((ISupportInitialize)lucide3).EndInit();
		Avalonia.Controls.Controls children3 = stackPanel9.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children3.Add(textBlock);
		textBlock2.Text = Strings.Menu_Bootstrapper_Experimental_BetterMatchmaking_Title;
		textBlock2.FontSize = 20.0;
		textBlock2.FontWeight = FontWeight.DemiBold;
		textBlock2.HorizontalAlignment = HorizontalAlignment.Center;
		textBlock2.Margin = new Thickness(0.0, 10.0, 0.0, 0.0);
		((ISupportInitialize)textBlock2).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel8).EndInit();
		Avalonia.Controls.Controls children4 = stackPanel5.Children;
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		children4.Add(textBlock3);
		textBlock4.Text = Strings.Onboarding_Page4;
		textBlock4.TextAlignment = TextAlignment.Center;
		textBlock4.Margin = new Thickness(0.0, 0.0, 0.0, 16.0);
		textBlock4.TextWrapping = TextWrapping.Wrap;
		textBlock4.VerticalAlignment = VerticalAlignment.Center;
		textBlock4.HorizontalAlignment = HorizontalAlignment.Center;
		((ISupportInitialize)textBlock4).EndInit();
		Avalonia.Controls.Controls children5 = stackPanel5.Children;
		CardExpander cardExpander2;
		CardExpander cardExpander = (cardExpander2 = new CardExpander());
		((ISupportInitialize)cardExpander).BeginInit();
		children5.Add(cardExpander);
		CardExpander cardExpander4;
		CardExpander cardExpander3 = (cardExpander4 = cardExpander2);
		context.PushParent(cardExpander4);
		cardExpander4.Header = Strings.Menu_Bootstrapper_Experimental_BetterMatchmaking_Title;
		cardExpander4.Description = Strings.Menu_Bootstrapper_Experimental_BetterMatchmaking_Description;
		cardExpander4.Classes.Add("NoUserExpansion");
		StyledProperty<bool> isExpandedProperty = CardExpander.IsExpandedProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EOnboarding_002EPage4ViewModel_002CMerostrap_002EEnableBetterMatchmaking_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.OneWay
		};
		context.ProvideTargetProperty = CardExpander.IsExpandedProperty;
		CompiledBinding binding2 = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		cardExpander4.Bind(isExpandedProperty, binding2);
		ToggleSwitch toggleSwitch2;
		ToggleSwitch toggleSwitch = (toggleSwitch2 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch).BeginInit();
		cardExpander4.HeaderContent = toggleSwitch;
		ToggleSwitch toggleSwitch4;
		ToggleSwitch toggleSwitch3 = (toggleSwitch4 = toggleSwitch2);
		context.PushParent(toggleSwitch4);
		StyledProperty<bool?> isCheckedProperty = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EOnboarding_002EPage4ViewModel_002CMerostrap_002EEnableBetterMatchmaking_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding3 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch4.Bind(isCheckedProperty, binding3);
		context.PopParent();
		((ISupportInitialize)toggleSwitch3).EndInit();
		StackPanel stackPanel11;
		StackPanel stackPanel10 = (stackPanel11 = new StackPanel());
		((ISupportInitialize)stackPanel10).BeginInit();
		cardExpander4.Content = stackPanel10;
		StackPanel stackPanel12 = (stackPanel4 = stackPanel11);
		context.PushParent(stackPanel4);
		Avalonia.Controls.Controls children6 = stackPanel4.Children;
		OptionControl optionControl2;
		OptionControl optionControl = (optionControl2 = new OptionControl());
		((ISupportInitialize)optionControl).BeginInit();
		children6.Add(optionControl);
		OptionControl optionControl4;
		OptionControl optionControl3 = (optionControl4 = optionControl2);
		context.PushParent(optionControl4);
		optionControl4.Header = Strings.Menu_Bootstrapper_PreferredRegion_Title;
		optionControl4.Description = Strings.Menu_Bootstrapper_PreferredRegion_Description;
		StackPanel stackPanel14;
		StackPanel stackPanel13 = (stackPanel14 = new StackPanel());
		((ISupportInitialize)stackPanel13).BeginInit();
		optionControl4.InnerContent = stackPanel13;
		StackPanel stackPanel15 = (stackPanel4 = stackPanel14);
		context.PushParent(stackPanel4);
		StackPanel stackPanel16 = stackPanel4;
		stackPanel16.Orientation = Orientation.Horizontal;
		stackPanel16.VerticalAlignment = VerticalAlignment.Center;
		stackPanel16.Spacing = 8.0;
		Avalonia.Controls.Controls children7 = stackPanel16.Children;
		FAProgressRing fAProgressRing2;
		FAProgressRing fAProgressRing = (fAProgressRing2 = new FAProgressRing());
		((ISupportInitialize)fAProgressRing).BeginInit();
		children7.Add(fAProgressRing);
		FAProgressRing fAProgressRing4;
		FAProgressRing fAProgressRing3 = (fAProgressRing4 = fAProgressRing2);
		context.PushParent(fAProgressRing4);
		StyledProperty<bool> isActiveProperty = FAProgressRing.IsActiveProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EOnboarding_002EPage4ViewModel_002CMerostrap_002EIsLoadingRegions_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = FAProgressRing.IsActiveProperty;
		CompiledBinding binding4 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		fAProgressRing4.Bind(isActiveProperty, binding4);
		fAProgressRing4.Width = 20.0;
		fAProgressRing4.Height = 20.0;
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EOnboarding_002EPage4ViewModel_002CMerostrap_002EIsLoadingRegions_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding5 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		fAProgressRing4.Bind(isVisibleProperty, binding5);
		context.PopParent();
		((ISupportInitialize)fAProgressRing3).EndInit();
		Avalonia.Controls.Controls children8 = stackPanel16.Children;
		ComboBox comboBox2;
		ComboBox comboBox = (comboBox2 = new ComboBox());
		((ISupportInitialize)comboBox).BeginInit();
		children8.Add(comboBox);
		ComboBox comboBox4;
		ComboBox comboBox3 = (comboBox4 = comboBox2);
		context.PushParent(comboBox4);
		comboBox4.MinWidth = 200.0;
		StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EOnboarding_002EPage4ViewModel_002CMerostrap_002EAvailableRegions_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding6 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		comboBox4.Bind(itemsSourceProperty, binding6);
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EOnboarding_002EPage4ViewModel_002CMerostrap_002ESelectedRegion_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = SelectingItemsControl.SelectedItemProperty;
		CompiledBinding compiledBinding = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_10(comboBox4, compiledBinding);
		context.PopParent();
		((ISupportInitialize)comboBox3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel15).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel12).EndInit();
		context.PopParent();
		((ISupportInitialize)cardExpander3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(Page4 P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
