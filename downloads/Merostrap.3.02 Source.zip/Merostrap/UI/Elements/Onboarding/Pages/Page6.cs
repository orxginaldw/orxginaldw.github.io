using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Data;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.Templates;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using CompiledAvaloniaXaml;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.ViewModels.Onboarding;

namespace Merostrap.UI.Elements.Onboarding.Pages;

internal class Page6 : UserControl
{
	[CompilerGenerated]
	private class XamlClosure_32
	{
		public static object Build_1(IServiceProvider P_0)
		{
			XamlIlContext.Context<Page6> context = CreateContext(P_0);
			context.IntermediateRoot = new Expander();
			object obj = context.IntermediateRoot;
			((ISupportInitialize)obj).BeginInit();
			Expander expander = (Expander)obj;
			context.PushParent(expander);
			StyledProperty<bool> isExpandedProperty = Expander.IsExpandedProperty;
			CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EOnboarding_002EFaqItem_002CMerostrap_002EIsExpanded_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = Expander.IsExpandedProperty;
			CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
			context.ProvideTargetProperty = null;
			expander.Bind(isExpandedProperty, binding);
			expander.HorizontalAlignment = HorizontalAlignment.Stretch;
			expander.HorizontalContentAlignment = HorizontalAlignment.Stretch;
			expander.CornerRadius = new CornerRadius(6.0, 6.0, 6.0, 6.0);
			expander.Margin = new Thickness(0.0, 0.0, 0.0, 8.0);
			Grid grid2;
			Grid grid = (grid2 = new Grid());
			((ISupportInitialize)grid).BeginInit();
			expander.Header = grid;
			Grid grid4;
			Grid grid3 = (grid4 = grid2);
			context.PushParent(grid4);
			ColumnDefinitions columnDefinitions = new ColumnDefinitions();
			columnDefinitions.Capacity = 1;
			columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
			grid4.ColumnDefinitions = columnDefinitions;
			Avalonia.Controls.Controls children = grid4.Children;
			TextBlock textBlock2;
			TextBlock textBlock = (textBlock2 = new TextBlock());
			((ISupportInitialize)textBlock).BeginInit();
			children.Add(textBlock);
			TextBlock textBlock4;
			TextBlock textBlock3 = (textBlock4 = textBlock2);
			context.PushParent(textBlock4);
			StyledProperty<string?> textProperty = TextBlock.TextProperty;
			CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EOnboarding_002EFaqItem_002CMerostrap_002EQuestion_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = TextBlock.TextProperty;
			CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
			context.ProvideTargetProperty = null;
			textBlock4.Bind(textProperty, binding2);
			textBlock4.TextWrapping = TextWrapping.Wrap;
			textBlock4.FontWeight = FontWeight.DemiBold;
			textBlock4.Foreground = new ImmutableSolidColorBrush(4292927712u);
			context.PopParent();
			((ISupportInitialize)textBlock3).EndInit();
			context.PopParent();
			((ISupportInitialize)grid3).EndInit();
			Border border2;
			Border border = (border2 = new Border());
			((ISupportInitialize)border).BeginInit();
			expander.Content = border;
			Border border4;
			Border border3 = (border4 = border2);
			context.PushParent(border4);
			border4.Padding = new Thickness(4.0, 4.0, 4.0, 4.0);
			border4.CornerRadius = new CornerRadius(4.0, 4.0, 4.0, 4.0);
			border4.Margin = new Thickness(0.0, 4.0, 0.0, 0.0);
			MarkdownTextBlock markdownTextBlock2;
			MarkdownTextBlock markdownTextBlock = (markdownTextBlock2 = new MarkdownTextBlock());
			((ISupportInitialize)markdownTextBlock).BeginInit();
			border4.Child = markdownTextBlock;
			MarkdownTextBlock markdownTextBlock4;
			MarkdownTextBlock markdownTextBlock3 = (markdownTextBlock4 = markdownTextBlock2);
			context.PushParent(markdownTextBlock4);
			StyledProperty<string> markdownTextProperty = MarkdownTextBlock.MarkdownTextProperty;
			CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EOnboarding_002EFaqItem_002CMerostrap_002EAnswer_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
			context.ProvideTargetProperty = MarkdownTextBlock.MarkdownTextProperty;
			CompiledBinding binding3 = compiledBindingExtension3.ProvideValue(context);
			context.ProvideTargetProperty = null;
			markdownTextBlock4.Bind(markdownTextProperty, binding3);
			markdownTextBlock4.TextWrapping = TextWrapping.Wrap;
			markdownTextBlock4.Foreground = new ImmutableSolidColorBrush(4289769664u);
			context.PopParent();
			((ISupportInitialize)markdownTextBlock3).EndInit();
			context.PopParent();
			((ISupportInitialize)border3).EndInit();
			context.PopParent();
			((ISupportInitialize)obj).EndInit();
			return obj;
		}

		public static XamlIlContext.Context<Page6> CreateContext(IServiceProvider P_0)
		{
			XamlIlContext.Context<Page6> context = new XamlIlContext.Context<Page6>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FOnboarding_002FPages_002FPage6_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Onboarding/Pages/Page6.axaml");
			if (P_0 != null)
			{
				object service = P_0.GetService(typeof(IRootObjectProvider));
				if (service != null)
				{
					service = ((IRootObjectProvider)service).RootObject;
					context.RootObject = (Page6)service;
				}
			}
			return context;
		}
	}

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public Page6()
	{
		DataContext = new Page6ViewModel();
		InitializeComponent();
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
	}

	[CompilerGenerated]
	private unsafe static void _0021XamlIlPopulate(IServiceProvider P_0, Page6 P_1)
	{
		XamlIlContext.Context<Page6> context = new XamlIlContext.Context<Page6>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FOnboarding_002FPages_002FPage6_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Onboarding/Pages/Page6.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		P_1.Content = scrollViewer;
		ScrollViewer scrollViewer4;
		ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
		context.PushParent(scrollViewer4);
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		scrollViewer4.Content = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		stackPanel4.Spacing = 16.0;
		stackPanel4.Margin = new Thickness(0.0, 0.0, 16.0, 0.0);
		Avalonia.Controls.Controls children = stackPanel4.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children.Add(textBlock);
		textBlock2.Text = "Please take the time to read our FAQ that will most likely answer your question. If your question is still not answered feel free to join our Discord.";
		textBlock2.TextWrapping = TextWrapping.Wrap;
		textBlock2.Foreground = new ImmutableSolidColorBrush(4291875040u);
		textBlock2.Margin = new Thickness(0.0, 0.0, 0.0, 8.0);
		((ISupportInitialize)textBlock2).EndInit();
		Avalonia.Controls.Controls children2 = stackPanel4.Children;
		ItemsControl itemsControl2;
		ItemsControl itemsControl = (itemsControl2 = new ItemsControl());
		((ISupportInitialize)itemsControl).BeginInit();
		children2.Add(itemsControl);
		ItemsControl itemsControl4;
		ItemsControl itemsControl3 = (itemsControl4 = itemsControl2);
		context.PushParent(itemsControl4);
		StyledProperty<IEnumerable?> itemsSourceProperty = ItemsControl.ItemsSourceProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EOnboarding_002EPage6ViewModel_002CMerostrap_002EFaqItems_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ItemsControl.ItemsSourceProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		itemsControl4.Bind(itemsSourceProperty, binding);
		DataTemplate dataTemplate;
		DataTemplate itemTemplate = (dataTemplate = new DataTemplate());
		context.PushParent(dataTemplate);
		dataTemplate.DataType = typeof(FaqItem);
		dataTemplate.Content = XamlIlRuntimeHelpers.DeferredTransformationFactoryV3<Control>((nint)(delegate*<IServiceProvider, object>)(&XamlClosure_32.Build_1), context);
		context.PopParent();
		itemsControl4.ItemTemplate = itemTemplate;
		context.PopParent();
		((ISupportInitialize)itemsControl3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(Page6 P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
