using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Animation;
using Avalonia.Animation.Easings;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Data.Converters;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using CompiledAvaloniaXaml;
using LucideAvalonia;
using LucideAvalonia.Enum;
using Merostrap.Resources;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.Elements.Settings;
using Merostrap.UI.ViewModels.Onboarding;

namespace Merostrap.UI.Elements.Onboarding.Pages;

internal class Page3 : UserControl, IDisposable
{
	private static readonly LucideIconNames[] IconCycle = new LucideIconNames[2]
	{
		LucideIconNames.Users,
		LucideIconNames.UserLock
	};

	private static readonly TimeSpan HoldDuration = TimeSpan.FromSeconds(2.5);

	private static readonly TimeSpan FadeDuration = TimeSpan.FromSeconds(0.5);

	private CancellationTokenSource? _cts;

	private bool _disposed;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Lucide HeaderIcon;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public Page3()
	{
		DataContext = new Page3ViewModel();
		InitializeComponent();
		Loaded += OnLoaded;
		Unloaded += OnUnloaded;
	}

	private void OnLoaded(object? sender, RoutedEventArgs e)
	{
		_cts = new CancellationTokenSource();
		RunIconCycleAsync(_cts.Token);
	}

	private void OnUnloaded(object? sender, RoutedEventArgs e)
	{
		Dispose();
	}

	private async Task RunIconCycleAsync(CancellationToken token)
	{
		int index = 0;
		try
		{
			while (!token.IsCancellationRequested)
			{
				await Task.Delay(HoldDuration, token);
				HeaderIcon.Opacity = 0.0;
				await Task.Delay(FadeDuration, token);
				index = (index + 1) % IconCycle.Length;
				HeaderIcon.Icon = IconCycle[index];
				HeaderIcon.Opacity = 1.0;
				await Task.Delay(FadeDuration, token);
			}
		}
		catch (TaskCanceledException)
		{
		}
	}

	public void Dispose()
	{
		Dispose(disposing: true);
		GC.SuppressFinalize(this);
	}

	protected virtual void Dispose(bool disposing)
	{
		if (!_disposed)
		{
			if (disposing && _cts != null)
			{
				_cts.Cancel();
				_cts.Dispose();
				_cts = null;
			}
			_disposed = true;
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		HeaderIcon = this.FindNameScope()?.Find<Lucide>("HeaderIcon");
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, Page3 P_1)
	{
		XamlIlContext.Context<Page3> context = new XamlIlContext.Context<Page3>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FOnboarding_002FPages_002FPage3_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Onboarding/Pages/Page3.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		P_1.Content = scrollViewer;
		ScrollViewer scrollViewer4;
		ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
		context.PushParent(scrollViewer4);
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		scrollViewer4.Content = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		StackPanel stackPanel5 = stackPanel4;
		stackPanel5.Margin = new Thickness(8.0, 8.0, 8.0, 8.0);
		Avalonia.Controls.Controls children = stackPanel5.Children;
		StackPanel stackPanel7;
		StackPanel stackPanel6 = (stackPanel7 = new StackPanel());
		((ISupportInitialize)stackPanel6).BeginInit();
		children.Add(stackPanel6);
		StackPanel stackPanel8 = (stackPanel4 = stackPanel7);
		context.PushParent(stackPanel4);
		StackPanel stackPanel9 = stackPanel4;
		stackPanel9.Orientation = Orientation.Vertical;
		stackPanel9.Spacing = 8.0;
		stackPanel9.HorizontalAlignment = HorizontalAlignment.Center;
		stackPanel9.Margin = new Thickness(0.0, 0.0, 0.0, 12.0);
		Avalonia.Controls.Controls children2 = stackPanel9.Children;
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		children2.Add(lucide);
		Lucide lucide4;
		Lucide lucide3 = (lucide4 = lucide2);
		context.PushParent(lucide4);
		Lucide lucide5 = lucide4;
		lucide5.Name = "HeaderIcon";
		object element = lucide5;
		context.AvaloniaNameScope.Register("HeaderIcon", element);
		lucide5.Icon = LucideIconNames.Users;
		lucide5.Width = 70.0;
		lucide5.Height = 70.0;
		lucide5.HorizontalAlignment = HorizontalAlignment.Center;
		StyledProperty<IBrush?> strokeBrushProperty = Lucide.StrokeBrushProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("TextFillColorPrimaryBrush");
		context.ProvideTargetProperty = Lucide.StrokeBrushProperty;
		BindingBase binding = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide5.Bind(strokeBrushProperty, binding);
		lucide5.StrokeThickness = 1.5;
		Transitions transitions = new Transitions();
		DoubleTransition doubleTransition = new DoubleTransition();
		doubleTransition.Property = Visual.OpacityProperty;
		doubleTransition.Duration = TimeSpan.FromTicks(5000000L);
		doubleTransition.Easing = Easing.Parse("CubicEaseInOut");
		transitions.Add(doubleTransition);
		lucide5.Transitions = transitions;
		context.PopParent();
		((ISupportInitialize)lucide3).EndInit();
		Avalonia.Controls.Controls children3 = stackPanel9.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children3.Add(textBlock);
		textBlock2.Text = Strings.Common_AccountManager;
		textBlock2.Margin = new Thickness(0.0, 10.0, 0.0, 0.0);
		textBlock2.FontSize = 20.0;
		textBlock2.FontWeight = FontWeight.DemiBold;
		textBlock2.HorizontalAlignment = HorizontalAlignment.Center;
		((ISupportInitialize)textBlock2).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel8).EndInit();
		Avalonia.Controls.Controls children4 = stackPanel5.Children;
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		children4.Add(textBlock3);
		textBlock4.Text = Strings.Onboarding_Page3_Text1;
		textBlock4.HorizontalAlignment = HorizontalAlignment.Center;
		textBlock4.VerticalAlignment = VerticalAlignment.Center;
		textBlock4.TextAlignment = TextAlignment.Center;
		textBlock4.Margin = new Thickness(0.0, 0.0, 0.0, 16.0);
		textBlock4.TextWrapping = TextWrapping.Wrap;
		((ISupportInitialize)textBlock4).EndInit();
		Avalonia.Controls.Controls children5 = stackPanel5.Children;
		OptionControl optionControl2;
		OptionControl optionControl = (optionControl2 = new OptionControl());
		((ISupportInitialize)optionControl).BeginInit();
		children5.Add(optionControl);
		OptionControl optionControl4;
		OptionControl optionControl3 = (optionControl4 = optionControl2);
		context.PushParent(optionControl4);
		optionControl4.Margin = new Thickness(0.0, 0.0, 0.0, 8.0);
		optionControl4.Header = Strings.Menu_Behaviour_AllowCookieAccess_Title;
		StyledProperty<string?> descriptionProperty = OptionControl.DescriptionProperty;
		CompiledBindingExtension compiledBindingExtension2;
		CompiledBindingExtension compiledBindingExtension = (compiledBindingExtension2 = new CompiledBindingExtension());
		context.PushParent(compiledBindingExtension2);
		compiledBindingExtension2.Source = Strings.Menu_Behaviour_AllowCookieAccess_Description;
		StaticResourceExtension staticResourceExtension = new StaticResourceExtension("StringFormatConverter");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EData_002ECompiledBinding_002CAvalonia_002EBase_002EConverter_0021Property();
		object? obj = staticResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		compiledBindingExtension2.Converter = (IValueConverter)obj;
		compiledBindingExtension2.ConverterParameter = "https://github.com/fishstrap/fishstrap/wiki/Account-Access#what-will-fishstrap-access-with-your-account";
		context.PopParent();
		context.ProvideTargetProperty = OptionControl.DescriptionProperty;
		CompiledBinding binding2 = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		optionControl4.Bind(descriptionProperty, binding2);
		StackPanel stackPanel11;
		StackPanel stackPanel10 = (stackPanel11 = new StackPanel());
		((ISupportInitialize)stackPanel10).BeginInit();
		optionControl4.InnerContent = stackPanel10;
		StackPanel stackPanel12 = (stackPanel4 = stackPanel11);
		context.PushParent(stackPanel4);
		StackPanel stackPanel13 = stackPanel4;
		stackPanel13.Orientation = Orientation.Horizontal;
		stackPanel13.Spacing = 8.0;
		Avalonia.Controls.Controls children6 = stackPanel13.Children;
		Lucide lucide7;
		Lucide lucide6 = (lucide7 = new Lucide());
		((ISupportInitialize)lucide6).BeginInit();
		children6.Add(lucide6);
		Lucide lucide8 = (lucide4 = lucide7);
		context.PushParent(lucide4);
		Lucide lucide9 = lucide4;
		lucide9.Icon = LucideIconNames.TriangleAlert;
		lucide9.VerticalAlignment = VerticalAlignment.Center;
		lucide9.StrokeBrush = new ImmutableSolidColorBrush(4294944000u);
		StyledProperty<bool> isVisibleProperty = Visual.IsVisibleProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EOnboarding_002EPage3ViewModel_002CMerostrap_002ECookieLoadingFailed_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Visual.IsVisibleProperty;
		CompiledBinding binding3 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		lucide9.Bind(isVisibleProperty, binding3);
		context.PopParent();
		((ISupportInitialize)lucide8).EndInit();
		Avalonia.Controls.Controls children7 = stackPanel13.Children;
		ToggleSwitch toggleSwitch2;
		ToggleSwitch toggleSwitch = (toggleSwitch2 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch).BeginInit();
		children7.Add(toggleSwitch);
		ToggleSwitch toggleSwitch4;
		ToggleSwitch toggleSwitch3 = (toggleSwitch4 = toggleSwitch2);
		context.PushParent(toggleSwitch4);
		StyledProperty<bool?> isCheckedProperty = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EOnboarding_002EPage3ViewModel_002CMerostrap_002ECookieAccess_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding4 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch4.Bind(isCheckedProperty, binding4);
		context.PopParent();
		((ISupportInitialize)toggleSwitch3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel12).EndInit();
		context.PopParent();
		((ISupportInitialize)optionControl3).EndInit();
		Avalonia.Controls.Controls children8 = stackPanel5.Children;
		TextBlock textBlock6;
		TextBlock textBlock5 = (textBlock6 = new TextBlock());
		((ISupportInitialize)textBlock5).BeginInit();
		children8.Add(textBlock5);
		textBlock6.Text = Strings.Onboarding_Page3_Text2;
		textBlock6.HorizontalAlignment = HorizontalAlignment.Center;
		textBlock6.VerticalAlignment = VerticalAlignment.Center;
		textBlock6.Margin = new Thickness(0.0, 0.0, 0.0, 16.0);
		textBlock6.TextAlignment = TextAlignment.Center;
		textBlock6.TextWrapping = TextWrapping.Wrap;
		((ISupportInitialize)textBlock6).EndInit();
		Avalonia.Controls.Controls children9 = stackPanel5.Children;
		AccountSelectorView accountSelectorView2;
		AccountSelectorView accountSelectorView = (accountSelectorView2 = new AccountSelectorView());
		((ISupportInitialize)accountSelectorView).BeginInit();
		children9.Add(accountSelectorView);
		AccountSelectorView accountSelectorView4;
		AccountSelectorView accountSelectorView3 = (accountSelectorView4 = accountSelectorView2);
		context.PushParent(accountSelectorView4);
		StyledProperty<IBrush?> backgroundProperty = TemplatedControl.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = TemplatedControl.BackgroundProperty;
		BindingBase binding5 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		accountSelectorView4.Bind(backgroundProperty, binding5);
		StyledProperty<IBrush?> borderBrushProperty = TemplatedControl.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("ControlElevationBorderBrush");
		context.ProvideTargetProperty = TemplatedControl.BorderBrushProperty;
		BindingBase binding6 = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		accountSelectorView4.Bind(borderBrushProperty, binding6);
		accountSelectorView4.BorderThickness = new Thickness(1.0, 1.0, 1.0, 1.0);
		accountSelectorView4.CornerRadius = new CornerRadius(6.0, 6.0, 6.0, 6.0);
		context.PopParent();
		((ISupportInitialize)accountSelectorView3).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(Page3 P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
