using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using CompiledAvaloniaXaml;
using Merostrap.Resources;
using Merostrap.UI.ViewModels;
using Merostrap.UI.ViewModels.Onboarding;

namespace Merostrap.UI.Elements.Onboarding.Pages;

internal class Page5 : UserControl
{
	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public Page5()
	{
		InitializeComponent();
		DataContext = new Page5ViewModel();
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, Page5 P_1)
	{
		XamlIlContext.Context<Page5> context = new XamlIlContext.Context<Page5>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FOnboarding_002FPages_002FPage5_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Onboarding/Pages/Page5.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		ScrollViewer scrollViewer2;
		ScrollViewer scrollViewer = (scrollViewer2 = new ScrollViewer());
		((ISupportInitialize)scrollViewer).BeginInit();
		P_1.Content = scrollViewer;
		ScrollViewer scrollViewer4;
		ScrollViewer scrollViewer3 = (scrollViewer4 = scrollViewer2);
		context.PushParent(scrollViewer4);
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		scrollViewer4.Content = stackPanel;
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		stackPanel4.Spacing = 24.0;
		Avalonia.Controls.Controls children = stackPanel4.Children;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		children.Add(grid);
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 2;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid5.ColumnDefinitions = columnDefinitions;
		Avalonia.Controls.Controls children2 = grid5.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children2.Add(textBlock);
		textBlock2.Text = Strings.Common_Shortcuts_Desktop;
		textBlock2.VerticalAlignment = VerticalAlignment.Center;
		textBlock2.FontWeight = FontWeight.DemiBold;
		((ISupportInitialize)textBlock2).EndInit();
		Avalonia.Controls.Controls children3 = grid5.Children;
		ToggleSwitch toggleSwitch2;
		ToggleSwitch toggleSwitch = (toggleSwitch2 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch).BeginInit();
		children3.Add(toggleSwitch);
		ToggleSwitch toggleSwitch4;
		ToggleSwitch toggleSwitch3 = (toggleSwitch4 = toggleSwitch2);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch5 = toggleSwitch4;
		Grid.SetColumn(toggleSwitch5, 1);
		StyledProperty<bool?> isCheckedProperty = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EOnboarding_002EPage5ViewModel_002CMerostrap_002EDesktopIconTask_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EModels_002ESettingTasks_002EBase_002EBoolBaseTask_002CMerostrap_002ENewState_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch5.Bind(isCheckedProperty, binding);
		AutomationProperties.SetName(toggleSwitch5, Strings.Common_Shortcuts_Desktop);
		context.PopParent();
		((ISupportInitialize)toggleSwitch3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		Avalonia.Controls.Controls children4 = stackPanel4.Children;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		children4.Add(grid6);
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		ColumnDefinitions columnDefinitions2 = new ColumnDefinitions();
		columnDefinitions2.Capacity = 2;
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid9.ColumnDefinitions = columnDefinitions2;
		grid9.IsVisible = GlobalViewModel.IsWindows;
		Avalonia.Controls.Controls children5 = grid9.Children;
		TextBlock textBlock4;
		TextBlock textBlock3 = (textBlock4 = new TextBlock());
		((ISupportInitialize)textBlock3).BeginInit();
		children5.Add(textBlock3);
		textBlock4.Text = Strings.Common_Shortcuts_StartMenu;
		textBlock4.VerticalAlignment = VerticalAlignment.Center;
		textBlock4.FontWeight = FontWeight.DemiBold;
		((ISupportInitialize)textBlock4).EndInit();
		Avalonia.Controls.Controls children6 = grid9.Children;
		ToggleSwitch toggleSwitch7;
		ToggleSwitch toggleSwitch6 = (toggleSwitch7 = new ToggleSwitch());
		((ISupportInitialize)toggleSwitch6).BeginInit();
		children6.Add(toggleSwitch6);
		ToggleSwitch toggleSwitch8 = (toggleSwitch4 = toggleSwitch7);
		context.PushParent(toggleSwitch4);
		ToggleSwitch toggleSwitch9 = toggleSwitch4;
		Grid.SetColumn(toggleSwitch9, 1);
		StyledProperty<bool?> isCheckedProperty2 = ToggleButton.IsCheckedProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EOnboarding_002EPage5ViewModel_002CMerostrap_002EStartMenuIconTask_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Property(XamlIlHelpers.Merostrap_002EModels_002ESettingTasks_002EBase_002EBoolBaseTask_002CMerostrap_002ENewState_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build())
		{
			Mode = BindingMode.TwoWay
		};
		context.ProvideTargetProperty = ToggleButton.IsCheckedProperty;
		CompiledBinding binding2 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		toggleSwitch9.Bind(isCheckedProperty2, binding2);
		AutomationProperties.SetName(toggleSwitch9, Strings.Common_Shortcuts_StartMenu);
		context.PopParent();
		((ISupportInitialize)toggleSwitch8).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)scrollViewer3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(Page5 P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
