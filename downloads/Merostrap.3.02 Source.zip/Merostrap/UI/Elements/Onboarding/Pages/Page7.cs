using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using CompiledAvaloniaXaml;
using Merostrap.Resources;
using Merostrap.UI.ViewModels.Onboarding;

namespace Merostrap.UI.Elements.Onboarding.Pages;

internal class Page7 : UserControl
{
	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public Page7()
	{
		InitializeComponent();
		DataContext = new Page7ViewModel();
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, Page7 P_1)
	{
		XamlIlContext.Context<Page7> context = new XamlIlContext.Context<Page7>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FOnboarding_002FPages_002FPage7_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Onboarding/Pages/Page7.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		P_1.Content = textBlock;
		textBlock2.Classes.Add("WelcomeHeading");
		textBlock2.Text = WelcomeStrings.ReadyTitle;
		textBlock2.VerticalAlignment = VerticalAlignment.Center;
		textBlock2.HorizontalAlignment = HorizontalAlignment.Center;
		((ISupportInitialize)textBlock2).EndInit();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(Page7 P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
