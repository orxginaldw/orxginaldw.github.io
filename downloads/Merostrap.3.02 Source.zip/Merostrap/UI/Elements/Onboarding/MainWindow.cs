using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Input;
using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.Converters;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using CompiledAvaloniaXaml;
using Merostrap.Enums;
using Merostrap.Models.SettingTasks.Base;
using Merostrap.Resources;
using Merostrap.UI.Elements.Base;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.Elements.Onboarding.Pages;
using Merostrap.UI.Utility;
using Merostrap.UI.ViewModels.Onboarding;

namespace Merostrap.UI.Elements.Onboarding;

internal class MainWindow : AvaloniaWindow
{
	internal readonly MainWindowViewModel _viewModel = new MainWindowViewModel();

	private Type _currentPage = typeof(Page1);

	private bool _isInitialLoad = true;

	private readonly List<Type> _pages;

	public Func<Task<bool>>? NextPageCallback;

	public NextAction CloseAction;

	private readonly Dictionary<Type, object> _pageCache;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TransitioningContentControl RootFrame;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	protected override bool ApplyTopPadding => false;

	public static MainWindow? Instance { get; private set; }

	public bool Completed { get; private set; }

	public bool Finished => _currentPage == _pages.Last();

	public MainWindow()
	{
		int num = 4;
		List<Type> list = new List<Type>(num);
		CollectionsMarshal.SetCount(list, num);
		Span<Type> span = CollectionsMarshal.AsSpan(list);
		span[0] = typeof(Page1);
		span[1] = typeof(Page2);
		span[2] = typeof(Page5);
		span[3] = typeof(Page7);
		_pages = list;
		_pageCache = new Dictionary<Type, object>();
		base._002Ector();
		Instance = this;
		DataContext = _viewModel;
		InitializeComponent();
		_viewModel.PageRequest += (object? _, string type) =>
		{
			if (type == "next")
			{
				NextPage();
			}
			else if (type == "back")
			{
				BackPage();
			}
		};
		Navigate(typeof(Page1));
		App.Logger.Debug("Initializing onboarding window");
	}

	private async void NextPage()
	{
		bool flag = NextPageCallback != null;
		if (flag)
		{
			flag = !(await NextPageCallback());
		}
		if (flag)
		{
			return;
		}
		if (_currentPage == _pages.Last())
		{
			BaseTask[] array = App.PendingSettingTasks.Values.ToArray();
			foreach (BaseTask baseTask in array)
			{
				if (baseTask.Changed)
				{
					baseTask.Execute();
				}
			}
			App.PendingSettingTasks.Clear();
			App.Settings.Save();
			Completed = true;
			CloseAction = NextAction.SignIn;
			Close();
		}
		else
		{
			App.Settings.Save();
			int index = _pages.IndexOf(_currentPage) + 1;
			Type pageType = _pages[index];
			Navigate(pageType);
		}
	}

	private void BackPage()
	{
		if (!(_currentPage == _pages.First()))
		{
			int index = _pages.IndexOf(_currentPage) - 1;
			Type pageType = _pages[index];
			Navigate(pageType);
		}
	}

	public void SetNextButtonText(string text)
	{
		_viewModel.SetNextButtonText(text);
	}

	public bool Navigate(Type pageType)
	{
		int num = _pages.IndexOf(_currentPage);
		bool flag = _pages.IndexOf(pageType) > num;
		if (!_isInitialLoad && !App.Settings.Prop.DisableAnimations && !App.Settings.Prop.Performance.UseReducedAnimations)
		{
			RootFrame.PageTransition = new FluentSlideTransition
			{
				Direction = (flag ? SlideDirection.Right : SlideDirection.Left),
				HorizontalOffset = 28.0,
				Duration = TimeSpan.FromMilliseconds(180L)
			};
		}
		else
		{
			RootFrame.PageTransition = null;
			_isInitialLoad = false;
		}
		_currentPage = pageType;
		NextPageCallback = null;
		if (!_pageCache.TryGetValue(pageType, out object value))
		{
			value = Activator.CreateInstance(pageType);
			_pageCache[pageType] = value;
		}
		RootFrame.Content = value;
		int num2 = _pages.IndexOf(pageType);
		if (num2 >= 0)
		{
			_viewModel.SetStep(num2, _pages.Count);
		}
		if (_currentPage == _pages.Last())
		{
			SetNextButtonText(WelcomeStrings.SignIn);
		}
		else
		{
			SetNextButtonText(WelcomeStrings.Continue);
		}
		_viewModel.BackButtonEnabled = _currentPage != _pages.First();
		return true;
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		RootFrame = this.FindNameScope()?.Find<TransitioningContentControl>("RootFrame");
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, MainWindow P_1)
	{
		XamlIlContext.Context<MainWindow> context = new XamlIlContext.Context<MainWindow>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FOnboarding_002FMainWindow_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Onboarding/MainWindow.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Title = Strings.Onboarding_Title;
		P_1.Width = 600.0;
		P_1.Height = 480.0;
		P_1.MinWidth = 520.0;
		P_1.MinHeight = 440.0;
		P_1.WindowDecorations = WindowDecorations.None;
		P_1.ExtendClientAreaToDecorationsHint = false;
		P_1.CanResize = true;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 4;
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid5.RowDefinitions = rowDefinitions;
		StyledProperty<IBrush?> backgroundProperty = Panel.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("WelcomeSurface");
		context.ProvideTargetProperty = Panel.BackgroundProperty;
		BindingBase binding = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		grid5.Bind(backgroundProperty, binding);
		Avalonia.Controls.Controls children = grid5.Children;
		WelcomeTitleBar welcomeTitleBar2;
		WelcomeTitleBar welcomeTitleBar = (welcomeTitleBar2 = new WelcomeTitleBar());
		((ISupportInitialize)welcomeTitleBar).BeginInit();
		children.Add(welcomeTitleBar);
		((ISupportInitialize)welcomeTitleBar2).EndInit();
		Avalonia.Controls.Controls children2 = grid5.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children2.Add(border);
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Grid.SetRow(border4, 1);
		border4.Padding = new Thickness(32.0, 8.0, 32.0, 20.0);
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		border4.Child = grid6;
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 2;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		grid9.ColumnDefinitions = columnDefinitions;
		Avalonia.Controls.Controls children3 = grid9.Children;
		Image image2;
		Image image = (image2 = new Image());
		((ISupportInitialize)image).BeginInit();
		children3.Add(image);
		Image image4;
		Image image3 = (image4 = image2);
		context.PushParent(image4);
		image4.Source = (IImage)new BitmapTypeConverter().ConvertFrom(context, CultureInfo.InvariantCulture, "avares://Merostrap/Resources/Brand/Merostrap.png");
		image4.Width = 42.0;
		image4.Height = 42.0;
		RenderOptions.SetBitmapInterpolationMode(image4, BitmapInterpolationMode.HighQuality);
		context.PopParent();
		((ISupportInitialize)image3).EndInit();
		Avalonia.Controls.Controls children4 = grid9.Children;
		TextBlock textBlock2;
		TextBlock textBlock = (textBlock2 = new TextBlock());
		((ISupportInitialize)textBlock).BeginInit();
		children4.Add(textBlock);
		Grid.SetColumn(textBlock2, 1);
		textBlock2.Text = "Merostrap";
		textBlock2.FontSize = 20.0;
		textBlock2.FontWeight = FontWeight.DemiBold;
		textBlock2.Margin = new Thickness(12.0, 0.0, 0.0, 0.0);
		textBlock2.VerticalAlignment = VerticalAlignment.Center;
		((ISupportInitialize)textBlock2).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		Avalonia.Controls.Controls children5 = grid5.Children;
		TransitioningContentControl transitioningContentControl2;
		TransitioningContentControl transitioningContentControl = (transitioningContentControl2 = new TransitioningContentControl());
		((ISupportInitialize)transitioningContentControl).BeginInit();
		children5.Add(transitioningContentControl);
		Grid.SetRow(transitioningContentControl2, 2);
		transitioningContentControl2.Name = "RootFrame";
		object element = transitioningContentControl2;
		context.AvaloniaNameScope.Register("RootFrame", element);
		transitioningContentControl2.Margin = new Thickness(32.0, 16.0, 32.0, 24.0);
		((ISupportInitialize)transitioningContentControl2).EndInit();
		Avalonia.Controls.Controls children6 = grid5.Children;
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		children6.Add(stackPanel);
		StackPanel stackPanel4;
		StackPanel stackPanel3 = (stackPanel4 = stackPanel2);
		context.PushParent(stackPanel4);
		Grid.SetRow(stackPanel4, 3);
		Avalonia.Controls.Controls children7 = stackPanel4.Children;
		ProgressBar progressBar2;
		ProgressBar progressBar = (progressBar2 = new ProgressBar());
		((ISupportInitialize)progressBar).BeginInit();
		children7.Add(progressBar);
		ProgressBar progressBar4;
		ProgressBar progressBar3 = (progressBar4 = progressBar2);
		context.PushParent(progressBar4);
		StyledProperty<double> valueProperty = RangeBase.ValueProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EOnboarding_002EMainWindowViewModel_002CMerostrap_002EProgress_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = RangeBase.ValueProperty;
		CompiledBinding binding2 = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		progressBar4.Bind(valueProperty, binding2);
		progressBar4.Maximum = 100.0;
		progressBar4.Height = 3.0;
		StyledProperty<IBrush?> foregroundProperty = TemplatedControl.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("WelcomeAccent");
		context.ProvideTargetProperty = TemplatedControl.ForegroundProperty;
		BindingBase binding3 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		progressBar4.Bind(foregroundProperty, binding3);
		StyledProperty<IBrush?> backgroundProperty2 = TemplatedControl.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("WelcomeBorder");
		context.ProvideTargetProperty = TemplatedControl.BackgroundProperty;
		BindingBase binding4 = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		progressBar4.Bind(backgroundProperty2, binding4);
		AttachedProperty<string?> nameProperty = AutomationProperties.NameProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EOnboarding_002EMainWindowViewModel_002CMerostrap_002EStepText_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = AutomationProperties.NameProperty;
		CompiledBinding binding5 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		progressBar4.Bind(nameProperty, binding5);
		context.PopParent();
		((ISupportInitialize)progressBar3).EndInit();
		Avalonia.Controls.Controls children8 = stackPanel4.Children;
		Grid grid11;
		Grid grid10 = (grid11 = new Grid());
		((ISupportInitialize)grid10).BeginInit();
		children8.Add(grid10);
		Grid grid12 = (grid4 = grid11);
		context.PushParent(grid4);
		Grid grid13 = grid4;
		ColumnDefinitions columnDefinitions2 = new ColumnDefinitions();
		columnDefinitions2.Capacity = 3;
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions2.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid13.ColumnDefinitions = columnDefinitions2;
		grid13.Margin = new Thickness(32.0, 20.0, 32.0, 20.0);
		Avalonia.Controls.Controls children9 = grid13.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children9.Add(button);
		Button button4;
		Button button3 = (button4 = button2);
		context.PushParent(button4);
		Button button5 = button4;
		button5.Classes.Add("WelcomeSecondary");
		StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EOnboarding_002EMainWindowViewModel_002CMerostrap_002EBackPageCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding6 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button5.Bind(commandProperty, binding6);
		StyledProperty<bool> isEnabledProperty = InputElement.IsEnabledProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EOnboarding_002EMainWindowViewModel_002CMerostrap_002EBackButtonEnabled_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = InputElement.IsEnabledProperty;
		CompiledBinding binding7 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button5.Bind(isEnabledProperty, binding7);
		button5.Content = Strings.Common_Back;
		context.PopParent();
		((ISupportInitialize)button3).EndInit();
		Avalonia.Controls.Controls children10 = grid13.Children;
		Button button7;
		Button button6 = (button7 = new Button());
		((ISupportInitialize)button6).BeginInit();
		children10.Add(button6);
		Button button8 = (button4 = button7);
		context.PushParent(button4);
		Button button9 = button4;
		Grid.SetColumn(button9, 2);
		button9.Classes.Add("WelcomePrimary");
		button9.MinWidth = 130.0;
		StyledProperty<ICommand?> commandProperty2 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension5 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EOnboarding_002EMainWindowViewModel_002CMerostrap_002ENextPageCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding8 = compiledBindingExtension5.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button9.Bind(commandProperty2, binding8);
		CompiledBindingExtension compiledBindingExtension6 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EOnboarding_002EMainWindowViewModel_002CMerostrap_002ENextButtonText_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = ContentControl.ContentProperty;
		CompiledBinding compiledBinding = compiledBindingExtension6.ProvideValue(context);
		context.ProvideTargetProperty = null;
		XamlDynamicSetters._003C_003EXamlDynamicSetter_4(button9, compiledBinding);
		button9.IsDefault = true;
		context.PopParent();
		((ISupportInitialize)button8).EndInit();
		context.PopParent();
		((ISupportInitialize)grid12).EndInit();
		context.PopParent();
		((ISupportInitialize)stackPanel3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(MainWindow P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
