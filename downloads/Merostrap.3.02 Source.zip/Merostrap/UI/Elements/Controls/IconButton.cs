using System;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using LucideAvalonia.Enum;

namespace Merostrap.UI.Elements.Controls;

internal class IconButton : Button
{
	public static readonly StyledProperty<double> IconSizeProperty = AvaloniaProperty.Register<IconButton, double>("IconSize", 12.0);

	public static readonly StyledProperty<LucideIconNames?> IconProperty = AvaloniaProperty.Register<IconButton, LucideIconNames?>("Icon");

	public static readonly StyledProperty<bool> IsFilledProperty = AvaloniaProperty.Register<IconButton, bool>("IsFilled", defaultValue: false);

	public new static readonly StyledProperty<FlyoutBase?> FlyoutProperty = AvaloniaProperty.Register<IconButton, FlyoutBase>("Flyout");

	private Button? _secondaryButton;

	public double IconSize
	{
		get
		{
			return GetValue(IconSizeProperty);
		}
		set
		{
			SetValue(IconSizeProperty, value);
		}
	}

	public LucideIconNames? Icon
	{
		get
		{
			return GetValue(IconProperty);
		}
		set
		{
			SetValue(IconProperty, value);
		}
	}

	public bool IsFilled
	{
		get
		{
			return GetValue(IsFilledProperty);
		}
		set
		{
			SetValue(IsFilledProperty, value);
		}
	}

	public new FlyoutBase? Flyout
	{
		get
		{
			return GetValue(FlyoutProperty);
		}
		set
		{
			SetValue(FlyoutProperty, value);
		}
	}

	protected override void OnApplyTemplate(TemplateAppliedEventArgs e)
	{
		base.OnApplyTemplate(e);
		Button? secondaryButton = _secondaryButton;
		if (secondaryButton != null)
		{
			secondaryButton.Click -= OnSecondaryButtonClick;
		}
		_secondaryButton = e.NameScope.Find<Button>("PART_SecondaryButton");
		Button? secondaryButton2 = _secondaryButton;
		if (secondaryButton2 != null)
		{
			secondaryButton2.Click += OnSecondaryButtonClick;
		}
	}

	private void OnSecondaryButtonClick(object? sender, EventArgs e)
	{
		if (Flyout != null)
		{
			Flyout.ShowAt(this);
			PseudoClasses.Set(":flyout-open", value: true);
			Flyout.Closed += OnFlyoutClosed;
		}
	}

	private void OnFlyoutClosed(object? sender, EventArgs e)
	{
		PseudoClasses.Set(":flyout-open", value: false);
		FlyoutBase? flyout = Flyout;
		if (flyout != null)
		{
			flyout.Closed -= OnFlyoutClosed;
		}
	}

	protected override void OnPropertyChanged(AvaloniaPropertyChangedEventArgs change)
	{
		base.OnPropertyChanged(change);
		if (change.Property == FlyoutProperty && change.OldValue is FlyoutBase flyoutBase)
		{
			flyoutBase.Closed -= OnFlyoutClosed;
		}
	}
}
