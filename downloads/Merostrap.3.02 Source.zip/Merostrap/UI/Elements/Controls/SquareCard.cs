using Avalonia;
using Avalonia.Controls.Primitives;
using Avalonia.Metadata;

namespace Merostrap.UI.Elements.Controls;

internal class SquareCard : TemplatedControl
{
	public static readonly StyledProperty<string> HeaderProperty = AvaloniaProperty.Register<SquareCard, string>("Header");

	public static readonly StyledProperty<string> DescriptionProperty = AvaloniaProperty.Register<SquareCard, string>("Description");

	public static readonly StyledProperty<object> InnerContentProperty = AvaloniaProperty.Register<SquareCard, object>("InnerContent");

	public string Header
	{
		get
		{
			return GetValue(HeaderProperty);
		}
		set
		{
			SetValue(HeaderProperty, value);
		}
	}

	public string Description
	{
		get
		{
			return GetValue(DescriptionProperty);
		}
		set
		{
			SetValue(DescriptionProperty, value);
		}
	}

	[Content]
	public object InnerContent
	{
		get
		{
			return GetValue(InnerContentProperty);
		}
		set
		{
			SetValue(InnerContentProperty, value);
		}
	}
}
