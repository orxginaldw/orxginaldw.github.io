using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using Avalonia;
using Avalonia.Animation;
using Avalonia.Animation.Easings;
using Avalonia.Controls;
using Avalonia.Data;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using CompiledAvaloniaXaml;

namespace Merostrap.UI.Elements.Controls;

internal class StepIndicator : UserControl
{
	public static readonly StyledProperty<int> PageCountProperty;

	public static readonly StyledProperty<int> CurrentIndexProperty;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Border Track;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Border FillBar;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public int PageCount
	{
		get
		{
			return GetValue(PageCountProperty);
		}
		set
		{
			SetValue(PageCountProperty, value);
		}
	}

	public int CurrentIndex
	{
		get
		{
			return GetValue(CurrentIndexProperty);
		}
		set
		{
			SetValue(CurrentIndexProperty, value);
		}
	}

	static StepIndicator()
	{
		PageCountProperty = AvaloniaProperty.Register<StepIndicator, int>("PageCount", 3);
		CurrentIndexProperty = AvaloniaProperty.Register<StepIndicator, int>("CurrentIndex", 0);
		PageCountProperty.Changed.AddClassHandler((StepIndicator c, AvaloniaPropertyChangedEventArgs _) =>
		{
			c.UpdateProgress();
		});
		CurrentIndexProperty.Changed.AddClassHandler((StepIndicator c, AvaloniaPropertyChangedEventArgs _) =>
		{
			c.UpdateProgress();
		});
	}

	public StepIndicator()
	{
		InitializeComponent();
		FillBar.Transitions = new Transitions
		{
			new DoubleTransition
			{
				Property = Layoutable.WidthProperty,
				Duration = TimeSpan.FromMilliseconds(250L),
				Easing = new CubicEaseOut()
			}
		};
		Track.SizeChanged += (object? _, SizeChangedEventArgs _) =>
		{
			UpdateProgress();
		};
		UpdateProgress();
	}

	private void UpdateProgress()
	{
		if (Track != null && FillBar != null)
		{
			double width = Track.Bounds.Width;
			if (!(width <= 0.0))
			{
				double num = ((PageCount > 1) ? Math.Clamp((double)CurrentIndex / (double)(PageCount - 1), 0.0, 1.0) : 1.0);
				FillBar.Width = width * num;
			}
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		Track = nameScope?.Find<Border>("Track");
		FillBar = nameScope?.Find<Border>("FillBar");
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, StepIndicator P_1)
	{
		XamlIlContext.Context<StepIndicator> context = new XamlIlContext.Context<StepIndicator>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FControls_002FStepIndicator_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Controls/StepIndicator.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		P_1.Content = border;
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Border border5 = border4;
		border5.Name = "Track";
		object element = border5;
		context.AvaloniaNameScope.Register("Track", element);
		border5.Height = 4.0;
		border5.CornerRadius = new CornerRadius(2.0, 2.0, 2.0, 2.0);
		border5.ClipToBounds = true;
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("ControlFillColorSecondaryBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border5.Bind(backgroundProperty, binding);
		Border border7;
		Border border6 = (border7 = new Border());
		((ISupportInitialize)border6).BeginInit();
		border5.Child = border6;
		Border border8 = (border4 = border7);
		context.PushParent(border4);
		Border border9 = border4;
		border9.Name = "FillBar";
		element = border9;
		context.AvaloniaNameScope.Register("FillBar", element);
		border9.HorizontalAlignment = HorizontalAlignment.Left;
		border9.Width = 0.0;
		border9.CornerRadius = new CornerRadius(2.0, 2.0, 2.0, 2.0);
		StyledProperty<IBrush?> backgroundProperty2 = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("AccentFillColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding2 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border9.Bind(backgroundProperty2, binding2);
		context.PopParent();
		((ISupportInitialize)border8).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(StepIndicator P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
