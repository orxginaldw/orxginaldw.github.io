using System;
using System.Threading;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Media.Imaging;
using Merostrap.UI.Converters;

namespace Merostrap.UI.Elements.Controls;

internal sealed class RemoteImage : Image
{
	public static readonly StyledProperty<string?> UrlProperty = AvaloniaProperty.Register<RemoteImage, string>("Url");

	private CancellationTokenSource? _request;

	private Bitmap? _bitmap;

	public string? Url
	{
		get
		{
			return GetValue(UrlProperty);
		}
		set
		{
			SetValue(UrlProperty, value);
		}
	}

	private void ClearImage()
	{
		Source = null;
		_bitmap?.Dispose();
		_bitmap = null;
	}

	protected override void OnPropertyChanged(AvaloniaPropertyChangedEventArgs change)
	{
		base.OnPropertyChanged(change);
		if (change.Property == UrlProperty)
		{
			CancelRequest();
			ClearImage();
			if (IsLoaded)
			{
				StartRequest();
			}
		}
	}

	protected override void OnLoaded(RoutedEventArgs e)
	{
		base.OnLoaded(e);
		StartRequest();
	}

	protected override void OnUnloaded(RoutedEventArgs e)
	{
		CancelRequest();
		ClearImage();
		base.OnUnloaded(e);
	}

	private void CancelRequest()
	{
		_request?.Cancel();
		_request = null;
	}

	private async void StartRequest()
	{
		CancelRequest();
		if (string.IsNullOrWhiteSpace(Url))
		{
			return;
		}
		using CancellationTokenSource request = new CancellationTokenSource(TimeSpan.FromSeconds(10L));
		_request = request;
		try
		{
			Bitmap bitmap = await UrlToBitmapConverter.GetBitmapFromCacheOrDownloadAsync(Url, request.Token);
			if (_request == request && !request.IsCancellationRequested && IsLoaded)
			{
				ClearImage();
				_bitmap = bitmap;
				Source = bitmap;
			}
			else
			{
				bitmap?.Dispose();
			}
		}
		finally
		{
			if (_request == request)
			{
				_request = null;
			}
		}
	}
}
