using System;
using Avalonia.Controls;
using Avalonia.Input;

namespace Merostrap.UI.Elements.Controls;

internal sealed class PasswordTextBox : TextBox
{
	protected override Type StyleKeyOverride => typeof(TextBox);

	protected override void OnLostFocus(FocusChangedEventArgs e)
	{
		bool revealPassword = RevealPassword;
		base.OnLostFocus(e);
		SetCurrentValue(TextBox.RevealPasswordProperty, revealPassword);
	}
}
