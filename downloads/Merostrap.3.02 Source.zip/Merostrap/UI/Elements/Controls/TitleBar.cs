using System;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Media;
using LucideAvalonia.Enum;

namespace Merostrap.UI.Elements.Controls;

internal class TitleBar : TemplatedControl
{
	public static readonly StyledProperty<string?> TitleProperty = AvaloniaProperty.Register<TitleBar, string>("Title");

	public static readonly StyledProperty<bool> ShowMinimizeProperty = AvaloniaProperty.Register<TitleBar, bool>("ShowMinimize", defaultValue: true);

	public static readonly StyledProperty<bool> ShowMaximizeProperty = AvaloniaProperty.Register<TitleBar, bool>("ShowMaximize", defaultValue: true);

	public static readonly StyledProperty<bool> ShowCloseProperty = AvaloniaProperty.Register<TitleBar, bool>("ShowClose", defaultValue: true);

	public static readonly StyledProperty<IImage?> IconProperty = AvaloniaProperty.Register<TitleBar, IImage>("Icon");

	public static readonly StyledProperty<WindowState> WindowStateProperty = AvaloniaProperty.Register<TitleBar, WindowState>("WindowState", WindowState.Normal);

	private Window? _window;

	private IconButton? _minBtn;

	private IconButton? _maxBtn;

	private IconButton? _closeBtn;

	public string? Title
	{
		get
		{
			return GetValue(TitleProperty);
		}
		set
		{
			SetValue(TitleProperty, value);
		}
	}

	public bool ShowMinimize
	{
		get
		{
			return GetValue(ShowMinimizeProperty);
		}
		set
		{
			SetValue(ShowMinimizeProperty, value);
		}
	}

	public bool ShowMaximize
	{
		get
		{
			return GetValue(ShowMaximizeProperty);
		}
		set
		{
			SetValue(ShowMaximizeProperty, value);
		}
	}

	public bool ShowClose
	{
		get
		{
			return GetValue(ShowCloseProperty);
		}
		set
		{
			SetValue(ShowCloseProperty, value);
		}
	}

	public IImage? Icon
	{
		get
		{
			return GetValue(IconProperty);
		}
		set
		{
			SetValue(IconProperty, value);
		}
	}

	public WindowState WindowState
	{
		get
		{
			return GetValue(WindowStateProperty);
		}
		set
		{
			SetValue(WindowStateProperty, value);
		}
	}

	protected override void OnApplyTemplate(TemplateAppliedEventArgs e)
	{
		base.OnApplyTemplate(e);
		_window = TopLevel.GetTopLevel(this) as Window;
		if (_window == null)
		{
			return;
		}
		string[] array = new string[2] { "PART_LeftPanel", "PART_RightPanel" };
		foreach (string name in array)
		{
			StackPanel? stackPanel = e.NameScope.Find<StackPanel>(name);
			if (stackPanel != null)
			{
				stackPanel.IsVisible = !OperatingSystem.IsMacOS();
			}
		}
		_window.PropertyChanged += OnWindowPropertyChanged;
		_minBtn = e.NameScope.Find<IconButton>("PART_MinimizeButton");
		_maxBtn = e.NameScope.Find<IconButton>("PART_MaximizeButton");
		_closeBtn = e.NameScope.Find<IconButton>("PART_CloseButton");
		IconButton? minBtn = _minBtn;
		if (minBtn != null)
		{
			minBtn.Click += OnMinimizeClick;
		}
		IconButton? maxBtn = _maxBtn;
		if (maxBtn != null)
		{
			maxBtn.Click += OnMaximizeClick;
		}
		IconButton? closeBtn = _closeBtn;
		if (closeBtn != null)
		{
			closeBtn.Click += OnCloseClick;
		}
		UpdateMaximizeIcon();
	}

	private void OnWindowPropertyChanged(object? sender, AvaloniaPropertyChangedEventArgs e)
	{
		if (e.Property.Name == "WindowState")
		{
			SetValue(WindowStateProperty, _window.WindowState);
			UpdateMaximizeIcon();
		}
	}

	private void UpdateMaximizeIcon()
	{
		if (_maxBtn != null && _window != null)
		{
			_maxBtn.Icon = ((_window.WindowState == WindowState.Maximized) ? LucideIconNames.Minimize : LucideIconNames.Maximize);
		}
	}

	private void OnMinimizeClick(object? sender, EventArgs e)
	{
		Window? window = _window;
		if (window != null)
		{
			window.WindowState = WindowState.Minimized;
		}
	}

	private void OnMaximizeClick(object? sender, EventArgs e)
	{
		if (_window != null)
		{
			_window.WindowState = ((_window.WindowState != WindowState.Maximized) ? WindowState.Maximized : WindowState.Normal);
		}
	}

	private void OnCloseClick(object? sender, EventArgs e)
	{
		_window?.Close();
	}

	protected override void OnDetachedFromVisualTree(VisualTreeAttachmentEventArgs e)
	{
		base.OnDetachedFromVisualTree(e);
		Window? window = _window;
		if (window != null)
		{
			window.PropertyChanged -= OnWindowPropertyChanged;
		}
		IconButton? minBtn = _minBtn;
		if (minBtn != null)
		{
			minBtn.Click -= OnMinimizeClick;
		}
		IconButton? maxBtn = _maxBtn;
		if (maxBtn != null)
		{
			maxBtn.Click -= OnMaximizeClick;
		}
		IconButton? closeBtn = _closeBtn;
		if (closeBtn != null)
		{
			closeBtn.Click -= OnCloseClick;
		}
	}
}
