using Avalonia;
using Avalonia.Controls;
using Merostrap.Utility;

namespace Merostrap.UI.Elements.Controls;

internal class Hyperlink : Button
{
	public static readonly StyledProperty<string?> UrlProperty = AvaloniaProperty.Register<Hyperlink, string>("Url");

	public string? Url
	{
		get
		{
			return GetValue(UrlProperty);
		}
		set
		{
			SetValue(UrlProperty, value);
		}
	}

	public string? Text
	{
		get
		{
			return Content as string;
		}
		set
		{
			Content = value;
		}
	}

	public Hyperlink()
	{
	}

	public Hyperlink(string text, string url)
	{
		Content = text;
		Url = url;
	}

	protected override void OnClick()
	{
		base.OnClick();
		if (!string.IsNullOrEmpty(Url))
		{
			Threading.ShellExecute(Url);
		}
	}
}
