using Avalonia.Controls;

namespace Merostrap.UI.Elements.Controls;

internal class Card : ContentControl
{
}
