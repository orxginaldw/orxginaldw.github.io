using Avalonia;
using Avalonia.Controls.Primitives;
using Avalonia.Metadata;

namespace Merostrap.UI.Elements.Controls;

internal class OptionControl : TemplatedControl
{
	public static readonly StyledProperty<string?> HeaderProperty = AvaloniaProperty.Register<OptionControl, string>("Header");

	public static readonly StyledProperty<string?> DescriptionProperty = AvaloniaProperty.Register<OptionControl, string>("Description");

	public static readonly StyledProperty<string?> HelpLinkProperty = AvaloniaProperty.Register<OptionControl, string>("HelpLink");

	public static readonly StyledProperty<object?> InnerContentProperty = AvaloniaProperty.Register<OptionControl, object>("InnerContent");

	public string? Header
	{
		get
		{
			return GetValue(HeaderProperty);
		}
		set
		{
			SetValue(HeaderProperty, value);
		}
	}

	public string? Description
	{
		get
		{
			return GetValue(DescriptionProperty);
		}
		set
		{
			SetValue(DescriptionProperty, value);
		}
	}

	public string? HelpLink
	{
		get
		{
			return GetValue(HelpLinkProperty);
		}
		set
		{
			SetValue(HelpLinkProperty, value);
		}
	}

	[Content]
	public object? InnerContent
	{
		get
		{
			return GetValue(InnerContentProperty);
		}
		set
		{
			SetValue(InnerContentProperty, value);
		}
	}
}
