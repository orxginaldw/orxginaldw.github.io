using System.Collections.Generic;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Documents;
using Avalonia.Media;
using Markdig;
using Markdig.Extensions.EmphasisExtras;
using Markdig.Syntax;
using Markdig.Syntax.Inlines;

namespace Merostrap.UI.Elements.Controls;

internal class MarkdownTextBlock : TextBlock
{
	private static readonly MarkdownPipeline _markdownPipeline;

	public static readonly StyledProperty<string> MarkdownTextProperty;

	public string MarkdownText
	{
		get
		{
			return GetValue(MarkdownTextProperty);
		}
		set
		{
			SetValue(MarkdownTextProperty, value);
		}
	}

	static MarkdownTextBlock()
	{
		_markdownPipeline = new MarkdownPipelineBuilder().UseEmphasisExtras(EmphasisExtraOptions.Marked).UseSoftlineBreakAsHardlineBreak().Build();
		MarkdownTextProperty = AvaloniaProperty.Register<MarkdownTextBlock, string>("MarkdownText", string.Empty);
		MarkdownTextProperty.Changed.AddClassHandler((MarkdownTextBlock x, AvaloniaPropertyChangedEventArgs e) =>
		{
			x.UpdateMarkdown(e.NewValue as string);
		});
		TextBlock.FontSizeProperty.Changed.AddClassHandler((MarkdownTextBlock x, AvaloniaPropertyChangedEventArgs e) =>
		{
			x.UpdateMarkdown(x.MarkdownText);
		});
		TextBlock.FontFamilyProperty.Changed.AddClassHandler((MarkdownTextBlock x, AvaloniaPropertyChangedEventArgs e) =>
		{
			x.UpdateMarkdown(x.MarkdownText);
		});
		TextBlock.FontWeightProperty.Changed.AddClassHandler((MarkdownTextBlock x, AvaloniaPropertyChangedEventArgs e) =>
		{
			x.UpdateMarkdown(x.MarkdownText);
		});
	}

	private void UpdateMarkdown(string? markdown)
	{
		Inlines?.Clear();
		if (!string.IsNullOrEmpty(markdown))
		{
			List<Avalonia.Controls.Documents.Inline> items = ConvertMarkdownToInlines(Markdown.Parse(markdown, _markdownPipeline), FontSize, FontFamily, FontWeight);
			Inlines.AddRange(items);
		}
	}

	private static List<Avalonia.Controls.Documents.Inline> ConvertMarkdownToInlines(MarkdownDocument document, double fontSize, FontFamily fontFamily, FontWeight fontWeight)
	{
		List<Avalonia.Controls.Documents.Inline> list = new List<Avalonia.Controls.Documents.Inline>();
		foreach (Block item in document)
		{
			if (!(item is ParagraphBlock { Inline: not null } paragraphBlock))
			{
				continue;
			}
			foreach (Markdig.Syntax.Inlines.Inline item2 in paragraphBlock.Inline)
			{
				IEnumerable<Avalonia.Controls.Documents.Inline> avaloniaInlinesFromMarkdownInline = GetAvaloniaInlinesFromMarkdownInline(item2, fontSize, fontFamily, fontWeight);
				list.AddRange(avaloniaInlinesFromMarkdownInline);
			}
			if (item != document.LastChild)
			{
				list.Add(new LineBreak());
			}
		}
		return list;
	}

	private static IEnumerable<Avalonia.Controls.Documents.Inline> GetAvaloniaInlinesFromMarkdownInline(Markdig.Syntax.Inlines.Inline? inline, double fontSize, FontFamily fontFamily, FontWeight fontWeight)
	{
		if (inline == null)
		{
			yield break;
		}
		if (inline is LiteralInline literalInline)
		{
			yield return new Run(literalInline.Content.ToString());
		}
		else if (inline is EmphasisInline emphasisInline)
		{
			Span span;
			if (emphasisInline.DelimiterCount == 1 && (emphasisInline.DelimiterChar == '*' || emphasisInline.DelimiterChar == '_'))
			{
				span = new Italic();
			}
			else
			{
				span = ((emphasisInline.DelimiterChar == '=') ? new Span() : new Bold());
			}
			if (span is Bold bold)
			{
				bold.FontWeight = FontWeight.DemiBold;
			}
			if (emphasisInline.DelimiterChar == '=')
			{
				span.Background = (IBrush)Application.Current.FindResource("AccentFillColorSelectedTextBackgroundBrush");
				span.Foreground = (IBrush)Application.Current.FindResource("SystemAccentColor");
			}
			foreach (Markdig.Syntax.Inlines.Inline item in emphasisInline)
			{
				foreach (Avalonia.Controls.Documents.Inline item2 in GetAvaloniaInlinesFromMarkdownInline(item, fontSize, fontFamily, fontWeight))
				{
					span.Inlines.Add(item2);
				}
			}
			yield return span;
		}
		else if (inline is LinkInline linkInline)
		{
			string text = linkInline.Url ?? string.Empty;
			string content = linkInline.FirstChild?.ToString() ?? text;
			Hyperlink child = new Hyperlink
			{
				Content = content,
				Url = text,
				FontSize = fontSize,
				FontFamily = fontFamily,
				FontWeight = fontWeight
			};
			yield return new InlineUIContainer(child)
			{
				BaselineAlignment = BaselineAlignment.Center
			};
		}
		else if (inline is LineBreakInline)
		{
			yield return new LineBreak();
		}
		else
		{
			if (!(inline is ContainerInline containerInline))
			{
				yield break;
			}
			foreach (Markdig.Syntax.Inlines.Inline item3 in containerInline)
			{
				foreach (Avalonia.Controls.Documents.Inline item4 in GetAvaloniaInlinesFromMarkdownInline(item3, fontSize, fontFamily, fontWeight))
				{
					yield return item4;
				}
			}
		}
	}
}
