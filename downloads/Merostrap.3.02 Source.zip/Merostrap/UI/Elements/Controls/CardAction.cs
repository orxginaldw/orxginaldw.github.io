using Avalonia;
using Avalonia.Controls;
using LucideAvalonia.Enum;

namespace Merostrap.UI.Elements.Controls;

internal class CardAction : Button
{
	public static readonly StyledProperty<string> HeaderProperty = AvaloniaProperty.Register<CardAction, string>("Header");

	public static readonly StyledProperty<string> DescriptionProperty = AvaloniaProperty.Register<CardAction, string>("Description");

	public static readonly StyledProperty<LucideIconNames> IconProperty = AvaloniaProperty.Register<CardAction, LucideIconNames>("Icon", LucideIconNames.AArrowDown);

	public static readonly StyledProperty<double> IconSizeProperty = AvaloniaProperty.Register<CardAction, double>("IconSize", 24.0);

	public string Header
	{
		get
		{
			return GetValue(HeaderProperty);
		}
		set
		{
			SetValue(HeaderProperty, value);
		}
	}

	public string Description
	{
		get
		{
			return GetValue(DescriptionProperty);
		}
		set
		{
			SetValue(DescriptionProperty, value);
		}
	}

	public LucideIconNames Icon
	{
		get
		{
			return GetValue(IconProperty);
		}
		set
		{
			SetValue(IconProperty, value);
		}
	}

	public double IconSize
	{
		get
		{
			return GetValue(IconSizeProperty);
		}
		set
		{
			SetValue(IconSizeProperty, value);
		}
	}
}
