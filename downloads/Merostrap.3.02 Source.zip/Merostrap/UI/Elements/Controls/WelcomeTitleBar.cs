using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;
using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Controls.Presenters;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media.Immutable;
using Avalonia.Styling;
using CompiledAvaloniaXaml;
using LucideAvalonia;
using LucideAvalonia.Enum;

namespace Merostrap.UI.Elements.Controls;

internal class WelcomeTitleBar : UserControl
{
	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Button MaximizeButton;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Lucide MaximizeGlyph;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	private Window? Host => TopLevel.GetTopLevel(this) as Window;

	public WelcomeTitleBar()
	{
		InitializeComponent();
	}

	private void Minimize(object? sender, RoutedEventArgs e)
	{
		Window host = Host;
		if (host != null)
		{
			host.WindowState = WindowState.Minimized;
		}
	}

	private void Maximize(object? sender, RoutedEventArgs e)
	{
		ToggleMaximize();
	}

	private void ToggleMaximize()
	{
		Window host = Host;
		if (host != null)
		{
			host.WindowState = ((host.WindowState != WindowState.Maximized) ? WindowState.Maximized : WindowState.Normal);
			MaximizeGlyph.Icon = ((host.WindowState == WindowState.Maximized) ? LucideIconNames.Copy : LucideIconNames.Square);
		}
	}

	private void Close(object? sender, RoutedEventArgs e)
	{
		Host?.Close();
	}

	private void DragWindow(object? sender, PointerPressedEventArgs e)
	{
		if (e.GetCurrentPoint(this).Properties.IsLeftButtonPressed)
		{
			if (e.ClickCount == 2)
			{
				ToggleMaximize();
			}
			else
			{
				Host?.BeginMoveDrag(e);
			}
		}
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		MaximizeButton = nameScope?.Find<Button>("MaximizeButton");
		MaximizeGlyph = nameScope?.Find<Lucide>("MaximizeGlyph");
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, WelcomeTitleBar P_1)
	{
		XamlIlContext.Context<WelcomeTitleBar> context = new XamlIlContext.Context<WelcomeTitleBar>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FControls_002FWelcomeTitleBar_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Controls/WelcomeTitleBar.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		P_1.Height = 36.0;
		Styles styles = P_1.Styles;
		Style style;
		Style item = (style = new Style());
		context.PushParent(style);
		Style style2 = style;
		style2.Selector = ((Selector?)null).OfType(typeof(Lucide));
		Setter setter2;
		Setter setter = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter3 = setter2;
		setter3.Property = Lucide.StrokeBrushProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("WelcomeMuted");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter3.Value = value;
		context.PopParent();
		style2.Add(setter);
		Setter setter4 = new Setter();
		setter4.Property = Lucide.StrokeThicknessProperty;
		setter4.Value = 1.25;
		style2.Add(setter4);
		context.PopParent();
		styles.Add(item);
		Styles styles2 = P_1.Styles;
		Style style3 = new Style();
		style3.Selector = ((Selector?)null).OfType(typeof(Button)).Class("CloseCaption").Class(":pointerover")
			.Descendant()
			.OfType(typeof(Lucide));
		Setter setter5 = new Setter();
		setter5.Property = Lucide.StrokeBrushProperty;
		setter5.Value = new ImmutableSolidColorBrush(uint.MaxValue);
		style3.Add(setter5);
		styles2.Add(style3);
		Styles styles3 = P_1.Styles;
		Style item2 = (style = new Style());
		context.PushParent(style);
		Style style4 = style;
		style4.Selector = ((Selector?)null).OfType(typeof(Button)).Class("Caption");
		Setter setter6 = new Setter();
		setter6.Property = Layoutable.WidthProperty;
		setter6.Value = 36.0;
		style4.Add(setter6);
		Setter setter7 = new Setter();
		setter7.Property = Layoutable.HeightProperty;
		setter7.Value = 32.0;
		style4.Add(setter7);
		Setter setter8 = new Setter();
		setter8.Property = TemplatedControl.PaddingProperty;
		setter8.Value = new Thickness(0.0, 0.0, 0.0, 0.0);
		style4.Add(setter8);
		Setter setter9 = new Setter();
		setter9.Property = TemplatedControl.CornerRadiusProperty;
		setter9.Value = new CornerRadius(6.0, 6.0, 6.0, 6.0);
		style4.Add(setter9);
		Setter setter10 = new Setter();
		setter10.Property = TemplatedControl.BackgroundProperty;
		setter10.Value = new ImmutableSolidColorBrush(16777215u);
		style4.Add(setter10);
		Setter setter11 = new Setter();
		setter11.Property = TemplatedControl.BorderThicknessProperty;
		setter11.Value = new Thickness(0.0, 0.0, 0.0, 0.0);
		style4.Add(setter11);
		Setter setter12 = new Setter();
		setter12.Property = ContentControl.HorizontalContentAlignmentProperty;
		setter12.Value = HorizontalAlignment.Center;
		style4.Add(setter12);
		Setter setter13 = new Setter();
		setter13.Property = ContentControl.VerticalContentAlignmentProperty;
		setter13.Value = VerticalAlignment.Center;
		style4.Add(setter13);
		Setter setter14 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter15 = setter2;
		setter15.Property = TemplatedControl.ForegroundProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("WelcomeMuted");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value2 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter15.Value = value2;
		context.PopParent();
		style4.Add(setter14);
		context.PopParent();
		styles3.Add(item2);
		Styles styles4 = P_1.Styles;
		Style item3 = (style = new Style());
		context.PushParent(style);
		Style style5 = style;
		style5.Selector = ((Selector?)null).OfType(typeof(Button)).Class("Caption").Class(":pointerover")
			.Template()
			.OfType(typeof(ContentPresenter));
		Setter setter16 = (setter2 = new Setter());
		context.PushParent(setter2);
		Setter setter17 = setter2;
		setter17.Property = ContentPresenter.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension3 = new DynamicResourceExtension("WelcomeCard");
		context.ProvideTargetProperty = XamlIlHelpers.Avalonia_002EStyling_002ESetter_002CAvalonia_002EBase_002EValue_0021Property();
		BindingBase value3 = dynamicResourceExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		setter17.Value = value3;
		context.PopParent();
		style5.Add(setter16);
		context.PopParent();
		styles4.Add(item3);
		Styles styles5 = P_1.Styles;
		Style style6 = new Style();
		style6.Selector = ((Selector?)null).OfType(typeof(Button)).Class("CloseCaption").Class(":pointerover")
			.Template()
			.OfType(typeof(ContentPresenter));
		Setter setter18 = new Setter();
		setter18.Property = ContentPresenter.BackgroundProperty;
		setter18.Value = new ImmutableSolidColorBrush(4290718017u);
		style6.Add(setter18);
		Setter setter19 = new Setter();
		setter19.Property = ContentPresenter.ForegroundProperty;
		setter19.Value = new ImmutableSolidColorBrush(uint.MaxValue);
		style6.Add(setter19);
		styles5.Add(style6);
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 2;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid2.ColumnDefinitions = columnDefinitions;
		Avalonia.Controls.Controls children = grid2.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children.Add(border);
		border2.Background = new ImmutableSolidColorBrush(16777215u);
		border2.AddHandler(InputElement.PointerPressedEvent, context.RootObject.DragWindow);
		((ISupportInitialize)border2).EndInit();
		Avalonia.Controls.Controls children2 = grid2.Children;
		StackPanel stackPanel2;
		StackPanel stackPanel = (stackPanel2 = new StackPanel());
		((ISupportInitialize)stackPanel).BeginInit();
		children2.Add(stackPanel);
		Grid.SetColumn(stackPanel2, 1);
		stackPanel2.Orientation = Orientation.Horizontal;
		stackPanel2.Margin = new Thickness(0.0, 2.0, 6.0, 2.0);
		Avalonia.Controls.Controls children3 = stackPanel2.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children3.Add(button);
		button2.Classes.Add("Caption");
		button2.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.Minimize), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		ToolTip.SetTip(button2, "Minimize");
		AutomationProperties.SetName(button2, "Minimize");
		Lucide lucide2;
		Lucide lucide = (lucide2 = new Lucide());
		((ISupportInitialize)lucide).BeginInit();
		button2.Content = lucide;
		lucide2.Icon = LucideIconNames.Minus;
		lucide2.Width = 12.0;
		lucide2.Height = 12.0;
		((ISupportInitialize)lucide2).EndInit();
		((ISupportInitialize)button2).EndInit();
		Avalonia.Controls.Controls children4 = stackPanel2.Children;
		Button button5;
		Button button4 = (button5 = new Button());
		((ISupportInitialize)button4).BeginInit();
		children4.Add(button4);
		button5.Name = "MaximizeButton";
		object element = button5;
		context.AvaloniaNameScope.Register("MaximizeButton", element);
		button5.Classes.Add("Caption");
		button5.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.Maximize), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		ToolTip.SetTip(button5, "Maximize or restore");
		AutomationProperties.SetName(button5, "Maximize or restore");
		Lucide lucide4;
		Lucide lucide3 = (lucide4 = new Lucide());
		((ISupportInitialize)lucide3).BeginInit();
		button5.Content = lucide3;
		lucide4.Name = "MaximizeGlyph";
		element = lucide4;
		context.AvaloniaNameScope.Register("MaximizeGlyph", element);
		lucide4.Icon = LucideIconNames.Square;
		lucide4.Width = 12.0;
		lucide4.Height = 12.0;
		((ISupportInitialize)lucide4).EndInit();
		((ISupportInitialize)button5).EndInit();
		Avalonia.Controls.Controls children5 = stackPanel2.Children;
		Button button7;
		Button button6 = (button7 = new Button());
		((ISupportInitialize)button6).BeginInit();
		children5.Add(button6);
		button7.Classes.Add("Caption");
		button7.Classes.Add("CloseCaption");
		button7.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.Close), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		ToolTip.SetTip(button7, "Close");
		AutomationProperties.SetName(button7, "Close");
		Lucide lucide6;
		Lucide lucide5 = (lucide6 = new Lucide());
		((ISupportInitialize)lucide5).BeginInit();
		button7.Content = lucide5;
		lucide6.Icon = LucideIconNames.X;
		lucide6.Width = 12.0;
		lucide6.Height = 12.0;
		((ISupportInitialize)lucide6).EndInit();
		((ISupportInitialize)button7).EndInit();
		((ISupportInitialize)stackPanel2).EndInit();
		((ISupportInitialize)grid2).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(WelcomeTitleBar P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
