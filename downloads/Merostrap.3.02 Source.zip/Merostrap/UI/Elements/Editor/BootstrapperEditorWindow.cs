using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Xml;
using Avalonia;
using Avalonia.Animation;
using Avalonia.Animation.Easings;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Controls.Shapes;
using Avalonia.Data;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Markup.Xaml.MarkupExtensions.CompiledBindings;
using Avalonia.Markup.Xaml.XamlIl.Runtime;
using Avalonia.Media;
using Avalonia.Platform;
using Avalonia.Threading;
using AvaloniaEdit;
using AvaloniaEdit.CodeCompletion;
using AvaloniaEdit.Document;
using AvaloniaEdit.Highlighting;
using AvaloniaEdit.Highlighting.Xshd;
using CompiledAvaloniaXaml;
using FluentAvalonia.UI.Controls;
using LucideAvalonia.Enum;
using Merostrap.Enums.Messagebox;
using Merostrap.Extensions;
using Merostrap.Resources;
using Merostrap.UI.Elements.Base;
using Merostrap.UI.Elements.Controls;
using Merostrap.UI.ViewModels.Editor;

namespace Merostrap.UI.Elements.Editor;

internal class BootstrapperEditorWindow : AvaloniaWindow, IDisposable
{
	private static class CustomBootstrapperSchema
	{
		private class Schema
		{
			public Dictionary<string, Element> Elements { get; set; } = new Dictionary<string, Element>();

			public Dictionary<string, Type> Types { get; set; } = new Dictionary<string, Type>();
		}

		private class Element
		{
			public string? SuperClass { get; set; }

			public bool IsCreatable { get; set; }

			public Dictionary<string, string> Attributes { get; set; } = new Dictionary<string, string>();
		}

		internal class Type
		{
			public bool CanHaveElement { get; set; }

			public List<string>? Values { get; set; }
		}

		private static Schema? _schema;

		public static SortedDictionary<string, SortedDictionary<string, string>> ElementInfo { get; set; } = new SortedDictionary<string, SortedDictionary<string, string>>();

		public static Dictionary<string, List<string>> PropertyElements { get; set; } = new Dictionary<string, List<string>>();

		public static SortedDictionary<string, Type> Types { get; set; } = new SortedDictionary<string, Type>();

		public static void ParseSchema()
		{
			if (_schema != null)
			{
				return;
			}
			try
			{
				_schema = JsonSerializer.Deserialize<Schema>(Resource.GetString("CustomBootstrapperSchema.json").GetAwaiter().GetResult()) ?? throw new InvalidOperationException("Schema deserialization failed.");
				foreach (KeyValuePair<string, Type> type in _schema.Types)
				{
					Types.Add(type.Key, type.Value);
				}
				PopulateElementInfo();
			}
			catch (Exception ex)
			{
				App.Logger.Error("Critical error loading schema: " + ex.Message);
			}
		}

		private static (SortedDictionary<string, string>, List<string>) GetElementAttributes(string name, Element element)
		{
			if (ElementInfo.TryGetValue(name, out SortedDictionary<string, string> value))
			{
				return (value, PropertyElements[name]);
			}
			List<string> list = new List<string>();
			SortedDictionary<string, string> sortedDictionary = new SortedDictionary<string, string>();
			foreach (KeyValuePair<string, string> attribute in element.Attributes)
			{
				sortedDictionary.Add(attribute.Key, attribute.Value);
				if (Types.TryGetValue(attribute.Value, out Type value2))
				{
					if (value2.CanHaveElement)
					{
						list.Add(attribute.Key);
					}
					continue;
				}
				throw new InvalidOperationException("Schema for type " + attribute.Value + " is missing. Blame Matt!");
			}
			if (element.SuperClass != null)
			{
				var (sortedDictionary2, list2) = GetElementAttributes(element.SuperClass, _schema.Elements[element.SuperClass]);
				foreach (KeyValuePair<string, string> item in sortedDictionary2)
				{
					sortedDictionary.TryAdd(item.Key, item.Value);
				}
				foreach (string item2 in list2)
				{
					if (!list.Contains(item2))
					{
						list.Add(item2);
					}
				}
			}
			list.Sort();
			ElementInfo[name] = sortedDictionary;
			PropertyElements[name] = list;
			return (sortedDictionary, list);
		}

		private static void PopulateElementInfo()
		{
			List<string> list = new List<string>();
			foreach (KeyValuePair<string, Element> element in _schema.Elements)
			{
				GetElementAttributes(element.Key, element.Value);
				if (!element.Value.IsCreatable)
				{
					list.Add(element.Key);
				}
			}
			foreach (string item in list)
			{
				ElementInfo.Remove(item);
			}
		}
	}

	private sealed class NotificationEntry
	{
		public required Border Element { get; init; }

		public required TranslateTransform Transform { get; init; }

		public CancellationTokenSource? TimeoutCts { get; set; }
	}

	private readonly BootstrapperEditorWindowViewModel _viewModel;

	private CompletionWindow? _completionWindow;

	private bool _isInitialLoad = true;

	private bool _disposed;

	private readonly List<NotificationEntry> _notifications = new List<NotificationEntry>();

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal Panel NotificationPanel;

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	internal TextEditor UIXML;

	[CompilerGenerated]
	private static Action<object> _0021XamlIlPopulateOverride;

	public BootstrapperEditorWindow()
	{
		InitializeComponent();
	}

	public BootstrapperEditorWindow(string name)
		: this()
	{
		CustomBootstrapperSchema.ParseSchema();
		string text = System.IO.Path.Combine(Paths.CustomThemes, name);
		string text2 = File.ReadAllText(System.IO.Path.Combine(text, "Theme.xml"));
		_viewModel = new BootstrapperEditorWindowViewModel
		{
			Directory = text,
			Name = name,
			Code = ToCRLF(text2),
			Title = string.Format(CultureInfo.InvariantCulture, Strings.CustomTheme_Editor_Title, name)
		};
		DataContext = _viewModel;
		Loaded += (object? s, RoutedEventArgs e) =>
		{
			UIXML.Text = _viewModel.Code;
		};
		_viewModel.ThemeSavedCallback = (bool success, string message) =>
		{
			if (success)
			{
				Avalonia.Threading.Dispatcher.UIThread.Post(() =>
				{
					ShowNotification(Strings.Menu_SettingsSaved_Title, Strings.Menu_SettingsSaved_Message, FAInfoBarSeverity.Success, 3000);
				});
			}
			else
			{
				Avalonia.Threading.Dispatcher.UIThread.Post(() =>
				{
					ShowNotification("Error", message, FAInfoBarSeverity.Error, 5000);
				});
			}
		};
		UIXML.TextChanged += OnCodeChanged;
		UIXML.TextArea.TextEntered += OnTextEntered;
		LoadHighlightingTheme();
		Closing += OnClosing;
	}

	private void OnTextEntered(object? sender, TextInputEventArgs e)
	{
		if (!string.IsNullOrEmpty(e.Text))
		{
			switch (e.Text)
			{
			case "<":
				OpenElementAutoComplete();
				break;
			case " ":
				OpenAttributeAutoComplete();
				break;
			case ".":
				OpenPropertyElementAutoComplete();
				break;
			case "/":
				AddEndTag();
				break;
			case ">":
			case "!":
				CloseCompletionWindow();
				break;
			}
		}
	}

	private void LoadHighlightingTheme()
	{
		try
		{
			string text = App.Settings.Prop.Theme.GetFinal().ToString();
			using Stream input = AssetLoader.Open(new Uri("avares://Merostrap/UI/AppThemes/EditorThemes/Editor-Theme-" + text + ".xshd"));
			using XmlReader reader = XmlReader.Create(input);
			UIXML.SyntaxHighlighting = HighlightingLoader.Load(reader, HighlightingManager.Instance);
		}
		catch (Exception)
		{
			App.Logger.Error("Theme file not found, falling back to default XML.");
			UIXML.SyntaxHighlighting = HighlightingManager.Instance.GetDefinition("XML");
		}
	}

	public void ShowNotification(string title, string subtitle, FAInfoBarSeverity type, int timeout, LucideIconNames? customIcon = null)
	{
		Panel panel = this.FindControl<Panel>("NotificationPanel");
		if (panel == null)
		{
			return;
		}
		string s = ((type == FAInfoBarSeverity.Success) ? "#00D084" : "#FFB900");
		LucideIconNames? lucideIconNames = customIcon;
		if (!lucideIconNames.HasValue)
		{
			if (type == FAInfoBarSeverity.Success)
			{
			}
		}
		else
		{
			lucideIconNames.GetValueOrDefault();
		}
		Grid grid = new Grid
		{
			ColumnDefinitions = new ColumnDefinitions("Auto,*,Auto"),
			Margin = new Thickness(0.0)
		};
		Ellipse ellipse = new Ellipse
		{
			Width = 12.0,
			Height = 12.0,
			Margin = new Thickness(25.0),
			Fill = new SolidColorBrush(Color.Parse(s))
		};
		Grid.SetColumn(ellipse, 0);
		grid.Children.Add(ellipse);
		StackPanel stackPanel = new StackPanel
		{
			VerticalAlignment = VerticalAlignment.Center,
			Spacing = 2.0
		};
		TextBlock textBlock = new TextBlock
		{
			Text = title,
			FontWeight = FontWeight.DemiBold,
			FontSize = 16.0,
			Margin = new Thickness(0.0, 2.0)
		};
		textBlock.Bind(TextBlock.ForegroundProperty, new DynamicResourceExtension("TextFillColorPrimaryBrush"));
		TextBlock textBlock2 = new TextBlock
		{
			Text = subtitle,
			FontSize = 12.0,
			TextWrapping = TextWrapping.Wrap,
			Margin = new Thickness(0.0, 2.0)
		};
		textBlock2.Bind(TextBlock.ForegroundProperty, new DynamicResourceExtension("TextFillColorSecondaryBrush"));
		stackPanel.Children.Add(textBlock);
		stackPanel.Children.Add(textBlock2);
		Grid.SetColumn(stackPanel, 1);
		grid.Children.Add(stackPanel);
		IconButton iconButton = new IconButton
		{
			Icon = LucideIconNames.X,
			IconSize = 12.0,
			CornerRadius = new CornerRadius(0.0, 10.0, 10.0, 0.0),
			Background = Brushes.Transparent,
			BorderThickness = new Thickness(0.0),
			Padding = new Thickness(8.0, 4.0, 8.0, 4.0),
			VerticalAlignment = VerticalAlignment.Stretch,
			HorizontalAlignment = HorizontalAlignment.Right,
			Margin = new Thickness(20.0, 0.0, 0.0, 0.0),
			Width = 50.0
		};
		iconButton.Bind(TemplatedControl.ForegroundProperty, new DynamicResourceExtension("TextFillColorSecondaryBrush"));
		Grid.SetColumn(iconButton, 2);
		grid.Children.Add(iconButton);
		TranslateTransform transform = new TranslateTransform(500.0, 0.0)
		{
			Transitions = new Transitions
			{
				new DoubleTransition
				{
					Property = TranslateTransform.XProperty,
					Duration = TimeSpan.FromMilliseconds(350L),
					Easing = new QuarticEaseOut()
				},
				new DoubleTransition
				{
					Property = TranslateTransform.YProperty,
					Duration = TimeSpan.FromMilliseconds(300L),
					Easing = new QuarticEaseOut()
				}
			}
		};
		Border border = new Border
		{
			Margin = new Thickness(0.0, 15.0, 15.0, 0.0),
			MinWidth = 350.0,
			Height = 80.0,
			CornerRadius = new CornerRadius(10.0),
			RenderTransform = transform,
			Child = grid,
			BoxShadow = new BoxShadows(new BoxShadow
			{
				Blur = 10.0,
				OffsetY = 4.0,
				Color = Color.Parse("#40000000")
			}),
			HorizontalAlignment = HorizontalAlignment.Right,
			VerticalAlignment = VerticalAlignment.Top
		};
		border.Bind(Border.BackgroundProperty, new DynamicResourceExtension("NotificationBackgroundColor"));
		NotificationEntry entry = new NotificationEntry
		{
			Element = border,
			Transform = transform
		};
		iconButton.Click += (object? obj, RoutedEventArgs e) =>
		{
			e.Handled = true;
			Dismiss();
		};
		border.PointerPressed += (object? obj, PointerPressedEventArgs e) =>
		{
			if (!(e.Source is IconButton))
			{
				Dismiss();
			}
		};
		_notifications.Insert(0, entry);
		panel.Children.Add(border);
		while (_notifications.Count > 3)
		{
			List<NotificationEntry> notifications = _notifications;
			DismissNotification(notifications[notifications.Count - 1]);
		}
		RepositionNotifications();
		CancellationTokenSource cts = new CancellationTokenSource();
		entry.TimeoutCts = cts;
		Avalonia.Threading.Dispatcher.UIThread.InvokeAsync(async () =>
		{
			await Task.Delay(50);
			if (!cts.IsCancellationRequested)
			{
				transform.X = 0.0;
				await Task.Delay(timeout);
				if (!cts.IsCancellationRequested)
				{
					Dismiss();
				}
			}
		});
		void Dismiss()
		{
			DismissNotification(entry);
		}
	}

	private async void DismissNotification(NotificationEntry entry)
	{
		if (_notifications.Remove(entry))
		{
			entry.TimeoutCts?.Cancel();
			RepositionNotifications();
			entry.Transform.X = 500.0;
			await Task.Delay(350);
			Panel panel = this.FindControl<Panel>("NotificationPanel");
			if (panel != null && panel.Children.Contains(entry.Element))
			{
				panel.Children.Remove(entry.Element);
			}
		}
	}

	private void RepositionNotifications()
	{
		for (int i = 0; i < _notifications.Count; i++)
		{
			_notifications[i].Transform.Y = i * 95;
		}
	}

	private static string ToCRLF(string text)
	{
		return text.Replace("\r\n", "\n", StringComparison.Ordinal).Replace('\r', '\n').Replace('\n', '\r');
	}

	private void OnCodeChanged(object? sender, EventArgs e)
	{
		if (_isInitialLoad)
		{
			_isInitialLoad = false;
			return;
		}
		_viewModel.Code = UIXML.Text;
		_viewModel.CodeChanged = true;
	}

	private async void OnClosing(object? sender, CancelEventArgs e)
	{
		if (_viewModel.CodeChanged)
		{
			e.Cancel = true;
			switch (await Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.CustomTheme_Editor_ConfirmSave, _viewModel.Name), MessageBoxImage.Information, MessageBoxButton.YesNoCancel))
			{
			case MessageBoxResult.Yes:
				_viewModel.SaveCommand.Execute(null);
				_viewModel.CodeChanged = false;
				Close();
				break;
			case MessageBoxResult.No:
				_viewModel.CodeChanged = false;
				Close();
				break;
			}
		}
	}

	private (string, int) GetLineAndPosAtCaretPosition()
	{
		if (UIXML.CaretOffset - 1 < 0)
		{
			return ("", 0);
		}
		DocumentLine lineByOffset = UIXML.Document.GetLineByOffset(UIXML.CaretOffset);
		string text = UIXML.Document.GetText(lineByOffset.Offset, lineByOffset.Length);
		int item = UIXML.CaretOffset - lineByOffset.Offset - 1;
		return (text, item);
	}

	public static string? GetElementAtCursor(string xml, int offset, bool onlyAllowInside = false)
	{
		if (offset <= 0)
		{
			return null;
		}
		if (offset > xml.Length)
		{
			offset = xml.Length;
		}
		int num = xml.LastIndexOf('<', offset - 1);
		if (num < 0)
		{
			return null;
		}
		if (num + 1 < xml.Length && xml[num + 1] == '/')
		{
			num++;
		}
		int num2 = xml.IndexOf(' ', num);
		if (num2 == -1)
		{
			num2 = int.MaxValue;
		}
		int num3 = xml.IndexOf('>', num);
		if (num3 == -1)
		{
			num3 = int.MaxValue;
		}
		else
		{
			if (onlyAllowInside && num3 < offset)
			{
				return null;
			}
			if (num3 > 0 && xml[num3 - 1] == '/')
			{
				num3--;
			}
		}
		int num4 = Math.Min(num2, num3);
		if (num4 > num && num4 < int.MaxValue)
		{
			string text = xml.Substring(num + 1, num4 - num - 1);
			if (!text.StartsWith("!--", StringComparison.Ordinal))
			{
				return text;
			}
			return null;
		}
		return null;
	}

	private string? GetElementAtCursorNoSpaces()
	{
		(string, int) lineAndPosAtCaretPosition = GetLineAndPosAtCaretPosition();
		string item = lineAndPosAtCaretPosition.Item1;
		int num = lineAndPosAtCaretPosition.Item2;
		string text = "";
		while (num != -1)
		{
			char c = item[num];
			switch (c)
			{
			case '\t':
			case ' ':
				return null;
			case '<':
				return text;
			}
			text = c + text;
			num--;
		}
		return null;
	}

	private string? ShowAttributesForElementName()
	{
		var (text, num) = GetLineAndPosAtCaretPosition();
		if (text.Count((char x) => x == '"') % 2 == 0)
		{
			int num2 = 0;
			for (int num3 = num + 1; num3 < text.Length; num3++)
			{
				if (text[num3] == '"')
				{
					num2++;
				}
			}
			if (num2 % 2 != 0)
			{
				return null;
			}
		}
		return GetElementAtCursor(UIXML.Text, UIXML.CaretOffset, onlyAllowInside: true);
	}

	private void AddEndTag()
	{
		CloseCompletionWindow();
		if (UIXML.CaretOffset >= 2 && UIXML.Text[UIXML.CaretOffset - 2] == '<')
		{
			string elementAtCursor = GetElementAtCursor(UIXML.Text, UIXML.CaretOffset - 2);
			if (elementAtCursor != null)
			{
				UIXML.TextArea.Document.Insert(UIXML.CaretOffset, elementAtCursor + ">");
			}
		}
		else if ((UIXML.CaretOffset >= UIXML.Text.Length || UIXML.Text[UIXML.CaretOffset] != '>') && ShowAttributesForElementName() != null)
		{
			UIXML.TextArea.Document.Insert(UIXML.CaretOffset, ">");
		}
	}

	private void OpenElementAutoComplete()
	{
		List<ICompletionData> completionData = CustomBootstrapperSchema.ElementInfo.Keys.Select((string e) => new ElementCompletionData(e)).Cast<ICompletionData>().ToList();
		ShowCompletionWindow(completionData);
	}

	private void OpenAttributeAutoComplete()
	{
		string text = ShowAttributesForElementName();
		if (text == null || !CustomBootstrapperSchema.ElementInfo.TryGetValue(text, out SortedDictionary<string, string> value))
		{
			CloseCompletionWindow();
			return;
		}
		List<ICompletionData> completionData = value.Select((KeyValuePair<string, string> a) => new AttributeCompletionData(a.Key, () =>
		{
			OpenTypeValueAutoComplete(a.Value);
		})).Cast<ICompletionData>().ToList();
		ShowCompletionWindow(completionData);
	}

	private void OpenTypeValueAutoComplete(string typeName)
	{
		if (CustomBootstrapperSchema.Types.TryGetValue(typeName, out CustomBootstrapperSchema.Type value) && value.Values != null)
		{
			List<ICompletionData> completionData = value.Values.Select((string v) => new TypeValueCompletionData(v)).Cast<ICompletionData>().ToList();
			ShowCompletionWindow(completionData);
		}
	}

	private void OpenPropertyElementAutoComplete()
	{
		string elementAtCursorNoSpaces = GetElementAtCursorNoSpaces();
		if (elementAtCursorNoSpaces == null || !CustomBootstrapperSchema.PropertyElements.TryGetValue(elementAtCursorNoSpaces, out List<string> value))
		{
			CloseCompletionWindow();
			return;
		}
		List<ICompletionData> completionData = value.Select((string p) => new TypeValueCompletionData(p)).Cast<ICompletionData>().ToList();
		ShowCompletionWindow(completionData);
	}

	private void CloseCompletionWindow()
	{
		_completionWindow?.Close();
		_completionWindow = null;
	}

	private void ShowCompletionWindow(List<ICompletionData> completionData)
	{
		CloseCompletionWindow();
		if (completionData.Count == 0)
		{
			return;
		}
		_completionWindow = new CompletionWindow(UIXML.TextArea);
		foreach (ICompletionData completionDatum in completionData)
		{
			_completionWindow.CompletionList.CompletionData.Add(completionDatum);
		}
		_completionWindow.Show();
		_completionWindow.Closed += (object? _, EventArgs _) =>
		{
			_completionWindow = null;
		};
	}

	private void OnCancelButtonClicked(object? sender, RoutedEventArgs e)
	{
		Close();
	}

	public void Dispose()
	{
		Dispose(disposing: true);
		GC.SuppressFinalize(this);
	}

	protected virtual void Dispose(bool disposing)
	{
		if (_disposed)
		{
			return;
		}
		if (disposing)
		{
			_completionWindow?.Close();
			_completionWindow = null;
			foreach (NotificationEntry notification in _notifications)
			{
				notification.TimeoutCts?.Cancel();
				notification.TimeoutCts?.Dispose();
				(notification.Element.Parent as Panel)?.Children.Remove(notification.Element);
			}
			_notifications.Clear();
		}
		_disposed = true;
	}

	[GeneratedCode("Avalonia.Generators.NameGenerator.InitializeComponentCodeGenerator", "12.1.2.0")]
	[ExcludeFromCodeCoverage]
	public void InitializeComponent(bool loadXaml = true)
	{
		if (loadXaml)
		{
			_0021XamlIlPopulateTrampoline(this);
		}
		INameScope nameScope = this.FindNameScope();
		NotificationPanel = nameScope?.Find<Panel>("NotificationPanel");
		UIXML = nameScope?.Find<TextEditor>("UIXML");
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulate(IServiceProvider P_0, BootstrapperEditorWindow P_1)
	{
		XamlIlContext.Context<BootstrapperEditorWindow> context = new XamlIlContext.Context<BootstrapperEditorWindow>(P_0, new object[1] { _0021AvaloniaResources.NamespaceInfo_003A_002FUI_002FElements_002FEditor_002FBootstrapperEditorWindow_002Eaxaml.Singleton }, "avares://Merostrap/UI/Elements/Editor/BootstrapperEditorWindow.axaml")
		{
			RootObject = P_1,
			IntermediateRoot = P_1
		};
		((ISupportInitialize)P_1).BeginInit();
		context.PushParent(P_1);
		StyledProperty<string?> titleProperty = Window.TitleProperty;
		CompiledBindingExtension compiledBindingExtension = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EEditor_002EBootstrapperEditorWindowViewModel_002CMerostrap_002ETitle_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Window.TitleProperty;
		CompiledBinding binding = compiledBindingExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		P_1.Bind(titleProperty, binding);
		P_1.Width = 1000.0;
		P_1.Height = 500.0;
		P_1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		Grid grid2;
		Grid grid = (grid2 = new Grid());
		((ISupportInitialize)grid).BeginInit();
		P_1.Content = grid;
		Grid grid4;
		Grid grid3 = (grid4 = grid2);
		context.PushParent(grid4);
		Grid grid5 = grid4;
		RowDefinitions rowDefinitions = new RowDefinitions();
		rowDefinitions.Capacity = 2;
		rowDefinitions.Add(new RowDefinition(new GridLength(1.0, GridUnitType.Star)));
		rowDefinitions.Add(new RowDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid5.RowDefinitions = rowDefinitions;
		Avalonia.Controls.Controls children = grid5.Children;
		Panel panel2;
		Panel panel = (panel2 = new Panel());
		((ISupportInitialize)panel).BeginInit();
		children.Add(panel);
		panel2.Name = "NotificationPanel";
		object element = panel2;
		context.AvaloniaNameScope.Register("NotificationPanel", element);
		Grid.SetRow(panel2, 0);
		Grid.SetRowSpan(panel2, 3);
		panel2.HorizontalAlignment = HorizontalAlignment.Stretch;
		panel2.VerticalAlignment = VerticalAlignment.Top;
		panel2.ZIndex = 1000;
		((ISupportInitialize)panel2).EndInit();
		Avalonia.Controls.Controls children2 = grid5.Children;
		TextEditor textEditor2;
		TextEditor textEditor = (textEditor2 = new TextEditor());
		((ISupportInitialize)textEditor).BeginInit();
		children2.Add(textEditor);
		textEditor2.Name = "UIXML";
		element = textEditor2;
		context.AvaloniaNameScope.Register("UIXML", element);
		Grid.SetRow(textEditor2, 0);
		textEditor2.Classes.Add("NewTextEditor");
		textEditor2.ShowLineNumbers = true;
		textEditor2.Margin = new Thickness(10.0, 10.0, 10.0, 10.0);
		textEditor2.Padding = new Thickness(5.0, 5.0, 5.0, 5.0);
		textEditor2.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
		textEditor2.VerticalScrollBarVisibility = ScrollBarVisibility.Visible;
		((ISupportInitialize)textEditor2).EndInit();
		Avalonia.Controls.Controls children3 = grid5.Children;
		Border border2;
		Border border = (border2 = new Border());
		((ISupportInitialize)border).BeginInit();
		children3.Add(border);
		Border border4;
		Border border3 = (border4 = border2);
		context.PushParent(border4);
		Grid.SetRow(border4, 1);
		StyledProperty<IBrush?> backgroundProperty = Border.BackgroundProperty;
		DynamicResourceExtension dynamicResourceExtension = new DynamicResourceExtension("ControlFillColorDefaultBrush");
		context.ProvideTargetProperty = Border.BackgroundProperty;
		BindingBase binding2 = dynamicResourceExtension.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border4.Bind(backgroundProperty, binding2);
		StyledProperty<IBrush?> borderBrushProperty = Border.BorderBrushProperty;
		DynamicResourceExtension dynamicResourceExtension2 = new DynamicResourceExtension("ControlStrokeColorDefault");
		context.ProvideTargetProperty = Border.BorderBrushProperty;
		BindingBase binding3 = dynamicResourceExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		border4.Bind(borderBrushProperty, binding3);
		border4.BorderThickness = new Thickness(0.0, 1.0, 0.0, 0.0);
		border4.Padding = new Thickness(0.0, 0.0, 16.0, 0.0);
		border4.Height = 56.0;
		Grid grid7;
		Grid grid6 = (grid7 = new Grid());
		((ISupportInitialize)grid6).BeginInit();
		border4.Child = grid6;
		Grid grid8 = (grid4 = grid7);
		context.PushParent(grid4);
		Grid grid9 = grid4;
		ColumnDefinitions columnDefinitions = new ColumnDefinitions();
		columnDefinitions.Capacity = 4;
		columnDefinitions.Add(new ColumnDefinition(new GridLength(1.0, GridUnitType.Star)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		columnDefinitions.Add(new ColumnDefinition(new GridLength(0.0, GridUnitType.Auto)));
		grid9.ColumnDefinitions = columnDefinitions;
		Avalonia.Controls.Controls children4 = grid9.Children;
		Button button2;
		Button button = (button2 = new Button());
		((ISupportInitialize)button).BeginInit();
		children4.Add(button);
		Button button4;
		Button button3 = (button4 = button2);
		context.PushParent(button4);
		Button button5 = button4;
		Grid.SetColumn(button5, 0);
		button5.Margin = new Thickness(8.0, 0.0, 0.0, 0.0);
		StyledProperty<ICommand?> commandProperty = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension2 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EEditor_002EBootstrapperEditorWindowViewModel_002CMerostrap_002EOpenThemeFolderCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding4 = compiledBindingExtension2.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button5.Bind(commandProperty, binding4);
		button5.Content = Strings.CustomTheme_Editor_OpenThemeDirectory;
		context.PopParent();
		((ISupportInitialize)button3).EndInit();
		Avalonia.Controls.Controls children5 = grid9.Children;
		Button button7;
		Button button6 = (button7 = new Button());
		((ISupportInitialize)button6).BeginInit();
		children5.Add(button6);
		Button button8 = (button4 = button7);
		context.PushParent(button4);
		Button button9 = button4;
		Grid.SetColumn(button9, 1);
		button9.Margin = new Thickness(10.0, 0.0, 0.0, 0.0);
		button9.Classes.Add("accent");
		StyledProperty<ICommand?> commandProperty2 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension3 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EEditor_002EBootstrapperEditorWindowViewModel_002CMerostrap_002EPreviewCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding5 = compiledBindingExtension3.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button9.Bind(commandProperty2, binding5);
		button9.Content = Strings.Menu_Appearance_Preview;
		context.PopParent();
		((ISupportInitialize)button8).EndInit();
		Avalonia.Controls.Controls children6 = grid9.Children;
		Button button11;
		Button button10 = (button11 = new Button());
		((ISupportInitialize)button10).BeginInit();
		children6.Add(button10);
		Button button12 = (button4 = button11);
		context.PushParent(button4);
		Button button13 = button4;
		Grid.SetColumn(button13, 2);
		button13.Margin = new Thickness(10.0, 0.0, 0.0, 0.0);
		button13.Classes.Add("accent");
		StyledProperty<ICommand?> commandProperty3 = Button.CommandProperty;
		CompiledBindingExtension compiledBindingExtension4 = new CompiledBindingExtension(new CompiledBindingPathBuilder().Property(XamlIlHelpers.Merostrap_002EUI_002EViewModels_002EEditor_002EBootstrapperEditorWindowViewModel_002CMerostrap_002ESaveCommand_0021Property(), PropertyInfoAccessorFactory.CreateInpcPropertyAccessor).Build());
		context.ProvideTargetProperty = Button.CommandProperty;
		CompiledBinding binding6 = compiledBindingExtension4.ProvideValue(context);
		context.ProvideTargetProperty = null;
		button13.Bind(commandProperty3, binding6);
		button13.Content = Strings.Menu_Save;
		context.PopParent();
		((ISupportInitialize)button12).EndInit();
		Avalonia.Controls.Controls children7 = grid9.Children;
		Button button15;
		Button button14 = (button15 = new Button());
		((ISupportInitialize)button14).BeginInit();
		children7.Add(button14);
		Grid.SetColumn(button15, 3);
		button15.Margin = new Thickness(12.0, 0.0, 0.0, 0.0);
		button15.Content = Strings.Common_Close;
		button15.AddHandler((RoutedEvent)Button.ClickEvent, (Delegate)new EventHandler<RoutedEventArgs>(context.RootObject.OnCancelButtonClicked), RoutingStrategies.Direct | RoutingStrategies.Bubble, false);
		((ISupportInitialize)button15).EndInit();
		context.PopParent();
		((ISupportInitialize)grid8).EndInit();
		context.PopParent();
		((ISupportInitialize)border3).EndInit();
		context.PopParent();
		((ISupportInitialize)grid3).EndInit();
		context.PopParent();
		((ISupportInitialize)P_1).EndInit();
		if (P_1 is StyledElement styled)
		{
			NameScope.SetNameScope(styled, context.AvaloniaNameScope);
		}
		context.AvaloniaNameScope.Complete();
	}

	[CompilerGenerated]
	private static void _0021XamlIlPopulateTrampoline(BootstrapperEditorWindow P_0)
	{
		if (_0021XamlIlPopulateOverride != null)
		{
			_0021XamlIlPopulateOverride(P_0);
		}
		else
		{
			_0021XamlIlPopulate(XamlIlRuntimeHelpers.CreateRootServiceProviderV3(null), P_0);
		}
	}
}
