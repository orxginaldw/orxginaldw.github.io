using System;
using Avalonia.Media;
using Avalonia.Threading;
using AvaloniaEdit.CodeCompletion;
using AvaloniaEdit.Document;
using AvaloniaEdit.Editing;

namespace Merostrap.UI.Elements.Editor;

internal class AttributeCompletionData(string text, Action openValueAction) : ICompletionData
{
	public IImage? Image => null;

	public string Text { get; } = text;

	public object Content => Text;

	public object? Description => null;

	public double Priority => 0.0;

	public void Complete(TextArea textArea, ISegment completionSegment, EventArgs insertionRequestEventArgs)
	{
		textArea.Document.Replace(completionSegment, Text + "=\"\"");
		textArea.Caret.Offset--;
		Dispatcher.UIThread.Post(openValueAction);
	}
}
