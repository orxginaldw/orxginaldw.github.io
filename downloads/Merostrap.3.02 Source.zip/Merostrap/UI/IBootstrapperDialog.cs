using System;
using Merostrap.Enums.BootstrapperDialogs;

namespace Merostrap.UI;

internal interface IBootstrapperDialog
{
	Bootstrapper? Bootstrapper { get; set; }

	string Message { get; set; }

	string CancelButtonText { get; set; }

	bool ProgressIndeterminate { get; set; }

	int ProgressValue { get; set; }

	int ProgressMaximum { get; set; }

	TaskbarItemProgressState TaskbarProgressState { get; set; }

	double TaskbarProgressValue { get; set; }

	bool CancelEnabled { get; set; }

	void ShowBootstrapper();

	void CloseBootstrapper();

	void ShowSuccess(string message, Action? callback = null);
}
