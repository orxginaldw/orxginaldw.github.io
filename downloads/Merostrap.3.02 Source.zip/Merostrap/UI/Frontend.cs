using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Threading;
using Merostrap.Enums;
using Merostrap.Enums.Messagebox;
using Merostrap.Resources;
using Merostrap.UI.Elements.Bootstrapper;
using Merostrap.UI.Elements.Dialogs;

namespace Merostrap.UI;

internal static class Frontend
{
	public static async Task<MessageBoxResult> ShowMessageBox(string message, MessageBoxImage icon = MessageBoxImage.Information, MessageBoxButton buttons = MessageBoxButton.OK, MessageBoxResult defaultResult = MessageBoxResult.None)
	{
		if (App.LaunchSettings.QuietFlag.Active)
		{
			return defaultResult;
		}
		App.Logger.Info(message);
		return await ShowFluentMessageBox(message, icon, buttons);
	}

	public static async Task ShowPlayerErrorDialog(bool crash = false)
	{
		if (!App.LaunchSettings.QuietFlag.Active)
		{
			string text = (crash ? Strings.Dialog_PlayerError_Crash : Strings.Dialog_PlayerError_FailedLaunch);
			string text2 = string.Format(CultureInfo.InvariantCulture, Strings.Dialog_PlayerError_HelpInformation, "https://github.com//wiki/Roblox-crashes-or-does-not-launch", "https://github.com//wiki/Switching-between-Roblox-and-Bloxstrap");
			await ShowMessageBox(string.IsNullOrEmpty("") ? text : (text + "\n\n" + text2), MessageBoxImage.Error);
		}
	}

	public static async Task ShowExceptionDialog(Exception exception)
	{
		if (App.LaunchSettings.QuietFlag.Active)
		{
			return;
		}
		await Dispatcher.UIThread.InvokeAsync(async () =>
		{
			ExceptionDialog exceptionDialog = new ExceptionDialog(exception);
			Window window = null;
			if (Application.Current?.ApplicationLifetime is IClassicDesktopStyleApplicationLifetime { Windows: var windows } classicDesktopStyleApplicationLifetime)
			{
				window = windows.FirstOrDefault((Window w) => w.IsActive) ?? classicDesktopStyleApplicationLifetime.MainWindow;
			}
			if (window != null && window.IsVisible)
			{
				await exceptionDialog.ShowDialog(window);
			}
			else
			{
				TaskCompletionSource<bool> tcs = new TaskCompletionSource<bool>();
				exceptionDialog.Closed += (object? s, EventArgs e) =>
				{
					tcs.TrySetResult(result: true);
				};
				exceptionDialog.Show();
				await tcs.Task;
			}
		});
	}

	public static async Task ShowConnectivityDialog(string title, string description, MessageBoxImage image, Exception exception)
	{
		if (App.LaunchSettings.QuietFlag.Active)
		{
			return;
		}
		await Dispatcher.UIThread.InvokeAsync(async () =>
		{
			ConnectivityDialog connectivityDialog = new ConnectivityDialog(title, description, image, exception);
			Window window = null;
			if (Application.Current?.ApplicationLifetime is IClassicDesktopStyleApplicationLifetime { Windows: var windows } classicDesktopStyleApplicationLifetime)
			{
				window = windows.FirstOrDefault((Window w) => w.IsActive) ?? classicDesktopStyleApplicationLifetime.MainWindow;
			}
			if (window != null && window.IsVisible)
			{
				await connectivityDialog.ShowDialog(window);
			}
			else
			{
				TaskCompletionSource<bool> tcs = new TaskCompletionSource<bool>();
				connectivityDialog.Closed += (object? s, EventArgs e) =>
				{
					tcs.TrySetResult(result: true);
				};
				connectivityDialog.Show();
				await tcs.Task;
			}
		});
	}

	private static async Task<IBootstrapperDialog> GetCustomBootstrapper()
	{
		Directory.CreateDirectory(Paths.CustomThemes);
		try
		{
			if (App.Settings.Prop.SelectedCustomTheme == null)
			{
				throw new InvalidOperationException("No custom theme selected");
			}
			CustomDialog customDialog = new CustomDialog();
			customDialog.ApplyCustomTheme(App.Settings.Prop.SelectedCustomTheme);
			return customDialog;
		}
		catch (Exception ex)
		{
			App.Logger.Error("Unhandled exception", ex);
			if (!App.LaunchSettings.QuietFlag.Active)
			{
				await ShowMessageBox("Failed to setup custom bootstrapper: " + ex.Message + ".\nDefaulting to Fluent.", MessageBoxImage.Error);
			}
			return await GetBootstrapperDialog(BootstrapperStyle.FluentDialog);
		}
	}

	public static async Task<IBootstrapperDialog> GetBootstrapperDialog(BootstrapperStyle style)
	{
		return style switch
		{
			BootstrapperStyle.ClassicFluentDialog => new ClassicFluentDialog(), 
			BootstrapperStyle.ByfronDialog => new ByfronDialog(), 
			BootstrapperStyle.ModernDialog => new ModernDialog(), 
			BootstrapperStyle.TwentyFiveDialog => new TwentyFiveDialog(), 
			BootstrapperStyle.FluentDialog => new FluentDialog(aero: false), 
			BootstrapperStyle.FluentAeroDialog => new FluentDialog(aero: true), 
			BootstrapperStyle.CustomDialog => await GetCustomBootstrapper(), 
			_ => new FluentDialog(aero: false), 
		};
	}

	private static async Task<MessageBoxResult> ShowFluentMessageBox(string message, MessageBoxImage icon, MessageBoxButton buttons)
	{
		return await Dispatcher.UIThread.InvokeAsync(async () =>
		{
			FluentMessageBox messagebox = new FluentMessageBox(message, icon, buttons);
			Window window = null;
			if (Application.Current?.ApplicationLifetime is IClassicDesktopStyleApplicationLifetime { Windows: var windows } classicDesktopStyleApplicationLifetime)
			{
				window = windows.FirstOrDefault((Window w) => w.IsActive) ?? classicDesktopStyleApplicationLifetime.MainWindow;
			}
			if (window != null)
			{
				await messagebox.ShowDialog(window);
			}
			else
			{
				TaskCompletionSource<bool> tcs = new TaskCompletionSource<bool>();
				messagebox.Closed += (object? s, EventArgs e) =>
				{
					tcs.TrySetResult(result: true);
				};
				messagebox.Show();
				await tcs.Task;
			}
			return messagebox.Result;
		});
	}
}
