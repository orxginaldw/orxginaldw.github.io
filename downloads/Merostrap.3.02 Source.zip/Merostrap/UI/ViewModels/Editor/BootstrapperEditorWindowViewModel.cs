using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Windows.Input;
using CommunityToolkit.Mvvm.Input;
using Merostrap.Enums.Messagebox;
using Merostrap.Resources;
using Merostrap.UI.Elements.Bootstrapper;

namespace Merostrap.UI.ViewModels.Editor;

internal class BootstrapperEditorWindowViewModel : NotifyPropertyChangedViewModel
{
	private CustomDialog? _dialog;

	public ICommand PreviewCommand => new RelayCommand(Preview);

	public ICommand SaveCommand => new RelayCommand(Save);

	public ICommand OpenThemeFolderCommand => new RelayCommand(OpenThemeFolder);

	public Action<bool, string> ThemeSavedCallback { get; set; }

	public string Directory { get; set; } = "";

	public string Name { get; set; } = "";

	public string Title { get; set; } = "Editing \"Custom Theme\"";

	public string Code { get; set; } = "";

	public bool CodeChanged { get; set; }

	private void Preview()
	{
		try
		{
			CustomDialog customDialog = new CustomDialog();
			customDialog.ApplyCustomTheme(Name, Code);
			_dialog?.CloseBootstrapper();
			_dialog = customDialog;
			customDialog.Message = Strings.Bootstrapper_StylePreview_TextCancel;
			customDialog.CancelEnabled = true;
			customDialog.ShowBootstrapper();
		}
		catch (Exception ex)
		{
			App.Logger.Error("Unhandled exception: ", ex);
			Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.CustomTheme_Editor_Errors_PreviewFailed, ex.Message), MessageBoxImage.Error);
		}
	}

	private void Save()
	{
		string path = Path.Combine(Directory, "Theme.xml");
		try
		{
			File.WriteAllText(path, Code);
			CodeChanged = false;
			ThemeSavedCallback?.Invoke(arg1: true, Strings.CustomTheme_Editor_Save_Success_Description);
		}
		catch (Exception ex)
		{
			App.Logger.Error("Unhandled exception: ", ex);
			ThemeSavedCallback?.Invoke(arg1: false, ex.Message);
		}
	}

	private void OpenThemeFolder()
	{
		if (!string.IsNullOrEmpty(Directory))
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = Directory,
				UseShellExecute = true,
				Verb = "open"
			});
		}
	}
}
