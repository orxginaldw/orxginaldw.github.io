using System;
using Avalonia;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Platform;

namespace Merostrap.UI.ViewModels.Bootstrapper;

internal class ByfronDialogViewModel(IBootstrapperDialog dialog, string version) : BootstrapperDialogViewModel(dialog)
{
	public Bitmap ByfronLogoLocation { get; set; } = new Bitmap(AssetLoader.Open(new Uri("avares://Merostrap/Resources/BootstrapperStyles/ByfronDialog/ByfronLogoDark.jpg")));

	public Thickness DialogBorder { get; set; } = new Thickness(0.0);

	public IBrush Background { get; set; } = Brushes.Black;

	public IBrush Foreground { get; set; } = new SolidColorBrush(Color.FromRgb(239, 239, 239));

	public IBrush IconColor { get; set; } = new SolidColorBrush(Color.FromRgb(byte.MaxValue, byte.MaxValue, byte.MaxValue));

	public IBrush ProgressBarBackground { get; set; } = new SolidColorBrush(Color.FromRgb(86, 86, 86));

	public bool VersionTextVisible => !CancelEnabled;

	public string VersionText { get; init; } = version;
}
