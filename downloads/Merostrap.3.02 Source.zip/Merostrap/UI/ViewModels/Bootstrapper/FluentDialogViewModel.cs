using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Avalonia.Controls;
using Avalonia.Media;
using Merostrap.Enums;
using Merostrap.Extensions;

namespace Merostrap.UI.ViewModels.Bootstrapper;

internal class FluentDialogViewModel : BootstrapperDialogViewModel
{
	public List<WindowTransparencyLevel> WindowBackdropType { get; set; }

	public IBrush BackgroundColourBrush { get; set; } = Brushes.Transparent;

	public FluentDialogViewModel(IBootstrapperDialog dialog, bool aero)
		: base(dialog)
	{
		List<WindowTransparencyLevel> list;
		if (!aero)
		{
			int num = 1;
			list = new List<WindowTransparencyLevel>(num);
			CollectionsMarshal.SetCount(list, num);
			CollectionsMarshal.AsSpan(list)[0] = WindowTransparencyLevel.None;
		}
		else
		{
			int num = 3;
			list = new List<WindowTransparencyLevel>(num);
			CollectionsMarshal.SetCount(list, num);
			Span<WindowTransparencyLevel> span = CollectionsMarshal.AsSpan(list);
			span[0] = WindowTransparencyLevel.AcrylicBlur;
			span[1] = WindowTransparencyLevel.Blur;
			span[2] = WindowTransparencyLevel.None;
		}
		WindowBackdropType = list;
		bool flag = App.Settings.Prop.Theme.GetFinal() == Theme.Light;
		if (aero)
		{
			byte a = 135;
			BackgroundColourBrush = new SolidColorBrush(flag ? Color.FromArgb(a, 225, 225, 225) : Color.FromArgb(a, 30, 30, 30));
		}
		else
		{
			BackgroundColourBrush = new SolidColorBrush(flag ? Color.FromRgb(240, 240, 240) : Color.FromRgb(30, 30, 30));
		}
	}
}
