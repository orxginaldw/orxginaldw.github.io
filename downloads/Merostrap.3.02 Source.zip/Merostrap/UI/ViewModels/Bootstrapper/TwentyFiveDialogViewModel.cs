namespace Merostrap.UI.ViewModels.Bootstrapper;

internal class TwentyFiveDialogViewModel : BootstrapperDialogViewModel
{
	public bool CancelButtonVisibility => CancelEnabled;

	public TwentyFiveDialogViewModel(IBootstrapperDialog dialog)
		: base(dialog)
	{
	}
}
