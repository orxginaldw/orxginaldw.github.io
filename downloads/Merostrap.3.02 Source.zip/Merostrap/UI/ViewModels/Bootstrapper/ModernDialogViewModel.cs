using Avalonia;
using Avalonia.Media;

namespace Merostrap.UI.ViewModels.Bootstrapper;

internal class ModernDialogViewModel(IBootstrapperDialog dialog, string version) : BootstrapperDialogViewModel(dialog)
{
	public Thickness DialogBorder { get; set; } = new Thickness(0.0);

	public IBrush Background { get; set; } = Brushes.Black;

	public IBrush Foreground { get; set; } = new SolidColorBrush(Color.FromRgb(239, 239, 239));

	public IBrush IconColor { get; set; } = new SolidColorBrush(Color.FromRgb(byte.MaxValue, byte.MaxValue, byte.MaxValue));

	public IBrush ProgressBarBackground { get; set; } = new SolidColorBrush(Color.FromRgb(86, 86, 86));

	public bool VersionTextVisible => !CancelEnabled;

	public string VersionText { get; init; } = version;
}
