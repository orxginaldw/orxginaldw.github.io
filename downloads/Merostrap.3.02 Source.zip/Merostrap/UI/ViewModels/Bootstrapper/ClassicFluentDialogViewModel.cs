using System;

namespace Merostrap.UI.ViewModels.Bootstrapper;

internal class ClassicFluentDialogViewModel : BootstrapperDialogViewModel
{
	public static double FooterOpacity
	{
		get
		{
			if (!OperatingSystem.IsWindows() || Environment.OSVersion.Version.Build < 22000)
			{
				return 1.0;
			}
			return 0.4;
		}
	}

	public ClassicFluentDialogViewModel(IBootstrapperDialog dialog)
		: base(dialog)
	{
	}
}
