using System;
using System.Windows.Input;
using Avalonia.Media;
using CommunityToolkit.Mvvm.Input;
using Merostrap.Enums.BootstrapperDialogs;
using Merostrap.Extensions;
using Merostrap.Resources;

namespace Merostrap.UI.ViewModels.Bootstrapper;

internal class BootstrapperDialogViewModel : NotifyPropertyChangedViewModel
{
	private readonly IBootstrapperDialog _dialog;

	private string _cancelButtonText = Strings.Common_Cancel;

	public ICommand CancelInstallCommand => new RelayCommand(CancelInstall);

	public static string Title => App.Settings.Prop.BootstrapperTitle;

	public IImage? Icon { get; set; } = App.Settings.Prop.BootstrapperIcon.GetIcon()?.GetImageSource();

	public string Message { get; set; } = "Please wait...";

	public bool ProgressIndeterminate { get; set; } = true;

	public int ProgressMaximum { get; set; }

	public int ProgressValue { get; set; }

	public TaskbarItemProgressState TaskbarProgressState { get; set; } = TaskbarItemProgressState.Indeterminate;

	public double TaskbarProgressValue { get; set; }

	public bool CancelEnabled { get; set; }

	public bool CancelButtonVisible => CancelEnabled;

	public string CancelButtonText
	{
		get
		{
			return _cancelButtonText;
		}
		set
		{
			_cancelButtonText = value;
			OnPropertyChanged("CancelButtonText");
		}
	}

	[Obsolete("Do not use this! This is for the designer only.", true)]
	public BootstrapperDialogViewModel()
	{
		_dialog = null;
	}

	public BootstrapperDialogViewModel(IBootstrapperDialog dialog)
	{
		_dialog = dialog;
	}

	private void CancelInstall()
	{
		Merostrap.Bootstrapper? bootstrapper = _dialog.Bootstrapper;
		if (bootstrapper == null || !bootstrapper.Cancel())
		{
			_dialog.CloseBootstrapper();
		}
	}
}
