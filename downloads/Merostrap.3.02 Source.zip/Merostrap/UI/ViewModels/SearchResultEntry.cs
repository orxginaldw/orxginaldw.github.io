using Merostrap.Models;

namespace Merostrap.UI.ViewModels;

internal class SearchResultEntry
{
	public required SearchBarItem Item { get; init; }

	public required bool IsLastInGroup { get; init; }

	public string Connector
	{
		get
		{
			if (!IsLastInGroup)
			{
				return "├";
			}
			return "└";
		}
	}

	public string DisplayName => Item.DisplayName;

	public string Description => Item.Description ?? string.Empty;

	public bool HasDescription => !string.IsNullOrEmpty(Item.Description);
}
