using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Avalonia.Threading;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using LucideAvalonia.Enum;
using Merostrap.Models;

namespace Merostrap.UI.ViewModels;

internal class SearchBarViewModel : ObservableObject, IDisposable
{
	private string _searchQuery = string.Empty;

	private CancellationTokenSource? _debounceCts;

	private bool _isDropDownOpen;

	private bool _disposed;

	private bool _isIndexing;

	private ObservableCollection<SearchBarItem> _filteredSearchResults = new ObservableCollection<SearchBarItem>();

	private ObservableCollection<SearchResultGroup> _groupedSearchResults = new ObservableCollection<SearchResultGroup>();

	private List<SearchBarItem> _searchIndex = new List<SearchBarItem>();

	public string SearchQuery
	{
		get
		{
			return _searchQuery;
		}
		set
		{
			if (!SetProperty(ref _searchQuery, value, "SearchQuery"))
			{
				return;
			}
			_debounceCts?.Cancel();
			_debounceCts = new CancellationTokenSource();
			CancellationToken token = _debounceCts.Token;
			Task.Run(async () =>
			{
				await Task.Delay(150, token);
				if (!token.IsCancellationRequested)
				{
					FilterSearchResults();
				}
			}, token);
		}
	}

	public bool IsDropDownOpen
	{
		get
		{
			return _isDropDownOpen;
		}
		set
		{
			SetProperty(ref _isDropDownOpen, value, "IsDropDownOpen");
		}
	}

	public bool IsIndexing
	{
		get
		{
			return _isIndexing;
		}
		set
		{
			if (SetProperty(ref _isIndexing, value, "IsIndexing"))
			{
				OnPropertyChanged("ShowEmptyState");
				OnPropertyChanged("ShowNoResults");
				OnPropertyChanged("ShowResults");
			}
		}
	}

	public ObservableCollection<SearchBarItem> FilteredSearchResults
	{
		get
		{
			return _filteredSearchResults;
		}
		private set
		{
			SetProperty(ref _filteredSearchResults, value, "FilteredSearchResults");
			IsDropDownOpen = !string.IsNullOrWhiteSpace(SearchQuery) && value.Count > 0;
		}
	}

	public ObservableCollection<SearchResultGroup> GroupedSearchResults
	{
		get
		{
			return _groupedSearchResults;
		}
		private set
		{
			SetProperty(ref _groupedSearchResults, value, "GroupedSearchResults");
			OnPropertyChanged("HasResults");
			OnPropertyChanged("ResultsCountText");
			OnPropertyChanged("ShowNoResults");
			OnPropertyChanged("ShowResults");
		}
	}

	public bool HasResults => GroupedSearchResults.Count > 0;

	public bool HasQuery => !string.IsNullOrWhiteSpace(SearchQuery);

	public bool ShowEmptyState
	{
		get
		{
			if (!HasQuery)
			{
				return !IsIndexing;
			}
			return false;
		}
	}

	public bool ShowNoResults
	{
		get
		{
			if (HasQuery && !HasResults)
			{
				return !IsIndexing;
			}
			return false;
		}
	}

	public bool ShowResults
	{
		get
		{
			if (HasResults)
			{
				return !IsIndexing;
			}
			return false;
		}
	}

	public string ResultsCountText
	{
		get
		{
			if (!HasQuery)
			{
				return string.Empty;
			}
			int num = _searchIndex.Count((SearchBarItem item) => item.DisplayName.Contains(SearchQuery, StringComparison.OrdinalIgnoreCase));
			string value = ((num == 1) ? "result" : "results");
			return $"{num} {value} for {SearchQuery}";
		}
	}

	public IRelayCommand<SearchBarItem> SearchResultSelectedCommand { get; }

	public IRelayCommand ClearSearchCommand { get; }

	public event EventHandler<SearchBarItem>? SearchResultSelected;

	public SearchBarViewModel()
	{
		SearchResultSelectedCommand = new RelayCommand<SearchBarItem>(HandleSearchResultSelected);
		ClearSearchCommand = new RelayCommand(Clear);
	}

	public void SetSearchIndex(List<SearchBarItem> searchIndex)
	{
		_searchIndex = searchIndex ?? new List<SearchBarItem>();
		FilterSearchResults();
	}

	public List<SearchBarItem> GetSearchIndex()
	{
		return _searchIndex;
	}

	public void RefreshSearchResults()
	{
		FilterSearchResults();
	}

	private void FilterSearchResults()
	{
		string query = SearchQuery;
		if (string.IsNullOrWhiteSpace(query))
		{
			Dispatcher.UIThread.Post(() =>
			{
				FilteredSearchResults.Clear();
				GroupedSearchResults.Clear();
				IsDropDownOpen = false;
				OnPropertyChanged("ResultsCountText");
				OnPropertyChanged("ShowEmptyState");
				OnPropertyChanged("ShowNoResults");
				OnPropertyChanged("ShowResults");
			});
			return;
		}
		List<SearchBarItem> filtered = _searchIndex.Where((SearchBarItem item) => item.DisplayName.Contains(query, StringComparison.OrdinalIgnoreCase)).ToList();
		List<SearchResultGroup> groups = (from item in filtered
			group item by item.PageName ?? "Other").Select((IGrouping<string, SearchBarItem> g) =>
		{
			List<SearchBarItem> items = g.ToList();
			return new SearchResultGroup
			{
				PageName = g.Key,
				IconSymbol = (g.First().IconSymbol ?? LucideIconNames.CircleQuestionMark),
				Items = new ObservableCollection<SearchResultEntry>(items.Select((SearchBarItem item, int i) => new SearchResultEntry
				{
					Item = item,
					IsLastInGroup = (i == items.Count - 1)
				}))
			};
		}).ToList();
		Dispatcher.UIThread.Post(() =>
		{
			FilteredSearchResults = new ObservableCollection<SearchBarItem>(filtered);
			GroupedSearchResults = new ObservableCollection<SearchResultGroup>(groups);
			IsDropDownOpen = filtered.Count > 0;
			OnPropertyChanged("ResultsCountText");
			OnPropertyChanged("ShowEmptyState");
			OnPropertyChanged("ShowNoResults");
			OnPropertyChanged("ShowResults");
		});
	}

	private void HandleSearchResultSelected(SearchBarItem? item)
	{
		if (item != null)
		{
			SearchQuery = string.Empty;
			IsDropDownOpen = false;
			SearchResultSelected?.Invoke(this, item);
		}
	}

	public void Clear()
	{
		SearchQuery = string.Empty;
		Dispatcher.UIThread.Post(() =>
		{
			FilteredSearchResults.Clear();
			GroupedSearchResults.Clear();
			IsDropDownOpen = false;
		});
	}

	public void Dispose()
	{
		Dispose(disposing: true);
		GC.SuppressFinalize(this);
	}

	protected virtual void Dispose(bool disposing)
	{
		if (!_disposed)
		{
			if (disposing)
			{
				_debounceCts?.Cancel();
				_debounceCts?.Dispose();
				_debounceCts = null;
			}
			_disposed = true;
		}
	}
}
