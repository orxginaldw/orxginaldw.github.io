using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Input;
using Avalonia.Threading;
using CommunityToolkit.Mvvm.Input;
using Merostrap.Integrations.AccountManager;
using Merostrap.Models.APIs.Roblox;
using Merostrap.Utility;

namespace Merostrap.UI.ViewModels.Dialogs;

internal class PrivateServerJoinDialogViewModel : NotifyPropertyChangedViewModel
{
	private readonly long _placeId;

	private bool _isLoading;

	private bool _isEmpty;

	private ObservableCollection<PrivateServerInfo> _servers = new ObservableCollection<PrivateServerInfo>();

	public ObservableCollection<PrivateServerInfo> Servers
	{
		get
		{
			return _servers;
		}
		private set
		{
			SetProperty(ref _servers, value, "Servers");
		}
	}

	public bool IsLoading
	{
		get
		{
			return _isLoading;
		}
		private set
		{
			SetProperty(ref _isLoading, value, "IsLoading");
		}
	}

	public bool IsEmpty
	{
		get
		{
			return _isEmpty;
		}
		private set
		{
			SetProperty(ref _isEmpty, value, "IsEmpty");
		}
	}

	public ICommand JoinPrivateServerCommand { get; }

	public PrivateServerJoinDialogViewModel(long placeId)
	{
		_placeId = placeId;
		JoinPrivateServerCommand = new RelayCommand<string>(OnJoinPrivateServer);
		LoadAsync();
	}

	private async Task LoadAsync()
	{
		if (_placeId == 0L)
		{
			return;
		}
		AccountManager accountManager = AccountManager.Shared;
		if (accountManager?.ActiveAccount == null)
		{
			await Dispatcher.UIThread.InvokeAsync(() => IsEmpty = true);
			return;
		}
		string roblosecurityForUser = accountManager.GetRoblosecurityForUser(accountManager.ActiveAccount.UserId);
		if (!string.IsNullOrEmpty(roblosecurityForUser))
		{
			IsLoading = true;
			try
			{
				try
				{
					Uri requestUri = UrlBuilder.BuildApiUrl("games", $"v1/games/{_placeId}/private-servers?excludeFriendServers=false&sortOrder=Asc");
					using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, requestUri);
					request.Headers.Add("Cookie", ".ROBLOSECURITY=" + roblosecurityForUser);
					request.Headers.Add("Origin", "https://www.roblox.com");
					request.Headers.Add("Referrer", "https://www.roblox.com");
					PrivateServersResponse response = await Http.SendJson<PrivateServersResponse>(request);
					if (response?.Data == null || response.Data.Count == 0)
					{
						await Dispatcher.UIThread.InvokeAsync(() => IsEmpty = true);
						return;
					}
					List<long> list = (from s in response.Data
						select s.Owner.Id into id
						where id != 0
						select id).Distinct().ToList();
					Dictionary<long, string> dictionary = new Dictionary<long, string>();
					if (list.Count > 0)
					{
						dictionary = await accountManager.GetAvatarUrlsBulkAsync(list);
					}
					List<PrivateServerInfo> servers = new List<PrivateServerInfo>();
					foreach (PrivateServerData datum in response.Data)
					{
						servers.Add(new PrivateServerInfo(datum.VipServerId, datum.AccessCode, datum.Name, datum.Owner.Id, datum.Owner.Name, dictionary.GetValueOrDefault(datum.Owner.Id), datum.MaxPlayers, datum.Players.Count));
					}
					await Dispatcher.UIThread.InvokeAsync(() =>
					{
						Servers = new ObservableCollection<PrivateServerInfo>(servers);
						IsEmpty = servers.Count == 0;
					});
				}
				catch (Exception ex)
				{
					App.Logger.Error("Private server fetch failed: " + ex.Message);
					await Dispatcher.UIThread.InvokeAsync(() => IsEmpty = true);
				}
				return;
			}
			finally
			{
				IsLoading = false;
			}
		}
		await Dispatcher.UIThread.InvokeAsync(() => IsEmpty = true);
	}

	private void OnJoinPrivateServer(string? accessCode)
	{
		if (!string.IsNullOrWhiteSpace(accessCode))
		{
			Launch(_placeId, null, accessCode);
		}
	}

	private static void Launch(long placeId, string? jobId = null, string? accessCode = null)
	{
		if (placeId != 0L)
		{
			string text = $"roblox://experiences/start?placeId={placeId}";
			if (!string.IsNullOrEmpty(accessCode))
			{
				text = text + "&accessCode=" + Uri.EscapeDataString(accessCode);
			}
			else if (!string.IsNullOrEmpty(jobId))
			{
				text = text + "&gameInstanceId=" + Uri.EscapeDataString(jobId);
			}
			Process.Start(new ProcessStartInfo(text)
			{
				UseShellExecute = true
			});
		}
	}
}
