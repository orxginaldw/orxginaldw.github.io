using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;
using Avalonia.Media.Imaging;
using Avalonia.Threading;
using CommunityToolkit.Mvvm.Input;
using Merostrap.Enums;
using Merostrap.Integrations;
using Merostrap.Models;
using Merostrap.Models.APIs.Roblox;
using Merostrap.Models.Entities;
using Merostrap.Resources;
using Merostrap.Utility;

namespace Merostrap.UI.ViewModels.Dialogs;

internal class RobloxServersDialogViewModel : NotifyPropertyChangedViewModel, IDisposable
{
	private readonly long _placeId;

	private readonly long _universeId;

	private readonly bool _isTracked;

	private static readonly JsonSerializerOptions _historyLoadOptions = new JsonSerializerOptions
	{
		PropertyNameCaseInsensitive = true
	};

	private bool _isLoading;

	private bool _isCurrentGameApi;

	private bool _disposed;

	private ObservableCollection<ServerInfo> _servers = new ObservableCollection<ServerInfo>();

	public UniverseDetails? UniverseDetails { get; }

	public string GameName { get; }

	public string? GameThumbnailUrl { get; }

	public bool IsCurrentGameApi
	{
		get
		{
			return _isCurrentGameApi;
		}
		private set
		{
			if (SetProperty(ref _isCurrentGameApi, value, "IsCurrentGameApi"))
			{
				OnPropertyChanged("IsTrackedGame");
			}
		}
	}

	public bool IsTrackedGame => !IsCurrentGameApi;

	public ObservableCollection<ServerInfo> Servers
	{
		get
		{
			return _servers;
		}
		private set
		{
			SetProperty(ref _servers, value, "Servers");
		}
	}

	public bool IsLoading
	{
		get
		{
			return _isLoading;
		}
		private set
		{
			SetProperty(ref _isLoading, value, "IsLoading");
		}
	}

	public ICommand RejoinServerCommand { get; }

	public RobloxServersDialogViewModel(long placeId, long universeId, UniverseDetails? details, bool isTracked)
	{
		_placeId = placeId;
		_universeId = universeId;
		_isTracked = isTracked;
		UniverseDetails = details;
		GameName = details?.Data?.Name ?? Strings.Menu_QuickPlay_UnknownGame;
		GameThumbnailUrl = details?.Thumbnail?.ImageUrl;
		IsCurrentGameApi = !isTracked;
		RejoinServerCommand = new RelayCommand<object>(OnRejoinServer);
		LoadAsync();
	}

	private async Task LoadAsync()
	{
		IsLoading = true;
		try
		{
			if (_isTracked)
			{
				await LoadTrackedServersAsync();
			}
			else
			{
				await LoadApiServersAsync();
			}
		}
		catch (Exception ex)
		{
			App.Logger.Error("Failed to load servers: " + ex.Message);
		}
		finally
		{
			IsLoading = false;
		}
	}

	private async Task LoadTrackedServersAsync()
	{
		string cachePath = Path.Combine(Paths.Cache, "GameHistory.json");
		if (!File.Exists(cachePath))
		{
			return;
		}
		GameHistoryEntry gameHistoryEntry = (await Task.Run(() =>
		{
			try
			{
				return JsonSerializer.Deserialize<List<GameHistoryEntry>>(File.ReadAllText(cachePath), _historyLoadOptions) ?? new List<GameHistoryEntry>();
			}
			catch
			{
				return new List<GameHistoryEntry>();
			}
		})).FirstOrDefault((GameHistoryEntry x) => x.UniverseId == _universeId);
		if (gameHistoryEntry == null)
		{
			return;
		}
		List<ServerInfo> sorted = gameHistoryEntry.Servers.OrderByDescending((ServerInfo x) => x.JoinedAt).ToList();
		foreach (ServerInfo item in sorted)
		{
			item.IsLatest = false;
		}
		if (sorted.Count > 0)
		{
			sorted[0].IsLatest = true;
		}
		await Dispatcher.UIThread.InvokeAsync(() =>
		{
			Servers = new ObservableCollection<ServerInfo>(sorted);
		});
	}

	private async Task LoadApiServersAsync()
	{
		using RobloxServerFetcher fetcher = new RobloxServerFetcher();
		FetchResult fetchResult = await fetcher.FetchServerInstancesAsync(_placeId, "", null, 15);
		if (fetchResult.Servers == null || fetchResult.Servers.Count == 0)
		{
			return;
		}
		List<ServerInfo> servers = new List<ServerInfo>(fetchResult.Servers.Count);
		foreach (ServerInstance server in fetchResult.Servers)
		{
			if (string.IsNullOrEmpty(server.Region) || server.Region.Equals("Unknown", StringComparison.OrdinalIgnoreCase))
			{
				continue;
			}
			ServerInfo serverInfo = new ServerInfo
			{
				JobId = server.Id,
				Region = server.Region,
				JoinedAt = (server.FirstSeen ?? DateTime.UtcNow),
				IsLatest = false,
				Playing = server.Playing,
				MaxPlayers = server.MaxPlayers,
				Uptime = server.UptimeDisplay
			};
			List<string> playerTokens = server.PlayerTokens;
			if (playerTokens != null && playerTokens.Count > 0)
			{
				foreach (string playerToken in server.PlayerTokens)
				{
					serverInfo.PlayerTokens.Add(playerToken);
				}
			}
			servers.Add(serverInfo);
		}
		await LoadPlayerThumbnailsAsync(servers);
		servers = servers.OrderByDescending((ServerInfo s) => s.JoinedAt).ToList();
		await Dispatcher.UIThread.InvokeAsync(() =>
		{
			Servers = new ObservableCollection<ServerInfo>(servers);
		});
	}

	private static async Task LoadPlayerThumbnailsAsync(List<ServerInfo> servers)
	{
		List<string> list = (from t in servers.SelectMany((ServerInfo s) => s.PlayerTokens)
			where !string.IsNullOrEmpty(t)
			select t).Distinct().ToList();
		if (list.Count == 0)
		{
			return;
		}
		Dictionary<string, string?> tokenToUrl = new Dictionary<string, string>();
		List<List<string>> list2 = (from x in list.Select((string t, int i) => new
			{
				Token = t,
				Index = i
			})
			group x by x.Index / 100 into g
			select g.Select(x => x.Token).ToList()).ToList();
		foreach (List<string> chunk in list2)
		{
			string[] array = await Thumbnails.GetThumbnailUrlsAsync(chunk.Select((string token) => new ThumbnailRequest
			{
				Token = token,
				Type = ThumbnailType.AvatarHeadShot,
				Size = ThumbnailSize.Medium,
				Format = ThumbnailFormat.Png,
				IsCircular = true
			}).ToList(), CancellationToken.None);
			for (int num = 0; num < chunk.Count && num < array.Length; num++)
			{
				tokenToUrl[chunk[num]] = array[num];
			}
		}
		SemaphoreSlim semaphore = new SemaphoreSlim(15);
		try
		{
			await Task.WhenAll(((IEnumerable<ServerInfo>)servers).Select((Func<ServerInfo, Task>)(async (ServerInfo server) =>
			{
				await semaphore.WaitAsync();
				try
				{
					List<Bitmap> bitmaps = new List<Bitmap>();
					foreach (string playerToken in server.PlayerTokens)
					{
						if (tokenToUrl.TryGetValue(playerToken, out string value) && !string.IsNullOrEmpty(value))
						{
							try
							{
								using MemoryStream stream = new MemoryStream(await App.HttpClient.GetByteArrayAsync(new Uri(value)));
								bitmaps.Add(Bitmap.DecodeToWidth(stream, 32, BitmapInterpolationMode.LowQuality));
							}
							catch
							{
							}
						}
					}
					await Dispatcher.UIThread.InvokeAsync(() =>
					{
						server.PlayerAvatarThumbnails.Clear();
						foreach (Bitmap item in bitmaps)
						{
							server.PlayerAvatarThumbnails.Add(item);
						}
						int num2 = server.Playing - bitmaps.Count;
						if (num2 > 0)
						{
							server.ExtraPlayersText = $"+{num2}";
							server.HasExtraPlayers = true;
						}
						else
						{
							server.HasExtraPlayers = false;
						}
					}, DispatcherPriority.Background);
				}
				finally
				{
					semaphore.Release();
				}
			})));
		}
		finally
		{
			if (semaphore != null)
			{
				((IDisposable)semaphore).Dispose();
			}
		}
	}

	private void OnRejoinServer(object? param)
	{
		if (param is ServerInfo serverInfo)
		{
			Launch(_placeId, serverInfo.JobId);
		}
	}

	private static void Launch(long placeId, string? jobId = null, string? accessCode = null)
	{
		if (placeId != 0L)
		{
			string text = $"roblox://experiences/start?placeId={placeId}";
			if (!string.IsNullOrEmpty(accessCode))
			{
				text = text + "&accessCode=" + Uri.EscapeDataString(accessCode);
			}
			else if (!string.IsNullOrEmpty(jobId))
			{
				text = text + "&gameInstanceId=" + Uri.EscapeDataString(jobId);
			}
			Process.Start(new ProcessStartInfo(text)
			{
				UseShellExecute = true
			});
		}
	}

	public void Dispose()
	{
		Dispose(disposing: true);
		GC.SuppressFinalize(this);
	}

	protected virtual void Dispose(bool disposing)
	{
		if (_disposed)
		{
			return;
		}
		if (disposing)
		{
			foreach (ServerInfo server in _servers)
			{
				foreach (Bitmap playerAvatarThumbnail in server.PlayerAvatarThumbnails)
				{
					playerAvatarThumbnail.Dispose();
				}
			}
		}
		_disposed = true;
	}
}
