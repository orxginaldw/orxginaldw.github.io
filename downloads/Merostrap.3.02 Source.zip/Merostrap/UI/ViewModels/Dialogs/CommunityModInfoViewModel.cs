using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Media;
using Avalonia.Threading;
using CommunityToolkit.Mvvm.Input;
using Merostrap.Models;
using Merostrap.Models.APIs.Config;
using Merostrap.UI.Elements.Base;

namespace Merostrap.UI.ViewModels.Dialogs;

internal class CommunityModInfoViewModel(CommunityMod mod, AvaloniaWindow window) : NotifyPropertyChangedViewModel
{
	private string _colorDisplayText = string.Empty;

	private CommunityMod _mod = mod;

	private bool _isLoadingGlyphs;

	private ObservableCollection<GlyphItem> _glyphItems = new ObservableCollection<GlyphItem>();

	private SolidColorBrush _previewBrush = new SolidColorBrush(Colors.White);

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.4.0.0")]
	private RelayCommand? closeCommand;

	public string ColorDisplayText
	{
		get
		{
			return _colorDisplayText;
		}
		set
		{
			SetProperty(ref _colorDisplayText, value, "ColorDisplayText");
		}
	}

	public CommunityMod Mod
	{
		get
		{
			return _mod;
		}
		set
		{
			SetProperty(ref _mod, value, "Mod");
		}
	}

	public bool IsLoadingGlyphs
	{
		get
		{
			return _isLoadingGlyphs;
		}
		set
		{
			SetProperty(ref _isLoadingGlyphs, value, "IsLoadingGlyphs");
		}
	}

	public ObservableCollection<GlyphItem> GlyphItems
	{
		get
		{
			return _glyphItems;
		}
		set
		{
			SetProperty(ref _glyphItems, value, "GlyphItems");
		}
	}

	public SolidColorBrush PreviewBrush
	{
		get
		{
			return _previewBrush;
		}
		set
		{
			SetProperty(ref _previewBrush, value, "PreviewBrush");
		}
	}

	public bool IsGradientMode
	{
		get
		{
			List<Merostrap.Models.APIs.Config.GradientStop>? gradientStops = Mod.GradientStops;
			if (gradientStops == null)
			{
				return false;
			}
			return gradientStops.Count >= 2;
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.4.0.0")]
	[ExcludeFromCodeCoverage]
	public IRelayCommand CloseCommand => closeCommand ?? (closeCommand = new RelayCommand(Close));

	public void Initialize()
	{
		if (Mod.IsColorMod)
		{
			InitializePreviewAsync();
		}
	}

	[RelayCommand]
	private void Close()
	{
		window.Close();
	}

	private async Task InitializePreviewAsync()
	{
		try
		{
			Avalonia.Media.FontFamily fontFamily = new Avalonia.Media.FontFamily("avares://Merostrap/Resources/Fonts#BuilderIcons-Regular");
			Typeface typeface = new Typeface(fontFamily);
			UpdateGlyphColors();
			await LoadGlyphPreviewsAsync(typeface);
		}
		catch (Exception ex)
		{
			App.Logger.Error("Preview initialization failed: " + ex.Message);
		}
	}

	private void UpdateGlyphColors()
	{
		if (IsGradientMode)
		{
			List<Merostrap.Models.APIs.Config.GradientStop> gradientStops = Mod.GradientStops;
			ColorDisplayText = string.Join(" → ", gradientStops.Select((Merostrap.Models.APIs.Config.GradientStop s) => s.Color.ToUpperInvariant()));
			if (gradientStops.Count > 0 && Color.TryParse(gradientStops[0].Color, out var color))
			{
				PreviewBrush = new SolidColorBrush(color);
			}
			else
			{
				PreviewBrush = new SolidColorBrush(Colors.White);
			}
		}
		else
		{
			ColorDisplayText = "No color information";
			PreviewBrush = new SolidColorBrush(Colors.White);
		}
	}

	private IBrush CreateGradientBrush()
	{
		if (!IsGradientMode || Mod.GradientStops == null || Mod.GradientStops.Count < 2)
		{
			return PreviewBrush;
		}
		List<Merostrap.Models.APIs.Config.GradientStop> list = Mod.GradientStops.OrderBy((Merostrap.Models.APIs.Config.GradientStop s) => s.Offset).ToList();
		Avalonia.Media.GradientStops gradientStops = new Avalonia.Media.GradientStops();
		foreach (Merostrap.Models.APIs.Config.GradientStop item in list)
		{
			if (Color.TryParse(item.Color, out var color))
			{
				gradientStops.Add(new Avalonia.Media.GradientStop(color, item.Offset));
			}
		}
		if (gradientStops.Count < 2)
		{
			return PreviewBrush;
		}
		LinearGradientBrush linearGradientBrush = new LinearGradientBrush
		{
			GradientStops = gradientStops
		};
		double num = (Mod.GradientAngle ?? 90.0) * Math.PI / 180.0;
		double num2 = Math.Sin(num);
		double num3 = 0.0 - Math.Cos(num);
		double num4 = Math.Sqrt(num2 * num2 + num3 * num3);
		if (num4 > 0.0)
		{
			num2 /= num4;
			num3 /= num4;
		}
		linearGradientBrush.StartPoint = new RelativePoint(0.5 - num2 / 2.0, 0.5 - num3 / 2.0, RelativeUnit.Relative);
		linearGradientBrush.EndPoint = new RelativePoint(0.5 + num2 / 2.0, 0.5 + num3 / 2.0, RelativeUnit.Relative);
		return linearGradientBrush;
	}

	private async Task LoadGlyphPreviewsAsync(Typeface typeface)
	{
		IsLoadingGlyphs = true;
		ObservableCollection<GlyphItem> newItems = new ObservableCollection<GlyphItem>();
		try
		{
			IBrush brush;
			if (!IsGradientMode)
			{
				IBrush previewBrush = PreviewBrush;
				brush = previewBrush;
			}
			else
			{
				brush = CreateGradientBrush();
			}
			IBrush glyphBrush = brush;
			IEnumerable<int> enumerable = Enumerable.Range(61697, 50);
			foreach (int item in enumerable)
			{
				string text = char.ConvertFromUtf32(item);
				await Dispatcher.UIThread.InvokeAsync(() =>
				{
					try
					{
						Geometry geometry = new FormattedText(text, CultureInfo.CurrentCulture, FlowDirection.LeftToRight, typeface, 40.0, PreviewBrush).BuildGeometry(new Point(0.0, 0.0));
						if (geometry != null && !(geometry.Bounds.Width < 1.0))
						{
							Rect bounds = geometry.Bounds;
							TranslateTransform transform = new TranslateTransform((50.0 - bounds.Width) / 2.0 - bounds.X, (50.0 - bounds.Height) / 2.0 - bounds.Y);
							geometry.Transform = transform;
							newItems.Add(new GlyphItem
							{
								Data = geometry,
								Brush = glyphBrush
							});
						}
					}
					catch
					{
					}
				});
			}
			GlyphItems = newItems;
		}
		catch (Exception ex)
		{
			App.Logger.Error("Glyph loading error: " + ex.Message);
		}
		finally
		{
			IsLoadingGlyphs = false;
		}
	}
}
