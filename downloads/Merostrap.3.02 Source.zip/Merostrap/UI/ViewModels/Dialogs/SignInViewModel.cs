using System;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.Input;
using Merostrap.Access;
using Merostrap.Resources;

namespace Merostrap.UI.ViewModels.Dialogs;

internal sealed class SignInViewModel : NotifyPropertyChangedViewModel, IDisposable
{
	[StructLayout(LayoutKind.Auto)]
	[CompilerGenerated]
	private struct _003CSubmitAsync_003Ed__30 : IAsyncStateMachine
	{
		public int _003C_003E1__state;

		public AsyncTaskMethodBuilder _003C_003Et__builder;

		public SignInViewModel _003C_003E4__this;

		private TaskAwaiter _003C_003Eu__1;

		private void MoveNext()
		{
			int num = _003C_003E1__state;
			SignInViewModel signInViewModel = _003C_003E4__this;
			try
			{
				if (num == 0)
				{
					goto IL_004e;
				}
				signInViewModel.Message = "";
				if (!string.IsNullOrWhiteSpace(signInViewModel.Username) && !string.IsNullOrEmpty(signInViewModel.Password))
				{
					signInViewModel.IsBusy = true;
					goto IL_004e;
				}
				signInViewModel.Message = WelcomeStrings.MissingFields;
				goto end_IL_000e;
				IL_004e:
				try
				{
					TaskAwaiter awaiter;
					if (num != 0)
					{
						awaiter = AccessClient.SignInAsync(signInViewModel.Username.Trim(), signInViewModel.Password, signInViewModel._lifetime.Token).GetAwaiter();
						if (!awaiter.IsCompleted)
						{
							num = (_003C_003E1__state = 0);
							_003C_003Eu__1 = awaiter;
							_003C_003Et__builder.AwaitUnsafeOnCompleted(ref awaiter, ref this);
							return;
						}
					}
					else
					{
						awaiter = _003C_003Eu__1;
						_003C_003Eu__1 = default;
						num = (_003C_003E1__state = -1);
					}
					awaiter.GetResult();
					signInViewModel.Password = "";
					signInViewModel.SignedIn?.Invoke(signInViewModel, EventArgs.Empty);
				}
				catch (AccessException ex)
				{
					signInViewModel.Message = ex.Message switch
					{
						"not_configured" => WelcomeStrings.NotConfigured, 
						"invalid_credentials" => WelcomeStrings.InvalidCredentials, 
						"device_mismatch" => WelcomeStrings.DeviceMismatch, 
						"access_denied" => WelcomeStrings.AccountUnavailable, 
						"rate_limited" => WelcomeStrings.RateLimited, 
						_ => WelcomeStrings.Unavailable, 
					};
				}
				catch (OperationCanceledException)
				{
					if (!signInViewModel._lifetime.IsCancellationRequested)
					{
						App.Logger.Warn("Sign-in failed: request timed out.");
						signInViewModel.Message = WelcomeStrings.Unavailable + " (Timeout)";
					}
				}
				catch (HttpRequestException ex3)
				{
					App.Logger.Warn($"Sign-in failed: {ex3.HttpRequestError}.");
					signInViewModel.Message = WelcomeStrings.Unavailable + $" ({ex3.HttpRequestError})";
				}
				catch (JsonException)
				{
					App.Logger.Warn("Sign-in failed: invalid service response.");
					signInViewModel.Message = WelcomeStrings.Unavailable + " (InvalidResponse)";
				}
				catch (Exception ex5) when ((ex5 is InvalidOperationException || ex5 is IOException || ex5 is UnauthorizedAccessException) ? true : false)
				{
					signInViewModel.Message = WelcomeStrings.DeviceUnavailable;
				}
				finally
				{
					if (num < 0)
					{
						signInViewModel.IsBusy = false;
					}
				}
				end_IL_000e:;
			}
			catch (Exception exception)
			{
				_003C_003E1__state = -2;
				_003C_003Et__builder.SetException(exception);
				return;
			}
			_003C_003E1__state = -2;
			_003C_003Et__builder.SetResult();
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		[DebuggerHidden]
		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			_003C_003Et__builder.SetStateMachine(stateMachine);
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}
	}

	private readonly CancellationTokenSource _lifetime = new CancellationTokenSource();

	private string _username = "";

	private string _password = "";

	private string _message = "";

	private bool _busy;

	public string Username
	{
		get
		{
			return _username;
		}
		set
		{
			if (SetProperty(ref _username, value, "Username"))
			{
				Message = "";
			}
		}
	}

	public string Password
	{
		get
		{
			return _password;
		}
		set
		{
			if (SetProperty(ref _password, value, "Password"))
			{
				Message = "";
			}
		}
	}

	public string Message
	{
		get
		{
			return _message;
		}
		private set
		{
			SetProperty(ref _message, value, "Message");
			OnPropertyChanged("HasMessage");
		}
	}

	public bool HasMessage => !string.IsNullOrEmpty(Message);

	public bool IsBusy
	{
		get
		{
			return _busy;
		}
		private set
		{
			SetProperty(ref _busy, value, "IsBusy");
			OnPropertyChanged("CanEdit");
			OnPropertyChanged("SubmitText");
		}
	}

	public bool CanEdit => false;

	public string SubmitText
	{
		get
		{
			if (!IsBusy)
			{
				return WelcomeStrings.SignIn;
			}
			return WelcomeStrings.Working;
		}
	}

	public IAsyncRelayCommand SubmitCommand { get; }

	public event EventHandler? SignedIn;

	public SignInViewModel()
	{
		SubmitCommand = new AsyncRelayCommand(SubmitAsync);
	}

	[AsyncStateMachine(typeof(_003CSubmitAsync_003Ed__30))]
	private Task SubmitAsync()
	{
		return Task.CompletedTask;
	}

	public void Dispose()
	{
		_lifetime.Cancel();
		_lifetime.Dispose();
		Password = "";
	}
}
