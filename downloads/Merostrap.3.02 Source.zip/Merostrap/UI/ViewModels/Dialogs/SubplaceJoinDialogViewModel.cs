using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;
using Avalonia.Threading;
using CommunityToolkit.Mvvm.Input;
using Merostrap.Enums;
using Merostrap.Models;
using Merostrap.Models.APIs.Roblox;
using Merostrap.Utility;

namespace Merostrap.UI.ViewModels.Dialogs;

internal class SubplaceJoinDialogViewModel : NotifyPropertyChangedViewModel
{
	private readonly long _universeId;

	private bool _isLoading;

	private ObservableCollection<PlaceInfo> _subplaces = new ObservableCollection<PlaceInfo>();

	public ObservableCollection<PlaceInfo> Subplaces
	{
		get
		{
			return _subplaces;
		}
		private set
		{
			SetProperty(ref _subplaces, value, "Subplaces");
		}
	}

	public bool IsLoading
	{
		get
		{
			return _isLoading;
		}
		private set
		{
			SetProperty(ref _isLoading, value, "IsLoading");
		}
	}

	public ICommand JoinSubplaceCommand { get; }

	public SubplaceJoinDialogViewModel(long universeId)
	{
		_universeId = universeId;
		JoinSubplaceCommand = new RelayCommand<PlaceInfo>(OnJoinSubplace);
		LoadAsync();
	}

	private async Task LoadAsync()
	{
		if (_universeId == 0L)
		{
			return;
		}
		IsLoading = true;
		try
		{
			SubplacesResponse subplacesResponse = await Http.GetJson<SubplacesResponse>(UrlBuilder.BuildApiUrl("develop", $"v1/universes/{_universeId}/places?isUniverseCreation=false&limit=100&sortOrder=Asc"));
			if (subplacesResponse?.Data == null || subplacesResponse.Data.Count == 0)
			{
				return;
			}
			List<PlaceInfo> tempSubplaces = subplacesResponse.Data.Select((SubplaceData place) => new PlaceInfo(place.Id, place.UniverseId, place.Name, "")).ToList();
			List<ThumbnailRequest> requests = tempSubplaces.Select((PlaceInfo p) => new ThumbnailRequest
			{
				TargetId = (ulong)p.Id,
				Type = ThumbnailType.PlaceIcon,
				Size = ThumbnailSize.Detailed,
				Format = ThumbnailFormat.Png
			}).ToList();
			try
			{
				string[] source = await Thumbnails.GetThumbnailUrlsAsync(requests, CancellationToken.None);
				for (int num = 0; num < tempSubplaces.Count; num++)
				{
					tempSubplaces[num].ThumbnailUrl = source.ElementAtOrDefault(num) ?? "";
				}
			}
			catch (Exception ex)
			{
				App.Logger.Error("Subplace thumbnail fetch failed: " + ex.Message);
			}
			await Dispatcher.UIThread.InvokeAsync(() =>
			{
				Subplaces = new ObservableCollection<PlaceInfo>(tempSubplaces);
			});
		}
		catch (Exception ex2)
		{
			App.Logger.Error("Subplace fetch failed: " + ex2.Message);
		}
		finally
		{
			IsLoading = false;
		}
	}

	private void OnJoinSubplace(PlaceInfo? subplace)
	{
		if (subplace != null)
		{
			Launch(subplace.Id);
		}
	}

	private static void Launch(long placeId, string? jobId = null, string? accessCode = null)
	{
		if (placeId != 0L)
		{
			string text = $"roblox://experiences/start?placeId={placeId}";
			if (!string.IsNullOrEmpty(accessCode))
			{
				text = text + "&accessCode=" + Uri.EscapeDataString(accessCode);
			}
			else if (!string.IsNullOrEmpty(jobId))
			{
				text = text + "&gameInstanceId=" + Uri.EscapeDataString(jobId);
			}
			Process.Start(new ProcessStartInfo(text)
			{
				UseShellExecute = true
			});
		}
	}
}
