namespace Merostrap.UI.ViewModels.Dialogs;

internal record PrivateServerInfo(long VipServerId, string AccessCode, string Name, long OwnerId, string OwnerName, string? OwnerAvatarUrl, int MaxPlayers, int CurrentPlayers);
