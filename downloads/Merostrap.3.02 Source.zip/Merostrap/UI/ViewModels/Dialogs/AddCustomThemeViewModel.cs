using System;
using Merostrap.Enums;

namespace Merostrap.UI.ViewModels.Dialogs;

internal class AddCustomThemeViewModel : NotifyPropertyChangedViewModel
{
	private CustomThemeTemplate _template = CustomThemeTemplate.Simple;

	private string _name = "";

	private string _filePath = "";

	private string _nameError = "";

	private string _fileError = "";

	public static CustomThemeTemplate[] Templates => Enum.GetValues<CustomThemeTemplate>();

	public CustomThemeTemplate Template
	{
		get
		{
			return _template;
		}
		set
		{
			SetProperty(ref _template, value, "Template");
		}
	}

	public string Name
	{
		get
		{
			return _name;
		}
		set
		{
			SetProperty(ref _name, value, "Name");
		}
	}

	public string FilePath
	{
		get
		{
			return _filePath;
		}
		set
		{
			if (SetProperty(ref _filePath, value, "FilePath"))
			{
				OnPropertyChanged("HasFilePath");
			}
		}
	}

	public bool HasFilePath => !string.IsNullOrEmpty(FilePath);

	public int SelectedTab { get; set; }

	public string NameError
	{
		get
		{
			return _nameError;
		}
		set
		{
			if (SetProperty(ref _nameError, value, "NameError"))
			{
				OnPropertyChanged("HasNameError");
			}
		}
	}

	public bool HasNameError => !string.IsNullOrEmpty(NameError);

	public string FileError
	{
		get
		{
			return _fileError;
		}
		set
		{
			if (SetProperty(ref _fileError, value, "FileError"))
			{
				OnPropertyChanged("HasFileError");
			}
		}
	}

	public bool HasFileError => !string.IsNullOrEmpty(FileError);
}
