using System;
using System.CodeDom.Compiler;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.Input;
using Merostrap.Enums.Messagebox;
using Merostrap.Models;
using Merostrap.Models.APIs.Roblox;
using Merostrap.Resources;
using Merostrap.UI.Elements.Base;
using Merostrap.Utility;

namespace Merostrap.UI.ViewModels.Dialogs;

internal class ManualCookieDialogViewModel(AvaloniaWindow window) : NotifyPropertyChangedViewModel
{
	private string _cookieInput = string.Empty;

	private bool _isValidating;

	private bool _isAddEnabled = true;

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.4.0.0")]
	private AsyncRelayCommand? addAccountCommand;

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.4.0.0")]
	private RelayCommand? cancelCommand;

	public string CookieInput
	{
		get
		{
			return _cookieInput;
		}
		set
		{
			SetProperty(ref _cookieInput, value, "CookieInput");
		}
	}

	public bool IsValidating
	{
		get
		{
			return _isValidating;
		}
		set
		{
			SetProperty(ref _isValidating, value, "IsValidating");
		}
	}

	public bool IsAddEnabled
	{
		get
		{
			return _isAddEnabled;
		}
		set
		{
			SetProperty(ref _isAddEnabled, value, "IsAddEnabled");
		}
	}

	public AccountManagerAccount? ValidatedAccount { get; private set; }

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.4.0.0")]
	[ExcludeFromCodeCoverage]
	public IAsyncRelayCommand AddAccountCommand => addAccountCommand ?? (addAccountCommand = new AsyncRelayCommand(AddAccountAsync));

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.4.0.0")]
	[ExcludeFromCodeCoverage]
	public IRelayCommand CancelCommand => cancelCommand ?? (cancelCommand = new RelayCommand(Cancel));

	[RelayCommand]
	private async Task AddAccountAsync()
	{
		if (string.IsNullOrWhiteSpace(CookieInput))
		{
			await Frontend.ShowMessageBox(Strings.Menu_ManualLogin_EnterCookie, MessageBoxImage.Warning);
			return;
		}
		IsValidating = true;
		IsAddEnabled = false;
		try
		{
			AccountManagerAccount accountManagerAccount = await GetAccountInfoFromCookieAsync(CookieInput);
			if (accountManagerAccount == null)
			{
				await Frontend.ShowMessageBox(Strings.Menu_ManualLogin_InvalidCookie, MessageBoxImage.Error);
				return;
			}
			ValidatedAccount = accountManagerAccount;
			window.Close(ValidatedAccount);
		}
		catch (Exception ex)
		{
			App.Logger.Error("Validation error: " + ex.Message);
			await Frontend.ShowMessageBox("Error validating cookie: " + ex.Message, MessageBoxImage.Error);
		}
		finally
		{
			IsValidating = false;
			IsAddEnabled = true;
		}
	}

	[RelayCommand]
	private void Cancel()
	{
		window.Close(null);
	}

	private static async Task<AccountManagerAccount?> GetAccountInfoFromCookieAsync(string cookie)
	{
		_ = 1;
		try
		{
			CookieContainer cookieContainer = new CookieContainer();
			using HttpClientHandler handler = new HttpClientHandler
			{
				CookieContainer = cookieContainer,
				CheckCertificateRevocationList = true
			};
			using HttpClient client = new HttpClient(handler);
			string rawValue = (cookie.Contains(".ROBLOSECURITY=", StringComparison.Ordinal) ? cookie.Split(".ROBLOSECURITY=")[1].Split(';')[0].Trim() : cookie.Trim());
			cookieContainer.Add(new Uri("https://roblox.com"), new Cookie(".ROBLOSECURITY", rawValue, "/", ".roblox.com"));
			HttpResponseMessage httpResponseMessage = await client.GetAsync(UrlBuilder.BuildApiUrl("users", "v1/users/authenticated"));
			if (!httpResponseMessage.IsSuccessStatusCode)
			{
				return null;
			}
			AuthenticatedUser authenticatedUser = await httpResponseMessage.Content.ReadFromJsonAsync<AuthenticatedUser>();
			if (authenticatedUser == null || authenticatedUser.Id <= 0)
			{
				return null;
			}
			return new AccountManagerAccount(rawValue, authenticatedUser.Id, authenticatedUser.Username, authenticatedUser.DisplayName);
		}
		catch (Exception ex)
		{
			App.Logger.Error("HTTP Error: " + ex.Message);
			return null;
		}
	}
}
