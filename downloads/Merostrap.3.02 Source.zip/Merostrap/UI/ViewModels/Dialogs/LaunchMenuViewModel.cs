using System;
using System.Windows.Input;
using CommunityToolkit.Mvvm.Input;
using Merostrap.Enums;

namespace Merostrap.UI.ViewModels.Dialogs;

internal class LaunchMenuViewModel : NotifyPropertyChangedViewModel
{
	public ICommand PlayCommand { get; }

	public ICommand StudioCommand { get; }

	public ICommand LaunchSettingsCommand { get; }

	public event EventHandler<NextAction>? CloseWindowRequest;

	public LaunchMenuViewModel()
	{
		PlayCommand = new RelayCommand(() =>
		{
			Launch(LaunchMode.Player, NextAction.LaunchRoblox);
		});
		StudioCommand = new RelayCommand(() =>
		{
			Launch(LaunchMode.Studio, NextAction.LaunchRobloxStudio);
		});
		LaunchSettingsCommand = new RelayCommand(() =>
		{
			CloseWindowRequest?.Invoke(this, NextAction.LaunchSettings);
		});
	}

	private void Launch(LaunchMode mode, NextAction action)
	{
		App.State.Prop.LastLaunchMode = mode;
		App.State.SaveSetting("LastLaunchMode");
		CloseWindowRequest?.Invoke(this, action);
	}
}
