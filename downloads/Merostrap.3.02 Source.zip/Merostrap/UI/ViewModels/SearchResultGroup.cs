using System.Collections.ObjectModel;
using LucideAvalonia.Enum;

namespace Merostrap.UI.ViewModels;

internal class SearchResultGroup
{
	public string PageName { get; init; } = string.Empty;

	public LucideIconNames IconSymbol { get; init; }

	public ObservableCollection<SearchResultEntry> Items { get; init; } = new ObservableCollection<SearchResultEntry>();
}
