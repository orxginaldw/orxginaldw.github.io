using System.Windows.Input;
using CommunityToolkit.Mvvm.Input;

namespace Merostrap.UI.ViewModels.Settings.FastFlags;

internal class FastFlagEditorViewModel
{
	private readonly MainWindowViewModel _mainWindowViewModel;

	public ICommand BackCommand { get; }

	public FastFlagEditorViewModel(MainWindowViewModel mainWindowViewModel)
	{
		_mainWindowViewModel = mainWindowViewModel;
		App.Logger.Debug("FastFlagEditorViewModel created.");
		BackCommand = new RelayCommand(() =>
		{
			_mainWindowViewModel?.NavigateToFastFlagsCommand.Execute(null);
		});
	}
}
