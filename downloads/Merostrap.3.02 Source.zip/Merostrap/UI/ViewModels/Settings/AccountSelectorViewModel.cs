using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using Avalonia.Controls;
using Avalonia.Media;
using Avalonia.Threading;
using CommunityToolkit.Mvvm.Input;
using Merostrap.Enums;
using Merostrap.Enums.Messagebox;
using Merostrap.Integrations.AccountManager;
using Merostrap.Models;
using Merostrap.Models.APIs.Roblox;
using Merostrap.Resources;
using Merostrap.UI.Elements.Dialogs;

namespace Merostrap.UI.ViewModels.Settings;

internal class AccountSelectorViewModel : NotifyPropertyChangedViewModel, IDisposable
{
	internal class AccountWithAvatar : NotifyPropertyChangedViewModel
	{
		private string _presenceStatus = "Unknown";

		private IBrush _presenceBrush = Brushes.Gray;

		public AccountManagerAccount Account { get; }

		public string? AvatarUrl { get; }

		public string Username => Account.Username;

		public string DisplayName => Account.DisplayName;

		public long UserId => Account.UserId;

		public string PresenceStatus
		{
			get
			{
				return _presenceStatus;
			}
			set
			{
				SetProperty(ref _presenceStatus, value, "PresenceStatus");
			}
		}

		public IBrush PresenceBrush
		{
			get
			{
				return _presenceBrush;
			}
			set
			{
				SetProperty(ref _presenceBrush, value, "PresenceBrush");
			}
		}

		public AccountWithAvatar(AccountManagerAccount account, string? avatarUrl)
		{
			Account = account;
			AvatarUrl = avatarUrl;
		}
	}

	private readonly AccountManager _accountManager;

	private readonly Dictionary<long, string?> _accountAvatarUrls = new Dictionary<long, string>();

	private DispatcherTimer? _presenceTimer;

	private UserPresence? _currentPresence;

	private const int PRESENCE_REFRESH_INTERVAL_MS = 20000;

	private AccountManagerAccount? _currentAccount;

	private string? _currentAccountAvatarUrl;

	private ObservableCollection<AccountWithAvatar> _accounts = new ObservableCollection<AccountWithAvatar>();

	private string _selectedAddMethod = Strings.Menu_AccountSelector_Login_LocalCookie;

	private bool _isDropdownOpen;

	private bool _isAddingAccount;

	private IBrush _presenceBrush = Brushes.Gray;

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.4.0.0")]
	private RelayCommand<AccountWithAvatar>? selectAccountCommand;

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.4.0.0")]
	private RelayCommand? toggleDropdownCommand;

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.4.0.0")]
	private RelayCommand<AccountWithAvatar>? deleteAccountCommand;

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.4.0.0")]
	private AsyncRelayCommand? addAccountCommand;

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.4.0.0")]
	private RelayCommand<AccountWithAvatar>? applyAccountCommand;

	public AccountManagerAccount? CurrentAccount
	{
		get
		{
			return _currentAccount;
		}
		set
		{
			SetProperty(ref _currentAccount, value, "CurrentAccount");
		}
	}

	public string? CurrentAccountAvatarUrl
	{
		get
		{
			return _currentAccountAvatarUrl;
		}
		set
		{
			SetProperty(ref _currentAccountAvatarUrl, value, "CurrentAccountAvatarUrl");
		}
	}

	public ObservableCollection<AccountWithAvatar> Accounts
	{
		get
		{
			return _accounts;
		}
		set
		{
			SetProperty(ref _accounts, value, "Accounts");
		}
	}

	public string SelectedAddMethod
	{
		get
		{
			return _selectedAddMethod;
		}
		set
		{
			SetProperty(ref _selectedAddMethod, value, "SelectedAddMethod");
		}
	}

	public bool IsDropdownOpen
	{
		get
		{
			return _isDropdownOpen;
		}
		set
		{
			if (SetProperty(ref _isDropdownOpen, value, "IsDropdownOpen") & value)
			{
				RefreshAllPresencesAsync();
			}
		}
	}

	public bool IsAddingAccount
	{
		get
		{
			return _isAddingAccount;
		}
		set
		{
			SetProperty(ref _isAddingAccount, value, "IsAddingAccount");
		}
	}

	private UserPresence? CurrentPresence
	{
		get
		{
			return _currentPresence;
		}
		set
		{
			if (SetProperty(ref _currentPresence, value, "CurrentPresence"))
			{
				OnPropertyChanged("PresenceTooltip");
				UpdatePresenceBrush();
			}
		}
	}

	public IBrush PresenceBrush
	{
		get
		{
			return _presenceBrush;
		}
		private set
		{
			SetProperty(ref _presenceBrush, value, "PresenceBrush");
		}
	}

	public string PresenceTooltip
	{
		get
		{
			if (CurrentPresence == null)
			{
				return "Offline";
			}
			return CurrentPresence.UserPresenceType switch
			{
				0 => Strings.Menu_AccountSelector_Presence_Offline, 
				1 => Strings.Menu_AccountSelector_Presence_Online, 
				2 => Strings.Menu_AccountSelector_Presence_InGame, 
				3 => Strings.Menu_AccountSelector_Presence_InStudio, 
				_ => Strings.Common_Unknown, 
			};
		}
	}

	public List<string> AddMethods { get; }

	public string CurrentAccountDisplayName
	{
		get
		{
			if (!(CurrentAccount == null))
			{
				return "@" + CurrentAccount.Username;
			}
			return Strings.Menu_AccountSelector_NotLoggedIn;
		}
	}

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.4.0.0")]
	[ExcludeFromCodeCoverage]
	public IRelayCommand<AccountWithAvatar> SelectAccountCommand => selectAccountCommand ?? (selectAccountCommand = new RelayCommand<AccountWithAvatar>(SelectAccount));

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.4.0.0")]
	[ExcludeFromCodeCoverage]
	public IRelayCommand ToggleDropdownCommand => toggleDropdownCommand ?? (toggleDropdownCommand = new RelayCommand(ToggleDropdown));

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.4.0.0")]
	[ExcludeFromCodeCoverage]
	public IRelayCommand<AccountWithAvatar> DeleteAccountCommand => deleteAccountCommand ?? (deleteAccountCommand = new RelayCommand<AccountWithAvatar>(DeleteAccount));

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.4.0.0")]
	[ExcludeFromCodeCoverage]
	public IAsyncRelayCommand AddAccountCommand => addAccountCommand ?? (addAccountCommand = new AsyncRelayCommand(AddAccount));

	[GeneratedCode("CommunityToolkit.Mvvm.SourceGenerators.RelayCommandGenerator", "8.4.0.0")]
	[ExcludeFromCodeCoverage]
	public IRelayCommand<AccountWithAvatar> ApplyAccountCommand => applyAccountCommand ?? (applyAccountCommand = new RelayCommand<AccountWithAvatar>(ApplyAccount));

	public event Action? OnManualAddRequested;

	private void UpdatePresenceBrush()
	{
		if (CurrentPresence == null)
		{
			PresenceBrush = Brushes.Gray;
			return;
		}
		PresenceBrush = CurrentPresence.UserPresenceType switch
		{
			0 => (IBrush)Brushes.Gray, 
			1 => Brushes.DodgerBlue, 
			2 => Brushes.LimeGreen, 
			3 => Brushes.Orange, 
			_ => Brushes.Gray, 
		};
	}

	public AccountSelectorViewModel()
	{
		int num = 4;
		List<string> list = new List<string>(num);
		CollectionsMarshal.SetCount(list, num);
		Span<string> span = CollectionsMarshal.AsSpan(list);
		span[0] = Strings.Menu_AccountSelector_Login_LocalCookie;
		span[1] = Strings.Menu_Dialog_QuickSignIn_Title;
		span[2] = Strings.Common_Manual;
		span[3] = Strings.Common_Browser;
		AddMethods = list;
		base._002Ector();
		if (Design.IsDesignMode)
		{
			return;
		}
		_accountManager = AccountManager.Shared;
		_accountManager.ActiveAccountChanged += OnActiveAccountChanged;
		Task.Run(async () =>
		{
			try
			{
				await InitializeDataAsync();
			}
			catch (Exception ex)
			{
				App.Logger.Error("Safe catch: " + ex.Message);
			}
		});
	}

	private async Task InitializeDataAsync()
	{
		_ = 1;
		try
		{
			await LoadDataAsync();
			await ValidateAndRemoveInvalidAccountsAsync();
			App.Logger.Info("Initialised");
		}
		catch (Exception ex)
		{
			App.Logger.Error("Exception: " + ex.Message);
		}
	}

	private async Task ValidateAndRemoveInvalidAccountsAsync()
	{
		List<AccountManagerAccount> invalidAccounts = new List<AccountManagerAccount>();
		foreach (AccountManagerAccount account in _accountManager.Accounts)
		{
			bool? flag = await AccountManager.ValidateAccountAsync(account);
			if (flag == false)
			{
				invalidAccounts.Add(account);
			}
			else if (!flag.HasValue)
			{
				App.Logger.Warn("Could not validate account " + account.Username + " (network/server issue) – keeping it.");
			}
		}
		foreach (AccountManagerAccount account2 in invalidAccounts)
		{
			_accountManager.RemoveAccount(account2);
			App.Logger.Info("Removed expired/invalid account: " + account2.Username);
			await Dispatcher.UIThread.InvokeAsync(() => Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.Menu_AccountSelector_AccountRemoved, account2.Username)));
		}
		if (invalidAccounts.Count > 0)
		{
			await LoadDataAsync();
		}
	}

	private async Task LoadDataAsync()
	{
		_ = 1;
		try
		{
			AccountManager mgr = _accountManager;
			List<long> list = mgr.Accounts.Select((AccountManagerAccount acc) => acc.UserId).ToList();
			if (list.Count > 0)
			{
				foreach (KeyValuePair<long, string> item in await mgr.GetAvatarUrlsBulkAsync(list))
				{
					_accountAvatarUrls[item.Key] = item.Value;
				}
			}
			CurrentAccount = mgr.ActiveAccount;
			if (CurrentAccount != null)
			{
				CurrentAccountAvatarUrl = GetAccountAvatarUrl(CurrentAccount.UserId);
			}
			OnPropertyChanged("CurrentAccountDisplayName");
			Accounts.Clear();
			foreach (AccountManagerAccount account in mgr.Accounts)
			{
				string avatarUrl = (_accountAvatarUrls.TryGetValue(account.UserId, out string value) ? value : null);
				Accounts.Add(new AccountWithAvatar(account, avatarUrl));
			}
			await RefreshAllPresencesAsync();
		}
		catch (Exception ex)
		{
			App.Logger.Error("Failed to load account data: " + ex.Message);
		}
	}

	private void OnActiveAccountChanged(AccountManagerAccount? account)
	{
		Dispatcher.UIThread.Post(() =>
		{
			CurrentAccount = account;
			CurrentAccountAvatarUrl = ((account != null) ? GetAccountAvatarUrl(account.UserId) : null);
			OnPropertyChanged("CurrentAccountDisplayName");
			StopPresencePolling();
			if (account != null)
			{
				StartPresencePolling();
				RefreshPresenceAsync();
			}
			else
			{
				CurrentPresence = null;
			}
		});
	}

	private void StartPresencePolling()
	{
		if (_presenceTimer == null)
		{
			_presenceTimer = new DispatcherTimer
			{
				Interval = TimeSpan.FromMilliseconds(20000L)
			};
			_presenceTimer.Tick += async (object? s, EventArgs e) =>
			{
				await RefreshPresenceAsync();
			};
			_presenceTimer.Start();
		}
	}

	private void StopPresencePolling()
	{
		_presenceTimer?.Stop();
		_presenceTimer = null;
	}

	private async Task RefreshPresenceAsync()
	{
		if (CurrentAccount == null)
		{
			return;
		}
		try
		{
			UserPresence userPresence = await AccountManager.GetUserPresenceAsync(CurrentAccount.UserId);
			if (userPresence != null)
			{
				CurrentPresence = userPresence;
			}
		}
		catch (Exception ex)
		{
			App.Logger.Error("Failed to refresh presence: " + ex.Message);
		}
	}

	private async Task RefreshAllPresencesAsync()
	{
		await Task.WhenAll(((IEnumerable<AccountWithAvatar>)Accounts).Select((Func<AccountWithAvatar, Task>)(async (AccountWithAvatar item) =>
		{
			try
			{
				UserPresence presence = await AccountManager.GetUserPresenceAsync(item.UserId);
				await Dispatcher.UIThread.InvokeAsync(() =>
				{
					AccountWithAvatar accountWithAvatar = item;
					accountWithAvatar.PresenceStatus = presence?.UserPresenceType switch
					{
						0 => "Offline", 
						1 => "Online", 
						2 => "In Game", 
						3 => "In Studio", 
						_ => "Unknown", 
					};
					accountWithAvatar = item;
					accountWithAvatar.PresenceBrush = presence?.UserPresenceType switch
					{
						0 => (IBrush)Brushes.Gray, 
						1 => Brushes.DodgerBlue, 
						2 => Brushes.LimeGreen, 
						3 => Brushes.Orange, 
						_ => Brushes.Gray, 
					};
				});
			}
			catch (Exception ex)
			{
				App.Logger.Error($"Failed to fetch presence for user {item.UserId}: {ex.Message}");
			}
		})));
	}

	[RelayCommand]
	private void SelectAccount(AccountWithAvatar item)
	{
		_accountManager.SetActiveAccount(item.UserId);
		IsDropdownOpen = false;
	}

	[RelayCommand]
	private void ToggleDropdown()
	{
		IsDropdownOpen = !IsDropdownOpen;
	}

	[RelayCommand]
	private void DeleteAccount(AccountWithAvatar item)
	{
		_accountManager.RemoveAccount(item.Account);
		Accounts.Remove(item);
	}

	[RelayCommand]
	private async Task AddAccount()
	{
		IsAddingAccount = true;
		try
		{
			AccountManagerAccount newAccount = null;
			QuickSignCodeDialog dialog;
			CancellationTokenSource cts;
			if (SelectedAddMethod == Strings.Menu_Dialog_QuickSignIn_Title)
			{
				dialog = new QuickSignCodeDialog();
				cts = new CancellationTokenSource();
				dialog.Closed += OnDialogClosed;
				dialog.Show();
				try
				{
					newAccount = await AccountManager.AddAccountByQuickSignInAsync(dialog, cts.Token);
				}
				finally
				{
					dialog.Closed -= OnDialogClosed;
					cts.Dispose();
				}
			}
			else if (SelectedAddMethod == Strings.Common_Browser)
			{
				newAccount = await _accountManager.AddAccountByBrowserAsync();
			}
			else
			{
				if (SelectedAddMethod == Strings.Common_Manual)
				{
					OnManualAddRequested?.Invoke();
					return;
				}
				if (SelectedAddMethod == Strings.Menu_AccountSelector_Login_LocalCookie)
				{
					newAccount = await ImportFromCookieManager();
				}
			}
			if (!(newAccount == null) && !(await HandleDuplicateAccountAsync(newAccount)))
			{
				_accountManager.AddAccount(newAccount);
				string valueOrDefault = (await _accountManager.GetAvatarUrlsBulkAsync(new List<long>(1) { newAccount.UserId })).GetValueOrDefault(newAccount.UserId);
				_accountAvatarUrls[newAccount.UserId] = valueOrDefault;
				Accounts.Add(new AccountWithAvatar(newAccount, valueOrDefault));
				_accountManager.SetActiveAccount(newAccount.UserId);
				IsDropdownOpen = false;
			}
			void OnDialogClosed(object? _, EventArgs __)
			{
				dialog.Closed -= OnDialogClosed;
				try
				{
					cts.Cancel();
				}
				catch (ObjectDisposedException)
				{
				}
			}
		}
		catch (Exception ex)
		{
			App.Logger.Error("Error adding account: " + ex.Message);
		}
		finally
		{
			IsAddingAccount = false;
		}
	}

	private async Task<bool> HandleDuplicateAccountAsync(AccountManagerAccount account)
	{
		AccountManagerAccount accountManagerAccount = _accountManager.Accounts.FirstOrDefault((AccountManagerAccount a) => a.UserId == account.UserId);
		if (accountManagerAccount != null)
		{
			_accountManager.SetActiveAccount(accountManagerAccount.UserId);
			IsDropdownOpen = false;
			await Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.Menu_AccountSelector_AlreadyLoggedIn, accountManagerAccount.Username));
			return true;
		}
		return false;
	}

	private static async Task<AccountManagerAccount?> ImportFromCookieManager()
	{
		CookiesManager cookieManager = new CookiesManager();
		await cookieManager.LoadCookies();
		if (!cookieManager.Loaded)
		{
			Frontend.ShowMessageBox(cookieManager.State switch
			{
				CookieState.NotAllowed => Strings.Menu_CookieState_NotAllowed, 
				CookieState.NotFound => Strings.Menu_CookieState_NotFound, 
				CookieState.Invalid => Strings.Menu_CookieState_Invalid, 
				CookieState.Failed => Strings.Menu_CookieState_Failed, 
				_ => Strings.Menu_CookieState_CouldNotLoad, 
			});
			return null;
		}
		AuthenticatedUser authenticatedUser = await cookieManager.GetAuthenticated();
		if (authenticatedUser == null || authenticatedUser.Id == 0L)
		{
			App.Logger.Error("Failed to get authenticated user from cookie.");
			return null;
		}
		string authCookie = cookieManager.GetAuthCookie();
		if (string.IsNullOrEmpty(authCookie))
		{
			App.Logger.Warn("Auth cookie is empty.");
			return null;
		}
		return new AccountManagerAccount(authCookie, authenticatedUser.Id, authenticatedUser.Username, authenticatedUser.DisplayName);
	}

	public async void AddAccountDirect(AccountManagerAccount account)
	{
		if (await HandleDuplicateAccountAsync(account))
		{
			return;
		}
		_accountManager.AddAccount(account);
		string avatarUrl = null;
		try
		{
			avatarUrl = (await _accountManager.GetAvatarUrlsBulkAsync(new List<long>(1) { account.UserId })).GetValueOrDefault(account.UserId);
			if (avatarUrl != null)
			{
				_accountAvatarUrls[account.UserId] = avatarUrl;
			}
		}
		catch (Exception ex)
		{
			App.Logger.Error($"Failed to fetch avatar for {account.UserId}: {ex.Message}");
		}
		if (Accounts.All((AccountWithAvatar a) => a.UserId != account.UserId))
		{
			Accounts.Add(new AccountWithAvatar(account, avatarUrl));
		}
		_accountManager.SetActiveAccount(account.UserId);
		IsDropdownOpen = false;
	}

	[RelayCommand]
	private static void ApplyAccount(AccountWithAvatar item)
	{
		if (item != null)
		{
			if (AccountManager.WriteCookieFileForAccount(item.Account))
			{
				Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.AccountManager_Replace_Success, item.Username));
			}
			else
			{
				Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.AccountManager_Replace_Failed, item.Username), MessageBoxImage.Error);
			}
		}
	}

	public string? GetAccountAvatarUrl(long userId)
	{
		if (!_accountAvatarUrls.TryGetValue(userId, out string value))
		{
			return _accountManager.GetCachedAvatarUrl(userId);
		}
		return value;
	}

	public void Dispose()
	{
		StopPresencePolling();
		_accountManager.ActiveAccountChanged -= OnActiveAccountChanged;
		GC.SuppressFinalize(this);
	}
}
