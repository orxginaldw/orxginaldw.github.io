using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Input;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Platform.Storage;
using Avalonia.Threading;
using CommunityToolkit.Mvvm.Input;
using ICSharpCode.SharpZipLib.Zip;
using Merostrap.Enums;
using Merostrap.Enums.Messagebox;
using Merostrap.Extensions;
using Merostrap.Models;
using Merostrap.Resources;
using Merostrap.UI.Elements.Base;
using Merostrap.UI.Elements.Dialogs;
using Merostrap.UI.Elements.Editor;
using Merostrap.Utility;

namespace Merostrap.UI.ViewModels.Settings;

internal class AppearanceViewModel : NotifyPropertyChangedViewModel
{
	private static readonly string[] _zipFilter = new string[1] { "*.zip" };

	private static readonly string[] JsonPatterns = new string[1] { "*.json" };

	private static readonly JsonSerializerOptions SerializationOptions = new JsonSerializerOptions
	{
		WriteIndented = true
	};

	private CustomThemeCycleSelectionWrapper? _selectedThemeWrapper;

	private ICommand? _addGradientStopCommand;

	private ICommand? _resetGradientCommand;

	private ICommand? _removeGradientStopCommand;

	private ICommand? _exportGradientCommand;

	private ICommand? _importGradientCommand;

	private ICommand? _selectImageCommand;

	private ICommand? _clearImageCommand;

	private ICommand? _openColorPickerCommand;

	public ICommand PreviewBootstrapperCommand => new RelayCommand(PreviewBootstrapper);

	public IAsyncRelayCommand BrowseCustomIconLocationCommand => new AsyncRelayCommand<Control>(async (Control? c) =>
	{
		await BrowseCustomIconLocation(c);
	});

	public IAsyncRelayCommand BrowseCustomRobloxIconLocationCommand => new AsyncRelayCommand<Control>(async (Control? c) =>
	{
		await BrowseCustomRobloxIconLocation(c);
	});

	public ICommand AddCustomThemeCommand => new RelayCommand<Control>(async (Control? c) =>
	{
		await AddCustomTheme(c);
	});

	public ICommand EditCustomThemeCommand => new RelayCommand<Control>(async (Control? c) =>
	{
		await EditCustomTheme(c);
	});

	public ICommand ExportCustomThemeCommand => new RelayCommand<Control>(async (Control? c) =>
	{
		await ExportCustomTheme(c);
	});

	public IAsyncRelayCommand DeleteCustomThemeCommand => new AsyncRelayCommand(() => Task.Run((Action)DeleteCustomTheme));

	public IAsyncRelayCommand RenameCustomThemeCommand => new AsyncRelayCommand(() => Task.Run((Action)RenameCustomTheme));

	public static List<string> Languages => Locale.GetLanguages();

	public string SelectedLanguage
	{
		get
		{
			string locale = App.Settings.Prop.Locale;
			if (locale == "nil")
			{
				return Strings.Common_SystemDefault;
			}
			if (!Locale.SupportedLocales.TryGetValue(locale, out string value))
			{
				return Strings.Common_SystemDefault;
			}
			return value;
		}
		set
		{
			string text = Locale.SupportedLocales.FirstOrDefault((KeyValuePair<string, string> x) => x.Value == value).Key;
			if (text == null && value == Strings.Common_SystemDefault)
			{
				text = "nil";
			}
			if (text == null)
			{
				text = "nil";
			}
			if (App.Settings.Prop.Locale != text)
			{
				App.Settings.Prop.Locale = text;
				OnPropertyChanged("SelectedLanguage");
				Locale.Set(text);
			}
		}
	}

	public ObservableCollection<BootstrapperIconEntry> Icons { get; set; } = new ObservableCollection<BootstrapperIconEntry>();

	public BootstrapperIcon Icon
	{
		get
		{
			return App.Settings.Prop.BootstrapperIcon;
		}
		set
		{
			App.Settings.Prop.BootstrapperIcon = value;
			OnPropertyChanged("IsCustomIconSelected");
		}
	}

	public static bool IsCustomIconSelected => App.Settings.Prop.BootstrapperIcon == BootstrapperIcon.IconCustom;

	public ObservableCollection<RobloxIconEntry> RobloxIcons { get; set; } = new ObservableCollection<RobloxIconEntry>();

	public RobloxIcon RobloxIcon
	{
		get
		{
			return App.Settings.Prop.RobloxIcon;
		}
		set
		{
			App.Settings.Prop.RobloxIcon = value;
			OnPropertyChanged("IsCustomRobloxIconSelected");
		}
	}

	public static bool IsCustomRobloxIconSelected => App.Settings.Prop.RobloxIcon == RobloxIcon.IconCustom;

	public static IEnumerable<WindowsBackdrops> BackdropOptions => Enum.GetValues<WindowsBackdrops>().Where(IsBackdropSupported);

	public WindowsBackdrops SelectedBackdrop
	{
		get
		{
			return App.Settings.Prop.SelectedBackdrop;
		}
		set
		{
			WindowsBackdrops windowsBackdrops = (IsBackdropSupported(value) ? value : WindowsBackdrops.None);
			if (App.Settings.Prop.SelectedBackdrop != windowsBackdrops)
			{
				App.Settings.Prop.SelectedBackdrop = windowsBackdrops;
				OnPropertyChanged("SelectedBackdrop");
				AvaloniaWindow.UpdateBackdropForAllWindows();
			}
		}
	}

	public static string Title
	{
		get
		{
			return App.Settings.Prop.BootstrapperTitle;
		}
		set
		{
			App.Settings.Prop.BootstrapperTitle = value;
		}
	}

	public string CustomIconLocation
	{
		get
		{
			return App.Settings.Prop.BootstrapperIconCustomLocation;
		}
		set
		{
			if (string.IsNullOrEmpty(value))
			{
				if (App.Settings.Prop.BootstrapperIcon == BootstrapperIcon.IconCustom)
				{
					App.Settings.Prop.BootstrapperIcon = BootstrapperIcon.None;
				}
			}
			else
			{
				App.Settings.Prop.BootstrapperIcon = BootstrapperIcon.IconCustom;
			}
			App.Settings.Prop.BootstrapperIconCustomLocation = value;
			BootstrapperIconEx.InvalidateCustomIcon();
			Icons.FirstOrDefault((BootstrapperIconEntry e) => e.IconType == BootstrapperIcon.IconCustom)?.RefreshImage();
			OnPropertyChanged("Icon");
			OnPropertyChanged("Icons");
			if (!App.Settings.Prop.EnableActivityTracking && App.Settings.Prop.EnableWindowManipulation)
			{
				App.Settings.Prop.EnableWindowManipulation = true;
				WindowManipulationEnabled = false;
			}
		}
	}

	public bool WindowManipulationEnabled
	{
		get
		{
			if (ActivityTrackingEnabled)
			{
				return App.Settings.Prop.EnableWindowManipulation;
			}
			return false;
		}
		set
		{
			if ((!value || ActivityTrackingEnabled) && App.Settings.Prop.EnableWindowManipulation != value)
			{
				App.Settings.Prop.EnableWindowManipulation = value;
				if (!value)
				{
					App.Settings.Prop.RobloxTitle = "Roblox";
					App.Settings.Prop.RobloxIcon = RobloxIcon.IconDefault;
					App.Settings.Prop.RobloxIconCustomLocation = "";
					App.Settings.Prop.AutoChangeTitle = false;
					App.Settings.Prop.AutoChangeTitleWithPlayerCount = false;
					App.Settings.Prop.AutoChangeIcon = false;
					OnPropertyChanged("WindowTitle");
					OnPropertyChanged("RobloxIcon");
					OnPropertyChanged("CustomRobloxIconLocation");
					OnPropertyChanged("IsCustomRobloxIconSelected");
					OnPropertyChanged("AutoChangeTitle");
					OnPropertyChanged("AutoChangeTitlePlayerCounter");
					OnPropertyChanged("AutoChangeIcon");
				}
				OnPropertyChanged("WindowManipulationEnabled");
			}
		}
	}

	public bool ActivityTrackingEnabled
	{
		get
		{
			return App.Settings.Prop.EnableActivityTracking;
		}
		set
		{
			if (App.Settings.Prop.EnableActivityTracking != value)
			{
				App.Settings.Prop.EnableActivityTracking = value;
				OnPropertyChanged("ActivityTrackingEnabled");
				if (!value)
				{
					WindowManipulationEnabled = false;
				}
			}
		}
	}

	public string CustomRobloxIconLocation
	{
		get
		{
			return App.Settings.Prop.RobloxIconCustomLocation;
		}
		set
		{
			if (string.IsNullOrEmpty(value))
			{
				if (App.Settings.Prop.RobloxIcon == RobloxIcon.IconCustom)
				{
					App.Settings.Prop.RobloxIcon = RobloxIcon.IconDefault;
				}
			}
			else
			{
				App.Settings.Prop.RobloxIcon = RobloxIcon.IconCustom;
			}
			App.Settings.Prop.RobloxIconCustomLocation = value;
			RobloxIconEx.InvalidateCustomIcon();
			RobloxIcons.FirstOrDefault((RobloxIconEntry e) => e.IconType == RobloxIcon.IconCustom)?.RefreshImage();
			OnPropertyChanged("RobloxIcon");
			OnPropertyChanged("RobloxIcons");
		}
	}

	public string WindowTitle
	{
		get
		{
			return App.Settings.Prop.RobloxTitle;
		}
		set
		{
			App.Settings.Prop.RobloxTitle = value;
			OnPropertyChanged("WindowTitle");
		}
	}

	public bool AutoChangeTitle
	{
		get
		{
			return App.Settings.Prop.AutoChangeTitle;
		}
		set
		{
			App.Settings.Prop.AutoChangeTitle = value;
			if (!value)
			{
				AutoChangeTitlePlayerCounter = false;
				OnPropertyChanged("AutoChangeTitlePlayerCounter");
			}
			OnPropertyChanged("AutoChangeTitle");
		}
	}

	public bool AutoChangeTitlePlayerCounter
	{
		get
		{
			return App.Settings.Prop.AutoChangeTitleWithPlayerCount;
		}
		set
		{
			App.Settings.Prop.AutoChangeTitleWithPlayerCount = value;
			OnPropertyChanged("AutoChangeTitlePlayerCounter");
		}
	}

	public bool AutoChangeIcon
	{
		get
		{
			return App.Settings.Prop.AutoChangeIcon;
		}
		set
		{
			App.Settings.Prop.AutoChangeIcon = value;
			OnPropertyChanged("AutoChangeIcon");
		}
	}

	public IEnumerable<BootstrapperStyle> Dialogs { get; } = BootstrapperStyleEx.Selections;

	public BootstrapperStyle Dialog
	{
		get
		{
			return App.Settings.Prop.BootstrapperStyle;
		}
		set
		{
			App.Settings.Prop.BootstrapperStyle = value;
			OnPropertyChanged("CustomThemesExpanded");
		}
	}

	public static bool CustomThemesExpanded => App.Settings.Prop.BootstrapperStyle == BootstrapperStyle.CustomDialog;

	public bool IsThemeCyclingEnabled
	{
		get
		{
			return App.Settings.Prop.CycleEnabled;
		}
		set
		{
			App.Settings.Prop.CycleEnabled = value;
			OnPropertyChanged("IsThemeCyclingEnabled");
		}
	}

	public static IEnumerable<CycleFrequency> CycleFrequencies => Enum.GetValues<CycleFrequency>();

	public CycleFrequency SelectedCycleFrequency
	{
		get
		{
			return App.Settings.Prop.CycleFrequency;
		}
		set
		{
			App.Settings.Prop.CycleFrequency = value;
			OnPropertyChanged("SelectedCycleFrequency");
			OnPropertyChanged("IsIntervalValueVisible");
		}
	}

	public int CycleIntervalValue
	{
		get
		{
			return App.Settings.Prop.CycleIntervalValue;
		}
		set
		{
			App.Settings.Prop.CycleIntervalValue = value;
			OnPropertyChanged("CycleIntervalValue");
		}
	}

	public bool IsIntervalValueVisible => SelectedCycleFrequency != CycleFrequency.EveryLaunch;

	public ObservableCollection<CustomThemeCycleSelectionWrapper> CustomThemeSelections { get; set; } = new ObservableCollection<CustomThemeCycleSelectionWrapper>();

	public CustomThemeCycleSelectionWrapper? SelectedThemeWrapper
	{
		get
		{
			return _selectedThemeWrapper;
		}
		set
		{
			if (_selectedThemeWrapper != value)
			{
				_selectedThemeWrapper = value;
				OnPropertyChanged("SelectedThemeWrapper");
				SelectedCustomTheme = value?.ThemeName;
			}
		}
	}

	public string? SelectedCustomTheme
	{
		get
		{
			return App.Settings.Prop.SelectedCustomTheme;
		}
		set
		{
			if (!(App.Settings.Prop.SelectedCustomTheme != value))
			{
				return;
			}
			App.Settings.Prop.SelectedCustomTheme = value;
			SelectedCustomThemeName = value ?? string.Empty;
			if (value != null)
			{
				SelectedThemeWrapper = CustomThemeSelections.FirstOrDefault((CustomThemeCycleSelectionWrapper w) => w.ThemeName == value);
			}
			else
			{
				SelectedThemeWrapper = null;
			}
			if (value != null && App.Settings.Prop.CycleEnabledCustomThemes.Contains(value))
			{
				App.Settings.Prop.CycleCurrentIndex = App.Settings.Prop.CycleEnabledCustomThemes.IndexOf(value);
			}
			OnPropertyChanged("SelectedCustomTheme");
			OnPropertyChanged("SelectedCustomThemeName");
			OnPropertyChanged("IsCustomThemeSelected");
		}
	}

	public string SelectedCustomThemeName { get; set; } = "";

	public int SelectedCustomThemeIndex { get; set; }

	public ObservableCollection<string> CustomThemes { get; set; } = new ObservableCollection<string>();

	public bool IsCustomThemeSelected => SelectedCustomTheme != null;

	public IEnumerable<Theme> Themes { get; } = Enum.GetValues<Theme>();

	public Theme Theme
	{
		get
		{
			return App.Settings.Prop.Theme;
		}
		set
		{
			App.Settings.Prop.Theme = value;
			OnPropertyChanged("Theme");
			OnPropertyChanged("CustomThemeExpanded");
			ApplyThemeUpdate();
		}
	}

	public static bool CustomThemeExpanded => App.Settings.Prop.Theme == Theme.Custom;

	public IEnumerable<BackgroundMode> BackgroundTypes { get; } = Enum.GetValues<BackgroundMode>();

	public IEnumerable<BackgroundStretch> BackgroundStretches { get; } = Enum.GetValues<BackgroundStretch>();

	public BackgroundMode BackgroundType
	{
		get
		{
			return App.Settings.Prop.BackgroundType;
		}
		set
		{
			App.Settings.Prop.BackgroundType = value;
			OnPropertyChanged("BackgroundType");
			OnPropertyChanged("IsGradientMode");
			OnPropertyChanged("IsImageMode");
			ApplyThemeUpdate();
		}
	}

	public BackgroundStretch BackgroundStretch
	{
		get
		{
			return App.Settings.Prop.BackgroundStretch;
		}
		set
		{
			App.Settings.Prop.BackgroundStretch = value;
			OnPropertyChanged("BackgroundStretch");
			ApplyThemeUpdate();
		}
	}

	public double BackgroundOpacity
	{
		get
		{
			return App.Settings.Prop.BackgroundOpacity;
		}
		set
		{
			App.Settings.Prop.BackgroundOpacity = value;
			OnPropertyChanged("BackgroundOpacity");
			ApplyThemeUpdate();
		}
	}

	public string BackgroundImagePath
	{
		get
		{
			return App.Settings.Prop.BackgroundImagePath ?? string.Empty;
		}
		set
		{
			App.Settings.Prop.BackgroundImagePath = value;
			OnPropertyChanged("BackgroundImagePath");
			ApplyThemeUpdate();
		}
	}

	public bool IsGradientMode => BackgroundType == BackgroundMode.Gradient;

	public bool IsImageMode => BackgroundType == BackgroundMode.Image;

	public double? GradientAngle
	{
		get
		{
			return App.Settings.Prop.GradientAngle;
		}
		set
		{
			if (value.HasValue && !(value.Value < 0.0) && !(value.Value > 360.0) && App.Settings.Prop.GradientAngle != value)
			{
				App.Settings.Prop.GradientAngle = value.Value;
				OnPropertyChanged("GradientAngle");
				ApplyThemeUpdate();
			}
		}
	}

	public ObservableCollection<GradientStops> GradientStops { get; } = new ObservableCollection<GradientStops>();

	public ICommand AddGradientStopCommand => _addGradientStopCommand ?? (_addGradientStopCommand = new RelayCommand(async () =>
	{
		await AddGradientStop();
	}));

	public ICommand ResetGradientCommand => _resetGradientCommand ?? (_resetGradientCommand = new RelayCommand(ResetGradient));

	public ICommand RemoveGradientStopCommand => _removeGradientStopCommand ?? (_removeGradientStopCommand = new RelayCommand<GradientStops>((GradientStops? stop) =>
	{
		if (stop != null)
		{
			RemoveGradientStop(stop);
		}
	}));

	public ICommand ExportGradientCommand => _exportGradientCommand ?? (_exportGradientCommand = new RelayCommand<TopLevel>(async (TopLevel? topLevel) =>
	{
		if (topLevel != null)
		{
			await ExportGradient(topLevel);
		}
	}));

	public ICommand ImportGradientCommand => _importGradientCommand ?? (_importGradientCommand = new RelayCommand<TopLevel>(async (TopLevel? topLevel) =>
	{
		if (topLevel != null)
		{
			await ImportGradient(topLevel);
		}
	}));

	public ICommand SelectImageCommand => _selectImageCommand ?? (_selectImageCommand = new RelayCommand<TopLevel>(async (TopLevel? tl) =>
	{
		if (tl != null)
		{
			IReadOnlyList<IStorageFile> readOnlyList = await tl.StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
			{
				Title = "Select Background Image",
				FileTypeFilter = new _003C_003Ez__ReadOnlySingleElementList<FilePickerFileType>(FilePickerFileTypes.ImageAll),
				AllowMultiple = false
			});
			if (readOnlyList.Count > 0)
			{
				BackgroundImagePath = readOnlyList[0].Path.LocalPath;
			}
		}
	}));

	public ICommand ClearImageCommand => _clearImageCommand ?? (_clearImageCommand = new RelayCommand(() =>
	{
		BackgroundImagePath = string.Empty;
	}));

	public ICommand OpenColorPickerCommand => _openColorPickerCommand ?? (_openColorPickerCommand = new RelayCommand<Control>(async (Control? control) =>
	{
		object obj = control?.DataContext;
		if (obj is GradientStops stop && TopLevel.GetTopLevel(control) is Window owner)
		{
			string text = await new ColorPickerDialog(stop.Color).ShowDialog<string>(owner);
			if (!string.IsNullOrWhiteSpace(text))
			{
				stop.Color = text;
			}
		}
	}));

	private async void PreviewBootstrapper()
	{
		App.FrostRPC?.SetDialog("Preview Launcher");
		IBootstrapperDialog bootstrapperDialog = await App.Settings.Prop.BootstrapperStyle.GetNew();
		bootstrapperDialog.Message = ((App.Settings.Prop.BootstrapperStyle == BootstrapperStyle.ByfronDialog) ? Strings.Bootstrapper_StylePreview_ImageCancel : Strings.Bootstrapper_StylePreview_TextCancel);
		bootstrapperDialog.CancelEnabled = true;
		bootstrapperDialog.ShowBootstrapper();
		App.FrostRPC?.ClearDialog();
	}

	private async Task BrowseCustomIconLocation(Control? control)
	{
		if (control != null && TopLevel.GetTopLevel(control) is Window { StorageProvider: var storageProvider })
		{
			IReadOnlyList<IStorageFile> readOnlyList = await storageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
			{
				Title = "Select Icon File",
				AllowMultiple = false,
				FileTypeFilter = new _003C_003Ez__ReadOnlySingleElementList<FilePickerFileType>(new FilePickerFileType("Images")
				{
					Patterns = new _003C_003Ez__ReadOnlyArray<string>(new string[5] { "*.ico", "*.png", "*.jpg", "*.jpeg", "*.bmp" })
				})
			});
			if (readOnlyList.Count > 0)
			{
				CustomIconLocation = readOnlyList[0].Path.LocalPath;
				OnPropertyChanged("CustomIconLocation");
			}
		}
	}

	private async Task BrowseCustomRobloxIconLocation(Control? control)
	{
		if (control != null && TopLevel.GetTopLevel(control) is Window { StorageProvider: var storageProvider })
		{
			IReadOnlyList<IStorageFile> readOnlyList = await storageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
			{
				Title = "Select Roblox Icon File",
				AllowMultiple = false,
				FileTypeFilter = new _003C_003Ez__ReadOnlySingleElementList<FilePickerFileType>(new FilePickerFileType("Icons")
				{
					Patterns = new _003C_003Ez__ReadOnlySingleElementList<string>("*.ico")
				})
			});
			if (readOnlyList.Count > 0)
			{
				CustomRobloxIconLocation = readOnlyList[0].Path.LocalPath;
				OnPropertyChanged("CustomRobloxIconLocation");
			}
		}
	}

	private static bool IsBackdropSupported(WindowsBackdrops backdrop)
	{
		if (!OperatingSystem.IsWindows())
		{
			return backdrop == WindowsBackdrops.None;
		}
		return backdrop switch
		{
			WindowsBackdrops.Mica => OperatingSystem.IsWindowsVersionAtLeast(10, 0, 22000), 
			WindowsBackdrops.Acrylic => OperatingSystem.IsWindowsVersionAtLeast(10, 0, 17763), 
			_ => true, 
		};
	}

	public AppearanceViewModel()
	{
		foreach (BootstrapperIcon selection in BootstrapperIconEx.Selections)
		{
			Icons.Add(new BootstrapperIconEntry
			{
				IconType = selection
			});
		}
		foreach (RobloxIcon selection2 in RobloxIconEx.Selections)
		{
			RobloxIcons.Add(new RobloxIconEntry
			{
				IconType = selection2
			});
		}
		PopulateCustomThemes();
		InitializeGradientStops();
	}

	public void InitializeCustomThemeSelections()
	{
		foreach (CustomThemeCycleSelectionWrapper customThemeSelection in CustomThemeSelections)
		{
			customThemeSelection.PropertyChanged -= OnCycleSelectionPropertyChanged;
		}
		CustomThemeSelections.Clear();
		List<string> cycleEnabledCustomThemes = App.Settings.Prop.CycleEnabledCustomThemes;
		foreach (string customTheme in CustomThemes)
		{
			CustomThemeCycleSelectionWrapper customThemeCycleSelectionWrapper = new CustomThemeCycleSelectionWrapper
			{
				ThemeName = customTheme,
				IsSelected = cycleEnabledCustomThemes.Contains(customTheme)
			};
			customThemeCycleSelectionWrapper.PropertyChanged += OnCycleSelectionPropertyChanged;
			CustomThemeSelections.Add(customThemeCycleSelectionWrapper);
		}
	}

	private void OnCycleSelectionPropertyChanged(object? sender, PropertyChangedEventArgs e)
	{
		if (!(sender is CustomThemeCycleSelectionWrapper customThemeCycleSelectionWrapper) || !(e.PropertyName == "IsSelected"))
		{
			return;
		}
		List<string> cycleEnabledCustomThemes = App.Settings.Prop.CycleEnabledCustomThemes;
		if (customThemeCycleSelectionWrapper.IsSelected)
		{
			if (!cycleEnabledCustomThemes.Contains(customThemeCycleSelectionWrapper.ThemeName))
			{
				cycleEnabledCustomThemes.Add(customThemeCycleSelectionWrapper.ThemeName);
			}
		}
		else
		{
			cycleEnabledCustomThemes.Remove(customThemeCycleSelectionWrapper.ThemeName);
		}
	}

	private static void DeleteCustomThemeStructure(string name)
	{
		string path = Path.Combine(Paths.CustomThemes, name);
		if (Directory.Exists(path))
		{
			Directory.Delete(path, recursive: true);
		}
	}

	private static void RenameCustomThemeStructure(string oldName, string newName)
	{
		string sourceDirName = Path.Combine(Paths.CustomThemes, oldName);
		string destDirName = Path.Combine(Paths.CustomThemes, newName);
		Directory.Move(sourceDirName, destDirName);
	}

	private async Task AddCustomTheme(Control? control)
	{
		if (!((TopLevel.GetTopLevel(control) ?? (Application.Current?.ApplicationLifetime as IClassicDesktopStyleApplicationLifetime)?.MainWindow) is Window owner))
		{
			App.Logger.Info("No parent window found.");
			return;
		}
		App.FrostRPC?.SetDialog("Add Custom Launcher");
		AddCustomThemeDialog dialog = new AddCustomThemeDialog();
		await dialog.ShowDialog(owner);
		App.FrostRPC?.ClearDialog();
		if (dialog.Created)
		{
			CustomThemes.Add(dialog.ThemeName);
			CustomThemeCycleSelectionWrapper customThemeCycleSelectionWrapper = new CustomThemeCycleSelectionWrapper
			{
				ThemeName = dialog.ThemeName,
				IsSelected = false
			};
			customThemeCycleSelectionWrapper.PropertyChanged += OnCycleSelectionPropertyChanged;
			CustomThemeSelections.Add(customThemeCycleSelectionWrapper);
			SelectedThemeWrapper = customThemeCycleSelectionWrapper;
			SelectedCustomThemeIndex = CustomThemes.IndexOf(dialog.ThemeName);
			OnPropertyChanged("SelectedCustomThemeIndex");
			if (dialog.OpenEditor)
			{
				await EditCustomTheme(control);
			}
		}
	}

	private async Task EditCustomTheme(Control? control)
	{
		if (SelectedCustomTheme != null && TopLevel.GetTopLevel(control) is Window owner)
		{
			App.FrostRPC?.SetDialog("Editing Custom Theme");
			using (BootstrapperEditorWindow editor = new BootstrapperEditorWindow(SelectedCustomTheme))
			{
				await editor.ShowDialog(owner);
			}
			App.FrostRPC?.ClearDialog();
		}
	}

	private async Task ExportCustomTheme(Control? control)
	{
		if (SelectedCustomTheme == null || !(TopLevel.GetTopLevel(control) is Window { StorageProvider: var storageProvider }))
		{
			return;
		}
		IStorageFile file = await storageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
		{
			Title = "Export Theme",
			SuggestedFileName = SelectedCustomTheme + ".zip",
			FileTypeChoices = new _003C_003Ez__ReadOnlySingleElementList<FilePickerFileType>(new FilePickerFileType("Zip Archive")
			{
				Patterns = _zipFilter
			})
		});
		if (file == null)
		{
			return;
		}
		string themeDir = Path.Combine(Paths.CustomThemes, SelectedCustomTheme);
		await Task.Run(async () =>
		{
			using Stream outputStream = await file.OpenWriteAsync();
			using ZipOutputStream zipStream = new ZipOutputStream(outputStream);
			zipStream.SetLevel(5);
			foreach (string filePath in Directory.EnumerateFiles(themeDir, "*.*", SearchOption.AllDirectories))
			{
				ZipEntry entry = new ZipEntry(Path.GetRelativePath(themeDir, filePath))
				{
					DateTime = DateTime.Now
				};
				await zipStream.PutNextEntryAsync(entry);
				using FileStream fileStream = File.OpenRead(filePath);
				await fileStream.CopyToAsync(zipStream);
				zipStream.CloseEntry();
			}
			zipStream.Finish();
		});
		Threading.ShellExecute(file.Path.LocalPath, select: true);
	}

	private async void DeleteCustomTheme()
	{
		if (SelectedCustomTheme == null)
		{
			return;
		}
		string themeToDelete = SelectedCustomTheme;
		try
		{
			DeleteCustomThemeStructure(themeToDelete);
		}
		catch (Exception ex)
		{
			App.Logger.Error("Unhandled exception: " + ex.Message);
			await Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.Menu_Appearance_CustomThemes_DeleteFailed, themeToDelete, ex.Message), MessageBoxImage.Error);
			return;
		}
		await Dispatcher.UIThread.InvokeAsync(() =>
		{
			CustomThemeCycleSelectionWrapper customThemeCycleSelectionWrapper = CustomThemeSelections.FirstOrDefault((CustomThemeCycleSelectionWrapper w) => w.ThemeName == themeToDelete);
			App.Settings.Prop.CycleEnabledCustomThemes.Remove(themeToDelete);
			if (customThemeCycleSelectionWrapper != null)
			{
				customThemeCycleSelectionWrapper.PropertyChanged -= OnCycleSelectionPropertyChanged;
				CustomThemeSelections.Remove(customThemeCycleSelectionWrapper);
			}
			int num = CustomThemes.IndexOf(themeToDelete);
			if (num >= 0)
			{
				CustomThemes.RemoveAt(num);
			}
			if (CustomThemes.Count > 0)
			{
				CustomThemeCycleSelectionWrapper selectedThemeWrapper = CustomThemeSelections.LastOrDefault();
				SelectedThemeWrapper = selectedThemeWrapper;
				SelectedCustomThemeIndex = CustomThemes.Count - 1;
			}
			else
			{
				SelectedThemeWrapper = null;
				SelectedCustomTheme = null;
				SelectedCustomThemeIndex = -1;
			}
			OnPropertyChanged("IsCustomThemeSelected");
			OnPropertyChanged("SelectedCustomThemeIndex");
		});
	}

	private async void RenameCustomTheme()
	{
		if (SelectedCustomTheme == null || SelectedCustomTheme == SelectedCustomThemeName)
		{
			return;
		}
		if (string.IsNullOrEmpty(SelectedCustomThemeName))
		{
			await Frontend.ShowMessageBox(Strings.CustomTheme_Add_Errors_NameEmpty, MessageBoxImage.Error);
			return;
		}
		PathValidator.ValidationResult validationResult = PathValidator.IsFileNameValid(SelectedCustomThemeName);
		if (validationResult != PathValidator.ValidationResult.Ok)
		{
			await Frontend.ShowMessageBox(validationResult switch
			{
				PathValidator.ValidationResult.IllegalCharacter => Strings.CustomTheme_Add_Errors_NameIllegalCharacters, 
				PathValidator.ValidationResult.ReservedFileName => Strings.CustomTheme_Add_Errors_NameReserved, 
				_ => Strings.CustomTheme_Add_Errors_Unknown, 
			}, MessageBoxImage.Error);
			return;
		}
		if (File.Exists(Path.Combine(Paths.CustomThemes, SelectedCustomThemeName, "Theme.xml")))
		{
			await Frontend.ShowMessageBox(Strings.CustomTheme_Add_Errors_NameTaken, MessageBoxImage.Error);
			return;
		}
		try
		{
			RenameCustomThemeStructure(SelectedCustomTheme, SelectedCustomThemeName);
		}
		catch (Exception ex)
		{
			App.Logger.Error("Unhandled exception: " + ex.Message);
			await Frontend.ShowMessageBox("Rename failed", MessageBoxImage.Error);
			return;
		}
		string newName = SelectedCustomThemeName;
		string oldName = SelectedCustomTheme;
		await Dispatcher.UIThread.InvokeAsync(() =>
		{
			int num = CustomThemes.IndexOf(oldName);
			if (num >= 0)
			{
				CustomThemes[num] = newName;
			}
			CustomThemeCycleSelectionWrapper customThemeCycleSelectionWrapper = CustomThemeSelections.FirstOrDefault((CustomThemeCycleSelectionWrapper w) => w.ThemeName == oldName);
			if (customThemeCycleSelectionWrapper != null)
			{
				customThemeCycleSelectionWrapper.ThemeName = newName;
				if (App.Settings.Prop.CycleEnabledCustomThemes.Remove(oldName))
				{
					App.Settings.Prop.CycleEnabledCustomThemes.Add(newName);
				}
			}
			SelectedThemeWrapper = customThemeCycleSelectionWrapper;
			SelectedCustomTheme = newName;
			SelectedCustomThemeIndex = num;
			OnPropertyChanged("SelectedCustomThemeIndex");
			OnPropertyChanged("SelectedCustomTheme");
			OnPropertyChanged("SelectedCustomThemeName");
		});
	}

	private void PopulateCustomThemes()
	{
		string selected = App.Settings.Prop.SelectedCustomTheme;
		CustomThemes.Clear();
		if (!Directory.Exists(Paths.CustomThemes))
		{
			Directory.CreateDirectory(Paths.CustomThemes);
		}
		string[] directories = Directory.GetDirectories(Paths.CustomThemes);
		foreach (string text in directories)
		{
			if (File.Exists(Path.Combine(text, "Theme.xml")))
			{
				CustomThemes.Add(Path.GetFileName(text));
			}
		}
		InitializeCustomThemeSelections();
		if (!string.IsNullOrEmpty(selected))
		{
			CustomThemeCycleSelectionWrapper customThemeCycleSelectionWrapper = CustomThemeSelections.FirstOrDefault((CustomThemeCycleSelectionWrapper w) => w.ThemeName == selected);
			if (customThemeCycleSelectionWrapper != null)
			{
				SelectedThemeWrapper = customThemeCycleSelectionWrapper;
				SelectedCustomThemeIndex = CustomThemes.IndexOf(selected);
				SelectedCustomThemeName = selected;
				OnPropertyChanged("SelectedCustomThemeIndex");
				OnPropertyChanged("SelectedCustomThemeName");
			}
		}
	}

	private void OnGradientStopPropertyChanged(object? sender, PropertyChangedEventArgs e)
	{
		ApplyThemeUpdate();
	}

	private async Task AddGradientStop()
	{
		GradientStops gradientStops = new GradientStops
		{
			Offset = 0.5,
			Color = "#000000"
		};
		gradientStops.PropertyChanged += OnGradientStopPropertyChanged;
		GradientStops.Add(gradientStops);
		ApplyThemeUpdate();
	}

	private void RemoveGradientStop(GradientStops stop)
	{
		if (stop != null)
		{
			stop.PropertyChanged -= OnGradientStopPropertyChanged;
			GradientStops.Remove(stop);
			ApplyThemeUpdate();
		}
	}

	private void ResetGradient()
	{
		int num = 3;
		List<GradientStops> list = new List<GradientStops>(num);
		CollectionsMarshal.SetCount(list, num);
		Span<GradientStops> span = CollectionsMarshal.AsSpan(list);
		span[0] = new GradientStops
		{
			Offset = 0.0,
			Color = "#8025304A"
		};
		span[1] = new GradientStops
		{
			Offset = 0.5,
			Color = "#80272F48"
		};
		span[2] = new GradientStops
		{
			Offset = 1.0,
			Color = "#80202C36"
		};
		List<GradientStops> list2 = list;
		foreach (GradientStops gradientStop in GradientStops)
		{
			gradientStop.PropertyChanged -= OnGradientStopPropertyChanged;
		}
		GradientStops.Clear();
		foreach (GradientStops item in list2)
		{
			item.PropertyChanged += OnGradientStopPropertyChanged;
			GradientStops.Add(item);
		}
		GradientAngle = 0.0;
		OnPropertyChanged("GradientAngle");
		ApplyThemeUpdate();
	}

	private async Task ExportGradient(TopLevel topLevel)
	{
		IStorageFile storageFile = await topLevel.StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
		{
			Title = "Export Gradient",
			FileTypeChoices = new _003C_003Ez__ReadOnlySingleElementList<FilePickerFileType>(new FilePickerFileType("JSON Files")
			{
				Patterns = JsonPatterns
			}),
			SuggestedFileName = "Merostrap Gradient Background.json"
		});
		if (storageFile == null)
		{
			return;
		}
		var data = new
		{
			GradientStops = GradientStops.Select((GradientStops s) => new { s.Offset, s.Color }).ToList(),
			GradientAngle = GradientAngle
		};
		using Stream stream = await storageFile.OpenWriteAsync();
		await JsonSerializer.SerializeAsync(stream, data, SerializationOptions);
	}

	private async Task ImportGradient(TopLevel topLevel)
	{
		IReadOnlyList<IStorageFile> readOnlyList = await topLevel.StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
		{
			Title = "Import Gradient",
			FileTypeFilter = new _003C_003Ez__ReadOnlySingleElementList<FilePickerFileType>(new FilePickerFileType("JSON Files")
			{
				Patterns = JsonPatterns
			}),
			AllowMultiple = false
		});
		if (readOnlyList.Count == 0)
		{
			return;
		}
		IStorageFile storageFile = readOnlyList[0];
		try
		{
			using Stream stream = await storageFile.OpenReadAsync();
			using JsonDocument jsonDocument = await JsonDocument.ParseAsync(stream);
			JsonElement rootElement = jsonDocument.RootElement;
			foreach (GradientStops gradientStop in GradientStops)
			{
				gradientStop.PropertyChanged -= OnGradientStopPropertyChanged;
			}
			GradientStops.Clear();
			if (rootElement.TryGetProperty("GradientStops", out var value))
			{
				foreach (JsonElement item in value.EnumerateArray())
				{
					GradientStops gradientStops = new GradientStops
					{
						Offset = item.GetProperty("Offset").GetDouble(),
						Color = (item.GetProperty("Color").GetString() ?? "#FFFFFF")
					};
					gradientStops.PropertyChanged += OnGradientStopPropertyChanged;
					GradientStops.Add(gradientStops);
				}
			}
			if (rootElement.TryGetProperty("GradientAngle", out var value2))
			{
				GradientAngle = value2.GetDouble();
			}
			ApplyThemeUpdate();
		}
		catch (Exception ex)
		{
			App.Logger.Error("Unhandled exception: " + ex.Message);
		}
	}

	private void ApplyThemeUpdate()
	{
		App.Settings.Prop.CustomGradientStops = GradientStops.Select((GradientStops x) => new GradientStops
		{
			Offset = x.Offset,
			Color = x.Color
		}).ToList();
		App.Settings.Prop.GradientAngle = GradientAngle;
		AvaloniaWindow.ApplyTheme();
	}

	private void InitializeGradientStops()
	{
		foreach (GradientStops gradientStop in GradientStops)
		{
			gradientStop.PropertyChanged -= OnGradientStopPropertyChanged;
		}
		GradientStops.Clear();
		List<GradientStops> customGradientStops = App.Settings.Prop.CustomGradientStops;
		if (customGradientStops != null && customGradientStops.Count > 0)
		{
			foreach (GradientStops item in customGradientStops)
			{
				GradientStops gradientStops = new GradientStops
				{
					Offset = item.Offset,
					Color = item.Color
				};
				gradientStops.PropertyChanged += OnGradientStopPropertyChanged;
				GradientStops.Add(gradientStops);
			}
			return;
		}
		if (App.Settings.Prop.Theme == Theme.Custom)
		{
			ResetGradient();
		}
	}
}
