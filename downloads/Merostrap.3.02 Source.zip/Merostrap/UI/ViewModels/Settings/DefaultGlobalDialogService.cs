using System.Threading.Tasks;

namespace Merostrap.UI.ViewModels.Settings;

internal class DefaultGlobalDialogService : IDialogServiceGlobal
{
	public Task OpenGlobalSettingsEditorAsync()
	{
		return Task.CompletedTask;
	}
}
