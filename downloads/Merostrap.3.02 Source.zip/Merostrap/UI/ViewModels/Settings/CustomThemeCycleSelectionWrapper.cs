namespace Merostrap.UI.ViewModels.Settings;

internal class CustomThemeCycleSelectionWrapper : NotifyPropertyChangedViewModel
{
	private bool _isSelected;

	private string _themeName = string.Empty;

	public string ThemeName
	{
		get
		{
			return _themeName;
		}
		set
		{
			if (_themeName != value)
			{
				_themeName = value;
				OnPropertyChanged("ThemeName");
			}
		}
	}

	public bool IsSelected
	{
		get
		{
			return _isSelected;
		}
		set
		{
			_isSelected = value;
			OnPropertyChanged("IsSelected");
		}
	}
}
