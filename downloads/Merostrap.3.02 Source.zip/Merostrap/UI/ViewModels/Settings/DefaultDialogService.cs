using System.Threading.Tasks;

namespace Merostrap.UI.ViewModels.Settings;

internal class DefaultDialogService : IDialogService
{
	public Task OpenFastFlagEditorAsync()
	{
		return Task.CompletedTask;
	}
}
