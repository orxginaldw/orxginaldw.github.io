using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Xml.Linq;
using Avalonia.Controls;
using Avalonia.Platform.Storage;
using CommunityToolkit.Mvvm.Input;
using Merostrap.Enums.GBSPresets;
using Merostrap.Enums.Messagebox;
using Merostrap.Resources;
using Merostrap.Utility;

namespace Merostrap.UI.ViewModels.Settings;

internal class GlobalSettingsViewModel(IDialogServiceGlobal dialogService) : NotifyPropertyChangedViewModel
{
	private readonly IDialogServiceGlobal _dialogService = dialogService ?? throw new ArgumentNullException("dialogService");

	public ICommand OpenGlobalSettingsEditorCommand => new AsyncRelayCommand(async () =>
	{
		App.Logger.Info("Opening Global Settings Editor...");
		await _dialogService.OpenGlobalSettingsEditorAsync();
	});

	public static ICommand OpenRobloxFolderCommand => new RelayCommand(() =>
	{
		string path = ((!OperatingSystem.IsMacOS()) ? Paths.Roblox : Path.Combine(Paths.UserProfile, "Library", "Roblox"));
		Threading.ShellExecute(path);
	});

	public static IAsyncRelayCommand ImportCommand => new AsyncRelayCommand<Control>(async (Control? c) =>
	{
		await ImportSettings(c);
	});

	public static IAsyncRelayCommand ExportCommand => new AsyncRelayCommand<Control>(async (Control? c) =>
	{
		await ExportSettings(c);
	});

	public bool IsWarningVisible
	{
		get
		{
			if (!ReadOnly)
			{
				if (!Fullscreen && !MaxQualityEnabled && !VignetteEnabled)
				{
					return FramerateCap != -1;
				}
				return true;
			}
			return false;
		}
	}

	public string WarningTooltipText
	{
		get
		{
			if (ReadOnly)
			{
				return string.Empty;
			}
			List<string> list = new List<string>();
			if (Fullscreen)
			{
				list.Add("Fullscreen");
			}
			if (MaxQualityEnabled)
			{
				list.Add("Max Quality");
			}
			if (VignetteEnabled)
			{
				list.Add("Vignette");
			}
			if (FramerateCap != -1)
			{
				list.Add("Framerate Cap");
			}
			if (list.Count == 0)
			{
				return string.Empty;
			}
			string text = ((list.Count > 1) ? (string.Join(", ", list.Take(list.Count - 1)) + " and " + list.Last()) : list[0]);
			return "Read-only must be enabled for " + text + " to not be forgotten";
		}
	}

	public bool ReadOnly
	{
		get
		{
			return GBSEditor.GetReadOnly();
		}
		set
		{
			if (value)
			{
				Frontend.ShowMessageBox(Strings.Menu_GlobalSettings_ReadonlyMessage, MessageBoxImage.Warning);
			}
			App.GlobalSettings.SetReadOnly(value);
			OnPropertyChanged("ReadOnly");
			UpdateWarningState();
		}
	}

	public int FramerateCap
	{
		get
		{
			int? userFrameCap = App.Settings.Prop.Performance.UserFrameCap;
			if (userFrameCap.HasValue)
			{
				int valueOrDefault = userFrameCap.GetValueOrDefault();
				if (valueOrDefault != 0)
				{
					return valueOrDefault;
				}
				return -1;
			}
			if (int.TryParse(App.GlobalSettings.GetPreset("Rendering.FramerateCap"), out var result))
			{
				return result;
			}
			return 60;
		}
		set
		{
			if (value < 1)
			{
				value = -1;
			}
			App.GlobalSettings.SetPreset("Rendering.FramerateCap", value);
			App.Settings.Prop.Performance.UserFrameCap = Math.Max(0, value);
			OnPropertyChanged("FramerateCap");
			UpdateWarningState();
		}
	}

	public int GraphicsQuality
	{
		get
		{
			if (!int.TryParse(App.GlobalSettings.GetPreset("Rendering.SavedQualityLevel"), NumberStyles.Integer, CultureInfo.InvariantCulture, out var result))
			{
				return 1;
			}
			return result;
		}
		set
		{
			App.GlobalSettings.SetPreset("Rendering.SavedQualityLevel", value.ToString(CultureInfo.InvariantCulture));
			OnPropertyChanged("GraphicsQuality");
		}
	}

	public bool Fullscreen
	{
		get
		{
			return App.GlobalSettings.GetPreset("Rendering.Fullscreen")?.ToUpperInvariant() == "TRUE";
		}
		set
		{
			App.GlobalSettings.SetPreset("Rendering.Fullscreen", value);
			OnPropertyChanged("Fullscreen");
			UpdateWarningState();
		}
	}

	public bool MaxQualityEnabled
	{
		get
		{
			return App.GlobalSettings.GetPreset("Rendering.MaxQualityEnabled")?.ToUpperInvariant() == "TRUE";
		}
		set
		{
			App.GlobalSettings.SetPreset("Rendering.MaxQualityEnabled", value);
			OnPropertyChanged("MaxQualityEnabled");
			UpdateWarningState();
		}
	}

	public bool VignetteEnabled
	{
		get
		{
			bool flag = App.GlobalSettings.GetPreset("Rendering.VignetteEnabled")?.ToUpperInvariant() == "TRUE";
			bool flag2 = App.GlobalSettings.GetPreset("Rendering.VignetteEnableOption")?.ToUpperInvariant() == "TRUE";
			return flag & flag2;
		}
		set
		{
			string value2 = value.ToString().ToUpperInvariant();
			App.GlobalSettings.SetPreset("Rendering.VignetteEnabled", value2);
			App.GlobalSettings.SetPreset("Rendering.VignetteEnableOption", value2);
			OnPropertyChanged("VignetteEnabled");
			UpdateWarningState();
		}
	}

	public static double MasterVolume
	{
		get
		{
			if (!double.TryParse(App.GlobalSettings.GetPreset("Audio.MasterVolume"), NumberStyles.Float, CultureInfo.InvariantCulture, out var result))
			{
				return 1.0;
			}
			return result;
		}
		set
		{
			App.GlobalSettings.SetPreset("Audio.MasterVolume", value.ToString(CultureInfo.InvariantCulture));
		}
	}

	public static double MasterVolumeStudio
	{
		get
		{
			if (!double.TryParse(App.GlobalSettings.GetPreset("Audio.MasterVolumeStudio"), NumberStyles.Float, CultureInfo.InvariantCulture, out var result))
			{
				return 1.0;
			}
			return result;
		}
		set
		{
			App.GlobalSettings.SetPreset("Audio.MasterVolumeStudio", value.ToString(CultureInfo.InvariantCulture));
		}
	}

	public static double PartyVoiceVolume
	{
		get
		{
			if (!double.TryParse(App.GlobalSettings.GetPreset("Audio.PartyChatVolume"), NumberStyles.Float, CultureInfo.InvariantCulture, out var result))
			{
				return 1.0;
			}
			return result;
		}
		set
		{
			App.GlobalSettings.SetPreset("Audio.PartyChatVolume", value.ToString(CultureInfo.InvariantCulture));
		}
	}

	public static double VoiceChatVolume
	{
		get
		{
			if (!double.TryParse(App.GlobalSettings.GetPreset("Audio.VoiceChatVolume"), NumberStyles.Float, CultureInfo.InvariantCulture, out var result))
			{
				return 1.0;
			}
			return result;
		}
		set
		{
			App.GlobalSettings.SetPreset("Audio.VoiceChatVolume", value.ToString(CultureInfo.InvariantCulture));
		}
	}

	public static double MouseSensitivity
	{
		get
		{
			if (!double.TryParse(App.GlobalSettings.GetPreset("User.MouseSensitivity"), NumberStyles.Float, CultureInfo.InvariantCulture, out var result))
			{
				return 1.0;
			}
			return result;
		}
		set
		{
			App.GlobalSettings.SetPreset("User.MouseSensitivity", value.ToString(CultureInfo.InvariantCulture));
		}
	}

	public static bool ShiftLock
	{
		get
		{
			return App.GlobalSettings.GetPreset("User.ShiftLock") == "1";
		}
		set
		{
			App.GlobalSettings.SetPreset("User.ShiftLock", value ? "1" : "0");
		}
	}

	public string MouseSensitivityFirstPersonX
	{
		get
		{
			return App.GlobalSettings.GetVectorValue("User.MouseSensitivityFirstPerson", "X");
		}
		set
		{
			App.GlobalSettings.SetVectorValue("User.MouseSensitivityFirstPerson", "X", value);
			OnPropertyChanged("MouseSensitivityFirstPersonX");
		}
	}

	public string MouseSensitivityFirstPersonY
	{
		get
		{
			return App.GlobalSettings.GetVectorValue("User.MouseSensitivityFirstPerson", "Y");
		}
		set
		{
			App.GlobalSettings.SetVectorValue("User.MouseSensitivityFirstPerson", "Y", value);
			OnPropertyChanged("MouseSensitivityFirstPersonY");
		}
	}

	public string MouseSensitivityThirdPersonX
	{
		get
		{
			return App.GlobalSettings.GetVectorValue("User.MouseSensitivityThirdPerson", "X");
		}
		set
		{
			App.GlobalSettings.SetVectorValue("User.MouseSensitivityThirdPerson", "X", value);
			OnPropertyChanged("MouseSensitivityThirdPersonX");
		}
	}

	public string MouseSensitivityThirdPersonY
	{
		get
		{
			return App.GlobalSettings.GetVectorValue("User.MouseSensitivityThirdPerson", "Y");
		}
		set
		{
			App.GlobalSettings.SetVectorValue("User.MouseSensitivityThirdPerson", "Y", value);
			OnPropertyChanged("MouseSensitivityThirdPersonY");
		}
	}

	public static bool CameraYInverted
	{
		get
		{
			return App.GlobalSettings.GetPreset("User.CameraYInverted")?.ToUpperInvariant() == "TRUE";
		}
		set
		{
			App.GlobalSettings.SetPreset("User.CameraYInverted", value);
		}
	}

	public static int HapticStrength
	{
		get
		{
			if (!int.TryParse(App.GlobalSettings.GetPreset("User.HapticStrength"), NumberStyles.Integer, CultureInfo.InvariantCulture, out var result))
			{
				return 1;
			}
			return result;
		}
		set
		{
			App.GlobalSettings.SetPreset("User.HapticStrength", value.ToString(CultureInfo.InvariantCulture));
		}
	}

	public int UITransparency
	{
		get
		{
			if (!int.TryParse(App.GlobalSettings.GetPreset("UI.Transparency"), NumberStyles.Integer, CultureInfo.InvariantCulture, out var result))
			{
				return 1;
			}
			return result;
		}
		set
		{
			App.GlobalSettings.SetPreset("UI.Transparency", value.ToString(CultureInfo.InvariantCulture));
			OnPropertyChanged("UITransparency");
		}
	}

	public static bool ReducedMotion
	{
		get
		{
			return App.GlobalSettings.GetPreset("UI.ReducedMotion")?.ToUpperInvariant() == "TRUE";
		}
		set
		{
			App.GlobalSettings.SetPreset("UI.ReducedMotion", value);
		}
	}

	public static IReadOnlyDictionary<FontSize, string?> FontSizes => GBSEditor.FontSizes;

	public static FontSize SelectedFontSize
	{
		get
		{
			return FontSizes.FirstOrDefault((KeyValuePair<FontSize, string> x) => x.Value == App.GlobalSettings.GetPreset("UI.FontSize")).Key;
		}
		set
		{
			App.GlobalSettings.SetPreset("UI.FontSize", FontSizes[value]);
		}
	}

	public static IReadOnlyDictionary<PlayerListLayOut, string?> PlayerListLayOuts => GBSEditor.PlayerListLayOuts;

	public static PlayerListLayOut SelectedPlayerListLayOut
	{
		get
		{
			return PlayerListLayOuts.FirstOrDefault((KeyValuePair<PlayerListLayOut, string> x) => x.Value == App.GlobalSettings.GetPreset("UI.PlayerListLayOut")).Key;
		}
		set
		{
			App.GlobalSettings.SetPreset("UI.PlayerListLayOut", PlayerListLayOuts[value]);
		}
	}

	public static bool PerformanceStatsVisible
	{
		get
		{
			return App.GlobalSettings.GetPreset("Misc.PerformanceStatsVisible")?.ToUpperInvariant() == "TRUE";
		}
		set
		{
			App.GlobalSettings.SetPreset("Misc.PerformanceStatsVisible", value);
		}
	}

	public static bool ChatTranslationEnabled
	{
		get
		{
			return App.GlobalSettings.GetPreset("Misc.ChatTranslationEnabled")?.ToUpperInvariant() == "TRUE";
		}
		set
		{
			App.GlobalSettings.SetPreset("Misc.ChatTranslationEnabled", value);
		}
	}

	public static bool ChatTranslationFTUXShown
	{
		get
		{
			return App.GlobalSettings.GetPreset("Misc.ChatTranslationFTUXShown")?.ToUpperInvariant() == "TRUE";
		}
		set
		{
			App.GlobalSettings.SetPreset("Misc.ChatTranslationFTUXShown", value);
		}
	}

	public static bool VREnabled
	{
		get
		{
			return App.GlobalSettings.GetPreset("User.VREnabled")?.ToUpperInvariant() == "TRUE";
		}
		set
		{
			App.GlobalSettings.SetPreset("User.VREnabled", value);
		}
	}

	public GlobalSettingsViewModel()
		: this(new DefaultGlobalDialogService())
	{
	}

	private static async Task ExportSettings(Control? control)
	{
		App.Logger.Info("Exporting settings");
		if (control == null || !(TopLevel.GetTopLevel(control) is Window { StorageProvider: var storageProvider }))
		{
			return;
		}
		IStorageFile storageFile = await storageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
		{
			Title = "Export GBS Settings",
			SuggestedFileName = "GlobalBasicSettings_13.xml",
			DefaultExtension = ".xml",
			FileTypeChoices = new _003C_003Ez__ReadOnlySingleElementList<FilePickerFileType>(new FilePickerFileType("GBS Settings File")
			{
				Patterns = new _003C_003Ez__ReadOnlySingleElementList<string>("*.xml")
			})
		});
		if (storageFile != null)
		{
			string localPath = storageFile.Path.LocalPath;
			if (GBSEditor.ExportSettings(localPath))
			{
				Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.Menu_GlobalSettings_Export_Success, localPath));
			}
			else
			{
				Frontend.ShowMessageBox(Strings.Menu_GlobalSettings_Export_Fail, MessageBoxImage.Error);
			}
		}
	}

	private static async Task ImportSettings(Control? control)
	{
		App.Logger.Info("Importing settings");
		if (control == null || !(TopLevel.GetTopLevel(control) is Window { StorageProvider: var storageProvider }))
		{
			return;
		}
		IReadOnlyList<IStorageFile> readOnlyList = await storageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
		{
			Title = "Import GBS Settings",
			AllowMultiple = false,
			FileTypeFilter = new _003C_003Ez__ReadOnlySingleElementList<FilePickerFileType>(new FilePickerFileType("GBS Settings File")
			{
				Patterns = new _003C_003Ez__ReadOnlySingleElementList<string>("*.xml")
			})
		});
		if (readOnlyList.Count == 0)
		{
			return;
		}
		IStorageFile storageFile = readOnlyList[0];
		string localPath = storageFile.Path.LocalPath;
		try
		{
			if (XDocument.Load(localPath).Root?.Name != "roblox")
			{
				Frontend.ShowMessageBox(Strings.Menu_GlobalSettings_Import_NotGBS, MessageBoxImage.Warning);
				return;
			}
		}
		catch
		{
			Frontend.ShowMessageBox(Strings.Menu_GlobalSettings_Import_NotXML, MessageBoxImage.Warning);
			return;
		}
		if (await Frontend.ShowMessageBox(Strings.Menu_GlobalSettings_Import_Confirmation, MessageBoxImage.Warning, MessageBoxButton.YesNo) == MessageBoxResult.Yes)
		{
			if (App.GlobalSettings.ImportSettings(localPath))
			{
				App.GlobalSettings.Load();
				Frontend.ShowMessageBox(Strings.Menu_GlobalSettings_Import_Success);
			}
			else
			{
				Frontend.ShowMessageBox(Strings.Menu_GlobalSettings_Import_Fail, MessageBoxImage.Error);
			}
		}
	}

	private void UpdateWarningState()
	{
		OnPropertyChanged("IsWarningVisible");
		OnPropertyChanged("WarningTooltipText");
	}
}
