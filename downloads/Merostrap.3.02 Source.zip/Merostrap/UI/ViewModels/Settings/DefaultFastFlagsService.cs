using System.Collections.Generic;

namespace Merostrap.UI.ViewModels.Settings;

internal class DefaultFastFlagsService : IFastFlagsService
{
	public string? GetPreset(string key)
	{
		return App.FastFlags?.GetPreset(key);
	}

	public void SetPreset(string key, string? value)
	{
		App.FastFlags?.SetPreset(key, value);
	}

	public object? GetPresetEnum(IReadOnlyDictionary<object, string> enumMap, string key, string defaultValue)
	{
		return App.FastFlags?.GetPreset(key);
	}

	public void SetPresetEnum(string prefix, string target, string value)
	{
		App.FastFlags?.SetPresetEnum(prefix, target, value);
	}

	public IReadOnlyDictionary<string, object> GetAllPresets()
	{
		return App.FastFlags?.Prop ?? new Dictionary<string, object>();
	}

	public void SetAllPresets(IReadOnlyDictionary<string, object> presets)
	{
		if (App.FastFlags == null)
		{
			return;
		}
		App.FastFlags.Prop.Clear();
		foreach (KeyValuePair<string, object> preset in presets)
		{
			App.FastFlags.Prop[preset.Key] = preset.Value;
		}
	}
}
