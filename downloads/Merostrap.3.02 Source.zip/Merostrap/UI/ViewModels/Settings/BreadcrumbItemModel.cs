namespace Merostrap.UI.ViewModels.Settings;

internal class BreadcrumbItemModel
{
	public string Content { get; set; } = string.Empty;

	public string? Tag { get; set; }

	public bool IsLast { get; set; }
}
