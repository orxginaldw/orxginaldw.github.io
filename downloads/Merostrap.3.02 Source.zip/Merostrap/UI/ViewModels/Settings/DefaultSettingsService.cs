namespace Merostrap.UI.ViewModels.Settings;

internal class DefaultSettingsService : ISettingsService
{
	public bool AskBeforeUsingFastFlags
	{
		get
		{
			return App.Settings.Prop.AskBeforeUsingFastFlags;
		}
		set
		{
			App.Settings.Prop.AskBeforeUsingFastFlags = value;
		}
	}

	public bool UseFastFlagManager
	{
		get
		{
			return App.Settings.Prop.UseFastFlagManager;
		}
		set
		{
			App.Settings.Prop.UseFastFlagManager = value;
		}
	}
}
