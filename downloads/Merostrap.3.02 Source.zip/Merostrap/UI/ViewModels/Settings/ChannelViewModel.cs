using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Platform.Storage;
using CommunityToolkit.Mvvm.Input;
using Merostrap.Enums;
using Merostrap.Enums.Messagebox;
using Merostrap.Exceptions;
using Merostrap.Models;
using Merostrap.Models.APIs.Config;
using Merostrap.Models.APIs.Roblox;
using Merostrap.Models.Persistable;
using Merostrap.Resources;
using Merostrap.RobloxInterfaces;
using Merostrap.UI.Elements.Dialogs;

namespace Merostrap.UI.ViewModels.Settings;

internal class ChannelViewModel : NotifyPropertyChangedViewModel, IDisposable
{
	internal enum VersionHashValidationState
	{
		Idle,
		Checking,
		Valid,
		Invalid
	}

	private CancellationTokenSource? _playerCts;

	private CancellationTokenSource? _studioCts;

	private CancellationTokenSource? _studioHashCts;

	private CancellationTokenSource? _playerHashCts;

	private bool _disposed;

	private VersionHashValidationState _studioHashState;

	private string _studioHashMessage = string.Empty;

	private VersionHashValidationState _playerHashState;

	private string _playerHashMessage = string.Empty;

	public static IEnumerable<UpdateCheck> UpdateCheckValues => Enum.GetValues<UpdateCheck>();

	public bool AutomaticUpdatesEnabled
	{
		get
		{
			return false;
		}
		set
		{
		}
	}

	public ICommand ImportSettingsCommand => new AsyncRelayCommand<object>(ImportSettingsAsync);

	public ICommand ExportSettingsCommand => new AsyncRelayCommand<object>(ExportSettingsAsync);

	public ICommand ResetSettingsToDefaultCommand => new RelayCommand(ResetSettingsToDefault);

	public IAsyncRelayCommand<object?> BrowsePlayerVersionHashCommand { get; }

	public IAsyncRelayCommand<object?> BrowseStudioVersionHashCommand { get; }

	public bool PreReleaseUpdatesEnabled
	{
		get
		{
			return false;
		}
		set
		{
		}
	}

	public static string RobloxDomain
	{
		get
		{
			return App.Settings.Prop.RobloxDomain;
		}
		set
		{
			if (ValidateDomain(value))
			{
				App.Settings.Prop.RobloxDomain = value;
			}
			else
			{
				Frontend.ShowMessageBox(Strings.Menu_Deployment_DomainValidation, MessageBoxImage.Warning);
			}
		}
	}

	public bool TestModeEnabled
	{
		get
		{
			return App.LaunchSettings.TestModeFlag.Active;
		}
		set
		{
			if (value && !App.State.Prop.TestModeWarningShown)
			{
				HandleTestModeConfirmation();
				return;
			}
			App.LaunchSettings.TestModeFlag.Active = value;
			OnPropertyChanged("TestModeEnabled");
		}
	}

	public UpdateCheck SelectedUpdateCheck
	{
		get
		{
			return UpdateCheck.Disabled;
		}
		set
		{
		}
	}

	public static bool IsRobloxInstallationMissing
	{
		get
		{
			if (OperatingSystem.IsLinux())
			{
				InlineArray7<string> buffer = default;
				buffer[0] = Paths.Versions;
				buffer[1] = "Sober";
				buffer[2] = "data";
				buffer[3] = "sober";
				buffer[4] = "packages";
				buffer[5] = "x86_64";
				buffer[6] = "com.roblox.client";
				string path = Path.Combine(buffer);
				return !Directory.Exists(path) || !Directory.EnumerateFiles(path, "*", SearchOption.AllDirectories).Any();
			}
			if (!App.IsPlayerInstalled)
			{
				return !App.IsStudioInstalled;
			}
			return false;
		}
	}

	public DeployInfo? PlayerDeployInfo { get; private set; }

	public DeployInfo? StudioDeployInfo { get; private set; }

	public bool PlayerShowLoadingError { get; set; }

	public bool StudioShowLoadingError { get; set; }

	public string PlayerInfoLoadingText { get; private set; } = "";

	public string StudioInfoLoadingText { get; private set; } = "";

	public bool PlayerShowChannelWarning { get; set; }

	public bool StudioShowChannelWarning { get; set; }

	public string PlayerChannel
	{
		get
		{
			return App.Settings.Prop.PlayerChannel;
		}
		set
		{
			value = value.Trim();
			App.Settings.Prop.PlayerChannel = NormalizeChannel(value);
			OnPropertyChanged("PlayerChannel");
			LoadChannelDeployInfo(value, isStudio: false);
		}
	}

	public string StudioChannel
	{
		get
		{
			return App.Settings.Prop.StudioChannel;
		}
		set
		{
			value = value.Trim();
			App.Settings.Prop.StudioChannel = NormalizeChannel(value);
			OnPropertyChanged("StudioChannel");
			LoadChannelDeployInfo(value, isStudio: true);
		}
	}

	public static bool UpdateRoblox
	{
		get
		{
			if (App.Settings.Prop.UpdateRoblox)
			{
				return !IsRobloxInstallationMissing;
			}
			return false;
		}
		set
		{
			App.Settings.Prop.UpdateRoblox = value;
		}
	}

	public static bool AutomaticallyUpdateSober
	{
		get
		{
			return App.Settings.Prop.AutomaticallyUpdateSober;
		}
		set
		{
			App.Settings.Prop.AutomaticallyUpdateSober = value;
		}
	}

	public static int MaxThreadDownload
	{
		get
		{
			return App.Settings.Prop.MaxThreadDownload;
		}
		set
		{
			App.Settings.Prop.MaxThreadDownload = value;
		}
	}

	public static bool StaticDirectory
	{
		get
		{
			return App.Settings.Prop.StaticDirectory;
		}
		set
		{
			App.Settings.Prop.StaticDirectory = value;
		}
	}

	public static bool DisableAnimations
	{
		get
		{
			return App.Settings.Prop.DisableAnimations;
		}
		set
		{
			App.Settings.Prop.DisableAnimations = value;
			App.Settings.Save();
			if (value)
			{
				App.ApplyAnimationSettings();
			}
			else
			{
				App.RemoveAnimationSettings();
			}
		}
	}

	public static IReadOnlyDictionary<string, ChannelChangeMode> ChannelChangeModes => new Dictionary<string, ChannelChangeMode>
	{
		{
			Strings.Menu_Channel_ChangeAction_Automatic,
			ChannelChangeMode.Automatic
		},
		{
			Strings.Menu_Channel_ChangeAction_Prompt,
			ChannelChangeMode.Prompt
		},
		{
			Strings.Menu_Channel_ChangeAction_Ignore,
			ChannelChangeMode.Ignore
		}
	};

	public static string SelectedChannelChangeMode
	{
		get
		{
			return ChannelChangeModes.FirstOrDefault((KeyValuePair<string, ChannelChangeMode> x) => x.Value == App.Settings.Prop.ChannelChangeMode).Key;
		}
		set
		{
			App.Settings.Prop.ChannelChangeMode = ChannelChangeModes[value];
		}
	}

	public static bool ForceRobloxReinstallation
	{
		get
		{
			if (!App.State.Prop.ForceReinstall)
			{
				return IsRobloxInstallationMissing;
			}
			return true;
		}
		set
		{
			App.State.Prop.ForceReinstall = value;
		}
	}

	public bool StudioVersionOverrideEnabled
	{
		get
		{
			return App.Settings.Prop.StudioVersionOverrideEnabled;
		}
		set
		{
			App.Settings.Prop.StudioVersionOverrideEnabled = value;
			OnPropertyChanged("StudioVersionOverrideEnabled");
			if (value && !string.IsNullOrWhiteSpace(App.Settings.Prop.StudioVersionOverrideHash))
			{
				ValidateStudioVersionHashAsync(App.Settings.Prop.StudioVersionOverrideHash);
			}
			else if (!value)
			{
				SetStudioHashState(VersionHashValidationState.Idle, string.Empty);
			}
		}
	}

	public string StudioVersionOverrideHash
	{
		get
		{
			return App.Settings.Prop.StudioVersionOverrideHash;
		}
		set
		{
			value = value?.Trim() ?? string.Empty;
			App.Settings.Prop.StudioVersionOverrideHash = value;
			OnPropertyChanged("StudioVersionOverrideHash");
			if (App.Settings.Prop.StudioVersionOverrideEnabled)
			{
				ValidateStudioVersionHashAsync(value);
			}
			else
			{
				SetStudioHashState(VersionHashValidationState.Idle, string.Empty);
			}
		}
	}

	public bool PlayerVersionOverrideEnabled
	{
		get
		{
			return App.Settings.Prop.PlayerVersionOverrideEnabled;
		}
		set
		{
			if (App.Settings.Prop.PlayerVersionOverrideEnabled != value)
			{
				App.Settings.Prop.PlayerVersionOverrideEnabled = value;
				OnPropertyChanged("PlayerVersionOverrideEnabled");
				if (value && !string.IsNullOrWhiteSpace(PlayerVersionOverrideHash))
				{
					ValidatePlayerVersionHashAsync(PlayerVersionOverrideHash);
				}
				else if (!value)
				{
					SetPlayerHashState(VersionHashValidationState.Idle, string.Empty);
				}
			}
		}
	}

	public string PlayerVersionOverrideHash
	{
		get
		{
			return App.Settings.Prop.PlayerVersionOverrideHash;
		}
		set
		{
			value = value?.Trim() ?? string.Empty;
			App.Settings.Prop.PlayerVersionOverrideHash = value;
			OnPropertyChanged("PlayerVersionOverrideHash");
			if (PlayerVersionOverrideEnabled)
			{
				ValidatePlayerVersionHashAsync(value);
			}
			else
			{
				SetPlayerHashState(VersionHashValidationState.Idle, string.Empty);
			}
		}
	}

	public VersionHashValidationState StudioHashValidationState
	{
		get
		{
			return _studioHashState;
		}
		private set
		{
			_studioHashState = value;
			OnPropertyChanged("StudioHashValidationState");
			OnPropertyChanged("IsStudioHashIdle");
			OnPropertyChanged("IsStudioHashChecking");
			OnPropertyChanged("IsStudioHashValid");
			OnPropertyChanged("IsStudioHashInvalid");
		}
	}

	public string StudioHashValidationMessage
	{
		get
		{
			return _studioHashMessage;
		}
		private set
		{
			_studioHashMessage = value;
			OnPropertyChanged("StudioHashValidationMessage");
		}
	}

	public bool IsStudioHashIdle => StudioHashValidationState == VersionHashValidationState.Idle;

	public bool IsStudioHashChecking => StudioHashValidationState == VersionHashValidationState.Checking;

	public bool IsStudioHashValid => StudioHashValidationState == VersionHashValidationState.Valid;

	public bool IsStudioHashInvalid => StudioHashValidationState == VersionHashValidationState.Invalid;

	public VersionHashValidationState PlayerHashValidationState
	{
		get
		{
			return _playerHashState;
		}
		private set
		{
			_playerHashState = value;
			OnPropertyChanged("PlayerHashValidationState");
			OnPropertyChanged("IsPlayerHashIdle");
			OnPropertyChanged("IsPlayerHashChecking");
			OnPropertyChanged("IsPlayerHashValid");
			OnPropertyChanged("IsPlayerHashInvalid");
		}
	}

	public string PlayerHashValidationMessage
	{
		get
		{
			return _playerHashMessage;
		}
		private set
		{
			_playerHashMessage = value;
			OnPropertyChanged("PlayerHashValidationMessage");
		}
	}

	public bool IsPlayerHashIdle => PlayerHashValidationState == VersionHashValidationState.Idle;

	public bool IsPlayerHashChecking => PlayerHashValidationState == VersionHashValidationState.Checking;

	public bool IsPlayerHashValid => PlayerHashValidationState == VersionHashValidationState.Valid;

	public bool IsPlayerHashInvalid => PlayerHashValidationState == VersionHashValidationState.Invalid;

	public ChannelViewModel()
	{
		LoadChannelDeployInfo(App.Settings.Prop.PlayerChannel, isStudio: false);
		LoadChannelDeployInfo(App.Settings.Prop.StudioChannel, isStudio: true);
		BrowsePlayerVersionHashCommand = new AsyncRelayCommand<object>(BrowsePlayerVersionHashAsync);
		BrowseStudioVersionHashCommand = new AsyncRelayCommand<object>(BrowseStudioVersionHashAsync);
	}

	private static Window? GetMainWindow()
	{
		if (Application.Current?.ApplicationLifetime is IClassicDesktopStyleApplicationLifetime classicDesktopStyleApplicationLifetime)
		{
			return classicDesktopStyleApplicationLifetime.MainWindow;
		}
		return null;
	}

	private static bool ValidateDomain(string domain)
	{
		return Regex.IsMatch(domain, "^([a-zA-Z0-9.-]+)\\.([a-zA-Z0-9]+)$");
	}

	private async Task HandleTestModeConfirmation()
	{
		if (await Frontend.ShowMessageBox(Strings.Menu_TestMode_Prompt, MessageBoxImage.Information, MessageBoxButton.YesNo) == MessageBoxResult.Yes)
		{
			App.State.Prop.TestModeWarningShown = true;
			App.LaunchSettings.TestModeFlag.Active = true;
		}
		OnPropertyChanged("TestModeEnabled");
	}

	private static string NormalizeChannel(string channel)
	{
		if (string.Equals(channel, "live", StringComparison.OrdinalIgnoreCase) || string.Equals(channel, "zlive", StringComparison.OrdinalIgnoreCase))
		{
			return "production";
		}
		return channel;
	}

	private async Task LoadChannelDeployInfo(string channel, bool isStudio)
	{
		CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
		if (isStudio)
		{
			_studioCts?.Cancel();
			_studioCts?.Dispose();
			_studioCts = cancellationTokenSource;
		}
		else
		{
			_playerCts?.Cancel();
			_playerCts?.Dispose();
			_playerCts = cancellationTokenSource;
		}
		CancellationToken token = cancellationTokenSource.Token;
		try
		{
			if (isStudio)
			{
				StudioShowLoadingError = false;
				StudioInfoLoadingText = Strings.Menu_Channel_Switcher_Fetching;
				StudioDeployInfo = null;
				OnPropertyChanged("StudioShowLoadingError");
				OnPropertyChanged("StudioInfoLoadingText");
				OnPropertyChanged("StudioDeployInfo");
			}
			else
			{
				PlayerShowLoadingError = false;
				PlayerInfoLoadingText = Strings.Menu_Channel_Switcher_Fetching;
				PlayerDeployInfo = null;
				OnPropertyChanged("PlayerShowLoadingError");
				OnPropertyChanged("PlayerInfoLoadingText");
				OnPropertyChanged("PlayerDeployInfo");
			}
			if (token.IsCancellationRequested)
			{
				return;
			}
			string binaryType;
			if (isStudio)
			{
				binaryType = (OperatingSystem.IsMacOS() ? "MacStudio" : "WindowsStudio64");
			}
			else
			{
				binaryType = (OperatingSystem.IsMacOS() ? "MacPlayer" : "WindowsPlayer");
			}
			bool isPrivate = await Deployment.IsChannelPrivate(channel);
			if (token.IsCancellationRequested)
			{
				return;
			}
			if ((App.Cookies.Loaded & isPrivate) && string.IsNullOrEmpty(Deployment.ChannelToken))
			{
				UserChannel userChannel = await Deployment.GetUserChannel(binaryType);
				if (userChannel?.Token != null)
				{
					Deployment.ChannelToken = userChannel.Token;
				}
			}
			ClientVersion clientVersion = await Deployment.GetInfo(channel, behindProductionCheck: true, includeTimestamp: true, binaryType);
			if (!token.IsCancellationRequested)
			{
				DeployInfo deployInfo = new DeployInfo
				{
					Version = clientVersion.Version,
					VersionGuid = (isPrivate ? "version-private" : clientVersion.VersionGuid),
					Timestamp = (clientVersion.Timestamp?.ToLocalTime().ToString(CultureInfo.InvariantCulture) ?? "?")
				};
				if (isStudio)
				{
					StudioDeployInfo = deployInfo;
					StudioShowChannelWarning = clientVersion.IsBehindDefaultChannel;
					OnPropertyChanged("StudioDeployInfo");
					OnPropertyChanged("StudioShowChannelWarning");
				}
				else
				{
					PlayerDeployInfo = deployInfo;
					PlayerShowChannelWarning = clientVersion.IsBehindDefaultChannel;
					OnPropertyChanged("PlayerDeployInfo");
					OnPropertyChanged("PlayerShowChannelWarning");
				}
			}
		}
		catch (OperationCanceledException)
		{
		}
		catch (InvalidChannelException ex2)
		{
			if (!token.IsCancellationRequested)
			{
				string text;
				if (ex2.StatusCode.HasValue && ex2.StatusCode.Value == HttpStatusCode.Unauthorized)
				{
					text = Strings.Menu_Channel_Switcher_Unauthorized;
				}
				else
				{
					text = ((!ex2.StatusCode.HasValue) ? "An unknown HTTP error occurred." : $"HTTP error {(int)ex2.StatusCode.Value}");
				}
				if (isStudio)
				{
					StudioShowLoadingError = true;
					StudioInfoLoadingText = text;
					OnPropertyChanged("StudioShowLoadingError");
					OnPropertyChanged("StudioInfoLoadingText");
				}
				else
				{
					PlayerShowLoadingError = true;
					PlayerInfoLoadingText = text;
					OnPropertyChanged("PlayerShowLoadingError");
					OnPropertyChanged("PlayerInfoLoadingText");
				}
			}
		}
		catch (Exception argument)
		{
			if (!token.IsCancellationRequested)
			{
				if (isStudio)
				{
					StudioShowLoadingError = true;
					StudioInfoLoadingText = Strings.Menu_Deployment_FailedToLoadChannelData;
					OnPropertyChanged("StudioShowLoadingError");
					OnPropertyChanged("StudioInfoLoadingText");
				}
				else
				{
					PlayerShowLoadingError = true;
					PlayerInfoLoadingText = Strings.Menu_Deployment_FailedToLoadChannelData;
					OnPropertyChanged("PlayerShowLoadingError");
					OnPropertyChanged("PlayerInfoLoadingText");
				}
				App.Logger.Error("Unhandled exception: ", argument);
			}
		}
	}

	private async Task ImportSettingsAsync(object? parameter)
	{
		TopLevel topLevel = ((parameter is Control) ? TopLevel.GetTopLevel(parameter as Control) : GetMainWindow());
		if (topLevel == null)
		{
			return;
		}
		IReadOnlyList<IStorageFile> readOnlyList = await topLevel.StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
		{
			Title = Strings.Menu_BottomButtons_ImportSettings,
			AllowMultiple = false,
			FileTypeFilter = new _003C_003Ez__ReadOnlySingleElementList<FilePickerFileType>(new FilePickerFileType("JSON")
			{
				Patterns = new _003C_003Ez__ReadOnlySingleElementList<string>("*.json")
			})
		});
		if (readOnlyList.Count == 0)
		{
			return;
		}
		string text = readOnlyList[0].TryGetLocalPath();
		if (string.IsNullOrWhiteSpace(text) || !File.Exists(text))
		{
			return;
		}
		try
		{
			string directoryName = Path.GetDirectoryName(App.Settings.FileLocation);
			if (!string.IsNullOrEmpty(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			File.Copy(text, App.Settings.FileLocation, overwrite: true);
			App.Settings.Load();
			RefreshBindings();
		}
		catch (Exception ex)
		{
			await Frontend.ShowMessageBox(ex.Message, MessageBoxImage.Error);
		}
	}

	private async Task ExportSettingsAsync(object? parameter)
	{
		TopLevel topLevel = ((parameter is Control) ? TopLevel.GetTopLevel(parameter as Control) : GetMainWindow());
		if (topLevel == null)
		{
			return;
		}
		App.Settings.Save();
		IStorageFile storageFile = await topLevel.StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
		{
			Title = Strings.Menu_BottomButtons_ExportSettings,
			SuggestedFileName = "Settings.json",
			FileTypeChoices = new _003C_003Ez__ReadOnlySingleElementList<FilePickerFileType>(new FilePickerFileType("JSON")
			{
				Patterns = new _003C_003Ez__ReadOnlySingleElementList<string>("*.json")
			})
		});
		if (storageFile == null)
		{
			return;
		}
		string text = storageFile.TryGetLocalPath();
		if (string.IsNullOrWhiteSpace(text))
		{
			return;
		}
		try
		{
			File.Copy(App.Settings.FileLocation, text, overwrite: true);
		}
		catch (Exception ex)
		{
			await Frontend.ShowMessageBox(ex.Message, MessageBoxImage.Error);
		}
	}

	private void ResetSettingsToDefault()
	{
		App.Settings.Prop = new Merostrap.Models.Persistable.Settings();
		App.Settings.Save();
		RefreshBindings();
	}

	private void RefreshBindings()
	{
		OnPropertyChanged("AutomaticUpdatesEnabled");
		OnPropertyChanged("PreReleaseUpdatesEnabled");
		OnPropertyChanged("SelectedUpdateCheck");
		OnPropertyChanged("ForceRobloxReinstallation");
		OnPropertyChanged("UpdateRoblox");
		OnPropertyChanged("AutomaticallyUpdateSober");
		OnPropertyChanged("StaticDirectory");
		OnPropertyChanged("TestModeEnabled");
		OnPropertyChanged("IsRobloxInstallationMissing");
		OnPropertyChanged("StudioVersionOverrideEnabled");
		OnPropertyChanged("StudioVersionOverrideHash");
		OnPropertyChanged("PlayerVersionOverrideEnabled");
		OnPropertyChanged("PlayerVersionOverrideHash");
		OnPropertyChanged("PlayerChannel");
		OnPropertyChanged("StudioChannel");
		SetStudioHashState(VersionHashValidationState.Idle, string.Empty);
		SetPlayerHashState(VersionHashValidationState.Idle, string.Empty);
	}

	private void SetStudioHashState(VersionHashValidationState state, string message)
	{
		StudioHashValidationState = state;
		StudioHashValidationMessage = message;
	}

	private void SetPlayerHashState(VersionHashValidationState state, string message)
	{
		PlayerHashValidationState = state;
		PlayerHashValidationMessage = message;
	}

	public static async Task<(bool Valid, string Error)> ValidateHashCore(string hash, bool enforceAgeAndBan = false, string? binaryType = null)
	{
		if (string.IsNullOrWhiteSpace(hash))
		{
			return (Valid: false, Error: "Hash is empty.");
		}
		if (!Regex.IsMatch(hash, "^version-[0-9a-f]{16}$", RegexOptions.IgnoreCase))
		{
			return (Valid: false, Error: "Invalid format. Expected: version-xxxxxxxxxxxxxxxx");
		}
		try
		{
			string text = (string.IsNullOrEmpty(Deployment.BaseUrl) ? "https://setup.rbxcdn.com" : Deployment.BaseUrl);
			string requestUri;
			if (OperatingSystem.IsMacOS())
			{
				if (string.IsNullOrEmpty(binaryType))
				{
					return (Valid: false, Error: "Binary type is required for macOS validation.");
				}
				string value = (binaryType.Contains("Studio", StringComparison.OrdinalIgnoreCase) ? "RobloxStudioApp.zip" : "RobloxPlayer.zip");
				requestUri = $"{text}/mac/{hash}-{value}";
			}
			else
			{
				requestUri = text + "/" + hash + "-rbxPkgManifest.txt";
			}
			using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Head, requestUri);
			using HttpResponseMessage response = await App.HttpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead);
			if (!response.IsSuccessStatusCode)
			{
				if (response.StatusCode == HttpStatusCode.NotFound)
				{
					return (Valid: false, Error: "Version not found on Roblox servers.");
				}
				return (Valid: false, Error: $"Unexpected response: {(int)response.StatusCode} {response.StatusCode}");
			}
			if (enforceAgeAndBan)
			{
				await App.RemoteData.WaitUntilDataFetched();
				RemoteDataBase prop = App.RemoteData.Prop;
				if (prop != null && prop.BannedVersionHashes?.Contains(hash) == true)
				{
					return (Valid: false, Error: "This version is banned.");
				}
				DateTime? dateTime = await Deployment.GetVersionTimestamp(hash);
				if (!dateTime.HasValue)
				{
					return (Valid: false, Error: "Could not verify version date.");
				}
				if ((DateTime.UtcNow - dateTime.Value).TotalDays > 365.0)
				{
					return (Valid: false, Error: "Version is older than 1 year.");
				}
			}
			return (Valid: true, Error: string.Empty);
		}
		catch (Exception ex)
		{
			return (Valid: false, Error: "Network error: " + ex.Message);
		}
	}

	private static async Task ValidateVersionHashAsync(string hash, Action<VersionHashValidationState, string> setState, CancellationToken token, bool enforceAgeAndBan = false, string? binaryType = null)
	{
		var (flag, arg) = await ValidateHashCore(hash, enforceAgeAndBan, binaryType);
		if (!token.IsCancellationRequested)
		{
			if (flag)
			{
				setState(VersionHashValidationState.Valid, "Version found.");
			}
			else
			{
				setState(VersionHashValidationState.Invalid, arg);
			}
		}
	}

	private static string GetBinaryType(bool isStudio)
	{
		if (OperatingSystem.IsMacOS())
		{
			if (!isStudio)
			{
				return "MacPlayer";
			}
			return "MacStudio";
		}
		if (!isStudio)
		{
			return "WindowsPlayer";
		}
		return "WindowsStudio64";
	}

	private async Task ValidateStudioVersionHashAsync(string hash)
	{
		if (_studioHashCts != null)
		{
			await _studioHashCts.CancelAsync();
			_studioHashCts.Dispose();
		}
		_studioHashCts = new CancellationTokenSource();
		CancellationToken token = _studioHashCts.Token;
		await ValidateVersionHashAsync(hash, (VersionHashValidationState state, string msg) =>
		{
			SetStudioHashState(state, msg);
		}, token, enforceAgeAndBan: false, GetBinaryType(isStudio: true));
	}

	private async Task ValidatePlayerVersionHashAsync(string hash)
	{
		if (_playerHashCts != null)
		{
			await _playerHashCts.CancelAsync();
			_playerHashCts.Dispose();
		}
		_playerHashCts = new CancellationTokenSource();
		CancellationToken token = _playerHashCts.Token;
		await ValidateVersionHashAsync(hash, (VersionHashValidationState state, string msg) =>
		{
			SetPlayerHashState(state, msg);
		}, token, enforceAgeAndBan: true, GetBinaryType(isStudio: false));
	}

	private async Task BrowsePlayerVersionHashAsync(object? parameter)
	{
		TopLevel topLevel = GetTopLevel(parameter);
		if (topLevel != null)
		{
			await new VersionOverrideDialog(LaunchMode.Player).ShowDialog((Window)topLevel);
		}
	}

	private async Task BrowseStudioVersionHashAsync(object? parameter)
	{
		TopLevel topLevel = GetTopLevel(parameter);
		if (topLevel != null)
		{
			await new VersionOverrideDialog(LaunchMode.Studio).ShowDialog((Window)topLevel);
		}
	}

	private static TopLevel? GetTopLevel(object? parameter)
	{
		if (parameter is Control visual)
		{
			return TopLevel.GetTopLevel(visual);
		}
		if (Application.Current?.ApplicationLifetime is IClassicDesktopStyleApplicationLifetime classicDesktopStyleApplicationLifetime)
		{
			return classicDesktopStyleApplicationLifetime.MainWindow;
		}
		return null;
	}

	public void Dispose()
	{
		Dispose(disposing: true);
		GC.SuppressFinalize(this);
	}

	protected virtual void Dispose(bool disposing)
	{
		if (!_disposed)
		{
			if (disposing)
			{
				_playerCts?.Cancel();
				_playerCts?.Dispose();
				_playerCts = null;
				_studioCts?.Cancel();
				_studioCts?.Dispose();
				_studioCts = null;
				_studioHashCts?.Cancel();
				_studioHashCts?.Dispose();
				_studioHashCts = null;
				_playerHashCts?.Cancel();
				_playerHashCts?.Dispose();
				_playerHashCts = null;
			}
			_disposed = true;
		}
	}
}
