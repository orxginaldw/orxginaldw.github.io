using System.Threading.Tasks;

namespace Merostrap.UI.ViewModels.Settings;

internal interface IDialogService
{
	Task OpenFastFlagEditorAsync();
}
