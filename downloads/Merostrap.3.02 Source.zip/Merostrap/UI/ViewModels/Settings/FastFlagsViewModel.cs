using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows.Input;
using CommunityToolkit.Mvvm.Input;
using Merostrap.Enums.FlagPresets;
using Merostrap.Resources;

namespace Merostrap.UI.ViewModels.Settings;

internal class FastFlagsViewModel(IFastFlagsService flagsService, ISettingsService settingsService, IDialogService dialogService) : NotifyPropertyChangedViewModel
{
	private readonly IFastFlagsService _flagsService = flagsService ?? throw new ArgumentNullException("flagsService");

	private readonly ISettingsService _settingsService = settingsService ?? throw new ArgumentNullException("settingsService");

	private readonly IDialogService _dialogService = dialogService ?? throw new ArgumentNullException("dialogService");

	private Dictionary<string, object>? _preResetFlags;

	public ICommand OpenFastFlagEditorCommand => new AsyncRelayCommand(async () =>
	{
		App.Logger.Info("OpenFastFlagEditorCommand executed");
		await _dialogService.OpenFastFlagEditorAsync();
		App.Logger.Info("OpenFastFlagEditorCommand completed");
	});

	public bool RemoveGrass
	{
		get
		{
			if (_flagsService.GetPreset("Rendering.RemoveGrass1") == "0" && _flagsService.GetPreset("Rendering.RemoveGrass2") == "0")
			{
				return _flagsService.GetPreset("Rendering.RemoveGrass3") == "0";
			}
			return false;
		}
		set
		{
			_flagsService.SetPreset("Rendering.RemoveGrass1", value ? "0" : null);
			_flagsService.SetPreset("Rendering.RemoveGrass2", value ? "0" : null);
			_flagsService.SetPreset("Rendering.RemoveGrass3", value ? "0" : null);
			OnPropertyChanged("RemoveGrass");
		}
	}

	public bool LowPolyMeshesEnabled
	{
		get
		{
			return _flagsService.GetPreset("Rendering.LowPolyMeshes1") != null;
		}
		set
		{
			if (value)
			{
				LowPolyMeshesLevel = 5;
			}
			else
			{
				_flagsService.SetPreset("Rendering.LowPolyMeshes1", null);
				_flagsService.SetPreset("Rendering.LowPolyMeshes2", null);
				_flagsService.SetPreset("Rendering.LowPolyMeshes3", null);
				_flagsService.SetPreset("Rendering.LowPolyMeshes4", null);
			}
			OnPropertyChanged("LowPolyMeshesEnabled");
		}
	}

	public int LowPolyMeshesLevel
	{
		get
		{
			if (int.TryParse(_flagsService.GetPreset("Rendering.LowPolyMeshes1"), out var result))
			{
				return result * 9 / 2000;
			}
			return 0;
		}
		set
		{
			int num = Math.Clamp(value, 0, 9);
			int[] array = new int[4] { 2000, 1500, 1000, 500 };
			int[] array2 = new int[4];
			for (int i = 0; i < 4; i++)
			{
				array2[i] = array[i] * num / 9;
			}
			_flagsService.SetPreset("Rendering.LowPolyMeshes1", array2[0].ToString(CultureInfo.InvariantCulture));
			_flagsService.SetPreset("Rendering.LowPolyMeshes2", array2[1].ToString(CultureInfo.InvariantCulture));
			_flagsService.SetPreset("Rendering.LowPolyMeshes3", array2[2].ToString(CultureInfo.InvariantCulture));
			_flagsService.SetPreset("Rendering.LowPolyMeshes4", array2[3].ToString(CultureInfo.InvariantCulture));
			OnPropertyChanged("LowPolyMeshesLevel");
			OnPropertyChanged("LowPolyMeshesEnabled");
		}
	}

	public bool PauseVoxelizer
	{
		get
		{
			return _flagsService.GetPreset("Rendering.PauseVoxerlizer") == "True";
		}
		set
		{
			_flagsService.SetPreset("Rendering.PauseVoxerlizer", value ? "True" : null);
			OnPropertyChanged("PauseVoxelizer");
		}
	}

	public bool GraySky
	{
		get
		{
			return _flagsService.GetPreset("Graphic.GraySky") == "True";
		}
		set
		{
			_flagsService.SetPreset("Graphic.GraySky", value ? "True" : null);
			OnPropertyChanged("GraySky");
		}
	}

	public bool AskBeforeUsingFastFlags
	{
		get
		{
			return _settingsService.AskBeforeUsingFastFlags;
		}
		set
		{
			_settingsService.AskBeforeUsingFastFlags = value;
			OnPropertyChanged("AskBeforeUsingFastFlags");
		}
	}

	public bool UseFastFlagManager
	{
		get
		{
			return _settingsService.UseFastFlagManager;
		}
		set
		{
			_settingsService.UseFastFlagManager = value;
			OnPropertyChanged("UseFastFlagManager");
		}
	}

	public static IReadOnlyDictionary<MSAAMode, string?> MSAALevels => FastFlagManager.MSAAModes;

	public MSAAMode SelectedMSAALevel
	{
		get
		{
			return MSAALevels.FirstOrDefault((KeyValuePair<MSAAMode, string> x) => x.Value == _flagsService.GetPreset("Rendering.MSAA1")).Key;
		}
		set
		{
			_flagsService.SetPreset("Rendering.MSAA1", MSAALevels[value]);
			OnPropertyChanged("SelectedMSAALevel");
		}
	}

	public static IReadOnlyDictionary<RenderingMode, string> RenderingModes => FastFlagManager.RenderingModes;

	public RenderingMode SelectedRenderingMode
	{
		get
		{
			return App.FastFlags?.GetPresetEnum(RenderingModes, "Rendering.Mode", "True") ?? RenderingMode.Default;
		}
		set
		{
			string value2 = RenderingModes[value];
			_flagsService.SetPresetEnum("Rendering.Mode", value2, "True");
			bool flag = value == RenderingMode.Vulkan || value == RenderingMode.OpenGL;
			_flagsService.SetPreset("Rendering.Mode.DisableD3D11", flag ? "True" : null);
			OnPropertyChanged("SelectedRenderingMode");
			OnPropertyChanged("SelectedRenderingModeItem");
		}
	}

	public static IEnumerable<KeyValuePair<RenderingMode, string>> RenderingModeOptions
	{
		get
		{
			RenderingMode[] values = Enum.GetValues<RenderingMode>();
			for (int i = 0; i < values.Length; i++)
			{
				RenderingMode renderingMode = values[i];
				if (renderingMode != RenderingMode.Direct3D || OperatingSystem.IsMacOS())
				{
					string value = renderingMode switch
					{
						RenderingMode.Default => (!OperatingSystem.IsMacOS()) ? Strings.Enums_RenderingMode_DefaultDirect : Strings.Enums_RenderingMode_DefaultMetal, 
						RenderingMode.Direct3D => Strings.Enums_FlagPresets_RenderingMode_Direct3D, 
						_ => renderingMode.ToString(), 
					};
					yield return new KeyValuePair<RenderingMode, string>(renderingMode, value);
				}
			}
		}
	}

	public KeyValuePair<RenderingMode, string>? SelectedRenderingModeItem
	{
		get
		{
			KeyValuePair<RenderingMode, string> value = RenderingModeOptions.FirstOrDefault((KeyValuePair<RenderingMode, string> x) => x.Key == SelectedRenderingMode);
			if (value.Equals(default(KeyValuePair<RenderingMode, string>)))
			{
				return RenderingModeOptions.FirstOrDefault();
			}
			return value;
		}
		set
		{
			if (value.HasValue)
			{
				SelectedRenderingMode = value.Value.Key;
			}
			OnPropertyChanged("SelectedRenderingModeItem");
		}
	}

	public bool FixDisplayScaling
	{
		get
		{
			return _flagsService.GetPreset("Rendering.DisableScaling") == "True";
		}
		set
		{
			_flagsService.SetPreset("Rendering.DisableScaling", value ? "True" : null);
			OnPropertyChanged("FixDisplayScaling");
		}
	}

	public static IReadOnlyDictionary<QualityLevel, string?> QualityLevels => FastFlagManager.QualityLevels;

	public QualityLevel SelectedQualityLevel
	{
		get
		{
			return FastFlagManager.QualityLevels.FirstOrDefault((KeyValuePair<QualityLevel, string> x) => x.Value == _flagsService.GetPreset("Rendering.FrmQuality")).Key;
		}
		set
		{
			if (value == QualityLevel.Disabled)
			{
				_flagsService.SetPreset("Rendering.FrmQuality", null);
			}
			else
			{
				_flagsService.SetPreset("Rendering.FrmQuality", FastFlagManager.QualityLevels[value]);
			}
			OnPropertyChanged("SelectedQualityLevel");
		}
	}

	public static IReadOnlyDictionary<TextureQuality, string?> TextureQualities => FastFlagManager.TextureQualityLevels;

	public TextureQuality SelectedTextureQuality
	{
		get
		{
			return TextureQualities.FirstOrDefault((KeyValuePair<TextureQuality, string> x) => x.Value == _flagsService.GetPreset("Rendering.TextureQuality.Level")).Key;
		}
		set
		{
			if (value == TextureQuality.Default)
			{
				_flagsService.SetPreset("Rendering.TextureQuality", null);
				return;
			}
			_flagsService.SetPreset("Rendering.TextureQuality.OverrideEnabled", "True");
			_flagsService.SetPreset("Rendering.TextureQuality.Level", TextureQualities[value]);
		}
	}

	public bool ResetConfiguration
	{
		get
		{
			return _preResetFlags != null;
		}
		set
		{
			if (value)
			{
				_preResetFlags = new Dictionary<string, object>(_flagsService.GetAllPresets());
				_flagsService.SetAllPresets(new Dictionary<string, object>());
			}
			else if (_preResetFlags != null)
			{
				_flagsService.SetAllPresets(_preResetFlags);
				_preResetFlags = null;
			}
			RequestPageReloadEvent?.Invoke(this, EventArgs.Empty);
			OnPropertyChanged("ResetConfiguration");
		}
	}

	public event EventHandler? RequestPageReloadEvent;

	public FastFlagsViewModel()
		: this(new DefaultFastFlagsService(), new DefaultSettingsService(), new DefaultDialogService())
	{
	}

	public bool GetFlagAsBool(string flagKey, string falseValue = "False")
	{
		return _flagsService.GetPreset(flagKey) != falseValue;
	}

	public void SetFlagFromBool(string flagKey, bool value, string falseValue = "False")
	{
		_flagsService.SetPreset(flagKey, value ? null : falseValue);
	}
}
