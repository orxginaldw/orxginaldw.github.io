using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Merostrap.Enums;
using Merostrap.Enums.AppStoragePresets;
using Merostrap.Enums.Messagebox;
using Merostrap.Extensions;
using Merostrap.Models;
using Merostrap.Models.APIs.RoValra;
using Merostrap.Utility;

namespace Merostrap.UI.ViewModels.Settings;

internal class BehaviourViewModel : NotifyPropertyChangedViewModel
{
	private List<string> _availableRegions = new List<string>();

	private bool _isLoadingRegions;

	private bool _changingMultiInstance;

	private bool _cookieLoadingFailed;

	private readonly List<string> CleanerItems = App.Settings.Prop.CleanerDirectories;

	public bool MultiInstances
	{
		get
		{
			return App.Settings.Prop.MultiInstanceLaunching;
		}
		set
		{
			ChangeMultiInstances(value);
		}
	}

	public static IEnumerable<SoftKeyProfile> SoftKeyProfiles => Enum.GetValues<SoftKeyProfile>();

	public bool LaunchWithVirtualDisplay
	{
		get
		{
			return App.Settings.Prop.LaunchWithVirtualDisplay;
		}
		set
		{
			App.Settings.Prop.LaunchWithVirtualDisplay = value;
			OnPropertyChanged("LaunchWithVirtualDisplay");
		}
	}

	public bool SoftKeyEnabled
	{
		get
		{
			return App.Settings.Prop.SoftKeyEnabled;
		}
		set
		{
			App.Settings.Prop.SoftKeyEnabled = value;
			OnPropertyChanged("SoftKeyEnabled");
		}
	}

	public SoftKeyProfile SoftKeyProfile
	{
		get
		{
			return App.Settings.Prop.SoftKeyProfile;
		}
		set
		{
			App.Settings.Prop.SoftKeyProfile = value;
			OnPropertyChanged("SoftKeyProfile");
		}
	}

	public static bool EnableRobloxBackgroundApp
	{
		get
		{
			return App.Settings.Prop.EnableRobloxBackgroundApp;
		}
		set
		{
			App.Settings.Prop.EnableRobloxBackgroundApp = value;
		}
	}

	public IReadOnlyCollection<RobloxTheme> RobloxThemes { get; } = RobloxThemeEx.Selections;

	public static RobloxTheme RobloxTheme
	{
		get
		{
			return App.Settings.Prop.RobloxTheme;
		}
		set
		{
			App.Settings.Prop.RobloxTheme = value;
		}
	}

	public static bool BackgroundUpdates
	{
		get
		{
			return false;
		}
		set
		{
		}
	}

	public static bool CloseCrashHandler
	{
		get
		{
			return App.Settings.Prop.AutoCloseCrashHandler;
		}
		set
		{
			App.Settings.Prop.AutoCloseCrashHandler = value;
		}
	}

	public static bool ConfirmLaunches
	{
		get
		{
			return App.Settings.Prop.ConfirmLaunches;
		}
		set
		{
			App.Settings.Prop.ConfirmLaunches = value;
		}
	}

	public static bool CookieLoadingFinished => true;

	public bool CookieAccess
	{
		get
		{
			return App.Settings.Prop.AllowCookieAccess;
		}
		set
		{
			App.Settings.Prop.AllowCookieAccess = value;
			if (value)
			{
				Task.Run((Func<Task?>)App.Cookies.LoadCookies);
			}
			OnPropertyChanged("CookieAccess");
		}
	}

	public bool CookieLoadingFailed
	{
		get
		{
			return _cookieLoadingFailed;
		}
		set
		{
			_cookieLoadingFailed = value;
			OnPropertyChanged("CookieLoadingFailed");
		}
	}

	public bool EnableBetterMatchmaking
	{
		get
		{
			return App.Settings.Prop.EnableBetterMatchmaking;
		}
		set
		{
			App.Settings.Prop.EnableBetterMatchmaking = value;
			OnPropertyChanged("EnableBetterMatchmaking");
		}
	}

	public string SelectedRegion
	{
		get
		{
			return App.Settings.Prop.SelectedRegion;
		}
		set
		{
			App.Settings.Prop.SelectedRegion = value;
			OnPropertyChanged("SelectedRegion");
		}
	}

	public List<string> AvailableRegions
	{
		get
		{
			return _availableRegions;
		}
		set
		{
			_availableRegions = value;
			OnPropertyChanged("AvailableRegions");
		}
	}

	public bool IsLoadingRegions
	{
		get
		{
			return _isLoadingRegions;
		}
		set
		{
			_isLoadingRegions = value;
			OnPropertyChanged("IsLoadingRegions");
		}
	}

	public static CleanerOptions SelectedCleanUpMode
	{
		get
		{
			return App.Settings.Prop.CleanerOptions;
		}
		set
		{
			App.Settings.Prop.CleanerOptions = value;
		}
	}

	public IEnumerable<CleanerOptions> CleanerOptions { get; } = CleanerOptionsEx.Selections;

	public static CleanerOptions CleanerOption
	{
		get
		{
			return App.Settings.Prop.CleanerOptions;
		}
		set
		{
			App.Settings.Prop.CleanerOptions = value;
		}
	}

	public bool CleanerLogs
	{
		get
		{
			return CleanerItems.Contains("RobloxLogs");
		}
		set
		{
			if (value)
			{
				CleanerItems.Add("RobloxLogs");
			}
			else
			{
				CleanerItems.Remove("RobloxLogs");
			}
		}
	}

	public bool CleanerCache
	{
		get
		{
			return CleanerItems.Contains("RobloxCache");
		}
		set
		{
			if (value)
			{
				CleanerItems.Add("RobloxCache");
			}
			else
			{
				CleanerItems.Remove("RobloxCache");
			}
		}
	}

	public bool CleanerMerostrap
	{
		get
		{
			return CleanerItems.Contains("MerostrapLogs");
		}
		set
		{
			if (value)
			{
				CleanerItems.Add("MerostrapLogs");
			}
			else
			{
				CleanerItems.Remove("MerostrapLogs");
			}
		}
	}

	private async void ChangeMultiInstances(bool value)
	{
		if (_changingMultiInstance || value == MultiInstances)
		{
			return;
		}
		_changingMultiInstance = true;
		try
		{
			bool flag = value;
			if (flag)
			{
				bool flag2 = !OperatingSystem.IsWindows();
				if (!flag2)
				{
					flag2 = await Frontend.ShowMessageBox("Multi-instance launching may result in an account ban. Enable it only at your own risk.\n\nClose all Roblox clients before the first launch. Enable multi-instance launching?", MessageBoxImage.Warning, MessageBoxButton.YesNo) != MessageBoxResult.Yes;
				}
				flag = flag2;
			}
			if (!flag)
			{
				App.Settings.Prop.MultiInstanceLaunching = value;
				App.Settings.SaveSetting("MultiInstanceLaunching");
			}
		}
		finally
		{
			_changingMultiInstance = false;
			OnPropertyChanged("MultiInstances");
		}
	}

	private static string GetCachePath()
	{
		return Path.Combine(Paths.Cache, "DataCentersCache.json");
	}

	private static async Task SaveDatacentersToCacheAsync(Dictionary<int, string> datacenterMap)
	{
		try
		{
			Dictionary<string, List<int>> dictionary = new Dictionary<string, List<int>>();
			foreach (KeyValuePair<int, string> item in datacenterMap)
			{
				if (!dictionary.TryGetValue(item.Value, out var value))
				{
					value = new List<int>();
					dictionary[item.Value] = value;
				}
				value.Add(item.Key);
			}
			Dictionary<string, List<int>> regions = dictionary.OrderBy((KeyValuePair<string, List<int>> kvp) => kvp.Key, StringComparer.OrdinalIgnoreCase).ToDictionary((KeyValuePair<string, List<int>> kvp) => kvp.Key, (KeyValuePair<string, List<int>> kvp) => kvp.Value);
			DatacentersCache value2 = new DatacentersCache
			{
				Regions = regions,
				LastUpdated = DateTime.UtcNow
			};
			Directory.CreateDirectory(Paths.Cache);
			string contents = JsonSerializer.Serialize(value2);
			await File.WriteAllTextAsync(GetCachePath(), contents);
		}
		catch
		{
		}
	}

	private static async Task<(List<string> regions, Dictionary<int, string> datacenterMap)?> LoadDatacentersFromCacheAsync(bool allowExpired = false)
	{
		try
		{
			if (!File.Exists(GetCachePath()))
			{
				return null;
			}
			DatacentersCache datacentersCache = JsonSerializer.Deserialize<DatacentersCache>(await File.ReadAllTextAsync(GetCachePath()));
			if (datacentersCache == null)
			{
				return null;
			}
			if (!allowExpired && datacentersCache.LastUpdated < DateTime.UtcNow.AddDays(-7.0))
			{
				return null;
			}
			Dictionary<int, string> dictionary = new Dictionary<int, string>();
			List<string> list = new List<string>();
			foreach (KeyValuePair<string, List<int>> region in datacentersCache.Regions)
			{
				list.Add(region.Key);
				foreach (int item in region.Value)
				{
					dictionary[item] = region.Key;
				}
			}
			return (list, dictionary);
		}
		catch
		{
			return null;
		}
	}

	public BehaviourViewModel()
	{
		CookiesManager cookies = App.Cookies;
		cookies.StateChanged = (EventHandler<CookieState>)Delegate.Combine(cookies.StateChanged, (EventHandler<CookieState>)((object? _, CookieState state) =>
		{
			bool flag = ((state == CookieState.Success || state == CookieState.Unknown) ? true : false);
			CookieLoadingFailed = !flag;
		}));
		LoadAvailableRegionsAsync();
	}

	private async Task LoadAvailableRegionsAsync()
	{
		(List<string>, Dictionary<int, string>)? tuple = await LoadDatacentersFromCacheAsync();
		List<string> baseRegions;
		if (tuple.HasValue)
		{
			baseRegions = tuple.Value.Item1;
			AvailableRegions = BuildAvailableRegionsWithCurrent(baseRegions);
			await SyncSelectedRegionAfterLoad();
			return;
		}
		IsLoadingRegions = true;
		try
		{
			List<DatacenterEntry> list = await Http.GetJson<List<DatacenterEntry>>(new Uri("https://apis.rovalra.com/v1/datacenters/list"));
			if (list != null && list.Count > 0)
			{
				HashSet<string> hashSet = new HashSet<string>();
				foreach (DatacenterEntry item2 in list)
				{
					if (item2.Location != null && !string.IsNullOrEmpty(item2.Location.City))
					{
						string item = (item2.Location.City + ", " + item2.Location.Country).TrimStart(',').Trim();
						hashSet.Add(item);
					}
					else if (item2.Location != null && !string.IsNullOrEmpty(item2.Location.Country))
					{
						hashSet.Add(item2.Location.Country);
					}
				}
				baseRegions = hashSet.OrderBy((string r) => r, StringComparer.OrdinalIgnoreCase).ToList();
				Dictionary<int, string> dictionary = new Dictionary<int, string>();
				foreach (DatacenterEntry item3 in list)
				{
					string value = ((string.IsNullOrWhiteSpace(item3.Location?.City) && string.IsNullOrWhiteSpace(item3.Location?.Country)) ? "Unknown" : (item3.Location.City + ", " + item3.Location.Country).Trim().Trim(new char[2] { ',', ' ' }));
					foreach (int dataCenterId in item3.DataCenterIds)
					{
						dictionary[dataCenterId] = value;
					}
				}
				await SaveDatacentersToCacheAsync(dictionary);
			}
			else
			{
				baseRegions = new List<string>();
			}
		}
		catch (Exception argument)
		{
			App.Logger.Error("Unhandled exception: ", argument);
			(List<string>, Dictionary<int, string>)? tuple2 = await LoadDatacentersFromCacheAsync(allowExpired: true);
			baseRegions = ((!tuple2.HasValue) ? new List<string>() : tuple2.Value.Item1);
		}
		finally
		{
			IsLoadingRegions = false;
		}
		AvailableRegions = BuildAvailableRegionsWithCurrent(baseRegions);
		await SyncSelectedRegionAfterLoad();
	}

	private List<string> BuildAvailableRegionsWithCurrent(IEnumerable<string> baseRegions)
	{
		List<string> list = new List<string> { "Auto" };
		foreach (string baseRegion in baseRegions)
		{
			if (!string.Equals(baseRegion, "Auto", StringComparison.OrdinalIgnoreCase))
			{
				list.Add(baseRegion);
			}
		}
		string current2 = SelectedRegion;
		if (!string.IsNullOrEmpty(current2) && !string.Equals(current2, "Auto", StringComparison.OrdinalIgnoreCase) && !list.Any((string r) => string.Equals(r?.Trim(), current2?.Trim(), StringComparison.OrdinalIgnoreCase)))
		{
			list.Add(current2);
		}
		return list;
	}

	private async Task SyncSelectedRegionAfterLoad()
	{
		await Task.Delay(50);
		string current = SelectedRegion;
		if (!AvailableRegions.Any((string r) => string.Equals(r?.Trim(), current?.Trim(), StringComparison.OrdinalIgnoreCase)))
		{
			SelectedRegion = AvailableRegions.FirstOrDefault() ?? string.Empty;
			return;
		}
		string text = AvailableRegions.FirstOrDefault((string r) => string.Equals(r?.Trim(), current?.Trim(), StringComparison.OrdinalIgnoreCase));
		if (text != null && text != current)
		{
			SelectedRegion = text;
			return;
		}
		string original = SelectedRegion;
		SelectedRegion = null;
		await Task.Delay(10);
		SelectedRegion = original;
	}
}
