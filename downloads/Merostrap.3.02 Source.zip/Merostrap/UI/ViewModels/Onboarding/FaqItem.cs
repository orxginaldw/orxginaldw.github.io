using System.Windows.Input;
using CommunityToolkit.Mvvm.Input;

namespace Merostrap.UI.ViewModels.Onboarding;

internal class FaqItem : NotifyPropertyChangedViewModel
{
	private bool _isExpanded;

	public string Question { get; set; } = string.Empty;

	public string Answer { get; set; } = string.Empty;

	public bool IsExpanded
	{
		get
		{
			return _isExpanded;
		}
		set
		{
			_isExpanded = value;
			OnPropertyChanged("IsExpanded");
		}
	}

	public ICommand ToggleCommand { get; }

	public FaqItem()
	{
		ToggleCommand = new RelayCommand(ToggleExpanded);
	}

	private void ToggleExpanded()
	{
		IsExpanded = !IsExpanded;
	}
}
