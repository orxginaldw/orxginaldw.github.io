using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Merostrap.Models;
using Merostrap.Models.APIs.RoValra;
using Merostrap.Utility;

namespace Merostrap.UI.ViewModels.Onboarding;

internal class Page4ViewModel : NotifyPropertyChangedViewModel
{
	private List<string> _availableRegions = new List<string>();

	private bool _isLoadingRegions;

	public bool EnableBetterMatchmaking
	{
		get
		{
			return App.Settings.Prop.EnableBetterMatchmaking;
		}
		set
		{
			App.Settings.Prop.EnableBetterMatchmaking = value;
			OnPropertyChanged("EnableBetterMatchmaking");
		}
	}

	public static string SelectedRegion
	{
		get
		{
			return App.Settings.Prop.SelectedRegion;
		}
		set
		{
			App.Settings.Prop.SelectedRegion = value;
		}
	}

	public List<string> AvailableRegions
	{
		get
		{
			return _availableRegions;
		}
		set
		{
			SetProperty(ref _availableRegions, value, "AvailableRegions");
		}
	}

	public bool IsLoadingRegions
	{
		get
		{
			return _isLoadingRegions;
		}
		set
		{
			SetProperty(ref _isLoadingRegions, value, "IsLoadingRegions");
		}
	}

	public Page4ViewModel()
	{
		EnableBetterMatchmaking = App.Settings.Prop.EnableBetterMatchmaking;
		LoadAvailableRegionsAsync();
	}

	private async Task LoadAvailableRegionsAsync()
	{
		(List<string>, Dictionary<int, string>)? tuple = await LoadDatacentersFromCacheAsync();
		List<string> baseRegions;
		if (tuple.HasValue)
		{
			baseRegions = tuple.Value.Item1;
			AvailableRegions = BuildAvailableRegionsWithCurrent(baseRegions);
			await SyncSelectedRegionAfterLoad();
			return;
		}
		IsLoadingRegions = true;
		try
		{
			List<DatacenterEntry> list = await Http.GetJson<List<DatacenterEntry>>(new Uri("https://apis.rovalra.com/v1/datacenters/list"));
			if (list != null && list.Count > 0)
			{
				HashSet<string> hashSet = new HashSet<string>();
				foreach (DatacenterEntry item2 in list)
				{
					if (item2.Location != null && !string.IsNullOrEmpty(item2.Location.City))
					{
						string item = (item2.Location.City + ", " + item2.Location.Country).TrimStart(',').Trim();
						hashSet.Add(item);
					}
					else if (item2.Location != null && !string.IsNullOrEmpty(item2.Location.Country))
					{
						hashSet.Add(item2.Location.Country);
					}
				}
				baseRegions = hashSet.OrderBy((string r) => r, StringComparer.OrdinalIgnoreCase).ToList();
				Dictionary<int, string> dictionary = new Dictionary<int, string>();
				foreach (DatacenterEntry item3 in list)
				{
					string value = ((string.IsNullOrWhiteSpace(item3.Location?.City) && string.IsNullOrWhiteSpace(item3.Location?.Country)) ? "Unknown" : (item3.Location.City + ", " + item3.Location.Country).Trim().Trim(new char[2] { ',', ' ' }));
					foreach (int dataCenterId in item3.DataCenterIds)
					{
						dictionary[dataCenterId] = value;
					}
				}
				await SaveDatacentersToCacheAsync(dictionary);
			}
			else
			{
				baseRegions = new List<string>();
			}
		}
		catch (Exception argument)
		{
			App.Logger.Error("Unhandled exception: ", argument);
			(List<string>, Dictionary<int, string>)? tuple2 = await LoadDatacentersFromCacheAsync(allowExpired: true);
			baseRegions = ((!tuple2.HasValue) ? new List<string>() : tuple2.Value.Item1);
		}
		finally
		{
			IsLoadingRegions = false;
		}
		AvailableRegions = BuildAvailableRegionsWithCurrent(baseRegions);
		await SyncSelectedRegionAfterLoad();
	}

	private static List<string> BuildAvailableRegionsWithCurrent(IEnumerable<string> baseRegions)
	{
		List<string> list = new List<string> { "Auto" };
		foreach (string baseRegion in baseRegions)
		{
			if (!string.Equals(baseRegion, "Auto", StringComparison.OrdinalIgnoreCase))
			{
				list.Add(baseRegion);
			}
		}
		string current2 = SelectedRegion;
		if (!string.IsNullOrEmpty(current2) && !string.Equals(current2, "Auto", StringComparison.OrdinalIgnoreCase) && !list.Any((string r) => string.Equals(r?.Trim(), current2?.Trim(), StringComparison.OrdinalIgnoreCase)))
		{
			list.Add(current2);
		}
		return list;
	}

	private async Task SyncSelectedRegionAfterLoad()
	{
		await Task.Delay(50);
		string current = SelectedRegion;
		if (!AvailableRegions.Any((string r) => string.Equals(r?.Trim(), current?.Trim(), StringComparison.OrdinalIgnoreCase)))
		{
			SelectedRegion = AvailableRegions.FirstOrDefault() ?? string.Empty;
			return;
		}
		string text = AvailableRegions.FirstOrDefault((string r) => string.Equals(r?.Trim(), current?.Trim(), StringComparison.OrdinalIgnoreCase));
		if (text != null && text != current)
		{
			SelectedRegion = text;
			return;
		}
		string original = SelectedRegion;
		SelectedRegion = null;
		await Task.Delay(10);
		SelectedRegion = original;
	}

	private static string GetCachePath()
	{
		return Path.Combine(Paths.Cache, "DataCentersCache.json");
	}

	private static async Task<(List<string> regions, Dictionary<int, string> datacenterMap)?> LoadDatacentersFromCacheAsync(bool allowExpired = false)
	{
		try
		{
			if (!File.Exists(GetCachePath()))
			{
				return null;
			}
			DatacentersCache datacentersCache = JsonSerializer.Deserialize<DatacentersCache>(await File.ReadAllTextAsync(GetCachePath()));
			if (datacentersCache == null)
			{
				return null;
			}
			if (!allowExpired && datacentersCache.LastUpdated < DateTime.UtcNow.AddDays(-7.0))
			{
				return null;
			}
			Dictionary<int, string> dictionary = new Dictionary<int, string>();
			List<string> list = new List<string>();
			foreach (KeyValuePair<string, List<int>> region in datacentersCache.Regions)
			{
				list.Add(region.Key);
				foreach (int item in region.Value)
				{
					dictionary[item] = region.Key;
				}
			}
			return (list, dictionary);
		}
		catch
		{
			return null;
		}
	}

	private static async Task SaveDatacentersToCacheAsync(Dictionary<int, string> datacenterMap)
	{
		try
		{
			Dictionary<string, List<int>> dictionary = new Dictionary<string, List<int>>();
			foreach (KeyValuePair<int, string> item in datacenterMap)
			{
				if (!dictionary.TryGetValue(item.Value, out var value))
				{
					value = new List<int>();
					dictionary[item.Value] = value;
				}
				value.Add(item.Key);
			}
			Dictionary<string, List<int>> regions = dictionary.OrderBy((KeyValuePair<string, List<int>> kvp) => kvp.Key, StringComparer.OrdinalIgnoreCase).ToDictionary((KeyValuePair<string, List<int>> kvp) => kvp.Key, (KeyValuePair<string, List<int>> kvp) => kvp.Value);
			DatacentersCache value2 = new DatacentersCache
			{
				Regions = regions,
				LastUpdated = DateTime.UtcNow
			};
			Directory.CreateDirectory(Paths.Cache);
			string contents = JsonSerializer.Serialize(value2);
			await File.WriteAllTextAsync(GetCachePath(), contents);
		}
		catch
		{
		}
	}
}
