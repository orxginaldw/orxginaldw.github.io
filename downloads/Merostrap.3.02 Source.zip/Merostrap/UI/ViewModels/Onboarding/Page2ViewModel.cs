using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Input;
using Avalonia.Controls;
using Avalonia.Platform.Storage;
using CommunityToolkit.Mvvm.Input;
using Merostrap.Enums;
using Merostrap.Models;
using Merostrap.UI.Elements.Base;
using Merostrap.UI.Elements.Dialogs;

namespace Merostrap.UI.ViewModels.Onboarding;

internal class Page2ViewModel : NotifyPropertyChangedViewModel
{
	private static readonly string[] JsonPatterns = new string[1] { "*.json" };

	private static readonly JsonSerializerOptions SerializationOptions = new JsonSerializerOptions
	{
		WriteIndented = true
	};

	private ICommand? _addGradientStopCommand;

	private ICommand? _resetGradientCommand;

	private ICommand? _removeGradientStopCommand;

	private ICommand? _exportGradientCommand;

	private ICommand? _importGradientCommand;

	private ICommand? _selectImageCommand;

	private ICommand? _clearImageCommand;

	private ICommand? _openColorPickerCommand;

	public static IEnumerable<WindowsBackdrops> BackdropOptions => Enum.GetValues<WindowsBackdrops>().Where(IsBackdropSupported);

	public WindowsBackdrops SelectedBackdrop
	{
		get
		{
			return App.Settings.Prop.SelectedBackdrop;
		}
		set
		{
			WindowsBackdrops windowsBackdrops = (IsBackdropSupported(value) ? value : WindowsBackdrops.None);
			if (App.Settings.Prop.SelectedBackdrop != windowsBackdrops)
			{
				App.Settings.Prop.SelectedBackdrop = windowsBackdrops;
				OnPropertyChanged("SelectedBackdrop");
				AvaloniaWindow.UpdateBackdropForAllWindows();
			}
		}
	}

	public IEnumerable<Theme> Themes { get; } = Enum.GetValues<Theme>();

	public Theme Theme
	{
		get
		{
			return App.Settings.Prop.Theme;
		}
		set
		{
			App.Settings.Prop.Theme = value;
			OnPropertyChanged("Theme");
			OnPropertyChanged("CustomThemeExpanded");
			ApplyThemeUpdate();
		}
	}

	public static bool CustomThemeExpanded => App.Settings.Prop.Theme == Theme.Custom;

	public IEnumerable<BackgroundMode> BackgroundTypes { get; } = Enum.GetValues<BackgroundMode>();

	public IEnumerable<BackgroundStretch> BackgroundStretches { get; } = Enum.GetValues<BackgroundStretch>();

	public BackgroundMode BackgroundType
	{
		get
		{
			return App.Settings.Prop.BackgroundType;
		}
		set
		{
			App.Settings.Prop.BackgroundType = value;
			OnPropertyChanged("BackgroundType");
			OnPropertyChanged("IsGradientMode");
			OnPropertyChanged("IsImageMode");
			ApplyThemeUpdate();
		}
	}

	public BackgroundStretch BackgroundStretch
	{
		get
		{
			return App.Settings.Prop.BackgroundStretch;
		}
		set
		{
			App.Settings.Prop.BackgroundStretch = value;
			OnPropertyChanged("BackgroundStretch");
			ApplyThemeUpdate();
		}
	}

	public double BackgroundOpacity
	{
		get
		{
			return App.Settings.Prop.BackgroundOpacity;
		}
		set
		{
			App.Settings.Prop.BackgroundOpacity = value;
			OnPropertyChanged("BackgroundOpacity");
			ApplyThemeUpdate();
		}
	}

	public string BackgroundImagePath
	{
		get
		{
			return App.Settings.Prop.BackgroundImagePath ?? string.Empty;
		}
		set
		{
			App.Settings.Prop.BackgroundImagePath = value;
			OnPropertyChanged("BackgroundImagePath");
			ApplyThemeUpdate();
		}
	}

	public bool IsGradientMode => BackgroundType == BackgroundMode.Gradient;

	public bool IsImageMode => BackgroundType == BackgroundMode.Image;

	public double? GradientAngle
	{
		get
		{
			return App.Settings.Prop.GradientAngle;
		}
		set
		{
			if (value.HasValue && !(value.Value < 0.0) && !(value.Value > 360.0) && App.Settings.Prop.GradientAngle != value)
			{
				App.Settings.Prop.GradientAngle = value.Value;
				OnPropertyChanged("GradientAngle");
				ApplyThemeUpdate();
			}
		}
	}

	public ObservableCollection<GradientStops> GradientStops { get; } = new ObservableCollection<GradientStops>();

	public ICommand AddGradientStopCommand => _addGradientStopCommand ?? (_addGradientStopCommand = new RelayCommand(async () =>
	{
		await AddGradientStop();
	}));

	public ICommand ResetGradientCommand => _resetGradientCommand ?? (_resetGradientCommand = new RelayCommand(ResetGradient));

	public ICommand RemoveGradientStopCommand => _removeGradientStopCommand ?? (_removeGradientStopCommand = new RelayCommand<GradientStops>((GradientStops? stop) =>
	{
		if (stop != null)
		{
			RemoveGradientStop(stop);
		}
	}));

	public ICommand ExportGradientCommand => _exportGradientCommand ?? (_exportGradientCommand = new RelayCommand<TopLevel>(async (TopLevel? topLevel) =>
	{
		if (topLevel != null)
		{
			await ExportGradient(topLevel);
		}
	}));

	public ICommand ImportGradientCommand => _importGradientCommand ?? (_importGradientCommand = new RelayCommand<TopLevel>(async (TopLevel? topLevel) =>
	{
		if (topLevel != null)
		{
			await ImportGradient(topLevel);
		}
	}));

	public ICommand SelectImageCommand => _selectImageCommand ?? (_selectImageCommand = new RelayCommand<TopLevel>(async (TopLevel? tl) =>
	{
		if (tl != null)
		{
			IReadOnlyList<IStorageFile> readOnlyList = await tl.StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
			{
				Title = "Select Background Image",
				FileTypeFilter = new _003C_003Ez__ReadOnlySingleElementList<FilePickerFileType>(FilePickerFileTypes.ImageAll),
				AllowMultiple = false
			});
			if (readOnlyList.Count > 0)
			{
				BackgroundImagePath = readOnlyList[0].Path.LocalPath;
			}
		}
	}));

	public ICommand ClearImageCommand => _clearImageCommand ?? (_clearImageCommand = new RelayCommand(() =>
	{
		BackgroundImagePath = string.Empty;
	}));

	public ICommand OpenColorPickerCommand => _openColorPickerCommand ?? (_openColorPickerCommand = new RelayCommand<Control>(async (Control? control) =>
	{
		object obj = control?.DataContext;
		if (obj is GradientStops stop && TopLevel.GetTopLevel(control) is Window owner)
		{
			string text = await new ColorPickerDialog(stop.Color).ShowDialog<string>(owner);
			if (!string.IsNullOrWhiteSpace(text))
			{
				stop.Color = text;
			}
		}
	}));

	public Page2ViewModel()
	{
		InitializeGradientStops();
	}

	private static bool IsBackdropSupported(WindowsBackdrops backdrop)
	{
		if (!OperatingSystem.IsWindows())
		{
			return backdrop == WindowsBackdrops.None;
		}
		return backdrop switch
		{
			WindowsBackdrops.Mica => OperatingSystem.IsWindowsVersionAtLeast(10, 0, 22000), 
			WindowsBackdrops.Acrylic => OperatingSystem.IsWindowsVersionAtLeast(10, 0, 17763), 
			_ => true, 
		};
	}

	private void OnGradientStopPropertyChanged(object? sender, PropertyChangedEventArgs e)
	{
		ApplyThemeUpdate();
	}

	private async Task AddGradientStop()
	{
		GradientStops gradientStops = new GradientStops
		{
			Offset = 0.5,
			Color = "#000000"
		};
		gradientStops.PropertyChanged += OnGradientStopPropertyChanged;
		GradientStops.Add(gradientStops);
		ApplyThemeUpdate();
	}

	private void RemoveGradientStop(GradientStops stop)
	{
		if (stop != null)
		{
			stop.PropertyChanged -= OnGradientStopPropertyChanged;
			GradientStops.Remove(stop);
			ApplyThemeUpdate();
		}
	}

	private void ResetGradient()
	{
		int num = 3;
		List<GradientStops> list = new List<GradientStops>(num);
		CollectionsMarshal.SetCount(list, num);
		Span<GradientStops> span = CollectionsMarshal.AsSpan(list);
		span[0] = new GradientStops
		{
			Offset = 0.0,
			Color = "#4D5560"
		};
		span[1] = new GradientStops
		{
			Offset = 0.5,
			Color = "#383F47"
		};
		span[2] = new GradientStops
		{
			Offset = 1.0,
			Color = "#252A30"
		};
		List<GradientStops> list2 = list;
		foreach (GradientStops gradientStop in GradientStops)
		{
			gradientStop.PropertyChanged -= OnGradientStopPropertyChanged;
		}
		GradientStops.Clear();
		foreach (GradientStops item in list2)
		{
			item.PropertyChanged += OnGradientStopPropertyChanged;
			GradientStops.Add(item);
		}
		GradientAngle = 0.0;
		OnPropertyChanged("GradientAngle");
		ApplyThemeUpdate();
	}

	private async Task ExportGradient(TopLevel topLevel)
	{
		IStorageFile storageFile = await topLevel.StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
		{
			Title = "Export Gradient",
			FileTypeChoices = new _003C_003Ez__ReadOnlySingleElementList<FilePickerFileType>(new FilePickerFileType("JSON Files")
			{
				Patterns = JsonPatterns
			}),
			SuggestedFileName = "Merostrap Gradient Background.json"
		});
		if (storageFile == null)
		{
			return;
		}
		var data = new
		{
			GradientStops = GradientStops.Select((GradientStops s) => new { s.Offset, s.Color }).ToList(),
			GradientAngle = GradientAngle
		};
		using Stream stream = await storageFile.OpenWriteAsync();
		await JsonSerializer.SerializeAsync(stream, data, SerializationOptions);
	}

	private async Task ImportGradient(TopLevel topLevel)
	{
		IReadOnlyList<IStorageFile> readOnlyList = await topLevel.StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
		{
			Title = "Import Gradient",
			FileTypeFilter = new _003C_003Ez__ReadOnlySingleElementList<FilePickerFileType>(new FilePickerFileType("JSON Files")
			{
				Patterns = JsonPatterns
			}),
			AllowMultiple = false
		});
		if (readOnlyList.Count == 0)
		{
			return;
		}
		IStorageFile storageFile = readOnlyList[0];
		try
		{
			using Stream stream = await storageFile.OpenReadAsync();
			using JsonDocument jsonDocument = await JsonDocument.ParseAsync(stream);
			JsonElement rootElement = jsonDocument.RootElement;
			foreach (GradientStops gradientStop in GradientStops)
			{
				gradientStop.PropertyChanged -= OnGradientStopPropertyChanged;
			}
			GradientStops.Clear();
			if (rootElement.TryGetProperty("GradientStops", out var value))
			{
				foreach (JsonElement item in value.EnumerateArray())
				{
					GradientStops gradientStops = new GradientStops
					{
						Offset = item.GetProperty("Offset").GetDouble(),
						Color = (item.GetProperty("Color").GetString() ?? "#FFFFFF")
					};
					gradientStops.PropertyChanged += OnGradientStopPropertyChanged;
					GradientStops.Add(gradientStops);
				}
			}
			if (rootElement.TryGetProperty("GradientAngle", out var value2))
			{
				GradientAngle = value2.GetDouble();
			}
			ApplyThemeUpdate();
		}
		catch (Exception argument)
		{
			App.Logger.Error("Unhandled exception: ", argument);
		}
	}

	private void ApplyThemeUpdate()
	{
		App.Settings.Prop.CustomGradientStops = GradientStops.Select((GradientStops x) => new GradientStops
		{
			Offset = x.Offset,
			Color = x.Color
		}).ToList();
		App.Settings.Prop.GradientAngle = GradientAngle;
		AvaloniaWindow.ApplyTheme();
	}

	private void InitializeGradientStops()
	{
		foreach (GradientStops gradientStop in GradientStops)
		{
			gradientStop.PropertyChanged -= OnGradientStopPropertyChanged;
		}
		GradientStops.Clear();
		List<GradientStops> customGradientStops = App.Settings.Prop.CustomGradientStops;
		if (customGradientStops != null && customGradientStops.Count > 0)
		{
			foreach (GradientStops item in customGradientStops)
			{
				GradientStops gradientStops = new GradientStops
				{
					Offset = item.Offset,
					Color = item.Color
				};
				gradientStops.PropertyChanged += OnGradientStopPropertyChanged;
				GradientStops.Add(gradientStops);
			}
			return;
		}
		if (App.Settings.Prop.Theme == Theme.Custom)
		{
			ResetGradient();
		}
	}
}
