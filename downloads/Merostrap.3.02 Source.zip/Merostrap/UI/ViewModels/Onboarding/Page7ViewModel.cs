using System.Windows.Input;
using CommunityToolkit.Mvvm.Input;
using Merostrap.Enums;
using Merostrap.UI.Elements.Onboarding;

namespace Merostrap.UI.ViewModels.Onboarding;

internal class Page7ViewModel : NotifyPropertyChangedViewModel
{
	public ICommand LaunchRobloxCommand { get; }

	public ICommand LaunchSettingsCommand { get; }

	public Page7ViewModel()
	{
		LaunchRobloxCommand = new RelayCommand(LaunchRoblox);
		LaunchSettingsCommand = new RelayCommand(LaunchSettings);
	}

	private void LaunchRoblox()
	{
		MainWindow instance = MainWindow.Instance;
		if (instance != null)
		{
			instance.CloseAction = NextAction.LaunchRoblox;
			instance.Close();
		}
	}

	private void LaunchSettings()
	{
		MainWindow instance = MainWindow.Instance;
		if (instance != null)
		{
			instance.CloseAction = NextAction.LaunchSettings;
			instance.Close();
		}
	}
}
