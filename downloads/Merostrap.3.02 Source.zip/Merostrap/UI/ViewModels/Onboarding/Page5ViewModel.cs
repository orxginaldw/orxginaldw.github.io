using Merostrap.Models.SettingTasks;
using Merostrap.Resources;

namespace Merostrap.UI.ViewModels.Onboarding;

internal class Page5ViewModel : NotifyPropertyChangedViewModel
{
	public ShortcutTask DesktopIconTask { get; } = new ShortcutTask("Desktop", Paths.Desktop, "Merostrap.lnk");

	public ShortcutTask StartMenuIconTask { get; } = new ShortcutTask("StartMenu", Paths.WindowsStartMenu, "Merostrap.lnk");

	public ShortcutTask PlayerIconTask { get; } = new ShortcutTask("RobloxPlayer", Paths.Desktop, Strings.LaunchMenu_LaunchRoblox + ".lnk", "-player");

	public ShortcutTask StudioIconTask { get; } = new ShortcutTask("RobloxStudio", Paths.Desktop, Strings.LaunchMenu_LaunchRobloxStudio + ".lnk", "-studio");

	public ShortcutTask SettingsIconTask { get; } = new ShortcutTask("Settings", Paths.Desktop, Strings.Menu_Title + ".lnk", "-settings");
}
