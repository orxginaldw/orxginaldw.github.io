using System;
using System.Threading.Tasks;
using Merostrap.Enums;

namespace Merostrap.UI.ViewModels.Onboarding;

internal class Page3ViewModel : NotifyPropertyChangedViewModel
{
	private bool _cookieLoadingFailed;

	public static bool CookieLoadingFinished => true;

	public bool CookieAccess
	{
		get
		{
			return App.Settings.Prop.AllowCookieAccess;
		}
		set
		{
			App.Settings.Prop.AllowCookieAccess = value;
			if (value)
			{
				Task.Run((Func<Task?>)App.Cookies.LoadCookies);
			}
			OnPropertyChanged("CookieAccess");
		}
	}

	public bool CookieLoadingFailed
	{
		get
		{
			return _cookieLoadingFailed;
		}
		set
		{
			_cookieLoadingFailed = value;
			OnPropertyChanged("CookieLoadingFailed");
		}
	}

	public Page3ViewModel()
	{
		CookiesManager cookies = App.Cookies;
		cookies.StateChanged = (EventHandler<CookieState>)Delegate.Combine(cookies.StateChanged, (EventHandler<CookieState>)((object? _, CookieState state) =>
		{
			bool flag = ((state == CookieState.Success || state == CookieState.Unknown) ? true : false);
			CookieLoadingFailed = !flag;
		}));
	}
}
