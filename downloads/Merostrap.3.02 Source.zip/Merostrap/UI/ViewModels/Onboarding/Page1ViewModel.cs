using System.Collections.Generic;

namespace Merostrap.UI.ViewModels.Onboarding;

internal class Page1ViewModel : NotifyPropertyChangedViewModel
{
	private string _selectedLanguage = Locale.SupportedLocales[App.Settings.Prop.Locale];

	public static List<string> Languages => Locale.GetLanguages();

	public string SelectedLanguage
	{
		get
		{
			return _selectedLanguage;
		}
		set
		{
			if (SetProperty(ref _selectedLanguage, value, "SelectedLanguage"))
			{
				SetLocale();
			}
		}
	}

	private void SetLocale()
	{
		string identifierFromName = Locale.GetIdentifierFromName(SelectedLanguage);
		Locale.Set(identifierFromName);
		App.Settings.Prop.Locale = identifierFromName;
	}
}
