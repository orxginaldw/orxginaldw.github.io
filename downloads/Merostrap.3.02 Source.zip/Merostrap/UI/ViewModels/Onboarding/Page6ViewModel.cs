using System.Collections.ObjectModel;
using Merostrap.Resources;

namespace Merostrap.UI.ViewModels.Onboarding;

internal class Page6ViewModel : NotifyPropertyChangedViewModel
{
	public ObservableCollection<FaqItem> FaqItems { get; } = new ObservableCollection<FaqItem>();

	public Page6ViewModel()
	{
		LoadFaqData();
	}

	private void LoadFaqData()
	{
		FaqItems.Add(new FaqItem
		{
			Question = Strings.Menu_Onboarding_Page6_Q1,
			Answer = Strings.Menu_Onboarding_Page6_A1
		});
		FaqItems.Add(new FaqItem
		{
			Question = Strings.Menu_Onboarding_Page6_Q2,
			Answer = Strings.Menu_Onboarding_Page6_A2
		});
		FaqItems.Add(new FaqItem
		{
			Question = Strings.Menu_Onboarding_Page6_Q3,
			Answer = Strings.Menu_Onboarding_Page6_A3
		});
		FaqItems.Add(new FaqItem
		{
			Question = Strings.Menu_Onboarding_Page6_Q4,
			Answer = Strings.Menu_Onboarding_Page6_A4
		});
		FaqItems.Add(new FaqItem
		{
			Question = Strings.Menu_Onboarding_Page6_Q5,
			Answer = Strings.Menu_Onboarding_Page6_A5
		});
		FaqItems.Add(new FaqItem
		{
			Question = Strings.Menu_Onboarding_Page6_Q6,
			Answer = Strings.Menu_Onboarding_Page6_A6
		});
	}
}
