using System;
using System.Globalization;
using System.Windows.Input;
using CommunityToolkit.Mvvm.Input;
using Merostrap.Resources;

namespace Merostrap.UI.ViewModels.Onboarding;

internal class MainWindowViewModel : NotifyPropertyChangedViewModel
{
	private bool _backButtonEnabled;

	public int StepNumber { get; private set; } = 1;

	public int StepCount { get; private set; } = 4;

	public double Progress => (double)StepNumber * 100.0 / (double)StepCount;

	public string StepText => string.Format(CultureInfo.CurrentCulture, WelcomeStrings.StepFormat, StepNumber, StepCount);

	public string NextButtonText { get; private set; } = Strings.Common_Next;

	public bool BackButtonEnabled
	{
		get
		{
			return _backButtonEnabled;
		}
		set
		{
			_backButtonEnabled = value;
			OnPropertyChanged("BackButtonEnabled");
		}
	}

	public int ButtonWidth { get; } = Locale.CurrentCulture.Name.StartsWith("bg", StringComparison.Ordinal) ? 112 : 96;

	public ICommand BackPageCommand => new RelayCommand(BackPage);

	public ICommand NextPageCommand => new RelayCommand(NextPage);

	public event EventHandler<string>? PageRequest;

	public void SetStep(int index, int count)
	{
		StepCount = Math.Max(1, count);
		StepNumber = Math.Clamp(index + 1, 1, StepCount);
		string[] array = new string[4] { "StepNumber", "StepCount", "Progress", "StepText" };
		foreach (string propertyName in array)
		{
			OnPropertyChanged(propertyName);
		}
	}

	public void SetNextButtonText(string text)
	{
		NextButtonText = text;
		OnPropertyChanged("NextButtonText");
	}

	private void BackPage()
	{
		PageRequest?.Invoke(this, "back");
	}

	private void NextPage()
	{
		PageRequest?.Invoke(this, "next");
	}
}
