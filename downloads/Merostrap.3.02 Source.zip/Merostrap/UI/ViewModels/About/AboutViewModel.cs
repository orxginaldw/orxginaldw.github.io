using System.Globalization;
using Merostrap.Extensions;
using Merostrap.Models.Attributes;
using Merostrap.Resources;

namespace Merostrap.UI.ViewModels.About;

internal class AboutViewModel : NotifyPropertyChangedViewModel
{
	public static string Version => string.Format(CultureInfo.InvariantCulture, Strings.Menu_About_Version, App.Version);

	public static BuildMetadataAttribute BuildMetadata => App.BuildMetadata;

	public static string BuildTimestamp => BuildMetadata.Timestamp.ToFriendlyString();

	public static string BuildCommitHashUrl => "https://github.com//commit/" + BuildMetadata.CommitHash;

	public static bool BuildInformationVisibility => !App.IsProductionBuild;

	public static bool BuildCommitVisibility => App.IsActionBuild;
}
