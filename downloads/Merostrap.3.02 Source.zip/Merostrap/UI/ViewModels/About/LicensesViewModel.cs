namespace Merostrap.UI.ViewModels.About;

internal class LicensesViewModel : NotifyPropertyChangedViewModel
{
}
