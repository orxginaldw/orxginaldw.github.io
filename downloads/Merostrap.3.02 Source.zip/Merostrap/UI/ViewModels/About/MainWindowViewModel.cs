using System;
using CommunityToolkit.Mvvm.Input;
using Merostrap.UI.Elements.Onboarding;

namespace Merostrap.UI.ViewModels.About;

internal class MainWindowViewModel : NotifyPropertyChangedViewModel
{
	private object? _currentPage;

	private string _selectedPage = "about";

	public object? CurrentPage
	{
		get
		{
			return _currentPage;
		}
		set
		{
			SetProperty(ref _currentPage, value, "CurrentPage");
		}
	}

	public string SelectedPage
	{
		get
		{
			return _selectedPage;
		}
		set
		{
			SetProperty(ref _selectedPage, value, "SelectedPage");
		}
	}

	public IRelayCommand NavigateToAboutCommand { get; }

	public IRelayCommand NavigateToLicensesCommand { get; }

	public IRelayCommand RestartOnboardingCommand { get; }

	public MainWindowViewModel()
	{
		NavigateToAboutCommand = new RelayCommand(NavigateToAbout);
		NavigateToLicensesCommand = new RelayCommand(NavigateToLicenses);
		RestartOnboardingCommand = new RelayCommand(RestartOnboarding);
		NavigateToAbout();
	}

	private void NavigateToAbout()
	{
		try
		{
			SelectedPage = "about";
			CurrentPage = new AboutViewModel();
		}
		catch (Exception argument)
		{
			App.Logger.Error("Unhandled exception: ", argument);
		}
	}

	private void NavigateToLicenses()
	{
		try
		{
			SelectedPage = "licenses";
			CurrentPage = new LicensesViewModel();
		}
		catch (Exception argument)
		{
			App.Logger.Error("Unhandled exception: ", argument);
		}
	}

	private void RestartOnboarding()
	{
		try
		{
			new MainWindow().Show();
		}
		catch (Exception argument)
		{
			App.Logger.Error("Failed to start onboarding: ", argument);
		}
	}
}
