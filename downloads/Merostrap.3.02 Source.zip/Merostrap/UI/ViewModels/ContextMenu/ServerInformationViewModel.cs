using System;
using System.Windows.Input;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Input.Platform;
using Avalonia.Threading;
using CommunityToolkit.Mvvm.Input;
using Merostrap.Integrations;
using Merostrap.Models.Entities;
using Merostrap.Resources;

namespace Merostrap.UI.ViewModels.ContextMenu;

internal class ServerInformationViewModel : NotifyPropertyChangedViewModel
{
	private ActivityWatcher? _activityWatcher;

	private string _serverType = string.Empty;

	private string _instanceId = string.Empty;

	private string _accessCode = string.Empty;

	private string _location = string.Empty;

	private string _uptime = string.Empty;

	private bool _hasServerData;

	private DispatcherTimer? _uptimeTimer;

	private bool _isTimerRunning;

	public string ServerType
	{
		get
		{
			return _serverType;
		}
		set
		{
			SetProperty(ref _serverType, value, "ServerType");
		}
	}

	public string InstanceId
	{
		get
		{
			return _instanceId;
		}
		set
		{
			if (SetProperty(ref _instanceId, value, "InstanceId"))
			{
				OnPropertyChanged("ShowInstanceId");
			}
		}
	}

	public string AccessCode
	{
		get
		{
			return _accessCode;
		}
		set
		{
			if (SetProperty(ref _accessCode, value, "AccessCode"))
			{
				OnPropertyChanged("AccessCodeVisibility");
				OnPropertyChanged("CopyButtonText");
			}
		}
	}

	public string ServerLocation
	{
		get
		{
			return _location;
		}
		set
		{
			if (SetProperty(ref _location, value, "ServerLocation"))
			{
				OnPropertyChanged("ServerLocationVisibility");
			}
		}
	}

	public string ServerUptime
	{
		get
		{
			return _uptime;
		}
		set
		{
			if (SetProperty(ref _uptime, value, "ServerUptime"))
			{
				OnPropertyChanged("ServerUptimeVisibility");
			}
		}
	}

	public bool HasServerData
	{
		get
		{
			return _hasServerData;
		}
		set
		{
			if (SetProperty(ref _hasServerData, value, "HasServerData"))
			{
				OnPropertyChanged("ShowInstanceId");
				OnPropertyChanged("AccessCodeVisibility");
				OnPropertyChanged("ServerLocationVisibility");
				OnPropertyChanged("ServerUptimeVisibility");
				OnPropertyChanged("ShowCopyButton");
				OnPropertyChanged("CopyButtonText");
			}
		}
	}

	public bool ShowInstanceId
	{
		get
		{
			if (HasServerData)
			{
				return !string.IsNullOrEmpty(InstanceId);
			}
			return false;
		}
	}

	public bool AccessCodeVisibility
	{
		get
		{
			if (HasServerData)
			{
				return !string.IsNullOrEmpty(AccessCode);
			}
			return false;
		}
	}

	public bool ServerLocationVisibility
	{
		get
		{
			if (HasServerData && !string.IsNullOrEmpty(ServerLocation))
			{
				return ServerLocation != Strings.Common_NotAvailable;
			}
			return false;
		}
	}

	public bool ServerUptimeVisibility
	{
		get
		{
			if (HasServerData && !string.IsNullOrEmpty(ServerUptime) && ServerUptime != Strings.Common_NotAvailable)
			{
				return App.Settings.Prop.ShowServerUptime;
			}
			return false;
		}
	}

	public bool ShowCopyButton => HasServerData;

	public ICommand CopyCommand { get; }

	public ICommand CloseCommand { get; }

	public string CopyButtonText
	{
		get
		{
			if (!AccessCodeVisibility)
			{
				return Strings.ContextMenu_ServerInformation_CopyInstanceId;
			}
			return Strings.ContextMenu_ServerInformation_CopyAccessCode;
		}
	}

	public ServerInformationViewModel()
	{
		CopyCommand = new RelayCommand<Visual>(CopyToClipboard);
		CloseCommand = new RelayCommand<Window>((Window? window) =>
		{
			window?.Close();
		});
		_uptimeTimer = new DispatcherTimer
		{
			Interval = TimeSpan.FromSeconds(1L)
		};
		_uptimeTimer.Tick += (object? s, EventArgs e) =>
		{
			RefreshUptime();
		};
	}

	public void SetWatcher(ActivityWatcher? watcher)
	{
		_activityWatcher = watcher;
	}

	public void UpdateData(ActivityData data)
	{
		ServerType = data.ServerType.ToString();
		InstanceId = data.JobId;
		AccessCode = data.AccessCode;
		ServerLocation = data.Region ?? Strings.Common_NotAvailable;
		ServerUptime = (data.StartTime.HasValue ? FormatUptime(DateTime.UtcNow - data.StartTime.Value) : Strings.Common_NotAvailable);
		HasServerData = true;
		StartUptimeUpdates();
	}

	public void ClearData()
	{
		StopUptimeUpdates();
		ServerType = string.Empty;
		InstanceId = string.Empty;
		AccessCode = string.Empty;
		ServerLocation = string.Empty;
		ServerUptime = string.Empty;
		HasServerData = false;
	}

	public void RefreshUptime()
	{
		if (_activityWatcher != null && _activityWatcher.InGame)
		{
			ActivityData data = _activityWatcher.Data;
			if (data.StartTime.HasValue)
			{
				ServerUptime = FormatUptime(DateTime.UtcNow - data.StartTime.Value);
			}
			else
			{
				ServerUptime = Strings.Common_NotAvailable;
			}
		}
	}

	public async void RefreshLocation()
	{
		if (_activityWatcher == null || !_activityWatcher.InGame)
		{
			return;
		}
		ActivityData data = _activityWatcher.Data;
		if (!string.IsNullOrEmpty(data.Region))
		{
			ServerLocation = data.Region;
		}
		else if (data.MachineAddressValid)
		{
			string text = await data.QueryServerLocation();
			if (!string.IsNullOrEmpty(text))
			{
				ServerLocation = text;
			}
			else
			{
				ServerLocation = Strings.Common_NotAvailable;
			}
		}
		else
		{
			ServerLocation = Strings.Common_NotAvailable;
		}
	}

	private static string FormatUptime(TimeSpan uptime)
	{
		if (!(uptime.TotalHours >= 1.0))
		{
			return $"{uptime.Minutes}m {uptime.Seconds}s";
		}
		return $"{(int)uptime.TotalHours}h {uptime.Minutes}m {uptime.Seconds}s";
	}

	private async void CopyToClipboard(Visual? visual)
	{
		if (visual != null)
		{
			TopLevel topLevel = TopLevel.GetTopLevel(visual);
			if (topLevel?.Clipboard != null)
			{
				string text = (AccessCodeVisibility ? AccessCode : InstanceId);
				await topLevel.Clipboard.SetTextAsync(text);
			}
		}
	}

	private void StartUptimeUpdates()
	{
		if (!_isTimerRunning && HasServerData && _activityWatcher != null && _activityWatcher.InGame)
		{
			_uptimeTimer?.Start();
			_isTimerRunning = true;
		}
	}

	public void StopUptimeUpdates()
	{
		if (_isTimerRunning)
		{
			_uptimeTimer?.Stop();
			_isTimerRunning = false;
		}
	}
}
