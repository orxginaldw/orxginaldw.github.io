using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;
using Avalonia.Media.Imaging;
using CommunityToolkit.Mvvm.Input;
using Merostrap.Enums;
using Merostrap.Integrations;
using Merostrap.Models.APIs.Roblox;
using Merostrap.Models.Entities;
using Merostrap.Utility;

namespace Merostrap.UI.ViewModels.ContextMenu;

internal class ServerHistoryViewModel : NotifyPropertyChangedViewModel
{
	private readonly ActivityWatcher _activityWatcher;

	public EventHandler? RequestCloseEvent;

	public List<ActivityData>? GameHistory { get; private set; }

	public GenericTriState LoadState { get; private set; } = GenericTriState.Unknown;

	public string Error { get; private set; } = string.Empty;

	public ICommand CloseWindowCommand => new RelayCommand(RequestClose);

	public ICommand CleanOldHistoryCommand => new RelayCommand(CleanOldHistory);

	public ServerHistoryViewModel(ActivityWatcher activityWatcher)
	{
		_activityWatcher = activityWatcher;
		_activityWatcher.OnGameLeave += (object? _, EventArgs _) =>
		{
			LoadData();
		};
		_activityWatcher.OnHistoryUpdated += (object? _, EventArgs _) =>
		{
			LoadData();
		};
		LoadData();
	}

	private async void LoadData()
	{
		LoadState = GenericTriState.Unknown;
		OnPropertyChanged("LoadState");
		try
		{
			await Task.Run((Action)CleanOldEntries);
			List<ActivityData> entriesNeedingDetails = _activityWatcher.History.Where((ActivityData x) => x.UniverseId != 0L && x.UniverseDetails == null && x.TimeJoined > DateTime.Now.AddDays(-30.0)).ToList();
			if (entriesNeedingDetails.Count > 0)
			{
				List<long> values = entriesNeedingDetails.Select((ActivityData x) => x.UniverseId).Distinct().ToList();
				await UniverseDetails.FetchBulk(string.Join(',', values));
				foreach (ActivityData item in entriesNeedingDetails)
				{
					item.UniverseDetails = UniverseDetails.LoadFromCache(item.UniverseId);
				}
			}
			List<ActivityData> processedHistory = ProcessAndConsolidateHistory(_activityWatcher.History);
			string?[] fetchedUrls = await Thumbnails.GetThumbnailUrlsAsync(processedHistory.Select((ActivityData r) => new ThumbnailRequest
			{
				Type = ThumbnailType.GameIcon,
				TargetId = (ulong)r.UniverseId,
				Size = ThumbnailSize.Large
			}).ToList(), CancellationToken.None);
			if (fetchedUrls != null)
			{
				for (int i = 0; i < processedHistory.Count; i++)
				{
					if (i >= fetchedUrls.Length || string.IsNullOrEmpty(fetchedUrls[i]))
					{
						continue;
					}
					try
					{
						using MemoryStream stream = new MemoryStream(await App.HttpClient.GetByteArrayAsync(new Uri(fetchedUrls[i])));
						processedHistory[i].ThumbnailBitmap = new Bitmap(stream);
					}
					catch (Exception ex)
					{
						App.Logger.Error("Failed to load image: " + ex.Message);
					}
				}
			}
			GameHistory = processedHistory;
			if (GameHistory != null)
			{
				foreach (ActivityData item2 in GameHistory)
				{
					item2.OnDeleteRequested += OnActivityDeleteRequested;
				}
			}
			OnPropertyChanged("GameHistory");
			LoadState = GenericTriState.Successful;
			OnPropertyChanged("LoadState");
		}
		catch (Exception ex2)
		{
			App.Logger.Error("Unhandled exception: ", ex2);
			Error = "Failed to load game history: " + ex2.Message;
			OnPropertyChanged("Error");
			LoadState = GenericTriState.Failed;
			OnPropertyChanged("LoadState");
		}
	}

	private static List<ActivityData> ProcessAndConsolidateHistory(List<ActivityData> history)
	{
		DateTime cutoffDate = DateTime.Now.AddDays(-30.0);
		List<ActivityData> list = new List<ActivityData>();
		HashSet<string> hashSet = new HashSet<string>();
		foreach (ActivityData item2 in from x in history
			where x.TimeJoined > cutoffDate
			orderby x.TimeJoined descending
			select x)
		{
			if (item2.ServerType == ServerType.Private || item2.ServerType == ServerType.Reserved)
			{
				continue;
			}
			if (item2.RootActivity != null && !string.IsNullOrEmpty(item2.RootActivity.JobId))
			{
				string rootId = item2.RootActivity.JobId;
				if (!hashSet.Contains(rootId))
				{
					List<ActivityData> list2 = (from x in history
						where (x.RootActivity?.JobId == rootId || x.JobId == rootId) && x.TimeJoined > cutoffDate
						orderby x.TimeJoined descending
						select x).ToList();
					if (list2.Count > 0)
					{
						ActivityData activityData = list2.First();
						ActivityData activityData2 = list2.Last();
						ActivityData item = new ActivityData
						{
							UniverseId = activityData.UniverseId,
							PlaceId = activityData.PlaceId,
							JobId = activityData.JobId,
							UserId = activityData.UserId,
							ServerType = activityData.ServerType,
							TimeJoined = (activityData2.RootActivity?.TimeJoined ?? activityData2.TimeJoined),
							TimeLeft = activityData.TimeLeft,
							UniverseDetails = activityData.UniverseDetails,
							IsTeleport = true,
							RootJobId = rootId
						};
						list.Add(item);
						hashSet.Add(rootId);
					}
				}
			}
			else if (!string.IsNullOrEmpty(item2.JobId) && !hashSet.Contains(item2.JobId))
			{
				list.Add(item2);
				hashSet.Add(item2.JobId);
			}
		}
		return (from x in (from x in list
				group x by x.UniverseId).SelectMany((IGrouping<long, ActivityData> g) => g.OrderByDescending((ActivityData x) => x.TimeJoined).Take(3))
			orderby x.TimeJoined descending
			select x).ToList();
	}

	private void CleanOldEntries()
	{
		try
		{
			DateTime cutoffDate = DateTime.Now.AddDays(-30.0);
			int count = _activityWatcher.History.Count;
			_activityWatcher.History.RemoveAll((ActivityData x) => x.TimeJoined < cutoffDate);
			int num = count - _activityWatcher.History.Count;
			if (num > 0)
			{
				App.Logger.Info($"Removed {num} old history entries (older than {30} days)");
				_activityWatcher.SaveGameHistory();
			}
		}
		catch (Exception argument)
		{
			App.Logger.Error("Unhandled exception: ", argument);
		}
	}

	private void CleanOldHistory()
	{
		CleanOldEntries();
		LoadData();
	}

	private void OnActivityDeleteRequested(object? sender, string jobId)
	{
		DeleteHistoryEntry(jobId);
	}

	public void DeleteHistoryEntry(string jobId)
	{
		try
		{
			int num = _activityWatcher.History.RemoveAll((ActivityData x) => x.JobId == jobId);
			if (!string.IsNullOrEmpty(jobId))
			{
				num += _activityWatcher.History.RemoveAll((ActivityData x) => x.RootActivity?.JobId == jobId);
			}
			if (num > 0)
			{
				App.Logger.Info($"Removed {num} history entries for job {jobId}");
				_activityWatcher.SaveGameHistory();
				LoadData();
			}
		}
		catch (Exception argument)
		{
			App.Logger.Error("Unhandled exception: ", argument);
		}
	}

	private void RequestClose()
	{
		RequestCloseEvent?.Invoke(this, EventArgs.Empty);
	}
}
