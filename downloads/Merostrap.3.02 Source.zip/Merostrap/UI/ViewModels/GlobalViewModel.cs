using System;
using System.Windows.Input;
using CommunityToolkit.Mvvm.Input;
using Merostrap.Utility;

namespace Merostrap.UI.ViewModels;

internal static class GlobalViewModel
{
	public static bool IsWindows => OperatingSystem.IsWindows();

	public static bool IsMacOS => OperatingSystem.IsMacOS();

	public static bool IsLinux => OperatingSystem.IsLinux();

	public static bool IsWindowsOrLinux
	{
		get
		{
			if (!IsWindows)
			{
				return IsLinux;
			}
			return true;
		}
	}

	public static bool IsWindowsOrMacOS
	{
		get
		{
			if (!IsWindows)
			{
				return IsMacOS;
			}
			return true;
		}
	}

	public static ICommand OpenWebpageCommand => new RelayCommand<string>(OpenWebpage);

	private static void OpenWebpage(string? location)
	{
		if (!string.IsNullOrEmpty(location))
		{
			Threading.ShellExecute(location);
		}
	}
}
