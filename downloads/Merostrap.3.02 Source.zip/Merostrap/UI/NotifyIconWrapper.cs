using System;
using System.Globalization;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Threading;
using Merostrap.Backend;
using Merostrap.Enums;
using Merostrap.Integrations;
using Merostrap.Resources;
using Merostrap.UI.Elements.ContextMenu;
using Merostrap.Utility;

namespace Merostrap.UI;

internal class NotifyIconWrapper : IDisposable
{
	private bool _isDisposed;

	private readonly TrayIcon _trayIcon;

	private readonly MenuContainer _menuContainer;

	private readonly Watcher _watcher;

	private DateTime _lastClickTime = DateTime.MinValue;

	private const int DoubleClickThresholdMs = 300;

	private ActivityWatcher? ActivityWatcher => _watcher.ActivityWatcher;

	public NotifyIconWrapper(Watcher watcher)
	{
		App.Logger.Info("Initializing Avalonia TrayIcon");
		_watcher = watcher;
		_menuContainer = new MenuContainer(_watcher);
		NativeMenu menu = NativeMenu.GetMenu(_menuContainer);
		_trayIcon = new TrayIcon
		{
			IsVisible = false,
			ToolTipText = "Merostrap",
			Menu = menu
		};
		_trayIcon.Clicked += OnTrayIconClicked;
		if (ActivityWatcher != null && App.Settings.Prop.ShowServerDetails)
		{
			if (App.Settings.Prop.ShowServerUptime)
			{
				ActivityWatcher.ShowNotif += ShowNotification;
			}
			else
			{
				ActivityWatcher.OnGameJoin += ShowNotification;
			}
		}
		TrayIcon.GetIcons(Application.Current)?.Add(_trayIcon);
	}

	private void OnTrayIconClicked(object? sender, EventArgs e)
	{
		if (!OperatingSystem.IsMacOS())
		{
			HandleWindowsDoubleClickLogic();
		}
	}

	private void HandleWindowsDoubleClickLogic()
	{
		DateTime now = DateTime.Now;
		if ((now - _lastClickTime).TotalMilliseconds <= 300.0)
		{
			_lastClickTime = DateTime.MinValue;
			HandleDoubleClickAction();
		}
		else
		{
			_lastClickTime = now;
		}
	}

	private void HandleDoubleClickAction()
	{
		switch (App.Settings.Prop.DoubleClickAction)
		{
		case TrayDoubleClickAction.None:
			Frontend.ShowMessageBox("You don't have the double-click action set to anything.");
			break;
		case TrayDoubleClickAction.GameHistory:
			if (!App.Settings.Prop.ShowGameHistoryMenu)
			{
				Frontend.ShowMessageBox("Enable 'Game History' in settings to use this feature.");
			}
			else
			{
				new ServerHistory(ActivityWatcher).Show();
			}
			break;
		case TrayDoubleClickAction.ServerInfo:
		{
			if (!App.Settings.Prop.ShowServerDetails)
			{
				Frontend.ShowMessageBox("Enable 'Query Server Location' in settings to use this feature.");
				break;
			}
			ActivityWatcher? activityWatcher = ActivityWatcher;
			if (activityWatcher != null && activityWatcher.InGame)
			{
				_menuContainer.ShowServerInformationWindow();
			}
			else
			{
				Frontend.ShowMessageBox("Join a game first to view server information.");
			}
			break;
		}
		}
	}

	public async void ShowNotification(object? sender, EventArgs e)
	{
		if (App.Settings.Prop.Performance.NetworkMode)
		{
			return;
		}
		App.Logger.Debug("Dispatching event notfification");
		if (ActivityWatcher?.Data != null)
		{
			string title = ActivityWatcher.Data.ServerType switch
			{
				ServerType.Public => Strings.ContextMenu_ServerInformation_Notification_Title_Public, 
				ServerType.Private => Strings.ContextMenu_ServerInformation_Notification_Title_Private, 
				ServerType.Reserved => Strings.ContextMenu_ServerInformation_Notification_Title_Reserved, 
				_ => "", 
			};
			string text = await ActivityWatcher.Data.QueryServerLocation();
			if (string.IsNullOrEmpty(text))
			{
				App.Logger.Error("Couldn't connect to ipinfo.io");
				ShowAlert(string.Format(CultureInfo.InvariantCulture, Strings.Dialog_Connectivity_UnableToConnect, "ipinfo.io"), Strings.ActivityWatcher_LocationQueryFailed);
			}
			else if (!App.Settings.Prop.ShowServerUptime)
			{
				string jobId = ActivityWatcher.Data.JobId;
				ShowAlert(title, string.Format(CultureInfo.InvariantCulture, Strings.ContextMenu_ServerDetails_Notification_Text_ServerID, text, jobId));
			}
			else
			{
				TimeSpan timeSpan = DateTime.UtcNow - (ActivityWatcher.Data.StartTime ?? DateTime.UtcNow);
				string arg = ((timeSpan.TotalMinutes < 1.0) ? Strings.Common_JustStarted : Time.FormatTimeSpan(timeSpan));
				ShowAlert(title, string.Format(CultureInfo.InvariantCulture, Strings.ContextMenu_ServerDetails_Notification_Text, text, arg));
			}
		}
	}

	private void ShowAlert(string title, string message, int duration = 5)
	{
		App.Logger.Debug("Dispatching Alert");
		if (!_isDisposed)
		{
			NativeNotify.SendMessage(title, message, duration);
		}
	}

	public void Dispose()
	{
		if (_isDisposed)
		{
			return;
		}
		_isDisposed = true;
		App.Logger.Info("Cleaning up TrayIcon and MenuContainer");
		Dispatcher.UIThread.Post(() =>
		{
			try
			{
				_trayIcon.IsVisible = false;
				TrayIcon.GetIcons(Application.Current)?.Remove(_trayIcon);
				_menuContainer.Close();
				_trayIcon.Dispose();
			}
			catch (Exception ex)
			{
				App.Logger.Error("Error during cleanup: " + ex.Message);
			}
		});
		if (ActivityWatcher != null)
		{
			ActivityWatcher.ShowNotif -= ShowNotification;
			ActivityWatcher.OnGameJoin -= ShowNotification;
		}
		GC.SuppressFinalize(this);
	}
}
