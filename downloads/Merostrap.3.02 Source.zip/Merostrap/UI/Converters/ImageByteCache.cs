using System;
using System.Collections.Generic;

namespace Merostrap.UI.Converters;

internal sealed class ImageByteCache
{
	private readonly long _maxBytes;

	private readonly int _maxEntries;

	private readonly object _sync;

	private readonly Dictionary<string, LinkedListNode<(string Key, byte[] Bytes)>> _entries;

	private readonly LinkedList<(string Key, byte[] Bytes)> _recent;

	private long _bytes;

	public long Bytes
	{
		get
		{
			lock (_sync)
			{
				return _bytes;
			}
		}
	}

	public int Count
	{
		get
		{
			lock (_sync)
			{
				return _entries.Count;
			}
		}
	}

	public ImageByteCache(long maxBytes, int maxEntries)
	{
		if (maxBytes <= 0)
		{
			throw new ArgumentOutOfRangeException("maxBytes");
		}
		_maxBytes = maxBytes;
		if (maxEntries <= 0)
		{
			throw new ArgumentOutOfRangeException("maxEntries");
		}
		_maxEntries = maxEntries;
		_sync = new object();
		_entries = new Dictionary<string, LinkedListNode<(string, byte[])>>(StringComparer.Ordinal);
		_recent = new LinkedList<(string, byte[])>();
		base._002Ector();
	}

	public byte[]? Get(string key)
	{
		lock (_sync)
		{
			if (!_entries.TryGetValue(key, out LinkedListNode<(string, byte[])> value))
			{
				return null;
			}
			_recent.Remove(value);
			_recent.AddFirst(value);
			return value.Value.Item2;
		}
	}

	public void Add(string key, byte[] bytes)
	{
		if (key.Length > 8192 || bytes.Length == 0 || bytes.LongLength > _maxBytes)
		{
			return;
		}
		lock (_sync)
		{
			if (!_entries.ContainsKey(key))
			{
				while (_entries.Count >= _maxEntries || _bytes + bytes.LongLength > _maxBytes)
				{
					LinkedListNode<(string, byte[])> last = _recent.Last;
					_bytes -= last.Value.Item2.LongLength;
					_entries.Remove(last.Value.Item1);
					_recent.RemoveLast();
				}
				_entries.Add(key, _recent.AddFirst((key, bytes)));
				_bytes += bytes.LongLength;
			}
		}
	}
}
