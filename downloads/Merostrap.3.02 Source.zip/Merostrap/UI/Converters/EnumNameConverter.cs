using System;
using System.Globalization;
using System.Linq;
using Avalonia.Data.Converters;
using Merostrap.Models.Attributes;
using Merostrap.Resources;

namespace Merostrap.UI.Converters;

internal class EnumNameConverter : IValueConverter
{
	public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
	{
		if (!(value is Enum obj))
		{
			return value?.ToString() ?? "Unknown";
		}
		string text = obj.ToString();
		Type type = obj.GetType();
		string fullName = type.FullName;
		if (string.IsNullOrEmpty(fullName))
		{
			return text;
		}
		if (type.GetMember(text).FirstOrDefault()?.GetCustomAttributes(typeof(EnumNameAttribute), inherit: false).FirstOrDefault() is EnumNameAttribute enumNameAttribute)
		{
			if (!string.IsNullOrEmpty(enumNameAttribute.StaticName))
			{
				return enumNameAttribute.StaticName;
			}
			if (!string.IsNullOrEmpty(enumNameAttribute.FromTranslation))
			{
				return Strings.ResourceManager.GetString(enumNameAttribute.FromTranslation, CultureInfo.CurrentCulture) ?? enumNameAttribute.FromTranslation;
			}
		}
		int num = fullName.IndexOf('.', StringComparison.Ordinal);
		string text2 = ((num >= 0) ? fullName.Substring(num + 1) : fullName);
		return Strings.ResourceManager.GetString(text2 + "." + text, CultureInfo.CurrentCulture) ?? (text2 + "." + text);
	}

	public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
	{
		throw new NotSupportedException();
	}
}
