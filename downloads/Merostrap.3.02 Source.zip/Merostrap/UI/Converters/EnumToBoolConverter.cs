using System;
using System.Globalization;
using Avalonia.Data;
using Avalonia.Data.Converters;

namespace Merostrap.UI.Converters;

internal class EnumToBoolConverter : IValueConverter
{
	public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
	{
		if (value == null || parameter == null)
		{
			return false;
		}
		return value.ToString() == parameter.ToString();
	}

	public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
	{
		if (value == null || !value.Equals(true))
		{
			return BindingOperations.DoNothing;
		}
		return parameter;
	}
}
