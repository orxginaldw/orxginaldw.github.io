using System;
using System.Globalization;
using Avalonia.Data.Converters;

namespace Merostrap.UI.Converters;

internal class StringFormatConverter : IValueConverter
{
	private static readonly char[] Separator = new char[1] { '|' };

	public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
	{
		if (!(value is string text))
		{
			return string.Empty;
		}
		if (!(parameter is string text2))
		{
			return text;
		}
		string[] array = text2.Split(Separator);
		CultureInfo currentCulture = CultureInfo.CurrentCulture;
		object[] args = array;
		return string.Format(currentCulture, text, args);
	}

	public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
	{
		throw new NotImplementedException("ConvertBack");
	}
}
