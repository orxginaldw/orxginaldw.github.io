using System;
using System.Globalization;
using Avalonia.Data.Converters;

namespace Merostrap.UI.Converters;

internal class NumberAbbreviationConverter : IValueConverter
{
	public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
	{
		if (value == null)
		{
			return string.Empty;
		}
		string text = value.ToString();
		if (string.IsNullOrEmpty(text))
		{
			return string.Empty;
		}
		if (double.TryParse(text, out var result))
		{
			CultureInfo invariantCulture = CultureInfo.InvariantCulture;
			if (result >= 1000000000.0)
			{
				return (result / 1000000000.0).ToString("0.##", invariantCulture) + "B";
			}
			if (result >= 1000000.0)
			{
				return (result / 1000000.0).ToString("0.##", invariantCulture) + "M";
			}
			if (result >= 1000.0)
			{
				return (result / 1000.0).ToString("0.##", invariantCulture) + "K";
			}
			return result.ToString("0", invariantCulture);
		}
		return text;
	}

	public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
	{
		throw new NotImplementedException();
	}
}
