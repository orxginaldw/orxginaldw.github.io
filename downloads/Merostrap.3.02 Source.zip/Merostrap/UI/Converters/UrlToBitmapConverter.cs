using System;
using System.IO;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Avalonia.Media.Imaging;
using SkiaSharp;

namespace Merostrap.UI.Converters;

internal static class UrlToBitmapConverter
{
	private static readonly ImageByteCache _imageCache = new ImageByteCache(16777216L, 64);

	private static readonly SemaphoreSlim _downloads = new SemaphoreSlim(4, 4);

	public static async Task<Bitmap?> GetBitmapFromCacheOrDownloadAsync(string url, CancellationToken cancellationToken = default(CancellationToken))
	{
		if (url.Length > 8192 || !Uri.TryCreate(url, UriKind.Absolute, out Uri uri) || (uri.Scheme != Uri.UriSchemeHttps && uri.Scheme != Uri.UriSchemeHttp))
		{
			return null;
		}
		bool acquired = false;
		try
		{
			using CancellationTokenSource timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
			timeout.CancelAfter(TimeSpan.FromSeconds(10L));
			await _downloads.WaitAsync(timeout.Token).ConfigureAwait(continueOnCapturedContext: false);
			acquired = true;
			byte[] array = _imageCache.Get(url);
			if (array != null)
			{
				MemoryStream cachedStream = new MemoryStream(array, 0, array.Length, writable: false, publiclyVisible: true);
				try
				{
					return await Task.Run(() => DecodeThumbnail(cachedStream), timeout.Token).ConfigureAwait(continueOnCapturedContext: false);
				}
				finally
				{
					if (cachedStream != null)
					{
						((IDisposable)cachedStream).Dispose();
					}
				}
			}
			using HttpResponseMessage response = await App.HttpClient.GetAsync(uri, HttpCompletionOption.ResponseHeadersRead, timeout.Token).ConfigureAwait(continueOnCapturedContext: false);
			if (!response.IsSuccessStatusCode)
			{
				return null;
			}
			if (response.Content.Headers.ContentLength > 4194304)
			{
				return null;
			}
			Bitmap result;
			await using (Stream stream = await response.Content.ReadAsStreamAsync(timeout.Token).ConfigureAwait(continueOnCapturedContext: false))
			{
				MemoryStream memoryStream = new MemoryStream();
				try
				{
					byte[] buffer = new byte[81920];
					while (true)
					{
						int num;
						if ((num = await stream.ReadAsync(buffer, timeout.Token).ConfigureAwait(continueOnCapturedContext: false)) != 0)
						{
							if (memoryStream.Length + num > 4194304)
							{
								result = null;
								break;
							}
							await memoryStream.WriteAsync(buffer.AsMemory(0, num), timeout.Token).ConfigureAwait(continueOnCapturedContext: false);
							continue;
						}
						memoryStream.Position = 0L;
						Bitmap bitmap = await Task.Run(() => DecodeThumbnail(memoryStream), timeout.Token).ConfigureAwait(continueOnCapturedContext: false);
						if (bitmap == null)
						{
							result = null;
							break;
						}
						_imageCache.Add(url, memoryStream.ToArray());
						result = bitmap;
						break;
					}
				}
				finally
				{
					if (memoryStream != null)
					{
						((IDisposable)memoryStream).Dispose();
					}
				}
			}
			return result;
		}
		catch (OperationCanceledException)
		{
			return null;
		}
		catch
		{
			return null;
		}
		finally
		{
			if (acquired)
			{
				_downloads.Release();
			}
		}
	}

	private static Bitmap? DecodeThumbnail(MemoryStream stream)
	{
		using SKData data = SKData.CreateCopy(stream.GetBuffer().AsSpan(0, checked((int)stream.Length)));
		using SKCodec sKCodec = SKCodec.Create(data);
		if (sKCodec == null)
		{
			return null;
		}
		SKImageInfo info = sKCodec.Info;
		if (info.Width <= 0 || info.Height <= 0 || info.Width > 8192 || info.Height > 8192 || (long)info.Width * (long)info.Height > 16777216)
		{
			return null;
		}
		stream.Position = 0L;
		return (info.Width >= info.Height) ? Bitmap.DecodeToWidth(stream, Math.Min(info.Width, 512)) : Bitmap.DecodeToHeight(stream, Math.Min(info.Height, 512));
	}
}
