﻿#SingleInstance force
#NoEnv
SendMode Input
SetBatchLines, -1
SetMouseDelay, -1

; ---------- CONFIG ----------
FontName := "FOT-Matisse PRO EB"  ; <-- CHANGE THIS TO ANY FONT YOU HAVE INSTALLED
; ----------------------------

; ---------- state ----------
macroRunning := false
clickEnabled := true
zKeyEnabled := false  
rollParryEnabled := true  

; ----------GUI----------
Gui +AlwaysOnTop
Gui, Color, 000000

SplitPath, A_ScriptFullPath,, ScriptDir
ImagePath := ScriptDir . "\nerv.png"
ImagePath2 := ScriptDir . "\s.png"

Gui, Add, Picture, x20 y20 w150 h-1, %ImagePath%
Gui, Add, Picture, x350 y120 w230 h-1, %ImagePath2%

Gui, Font, s16 cFF0000 Bold, %FontName%
Gui, Add, Text, x190 y40 w300 h30, EVIL MACRO

Gui, Font, s11 cFF0000, %FontName%
Gui, Add, Checkbox, x40 y200 vMacroToggle gToggleMacro Checked0, GOLDEN TONGUE MACRO (F4)
Gui, Add, Checkbox, x40 y230 vClickToggle gToggleClick Checked, M1 MACRO (F3 / TOGGLE)
Gui, Add, Checkbox, x40 y260 vZKeyToggle gToggleZKey Checked0, GREEN REINFORCE
Gui, Add, Checkbox, x40 y290 vRollParryToggle gToggleRollParry Checked, ROLL PARRY

Gui, Add, Button, x40 y350 w150 h28 gMinToTray, MINIMIZE
Gui, Add, Button, x200 y350 w70 h28 gExitScript, EXIT

Gui, Show, w600 h400, EVIL MACRO

Menu, Tray, NoStandard
Menu, Tray, Add, OPEN, ShowGui
Menu, Tray, Add
Menu, Tray, Add, EXIT, ExitScript
Menu, Tray, Default, OPEN

Gosub, UpdateStatus
return

#If WinActive("ahk_exe RobloxPlayerBeta.exe")

F4::
    macroRunning := !macroRunning
    GuiControl,, MacroToggle, % macroRunning ? 1 : 0
    if (macroRunning) {
        SetTimer, RunMyMacro, 62000
        Gosub, RunMyMacro
    } else {
        SetTimer, RunMyMacro, Off
    }
    Gosub, UpdateStatus
return

F3::
    clickEnabled := !clickEnabled
    GuiControl,, ClickToggle, % clickEnabled ? 1 : 0
    Gosub, UpdateStatus
return

~LButton::
    if !clickEnabled
        return
    While GetKeyState("LButton", "P"){
        Click
        Sleep 3
    }
return

z::
    Send, z  ; always send z keypress
    if (zKeyEnabled) {
        Sleep, 30
        Send, f
    }
return

y::
    if (!rollParryEnabled)
        return
    Send, f
    Sleep, 10
    Send, q
return

#If

ToggleMacro:
    GuiControlGet, MacroToggle,, MacroToggle
    macroRunning := MacroToggle
    if (macroRunning) {
        SetTimer, RunMyMacro, 62000
        Gosub, RunMyMacro
    } else {
        SetTimer, RunMyMacro, Off
    }
    Gosub, UpdateStatus
return

ToggleClick:
    GuiControlGet, ClickToggle,, ClickToggle
    clickEnabled := ClickToggle
    Gosub, UpdateStatus
return

ToggleZKey:
    GuiControlGet, ZKeyToggle,, ZKeyToggle
    zKeyEnabled := ZKeyToggle
    Gosub, UpdateStatus
return

ToggleRollParry:
    GuiControlGet, RollParryToggle,, RollParryToggle
    rollParryEnabled := RollParryToggle
    Gosub, UpdateStatus
return

RunMyMacro:
    if (!macroRunning)
        return
    if !WinActive("ahk_exe RobloxPlayerBeta.exe")
        return
    Send, /
    Sleep, 30
    Send, s
    Sleep, 35
    Send, {Enter}
return

MinToTray:
    Gui, Hide
    Menu, Tray, Tip, EVIL MACRO (MINIMIZED) - DOUBLE-CLICK TRAY ICON OR CHOOSE 'OPEN' TO RESTORE.
return

ShowGui:
    Gui, Show
    Menu, Tray, Tip
return

ExitScript:
    ExitApp
return

GuiClose:
    Gosub, MinToTray
return

UpdateStatus:
    macroState := macroRunning ? "ON" : "OFF"
    clickState := clickEnabled ? "ON" : "OFF"
    zState := zKeyEnabled ? "ON" : "OFF"
    rollState := rollParryEnabled ? "ON" : "OFF"
    GuiControl,, StatusText, STATUS: MACRO: %macroState%  M1: %clickState%  Z-KEY: %zState%  ROLL PARRY: %rollState%
return
