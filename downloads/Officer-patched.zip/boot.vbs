Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

' Get the current directory where this .vbs file is located
currentDir = fso.GetParentFolderName(WScript.ScriptFullName)

ahkExe = currentDir & "\AutoHotkey_1.1.37.02\AutoHotkeyU64.exe"
ahkScript = currentDir & "\Akai.ahk"

' Check if files exist
If Not fso.FileExists(ahkExe) Then
    MsgBox "Could not find AutoHotkeyU64.exe in AutoHotkey_1.1.37.02 folder.", vbExclamation, "Error"
    WScript.Quit
End If

If Not fso.FileExists(ahkScript) Then
    MsgBox "Could not find Akai.ahk in the current directory.", vbExclamation, "Error"
    WScript.Quit
End If

' Run the script with 64-bit AutoHotkey
shell.Run """" & ahkExe & """ """ & ahkScript & """", 0, False
